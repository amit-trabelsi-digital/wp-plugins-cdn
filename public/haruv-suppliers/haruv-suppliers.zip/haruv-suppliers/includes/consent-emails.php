<?php
/**
 * Consent Emails
 *
 * Handles sending emails for privacy consent requests and confirmations.
 *
 * @package HaruvSuppliers
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Send a consent request email to a supplier/lecturer
 *
 * @param int $post_id Post ID
 * @return bool True on success, false on failure
 */
function haruv_send_consent_request_email($post_id) {
    $post = get_post($post_id);
    if (!$post) {
        return false;
    }
    
    // Get email address
    $email = get_field('email', $post_id);
    if (empty($email)) {
        // Try to get author email if no ACF email field
        $author_id = $post->post_author;
        if ($author_id) {
            $user_info = get_userdata($author_id);
            if ($user_info) {
                $email = $user_info->user_email;
            }
        }
    }
    
    if (empty($email)) {
        return false;
    }
    
    // Generate or get token
    // We use renew here to ensure we have a valid token (either new or extended existing)
    $token = haruv_renew_consent_token($post_id);
    
    // Build consent URL
    // We'll create a custom endpoint or page for this. 
    // Assuming /haruv-consent/ endpoint which we'll handle in consent-form-handler.php
    $consent_url = add_query_arg('token', $token, home_url('/haruv-consent/'));
    
    $subject = 'בקשה לאישור מדיניות פרטיות - מכון חרוב';
    
    $message = haruv_build_consent_request_email_content($post->post_title, $consent_url);
    
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . get_bloginfo('name') . ' <' . get_option('admin_email') . '>'
    );
    
    $sent = wp_mail($email, $subject, $message, $headers);
    
    if ($sent) {
        // Mark as sent in some meta if we want to track last sent date
        update_post_meta($post_id, '_privacy_consent_last_sent', current_time('mysql'));
    }
    
    return $sent;
}

/**
 * Send a confirmation email after consent is given
 *
 * @param int $post_id Post ID
 * @return bool True on success, false on failure
 */
function haruv_send_consent_confirmation_email($post_id) {
    $post = get_post($post_id);
    if (!$post) {
        return false;
    }
    
    // Get email address
    $email = get_field('email', $post_id);
    if (empty($email)) {
        $author_id = $post->post_author;
        if ($author_id) {
            $user_info = get_userdata($author_id);
            if ($user_info) {
                $email = $user_info->user_email;
            }
        }
    }
    
    if (empty($email)) {
        return false;
    }
    
    $privacy_policy_url = 'https://haruv.org.il/%d7%9e%d7%93%d7%99%d7%a0%d7%99%d7%95%d7%aa-%d7%a4%d7%a8%d7%98%d7%99%d7%95%d7%aa-%d7%a1%d7%a4%d7%a7%d7%99%d7%9d-%d7%a9%d7%95%d7%aa%d7%a4%d7%99%d7%9d-%d7%9e%d7%a7%d7%a6%d7%95%d7%a2%d7%99/';
    
    $subject = 'אישור קבלת הסכמה למדיניות פרטיות - מכון חרוב';
    
    $message = haruv_build_consent_confirmation_email_content($post->post_title, $privacy_policy_url);
    
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . get_bloginfo('name') . ' <' . get_option('admin_email') . '>'
    );
    
    return wp_mail($email, $subject, $message, $headers);
}

/**
 * Build HTML content for consent request email
 */
function haruv_build_consent_request_email_content($name, $url) {
    ob_start();
    ?>
    <!DOCTYPE html>
    <html dir="rtl" lang="he">
    <head>
        <meta charset="UTF-8">
        <style>
            body { font-family: Arial, sans-serif; direction: rtl; text-align: right; background-color: #f9f9f9; padding: 20px; }
            .container { max-width: 600px; margin: 0 auto; background-color: #ffffff; padding: 30px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
            .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #007cba; padding-bottom: 20px; }
            .content { font-size: 16px; line-height: 1.6; color: #333; }
            .button-container { text-align: center; margin: 30px 0; }
            .button { display: inline-block; padding: 12px 24px; background-color: #007cba; color: #ffffff !important; text-decoration: none; border-radius: 4px; font-weight: bold; font-size: 16px; }
            .footer { margin-top: 30px; border-top: 1px solid #eee; padding-top: 20px; font-size: 12px; color: #777; text-align: center; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>מכון חרוב - עדכון מדיניות פרטיות</h1>
            </div>
            
            <div class="content">
                <p>שלום <?php echo esc_html($name); ?>,</p>
                
                <p>במסגרת עדכון נהלי העבודה ומדיניות הפרטיות שלנו, אנו מבקשים את אישורך למדיניות הפרטיות המעודכנת.</p>
                
                <p>בקישור המצורף תוכל/י לצפות בפרטים שלך הרשומים אצלנו, לעדכן אותם במידת הצורך, ולאשר את מדיניות הפרטיות.</p>
                
                <div class="button-container">
                    <a href="<?php echo esc_url($url); ?>" class="button">לצפייה בפרטים ואישור המדיניות</a>
                </div>
                
                <p><strong>שים/י לב:</strong> הקישור הינו אישי ותקף ל-7 ימים בלבד.</p>
                
                <p>בברכה,<br>צוות מכון חרוב</p>
            </div>
            
            <div class="footer">
                <p>הודעה זו נשלחה באופן אוטומטי ממערכת הספקים של מכון חרוב.</p>
            </div>
        </div>
    </body>
    </html>
    <?php
    return ob_get_clean();
}

/**
 * Build HTML content for confirmation email
 */
function haruv_build_consent_confirmation_email_content($name, $policy_url) {
    ob_start();
    ?>
    <!DOCTYPE html>
    <html dir="rtl" lang="he">
    <head>
        <meta charset="UTF-8">
        <style>
            body { font-family: Arial, sans-serif; direction: rtl; text-align: right; background-color: #f9f9f9; padding: 20px; }
            .container { max-width: 600px; margin: 0 auto; background-color: #ffffff; padding: 30px; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
            .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #46b450; padding-bottom: 20px; }
            .content { font-size: 16px; line-height: 1.6; color: #333; }
            .footer { margin-top: 30px; border-top: 1px solid #eee; padding-top: 20px; font-size: 12px; color: #777; text-align: center; }
            a { color: #007cba; text-decoration: none; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>תודה על אישורך</h1>
            </div>
            
            <div class="content">
                <p>שלום <?php echo esc_html($name); ?>,</p>
                
                <p>תודה שאישרת את מדיניות הפרטיות שלנו.</p>
                
                <p>הסכמתך נרשמה במערכת בתאריך <?php echo date('d/m/Y'); ?> בשעה <?php echo date('H:i'); ?>.</p>
                
                <p>לעיון במדיניות הפרטיות המלאה בכל עת, ניתן להיכנס לקישור הבא:<br>
                <a href="<?php echo esc_url($policy_url); ?>">מדיניות פרטיות - ספקים ושותפים מקצועיים</a></p>
                
                <p>בברכה,<br>צוות מכון חרוב</p>
            </div>
            
            <div class="footer">
                <p>הודעה זו נשלחה באופן אוטומטי ממערכת הספקים של מכון חרוב.</p>
            </div>
        </div>
    </body>
    </html>
    <?php
    return ob_get_clean();
}

