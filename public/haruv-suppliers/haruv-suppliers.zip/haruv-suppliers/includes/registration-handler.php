<?php
/**
 * Registration Handler — consolidates lecturer/supplier registration SAVE logic
 * into the plugin so a production deploy of this plugin alone "just works".
 *
 * The forms themselves are still rendered by the theme templates via ACF's
 * acf_form() / Gravity Forms — that is unchanged. This file only owns what
 * happens AFTER submit, and neutralizes the legacy theme handlers so they do
 * not run in parallel (no duplicate emails, no rate overwrites).
 *
 * Responsibilities:
 *   1. Neutralize the theme's old registration hooks (naf-functions.php,
 *      gravityforms-addons.php) at runtime.
 *   2. Derive the hourly rate from the academic degree ON CREATION ONLY
 *      (idempotent — never overwrites a rate that already has a value, so
 *      staff can change it manually afterward).
 *   3. Finalize a lecture post (status + title) after ACF save.
 *   4. Take over the internal Gravity Forms lecturer create/edit, saving to
 *      the correct explicit ACF field keys.
 *   5. Re-add the chashav_id uniqueness validation.
 *
 * @package Haruv_Suppliers
 * @since   1.6.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/* -------------------------------------------------------------------------
 * ACF field-key maps (field NAMES collide across groups, so we save by KEY).
 * ---------------------------------------------------------------------- */

/**
 * Group 6 "פרטי המרצה" — shown on the lecture edit screen; used by the
 * internal Gravity Forms lecturer form.
 */
function haruv_lecture_field_keys_group6() {
    return array(
        'email'      => 'field_5fa06328d559b',
        'gender'     => 'field_5fa05d492be59',
        'vat_id'     => 'field_605707fe11486',
        'chashav_id' => 'field_5fa06258d5599',
        'mobile'     => 'field_5fa05e032be5e',
        'phone'      => 'field_5fa05e0e2be5f',
        'resume'     => 'field_5fa05e9b2be61',
        'zone'       => 'field_5fa05dd22be5d',
        'year_birth' => 'field_5fa05d082be58',
        'inner_desc' => 'field_5fa06bb5ea5ae',
        'hour_price' => 'field_5fa05fcc2be63',
        'type_biz'   => 'field_5fa05ca82be57',
        'degree'     => 'field_5fa05ee82be62',
        'org_name'   => 'field_5fbe2309811f7',
        'address'    => 'field_5fa05d632be5a',
        'file'       => 'field_60c87ed9e549e',
    );
}

/** hour_price field key in the public "רישום מרצה - כללי" group (1203). */
define('HARUV_HOUR_PRICE_KEY_PUBLIC', 'field_648977e669671');
/** hour_price field key in group 6 (internal / edit screen). */
define('HARUV_HOUR_PRICE_KEY_GROUP6', 'field_5fa05fcc2be63');

/* -------------------------------------------------------------------------
 * 1. Neutralize the legacy theme hooks (run after the theme registers them).
 * ---------------------------------------------------------------------- */

add_action('wp_loaded', 'haruv_neutralize_theme_registration_hooks', 5);
function haruv_neutralize_theme_registration_hooks() {
    // Public ACF-form lecturer save (naf-functions.php) — replaced by the plugin.
    remove_action('acf/save_post', 'save_new_lecture_naf', 10);
    remove_action('acf/save_post', 'update_lecture_naf', 10);
    remove_filter('acf/validate_value/name=chashav_id', 'chashav_id_unique', 10);

    // Internal Gravity Forms lecturer create/edit (gravityforms-addons.php).
    remove_action('gform_after_submission_1', 'set_post_content', 10);
    remove_action('gform_after_submission_3', 'update_post_content', 10);

    // NOTE: intentionally KEPT (render/UX, not save logic):
    //   naf_lecture_redirect_post, inject_acf_form_head, change_author,
    //   acf/prepare_field label filters, populate_posts* GF choice-builders.
}

/* -------------------------------------------------------------------------
 * 2. Rate-by-degree — on creation only, idempotent (manual edits preserved).
 * ---------------------------------------------------------------------- */

/**
 * Map an academic-degree choice value to the hourly-rate choice value.
 * hour_price ACF choices: 1=305, 2=365, 3=415, 4=450.
 * degree: 1=תואר ראשון, 2=תואר שני, 3=תואר שלישי, 4=מומחה, 5=דוקטור, …
 * Rule (from existing data): ראשון→305, שני→365, שלישי ומעלה→415.
 *
 * @return string '' when the degree is unknown/unmapped, else '1'|'2'|'3'.
 */
/**
 * Normalize a degree meta value to a scalar. Some historic/imported lecturers
 * store `degree` as a serialized array (e.g. array('5')) rather than a plain
 * string. A bare (int) cast on such an array yields 1 (+ a PHP warning), which
 * would silently map every one of them to the cheapest rate. Always reduce to
 * the first element first.
 *
 * @param mixed $degree
 * @return string
 */
function haruv_reg_scalar_degree($degree) {
    if (is_array($degree)) {
        $degree = reset($degree);
    }
    return (string) $degree;
}

function haruv_reg_rate_from_degree($degree) {
    $degree = (int) haruv_reg_scalar_degree($degree);
    $map = array(
        1 => '1', // תואר ראשון → 305
        2 => '2', // תואר שני   → 365
        3 => '3', // תואר שלישי → 415
        4 => '3', // מומחה      → 415
        5 => '3', // דוקטור     → 415
        6 => '3', // מומחה מנסיון חיים → 415
        7 => '3', // פסיכולוג מוסמך    → 415
        8 => '4', // פרופסור          → 450
        // 9 (פעילות הפגתית) ו-10 (אחר) נשארים ללא מיפוי בכוונה: admin.js כבר
        // מציב עבורם 450 בממשק, ואי-מיפוי כאן מונע דריסה של תעריף שנקבע ידנית.
    );
    return isset($map[$degree]) ? $map[$degree] : '';
}

/**
 * The standard hour_price choice values (ACF: 1=305, 2=365, 3=415, 4=450).
 * A rate that equals one of these is a "standard" rate that may be corrected
 * to match the degree. Anything else (e.g. a hand-typed 500) is a special
 * price the staff set on purpose and must never be touched.
 */
function haruv_reg_standard_rates() {
    return array('1', '2', '3', '4');
}

add_action('acf/save_post', 'haruv_derive_lecture_rate', 15);
function haruv_derive_lecture_rate($post_id) {
    if (!is_numeric($post_id) || get_post_type($post_id) !== 'lecture') {
        return;
    }

    // Raw degree value (the ACF field returns the LABEL when formatted).
    $degree = get_post_meta($post_id, 'degree', true);
    if ($degree === '' || $degree === null) {
        return;
    }

    $rate = haruv_reg_rate_from_degree($degree);
    if ($rate === '') {
        return; // degree unmapped — nothing to derive.
    }

    // Current rate — read raw.
    $current = get_post_meta($post_id, 'hour_price', true);

    // Decide whether to (re)derive:
    //  - empty            → derive (first save / public form).
    //  - standard value   → correct it to match the degree (this is the fix:
    //                       e.g. a doctor still showing 305 gets bumped to 415).
    //  - already correct  → nothing to do.
    //  - special price    → respect it, never overwrite.
    if ($current !== '' && $current !== null) {
        if ($current === $rate) {
            return; // already matches the degree.
        }
        if (!in_array((string) $current, haruv_reg_standard_rates(), true)) {
            return; // special (manual) price — leave it alone.
        }
        // else: standard rate that doesn't match the degree → fall through & fix.
    }

    // Write to whichever hour_price field the post actually uses. The public
    // form records its own key in _hour_price; the wp-admin edit screen / GF
    // form use group 6. Prefer the recorded key, then group 6 for admin edits,
    // then the public key.
    $key_ref = get_post_meta($post_id, '_hour_price', true);
    if ($key_ref) {
        $key = $key_ref;
    } elseif (is_admin() && !wp_doing_ajax()) {
        $key = HARUV_HOUR_PRICE_KEY_GROUP6;
    } else {
        $key = HARUV_HOUR_PRICE_KEY_PUBLIC;
    }
    update_field($key, $rate, $post_id);
}

/* -------------------------------------------------------------------------
 * 3. Finalize a lecture post after ACF save (status + title). Front-end only.
 *    Ports save_new_lecture_naf() (status) + update_lecture_naf() (title).
 * ---------------------------------------------------------------------- */

add_action('acf/save_post', 'haruv_finalize_lecture', 16);
function haruv_finalize_lecture($post_id) {
    if (!is_numeric($post_id) || get_post_type($post_id) !== 'lecture') {
        return;
    }
    if (is_admin() && !wp_doing_ajax()) {
        return; // don't fight manual admin edits.
    }

    // New submissions land as "pending review" (lecturer_status 2 → pending).
    if (get_field('lecturer_status', $post_id) === false || get_field('lecturer_status', $post_id) === '') {
        update_field('lecturer_status', '2', $post_id);
    }
    $post_status = (get_field('lecturer_status', $post_id) == 2) ? 'pending' : 'publish';

    $update = array('ID' => $post_id, 'post_status' => $post_status);

    // Sync the title from first/last name when present (public form).
    $first = get_field('first_name', $post_id);
    $last  = get_field('last_name', $post_id);
    if ($first && $last) {
        $update['post_title'] = trim($first . ' ' . $last);
    }

    // Avoid infinite loop: unhook, update, rehook.
    remove_action('acf/save_post', 'haruv_finalize_lecture', 16);
    wp_update_post($update);
    add_action('acf/save_post', 'haruv_finalize_lecture', 16);
}

/* -------------------------------------------------------------------------
 * 3b. Don't demand required fields that conditional logic is hiding.
 *
 * ACF evaluates conditional_logic in the browser only. Server-side it still
 * insists on a value, so a required-but-hidden field (e.g. ת"ז / אישור ניכוי
 * מס, shown only for סוג עוסק 5–6) blocks the whole registration form — with a
 * generic "יש למלא את כל שדות החובה" notice and nothing marked in red, because
 * the offending field isn't on screen. Originally fixed in 1.6.1; the fix was
 * lost when this file was rewritten for 1.6.5 and is restored here.
 * ---------------------------------------------------------------------- */

add_filter('acf/validate_value', 'haruv_skip_hidden_required_fields', 20, 4);
function haruv_skip_hidden_required_fields($valid, $value, $field, $input) {
    // Only step in when ACF is about to reject a required field.
    if ($valid === true || empty($field['required'])) {
        return $valid;
    }
    if (empty($field['conditional_logic']) || !is_array($field['conditional_logic'])) {
        return $valid;
    }
    if (!isset($_POST['acf']) || !is_array($_POST['acf'])) {
        return $valid;
    }
    // Visible for real → keep the requirement. Hidden → nothing to fill in.
    if (haruv_acf_conditional_logic_passes($field['conditional_logic'], $_POST['acf'])) {
        return $valid;
    }
    return true;
}

/** conditional_logic = OR-list of AND-groups. */
function haruv_acf_conditional_logic_passes($groups, $posted) {
    foreach ((array) $groups as $group) {
        $group_passes = true;
        foreach ((array) $group as $rule) {
            if (!haruv_acf_rule_passes($rule, $posted)) {
                $group_passes = false;
                break;
            }
        }
        if ($group_passes) {
            return true;
        }
    }
    return false;
}

function haruv_acf_rule_passes($rule, $posted) {
    if (empty($rule['field'])) {
        return true; // malformed rule — assume visible, keep the requirement.
    }
    $actual   = haruv_acf_find_posted_value($rule['field'], $posted);
    $expected = isset($rule['value']) ? (string) $rule['value'] : '';
    $operator = isset($rule['operator']) ? $rule['operator'] : '==';

    $is_empty = ($actual === null || $actual === '' || $actual === array());
    $matches  = is_array($actual)
        ? in_array($expected, array_map('strval', $actual), true)
        : ((string) $actual === $expected);

    switch ($operator) {
        case '==':
            return $matches;
        case '!=':
            return !$matches;
        case '==empty':
            return $is_empty;
        case '!=empty':
            return !$is_empty;
        case '==contains':
            return is_array($actual)
                ? $matches
                : (strpos((string) $actual, $expected) !== false);
        default:
            return true; // unknown operator — assume visible (never loosen validation blindly).
    }
}

/** $_POST['acf'] is nested by parent field key; find a key anywhere in the tree. */
function haruv_acf_find_posted_value($key, $posted) {
    if (!is_array($posted)) {
        return null;
    }
    if (array_key_exists($key, $posted)) {
        return $posted[$key];
    }
    foreach ($posted as $child) {
        if (is_array($child)) {
            $found = haruv_acf_find_posted_value($key, $child);
            if ($found !== null) {
                return $found;
            }
        }
    }
    return null;
}

/* -------------------------------------------------------------------------
 * 4. chashav_id uniqueness validation (port of chashav_id_unique).
 * ---------------------------------------------------------------------- */

add_filter('acf/validate_value/name=chashav_id', 'haruv_validate_chashav_unique', 10, 4);
function haruv_validate_chashav_unique($valid, $value, $field, $input) {
    if ($valid !== true) {
        return $valid;
    }
    if ($value === '' || $value === null) {
        return $valid;
    }
    // The post being edited. 'post_id' only exists on a front-end acf_form();
    // the wp-admin editor posts 'post_ID' and ACF posts '_acf_post_id'. Missing
    // it here made a lecturer collide with ITSELF, so ACF failed validation and
    // silently discarded every field value while WP still reported "עודכן".
    $post_id = 0;
    foreach (array('post_id', '_acf_post_id', 'post_ID') as $key) {
        if (!empty($_POST[$key]) && is_numeric($_POST[$key])) {
            $post_id = (int) $_POST[$key];
            break;
        }
    }
    if (!$post_id) {
        $post_id = (int) get_the_ID();
    }

    $lectures = get_posts(array(
        'post_type'    => 'lecture',
        'post_status'  => 'any',
        'fields'       => 'ids',
        'numberposts'  => 2,
        'post__not_in' => $post_id ? array($post_id) : array(),
        'meta_query'   => array(
            array('key' => 'chashav_id', 'value' => $value, 'compare' => '='),
        ),
    ));

    if (!empty($lectures)) {
        $title = get_the_title($lectures[0]);
        return 'קיים מרצה עם מזהה חשבשת זה: ' . $title;
    }
    return $valid;
}

/* -------------------------------------------------------------------------
 * 5. Internal Gravity Forms lecturer create / edit (form 1 / form 3).
 *    Ports set_post_content()/update_post_content() using explicit group-6
 *    keys (fixes the historical bare-name bind bug on the edit handler too).
 * ---------------------------------------------------------------------- */

add_action('gform_after_submission_1', 'haruv_gf_create_lecture', 10, 2);
function haruv_gf_create_lecture($entry, $form) {
    $post = wp_insert_post(array(
        'post_title'   => basename($entry[1]),
        'post_type'    => 'lecture',
        'post_status'  => 'pending',
        'post_content' => isset($entry[2]) ? $entry[2] : '',
        'post_author'  => isset($entry['created_by']) ? $entry['created_by'] : 0,
    ));
    if (is_wp_error($post) || !$post) {
        return;
    }

    $k = haruv_lecture_field_keys_group6();

    // Rate follows the degree (idempotent derivation happens on create here).
    $hour_price = haruv_reg_rate_from_degree(isset($entry[23]) ? $entry[23] : '');
    if ($hour_price === '') {
        $hour_price = isset($entry[24]) ? $entry[24] : '';
    }

    update_field($k['email'],      isset($entry[3])  ? $entry[3]  : '', $post);
    update_field($k['gender'],     isset($entry[28]) ? $entry[28] : '', $post);
    update_field($k['vat_id'],     isset($entry[21]) ? $entry[21] : '', $post);
    update_field($k['chashav_id'], isset($entry[8])  ? $entry[8]  : '', $post);
    update_field($k['mobile'],     isset($entry[4])  ? $entry[4]  : '', $post);
    update_field($k['phone'],      isset($entry[27]) ? $entry[27] : '', $post);
    update_field($k['resume'],     isset($entry[1])  ? $entry[1]  : '', $post);
    update_field($k['zone'],       isset($entry[22]) ? $entry[22] : '', $post);
    update_field($k['year_birth'], isset($entry[5])  ? $entry[5]  : '', $post);
    update_field($k['inner_desc'], isset($entry[9])  ? $entry[9]  : '', $post);
    update_field($k['hour_price'], $hour_price, $post);
    update_field($k['type_biz'],   isset($entry[25]) ? $entry[25] : '', $post);
    update_field($k['degree'],     isset($entry[23]) ? $entry[23] : '', $post);
    update_field($k['org_name'],   isset($entry[30]) ? $entry[30] : '', $post);
    update_field($k['address'], array(
        'city'     => isset($entry['18.3']) ? $entry['18.3'] : '',
        'street'   => isset($entry['18.1']) ? $entry['18.1'] : '',
        'zip_code' => isset($entry['18.5']) ? $entry['18.5'] : '',
    ), $post);

    // Taxonomies.
    if (!empty($entry['11.1'])) { wp_set_post_terms($post, $entry['11.1'], 'lecturer_type'); }
    if (!empty($entry['12.1'])) { wp_set_post_terms($post, $entry['12.1'], 'languages'); }
    if (!empty($entry['13.1'])) { wp_set_post_terms($post, $entry['13.1'], 'activity_type'); }
    if (!empty($entry['14.1'])) { wp_set_post_terms($post, $entry['14.1'], 'audince_type'); }
    if (!empty($entry['15.1'])) { wp_set_post_terms($post, $entry['15.1'], 'audince_size'); }

    // Optional uploaded file → attachment.
    if (!empty($entry[6])) {
        $filename = $entry[6];
        $filetype = wp_check_filetype(basename($filename), null);
        $upload   = wp_upload_dir();
        $attach_id = wp_insert_attachment(array(
            'guid'           => $upload['url'] . '/' . basename($filename),
            'post_mime_type' => $filetype['type'],
            'post_title'     => preg_replace('/\.[^.]+$/', '', basename($filename)),
            'post_content'   => '',
            'post_status'    => 'inherit',
        ), $filename);
        if (!is_wp_error($attach_id)) {
            update_field($k['file'], $attach_id, $post);
        }
    }
}

add_action('gform_after_submission_3', 'haruv_gf_update_lecture', 10, 2);
function haruv_gf_update_lecture($entry, $form) {
    $post_id = isset($entry[35]) ? (int) $entry[35] : 0;
    if (!$post_id || get_post_type($post_id) !== 'lecture') {
        return;
    }

    $update = array('ID' => $post_id);
    if (!empty($entry[2])) { $update['post_content'] = $entry[2]; }
    if (!empty($entry[1])) { $update['post_title']   = $entry[1]; }
    if (!empty($entry['created_by'])) { $update['post_author'] = $entry['created_by']; }
    wp_update_post($update);

    $k = haruv_lecture_field_keys_group6();

    update_field($k['email'],      isset($entry[3])  ? $entry[3]  : '', $post_id);
    if (isset($entry[36]) && $entry[36] !== '') {
        update_field('email_2', $entry[36], $post_id); // no group-6 dup; keep name
    }
    update_field($k['gender'],     isset($entry[28]) ? $entry[28] : '', $post_id);
    update_field($k['vat_id'],     isset($entry[21]) ? $entry[21] : '', $post_id);
    update_field($k['chashav_id'], isset($entry[8])  ? $entry[8]  : '', $post_id);
    update_field($k['mobile'],     isset($entry[4])  ? $entry[4]  : '', $post_id);
    update_field($k['phone'],      isset($entry[27]) ? $entry[27] : '', $post_id);
    update_field($k['resume'],     isset($entry[1])  ? $entry[1]  : '', $post_id);
    update_field($k['zone'],       isset($entry[22]) ? $entry[22] : '', $post_id);
    update_field($k['year_birth'], isset($entry[5])  ? $entry[5]  : '', $post_id);
    update_field($k['inner_desc'], isset($entry[9])  ? $entry[9]  : '', $post_id);
    update_field($k['type_biz'],   isset($entry[25]) ? $entry[25] : '', $post_id);
    update_field($k['degree'],     isset($entry[23]) ? $entry[23] : '', $post_id);
    update_field($k['org_name'],   isset($entry[30]) ? $entry[30] : '', $post_id);
    update_field($k['address'], array(
        'city'     => isset($entry['18.3']) ? $entry['18.3'] : '',
        'street'   => isset($entry['18.1']) ? $entry['18.1'] : '',
        'zip_code' => isset($entry['18.5']) ? $entry['18.5'] : '',
    ), $post_id);

    // On EDIT we intentionally do NOT re-derive hour_price — respect the saved
    // value so a manual rate is preserved. (Only entry[24] if explicitly sent.)
    if (isset($entry[24]) && $entry[24] !== '' && (get_post_meta($post_id, 'hour_price', true) === '')) {
        update_field($k['hour_price'], $entry[24], $post_id);
    }

    if (!empty($entry['11.1'])) { wp_set_post_terms($post_id, $entry['11.1'], 'lecturer_type'); }
    if (!empty($entry['12.1'])) { wp_set_post_terms($post_id, $entry['12.1'], 'languages'); }
    if (!empty($entry['13.1'])) { wp_set_post_terms($post_id, $entry['13.1'], 'activity_type'); }
    if (!empty($entry['14.1'])) { wp_set_post_terms($post_id, $entry['14.1'], 'audince_type'); }
    if (!empty($entry['15.1'])) { wp_set_post_terms($post_id, $entry['15.1'], 'audince_size'); }
}
