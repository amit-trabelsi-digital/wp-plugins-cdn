<?php
/**
 * Taxonomies Registration for Haruv Suppliers
 *
 * @package HaruvSuppliers
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register Geographic Areas Taxonomy
 */
function haruv_register_geographic_area_taxonomy() {
    // Prevent conflicts with theme code
    if (defined('HARUV_SUPPLIERS_THEME_ACTIVE')) {
        return; // Theme already registered this taxonomy
    }
    $labels = array(
        'name'              => __('אזורים גיאוגרפים', 'haruv-suppliers'),
        'singular_name'     => __('אזור גיאוגרפי', 'haruv-suppliers'),
        'search_items'      => __('חפש אזורים', 'haruv-suppliers'),
        'all_items'         => __('כל האזורים', 'haruv-suppliers'),
        'edit_item'         => __('ערוך אזור', 'haruv-suppliers'),
        'update_item'       => __('עדכן אזור', 'haruv-suppliers'),
        'add_new_item'      => __('הוסף אזור חדש', 'haruv-suppliers'),
        'new_item_name'     => __('שם אזור חדש', 'haruv-suppliers'),
        'menu_name'         => __('אזורים גיאוגרפים', 'haruv-suppliers')
    );

    register_taxonomy('geographic_area', array('venue'), array(
        'hierarchical'      => true,
        'labels'           => $labels,
        'show_ui'          => true,
        'show_admin_column' => true,
        'query_var'        => true,
        'rewrite'          => array('slug' => 'area'),
        'show_in_rest'     => true
    ));
}

/**
 * Register Supplier Tags Taxonomy (for all supplier types)
 */
function haruv_register_supplier_tags_taxonomy() {
    // Prevent conflicts with theme code
    if (defined('HARUV_SUPPLIERS_THEME_ACTIVE')) {
        return; // Theme already registered this taxonomy
    }
    $labels = array(
        'name'              => __('תגיות ספקים', 'haruv-suppliers'),
        'singular_name'     => __('תגית ספק', 'haruv-suppliers'),
        'search_items'      => __('חפש תגיות', 'haruv-suppliers'),
        'all_items'         => __('כל התגיות', 'haruv-suppliers'),
        'edit_item'         => __('ערוך תגית', 'haruv-suppliers'),
        'update_item'       => __('עדכן תגית', 'haruv-suppliers'),
        'add_new_item'      => __('הוסף תגית חדשה', 'haruv-suppliers'),
        'new_item_name'     => __('שם תגית חדשה', 'haruv-suppliers'),
        'menu_name'         => __('תגיות ספקים', 'haruv-suppliers')
    );

    $supplier_types = array('photographer', 'venue', 'catering', 'printing', 'administration', 'hotel');

    register_taxonomy('supplier_tag', $supplier_types, array(
        'hierarchical'      => false,
        'labels'           => $labels,
        'show_ui'          => true,
        'show_admin_column' => true,
        'query_var'        => true,
        'rewrite'          => array('slug' => 'supplier-tag'),
        'show_in_rest'     => true
    ));
}

// Hook into WordPress
add_action('init', 'haruv_register_geographic_area_taxonomy');
add_action('init', 'haruv_register_supplier_tags_taxonomy');
