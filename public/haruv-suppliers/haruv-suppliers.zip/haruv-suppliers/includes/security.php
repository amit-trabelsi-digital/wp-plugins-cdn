<?php
/**
 * Security Functions for Haruv Suppliers
 *
 * @package HaruvSuppliers
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Generate nonce for AJAX requests
 */
function haruv_generate_ajax_nonce() {
    return wp_create_nonce('haruv_suppliers_nonce');
}

/**
 * Verify AJAX nonce
 */
function haruv_verify_ajax_nonce($nonce) {
    return wp_verify_nonce($nonce, 'haruv_suppliers_nonce');
}

/**
 * Sanitize and validate supplier data
 */
function haruv_sanitize_supplier_data($data) {
    $sanitized = array();

    // Sanitize basic fields
    $text_fields = array('name', 'description', 'email', 'phone', 'address', 'organization');
    foreach ($text_fields as $field) {
        if (isset($data[$field])) {
            $sanitized[$field] = sanitize_text_field($data[$field]);
        }
    }

    // Sanitize email specifically
    if (isset($data['email'])) {
        $sanitized['email'] = sanitize_email($data['email']);
    }

    // Sanitize numeric fields
    $numeric_fields = array('capacity', 'room_count');
    foreach ($numeric_fields as $field) {
        if (isset($data[$field])) {
            $sanitized[$field] = intval($data[$field]);
        }
    }

    // Sanitize arrays safely
    $array_fields = array('photo_type', 'equipment', 'print_type', 'materials', 'services', 'cuisine_type');
    foreach ($array_fields as $field) {
        if (isset($data[$field]) && is_array($data[$field])) {
            $sanitized[$field] = array_map('sanitize_text_field', $data[$field]);
        }
    }

    return $sanitized;
}

/**
 * Validate user capabilities for supplier operations
 */
function haruv_check_supplier_permissions($post_id = null, $action = 'edit') {
    // Basic capability check
    if (!current_user_can('manage_options')) {
        return new WP_Error('insufficient_permissions', 'אין לך הרשאות לבצע פעולה זו');
    }

    // If post_id is provided, check post-specific permissions
    if ($post_id) {
        $post = get_post($post_id);
        if (!$post) {
            return new WP_Error('post_not_found', 'הפוסט לא נמצא');
        }

        // Check if user can edit this specific post
        if ($action === 'edit' && !current_user_can('edit_post', $post_id)) {
            return new WP_Error('cannot_edit_post', 'אין לך הרשאות לערוך פוסט זה');
        }
    }

    return true;
}

/**
 * Safe field output for templates
 */
function haruv_esc_field($field, $context = 'display') {
    if (is_array($field)) {
        if (isset($field['label'])) {
            return esc_html($field['label']);
        }
        return esc_html(implode(', ', $field));
    }

    return esc_html($field);
}

/**
 * Validate supplier type
 */
function haruv_validate_supplier_type($type) {
    $allowed_types = array('photographer', 'venue', 'catering', 'hotel', 'printing', 'administration', 'workshop');

    if (!in_array($type, $allowed_types)) {
        return new WP_Error('invalid_supplier_type', 'סוג ספק לא תקין');
    }

    return true;
}

/**
 * Log security events
 */
function haruv_log_security_event($event, $data = array()) {
    $log_data = array(
        'timestamp' => current_time('Y-m-d H:i:s'),
        'event' => $event,
        'user_id' => get_current_user_id(),
        'user_ip' => haruv_get_client_ip(),
        'data' => $data
    );

    error_log('Haruv Suppliers Security: ' . wp_json_encode($log_data));
}

/**
 * Get client IP address safely
 */
function haruv_get_client_ip() {
    $ip_headers = array(
        'HTTP_CF_CONNECTING_IP',
        'HTTP_CLIENT_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_FORWARDED',
        'HTTP_X_CLUSTER_CLIENT_IP',
        'HTTP_FORWARDED_FOR',
        'HTTP_FORWARDED',
        'REMOTE_ADDR'
    );

    foreach ($ip_headers as $header) {
        if (!empty($_SERVER[$header])) {
            $ip = $_SERVER[$header];

            // Handle comma-separated IPs (like X-Forwarded-For)
            if (strpos($ip, ',') !== false) {
                $ip = trim(explode(',', $ip)[0]);
            }

            // Validate IP
            if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                return $ip;
            }
        }
    }

    return 'unknown';
}

/**
 * Rate limiting for API calls
 */
function haruv_check_rate_limit($identifier, $limit = 100, $time_window = 3600) {
    $transient_key = 'haruv_rate_limit_' . md5($identifier);
    $current_count = get_transient($transient_key);

    if ($current_count === false) {
        set_transient($transient_key, 1, $time_window);
        return true;
    }

    if ($current_count >= $limit) {
        haruv_log_security_event('rate_limit_exceeded', array('identifier' => $identifier));
        return false;
    }

    set_transient($transient_key, $current_count + 1, $time_window);
    return true;
}

/**
 * Validate and sanitize file uploads
 */
function haruv_validate_file_upload($file) {
    // Check file type
    $allowed_types = array('image/jpeg', 'image/png', 'image/gif', 'application/pdf');

    if (!in_array($file['type'], $allowed_types)) {
        return new WP_Error('invalid_file_type', 'סוג קובץ לא מורשה');
    }

    // Check file size (max 10MB)
    $max_size = 10 * 1024 * 1024;
    if ($file['size'] > $max_size) {
        return new WP_Error('file_too_large', 'הקובץ גדול מדי (מקסימום 10MB)');
    }

    // Check for malicious content
    if (haruv_scan_file_for_malware($file['tmp_name'])) {
        haruv_log_security_event('malicious_file_detected', array('filename' => $file['name']));
        return new WP_Error('malicious_file', 'הקובץ מכיל תוכן חשוד');
    }

    return true;
}

/**
 * Basic malware scan (simplified)
 */
function haruv_scan_file_for_malware($file_path) {
    $content = file_get_contents($file_path);

    // Check for common malicious patterns
    $malicious_patterns = array(
        '<?php',
        'eval(',
        'base64_decode',
        'system(',
        'exec(',
        'shell_exec'
    );

    foreach ($malicious_patterns as $pattern) {
        if (stripos($content, $pattern) !== false) {
            return true;
        }
    }

    return false;
}
