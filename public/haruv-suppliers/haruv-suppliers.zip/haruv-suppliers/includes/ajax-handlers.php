<?php
/**
 * AJAX Handlers for Haruv Suppliers
 *
 * @package HaruvSuppliers
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Get suppliers data for admin tables
 */
function haruv_get_suppliers_data_ajax() {
    // Prevent conflicts with theme code
    if (defined('HARUV_SUPPLIERS_THEME_ACTIVE')) {
        return; // Theme already registered this AJAX handler
    }
    try {
        // Verify nonce for security
        if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'haruv_suppliers_nonce')) {
            wp_send_json_error('Security check failed');
            return;
        }

        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
            return;
        }

        // Validate and sanitize input
        if (!isset($_POST['supplier_type']) || empty($_POST['supplier_type'])) {
            wp_send_json_error('Missing supplier type');
            return;
        }

        $supplier_type = sanitize_text_field($_POST['supplier_type']);

        // Validate supplier type
        $allowed_types = array('photographer', 'venue', 'catering', 'hotel', 'printing', 'administration', 'workshop');
        if (!in_array($supplier_type, $allowed_types)) {
            wp_send_json_error('Invalid supplier type');
            return;
        }

    $args = array(
        'post_type' => $supplier_type,
        'post_status' => array('publish', 'pending', 'draft', 'private'),
        'posts_per_page' => -1,
    );

        $query = new WP_Query($args);
        $data = array();

        foreach ($query->posts as $post) {
            $fields = get_fields($post->ID);
            if (!$fields) {
                $fields = array();
            }

            $rating = 0;
            $notes_count = 0;

            // Calculate rating safely
            if (isset($fields['notes']) && is_array($fields['notes']) && !empty($fields['notes'])) {
                foreach ($fields['notes'] as $note) {
                    if (isset($note['rating']) && is_numeric($note['rating'])) {
                        $rating += (float)$note['rating'];
                        $notes_count++;
                    }
                }
                if ($notes_count > 0) {
                    $rating = $rating / $notes_count;
                }
            }

            // Get zones with labels safely
            $zones = array();
            if (isset($fields['zones']) && is_array($fields['zones']) && !empty($fields['zones'])) {
                $field_object = get_field_object('zones', $post->ID);
                if ($field_object && isset($field_object['choices'])) {
                    foreach ($fields['zones'] as $zone_value) {
                        if (isset($field_object['choices'][$zone_value])) {
                            $zones[] = $field_object['choices'][$zone_value];
                        } else {
                            $zones[] = $zone_value; // fallback
                        }
                    }
                } else {
                    $zones = $fields['zones'];
                }
            }

            $item = array(
                'id' => $post->ID,
                'name' => esc_html($post->post_title),
                'zone' => esc_html(implode(', ', $zones)),
                'updated_at' => get_the_modified_date('d/m/Y', $post->ID),
                'rating' => $rating > 0 ? round($rating, 1) : 'לא דורג',
                'notes' => isset($fields['notes']) && is_array($fields['notes']) ? $fields['notes'] : array(),
                'full_data' => $fields
            );

            // Add type-specific fields with safety checks
            switch ($supplier_type) {
                case 'venue':
                    $item['capacity'] = isset($fields['capacity']) ? esc_html($fields['capacity']) : '';
                    $item['venue_type'] = haruv_get_field_label($fields, 'venue_type');
                    break;

                case 'catering':
                    $item['kosher'] = haruv_get_field_label($fields, 'kosher_type');
                    $item['cuisine_type'] = haruv_get_array_field($fields, 'cuisine_type');
                    break;

                case 'photographer':
                    $item['photo_type'] = haruv_get_array_field($fields, 'photo_type');
                    $item['equipment'] = haruv_get_array_field($fields, 'equipment');
                    break;

                case 'printing':
                    $item['print_type'] = haruv_get_array_field($fields, 'print_type');
                    $item['materials'] = haruv_get_array_field($fields, 'materials');
                    break;

                case 'hotel':
                    $item['hotel_type'] = haruv_get_field_label($fields, 'hotel_type');
                    $item['room_count'] = isset($fields['room_count']) ? esc_html($fields['room_count']) : '';
                    break;

                case 'administration':
                    $item['admin_type'] = haruv_get_field_label($fields, 'admin_type');
                    $item['services'] = haruv_get_array_field($fields, 'services');
                    break;
            }

            $data[] = $item;
        }

        wp_send_json(array('data' => $data));

    } catch (Exception $e) {
        error_log('AJAX Error in haruv_get_suppliers_data_ajax: ' . $e->getMessage());
        wp_send_json_error('שגיאה בטעינת נתוני הספקים: ' . esc_html($e->getMessage()));
    } catch (Error $e) {
        error_log('Fatal AJAX Error in haruv_get_suppliers_data_ajax: ' . $e->getMessage());
        wp_send_json_error('שגיאה קריטית בטעינת נתוני הספקים');
    }
}

/**
 * Helper function to get field label safely
 */
function haruv_get_field_label($fields, $field_name) {
    if (isset($fields[$field_name]) && is_array($fields[$field_name]) && isset($fields[$field_name]['label'])) {
        return esc_html($fields[$field_name]['label']);
    } elseif (isset($fields[$field_name])) {
        return esc_html($fields[$field_name]);
    }
    return '';
}

/**
 * Helper function to get array field safely
 */
function haruv_get_array_field($fields, $field_name) {
    if (isset($fields[$field_name]) && is_array($fields[$field_name])) {
        return esc_html(implode(', ', $fields[$field_name]));
    } elseif (isset($fields[$field_name])) {
        return esc_html($fields[$field_name]);
    }
    return '';
}

// Register AJAX actions
add_action('wp_ajax_haruv_get_suppliers_data', 'haruv_get_suppliers_data_ajax');
