<?php
if (!defined('ABSPATH')) exit;

class Haruv_Privacy_Consent {

    public function __construct() {
        add_action('acf/save_post', array($this, 'save_consent_metadata'), 20);
    }

    public function save_consent_metadata($post_id) {
        // Check if this is an actual post save and not a revision or auto-draft
        if (wp_is_post_revision($post_id) || get_post_status($post_id) === 'auto-draft') {
            return;
        }

        // Check if the privacy consent field was submitted
        // We check $_POST['acf'] directly to see if the field key exists in the submission
        // Field keys: field_haruv_privacy_consent (Suppliers), field_lecture_privacy_consent (Lecturers)
        
        $consent_given = false;

        if (isset($_POST['acf']['field_haruv_privacy_consent']) && $_POST['acf']['field_haruv_privacy_consent'] == '1') {
            $consent_given = true;
        } elseif (isset($_POST['acf']['field_lecture_privacy_consent']) && $_POST['acf']['field_lecture_privacy_consent'] == '1') {
            $consent_given = true;
        }

        if ($consent_given) {
            // Only save if not already saved (to preserve original consent time)
            if (!get_post_meta($post_id, '_privacy_consent_timestamp', true)) {
                
                $timestamp = current_time('mysql');
                $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field($_SERVER['HTTP_USER_AGENT']) : '';
                $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : '';
                
                $user_identity = 'ע"י הספק'; // Default
                if (is_user_logged_in()) {
                    $current_user = wp_get_current_user();
                    $user_identity = $current_user->display_name . ' (ID: ' . $current_user->ID . ')';
                }

                update_post_meta($post_id, '_privacy_consent_timestamp', $timestamp);
                update_post_meta($post_id, '_privacy_consent_user_agent', $user_agent);
                update_post_meta($post_id, '_privacy_consent_ip', $ip);
                update_post_meta($post_id, '_privacy_consent_user_identity', $user_identity);
            }
        }
    }
}

new Haruv_Privacy_Consent();

