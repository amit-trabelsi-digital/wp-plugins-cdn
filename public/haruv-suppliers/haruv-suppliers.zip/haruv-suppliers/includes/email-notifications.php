<?php
/**
 * Email Notifications for Haruv Suppliers
 *
 * @package HaruvSuppliers
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Send email notification when a new supplier is created via ACF form
 * Uses acf/save_post to ensure all fields are saved before sending email
 */
function haruv_send_supplier_notification_email_acf($post_id) {
    // Bail if this is an autosave or revision
    if (wp_is_post_revision($post_id) || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)) {
        return;
    }
    
    // Get post object
    $post = get_post($post_id);
    if (!$post) {
        return;
    }
    
    // Check if this is a front-end submission (not admin)
    if (is_admin() && !defined('DOING_AJAX')) {
        return;
    }

    // Only run for supplier post types (+ lecture: staff notification for new
    // lecturer registrations, replacing the old theme mail to chagit@/batia@).
    $supplier_types = array('photographer', 'venue', 'catering', 'hotel', 'printing', 'administration', 'gifts', 'workshop', 'lecture');
    if (!in_array($post->post_type, $supplier_types)) {
        return;
    }
    
    // Check if email was already sent (prevent duplicates)
    $email_sent = get_post_meta($post_id, '_haruv_notification_email_sent', true);
    if ($email_sent) {
        return;
    }

    // Get admin email addresses
    $admin_emails = haruv_get_admin_emails();

    if (empty($admin_emails)) {
        return;
    }

    // Get supplier data (now ACF fields are available)
    $supplier_data = haruv_get_supplier_email_data($post);

    // Send email to each admin
    foreach ($admin_emails as $email) {
        haruv_send_supplier_email($email, $supplier_data);
    }
    
    // Mark email as sent
    update_post_meta($post_id, '_haruv_notification_email_sent', current_time('mysql'));
}
add_action('acf/save_post', 'haruv_send_supplier_notification_email_acf', 20);

/**
 * Get admin email addresses
 * שליחה לאותן כתובות ספציפיות כמו במרצים (naf-functions.php)
 */
function haruv_get_admin_emails() {
    // כתובות ספציפיות - כמו בפונקציית save_new_lecture_naf
    $emails = array(
        'chagit@haruv.org.il',
        'batia@haruv.org.il'
    );

    // Add additional emails from settings if available
    $additional_emails = get_option('haruv_supplier_notification_emails', '');
    if (!empty($additional_emails)) {
        $additional_emails = explode(',', $additional_emails);
        $emails = array_merge($emails, array_map('trim', $additional_emails));
    }

    return array_unique($emails);
}

/**
 * Get supplier data for email
 */
function haruv_get_supplier_email_data($post) {
    $fields = get_fields($post->ID);
    $author = get_user_by('id', $post->post_author);

    $data = array(
        'id' => $post->ID,
        'title' => $post->post_title,
        'type' => haruv_get_supplier_type_label($post->post_type),
        'content' => $post->post_content,
        'author' => $author ? $author->display_name : 'לא ידוע',
        'date' => get_the_date('d/m/Y H:i', $post->ID),
        'edit_link' => admin_url('post.php?post=' . $post->ID . '&action=edit'),
        'view_link' => get_permalink($post->ID),
        'fields' => array()
    );

    // Add ACF fields
    if ($fields) {
        $data['fields'] = array(
            'business_type' => haruv_get_business_type_label(isset($fields['business_type']) ? $fields['business_type'] : ''),
            'account_key' => isset($fields['account_key']) ? $fields['account_key'] : '',
            'email' => isset($fields['email']) ? $fields['email'] : '',
            'phone' => isset($fields['phone']) ? $fields['phone'] : '',
            'mobile' => isset($fields['mobile']) ? $fields['mobile'] : '',
            'address' => isset($fields['address']) ? $fields['address'] : '',
            'organization' => isset($fields['organization']) ? $fields['organization'] : ''
        );

        // Add type-specific fields
        switch ($post->post_type) {
            case 'venue':
                $data['fields']['venue_type'] = haruv_get_venue_type_label(isset($fields['venue_type']) ? $fields['venue_type'] : '');
                $data['fields']['capacity'] = isset($fields['capacity']) ? $fields['capacity'] : '';
                break;

            case 'catering':
                $data['fields']['food_type'] = haruv_get_food_type_label(isset($fields['food_type']) ? $fields['food_type'] : '');
                $data['fields']['kosher_type'] = haruv_get_kosher_type_label(isset($fields['kosher_type']) ? $fields['kosher_type'] : '');
                break;

            case 'hotel':
                $data['fields']['hotel_type'] = haruv_get_hotel_type_label(isset($fields['hotel_type']) ? $fields['hotel_type'] : '');
                $data['fields']['room_count'] = isset($fields['room_count']) ? $fields['room_count'] : '';
                break;
        }
    }

    return $data;
}

/**
 * Send supplier notification email
 */
function haruv_send_supplier_email($to_email, $supplier_data) {
    $subject = sprintf(__('ספק חדש נוסף למערכת - %s', 'haruv-suppliers'), $supplier_data['title']);

    $message = haruv_build_supplier_email_content($supplier_data);

    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . get_bloginfo('name') . ' <' . get_option('admin_email') . '>'
    );

    wp_mail($to_email, $subject, $message, $headers);
}

/**
 * Build supplier email content
 */
function haruv_build_supplier_email_content($data) {
    ob_start();
    ?>
    <!DOCTYPE html>
    <html dir="rtl" lang="he">
    <head>
        <meta charset="UTF-8">
        <title><?php _e('ספק חדש במערכת', 'haruv-suppliers'); ?></title>
        <style>
            body { font-family: Arial, sans-serif; direction: rtl; text-align: right; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #007cba; color: white; padding: 20px; text-align: center; }
            .content { padding: 20px; background: #f9f9f9; }
            .field { margin-bottom: 10px; }
            .field-label { font-weight: bold; display: inline-block; min-width: 120px; }
            .actions { text-align: center; margin-top: 30px; }
            .button { display: inline-block; padding: 10px 20px; background: #007cba; color: white; text-decoration: none; border-radius: 5px; margin: 0 10px; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1><?php _e('ספק חדש נוסף למערכת', 'haruv-suppliers'); ?></h1>
            </div>

            <div class="content">
                <h2><?php echo esc_html($data['title']); ?></h2>

                <div class="field">
                    <span class="field-label"><?php _e('סוג ספק:', 'haruv-suppliers'); ?></span>
                    <?php echo esc_html($data['type']); ?>
                </div>

                <div class="field">
                    <span class="field-label"><?php _e('נוצר על ידי:', 'haruv-suppliers'); ?></span>
                    <?php echo esc_html($data['author']); ?>
                </div>

                <div class="field">
                    <span class="field-label"><?php _e('תאריך:', 'haruv-suppliers'); ?></span>
                    <?php echo esc_html($data['date']); ?>
                </div>

                <?php if (!empty($data['fields']['business_type'])): ?>
                <div class="field">
                    <span class="field-label"><?php _e('סוג עוסק:', 'haruv-suppliers'); ?></span>
                    <?php echo esc_html($data['fields']['business_type']); ?>
                </div>
                <?php endif; ?>

                <?php if (!empty($data['fields']['account_key'])): ?>
                <div class="field">
                    <span class="field-label"><?php _e('מפתח חשבון:', 'haruv-suppliers'); ?></span>
                    <?php echo esc_html($data['fields']['account_key']); ?>
                </div>
                <?php endif; ?>

                <?php if (!empty($data['fields']['organization'])): ?>
                <div class="field">
                    <span class="field-label"><?php _e('ארגון:', 'haruv-suppliers'); ?></span>
                    <?php echo esc_html($data['fields']['organization']); ?>
                </div>
                <?php endif; ?>

                <?php if (!empty($data['fields']['email'])): ?>
                <div class="field">
                    <span class="field-label"><?php _e('דוא״ל:', 'haruv-suppliers'); ?></span>
                    <a href="mailto:<?php echo esc_attr($data['fields']['email']); ?>"><?php echo esc_html($data['fields']['email']); ?></a>
                </div>
                <?php endif; ?>

                <?php if (!empty($data['fields']['phone'])): ?>
                <div class="field">
                    <span class="field-label"><?php _e('טלפון:', 'haruv-suppliers'); ?></span>
                    <?php echo esc_html($data['fields']['phone']); ?>
                </div>
                <?php endif; ?>

                <?php if (!empty($data['fields']['mobile'])): ?>
                <div class="field">
                    <span class="field-label"><?php _e('נייד:', 'haruv-suppliers'); ?></span>
                    <?php echo esc_html($data['fields']['mobile']); ?>
                </div>
                <?php endif; ?>

                <?php if (!empty($data['content'])): ?>
                <div class="field">
                    <span class="field-label"><?php _e('תיאור:', 'haruv-suppliers'); ?></span>
                    <div><?php echo wpautop(esc_html($data['content'])); ?></div>
                </div>
                <?php endif; ?>

                <div class="actions">
                    <a href="<?php echo esc_url($data['edit_link']); ?>" class="button"><?php _e('ערוך ספק', 'haruv-suppliers'); ?></a>
                    <a href="<?php echo esc_url($data['view_link']); ?>" class="button"><?php _e('צפה בספק', 'haruv-suppliers'); ?></a>
                </div>
            </div>
        </div>
    </body>
    </html>
    <?php

    return ob_get_clean();
}

/**
 * Helper functions for labels
 */
function haruv_get_supplier_type_label($post_type) {
    $labels = array(
        'photographer' => __('צלם', 'haruv-suppliers'),
        'venue' => __('אולם', 'haruv-suppliers'),
        'catering' => __('הסעדה', 'haruv-suppliers'),
        'hotel' => __('מלון', 'haruv-suppliers'),
        'printing' => __('בית דפוס', 'haruv-suppliers'),
        'administration' => __('אדמיניסטרציה', 'haruv-suppliers'),
        'workshop' => __('סדנה', 'haruv-suppliers')
    );

    return isset($labels[$post_type]) ? $labels[$post_type] : $post_type;
}

function haruv_get_business_type_label($value) {
    // "סוג העוסק" — kept identical to the lecturer type_biz choices (numeric 1-7).
    // The ACF field stores numeric keys; legacy string slugs are also mapped so old
    // notification emails / exports still resolve to a label.
    $labels = array(
        // Current numeric keys (match ACF field choices + lecturer type_biz)
        '1' => __('עוסק פטור', 'haruv-suppliers'),
        '2' => __('עוסק מורשה', 'haruv-suppliers'),
        '3' => __('חברה בעמ', 'haruv-suppliers'),
        '4' => __('מלכר', 'haruv-suppliers'),
        '5' => __('אין מספר עוסק, נא לנכות מס מירבי מהתשלום שלי', 'haruv-suppliers'),
        '6' => __('אין מספר עוסק, יש בידי תיאום מס', 'haruv-suppliers'),
        '7' => __('חל"צ', 'haruv-suppliers'),
        // Legacy string slugs (pre-migration data) → same labels
        'exempt_dealer' => __('עוסק פטור', 'haruv-suppliers'),
        'authorized_dealer' => __('עוסק מורשה', 'haruv-suppliers'),
        'limited_company' => __('חברה בעמ', 'haruv-suppliers'),
        'non_profit' => __('מלכר', 'haruv-suppliers'),
    );

    // ACF may return the field as an array (['value'=>..,'label'=>..]); normalize.
    if (is_array($value)) {
        if (isset($value['label']) && $value['label'] !== '') {
            return $value['label'];
        }
        $value = isset($value['value']) ? $value['value'] : '';
    }

    return isset($labels[$value]) ? $labels[$value] : $value;
}

function haruv_get_venue_type_label($value) {
    $labels = array(
        'college' => __('מכללה', 'haruv-suppliers'),
        'museum' => __('מוזיאון', 'haruv-suppliers'),
        'hotel' => __('מלון', 'haruv-suppliers'),
        'community_center' => __('מרכז קהילתי', 'haruv-suppliers')
    );

    return isset($labels[$value]) ? $labels[$value] : $value;
}

function haruv_get_food_type_label($value) {
    $labels = array(
        'meat' => __('בשרי', 'haruv-suppliers'),
        'dairy' => __('חלבי', 'haruv-suppliers'),
        'parve' => __('פרווה', 'haruv-suppliers')
    );

    return isset($labels[$value]) ? $labels[$value] : $value;
}

function haruv_get_kosher_type_label($value) {
    $labels = array(
        'kosher' => __('כשר', 'haruv-suppliers'),
        'not_kosher' => __('לא כשר', 'haruv-suppliers')
    );

    return isset($labels[$value]) ? $labels[$value] : $value;
}

function haruv_get_hotel_type_label($value) {
    $labels = array(
        'boutique' => __('בוטיק', 'haruv-suppliers'),
        'business' => __('עסקי', 'haruv-suppliers'),
        'resort' => __('נופש', 'haruv-suppliers')
    );

    return isset($labels[$value]) ? $labels[$value] : $value;
}

/**
 * Add email settings to the settings page
 */
function haruv_add_email_settings($settings) {
    $settings['haruv_supplier_notification_emails'] = array(
        'label' => __('אימיילים נוספים לקבלת התראות', 'haruv-suppliers'),
        'description' => __('הפרד אימיילים בפסיקים', 'haruv-suppliers'),
        'type' => 'text',
        'default' => ''
    );

    return $settings;
}
add_filter('haruv_suppliers_settings', 'haruv_add_email_settings');
