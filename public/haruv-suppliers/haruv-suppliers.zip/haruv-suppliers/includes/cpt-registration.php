<?php
/**
 * Custom Post Types Registration for Haruv Suppliers
 *
 * @package HaruvSuppliers
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register all supplier post types (excluding lecturers)
 */
function haruv_register_supplier_types() {
    // CPTs are registered by plugin - theme should NOT register them
    // Photographers CPT
    $photographers_labels = array(
        'name'               => __('צלמים', 'haruv-suppliers'),
        'singular_name'      => __('צלם', 'haruv-suppliers'),
        'menu_name'          => __('צלמים', 'haruv-suppliers'),
        'add_new'           => __('הוסף צלם חדש', 'haruv-suppliers'),
        'add_new_item'      => __('הוסף צלם חדש', 'haruv-suppliers'),
        'edit_item'         => __('ערוך צלם', 'haruv-suppliers'),
        'all_items'         => __('כל הצלמים', 'haruv-suppliers')
    );

    register_post_type('photographer', array(
        'labels'              => $photographers_labels,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => false, // Menu handled by plugin main class
        'supports'            => array('title', 'editor', 'thumbnail'),
        'has_archive'         => true,
        'show_in_rest'        => true,
        'capability_type'     => 'post',
        'map_meta_cap'        => true,
    ));

    // Venues CPT
    $venues_labels = array(
        'name'               => __('אולמות', 'haruv-suppliers'),
        'singular_name'      => __('אולם', 'haruv-suppliers'),
        'menu_name'          => __('אולמות', 'haruv-suppliers'),
        'add_new'           => __('הוסף אולם חדש', 'haruv-suppliers'),
        'add_new_item'      => __('הוסף אולם חדש', 'haruv-suppliers'),
        'edit_item'         => __('ערוך אולם', 'haruv-suppliers'),
        'all_items'         => __('כל האולמות', 'haruv-suppliers')
    );

    register_post_type('venue', array(
        'labels'              => $venues_labels,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => false, // Menu handled by plugin main class
        'supports'            => array('title', 'editor', 'thumbnail'),
        'has_archive'         => true,
        'show_in_rest'        => true,
        'capability_type'     => 'post',
        'map_meta_cap'        => true,
    ));

    // Catering CPT
    $catering_labels = array(
        'name'               => __('הסעדה', 'haruv-suppliers'),
        'singular_name'      => __('הסעדה', 'haruv-suppliers'),
        'menu_name'          => __('הסעדה', 'haruv-suppliers'),
        'add_new'           => __('הוסף ספק הסעדה חדש', 'haruv-suppliers'),
        'add_new_item'      => __('הוסף ספק הסעדה חדש', 'haruv-suppliers'),
        'edit_item'         => __('ערוך ספק הסעדה', 'haruv-suppliers'),
        'all_items'         => __('כל ספקי ההסעדה', 'haruv-suppliers')
    );

    register_post_type('catering', array(
        'labels'              => $catering_labels,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => false, // Menu handled by plugin main class
        'supports'            => array('title', 'editor', 'thumbnail'),
        'has_archive'         => true,
        'show_in_rest'        => true,
        'capability_type'     => 'post',
        'map_meta_cap'        => true,
    ));

    // Printing CPT
    $printing_labels = array(
        'name'               => __('בתי דפוס', 'haruv-suppliers'),
        'singular_name'      => __('בית דפוס', 'haruv-suppliers'),
        'menu_name'          => __('בתי דפוס', 'haruv-suppliers'),
        'add_new'           => __('הוסף בית דפוס חדש', 'haruv-suppliers'),
        'add_new_item'      => __('הוסף בית דפוס חדש', 'haruv-suppliers'),
        'edit_item'         => __('ערוך בית דפוס', 'haruv-suppliers'),
        'all_items'         => __('כל בתי הדפוס', 'haruv-suppliers')
    );

    register_post_type('printing', array(
        'labels'              => $printing_labels,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => false, // Menu handled by plugin main class
        'supports'            => array('title', 'editor', 'thumbnail'),
        'has_archive'         => true,
        'show_in_rest'        => true,
        'capability_type'     => 'post',
        'map_meta_cap'        => true,
    ));

    // Administration CPT
    $admin_labels = array(
        'name'               => __('אדמיניסטרציה', 'haruv-suppliers'),
        'singular_name'      => __('אדמיניסטרציה', 'haruv-suppliers'),
        'menu_name'          => __('אדמיניסטרציה', 'haruv-suppliers'),
        'add_new'           => __('הוסף ספק אדמיניסטרטיבי חדש', 'haruv-suppliers'),
        'add_new_item'      => __('הוסף ספק אדמיניסטרטיבי חדש', 'haruv-suppliers'),
        'edit_item'         => __('ערוך ספק אדמיניסטרטיבי', 'haruv-suppliers'),
        'all_items'         => __('כל ספקי האדמיניסטרציה', 'haruv-suppliers')
    );

    register_post_type('administration', array(
        'labels'              => $admin_labels,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => false, // Menu handled by plugin main class
        'supports'            => array('title', 'editor', 'thumbnail'),
        'has_archive'         => true,
        'show_in_rest'        => true,
        'capability_type'     => 'post',
        'map_meta_cap'        => true,
    ));

    // Hotels CPT
    $hotels_labels = array(
        'name'               => __('מלונות', 'haruv-suppliers'),
        'singular_name'      => __('מלון', 'haruv-suppliers'),
        'menu_name'          => __('מלונות', 'haruv-suppliers'),
        'add_new'           => __('הוסף מלון חדש', 'haruv-suppliers'),
        'add_new_item'      => __('הוסף מלון חדש', 'haruv-suppliers'),
        'edit_item'         => __('ערוך מלון', 'haruv-suppliers'),
        'all_items'         => __('כל המלונות', 'haruv-suppliers')
    );

    register_post_type('hotel', array(
        'labels'              => $hotels_labels,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => false, // Menu handled by plugin main class
        'supports'            => array('title', 'editor', 'thumbnail'),
        'has_archive'         => true,
        'show_in_rest'        => true,
        'capability_type'     => 'post',
        'map_meta_cap'        => true,
    ));
    
    // Gifts CPT (מתנות)
    $gifts_labels = array(
        'name'               => __('מתנות', 'haruv-suppliers'),
        'singular_name'      => __('מתנה', 'haruv-suppliers'),
        'menu_name'          => __('מתנות', 'haruv-suppliers'),
        'add_new'           => __('הוסף מתנה חדשה', 'haruv-suppliers'),
        'add_new_item'      => __('הוסף מתנה חדשה', 'haruv-suppliers'),
        'edit_item'         => __('ערוך מתנה', 'haruv-suppliers'),
        'all_items'         => __('כל המתנות', 'haruv-suppliers')
    );

    register_post_type('gifts', array(
        'labels'              => $gifts_labels,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => false, // Menu handled by plugin main class
        'supports'            => array('title', 'editor', 'thumbnail'),
        'has_archive'         => true,
        'show_in_rest'        => true,
        'capability_type'     => 'post',
        'map_meta_cap'        => true,
    ));

    // Workshops CPT (סדנאות)
    $workshop_labels = array(
        'name'               => __('סדנאות', 'haruv-suppliers'),
        'singular_name'      => __('סדנה', 'haruv-suppliers'),
        'menu_name'          => __('סדנאות', 'haruv-suppliers'),
        'add_new'           => __('הוסף סדנה חדשה', 'haruv-suppliers'),
        'add_new_item'      => __('הוסף סדנה חדשה', 'haruv-suppliers'),
        'edit_item'         => __('ערוך סדנה', 'haruv-suppliers'),
        'all_items'         => __('כל הסדנאות', 'haruv-suppliers')
    );

    register_post_type('workshop', array(
        'labels'              => $workshop_labels,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => false, // Menu handled by plugin main class
        'supports'            => array('title', 'editor', 'thumbnail'),
        'has_archive'         => true,
        'show_in_rest'        => true,
        'capability_type'     => 'post',
        'map_meta_cap'        => true,
    ));
}

// Hook into WordPress
add_action('init', 'haruv_register_supplier_types');
