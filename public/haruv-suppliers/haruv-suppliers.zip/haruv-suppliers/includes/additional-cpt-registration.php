<?php
/**
 * Additional Custom Post Types and Taxonomies Registration
 *
 * @package HaruvSuppliers
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register Additional Post Types (Lecture, Item, Business Entity)
 */
function haruv_register_additional_post_types() {
    
    // Lecture CPT (מרצים)
    $lecture_labels = array(
        'name'               => 'lectures',
        'singular_name'      => 'lecture',
        'menu_name'          => 'מרצים',
        'all_items'          => 'כל המרצים',
        'add_new'            => 'הוספת מרצה',
        'add_new_item'       => '',
        'edit_item'          => 'ערוך מרצה',
        'new_item'           => 'מרצה חדש',
        'view_item'          => '',
        'search_items'       => '',
        'not_found'          => '',
        'not_found_in_trash' => '',
        'parent_item_colon'  => '',
    );
    
    register_post_type('lecture', array(
        'label'               => 'lectures',
        'labels'              => array(
            'name' => 'מרצים',
            'singular_name' => 'lecture',
            'menu_name' => 'מרצים',
            'all_items' => 'כל המרצים',
            'add_new' => 'הוספת מרצה',
            'edit_item' => 'ערוך מרצה',
            'new_item' => 'מרצה חדש',
        ),
        'description'         => '',
        'public'              => false, // public: "false" in JSON
        'publicly_queryable'  => true,
        'show_ui'             => true,
        'show_in_nav_menus'   => true,
        'delete_with_user'    => false,
        'show_in_rest'        => true,
        'rest_base'           => '',
        'rest_controller_class' => '',
        'has_archive'         => false,
        'exclude_from_search' => false,
        'capability_type'     => 'post',
        'hierarchical'        => true,
        'rewrite'             => true,
        'query_var'           => true,
        'menu_position'       => null,
        'show_in_menu'        => true,
        'menu_icon'           => 'dashicons-money',
        'supports'            => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'revisions', 'author', 'page-attributes'),
        'taxonomies'          => array('lecturer_type', 'audince_size', 'languages', 'audince_type'),
    ));

    // Item CPT (תכנים)
    register_post_type('item', array(
        'label'               => 'תכנים',
        'labels'              => array(
            'name' => 'תכנים',
            'singular_name' => 'תוכן',
            'menu_name' => 'תכנים',
            'all_items' => 'כל התכנים',
            'add_new' => 'הוספת חדש',
            'add_new_item' => 'הוספת תוכן חדש',
            'edit_item' => 'עריכת תוכן',
            'new_item' => 'תוכן חדש',
            'view_item' => 'הצג תוכן',
            'view_items' => 'הצגת תכנים',
            'search_items' => 'חיפוש תכנים',
            'not_found' => 'לא נמצאו תכנים',
            'not_found_in_trash' => 'לא נמצאו תכנים באשפה',
            'parent_item_colon' => 'תוכן אב',
            'featured_image' => 'תמונה ראשית עבור תוכן זה',
            'set_featured_image' => 'הגדרת תמונה ראשית',
            'remove_featured_image' => 'הסרת תמונה ראשית',
            'use_featured_image' => 'שימוש כתמונה ראשית',
            'archives' => 'ארכיון תכנים',
            'insert_into_item' => 'הכנסת תוכן חדש',
            'uploaded_to_this_item' => 'עדכון תוכן',
            'filter_items_list' => 'סינון רשימת תכנים',
            'items_list' => 'רשימת תכנים',
            'attributes' => 'תכונות תכנים',
            'item_published' => 'תוכן פורסם',
        ),
        'description'         => '',
        'public'              => true,
        'publicly_queryable'  => true,
        'show_ui'             => true,
        'show_in_nav_menus'   => true,
        'delete_with_user'    => false,
        'show_in_rest'        => true,
        'rest_base'           => '',
        'has_archive'         => true,
        'exclude_from_search' => false,
        'capability_type'     => 'post',
        'hierarchical'        => false,
        'can_export'          => false,
        'rewrite'             => array('slug' => 'תכנים', 'with_front' => true),
        'query_var'           => true,
        'menu_position'       => null,
        'show_in_menu'        => true,
        'menu_icon'           => 'dashicons-format-video',
        'supports'            => array('title', 'editor', 'thumbnail', 'revisions'),
        'taxonomies'          => array('category', 'audince_type'),
    ));

    // Business Entity CPT
    register_post_type('business_entity', array(
        'label'               => 'Business Entities',
        'labels'              => array(
            'name' => 'Business Entities',
            'singular_name' => 'Business Entity',
            'menu_name' => 'Business Entities',
        ),
        'description'         => '',
        'public'              => false,
        'publicly_queryable'  => true,
        'show_ui'             => true,
        'show_in_nav_menus'   => true,
        'delete_with_user'    => false,
        'show_in_rest'        => true,
        'rest_base'           => 'business-entities',
        'has_archive'         => false,
        'exclude_from_search' => false,
        'capability_type'     => 'post',
        'hierarchical'        => false,
        'can_export'          => false,
        'rewrite'             => true,
        'query_var'           => true,
        'menu_position'       => null,
        'show_in_menu'        => true,
        'menu_icon'           => 'dashicons-id-alt',
        'supports'            => array('title', 'revisions'),
        'taxonomies'          => array(),
    ));
}

/**
 * Register Additional Taxonomies
 * Labels inferred from codebase usage.
 */
function haruv_register_additional_taxonomies() {
    
    // Lecturer Type (lecturer_type)
    if (!taxonomy_exists('lecturer_type')) {
        register_taxonomy('lecturer_type', array('lecture'), array(
            'labels' => array(
                'name' => 'סוגי מרצה',
                'singular_name' => 'סוג מרצה',
                'menu_name' => 'סוגי מרצה',
                'all_items' => 'כל סוגי המרצים',
                'edit_item' => 'ערוך סוג מרצה',
                'view_item' => 'הצג סוג מרצה',
                'update_item' => 'עדכן סוג מרצה',
                'add_new_item' => 'הוסף סוג מרצה חדש',
                'new_item_name' => 'שם סוג מרצה חדש',
                'search_items' => 'חפש סוגי מרצה',
            ),
            'hierarchical' => true,
            'show_ui' => true,
            'show_admin_column' => true,
            'show_in_rest' => true,
        ));
    }

    // Audience Size (audince_size)
    if (!taxonomy_exists('audince_size')) {
        register_taxonomy('audince_size', array('lecture'), array(
            'labels' => array(
                'name' => 'גודל קהל',
                'singular_name' => 'גודל קהל',
                'menu_name' => 'גודל קהל',
                'all_items' => 'כל גדלי הקהל',
                'edit_item' => 'ערוך גודל קהל',
                'view_item' => 'הצג גודל קהל',
                'update_item' => 'עדכן גודל קהל',
                'add_new_item' => 'הוסף גודל קהל חדש',
                'new_item_name' => 'שם גודל קהל חדש',
                'search_items' => 'חפש גדלי קהל',
            ),
            'hierarchical' => true,
            'show_ui' => true,
            'show_admin_column' => true,
            'show_in_rest' => true,
        ));
    }

    // Languages (languages)
    if (!taxonomy_exists('languages')) {
        register_taxonomy('languages', array('lecture'), array(
            'labels' => array(
                'name' => 'שפות',
                'singular_name' => 'שפה',
                'menu_name' => 'שפות',
                'all_items' => 'כל השפות',
                'edit_item' => 'ערוך שפה',
                'view_item' => 'הצג שפה',
                'update_item' => 'עדכן שפה',
                'add_new_item' => 'הוסף שפה חדשה',
                'new_item_name' => 'שם שפה חדשה',
                'search_items' => 'חפש שפות',
            ),
            'hierarchical' => true,
            'show_ui' => true,
            'show_admin_column' => true,
            'show_in_rest' => true,
        ));
    }

    // Audience Type (audince_type) - Shared by lecture and item
    if (!taxonomy_exists('audince_type')) {
        register_taxonomy('audince_type', array('lecture', 'item'), array(
            'labels' => array(
                'name' => 'קהל יעד',
                'singular_name' => 'קהל יעד',
                'menu_name' => 'קהל יעד',
                'all_items' => 'כל סוגי קהל היעד',
                'edit_item' => 'ערוך קהל יעד',
                'view_item' => 'הצג קהל יעד',
                'update_item' => 'עדכן קהל יעד',
                'add_new_item' => 'הוסף קהל יעד חדש',
                'new_item_name' => 'שם קהל יעד חדש',
                'search_items' => 'חפש קהלי יעד',
            ),
            'hierarchical' => true,
            'show_ui' => true,
            'show_admin_column' => true,
            'show_in_rest' => true,
        ));
    }
}

// Hook into init
add_action('init', 'haruv_register_additional_post_types');
add_action('init', 'haruv_register_additional_taxonomies');
