<?php
/**
 * Consent Form Handler
 *
 * Handles the display and processing of the consent form via a custom endpoint.
 *
 * @package HaruvSuppliers
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register rewrite rules for the consent page
 */
function haruv_consent_rewrite_rules() {
    add_rewrite_rule('^haruv-consent/?', 'index.php?haruv_consent=1', 'top');
}
add_action('init', 'haruv_consent_rewrite_rules');

/**
 * Register query var
 */
function haruv_consent_query_vars($vars) {
    $vars[] = 'haruv_consent';
    return $vars;
}
add_filter('query_vars', 'haruv_consent_query_vars');

/**
 * Template redirect to handle the custom endpoint
 */
function haruv_consent_template_redirect() {
    if (get_query_var('haruv_consent')) {
        // This is our custom page
        haruv_render_consent_page();
        exit;
    }
}
add_action('template_redirect', 'haruv_consent_template_redirect');

/**
 * Render the consent page
 */
function haruv_render_consent_page() {
    $token = isset($_GET['token']) ? sanitize_text_field($_GET['token']) : '';
    $post_id = 0;
    $error_message = '';
    
    // Check if form was submitted successfully (redirected here)
    if (isset($_GET['updated']) && $_GET['updated'] === 'true') {
        haruv_render_success_page();
        return;
    }

    if (empty($token)) {
        $error_message = __('קישור לא תקין.', 'haruv-suppliers');
    } else {
        $post_id = haruv_validate_consent_token($token);
        if (!$post_id) {
            $error_message = __('הקישור אינו תקין או שפג תוקפו.', 'haruv-suppliers');
        }
    }

    // ACF Head
    acf_form_head();
    
    // Output HTML
    ?>
    <!DOCTYPE html>
    <html dir="rtl" lang="he">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php _e('אישור מדיניות פרטיות - מכון חרוב', 'haruv-suppliers'); ?></title>
        <?php wp_head(); ?>
        <style>
            body { font-family: Arial, sans-serif; background-color: #f0f0f1; color: #3c434a; direction: rtl; }
            .haruv-consent-container { max-width: 800px; margin: 40px auto; background: #fff; padding: 40px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-radius: 8px; }
            .haruv-logo { text-align: center; margin-bottom: 30px; }
            .haruv-logo img { max-width: 200px; height: auto; }
            h1 { text-align: center; color: #007cba; margin-bottom: 30px; }
            .error-message { background-color: #fcebeb; color: #cc0000; padding: 15px; border-radius: 4px; text-align: center; margin-bottom: 20px; }
            .success-message { background-color: #eaf7ed; color: #2e7d32; padding: 15px; border-radius: 4px; text-align: center; margin-bottom: 20px; }
            
            /* ACF Form Styles adjustment */
            .acf-field { margin-bottom: 20px; }
            .acf-label { font-weight: bold; display: block; margin-bottom: 5px; }
            .acf-input input[type="text"], .acf-input input[type="email"], .acf-input input[type="number"], .acf-input textarea, .acf-input select { width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
            .acf-form-submit { text-align: center; margin-top: 30px; }
            .acf-form-submit .button { background-color: #007cba; color: white; border: none; padding: 12px 24px; font-size: 16px; cursor: pointer; border-radius: 4px; transition: background 0.3s; }
            .acf-form-submit .button:hover { background-color: #005a87; }
        </style>
    </head>
    <body>
        <div class="haruv-consent-container">
            <!-- Logo placeholder (optional) -->
            <!-- <div class="haruv-logo"><img src="..." alt="מכון חרוב"></div> -->
            
            <h1><?php _e('אישור פרטים ומדיניות פרטיות', 'haruv-suppliers'); ?></h1>
            
            <?php if ($error_message): ?>
                <div class="error-message"><?php echo esc_html($error_message); ?></div>
            <?php else: ?>
                <p><?php _e('אנא עברו על הפרטים, עדכנו במידת הצורך, ואשרו את מדיניות הפרטיות בתחתית הטופס.', 'haruv-suppliers'); ?></p>
                
                <?php
                // Determine field groups based on post type
                $post_type = get_post_type($post_id);
                $field_groups = array();
                
                if ($post_type === 'lecture') {
                    $field_groups = array('group_605706750b28b'); // Lecture details + consent
                } else {
                    // Supplier types
                    $field_groups[] = 'group_supplier_base_details';
                    
                    // Add specific groups
                    switch ($post_type) {
                        case 'venue':
                            $field_groups[] = 'group_venue_details';
                            break;
                        case 'catering':
                            $field_groups[] = 'group_catering_details';
                            break;
                        case 'hotel':
                            $field_groups[] = 'group_hotel_details';
                            break;
                        case 'printing':
                            $field_groups[] = 'group_printing_details';
                            break;
                    }
                    
                    // Add separate consent group for suppliers (we created this earlier)
                    $field_groups[] = 'group_privacy_consent';
                }
                
                // Render ACF Form
                acf_form(array(
                    'post_id' => $post_id,
                    'field_groups' => $field_groups,
                    'submit_value' => __('אשר ושלח', 'haruv-suppliers'),
                    'return' => add_query_arg(array('haruv_consent' => '1', 'updated' => 'true', 'token' => $token), home_url('/')),
                    'html_updated_message' => false // We handle success page manually
                ));
                ?>
            <?php endif; ?>
        </div>
        <?php wp_footer(); ?>
    </body>
    </html>
    <?php
}

/**
 * Render success page
 */
function haruv_render_success_page() {
    ?>
    <!DOCTYPE html>
    <html dir="rtl" lang="he">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php _e('תודה רבה - מכון חרוב', 'haruv-suppliers'); ?></title>
        <style>
            body { font-family: Arial, sans-serif; background-color: #f0f0f1; color: #3c434a; direction: rtl; text-align: center; padding: 50px; }
            .container { max-width: 600px; margin: 0 auto; background: #fff; padding: 40px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-radius: 8px; }
            h1 { color: #2e7d32; margin-bottom: 20px; }
            p { font-size: 18px; line-height: 1.6; }
            .button { display: inline-block; margin-top: 20px; padding: 10px 20px; background-color: #007cba; color: white; text-decoration: none; border-radius: 4px; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1><?php _e('הפרטים נשמרו בהצלחה!', 'haruv-suppliers'); ?></h1>
            <p><?php _e('תודה שאישרת את מדיניות הפרטיות.', 'haruv-suppliers'); ?></p>
            <p><?php _e('מייל אישור עם הפרטים נשלח אליך.', 'haruv-suppliers'); ?></p>
            
            <a href="https://haruv.org.il" class="button"><?php _e('מעבר לאתר מכון חרוב', 'haruv-suppliers'); ?></a>
        </div>
    </body>
    </html>
    <?php
}

/**
 * Hook into ACF save post to handle token invalidation and confirmation email
 */
function haruv_handle_consent_submission($post_id) {
    // Check if this is a frontend submission via our consent form
    // We can check if the token is present in the _GET or _POST request, but acf_form might redirect before we can process everything if using 'return'.
    // However, acf/save_post runs BEFORE redirect.
    
    // We only want to run this if it's the consent form submission.
    // The query var 'haruv_consent' might not be set during the POST request handling in standard WP flow?
    // Actually, acf_form submits to the current URL. So $_GET['haruv_consent'] should be '1'.
    
    // Check URL parameters or referer to be safe
    // But checking for the privacy consent field value change is a good indicator too.
    
    // Let's rely on checking if the token was passed in the URL, as the form submits to the same URL
    $token = isset($_GET['token']) ? sanitize_text_field($_GET['token']) : '';
    
    if (empty($token)) {
        return;
    }
    
    // Validate token again to be sure
    $valid_post_id = haruv_validate_consent_token($token);
    
    if ($valid_post_id && $valid_post_id == $post_id) {
        // Check if consent was actually given in this submission
        // For 'supplier', field is 'privacy_policy_consent' (key: field_privacy_consent) - see group_privacy_consent.json
        // For 'lecture', field is 'privacy_policy_consent' (key: field_lecture_privacy_consent) - see group_605706750b28b.json
        
        $consent_given = false;
        
        // We can inspect $_POST['acf']
        // It's safer to use get_field() AFTER save, but we are inside save_post action. 
        // acf/save_post with priority 20 runs after ACF has saved the values.
        
        $consent_value = get_field('privacy_policy_consent', $post_id);
        
        if ($consent_value) {
            // Invalidate token
            haruv_invalidate_consent_token($post_id);
            
            // Send confirmation email
            haruv_send_consent_confirmation_email($post_id);
        }
    }
}
add_action('acf/save_post', 'haruv_handle_consent_submission', 30); // Run after privacy-consent.php (priority 20)

