<?php
/**
 * Update Checker for Haruv Suppliers Plugin
 *
 * Checks for updates from GitHub repository
 *
 * @package HaruvSuppliers
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Haruv_Suppliers_Update_Checker {

    private $plugin_slug;
    private $plugin_data;
    private $github_username;
    private $github_repo;
    private $access_token;

    public function __construct() {
        $this->plugin_slug = 'haruv-suppliers';
        $this->plugin_data = get_plugin_data(HARUV_SUPPLIERS_PLUGIN_DIR . '/haruv-suppliers.php');
        $this->github_username = 'amit-trabelsi-digital';
        $this->github_repo = 'haruv-suppliers-private';

        // GitHub personal access token for private repos - try constants first, then options
        $this->access_token = defined('HARUV_GITHUB_TOKEN') ? HARUV_GITHUB_TOKEN : get_option('haruv_github_token', '');

        // Only add update filters if we have a token
        if (!empty($this->access_token)) {
            add_filter('pre_set_site_transient_update_plugins', array($this, 'check_for_updates'));
            add_filter('plugins_api', array($this, 'plugin_info'), 10, 3);
            add_filter('upgrader_source_selection', array($this, 'rename_github_zip'), 10, 3);
        }
    }

    /**
     * Check for plugin updates
     */
    public function check_for_updates($transient) {
        if (empty($transient->checked)) {
            return $transient;
        }

        $remote_version = $this->get_remote_version();

        if ($remote_version && version_compare($this->plugin_data['Version'], $remote_version, '<')) {
            $plugin_slug = plugin_basename(HARUV_SUPPLIERS_PLUGIN_DIR . '/haruv-suppliers.php');

            $transient->response[$plugin_slug] = (object) array(
                'slug' => $this->plugin_slug,
                'new_version' => $remote_version,
                'url' => $this->plugin_data['PluginURI'],
                'package' => $this->get_download_url($remote_version),
                'tested' => '6.4',
                'requires' => '5.0',
                'requires_php' => '7.4'
            );
        }

        return $transient;
    }

    /**
     * Get plugin info for update details
     */
    public function plugin_info($result, $action, $args) {
        if ($action !== 'plugin_information' || $args->slug !== $this->plugin_slug) {
            return $result;
        }

        $remote_info = $this->get_plugin_info();

        if ($remote_info) {
            $result = (object) array(
                'name' => $remote_info->name ?? $this->plugin_data['Name'],
                'slug' => $this->plugin_slug,
                'version' => $remote_info->tag_name ?? '',
                'author' => $remote_info->author ?? $this->plugin_data['Author'],
                'homepage' => $remote_info->html_url ?? $this->plugin_data['PluginURI'],
                'requires' => '5.0',
                'tested' => '6.4',
                'requires_php' => '7.4',
                'download_link' => $this->get_download_url($remote_info->tag_name ?? ''),
                'sections' => array(
                    'description' => $remote_info->body ?? $this->plugin_data['Description'],
                    'changelog' => $this->get_changelog()
                ),
                'banners' => array(
                    'low' => HARUV_SUPPLIERS_PLUGIN_URL . 'assets/banner-772x250.png',
                    'high' => HARUV_SUPPLIERS_PLUGIN_URL . 'assets/banner-1544x500.png'
                )
            );
        }

        return $result;
    }

    /**
     * Get remote version from GitHub
     */
    private function get_remote_version() {
        $url = "https://api.github.com/repos/{$this->github_username}/{$this->github_repo}/releases/latest";

        $headers = array('User-Agent' => 'WordPress/' . get_bloginfo('version'));

        if ($this->access_token) {
            $headers['Authorization'] = 'token ' . $this->access_token;
        }

        $response = wp_remote_get($url, array(
            'headers' => $headers,
            'timeout' => 10
        ));

        if (is_wp_error($response)) {
            error_log('Haruv Suppliers Update Check Error: ' . $response->get_error_message());
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body);

        if (isset($data->tag_name)) {
            return ltrim($data->tag_name, 'v'); // Remove 'v' prefix if exists
        }

        return false;
    }

    /**
     * Get plugin info from GitHub
     */
    private function get_plugin_info() {
        $url = "https://api.github.com/repos/{$this->github_username}/{$this->github_repo}/releases/latest";

        $headers = array('User-Agent' => 'WordPress/' . get_bloginfo('version'));

        if ($this->access_token) {
            $headers['Authorization'] = 'token ' . $this->access_token;
        }

        $response = wp_remote_get($url, array(
            'headers' => $headers,
            'timeout' => 10
        ));

        if (!is_wp_error($response)) {
            return json_decode(wp_remote_retrieve_body($response));
        }

        return false;
    }

    /**
     * Get download URL for specific version
     */
    private function get_download_url($version) {
        if ($this->access_token) {
            return "https://{$this->access_token}@github.com/{$this->github_username}/{$this->github_repo}/archive/refs/tags/v{$version}.zip";
        }

        return "https://github.com/{$this->github_username}/{$this->github_repo}/archive/refs/tags/v{$version}.zip";
    }

    /**
     * Get changelog from CHANGELOG.md file
     */
    private function get_changelog() {
        $changelog_path = HARUV_SUPPLIERS_PLUGIN_DIR . '/CHANGELOG.md';

        if (file_exists($changelog_path)) {
            $changelog = file_get_contents($changelog_path);

            // Extract latest version changelog
            $pattern = '/## \[(.*?)\].*?(?=## \[|$)/s';
            if (preg_match($pattern, $changelog, $matches)) {
                return $matches[0];
            }

            return $changelog;
        }

        return 'Changelog not available.';
    }

    /**
     * Rename GitHub zip folder during update
     */
    public function rename_github_zip($source, $remote_source, $upgrader) {
        global $wp_filesystem;

        if (strpos($source, $this->plugin_slug) === false) {
            return $source;
        }

        $corrected_source = trailingslashit($remote_source) . trailingslashit($this->plugin_slug);

        if ($wp_filesystem->move($source, $corrected_source)) {
            return $corrected_source;
        }

        return new WP_Error();
    }
}

// Initialize update checker
new Haruv_Suppliers_Update_Checker();
