<?php
/**
 * Consent Tokens Management
 *
 * Handles generation, validation, and management of secure tokens for privacy consent.
 *
 * @package HaruvSuppliers
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Generate a secure consent token for a post
 *
 * @param int $post_id Post ID (supplier or lecturer)
 * @return string The generated token
 */
function haruv_generate_consent_token($post_id) {
    // Generate a cryptographically secure random token (64 hex characters)
    $token = bin2hex(random_bytes(32));
    
    // Save token and metadata
    update_post_meta($post_id, '_privacy_consent_token', $token);
    update_post_meta($post_id, '_privacy_consent_token_created', current_time('mysql'));
    update_post_meta($post_id, '_privacy_consent_token_used', '0'); // Stored as string '0' or '1' usually in WP meta
    
    return $token;
}

/**
 * Validate a consent token
 *
 * Checks if the token exists, matches the post, is not used, and is not expired.
 *
 * @param string $token The token to validate
 * @return int|false Post ID if valid, false otherwise
 */
function haruv_validate_consent_token($token) {
    global $wpdb;
    
    if (empty($token)) {
        return false;
    }
    
    // Find post ID by token
    $post_id = $wpdb->get_var($wpdb->prepare(
        "SELECT post_id FROM {$wpdb->postmeta} 
         WHERE meta_key = '_privacy_consent_token' 
         AND meta_value = %s",
        $token
    ));
    
    if (!$post_id) {
        return false;
    }
    
    // Check if token has been used
    $used = get_post_meta($post_id, '_privacy_consent_token_used', true);
    if ($used && $used !== '0') {
        return false;
    }
    
    // Check if token is expired (7 days)
    $created = get_post_meta($post_id, '_privacy_consent_token_created', true);
    if ($created) {
        $created_ts = strtotime($created);
        $expires_ts = strtotime('+7 days', $created_ts);
        
        if (time() > $expires_ts) {
            return false;
        }
    } else {
        // If no creation date, assume invalid
        return false;
    }
    
    return (int)$post_id;
}

/**
 * Invalidate a consent token after use
 *
 * @param int $post_id Post ID
 * @return bool True on success
 */
function haruv_invalidate_consent_token($post_id) {
    return update_post_meta($post_id, '_privacy_consent_token_used', '1');
}

/**
 * Renew a consent token (extend validity)
 *
 * Updates the creation timestamp to now, effectively extending validity by another 7 days.
 * Does NOT change the token string itself, so existing links remain valid if they haven't been used.
 *
 * @param int $post_id Post ID
 * @return string|false The existing token if renewed, false if no token exists
 */
function haruv_renew_consent_token($post_id) {
    $token = get_post_meta($post_id, '_privacy_consent_token', true);
    
    if (!$token) {
        // No existing token, generate a new one
        return haruv_generate_consent_token($post_id);
    }
    
    // Check if already used
    $used = get_post_meta($post_id, '_privacy_consent_token_used', true);
    if ($used && $used !== '0') {
        // If used, we should probably generate a new one for a new consent request?
        // But the requirement says "renew validity for unused token".
        // If it was used, it's not "unused".
        // Let's assume we generate a new one if it was used or doesn't exist.
        return haruv_generate_consent_token($post_id);
    }
    
    // Update creation time to now
    update_post_meta($post_id, '_privacy_consent_token_created', current_time('mysql'));
    
    return $token;
}

/**
 * Get the status of the consent token for a post
 *
 * @param int $post_id Post ID
 * @return string Status: 'active', 'expired', 'used', 'none'
 */
function haruv_get_token_status($post_id) {
    $token = get_post_meta($post_id, '_privacy_consent_token', true);
    
    if (!$token) {
        return 'none';
    }
    
    $used = get_post_meta($post_id, '_privacy_consent_token_used', true);
    if ($used && $used !== '0') {
        return 'used';
    }
    
    $created = get_post_meta($post_id, '_privacy_consent_token_created', true);
    if ($created) {
        $created_ts = strtotime($created);
        $expires_ts = strtotime('+7 days', $created_ts);
        
        if (time() > $expires_ts) {
            return 'expired';
        }
    }
    
    return 'active';
}

