<?php
/**
 * Consent Admin Interface
 *
 * Handles the admin interface for managing consent requests.
 *
 * @package HaruvSuppliers
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Add admin menu page
 */
function haruv_add_consent_admin_menu() {
    // Menu is now handled by main plugin class - this function is kept for backward compatibility
    // The main menu slug is 'haruv-suppliers-main'
    // No need to add here as the main class handles it
}
add_action('admin_menu', 'haruv_add_consent_admin_menu', 20); // Priority 20 to run after theme's menu registration

/**
 * Render admin page
 */
function haruv_consent_requests_page() {
    // Handle form submission
    if (isset($_POST['haruv_send_consent_emails']) && check_admin_referer('haruv_send_consent_emails_action', 'haruv_send_consent_emails_nonce')) {
        haruv_handle_consent_emails_submission();
    }

    // Get current filter
    $filter_type = isset($_GET['filter_type']) ? sanitize_text_field($_GET['filter_type']) : 'all';
    $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $posts_per_page = isset($_GET['posts_per_page']) ? intval($_GET['posts_per_page']) : 50;

    // Build query args
    $args = array(
        'post_type' => array('supplier', 'lecture', 'venue', 'catering', 'hotel', 'printing', 'photographer', 'administration', 'gifts'),
        'posts_per_page' => $posts_per_page,
        'paged' => $paged,
        'meta_query' => array(
            'relation' => 'OR',
            array(
                'key' => 'privacy_policy_consent',
                'compare' => 'NOT EXISTS'
            ),
            array(
                'key' => 'privacy_policy_consent',
                'value' => '1',
                'compare' => '!='
            )
        )
    );

    // Apply type filter
    if ($filter_type !== 'all') {
        $args['post_type'] = $filter_type;
    }

    $query = new WP_Query($args);
    
    // Calculate totals for stats
    $all_post_types = array('supplier', 'lecture', 'venue', 'catering', 'hotel', 'printing', 'photographer', 'administration', 'gifts');
    
    // Total entities
    $total_entities_query = new WP_Query(array(
        'post_type' => $all_post_types,
        'posts_per_page' => -1,
        'fields' => 'ids',
        'post_status' => 'publish'
    ));
    $total_entities = $total_entities_query->found_posts;
    
    // Total consented
    $total_consented_query = new WP_Query(array(
        'post_type' => $all_post_types,
        'posts_per_page' => -1,
        'fields' => 'ids',
        'post_status' => 'publish',
        'meta_query' => array(
            array(
                'key' => 'privacy_policy_consent',
                'value' => '1',
                'compare' => '='
            )
        )
    ));
    $total_consented = $total_consented_query->found_posts;
    
    // Total pending (not consented)
    $total_pending = $total_entities - $total_consented;
    
    // Consented last week
    $last_week_consented_query = new WP_Query(array(
        'post_type' => $all_post_types,
        'posts_per_page' => -1,
        'fields' => 'ids',
        'post_status' => 'publish',
        'meta_query' => array(
            'relation' => 'AND',
            array(
                'key' => 'privacy_policy_consent',
                'value' => '1',
                'compare' => '='
            ),
            array(
                'key' => '_privacy_consent_timestamp',
                'value' => date('Y-m-d H:i:s', strtotime('-7 days')),
                'compare' => '>=',
                'type' => 'DATETIME'
            )
        )
    ));
    $last_week_consented = $last_week_consented_query->found_posts;

    // Calculate totals for tabs (pending only)
    $post_types_list = array(
        'all' => array('label' => __('הכל', 'haruv-suppliers'), 'type' => $all_post_types),
        'lecture' => array('label' => __('מרצים', 'haruv-suppliers'), 'type' => 'lecture'),
        'supplier' => array('label' => __('ספק כללי', 'haruv-suppliers'), 'type' => 'supplier'),
        'venue' => array('label' => __('אולם אירועים', 'haruv-suppliers'), 'type' => 'venue'),
        'catering' => array('label' => __('קייטרינג', 'haruv-suppliers'), 'type' => 'catering'),
        'hotel' => array('label' => __('מלון', 'haruv-suppliers'), 'type' => 'hotel'),
        'printing' => array('label' => __('בית דפוס', 'haruv-suppliers'), 'type' => 'printing'),
        'photographer' => array('label' => __('צלם', 'haruv-suppliers'), 'type' => 'photographer'),
        'administration' => array('label' => __('אדמיניסטרציה', 'haruv-suppliers'), 'type' => 'administration'),
        'gifts' => array('label' => __('מתנות', 'haruv-suppliers'), 'type' => 'gifts'),
    );

    ?>
    <div class="wrap">
        <h1 class="wp-heading-inline"><?php _e('בקשת הסכמה למדיניות פרטיות', 'haruv-suppliers'); ?></h1>
        
        <div class="haruv-stats-dashboard" style="display: flex; gap: 20px; margin: 20px 0; flex-wrap: wrap;">
            <div class="stat-box" style="background: #fff; padding: 20px; border-left: 4px solid #2271b1; box-shadow: 0 1px 3px rgba(0,0,0,.1);">
                <h3 style="margin: 0 0 10px; font-size: 14px; color: #646970;">סה״כ במערכת</h3>
                <div style="font-size: 24px; font-weight: bold;"><?php echo $total_entities; ?></div>
            </div>
            <div class="stat-box" style="background: #fff; padding: 20px; border-left: 4px solid #46b450; box-shadow: 0 1px 3px rgba(0,0,0,.1);">
                <h3 style="margin: 0 0 10px; font-size: 14px; color: #646970;">הסכימו למדיניות</h3>
                <div style="font-size: 24px; font-weight: bold; color: #46b450;"><?php echo $total_consented; ?></div>
            </div>
            <div class="stat-box" style="background: #fff; padding: 20px; border-left: 4px solid #dba617; box-shadow: 0 1px 3px rgba(0,0,0,.1);">
                <h3 style="margin: 0 0 10px; font-size: 14px; color: #646970;">ממתינים לאישור</h3>
                <div style="font-size: 24px; font-weight: bold; color: #dba617;"><?php echo $total_pending; ?></div>
            </div>
            <div class="stat-box" style="background: #fff; padding: 20px; border-left: 4px solid #72aee6; box-shadow: 0 1px 3px rgba(0,0,0,.1);">
                <h3 style="margin: 0 0 10px; font-size: 14px; color: #646970;">הסכימו השבוע</h3>
                <div style="font-size: 24px; font-weight: bold; color: #72aee6;"><?php echo $last_week_consented; ?></div>
            </div>
        </div>

        <?php if (isset($_GET['sent'])): ?>
            <div class="notice notice-success is-dismissible">
                <p><?php printf(__('%d מיילים נשלחו בהצלחה.', 'haruv-suppliers'), intval($_GET['sent'])); ?></p>
            </div>
        <?php endif; ?>

        <ul class="subsubsub">
            <?php 
            $count_items = count($post_types_list);
            $i = 0;
            foreach ($post_types_list as $slug => $data): 
                $i++;
                $count = haruv_count_pending_consent($data['type']);
                $separator = ($i < $count_items) ? ' |' : '';
                $current_class = ($filter_type === $slug) ? 'current' : '';
            ?>
                <li class="<?php echo esc_attr($slug); ?>">
                    <a href="edit.php?post_type=supplier&page=haruv-consent-requests&filter_type=<?php echo esc_attr($slug); ?>" class="<?php echo $current_class; ?>">
                        <?php echo esc_html($data['label']); ?> <span class="count">(<?php echo $count; ?>)</span>
                    </a><?php echo $separator; ?>
                </li>
            <?php endforeach; ?>
        </ul>

        <form method="get" action="">
            <input type="hidden" name="post_type" value="supplier" />
            <input type="hidden" name="page" value="haruv-consent-requests" />
            <input type="hidden" name="filter_type" value="<?php echo esc_attr($filter_type); ?>" />
            
            <div class="tablenav top">
                <div class="alignleft actions bulkactions">
                    
                    <label for="posts_per_page" style="margin-right: 10px;"><?php _e('הצג:', 'haruv-suppliers'); ?></label>
                    <select name="posts_per_page" id="posts_per_page">
                        <option value="20" <?php selected($posts_per_page, 20); ?>>20</option>
                        <option value="50" <?php selected($posts_per_page, 50); ?>>50</option>
                        <option value="100" <?php selected($posts_per_page, 100); ?>>100</option>
                        <option value="-1" <?php selected($posts_per_page, -1); ?>><?php _e('הכל', 'haruv-suppliers'); ?></option>
                    </select>
                    
                    <button type="submit" class="button"><?php _e('סנן', 'haruv-suppliers'); ?></button>
                </div>
                
                <?php
                $big = 999999999;
                echo paginate_links(array(
                    'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
                    'format' => '?paged=%#%',
                    'current' => max(1, $paged),
                    'total' => $query->max_num_pages,
                    'prev_text' => __('&laquo; הקודם'),
                    'next_text' => __('הבא &raquo;'),
                ));
                ?>
            </div>
        </form>

        <form method="post" action="">
            <?php wp_nonce_field('haruv_send_consent_emails_action', 'haruv_send_consent_emails_nonce'); ?>
            <div class="alignleft actions bulkactions" style="margin-bottom: 10px;">
                <button type="submit" name="haruv_send_consent_emails" class="button action"><?php _e('שלח בקשת הסכמה לנבחרים', 'haruv-suppliers'); ?></button>
            </div>


            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <td id="cb" class="manage-column column-cb check-column">
                            <label class="screen-reader-text" for="cb-select-all-1"><?php _e('בחר הכל', 'haruv-suppliers'); ?></label>
                            <input id="cb-select-all-1" type="checkbox">
                        </td>
                        <th scope="col" class="manage-column column-title"><?php _e('שם', 'haruv-suppliers'); ?></th>
                        <th scope="col" class="manage-column column-type"><?php _e('סוג', 'haruv-suppliers'); ?></th>
                        <th scope="col" class="manage-column column-email"><?php _e('אימייל', 'haruv-suppliers'); ?></th>
                        <th scope="col" class="manage-column column-status"><?php _e('סטטוס טוקן', 'haruv-suppliers'); ?></th>
                        <th scope="col" class="manage-column column-date"><?php _e('נשלח לאחרונה', 'haruv-suppliers'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($query->have_posts()): ?>
                        <?php while ($query->have_posts()): $query->the_post(); ?>
                            <?php 
                            $post_id = get_the_ID();
                            $post_type = get_post_type();
                            $email = get_field('email', $post_id);
                            if (empty($email)) {
                                $author_id = get_post_field('post_author', $post_id);
                                if ($author_id) {
                                    $user = get_userdata($author_id);
                                    if ($user) $email = $user->user_email;
                                }
                            }
                            
                            $token_status = haruv_get_token_status($post_id);
                            $last_sent = get_post_meta($post_id, '_privacy_consent_last_sent', true);
                            
                            $status_label = '';
                            $status_class = '';
                            
                            switch ($token_status) {
                                case 'active':
                                    $status_label = __('פעיל', 'haruv-suppliers');
                                    $status_class = 'green';
                                    break;
                                case 'expired':
                                    $status_label = __('פג תוקף', 'haruv-suppliers');
                                    $status_class = 'red';
                                    break;
                                case 'used':
                                    $status_label = __('נוצל (ממתין לאישור?)', 'haruv-suppliers'); // Should not happen if filtered correctly
                                    $status_class = 'orange';
                                    break;
                                default:
                                    $status_label = __('טרם נוצר', 'haruv-suppliers');
                                    $status_class = 'grey';
                            }
                            ?>
                            <tr>
                                <th scope="row" class="check-column">
                                    <input type="checkbox" name="post[]" value="<?php echo $post_id; ?>">
                                </th>
                                <td class="title column-title">
                                    <strong><a href="<?php echo get_edit_post_link($post_id); ?>"><?php the_title(); ?></a></strong>
                                </td>
                                <td class="type column-type"><?php echo haruv_get_supplier_type_label($post_type); ?></td>
                                <td class="email column-email"><?php echo esc_html($email); ?></td>
                                <td class="status column-status">
                                    <span style="color: <?php echo $status_class; ?>; font-weight: bold;"><?php echo $status_label; ?></span>
                                </td>
                                <td class="date column-date">
                                    <?php echo $last_sent ? date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($last_sent)) : '-'; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6"><?php _e('לא נמצאו ספקים/מרצים הממתינים לאישור.', 'haruv-suppliers'); ?></td>
                        </tr>
                    <?php endif; ?>
                    <?php wp_reset_postdata(); ?>
                </tbody>
            </table>
        </form>
    </div>
    <?php
}

/**
 * Handle email submission
 */
function haruv_handle_consent_emails_submission() {
    if (!isset($_POST['post']) || !is_array($_POST['post'])) {
        return;
    }

    $count = 0;
    foreach ($_POST['post'] as $post_id) {
        $post_id = intval($post_id);
        if (haruv_send_consent_request_email($post_id)) {
            $count++;
        }
    }

    // Redirect to avoid resubmission
    $redirect_url = add_query_arg('sent', $count, remove_query_arg(array('haruv_send_consent_emails', '_wpnonce'), $_SERVER['REQUEST_URI']));
    wp_redirect($redirect_url);
    exit;
}

/**
 * Helper to count pending consents
 */
function haruv_count_pending_consent($post_types) {
    $args = array(
        'post_type' => $post_types,
        'posts_per_page' => -1,
        'fields' => 'ids',
        'meta_query' => array(
            'relation' => 'OR',
            array(
                'key' => 'privacy_policy_consent',
                'compare' => 'NOT EXISTS'
            ),
            array(
                'key' => 'privacy_policy_consent',
                'value' => '1',
                'compare' => '!='
            )
        )
    );
    
    $query = new WP_Query($args);
    return $query->found_posts;
}

