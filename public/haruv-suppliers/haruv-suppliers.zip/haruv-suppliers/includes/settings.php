<?php
/**
 * Settings Page for Haruv Suppliers Plugin
 *
 * @package HaruvSuppliers
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Add settings page to admin menu
 */
function haruv_suppliers_add_settings_page() {
    add_submenu_page(
        'edit.php?post_type=supplier',
        __('הגדרות', 'haruv-suppliers'),
        __('הגדרות', 'haruv-suppliers'),
        'manage_options',
        'haruv-suppliers-settings',
        'haruv_suppliers_settings_page'
    );
}
add_action('admin_menu', 'haruv_suppliers_add_settings_page');

/**
 * Register settings
 */
function haruv_suppliers_register_settings() {
    register_setting('haruv_suppliers_settings', 'haruv_github_token');
    register_setting('haruv_suppliers_settings', 'haruv_update_interval');
    register_setting('haruv_suppliers_settings', 'haruv_debug_updates');
}
add_action('admin_init', 'haruv_suppliers_register_settings');

/**
 * Settings page content
 */
function haruv_suppliers_settings_page() {
    // Save settings
    if (isset($_POST['submit']) && check_admin_referer('haruv_suppliers_settings')) {
        update_option('haruv_github_token', sanitize_text_field($_POST['haruv_github_token']));
        update_option('haruv_update_interval', intval($_POST['haruv_update_interval']));
        update_option('haruv_debug_updates', isset($_POST['haruv_debug_updates']) ? 1 : 0);

        echo '<div class="notice notice-success"><p>' . __('ההגדרות נשמרו בהצלחה!', 'haruv-suppliers') . '</p></div>';
    }

    $token = get_option('haruv_github_token', '');
    $interval = get_option('haruv_update_interval', 12 * HOUR_IN_SECONDS);
    $debug = get_option('haruv_debug_updates', false);

    ?>
    <div class="wrap">
        <h1><?php _e('הגדרות ספקי הרוב', 'haruv-suppliers'); ?></h1>

        <form method="post" action="">
            <?php wp_nonce_field('haruv_suppliers_settings'); ?>

            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="haruv_github_token"><?php _e('טוקן גישה אישי ל-GitHub', 'haruv-suppliers'); ?></label>
                    </th>
                    <td>
                        <input type="password"
                               id="haruv_github_token"
                               name="haruv_github_token"
                               value="<?php echo esc_attr($token); ?>"
                               class="regular-text"
                               placeholder="ghp_xxxxxxxxxxxxxxxxxxxx" />
                        <p class="description">
                            <?php _e('נדרש לעדכונים אוטומטיים מריפוזיטורי פרטי.', 'haruv-suppliers'); ?>
                            <a href="https://github.com/settings/tokens" target="_blank">
                                <?php _e('צור טוקן כאן', 'haruv-suppliers'); ?>
                            </a>
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="haruv_update_interval"><?php _e('מרווח בדיקת עדכונים', 'haruv-suppliers'); ?></label>
                    </th>
                    <td>
                        <select id="haruv_update_interval" name="haruv_update_interval">
                            <option value="<?php echo 6 * HOUR_IN_SECONDS; ?>" <?php selected($interval, 6 * HOUR_IN_SECONDS); ?>>
                                <?php _e('כל 6 שעות', 'haruv-suppliers'); ?>
                            </option>
                            <option value="<?php echo 12 * HOUR_IN_SECONDS; ?>" <?php selected($interval, 12 * HOUR_IN_SECONDS); ?>>
                                <?php _e('כל 12 שעות', 'haruv-suppliers'); ?>
                            </option>
                            <option value="<?php echo DAY_IN_SECONDS; ?>" <?php selected($interval, DAY_IN_SECONDS); ?>>
                                <?php _e('יומי', 'haruv-suppliers'); ?>
                            </option>
                        </select>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><?php _e('מצב דיבוג', 'haruv-suppliers'); ?></th>
                    <td>
                        <label for="haruv_debug_updates">
                            <input type="checkbox"
                                   id="haruv_debug_updates"
                                   name="haruv_debug_updates"
                                   value="1" <?php checked($debug, 1); ?> />
                            <?php _e('אפשר לוג דיבוג לעדכונים', 'haruv-suppliers'); ?>
                        </label>
                    </td>
                </tr>
            </table>

            <?php submit_button(__('שמור הגדרות', 'haruv-suppliers')); ?>
        </form>

        <hr />

        <h2><?php _e('מידע על התוסף', 'haruv-suppliers'); ?></h2>
        <table class="widefat">
            <tr>
                <td><strong><?php _e('גרסה', 'haruv-suppliers'); ?>:</strong></td>
                <td><?php echo HARUV_SUPPLIERS_VERSION; ?></td>
            </tr>
            <tr>
                <td><strong><?php _e('ריפוזיטורי', 'haruv-suppliers'); ?>:</strong></td>
                <td><a href="https://github.com/amit-trabelsi-digital/haruv-suppliers-private" target="_blank">
                    https://github.com/amit-trabelsi-digital/haruv-suppliers-private
                </a></td>
            </tr>
            <tr>
                <td><strong><?php _e('סטטוס', 'haruv-suppliers'); ?>:</strong></td>
                <td>
                    <?php
                    $token_status = !empty($token) ? '<span style="color: green;">✓ מחובר</span>' : '<span style="color: red;">✗ נדרש טוקן</span>';
                    echo $token_status;
                    ?>
                </td>
            </tr>
        </table>
    </div>
    <?php
}

/**
 * Add settings link to plugins page
 */
function haruv_suppliers_add_settings_link($links) {
    $settings_link = '<a href="' . admin_url('admin.php?page=haruv-suppliers-settings') . '">' . __('הגדרות', 'haruv-suppliers') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(HARUV_SUPPLIERS_PLUGIN_DIR . '/haruv-suppliers.php'), 'haruv_suppliers_add_settings_link');
