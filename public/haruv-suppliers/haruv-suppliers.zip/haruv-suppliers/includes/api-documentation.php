<?php
/**
 * API Documentation Page for Haruv Suppliers
 *
 * @package HaruvSuppliers
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Display API Documentation Page
 */
function haruv_suppliers_api_documentation_page() {
    $api_key = 'djn4d54cx'; // Development API key
    $base_url = get_site_url();
    ?>
    <div class="wrap">
        <h1><?php _e('תיעוד API - Haruv Suppliers', 'haruv-suppliers-plugin'); ?></h1>
        
        <div class="card">
            <h2><?php _e('מידע כללי', 'haruv-suppliers-plugin'); ?></h2>
            <table class="form-table">
                <tr>
                    <th><?php _e('Base URL', 'haruv-suppliers-plugin'); ?></th>
                    <td><code><?php echo $base_url; ?>/wp-json/api/v1</code></td>
                </tr>
                <tr>
                    <th><?php _e('API Key (Development)', 'haruv-suppliers-plugin'); ?></th>
                    <td><code><?php echo $api_key; ?></code></td>
                </tr>
                <tr>
                    <th><?php _e('Headers Required', 'haruv-suppliers-plugin'); ?></th>
                    <td><code>Content-Type: application/json</code></td>
                </tr>
            </table>
        </div>

        <style>
            .api-endpoint {
                background: #fff;
                border: 1px solid #ccd0d4;
                border-radius: 4px;
                margin: 20px 0;
                padding: 15px;
            }
            .api-endpoint h3 {
                margin-top: 0;
                color: #23282d;
            }
            .method-badge {
                display: inline-block;
                padding: 3px 8px;
                border-radius: 3px;
                font-weight: bold;
                font-size: 12px;
                margin-right: 10px;
            }
            .method-get { background: #61affe; color: white; }
            .method-post { background: #49cc90; color: white; }
            .method-put { background: #fca130; color: white; }
            .method-delete { background: #f93e3e; color: white; }
            .endpoint-url {
                background: #f1f1f1;
                padding: 8px 12px;
                border-radius: 3px;
                font-family: monospace;
                margin: 10px 0;
            }
            .params-table {
                width: 100%;
                border-collapse: collapse;
                margin: 15px 0;
            }
            .params-table th,
            .params-table td {
                text-align: right;
                padding: 8px;
                border: 1px solid #ddd;
            }
            .params-table th {
                background: #f5f5f5;
                font-weight: 600;
            }
            .param-required {
                color: #d63638;
                font-weight: bold;
            }
            .param-optional {
                color: #00a32a;
            }
            .example-code {
                background: #282c34;
                color: #abb2bf;
                padding: 15px;
                border-radius: 4px;
                overflow-x: auto;
                margin: 10px 0;
            }
            .response-example {
                background: #f6f7f7;
                border: 1px solid #ddd;
                padding: 10px;
                border-radius: 3px;
                margin: 10px 0;
                white-space: pre-wrap;
                font-family: monospace;
                font-size: 12px;
            }
        </style>

        <!-- Test Endpoint -->
        <div class="api-endpoint">
            <h3>
                <span class="method-badge method-get">GET</span>
                <?php _e('בדיקת חיבור', 'haruv-suppliers-plugin'); ?>
            </h3>
            <div class="endpoint-url">/test</div>
            <p><?php _e('בדיקת חיבור בסיסית ל-API. לא דורש אימות.', 'haruv-suppliers-plugin'); ?></p>
            
            <h4><?php _e('דוגמת קריאה:', 'haruv-suppliers-plugin'); ?></h4>
            <div class="example-code">curl <?php echo $base_url; ?>/wp-json/api/v1/test</div>
            
            <h4><?php _e('תגובה:', 'haruv-suppliers-plugin'); ?></h4>
            <div class="response-example">{
    "success": true,
    "message": "Haruv Suppliers API is working!",
    "version": "1.1.3",
    "plugin": "haruv-suppliers"
}</div>
        </div>

        <!-- Get All Suppliers -->
        <div class="api-endpoint">
            <h3>
                <span class="method-badge method-get">GET</span>
                <?php _e('קבלת כל הספקים', 'haruv-suppliers-plugin'); ?>
            </h3>
            <div class="endpoint-url">/suppliers</div>
            <p><?php _e('מחזיר רשימת כל הספקים במערכת עם אפשרויות סינון וחיפוש.', 'haruv-suppliers-plugin'); ?></p>
            
            <h4><?php _e('פרמטרים:', 'haruv-suppliers-plugin'); ?></h4>
            <table class="params-table">
                <thead>
                    <tr>
                        <th><?php _e('שם', 'haruv-suppliers-plugin'); ?></th>
                        <th><?php _e('סוג', 'haruv-suppliers-plugin'); ?></th>
                        <th><?php _e('חובה', 'haruv-suppliers-plugin'); ?></th>
                        <th><?php _e('תיאור', 'haruv-suppliers-plugin'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><code>apikey</code></td>
                        <td>string</td>
                        <td class="param-required"><?php _e('כן', 'haruv-suppliers-plugin'); ?></td>
                        <td><?php _e('מפתח API לאימות', 'haruv-suppliers-plugin'); ?></td>
                    </tr>
                    <tr>
                        <td><code>type</code></td>
                        <td>string</td>
                        <td class="param-optional"><?php _e('לא', 'haruv-suppliers-plugin'); ?></td>
                        <td>
                            <?php _e('סוג ספק: venue, catering, hotel, printing, photographer, administration, lecture, gifts, supplier, business_entity', 'haruv-suppliers-plugin'); ?>
                            <br><strong><?php _e('תמיכה בסוגים מרובים:', 'haruv-suppliers-plugin'); ?></strong>
                            <?php _e('ניתן לשלוח סוג אחד או כמה סוגים מופרדים בפסיק', 'haruv-suppliers-plugin'); ?>
                            <br><?php _e('דוגמה:', 'haruv-suppliers-plugin'); ?> <code>type=venue,catering,hotel</code>
                        </td>
                    </tr>
                    <tr>
                        <td><code>search</code></td>
                        <td>string</td>
                        <td class="param-optional"><?php _e('לא', 'haruv-suppliers-plugin'); ?></td>
                        <td><?php _e('חיפוש חופשי לפי שם', 'haruv-suppliers-plugin'); ?></td>
                    </tr>
                    <tr>
                        <td><code>per_page</code></td>
                        <td>integer</td>
                        <td class="param-optional"><?php _e('לא', 'haruv-suppliers-plugin'); ?></td>
                        <td><?php _e('מספר תוצאות בעמוד (ברירת מחדל: 10)', 'haruv-suppliers-plugin'); ?></td>
                    </tr>
                    <tr>
                        <td><code>page</code></td>
                        <td>integer</td>
                        <td class="param-optional"><?php _e('לא', 'haruv-suppliers-plugin'); ?></td>
                        <td><?php _e('מספר עמוד (ברירת מחדל: 1)', 'haruv-suppliers-plugin'); ?></td>
                    </tr>
                    <tr>
                        <td><code>fulldata</code></td>
                        <td>boolean</td>
                        <td class="param-optional"><?php _e('לא', 'haruv-suppliers-plugin'); ?></td>
                        <td><?php _e('החזר מידע מלא כולל שדות ACF', 'haruv-suppliers-plugin'); ?></td>
                    </tr>
                </tbody>
            </table>
            
            <h4><?php _e('דוגמאות קריאה:', 'haruv-suppliers-plugin'); ?></h4>
            <div class="example-code"># סוג אחד
curl "<?php echo $base_url; ?>/wp-json/api/v1/suppliers?apikey=<?php echo $api_key; ?>&type=venue&per_page=5"

# כמה סוגים
curl "<?php echo $base_url; ?>/wp-json/api/v1/suppliers?apikey=<?php echo $api_key; ?>&type=venue,catering,lecture&per_page=10"

# כל הסוגים
curl "<?php echo $base_url; ?>/wp-json/api/v1/suppliers?apikey=<?php echo $api_key; ?>&per_page=20"</div>
            
            <h4><?php _e('תגובה:', 'haruv-suppliers-plugin'); ?></h4>
            <div class="response-example">{
    "success": true,
    "data": [
        {
            "id": 123,
            "title": "אולם האירועים המפואר",
            "type": "venue",
            "status": "publish",
            "date_modified": "2025-01-09 10:30:00"
        }
    ],
    "total": 5
}</div>
        </div>

        <!-- Get Supplier by ID -->
        <div class="api-endpoint">
            <h3>
                <span class="method-badge method-get">GET</span>
                <?php _e('קבלת ספק לפי מזהה', 'haruv-suppliers-plugin'); ?>
            </h3>
            <div class="endpoint-url">/suppliers/{id}</div>
            <p><?php _e('מחזיר מידע מלא על ספק ספציפי לפי המזהה שלו.', 'haruv-suppliers-plugin'); ?></p>
            
            <h4><?php _e('פרמטרים:', 'haruv-suppliers-plugin'); ?></h4>
            <table class="params-table">
                <thead>
                    <tr>
                        <th><?php _e('שם', 'haruv-suppliers-plugin'); ?></th>
                        <th><?php _e('סוג', 'haruv-suppliers-plugin'); ?></th>
                        <th><?php _e('חובה', 'haruv-suppliers-plugin'); ?></th>
                        <th><?php _e('תיאור', 'haruv-suppliers-plugin'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><code>id</code></td>
                        <td>integer</td>
                        <td class="param-required"><?php _e('כן', 'haruv-suppliers-plugin'); ?></td>
                        <td><?php _e('מזהה הספק', 'haruv-suppliers-plugin'); ?></td>
                    </tr>
                    <tr>
                        <td><code>apikey</code></td>
                        <td>string</td>
                        <td class="param-required"><?php _e('כן', 'haruv-suppliers-plugin'); ?></td>
                        <td><?php _e('מפתח API לאימות', 'haruv-suppliers-plugin'); ?></td>
                    </tr>
                    <tr>
                        <td><code>fulldata</code></td>
                        <td>boolean</td>
                        <td class="param-optional"><?php _e('לא', 'haruv-suppliers-plugin'); ?></td>
                        <td><?php _e('החזר מידע מלא כולל כל השדות המותאמים (ברירת מחדל: true)', 'haruv-suppliers-plugin'); ?></td>
                    </tr>
                </tbody>
            </table>
            
            <h4><?php _e('דוגמת קריאה:', 'haruv-suppliers-plugin'); ?></h4>
            <div class="example-code">curl "<?php echo $base_url; ?>/wp-json/api/v1/suppliers/123?apikey=<?php echo $api_key; ?>&fulldata=true"</div>
        </div>

        <!-- Search Suppliers -->
        <div class="api-endpoint">
            <h3>
                <span class="method-badge method-get">GET</span>
                <?php _e('חיפוש ספקים', 'haruv-suppliers-plugin'); ?>
            </h3>
            <div class="endpoint-url">/suppliers/search</div>
            <p><?php _e('חיפוש ספקים לפי שם עם אפשרות לסינון לפי סוג.', 'haruv-suppliers-plugin'); ?></p>
            
            <h4><?php _e('פרמטרים:', 'haruv-suppliers-plugin'); ?></h4>
            <table class="params-table">
                <thead>
                    <tr>
                        <th><?php _e('שם', 'haruv-suppliers-plugin'); ?></th>
                        <th><?php _e('סוג', 'haruv-suppliers-plugin'); ?></th>
                        <th><?php _e('חובה', 'haruv-suppliers-plugin'); ?></th>
                        <th><?php _e('תיאור', 'haruv-suppliers-plugin'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><code>apikey</code></td>
                        <td>string</td>
                        <td class="param-required"><?php _e('כן', 'haruv-suppliers-plugin'); ?></td>
                        <td><?php _e('מפתח API לאימות', 'haruv-suppliers-plugin'); ?></td>
                    </tr>
                    <tr>
                        <td><code>name</code></td>
                        <td>string</td>
                        <td class="param-required"><?php _e('כן', 'haruv-suppliers-plugin'); ?></td>
                        <td><?php _e('מחרוזת חיפוש לשם הספק', 'haruv-suppliers-plugin'); ?></td>
                    </tr>
                    <tr>
                        <td><code>type</code></td>
                        <td>string</td>
                        <td class="param-optional"><?php _e('לא', 'haruv-suppliers-plugin'); ?></td>
                        <td>
                            <?php _e('סינון לפי סוג ספק', 'haruv-suppliers-plugin'); ?>
                            <br><?php _e('תמיכה בסוגים מרובים מופרדים בפסיק', 'haruv-suppliers-plugin'); ?>
                        </td>
                    </tr>
                    <tr>
                        <td><code>fulldata</code></td>
                        <td>boolean</td>
                        <td class="param-optional"><?php _e('לא', 'haruv-suppliers-plugin'); ?></td>
                        <td><?php _e('החזר מידע מלא', 'haruv-suppliers-plugin'); ?></td>
                    </tr>
                </tbody>
            </table>
            
            <h4><?php _e('דוגמת קריאה:', 'haruv-suppliers-plugin'); ?></h4>
            <div class="example-code">curl "<?php echo $base_url; ?>/wp-json/api/v1/suppliers/search?apikey=<?php echo $api_key; ?>&name=אולם&type=venue"</div>
        </div>

        <!-- Get Suppliers by Type -->
        <div class="api-endpoint">
            <h3>
                <span class="method-badge method-get">GET</span>
                <?php _e('קבלת ספקים לפי סוג', 'haruv-suppliers-plugin'); ?>
            </h3>
            <div class="endpoint-url">/suppliers/type/{type}</div>
            <p><?php _e('מחזיר את כל הספקים מסוג מסוים.', 'haruv-suppliers-plugin'); ?></p>
            
            <h4><?php _e('סוגי ספקים זמינים:', 'haruv-suppliers-plugin'); ?></h4>
            <ul>
                <li><code>venue</code> - <?php _e('אולמות', 'haruv-suppliers-plugin'); ?></li>
                <li><code>catering</code> - <?php _e('הסעדה', 'haruv-suppliers-plugin'); ?></li>
                <li><code>hotel</code> - <?php _e('מלונות', 'haruv-suppliers-plugin'); ?></li>
                <li><code>printing</code> - <?php _e('בתי דפוס', 'haruv-suppliers-plugin'); ?></li>
                <li><code>photographer</code> - <?php _e('צלמים', 'haruv-suppliers-plugin'); ?></li>
                <li><code>administration</code> - <?php _e('אדמיניסטרציה', 'haruv-suppliers-plugin'); ?></li>
                <li><code>lecture</code> - <?php _e('מרצים', 'haruv-suppliers-plugin'); ?></li>
                <li><code>gifts</code> - <?php _e('מתנות וקד״מ', 'haruv-suppliers-plugin'); ?></li>
                <li><code>supplier</code> - <?php _e('ספקים כלליים', 'haruv-suppliers-plugin'); ?></li>
                <li><code>business_entity</code> - <?php _e('ישויות עסקיות', 'haruv-suppliers-plugin'); ?></li>
            </ul>
            
            <h4><?php _e('דוגמת קריאה:', 'haruv-suppliers-plugin'); ?></h4>
            <div class="example-code">curl "<?php echo $base_url; ?>/wp-json/api/v1/suppliers/type/venue?apikey=<?php echo $api_key; ?>"</div>
        </div>

        <!-- Update Supplier -->
        <div class="api-endpoint">
            <h3>
                <span class="method-badge method-post">POST</span>
                <?php _e('עדכון ספק', 'haruv-suppliers-plugin'); ?>
            </h3>
            <div class="endpoint-url">/suppliers/update</div>
            <p><?php _e('עדכון פרטי ספק קיים במערכת.', 'haruv-suppliers-plugin'); ?></p>
            
            <h4><?php _e('פרמטרים:', 'haruv-suppliers-plugin'); ?></h4>
            <table class="params-table">
                <thead>
                    <tr>
                        <th><?php _e('שם', 'haruv-suppliers-plugin'); ?></th>
                        <th><?php _e('סוג', 'haruv-suppliers-plugin'); ?></th>
                        <th><?php _e('חובה', 'haruv-suppliers-plugin'); ?></th>
                        <th><?php _e('תיאור', 'haruv-suppliers-plugin'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><code>apikey</code></td>
                        <td>string</td>
                        <td class="param-required"><?php _e('כן', 'haruv-suppliers-plugin'); ?></td>
                        <td><?php _e('מפתח API לאימות', 'haruv-suppliers-plugin'); ?></td>
                    </tr>
                    <tr>
                        <td><code>id</code></td>
                        <td>integer</td>
                        <td class="param-required"><?php _e('כן', 'haruv-suppliers-plugin'); ?></td>
                        <td><?php _e('מזהה הספק לעדכון', 'haruv-suppliers-plugin'); ?></td>
                    </tr>
                    <tr>
                        <td><code>user_email</code></td>
                        <td>string</td>
                        <td class="param-required"><?php _e('כן', 'haruv-suppliers-plugin'); ?></td>
                        <td><?php _e('אימייל המשתמש המעדכן', 'haruv-suppliers-plugin'); ?></td>
                    </tr>
                    <tr>
                        <td><code>[field_name]</code></td>
                        <td>mixed</td>
                        <td class="param-optional"><?php _e('לא', 'haruv-suppliers-plugin'); ?></td>
                        <td><?php _e('כל שדה ACF או שדה רגיל לעדכון', 'haruv-suppliers-plugin'); ?></td>
                    </tr>
                </tbody>
            </table>
            
            <h4><?php _e('דוגמת קריאה:', 'haruv-suppliers-plugin'); ?></h4>
            <div class="example-code">curl -X POST "<?php echo $base_url; ?>/wp-json/api/v1/suppliers/update" \
    -d "apikey=<?php echo $api_key; ?>" \
    -d "id=123" \
    -d "user_email=admin@example.com" \
    -d "phone=050-1234567" \
    -d "address=רחוב הראשי 1, תל אביב"</div>
            
            <h4><?php _e('תגובה:', 'haruv-suppliers-plugin'); ?></h4>
            <div class="response-example">{
    "success": true,
    "message": "Supplier updated successfully",
    "supplier_id": 123
}</div>
        </div>

        <!-- Testing Tools -->
        <div class="card" style="margin-top: 30px;">
            <h2><?php _e('כלי בדיקה', 'haruv-suppliers-plugin'); ?></h2>
            
            <h3><?php _e('Postman Collection', 'haruv-suppliers-plugin'); ?></h3>
            <p><?php _e('ניתן להוריד את קובץ ה-Postman Collection המוכן עם כל הקריאות:', 'haruv-suppliers-plugin'); ?></p>
            <p>
                <a href="<?php echo admin_url('admin.php?page=haruv-postman-collection'); ?>" class="button button-primary">
                    <?php _e('הורד Postman Collection', 'haruv-suppliers-plugin'); ?>
                </a>
            </p>
            
            <h3><?php _e('בדיקה מהירה', 'haruv-suppliers-plugin'); ?></h3>
            <p><?php _e('העתק את הפקודות הבאות לטרמינל:', 'haruv-suppliers-plugin'); ?></p>
            <div class="example-code"># בדיקת חיבור
curl <?php echo $base_url; ?>/wp-json/api/v1/test

# קבלת כל הספקים
curl "<?php echo $base_url; ?>/wp-json/api/v1/suppliers?apikey=<?php echo $api_key; ?>"

# חיפוש ספקים
curl "<?php echo $base_url; ?>/wp-json/api/v1/suppliers/search?apikey=<?php echo $api_key; ?>&name=אולם"</div>
        </div>

        <!-- Rate Limiting Info -->
        <div class="card" style="margin-top: 20px;">
            <h2><?php _e('הגבלות ואבטחה', 'haruv-suppliers-plugin'); ?></h2>
            <ul>
                <li><?php _e('מפתח API נדרש לכל הקריאות (מלבד /test)', 'haruv-suppliers-plugin'); ?></li>
                <li><?php _e('הגבלת קצב: 100 בקשות לדקה לכל IP', 'haruv-suppliers-plugin'); ?></li>
                <li><?php _e('גודל מקסימלי לבקשת POST: 2MB', 'haruv-suppliers-plugin'); ?></li>
                <li><?php _e('תומך בסטטוסים: publish, pending, draft, private', 'haruv-suppliers-plugin'); ?></li>
            </ul>
        </div>
    </div>
    <?php
}

/**
 * Combined "מפתחים" admin screen — tabs: API docs + conversion tools.
 *
 * @since 1.5.0
 */
function haruv_developers_page() {
    $tabs = array(
        'api'     => __('תיעוד API', 'haruv-suppliers-plugin'),
        'migrate' => __('כלי המרה', 'haruv-suppliers-plugin'),
    );
    $active = isset($_GET['tab']) && isset($tabs[$_GET['tab']]) ? sanitize_key($_GET['tab']) : 'api';
    $base   = admin_url('admin.php?page=haruv-developers');
    ?>
    <div class="wrap">
        <h1><span class="dashicons dashicons-rest-api" style="font-size:28px;width:28px;height:28px;margin-left:8px;"></span><?php _e('מפתחים', 'haruv-suppliers-plugin'); ?></h1>

        <h2 class="nav-tab-wrapper">
            <?php foreach ($tabs as $slug => $label): ?>
                <a href="<?php echo esc_url(add_query_arg('tab', $slug, $base)); ?>" class="nav-tab <?php echo $active === $slug ? 'nav-tab-active' : ''; ?>"><?php echo esc_html($label); ?></a>
            <?php endforeach; ?>
        </h2>

        <div style="margin-top:16px;">
            <?php
            if ($active === 'migrate') {
                if (function_exists('haruv_migration_page_callback')) {
                    haruv_migration_page_callback();
                } else {
                    echo '<div class="notice notice-error inline"><p>' . esc_html__('כלי ההמרה אינו זמין.', 'haruv-suppliers-plugin') . '</p></div>';
                }
            } else {
                if (function_exists('haruv_suppliers_api_documentation_page')) {
                    haruv_suppliers_api_documentation_page();
                } else {
                    echo '<div class="notice notice-error inline"><p>' . esc_html__('תיעוד ה-API אינו זמין.', 'haruv-suppliers-plugin') . '</p></div>';
                }
            }
            ?>
        </div>
    </div>
    <?php
}
