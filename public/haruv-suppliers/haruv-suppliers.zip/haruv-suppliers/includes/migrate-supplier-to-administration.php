<?php
/**
 * Migration Script: Convert 'supplier' posts to 'administration'
 * 
 * This script converts all posts with post_type='supplier' to post_type='administration'
 * while preserving all metadata, taxonomies, and post relationships.
 * 
 * Run once via: /wp-admin/admin.php?page=haruv-migrate-suppliers
 * 
 * @package HaruvSuppliers
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Render the migration tool body (used inside the "מפתחים" tabbed screen).
 * The standalone menu item was removed in 1.5.0 — see haruv_developers_page().
 */
function haruv_migration_page_callback() {
    ?>
    <h2><?php _e('המרת ספקים: supplier → administration', 'haruv-suppliers'); ?></h2>

    <?php
    // Check if migration was triggered
    if (isset($_POST['haruv_run_migration']) && check_admin_referer('haruv_migration_nonce', 'haruv_migration_nonce_field')) {
        haruv_run_supplier_migration();
    } else {
        haruv_display_migration_preview();
    }
}

/**
 * Display migration preview (before running)
 */
function haruv_display_migration_preview() {
    global $wpdb;
    
    // Count supplier posts
    $supplier_count = $wpdb->get_var(
        "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'supplier'"
    );
    
    // Get sample posts
    $sample_posts = $wpdb->get_results(
        "SELECT ID, post_title, post_status, post_date 
         FROM {$wpdb->posts} 
         WHERE post_type = 'supplier' 
         ORDER BY post_date DESC 
         LIMIT 10"
    );
    
    ?>
    <div class="notice notice-info">
        <p><strong><?php _e('מה ההמרה תעשה?', 'haruv-suppliers'); ?></strong></p>
        <ul style="margin-right: 20px;">
            <li>✅ המרת כל הפוסטים מסוג <code>supplier</code> ל-<code>administration</code></li>
            <li>✅ שמירת כל המטאדטה (ACF fields, post meta)</li>
            <li>✅ שמירת כל הטקסונומיות</li>
            <li>✅ שמירת סטטוס הפוסט (draft/publish/pending)</li>
            <li>✅ שמירת תאריכים ויוצר</li>
            <li>✅ יצירת backup ב-log</li>
        </ul>
    </div>
    
    <div class="notice notice-warning">
        <p><strong>⚠️ שים לב:</strong> המרה זו היא <strong>בלתי הפיכה</strong>. מומלץ לגבות את המסד נתונים לפני ההמרה.</p>
    </div>
    
    <h2><?php printf(__('נמצאו %d ספקים להמרה', 'haruv-suppliers'), $supplier_count); ?></h2>
    
    <?php if ($supplier_count > 0): ?>
        <h3><?php _e('דוגמאות (10 אחרונים):', 'haruv-suppliers'); ?></h3>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th><?php _e('שם', 'haruv-suppliers'); ?></th>
                    <th><?php _e('סטטוס', 'haruv-suppliers'); ?></th>
                    <th><?php _e('תאריך', 'haruv-suppliers'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($sample_posts as $post): ?>
                    <tr>
                        <td><?php echo esc_html($post->ID); ?></td>
                        <td><strong><?php echo esc_html($post->post_title); ?></strong></td>
                        <td><span class="status-<?php echo esc_attr($post->post_status); ?>"><?php echo esc_html($post->post_status); ?></span></td>
                        <td><?php echo esc_html(mysql2date('d/m/Y H:i', $post->post_date)); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <br><br>
        
        <form method="post" onsubmit="return confirm('האם אתה בטוח שברצונך להמיר <?php echo $supplier_count; ?> ספקים מסוג supplier ל-administration?\n\nהפעולה בלתי הפיכה!');">
            <?php wp_nonce_field('haruv_migration_nonce', 'haruv_migration_nonce_field'); ?>
            <input type="hidden" name="haruv_run_migration" value="1">
            <button type="submit" class="button button-primary button-large">
                <span class="dashicons dashicons-migrate" style="margin-top: 4px;"></span>
                <?php printf(__('המר %d ספקים ל-אדמיניסטרציה', 'haruv-suppliers'), $supplier_count); ?>
            </button>
        </form>
        
    <?php else: ?>
        <div class="notice notice-success">
            <p><strong><?php _e('אין ספקים מסוג supplier להמרה!', 'haruv-suppliers'); ?></strong></p>
            <p><?php _e('כל הספקים הכללי כבר הומרו ל-administration או שלא היו קיימים.', 'haruv-suppliers'); ?></p>
        </div>
    <?php endif; ?>
    
    <style>
        .status-publish { color: #46b450; font-weight: bold; }
        .status-draft { color: #999; }
        .status-pending { color: #f56e28; }
    </style>
    <?php
}

/**
 * Run the actual migration
 */
function haruv_run_supplier_migration() {
    global $wpdb;
    
    // Start transaction (if supported)
    $wpdb->query('START TRANSACTION');
    
    try {
        // Get all supplier posts
        $supplier_posts = $wpdb->get_results(
            "SELECT ID, post_title, post_status, post_date, post_author 
             FROM {$wpdb->posts} 
             WHERE post_type = 'supplier'"
        );
        
        if (empty($supplier_posts)) {
            echo '<div class="notice notice-info"><p>' . __('אין ספקים להמרה.', 'haruv-suppliers') . '</p></div>';
            return;
        }
        
        $migrated_count = 0;
        $errors = array();
        
        // Log file for backup
        $log_file = WP_CONTENT_DIR . '/haruv-migration-log-' . date('Y-m-d-H-i-s') . '.txt';
        $log_content = "Migration started: " . date('Y-m-d H:i:s') . "\n";
        $log_content .= "Total suppliers to migrate: " . count($supplier_posts) . "\n\n";
        
        foreach ($supplier_posts as $post) {
            // Log before state
            $log_content .= "ID: {$post->ID} | Title: {$post->post_title} | Status: {$post->post_status}\n";
            
            // Get all postmeta before migration (for backup)
            $postmeta = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT meta_key, meta_value FROM {$wpdb->postmeta} WHERE post_id = %d",
                    $post->ID
                )
            );
            $log_content .= "  Metadata count: " . count($postmeta) . "\n";
            
            // Update post_type to 'administration'
            $updated = $wpdb->update(
                $wpdb->posts,
                array('post_type' => 'administration'),
                array('ID' => $post->ID),
                array('%s'),
                array('%d')
            );
            
            if ($updated === false) {
                $errors[] = sprintf(__('שגיאה בהמרת פוסט #%d: %s', 'haruv-suppliers'), $post->ID, $post->post_title);
                $log_content .= "  ERROR: Failed to update post_type\n";
            } else {
                $migrated_count++;
                $log_content .= "  SUCCESS: Converted to administration\n";
                
                // Clean post cache
                clean_post_cache($post->ID);
            }
            
            $log_content .= "\n";
        }
        
        // Save log
        file_put_contents($log_file, $log_content);
        
        // Commit transaction
        $wpdb->query('COMMIT');
        
        // Display results
        echo '<div class="notice notice-success"><p>';
        echo '<strong>' . sprintf(__('✅ ההמרה הושלמה בהצלחה!', 'haruv-suppliers')) . '</strong><br>';
        echo sprintf(__('הומרו %d ספקים מסוג supplier ל-administration', 'haruv-suppliers'), $migrated_count) . '<br>';
        echo sprintf(__('קובץ לוג נשמר ב: %s', 'haruv-suppliers'), '<code>' . $log_file . '</code>');
        echo '</p></div>';
        
        if (!empty($errors)) {
            echo '<div class="notice notice-error"><p><strong>' . __('שגיאות:', 'haruv-suppliers') . '</strong><br>';
            foreach ($errors as $error) {
                echo '• ' . esc_html($error) . '<br>';
            }
            echo '</p></div>';
        }
        
        // Show next steps
        echo '<div class="notice notice-info"><p>';
        echo '<strong>' . __('צעדים הבאים:', 'haruv-suppliers') . '</strong><br>';
        echo '1. ' . sprintf(__('בדוק את <a href="%s">רשימת האדמיניסטרציה</a> לוודא שהכל תקין', 'haruv-suppliers'), admin_url('edit.php?post_type=administration')) . '<br>';
        echo '2. ' . __('עדכן את הטופס החיצוני להשתמש ב-administration', 'haruv-suppliers') . '<br>';
        echo '3. ' . __('נקה את מטמון הדפדפן', 'haruv-suppliers');
        echo '</p></div>';
        
    } catch (Exception $e) {
        // Rollback on error
        $wpdb->query('ROLLBACK');
        
        echo '<div class="notice notice-error"><p>';
        echo '<strong>' . __('שגיאה קריטית בהמרה!', 'haruv-suppliers') . '</strong><br>';
        echo esc_html($e->getMessage());
        echo '</p></div>';
    }
}
