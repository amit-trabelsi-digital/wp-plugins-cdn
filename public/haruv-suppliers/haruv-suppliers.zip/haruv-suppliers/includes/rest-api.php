<?php
/**
 * REST API Endpoints for Haruv Suppliers
 *
 * @package HaruvSuppliers
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register REST API routes
 */
function haruv_register_suppliers_rest_routes() {
    // Prevent conflicts with theme code
    if (defined('HARUV_SUPPLIERS_THEME_ACTIVE')) {
        return; // Theme already registered these endpoints
    }
    // Test endpoint
    register_rest_route('api/v1', '/test', array(
        'methods' => 'GET',
        'callback' => 'haruv_test_rest_endpoint',
        'permission_callback' => '__return_true',
    ));

    // Get all suppliers
    register_rest_route('api/v1', '/suppliers', array(
        'methods' => 'GET',
        'callback' => 'haruv_get_suppliers_rest',
        'permission_callback' => 'haruv_check_api_permissions',
        'args' => array(
            'apikey' => array(
                'description' => 'מפתח API לאימות',
                'type' => 'string',
                'required' => true,
            ),
            'type' => array(
                'description' => 'סוג הספק - אפשר לשלוח סוג אחד או כמה סוגים מופרדים בפסיק (venue, catering, hotel, printing, photographer, administration, workshop, lecture, gifts, supplier, business_entity)',
                'type' => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            ),
            'search' => array(
                'description' => 'חיפוש לפי שם',
                'type' => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            ),
            'per_page' => array(
                'description' => 'מספר תוצאות בעמוד',
                'type' => 'integer',
                'default' => 10,
                'minimum' => 1,
                'maximum' => 100,
            ),
            'page' => array(
                'description' => 'מספר עמוד',
                'type' => 'integer',
                'default' => 1,
                'minimum' => 1,
            ),
            'fulldata' => array(
                'description' => 'האם להחזיר מידע מלא',
                'type' => 'boolean',
                'default' => false,
            ),
        ),
    ));

    // Get supplier by ID
    register_rest_route('api/v1', '/suppliers/(?P<id>\d+)', array(
        'methods' => 'GET',
        'callback' => 'haruv_get_supplier_by_id_rest',
        'permission_callback' => 'haruv_check_api_permissions',
        'args' => array(
            'id' => array(
                'description' => 'מזהה הספק',
                'type' => 'integer',
                'required' => true,
            ),
            'apikey' => array(
                'description' => 'מפתח API לאימות',
                'type' => 'string',
                'required' => true,
            ),
            'fulldata' => array(
                'description' => 'האם להחזיר מידע מלא',
                'type' => 'boolean',
                'default' => true,
            ),
        ),
    ));

    // Search suppliers by name
    register_rest_route('api/v1', '/suppliers/search', array(
        'methods' => 'GET',
        'callback' => 'haruv_search_suppliers_rest',
        'permission_callback' => 'haruv_check_api_permissions',
        'args' => array(
            'name' => array(
                'description' => 'שם הספק לחיפוש',
                'type' => 'string',
                'required' => true,
                'sanitize_callback' => 'sanitize_text_field',
            ),
            'type' => array(
                'description' => 'סוג הספק - אפשר לשלוח סוג אחד או כמה סוגים מופרדים בפסיק (venue, catering, hotel, printing, photographer, administration, workshop, lecture, gifts, supplier, business_entity)',
                'type' => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            ),
            'apikey' => array(
                'description' => 'מפתח API לאימות',
                'type' => 'string',
                'required' => true,
            ),
            'fulldata' => array(
                'description' => 'האם להחזיר מידע מלא',
                'type' => 'boolean',
                'default' => false,
            ),
        ),
    ));

    // Get suppliers by type
    register_rest_route('api/v1', '/suppliers/type/(?P<type>[a-zA-Z0-9-]+)', array(
        'methods' => 'GET',
        'callback' => 'haruv_get_suppliers_by_type_rest',
        'permission_callback' => 'haruv_check_api_permissions',
        'args' => array(
            'type' => array(
                'description' => 'סוג הספק',
                'type' => 'string',
                'required' => true,
            ),
            'apikey' => array(
                'description' => 'מפתח API לאימות',
                'type' => 'string',
                'required' => true,
            ),
            'fulldata' => array(
                'description' => 'האם להחזיר מידע מלא',
                'type' => 'boolean',
                'default' => false,
            ),
        ),
    ));

    // Update supplier
    register_rest_route('api/v1', '/suppliers/update', array(
        'methods' => 'POST',
        'callback' => 'haruv_update_supplier_rest',
        'permission_callback' => 'haruv_check_api_permissions',
        'args' => array(
            'id' => array(
                'description' => 'מזהה הספק',
                'type' => 'integer',
                'required' => true,
            ),
            'user_email' => array(
                'description' => 'אימייל המשתמש המעדכן',
                'type' => 'string',
                'required' => true,
                'sanitize_callback' => 'sanitize_email',
            ),
            'apikey' => array(
                'description' => 'מפתח API לאימות',
                'type' => 'string',
                'required' => true,
            ),
        ),
    ));
}

// Hook into WordPress
add_action('rest_api_init', 'haruv_register_suppliers_rest_routes');

/**
 * Test REST endpoint
 */
function haruv_test_rest_endpoint() {
    return new WP_REST_Response(array(
        'success' => true,
        'message' => 'Haruv Suppliers API is working!',
        'version' => defined('HARUV_SUPPLIERS_VERSION') ? HARUV_SUPPLIERS_VERSION : '',
        'plugin'  => 'haruv-suppliers',
    ), 200);
}

/**
 * Check API permissions
 */
function haruv_check_api_permissions($request) {
    $api_key = $request->get_param('apikey');

    if (empty($api_key) || $api_key !== 'djn4d54cx') {
        return new WP_Error('rest_forbidden', 'Invalid API key', array('status' => 403));
    }

    return true;
}

/**
 * Get all suppliers REST endpoint
 */
function haruv_get_suppliers_rest($request) {
    $params = $request->get_params();
    $fulldata = isset($params['fulldata']) ? $params['fulldata'] : false;

    $args = array(
        'post_status' => array('publish', 'pending', 'draft', 'private'),
        'posts_per_page' => isset($params['per_page']) ? $params['per_page'] : 10,
        'paged' => isset($params['page']) ? $params['page'] : 1,
    );

    // Default types for search/list when no type is specified (excludes business_entity)
    $default_search_types = array(
        'photographer', 'venue', 'catering', 'hotel', 'printing', 'administration', 'workshop',
        'lecture', 'gifts', 'supplier'
    );

    // All allowed types if requested specifically
    $all_allowed_types = array(
        'photographer', 'venue', 'catering', 'hotel', 'printing', 'administration', 'workshop',
        'lecture', 'gifts', 'supplier', 'business_entity'
    );

    if (isset($params['type'])) {
        // Support multiple types separated by comma
        $requested_types = array_map('trim', explode(',', $params['type']));
        $valid_types = array_intersect($requested_types, $all_allowed_types);
        
        if (!empty($valid_types)) {
            $args['post_type'] = $valid_types;
        } else {
            // If no valid types provided, use default
            $args['post_type'] = $default_search_types;
        }
    } else {
        $args['post_type'] = $default_search_types;
    }

    // Handle search
    if (isset($params['search']) && !empty($params['search'])) {
        $args['s'] = $params['search'];
    }

    $suppliers = get_posts($args);
    $formatted_suppliers = array();

    foreach ($suppliers as $supplier) {
        $formatted_suppliers[] = haruv_format_supplier_data_rest($supplier, $fulldata);
    }

    return new WP_REST_Response(array(
        'success' => true,
        'data' => $formatted_suppliers,
        'total' => count($formatted_suppliers)
    ), 200);
}

/**
 * Get supplier by ID REST endpoint
 */
function haruv_get_supplier_by_id_rest($request) {
    $params = $request->get_params();
    $id = $request['id'];
    $fulldata = isset($params['fulldata']) ? $params['fulldata'] : true;

    $supplier = get_post($id);

    if (!$supplier || $supplier->post_status === 'trash') {
        return new WP_Error('supplier_not_found', 'ספק לא נמצא', array('status' => 404));
    }

    $formatted_supplier = haruv_format_supplier_data_rest($supplier, $fulldata);

    return new WP_REST_Response(array(
        'success' => true,
        'data' => $formatted_supplier
    ), 200);
}

/**
 * Search suppliers REST endpoint
 */
function haruv_search_suppliers_rest($request) {
    $params = $request->get_params();
    $fulldata = isset($params['fulldata']) ? $params['fulldata'] : false;

    // Default types for search/list when no type is specified (excludes business_entity)
    $default_search_types = array(
        'photographer', 'venue', 'catering', 'hotel', 'printing', 'administration', 'workshop',
        'lecture', 'gifts', 'supplier'
    );

    // All allowed types if requested specifically
    $all_allowed_types = array(
        'photographer', 'venue', 'catering', 'hotel', 'printing', 'administration', 'workshop',
        'lecture', 'gifts', 'supplier', 'business_entity'
    );

    $args = array(
        'post_type' => $default_search_types,
        'post_status' => array('publish', 'pending', 'draft', 'private'),
        's' => $params['name'],
        'posts_per_page' => -1
    );

    if (isset($params['type'])) {
        // Support multiple types separated by comma
        $requested_types = array_map('trim', explode(',', $params['type']));
        $valid_types = array_intersect($requested_types, $all_allowed_types);
        
        if (!empty($valid_types)) {
            $args['post_type'] = $valid_types;
        }
    }

    $suppliers = get_posts($args);
    $formatted_suppliers = array();

    foreach ($suppliers as $supplier) {
        $formatted_suppliers[] = haruv_format_supplier_data_rest($supplier, $fulldata);
    }

    return new WP_REST_Response(array(
        'success' => true,
        'data' => $formatted_suppliers,
        'total' => count($formatted_suppliers)
    ), 200);
}

/**
 * Get suppliers by type REST endpoint
 */
function haruv_get_suppliers_by_type_rest($request) {
    $params = $request->get_params();
    $type = $request['type'];
    $fulldata = isset($params['fulldata']) ? $params['fulldata'] : false;

    $supplier_types = array(
        'photographer', 'venue', 'catering', 'hotel', 'printing', 'administration', 'workshop',
        'lecture', 'gifts', 'supplier', 'business_entity'
    );

    if (!in_array($type, $supplier_types)) {
        return new WP_Error('invalid_type', 'סוג ספק לא תקין', array('status' => 400));
    }

    $args = array(
        'post_type' => $type,
        'post_status' => array('publish', 'pending', 'draft', 'private'),
        'posts_per_page' => -1
    );

    $suppliers = get_posts($args);
    $formatted_suppliers = array();

    foreach ($suppliers as $supplier) {
        $formatted_suppliers[] = haruv_format_supplier_data_rest($supplier, $fulldata);
    }

    return new WP_REST_Response(array(
        'success' => true,
        'data' => $formatted_suppliers,
        'total' => count($formatted_suppliers),
        'type' => $type
    ), 200);
}

/**
 * Update supplier REST endpoint
 */
function haruv_update_supplier_rest($request) {
    $params = $request->get_params();
    $id = $params['id'];
    $user_email = $params['user_email'];

    // Validate user
    $user = get_user_by('email', $user_email);
    if (!$user) {
        return new WP_Error('user_not_found', 'משתמש לא נמצא', array('status' => 401));
    }

    // Get and validate post
    $post = get_post($id);
    if (!$post) {
        return new WP_Error('post_not_found', 'ספק לא נמצא', array('status' => 400));
    }

    $supplier_types = array(
        'photographer', 'venue', 'catering', 'hotel', 'printing', 'administration', 'workshop',
        'lecture', 'gifts', 'supplier'
    );
    if (!in_array($post->post_type, $supplier_types)) {
        return new WP_Error('invalid_post_type', 'סוג פוסט לא תקין', array('status' => 400));
    }

    // Fields to ignore
    $ignore = array('id', 'key', 'notes', 'apikey', 'user_email');

    // Update ACF fields
    foreach ($params as $key => $value) {
        if (in_array($key, $ignore)) continue;
        update_field($key, $value, $id);
    }

    // Handle notes if provided
    if (isset($params['notes'])) {
        $notes = json_decode(stripslashes($params['notes']), true);

        if ($notes && is_array($notes)) {
            foreach ($notes as $note) {
                if (isset($note['content']) && isset($note['rating'])) {
                    $row = array(
                        'user' => $user_email,
                        'time' => time(),
                        'content' => $note['content'],
                        'rating' => $note['rating']
                    );
                    add_row('notes', $row, $id);
                }
            }
        }
    }

    return new WP_REST_Response(array(
        'success' => true,
        'message' => 'הספק עודכן בהצלחה',
        'id' => $id
    ), 200);
}

/**
 * Format supplier data for REST response
 */
function haruv_format_supplier_data_rest($supplier, $detailed = false) {
    $fields = get_fields($supplier->ID);

    // Basic data
    $data = array(
        'id' => $supplier->ID,
        'name' => $supplier->post_title,
        'description' => $supplier->post_content,
        'excerpt' => $supplier->post_excerpt,
        'status' => $supplier->post_status,
        'date_created' => $supplier->post_date,
        'date_modified' => $supplier->post_modified,
        'author' => get_the_author_meta('display_name', $supplier->post_author),
        'type' => $supplier->post_type
    );

    // Add basic fields
    if ($fields) {
        $data['email'] = isset($fields['email']) ? $fields['email'] : '';
        $data['phone'] = isset($fields['mobile']) ? $fields['mobile'] : '';
        $data['phone_secondary'] = isset($fields['phone']) ? $fields['phone'] : '';
        $data['address'] = isset($fields['address']) ? $fields['address'] : '';
        $data['organization'] = isset($fields['org_name']) ? $fields['org_name'] : '';

        // Add all ACF fields automatically to top level (except known fields)
        $exclude_fields = array('email', 'mobile', 'phone', 'address', 'org_name', 'notes');
        foreach ($fields as $key => $value) {
            if (!in_array($key, $exclude_fields) && !isset($data[$key])) {
                $data[$key] = $value;
            }
        }
    }

    // Add detailed information if requested
    if ($detailed && $fields) {
        // Add all custom fields
        $data['custom_fields'] = $fields;
    }

    return $data;
}
