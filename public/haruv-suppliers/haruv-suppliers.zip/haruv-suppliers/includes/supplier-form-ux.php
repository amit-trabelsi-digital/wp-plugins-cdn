<?php
/**
 * Supplier registration form — UX layer
 *
 * - Locks the submit button + shows a full-screen "processing" overlay when the
 *   ACF form is submitted.
 * - On the success return page (?save&type=X) renders a confetti effect and a
 *   clear success message with next steps.
 * - The success message text is editable from the admin (under "ניהול ספקים").
 *
 * The theme template (page-add-supplier.php) only needs to call
 * haruv_render_supplier_success($supplier_type) inside its `$save` branch.
 *
 * @package HaruvSuppliers
 * @since 1.5.0
 */

if (!defined('ABSPATH')) {
    exit;
}

const HARUV_SUPPLIER_SUCCESS_OPTION    = 'haruv_supplier_form_success_message';
const HARUV_SUPPLIER_SEND_COPY_OPTION  = 'haruv_supplier_form_send_copy';        // '1' / ''
const HARUV_SUPPLIER_COPY_INTRO_OPTION = 'haruv_supplier_form_copy_intro';        // HTML

/**
 * Default success message (HTML allowed).
 */
function haruv_supplier_success_default_message() {
    return "<p>תודה שמילאתם את טופס ההרשמה. הפרטים התקבלו במערכת והם ממתינים לאישור הצוות שלנו.</p>\n"
        . "<p><strong>הצעדים הבאים:</strong></p>\n"
        . "<ul>\n"
        . "<li>נציג/ה מטעמנו יבדוק את הפרטים ויחזור אליכם תוך מספר ימי עסקים.</li>\n"
        . "<li>במידה ויידרשו השלמות — ניצור איתכם קשר באמצעות פרטי ההתקשרות שמסרתם.</li>\n"
        . "<li>לאחר האישור תיכללו במאגר הספקים של מכון חרוב.</li>\n"
        . "</ul>\n"
        . "<p>לשאלות ניתן לפנות אלינו בכל עת. תודה!</p>";
}

/**
 * Get the (admin-editable) success message.
 */
function haruv_supplier_success_message() {
    $msg = get_option(HARUV_SUPPLIER_SUCCESS_OPTION, '');
    if (!is_string($msg) || trim($msg) === '') {
        $msg = haruv_supplier_success_default_message();
    }
    /** Allow filtering, e.g. per supplier type via the second arg. */
    return apply_filters('haruv_supplier_success_message', $msg, isset($_GET['type']) ? sanitize_key($_GET['type']) : '');
}

/* -------------------------------------------------------------------------
 * Admin: editable success message
 * ---------------------------------------------------------------------- */

add_action('admin_menu', function () {
    add_submenu_page(
        'haruv-suppliers-main',
        __('הגדרות טופס הרשמה', 'haruv-suppliers'),
        __('הגדרות טופס הרשמה', 'haruv-suppliers'),
        'manage_options',
        'haruv-supplier-form-settings',
        'haruv_supplier_form_settings_page'
    );
}, 50);

add_action('admin_init', function () {
    register_setting('haruv_supplier_form_settings', HARUV_SUPPLIER_SUCCESS_OPTION, array(
        'type'              => 'string',
        'sanitize_callback' => 'wp_kses_post',
        'default'           => '',
    ));
    register_setting('haruv_supplier_form_settings', HARUV_SUPPLIER_SEND_COPY_OPTION, array(
        'type'              => 'string',
        'sanitize_callback' => function ($v) { return $v ? '1' : ''; },
        'default'           => '1',
    ));
    register_setting('haruv_supplier_form_settings', HARUV_SUPPLIER_COPY_INTRO_OPTION, array(
        'type'              => 'string',
        'sanitize_callback' => 'wp_kses_post',
        'default'           => '',
    ));
});

/**
 * Default intro paragraph for the copy email sent to the supplier.
 */
function haruv_supplier_copy_intro_default() {
    return "<p>שלום,</p>\n"
        . "<p>תודה שמילאתם את טופס ההרשמה למאגר הספקים של מכון חרוב. לנוחותכם, מצורף ריכוז הפרטים שמסרתם.</p>\n"
        . "<p><strong>אנא בדקו שכל הפרטים נכונים.</strong> במידה ונפלה טעות או שחל שינוי — צרו איתנו קשר ונעדכן.</p>";
}

function haruv_supplier_copy_intro() {
    $v = get_option(HARUV_SUPPLIER_COPY_INTRO_OPTION, '');
    return (is_string($v) && trim($v) !== '') ? $v : haruv_supplier_copy_intro_default();
}

function haruv_supplier_form_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }
    $current    = get_option(HARUV_SUPPLIER_SUCCESS_OPTION, '');
    $send_copy  = get_option(HARUV_SUPPLIER_SEND_COPY_OPTION, '1');
    $copy_intro = get_option(HARUV_SUPPLIER_COPY_INTRO_OPTION, '');
    ?>
    <div class="wrap">
        <h1><?php _e('הגדרות טופס הרשמת ספקים', 'haruv-suppliers'); ?></h1>
        <form method="post" action="options.php">
            <?php settings_fields('haruv_supplier_form_settings'); ?>

            <h2><?php _e('הודעת הצלחה (לאחר שליחת הטופס)', 'haruv-suppliers'); ?></h2>
            <p class="description"><?php _e('ההודעה שמוצגת לספק במסך ההצלחה (כולל הצעדים הבאים). השאירו ריק לנוסח ברירת המחדל.', 'haruv-suppliers'); ?></p>
            <?php
            wp_editor(
                $current !== '' ? $current : haruv_supplier_success_default_message(),
                'haruv_supplier_success_editor',
                array('textarea_name' => HARUV_SUPPLIER_SUCCESS_OPTION, 'textarea_rows' => 12, 'media_buttons' => false, 'teeny' => true)
            );
            ?>

            <hr>
            <h2><?php _e('מייל אישור לספק', 'haruv-suppliers'); ?></h2>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><?php _e('שליחת מייל אישור', 'haruv-suppliers'); ?></th>
                    <td>
                        <label>
                            <input type="checkbox" name="<?php echo esc_attr(HARUV_SUPPLIER_SEND_COPY_OPTION); ?>" value="1" <?php checked($send_copy, '1'); ?>>
                            <?php _e('לשלוח לספק מייל המכיל את כל הפרטים שהזין (למניעת אי-הבנות)', 'haruv-suppliers'); ?>
                        </label>
                        <p class="description"><?php _e('המייל נשלח לכתובת הדוא"ל שהוזנה בטופס (שדה דוא"ל כללי / אימייל איש קשר).', 'haruv-suppliers'); ?></p>
                    </td>
                </tr>
            </table>
            <h3><?php _e('פתיח המייל לספק', 'haruv-suppliers'); ?></h3>
            <p class="description"><?php _e('הטקסט שיופיע בראש מייל האישור, מעל טבלת הפרטים. השאירו ריק לנוסח ברירת המחדל.', 'haruv-suppliers'); ?></p>
            <?php
            wp_editor(
                $copy_intro !== '' ? $copy_intro : haruv_supplier_copy_intro_default(),
                'haruv_supplier_copy_intro_editor',
                array('textarea_name' => HARUV_SUPPLIER_COPY_INTRO_OPTION, 'textarea_rows' => 8, 'media_buttons' => false, 'teeny' => true)
            );
            ?>

            <?php submit_button(__('שמור', 'haruv-suppliers')); ?>
        </form>

        <hr>
        <h2><?php _e('תצוגה מקדימה — נוסח ברירת מחדל של הודעת ההצלחה', 'haruv-suppliers'); ?></h2>
        <div style="max-width:640px;border:1px solid #dcdcde;border-radius:6px;padding:16px;background:#fff;">
            <?php echo wp_kses_post(haruv_supplier_success_default_message()); ?>
        </div>
    </div>
    <?php
}

/* -------------------------------------------------------------------------
 * Email confirmation to the supplier — full dump of submitted data
 * ---------------------------------------------------------------------- */

add_action('acf/save_post', 'haruv_send_supplier_confirmation_copy', 25); // after the admin notification (prio 20)

function haruv_send_supplier_confirmation_copy($post_id) {
    if (get_option(HARUV_SUPPLIER_SEND_COPY_OPTION, '1') !== '1') {
        return;
    }
    if (!is_numeric($post_id)) { // ACF passes "options"/term strings sometimes
        return;
    }
    if (wp_is_post_revision($post_id) || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)) {
        return;
    }
    // Front-end submissions only.
    if (is_admin() && !(defined('DOING_AJAX') && DOING_AJAX)) {
        return;
    }
    $post = get_post($post_id);
    if (!$post) {
        return;
    }
    $supplier_types = array('photographer', 'venue', 'catering', 'hotel', 'printing', 'administration', 'gifts', 'workshop', 'lecture');
    if (!in_array($post->post_type, $supplier_types, true)) {
        return;
    }
    // Dedup.
    if (get_post_meta($post_id, '_haruv_supplier_copy_sent', true)) {
        return;
    }

    $to = haruv_extract_supplier_email($post_id);
    if (!$to || !is_email($to)) {
        return;
    }

    $subject = sprintf(__('אישור קליטת פרטים — %s', 'haruv-suppliers'), $post->post_title ?: __('ספק', 'haruv-suppliers'));
    $message = haruv_build_supplier_copy_email($post);
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . get_bloginfo('name') . ' <' . get_option('admin_email') . '>',
    );

    if (wp_mail($to, $subject, $message, $headers)) {
        update_post_meta($post_id, '_haruv_supplier_copy_sent', current_time('mysql'));
    }
}

/**
 * Find the email address the supplier entered (top-level 'email', or contact_person.email).
 */
function haruv_extract_supplier_email($post_id) {
    $candidates = array(
        get_field('email', $post_id),
    );
    $cp = get_field('contact_person', $post_id);
    if (is_array($cp) && !empty($cp['email'])) {
        $candidates[] = $cp['email'];
    }
    // lecturer group uses a flat 'email' too — already covered.
    foreach ($candidates as $c) {
        if (is_string($c) && is_email($c)) {
            return sanitize_email($c);
        }
    }
    return '';
}

/**
 * Build the confirmation email: intro text + a full, labelled dump of every ACF field on the post.
 */
function haruv_build_supplier_copy_email($post) {
    $intro = haruv_supplier_copy_intro();
    $rows  = haruv_acf_fields_to_html_rows($post->ID);
    $type  = function_exists('haruv_get_supplier_type_label') ? haruv_get_supplier_type_label($post->post_type) : $post->post_type;
    $date  = get_the_date('d/m/Y H:i', $post->ID);

    ob_start();
    ?><!DOCTYPE html>
<html dir="rtl" lang="he"><head><meta charset="UTF-8"></head>
<body style="font-family:Arial,Helvetica,sans-serif;direction:rtl;text-align:right;background:#f3f4f6;margin:0;padding:24px;">
<div style="max-width:640px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden;border:1px solid #e5e7eb;">
  <div style="background:#007cba;color:#fff;padding:20px 24px;">
    <h1 style="margin:0;font-size:20px;"><?php echo esc_html__('אישור קליטת פרטים', 'haruv-suppliers'); ?></h1>
    <div style="opacity:.9;font-size:13px;margin-top:4px;"><?php echo esc_html($type) . ' · ' . esc_html($date); ?></div>
  </div>
  <div style="padding:20px 24px;line-height:1.7;color:#1f2937;">
    <?php echo wp_kses_post($intro); ?>
    <h2 style="font-size:16px;border-bottom:2px solid #007cba;padding-bottom:6px;margin-top:24px;"><?php echo esc_html__('הפרטים שמסרת', 'haruv-suppliers'); ?></h2>
    <table style="width:100%;border-collapse:collapse;font-size:14px;">
      <tr><th style="text-align:right;padding:6px 8px;background:#f9fafb;border:1px solid #e5e7eb;width:38%;"><?php echo esc_html__('שם הספק', 'haruv-suppliers'); ?></th>
          <td style="padding:6px 8px;border:1px solid #e5e7eb;"><?php echo esc_html($post->post_title); ?></td></tr>
      <?php echo $rows; // already escaped inside ?>
    </table>
    <p style="margin-top:22px;color:#6b7280;font-size:13px;"><?php echo esc_html__('אם נפלה טעות באחד הפרטים — השיבו למייל זה ונתקן.', 'haruv-suppliers'); ?></p>
  </div>
</div>
</body></html>
    <?php
    return ob_get_clean();
}

/**
 * Recursively convert all ACF fields on a post into <tr> rows (label | value), HTML-escaped.
 */
function haruv_acf_fields_to_html_rows($post_id) {
    if (!function_exists('get_field_objects')) {
        return '';
    }
    $objects = get_field_objects($post_id);
    if (!$objects) {
        return '';
    }
    $out = '';
    foreach ($objects as $obj) {
        $out .= haruv_acf_field_row($obj, 0);
    }
    return $out;
}

function haruv_acf_field_row($obj, $depth) {
    $label = isset($obj['label']) ? $obj['label'] : (isset($obj['name']) ? $obj['name'] : '');
    $type  = isset($obj['type']) ? $obj['type'] : '';
    $value = isset($obj['value']) ? $obj['value'] : null;
    $pad   = $depth > 0 ? ('padding-inline-start:' . (8 + $depth * 16) . 'px;') : 'padding:6px 8px;';

    // Container types → header row + recurse into sub fields.
    if (in_array($type, array('group',), true) && is_array($value)) {
        $row = '<tr><th colspan="2" style="text-align:right;padding:8px;background:#eef2ff;border:1px solid #e5e7eb;font-size:13px;">' . esc_html($label) . '</th></tr>';
        if (!empty($obj['sub_fields'])) {
            foreach ($obj['sub_fields'] as $sub) {
                // get_field_objects already nested the values under $value[name]
                $sub_obj = $sub;
                $sub_obj['value'] = isset($value[$sub['name']]) ? $value[$sub['name']] : null;
                $row .= haruv_acf_field_row($sub_obj, $depth + 1);
            }
        }
        return $row;
    }
    if (in_array($type, array('repeater',), true) && is_array($value)) {
        $row = '<tr><th colspan="2" style="text-align:right;padding:8px;background:#eef2ff;border:1px solid #e5e7eb;font-size:13px;">' . esc_html($label) . ' (' . count($value) . ')</th></tr>';
        $i = 1;
        foreach ($value as $item) {
            $row .= '<tr><th colspan="2" style="text-align:right;padding:6px 8px;background:#f3f4f6;border:1px solid #e5e7eb;font-size:12px;">#' . $i++ . '</th></tr>';
            if (!empty($obj['sub_fields']) && is_array($item)) {
                foreach ($obj['sub_fields'] as $sub) {
                    $sub_obj = $sub;
                    $sub_obj['value'] = isset($item[$sub['name']]) ? $item[$sub['name']] : null;
                    $row .= haruv_acf_field_row($sub_obj, $depth + 1);
                }
            }
        }
        return $row;
    }

    $display = haruv_acf_value_to_text($obj);
    if ($display === '' ) {
        return ''; // skip empty fields
    }
    return '<tr><th style="text-align:right;' . $pad . 'background:#f9fafb;border:1px solid #e5e7eb;vertical-align:top;width:38%;font-weight:600;">'
        . esc_html($label) . '</th><td style="padding:6px 8px;border:1px solid #e5e7eb;vertical-align:top;">'
        . nl2br(esc_html($display)) . '</td></tr>';
}

/**
 * Human-readable text for a single ACF field value (handles select labels, files, dates, arrays).
 */
function haruv_acf_value_to_text($obj) {
    $type  = isset($obj['type']) ? $obj['type'] : '';
    $value = isset($obj['value']) ? $obj['value'] : null;

    if ($value === null || $value === '' || $value === false) {
        return '';
    }

    // Select / radio / checkbox — map value(s) to label(s) via choices.
    if (in_array($type, array('select', 'radio', 'checkbox', 'button_group'), true)) {
        $choices = isset($obj['choices']) && is_array($obj['choices']) ? $obj['choices'] : array();
        $map = function ($v) use ($choices) {
            if (is_array($v)) { // return_format=array → {value,label}
                return isset($v['label']) ? $v['label'] : (isset($v['value']) ? $v['value'] : '');
            }
            return isset($choices[$v]) ? $choices[$v] : $v;
        };
        if (is_array($value) && !isset($value['label'])) {
            return implode(', ', array_filter(array_map($map, $value), 'strlen'));
        }
        return (string) $map($value);
    }

    // True/false
    if ($type === 'true_false') {
        return $value ? __('כן', 'haruv-suppliers') : __('לא', 'haruv-suppliers');
    }

    // File / image
    if (in_array($type, array('file', 'image'), true)) {
        if (is_array($value)) {
            $name = isset($value['filename']) ? $value['filename'] : (isset($value['title']) ? $value['title'] : '');
            $url  = isset($value['url']) ? $value['url'] : '';
            return trim($name . ($url ? ' (' . $url . ')' : ''));
        }
        if (is_numeric($value)) {
            $url = wp_get_attachment_url($value);
            return $url ?: ('#' . $value);
        }
        return (string) $value;
    }

    // Date pickers
    if (in_array($type, array('date_picker', 'date_time_picker'), true)) {
        return (string) $value;
    }

    // Google map / address-ish array
    if (is_array($value)) {
        if (isset($value['address'])) {
            return (string) $value['address'];
        }
        // Flatten scalars.
        $parts = array();
        array_walk_recursive($value, function ($v) use (&$parts) {
            if (is_scalar($v) && $v !== '') { $parts[] = $v; }
        });
        return implode(', ', $parts);
    }

    return (string) $value;
}

/* -------------------------------------------------------------------------
 * Front-end: assets + success renderer
 * ---------------------------------------------------------------------- */

/**
 * Is the current request one of the supplier-registration page templates?
 */
function haruv_is_supplier_form_page() {
    if (!is_page()) {
        return false;
    }
    return is_page_template(array(
        'page-add-supplier.php',
        'page-add-supplier-general.php',
        'page-add-venue.php',
        'page-add-lecture.php',
        'page-add-lecture-general.php',
    ));
}

add_action('wp_enqueue_scripts', function () {
    if (!haruv_is_supplier_form_page()) {
        return;
    }
    $ver = defined('HARUV_SUPPLIERS_VERSION') ? HARUV_SUPPLIERS_VERSION : '1.5.0';

    wp_register_style('haruv-supplier-form-ux', false, array(), $ver);
    wp_enqueue_style('haruv-supplier-form-ux');
    wp_add_inline_style('haruv-supplier-form-ux', haruv_supplier_form_ux_css());

    // canvas-confetti (tiny, ~6KB) from CDN.
    wp_enqueue_script('canvas-confetti', 'https://cdn.jsdelivr.net/npm/canvas-confetti@1.9.3/dist/confetti.browser.min.js', array(), '1.9.3', true);

    wp_register_script('haruv-supplier-form-ux', false, array('jquery', 'canvas-confetti'), $ver, true);
    wp_enqueue_script('haruv-supplier-form-ux');
    wp_add_inline_script('haruv-supplier-form-ux', haruv_supplier_form_ux_js());

    // Required-field guard — its OWN handle with NO dependencies, so it still
    // runs when jQuery/ACF/confetti fail to load (the whole point of the guard).
    wp_register_script('haruv-supplier-required-guard', false, array(), $ver, true);
    wp_enqueue_script('haruv-supplier-required-guard');
    wp_add_inline_script('haruv-supplier-required-guard', haruv_supplier_required_guard_js());
}, 20);

function haruv_supplier_form_ux_css() {
    return <<<CSS
#haruv-processing-overlay,#haruv-success-overlay{position:fixed;inset:0;z-index:999999;display:none;align-items:center;justify-content:center;text-align:center;padding:20px;background:rgba(15,23,42,.92);color:#fff;font-size:18px}
#haruv-processing-overlay.is-visible,#haruv-success-overlay.is-visible{display:flex;flex-direction:column;gap:18px}
#haruv-processing-overlay .haruv-spinner{width:56px;height:56px;border:5px solid rgba(255,255,255,.25);border-top-color:#fff;border-radius:50%;animation:haruv-spin 1s linear infinite}
@keyframes haruv-spin{to{transform:rotate(360deg)}}
#haruv-processing-overlay .haruv-proc-title{font-size:22px;font-weight:700}
#haruv-processing-overlay .haruv-proc-sub{opacity:.85;font-size:15px}
#haruv-success-overlay .haruv-success-card{background:#fff;color:#1e293b;max-width:560px;width:100%;border-radius:16px;padding:32px 28px;box-shadow:0 20px 60px rgba(0,0,0,.35);text-align:right;line-height:1.7}
#haruv-success-overlay .haruv-success-emoji{font-size:54px;line-height:1;margin-bottom:8px;text-align:center}
#haruv-success-overlay .haruv-success-card h2{margin:0 0 12px;font-size:24px;color:#16a34a;text-align:center}
#haruv-success-overlay .haruv-success-card ul{padding-inline-start:22px}
#haruv-success-overlay .haruv-success-actions{margin-top:22px;text-align:center}
#haruv-success-overlay .haruv-btn{display:inline-block;background:#2271b1;color:#fff;text-decoration:none;padding:10px 22px;border-radius:8px;font-weight:600}
#haruv-success-overlay .haruv-btn:hover{background:#135e96}
.acf-field.haruv-invalid{outline:2px solid #d63638;outline-offset:4px;border-radius:4px}
.acf-field.haruv-invalid > .acf-label label{color:#d63638}
.haruv-required-notice{margin:0 0 16px;padding:10px 14px;background:#fcf0f1;border-inline-start:4px solid #d63638;color:#8a1f21;font-weight:600;border-radius:4px}
CSS;
}

function haruv_supplier_form_ux_js() {
    $processing_title = esc_js(__('מעבד את הבקשה…', 'haruv-suppliers'));
    $processing_sub   = esc_js(__('אנא המתינו, אנו שומרים את הפרטים. אין לרענן את העמוד.', 'haruv-suppliers'));
    return <<<JS
(function(){
  function el(html){var d=document.createElement('div');d.innerHTML=html.trim();return d.firstChild;}

  // ---- Processing overlay (shown on submit) -------------------------------
  var processing = el('<div id="haruv-processing-overlay" role="alert" aria-live="assertive">'
    + '<div class="haruv-spinner"></div>'
    + '<div class="haruv-proc-title">{$processing_title}</div>'
    + '<div class="haruv-proc-sub">{$processing_sub}</div>'
    + '</div>');
  document.body.appendChild(processing);

  function lockSubmit(form){
    var btn = form && form.querySelector('.acf-form-submit input[type="submit"], input[type="submit"], button[type="submit"]');
    if (btn){ btn.disabled = true; btn.classList.add('disabled'); }
  }
  function showProcessing(form){ lockSubmit(form); processing.classList.add('is-visible'); }
  function hideProcessing(){ processing.classList.remove('is-visible'); document.querySelectorAll('form.acf-form .acf-form-submit input[type="submit"]').forEach(function(b){ b.disabled=false; b.classList.remove('disabled'); }); }

  // Preferred path: ACF's validation lifecycle (only fires when the form will actually submit).
  if (window.acf && acf.addAction){
    acf.addAction('submit', function($form){
      // 'submit' runs after a successful validation, right before the form posts.
      showProcessing(($form && $form[0]) || document.querySelector('form.acf-form'));
    });
    // If ACF reports validation failure, make sure no overlay is stuck.
    acf.addAction('validation_failure', hideProcessing);
    acf.addAction('invalid_field', hideProcessing);
  } else {
    // Fallback when ACF JS isn't present: lock + overlay on raw submit.
    document.querySelectorAll('form.acf-form').forEach(function(form){
      form.addEventListener('submit', function(){ setTimeout(function(){ showProcessing(form); }, 0); }, true);
    });
  }
  // Safety net: if the page hasn't navigated away after 25s, release the lock so the user isn't stuck.
  window.addEventListener('pagehide', function(){}, false);

  // ---- Success overlay (shown on the ?save return page) -------------------
  var data = window.HARUV_SUPPLIER_SUCCESS || null;
  if (data && data.message){
    var card = el('<div id="haruv-success-overlay" role="dialog" aria-modal="true">'
      + '<div class="haruv-success-card">'
      +   '<div class="haruv-success-emoji">🎉</div>'
      +   '<h2>'+ (data.title || 'הפרטים נשמרו בהצלחה!') +'</h2>'
      +   '<div class="haruv-success-body">'+ data.message +'</div>'
      +   '<div class="haruv-success-actions"><a class="haruv-btn" href="'+ (data.home || '/') +'">'+ (data.button || 'סגור') +'</a></div>'
      + '</div></div>');
    document.body.appendChild(card);
    card.classList.add('is-visible');

    // Confetti burst.
    if (typeof confetti === 'function'){
      var end = Date.now() + 1200;
      (function frame(){
        confetti({particleCount:4,angle:60,spread:60,origin:{x:0}});
        confetti({particleCount:4,angle:120,spread:60,origin:{x:1}});
        if (Date.now() < end) requestAnimationFrame(frame);
      })();
      confetti({particleCount:120,spread:80,origin:{y:0.3}});
    }
  }
})();
JS;
}

/**
 * Client-side required-field guard for the ACF registration forms.
 *
 * Defense-in-depth: ACF's own AJAX validation only runs when its JS actually
 * loads. When those assets fail (e.g. served over the wrong scheme/host, a JS
 * error, an ad-blocker, or plain slow network) the form degrades to a raw HTML
 * POST and the applicant lands on an ugly server-rendered "Validation failed"
 * page instead of being stopped at the empty field. This guard blocks that.
 *
 * It is intentionally a STANDALONE, dependency-free module (no jQuery, no ACF,
 * no CDN) enqueued under its own handle, so it prints and runs from the page
 * origin even when everything else fails to load. It walks the required ACF
 * field wrappers and, on submit, prevents the POST if any is empty — for every
 * field type (text, textarea, number, email, select, radio, checkbox/
 * true_false consent, file), including fields nested inside ACF group fields.
 */
function haruv_supplier_required_guard_js() {
    $msg_field  = esc_js(__('שדה חובה', 'haruv-suppliers'));
    $msg_notice = esc_js(__('יש למלא את כל שדות החובה המסומנים.', 'haruv-suppliers'));
    return <<<JS
(function(){
  // A field wrapper is "required" if ACF flagged it. ACF uses several markers
  // across versions; accept any of them.
  function requiredWrappers(form){
    var set = [];
    var sel = '.acf-field.is-required, .acf-field.acf-required, .acf-field[data-required="1"]';
    form.querySelectorAll(sel).forEach(function(w){ if (set.indexOf(w) === -1) set.push(w); });
    return set;
  }

  var TEXTISH = 'input[type="text"], input[type="email"], input[type="number"], input[type="url"], input[type="tel"], input[type="password"], input:not([type]), textarea';

  // A GROUP field (address, bank details, tax details…) is required as a whole
  // but ACF marks only the group wrapper, not its sub-fields. Require every
  // visible sub-input inside it to be filled.
  function groupEmpty(wrapper){
    var texts = wrapper.querySelectorAll(TEXTISH);
    for (var i=0;i<texts.length;i++){
      if (texts[i].offsetParent === null) continue; // skip hidden
      if (texts[i].value.trim() === '') return true;
    }
    var selects = wrapper.querySelectorAll('select');
    for (var j=0;j<selects.length;j++){
      if (selects[j].offsetParent === null) continue;
      if (selects[j].value === '' || selects[j].value === null) return true;
    }
    return false;
  }

  // Is this required wrapper empty? Inspect the inputs it actually contains.
  function isEmpty(wrapper){
    // Group field: every visible sub-input must be filled.
    if (wrapper.className.indexOf('acf-field-group') !== -1){
      return groupEmpty(wrapper);
    }
    // Radio: at least one option must be checked.
    var radios = wrapper.querySelectorAll('input[type="radio"]');
    if (radios.length){
      for (var i=0;i<radios.length;i++){ if (radios[i].checked) return false; }
      return true;
    }
    // Checkbox / true_false (consent): the real (non-hidden) checkbox must be checked.
    var checks = wrapper.querySelectorAll('input[type="checkbox"]');
    if (checks.length){
      for (var j=0;j<checks.length;j++){ if (checks[j].checked) return false; }
      return true;
    }
    // Select: a real value that isn't the empty placeholder.
    var sel = wrapper.querySelector('select');
    if (sel){
      var v = sel.value;
      return (v === '' || v === null);
    }
    // File (ACF wp uploader): a hidden input holds the attachment id when set.
    if (wrapper.className.indexOf('acf-field-file') !== -1 || wrapper.className.indexOf('acf-field-image') !== -1){
      var hid = wrapper.querySelector('input[type="hidden"][name^="acf"]');
      return !(hid && hid.value && hid.value !== '');
    }
    // Text / textarea / number / email / url / tel.
    var txt = wrapper.querySelector(TEXTISH);
    if (txt){ return txt.value.trim() === ''; }
    return false; // unknown structure — do not block on it.
  }

  function clearMarks(form){
    form.querySelectorAll('.acf-field.haruv-invalid').forEach(function(w){ w.classList.remove('haruv-invalid'); });
    var msg = form.querySelector('.haruv-required-notice');
    if (msg){ msg.parentNode.removeChild(msg); }
  }

  function firstFocusable(wrapper){
    return wrapper.querySelector('select, input:not([type="hidden"]), textarea');
  }

  // Returns the first empty required wrapper, or null if all filled.
  function validate(form){
    var wraps = requiredWrappers(form), firstBad = null;
    for (var i=0;i<wraps.length;i++){
      if (isEmpty(wraps[i])){
        wraps[i].classList.add('haruv-invalid');
        if (!firstBad) firstBad = wraps[i];
      }
    }
    return firstBad;
  }

  function guard(e){
    var form = e.currentTarget;
    clearMarks(form);
    var bad = validate(form);
    if (bad){
      e.preventDefault();
      e.stopImmediatePropagation();  // also stops the processing-overlay listener
      // Inline notice at the top of the form, styled like ACF's own notices.
      var notice = document.createElement('div');
      notice.className = 'acf-notice -error haruv-required-notice';
      notice.setAttribute('role','alert');
      notice.textContent = '{$msg_notice}';
      form.insertBefore(notice, form.firstChild);
      var focusEl = firstFocusable(bad);
      (focusEl || bad).scrollIntoView({behavior:'smooth', block:'center'});
      if (focusEl){ try { focusEl.focus({preventScroll:true}); } catch(_){ focusEl.focus(); } }
    }
  }

  function markRequired(input){
    if (!input) return;
    input.setAttribute('required','required');
    input.setAttribute('aria-required','true');
  }

  function stampNativeRequired(form){
    // Belt-and-suspenders: native HTML5 required on text-like inputs + selects,
    // so the browser blocks even if THIS script's submit handler never runs.
    requiredWrappers(form).forEach(function(w){
      if (w.className.indexOf('acf-field-file') !== -1 || w.className.indexOf('acf-field-image') !== -1) return;
      // Group: stamp every visible text/select sub-input.
      if (w.className.indexOf('acf-field-group') !== -1){
        w.querySelectorAll(TEXTISH + ', select').forEach(function(inp){
          if (inp.offsetParent !== null) markRequired(inp);
        });
        return;
      }
      if (w.querySelector('input[type="radio"], input[type="checkbox"]')) return; // handled by guard()
      markRequired(w.querySelector('select, ' + TEXTISH));
    });
  }

  function init(){
    document.querySelectorAll('form.acf-form').forEach(function(form){
      stampNativeRequired(form);
      // Capture phase so we run before ACF's own submit hooks and the overlay.
      form.addEventListener('submit', guard, true);
      // Clear a field's error state as the user fixes it.
      form.addEventListener('change', function(ev){
        var w = ev.target.closest && ev.target.closest('.acf-field.haruv-invalid');
        if (w && !isEmpty(w)) w.classList.remove('haruv-invalid');
      }, true);
    });
  }

  if (document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', init);
  } else { init(); }
})();
JS;
}

/**
 * Output the success payload + (optional) inline fallback markup.
 * Call this from the theme template's `$save` branch:
 *   <?php if (function_exists('haruv_render_supplier_success')) haruv_render_supplier_success($supplier_type); ?>
 *
 * @param string $supplier_type
 */
function haruv_render_supplier_success($supplier_type = '') {
    $message = haruv_supplier_success_message();
    $payload = array(
        'title'   => __('הפרטים נשמרו בהצלחה!', 'haruv-suppliers'),
        'message' => $message,           // HTML — already wp_kses_post on save
        'button'  => __('חזרה לאתר', 'haruv-suppliers'),
        'home'    => esc_url(home_url('/')),
    );
    echo '<script>window.HARUV_SUPPLIER_SUCCESS = ' . wp_json_encode($payload) . ';</script>';

    // Non-JS fallback (also nice for the brief moment before the overlay paints).
    echo '<div class="haruv-success-inline" style="max-width:640px;margin:24px auto;border:1px solid #bbf7d0;background:#f0fdf4;border-radius:12px;padding:20px;line-height:1.7;">';
    echo '<h2 style="margin-top:0;color:#16a34a;">🎉 ' . esc_html__('הפרטים נשמרו בהצלחה!', 'haruv-suppliers') . '</h2>';
    echo wp_kses_post($message);
    echo '<p style="margin-bottom:0;"><a class="button" href="' . esc_url(home_url('/')) . '">' . esc_html__('חזרה לאתר', 'haruv-suppliers') . '</a></p>';
    echo '</div>';
}
