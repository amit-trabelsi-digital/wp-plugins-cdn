<?php
/**
 * Rate/Degree audit screen.
 *
 * Lists every lecturer whose hourly rate (hour_price) is a STANDARD choice
 * value that does NOT match the rate its academic degree would derive, and
 * offers a per-row (and bulk) "fix" that rewrites hour_price to the correct
 * degree-based value.
 *
 * Special (manual) prices — anything that is not one of the standard choice
 * values 1..4 — are intentionally excluded and never touched, mirroring the
 * rule enforced in registration-handler.php (haruv_derive_lecture_rate).
 *
 * @package Haruv_Suppliers
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * hour_price group-6 field key (edit screen). Falls back if the constant from
 * registration-handler.php is not defined for some reason.
 */
if (!defined('HARUV_HOUR_PRICE_KEY_GROUP6')) {
    define('HARUV_HOUR_PRICE_KEY_GROUP6', 'field_5fa05fcc2be63');
}

/**
 * Human-readable label for a degree choice value, read from the live ACF
 * field so it stays in sync with wp-admin. Falls back to a static map.
 *
 * @param string|int $value
 * @return string
 */
function haruv_rate_audit_degree_label($value) {
    static $map = null;
    if ($map === null) {
        $map = array();
        if (function_exists('acf_get_field')) {
            $field = acf_get_field('field_5fa05ee82be62'); // degree (group 6)
            if ($field && !empty($field['choices']) && is_array($field['choices'])) {
                $map = $field['choices'];
            }
        }
        if (empty($map)) {
            $map = array(
                '1' => 'תואר ראשון', '2' => 'תואר שני', '3' => 'תואר שלישי',
                '4' => 'מומחה', '5' => 'דוקטור', '6' => 'מומחה מנסיון חיים',
                '7' => 'פסיכולוג מוסמך להדרכה', '8' => 'פרופסור',
            );
        }
    }
    $value = (string) $value;
    return isset($map[$value]) ? $map[$value] : $value;
}

/**
 * Human-readable label (the shekel amount) for an hour_price choice value.
 *
 * @param string|int $value
 * @return string
 */
function haruv_rate_audit_price_label($value) {
    static $map = null;
    if ($map === null) {
        $map = array();
        if (function_exists('acf_get_field')) {
            $field = acf_get_field(HARUV_HOUR_PRICE_KEY_GROUP6);
            if ($field && !empty($field['choices']) && is_array($field['choices'])) {
                $map = $field['choices'];
            }
        }
        if (empty($map)) {
            $map = array('1' => '305', '2' => '365', '3' => '415', '4' => '450');
        }
    }
    $value = (string) $value;
    return isset($map[$value]) ? $map[$value] : $value;
}

/**
 * Scan all lecturers and return those whose standard hour_price does not match
 * their degree-derived rate. Depends on helpers from registration-handler.php.
 *
 * @return array[] Each: ['id','title','degree','degree_label',
 *                        'current','current_label','expected','expected_label']
 */
function haruv_rate_audit_mismatches() {
    $out = array();

    if (!function_exists('haruv_reg_rate_from_degree')
        || !function_exists('haruv_reg_standard_rates')) {
        return $out; // registration-handler.php not loaded — nothing we can do.
    }

    $standard = haruv_reg_standard_rates();

    $q = new WP_Query(array(
        'post_type'      => 'lecture',
        'post_status'    => 'any',
        'posts_per_page' => -1,
        'fields'         => 'ids',
        'no_found_rows'  => true,
    ));

    foreach ($q->posts as $post_id) {
        // Some historic lecturers store degree/hour_price as a serialized
        // array; normalize both to scalars before comparing (mirrors the
        // handler's haruv_reg_scalar_degree()).
        $degree = get_post_meta($post_id, 'degree', true);
        if (is_array($degree)) {
            $degree = reset($degree);
        }
        if ($degree === '' || $degree === null || $degree === false) {
            continue;
        }

        $expected = haruv_reg_rate_from_degree($degree);
        if ($expected === '') {
            continue; // degree unmapped — no expectation to compare against.
        }

        $current = get_post_meta($post_id, 'hour_price', true);
        if (is_array($current)) {
            $current = reset($current);
        }
        if ($current === '' || $current === null || $current === false) {
            continue; // empty is handled on save, not a "wrong" value to report.
        }

        // Only flag STANDARD prices that disagree. Special prices are respected.
        if (!in_array((string) $current, $standard, true)) {
            continue;
        }
        if ((string) $current === (string) $expected) {
            continue; // already correct.
        }

        $out[] = array(
            'id'             => $post_id,
            'title'          => get_the_title($post_id),
            'degree'         => (string) $degree,
            'degree_label'   => haruv_rate_audit_degree_label($degree),
            'current'        => (string) $current,
            'current_label'  => haruv_rate_audit_price_label($current),
            'expected'       => (string) $expected,
            'expected_label' => haruv_rate_audit_price_label($expected),
        );
    }

    return $out;
}

/**
 * Apply the degree-derived rate to a single lecturer. Re-validates that the
 * post is still a standard-but-mismatched case before writing, so a stale
 * button can never overwrite a special price.
 *
 * @param int $post_id
 * @return bool True if a fix was written.
 */
function haruv_rate_audit_fix_one($post_id) {
    $post_id = (int) $post_id;
    if (!$post_id || get_post_type($post_id) !== 'lecture') {
        return false;
    }
    if (!function_exists('haruv_reg_rate_from_degree')
        || !function_exists('haruv_reg_standard_rates')) {
        return false;
    }

    $degree = get_post_meta($post_id, 'degree', true);
    if (is_array($degree)) {
        $degree = reset($degree);
    }
    if ($degree === '' || $degree === null || $degree === false) {
        return false;
    }
    $expected = haruv_reg_rate_from_degree($degree);
    if ($expected === '') {
        return false;
    }
    $current = get_post_meta($post_id, 'hour_price', true);
    if (is_array($current)) {
        $current = reset($current);
    }
    if (!in_array((string) $current, haruv_reg_standard_rates(), true)) {
        return false; // special price — never touch.
    }
    if ((string) $current === (string) $expected) {
        return false; // already correct.
    }

    if (function_exists('update_field')) {
        update_field(HARUV_HOUR_PRICE_KEY_GROUP6, $expected, $post_id);
    } else {
        update_post_meta($post_id, 'hour_price', $expected);
    }
    return true;
}

/**
 * Handle fix actions (single + bulk) before the page renders.
 * Returns a status array for the notice, or null.
 */
function haruv_rate_audit_handle_actions() {
    if (empty($_POST['haruv_rate_audit_action'])) {
        return null;
    }
    if (!current_user_can('manage_options')) {
        return null;
    }
    check_admin_referer('haruv_rate_audit_fix');

    $action = sanitize_text_field(wp_unslash($_POST['haruv_rate_audit_action']));
    $fixed  = 0;

    if ($action === 'fix_one' && !empty($_POST['post_id'])) {
        if (haruv_rate_audit_fix_one((int) $_POST['post_id'])) {
            $fixed = 1;
        }
    } elseif ($action === 'fix_all' && !empty($_POST['post_ids']) && is_array($_POST['post_ids'])) {
        foreach ($_POST['post_ids'] as $pid) {
            if (haruv_rate_audit_fix_one((int) $pid)) {
                $fixed++;
            }
        }
    }

    return array('fixed' => $fixed);
}

/**
 * Render the audit page.
 */
function haruv_rate_audit_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('אין הרשאה', 'haruv-suppliers'));
    }

    $status      = haruv_rate_audit_handle_actions();
    $mismatches  = haruv_rate_audit_mismatches();
    $all_ids     = wp_list_pluck($mismatches, 'id');
    ?>
    <div class="wrap" dir="rtl">
        <h1><?php esc_html_e('פערי עלות / תואר — מרצים', 'haruv-suppliers'); ?></h1>

        <?php if ($status && $status['fixed'] > 0) : ?>
            <div class="notice notice-success is-dismissible">
                <p><?php printf(esc_html__('תוקנו %d מרצים.', 'haruv-suppliers'), (int) $status['fixed']); ?></p>
            </div>
        <?php elseif ($status) : ?>
            <div class="notice notice-info is-dismissible">
                <p><?php esc_html_e('לא בוצע שינוי (ייתכן שהערכים כבר תקינים או שמדובר במחיר מיוחד).', 'haruv-suppliers'); ?></p>
            </div>
        <?php endif; ?>

        <p style="max-width:760px;">
            <?php esc_html_e('הטבלה מציגה מרצים שהעלות לשעה שלהם היא ערך סטנדרטי (305/365/415/450) אך אינה תואמת לתואר האקדמי שלהם. מחירים מיוחדים (ערך שאינו אחד מהסטנדרטיים) לא מוצגים ולא ישונו.', 'haruv-suppliers'); ?>
        </p>

        <?php if (empty($mismatches)) : ?>
            <div class="notice notice-success inline"><p>
                <?php esc_html_e('אין פערים — כל העלויות תואמות לתארים. 🎉', 'haruv-suppliers'); ?>
            </p></div>
            <?php return; ?>
        <?php endif; ?>

        <form method="post" style="margin:12px 0;">
            <?php wp_nonce_field('haruv_rate_audit_fix'); ?>
            <input type="hidden" name="haruv_rate_audit_action" value="fix_all" />
            <?php foreach ($all_ids as $pid) : ?>
                <input type="hidden" name="post_ids[]" value="<?php echo esc_attr($pid); ?>" />
            <?php endforeach; ?>
            <button type="submit" class="button button-primary"
                onclick="return confirm('<?php echo esc_js(__('לתקן את כל המרצים ברשימה לפי התואר?', 'haruv-suppliers')); ?>');">
                <?php printf(esc_html__('תקן את כל הפערים (%d)', 'haruv-suppliers'), count($mismatches)); ?>
            </button>
        </form>

        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php esc_html_e('מרצה', 'haruv-suppliers'); ?></th>
                    <th><?php esc_html_e('תואר', 'haruv-suppliers'); ?></th>
                    <th><?php esc_html_e('עלות נוכחית', 'haruv-suppliers'); ?></th>
                    <th><?php esc_html_e('עלות נכונה', 'haruv-suppliers'); ?></th>
                    <th><?php esc_html_e('פעולה', 'haruv-suppliers'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($mismatches as $row) : ?>
                    <tr>
                        <td>
                            <a href="<?php echo esc_url(get_edit_post_link($row['id'])); ?>" target="_blank" rel="noopener">
                                <?php echo esc_html($row['title'] ? $row['title'] : ('#' . $row['id'])); ?>
                            </a>
                        </td>
                        <td><?php echo esc_html($row['degree_label']); ?></td>
                        <td style="color:#b32d2e;font-weight:600;"><?php echo esc_html($row['current_label']); ?> ₪</td>
                        <td style="color:#2271b1;font-weight:600;"><?php echo esc_html($row['expected_label']); ?> ₪</td>
                        <td>
                            <form method="post" style="margin:0;">
                                <?php wp_nonce_field('haruv_rate_audit_fix'); ?>
                                <input type="hidden" name="haruv_rate_audit_action" value="fix_one" />
                                <input type="hidden" name="post_id" value="<?php echo esc_attr($row['id']); ?>" />
                                <button type="submit" class="button button-secondary">
                                    <?php esc_html_e('תקן', 'haruv-suppliers'); ?>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}
