<?php
/**
 * Unified Suppliers & Lecturers Admin Screen
 *
 * Provides a single admin page to view, search, filter and sort all suppliers and lecturers.
 * Built for speed: lean WP_Query (no term cache, sticky-post skip), per-row ACF reads limited
 * to the few keys actually displayed, and server-side pagination.
 *
 * @package HaruvSuppliers
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Menu registration lives in haruv-suppliers.php (add_admin_menu): the main
// "ניהול ספקים" menu and its first submenu both point here, slug 'haruv-suppliers-main'.

/**
 * Supplier/lecturer post types handled by this screen.
 *
 * @return array slug => label
 */
function haruv_unified_supplier_types() {
    return array(
        'lecture'        => __('מרצים', 'haruv-suppliers'),
        'venue'          => __('אולמות', 'haruv-suppliers'),
        'catering'       => __('הסעדה', 'haruv-suppliers'),
        'hotel'          => __('מלונות', 'haruv-suppliers'),
        'printing'       => __('בתי דפוס', 'haruv-suppliers'),
        'photographer'   => __('צלמים', 'haruv-suppliers'),
        'administration' => __('אדמיניסטרציה', 'haruv-suppliers'),
        'gifts'          => __('מתנות', 'haruv-suppliers'),
        'workshop'       => __('סדנאות', 'haruv-suppliers'),
    );
}

/**
 * Build a column header link that toggles sort order for this column.
 */
function haruv_sortable_th($column, $label, $current_orderby, $current_order, $base_args, $extra_th = '') {
    $is_current = ($current_orderby === $column);
    $next_order = ($is_current && $current_order === 'asc') ? 'desc' : 'asc';
    $url = add_query_arg(array_merge($base_args, array('orderby' => $column, 'order' => $next_order)));
    $aria = $is_current ? ($current_order === 'asc' ? 'ascending' : 'descending') : 'none';
    $class = 'manage-column sortable ' . ($is_current ? $current_order : 'desc');
    printf(
        '<th scope="col" class="%s" %s aria-sort="%s"><a href="%s"><span>%s</span><span class="sorting-indicator"></span></a></th>',
        esc_attr($class),
        $extra_th,
        esc_attr($aria),
        esc_url($url),
        esc_html($label)
    );
}

/**
 * Unified suppliers page callback
 */
function haruv_unified_suppliers_page() {
    $all_types = haruv_unified_supplier_types();

    // -- Read & sanitize request --------------------------------------------
    $search        = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
    $type_filter   = isset($_GET['type']) && isset($all_types[$_GET['type']]) ? sanitize_key($_GET['type']) : '';
    $valid_status  = array('publish', 'draft', 'pending', 'private');
    $status_filter = isset($_GET['status']) && in_array($_GET['status'], $valid_status, true) ? $_GET['status'] : '';
    $per_page      = isset($_GET['per_page']) ? max(10, min(500, intval($_GET['per_page']))) : 50;
    $paged         = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $date_from     = isset($_GET['date_from']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['date_from']) ? $_GET['date_from'] : '';
    $date_to       = isset($_GET['date_to']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['date_to']) ? $_GET['date_to'] : '';

    // Whitelisted sort. 'type' = order by post_type alphabetically.
    $orderby_map = array(
        'id'       => 'ID',
        'title'    => 'title',
        'type'     => 'type',          // WP_Query understands 'orderby' => 'post_type' via 'type'
        'date'     => 'date',          // registration date
        'modified' => 'modified',
    );
    $orderby = isset($_GET['orderby']) && isset($orderby_map[$_GET['orderby']]) ? sanitize_key($_GET['orderby']) : 'date';
    $order   = (isset($_GET['order']) && strtolower($_GET['order']) === 'asc') ? 'asc' : 'desc';

    // -- Query ---------------------------------------------------------------
    $args = array(
        'post_type'              => $type_filter ? array($type_filter) : array_keys($all_types),
        'post_status'            => $status_filter ? array($status_filter) : $valid_status,
        'posts_per_page'         => $per_page,
        'paged'                  => $paged,
        'orderby'                => ($orderby === 'type') ? 'post_type' : $orderby_map[$orderby],
        'order'                  => strtoupper($order),
        'ignore_sticky_posts'    => true,
        'no_found_rows'          => false, // we need pagination totals
        'update_post_term_cache' => false,
        'update_post_meta_cache' => true,  // ACF reads below benefit from this
    );
    if ('' !== $search) {
        $args['s'] = $search;
    }
    if ($date_from || $date_to) {
        $dq = array('inclusive' => true);
        if ($date_from) { $dq['after'] = $date_from . ' 00:00:00'; }
        if ($date_to)   { $dq['before'] = $date_to . ' 23:59:59'; }
        $args['date_query'] = array($dq);
    }

    $query = new WP_Query($args);

    // Args carried across pagination / sort links.
    $persist_args = array(
        'page'      => 'haruv-suppliers-main',
        's'         => $search,
        'type'      => $type_filter,
        'status'    => $status_filter,
        'per_page'  => $per_page,
        'date_from' => $date_from,
        'date_to'   => $date_to,
    );
    $sort_base_args = array_merge($persist_args, array('paged' => 1));

    $status_labels = array(
        'publish' => __('מפורסם', 'haruv-suppliers'),
        'draft'   => __('טיוטה', 'haruv-suppliers'),
        'pending' => __('ממתין', 'haruv-suppliers'),
        'private' => __('פרטי', 'haruv-suppliers'),
    );
    ?>
    <div class="wrap">
        <h1 class="wp-heading-inline">
            <span class="dashicons dashicons-groups" style="font-size:30px;width:30px;height:30px;margin-left:8px;"></span>
            <?php _e('כל הספקים', 'haruv-suppliers'); ?>
        </h1>
        <a href="<?php echo esc_url(admin_url('post-new.php?post_type=administration')); ?>" class="page-title-action">
            <?php _e('הוסף ספק חדש', 'haruv-suppliers'); ?>
        </a>
        <hr class="wp-header-end">

        <form method="get" action="" class="haruv-suppliers-filters">
            <input type="hidden" name="page" value="haruv-suppliers-main">
            <input type="hidden" name="orderby" value="<?php echo esc_attr($orderby); ?>">
            <input type="hidden" name="order" value="<?php echo esc_attr($order); ?>">

            <div class="tablenav top">
                <div class="alignleft actions">
                    <select name="type">
                        <option value=""><?php _e('כל הסוגים', 'haruv-suppliers'); ?></option>
                        <?php foreach ($all_types as $type => $label): ?>
                            <option value="<?php echo esc_attr($type); ?>" <?php selected($type_filter, $type); ?>><?php echo esc_html($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <select name="status">
                        <option value=""><?php _e('כל הסטטוסים', 'haruv-suppliers'); ?></option>
                        <?php foreach ($status_labels as $k => $v): ?>
                            <option value="<?php echo esc_attr($k); ?>" <?php selected($status_filter, $k); ?>><?php echo esc_html($v); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <label class="haruv-date-label"><?php _e('נרשם מ-', 'haruv-suppliers'); ?>
                        <input type="date" name="date_from" value="<?php echo esc_attr($date_from); ?>">
                    </label>
                    <label class="haruv-date-label"><?php _e('עד', 'haruv-suppliers'); ?>
                        <input type="date" name="date_to" value="<?php echo esc_attr($date_to); ?>">
                    </label>
                    <select name="per_page">
                        <?php foreach (array(25, 50, 100, 200, 500) as $pp): ?>
                            <option value="<?php echo $pp; ?>" <?php selected($per_page, $pp); ?>><?php echo $pp; ?> <?php _e('פריטים', 'haruv-suppliers'); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" class="button"><?php _e('סנן', 'haruv-suppliers'); ?></button>
                    <?php if ($search || $type_filter || $status_filter || $date_from || $date_to): ?>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=haruv-suppliers-main')); ?>" class="button"><?php _e('נקה', 'haruv-suppliers'); ?></a>
                    <?php endif; ?>
                </div>

                <p class="search-box" style="margin:0;">
                    <input type="search" name="s" value="<?php echo esc_attr($search); ?>" placeholder="<?php esc_attr_e('חיפוש לפי שם / תוכן…', 'haruv-suppliers'); ?>">
                    <button type="submit" class="button"><?php _e('חפש', 'haruv-suppliers'); ?></button>
                </p>

                <div class="tablenav-pages haruv-count">
                    <span class="displaying-num"><?php printf(esc_html__('%s תוצאות', 'haruv-suppliers'), number_format_i18n($query->found_posts)); ?></span>
                </div>
            </div>
        </form>

        <?php if ($query->have_posts()): ?>
            <table class="wp-list-table widefat fixed striped haruv-suppliers-table">
                <thead>
                    <tr>
                        <?php haruv_sortable_th('id', __('ID', 'haruv-suppliers'), $orderby, $order, $sort_base_args, 'style="width:60px;"'); ?>
                        <?php haruv_sortable_th('title', __('שם', 'haruv-suppliers'), $orderby, $order, $sort_base_args); ?>
                        <?php haruv_sortable_th('type', __('סוג ספק', 'haruv-suppliers'), $orderby, $order, $sort_base_args, 'style="width:130px;"'); ?>
                        <th style="width:210px;"><?php _e('פרטי קשר', 'haruv-suppliers'); ?></th>
                        <th style="width:140px;"><?php _e('אזורים', 'haruv-suppliers'); ?></th>
                        <th style="width:100px;"><?php _e('סטטוס', 'haruv-suppliers'); ?></th>
                        <?php haruv_sortable_th('date', __('תאריך הרשמה', 'haruv-suppliers'), $orderby, $order, $sort_base_args, 'style="width:130px;"'); ?>
                        <?php haruv_sortable_th('modified', __('עודכן', 'haruv-suppliers'), $orderby, $order, $sort_base_args, 'style="width:130px;"'); ?>
                        <th style="width:90px;"><?php _e('פעולות', 'haruv-suppliers'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    while ($query->have_posts()):
                        $query->the_post();
                        $post_id   = get_the_ID();
                        $post_type = get_post_type();
                        $type_label = isset($all_types[$post_type]) ? $all_types[$post_type] : $post_type;

                        // Lean ACF reads — only the keys we render.
                        $email = get_field('email', $post_id);
                        if (!$email) {
                            $cp = get_field('contact_person', $post_id);
                            if (is_array($cp) && !empty($cp['email'])) { $email = $cp['email']; }
                        }
                        $phone = get_field('mobile', $post_id);
                        if (!$phone) { $phone = get_field('phone', $post_id); }
                        if (!$phone) {
                            if (!isset($cp)) { $cp = get_field('contact_person', $post_id); }
                            if (is_array($cp) && !empty($cp['phone'])) { $phone = $cp['phone']; }
                        }

                        $zones = get_field('zones', $post_id);
                        if (!is_array($zones)) { $zones = array(); }
                        if (!empty($zones)) {
                            $zones_text = in_array('all_israel', $zones, true)
                                ? __('כל הארץ', 'haruv-suppliers')
                                : sprintf(_n('אזור %d', '%d אזורים', count($zones), 'haruv-suppliers'), count($zones));
                        } else {
                            $zones_text = '—';
                        }

                        $status = get_post_status();
                        $status_label = isset($status_labels[$status]) ? $status_labels[$status] : $status;
                        $edit_link = get_edit_post_link($post_id);
                        ?>
                        <tr>
                            <td><strong><?php echo (int) $post_id; ?></strong></td>
                            <td>
                                <strong><a href="<?php echo esc_url($edit_link); ?>"><?php echo esc_html(get_the_title() ?: __('(ללא שם)', 'haruv-suppliers')); ?></a></strong>
                            </td>
                            <td><span class="haruv-type-badge type-<?php echo esc_attr($post_type); ?>"><?php echo esc_html($type_label); ?></span></td>
                            <td class="haruv-contact">
                                <?php if ($email): ?>
                                    <div><span class="dashicons dashicons-email"></span> <a href="mailto:<?php echo esc_attr($email); ?>"><?php echo esc_html($email); ?></a></div>
                                <?php endif; ?>
                                <?php if ($phone): ?>
                                    <div><span class="dashicons dashicons-phone"></span> <a href="tel:<?php echo esc_attr($phone); ?>"><?php echo esc_html($phone); ?></a></div>
                                <?php endif; ?>
                                <?php if (!$email && !$phone): ?>—<?php endif; ?>
                            </td>
                            <td><?php echo esc_html($zones_text); ?></td>
                            <td><span class="status-badge status-<?php echo esc_attr($status); ?>"><?php echo esc_html($status_label); ?></span></td>
                            <td><?php echo esc_html(get_the_date('d/m/Y')); ?><br><small><?php echo esc_html(get_the_date('H:i')); ?></small></td>
                            <td><?php echo esc_html(get_the_modified_date('d/m/Y')); ?><br><small><?php echo esc_html(get_the_modified_date('H:i')); ?></small></td>
                            <td><a href="<?php echo esc_url($edit_link); ?>" class="button button-small"><?php _e('ערוך', 'haruv-suppliers'); ?></a></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>

            <?php if ($query->max_num_pages > 1): ?>
                <div class="tablenav bottom">
                    <div class="tablenav-pages">
                        <?php
                        echo paginate_links(array(
                            'base'      => add_query_arg('paged', '%#%'),
                            'format'    => '',
                            'current'   => $paged,
                            'total'     => $query->max_num_pages,
                            'prev_text' => '‹',
                            'next_text' => '›',
                            'type'      => 'plain',
                            'add_args'  => array_merge($persist_args, array('orderby' => $orderby, 'order' => $order)),
                        ));
                        ?>
                    </div>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="notice notice-warning inline">
                <p>
                    <strong><?php _e('לא נמצאו תוצאות', 'haruv-suppliers'); ?></strong>
                    <?php if ($search || $type_filter || $status_filter || $date_from || $date_to): ?>
                        — <?php _e('נסה להרחיב את הסינון.', 'haruv-suppliers'); ?>
                    <?php endif; ?>
                </p>
            </div>
        <?php endif; ?>

        <?php wp_reset_postdata(); ?>
    </div>

    <style>
        .haruv-suppliers-filters .tablenav.top { display:flex; flex-wrap:wrap; gap:10px; align-items:center; height:auto; padding-top:6px; }
        .haruv-suppliers-filters .alignleft.actions { display:flex; gap:8px; flex-wrap:wrap; align-items:center; float:none; }
        .haruv-date-label { display:inline-flex; align-items:center; gap:4px; font-size:12px; color:#50575e; }
        .haruv-count { float:none; margin-inline-start:auto; }
        .haruv-suppliers-table { margin-top:14px; }
        .haruv-suppliers-table td { vertical-align:middle; }
        .haruv-contact { font-size:12px; line-height:1.6; }
        .haruv-contact .dashicons { font-size:14px; width:14px; height:14px; vertical-align:text-top; }
        .haruv-type-badge { display:inline-block; padding:3px 9px; border-radius:3px; font-size:12px; font-weight:500; background:#f0f0f1; color:#50575e; }
        .haruv-type-badge.type-lecture { background:#e7f5fe; color:#135e96; }
        .haruv-type-badge.type-venue { background:#fcf0f1; color:#b32d2e; }
        .haruv-type-badge.type-catering { background:#f0f6b6; color:#5b5e08; }
        .haruv-type-badge.type-hotel { background:#f0e6ff; color:#5b08a0; }
        .haruv-type-badge.type-photographer { background:#e5f5fa; color:#006ba1; }
        .haruv-type-badge.type-printing { background:#ffebe9; color:#8c1c13; }
        .haruv-type-badge.type-administration { background:#ededed; color:#2c3338; }
        .haruv-type-badge.type-gifts { background:#ffe9fd; color:#a01498; }
        .status-badge { display:inline-block; padding:2px 8px; border-radius:3px; font-size:11px; font-weight:600; }
        .status-badge.status-publish { background:#00a32a; color:#fff; }
        .status-badge.status-draft { background:#999; color:#fff; }
        .status-badge.status-pending { background:#f56e28; color:#fff; }
        .status-badge.status-private { background:#006ba1; color:#fff; }
    </style>
    <?php
}
