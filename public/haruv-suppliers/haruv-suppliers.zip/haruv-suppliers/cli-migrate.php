<?php
/**
 * WP-CLI Command for Supplier Migration
 * 
 * Usage:
 *   wp eval-file wp-content/plugins/haruv-suppliers/cli-migrate.php
 * 
 * @package HaruvSuppliers
 */

if (!defined('WP_CLI') && !defined('ABSPATH')) {
    exit('WP-CLI or WordPress environment required');
}

function haruv_cli_migrate_suppliers() {
    global $wpdb;
    
    WP_CLI::log('🔄 Starting supplier → administration migration...');
    WP_CLI::log('');
    
    // Get all supplier posts
    $supplier_posts = $wpdb->get_results(
        "SELECT ID, post_title, post_status, post_date 
         FROM {$wpdb->posts} 
         WHERE post_type = 'supplier'"
    );
    
    if (empty($supplier_posts)) {
        WP_CLI::success('✅ No suppliers to migrate! All clean.');
        return;
    }
    
    $total = count($supplier_posts);
    WP_CLI::log("Found {$total} suppliers to migrate");
    WP_CLI::log('');
    
    // Confirm
    WP_CLI::confirm("Are you sure you want to migrate {$total} suppliers to administration type?");
    
    // Start progress
    $progress = \WP_CLI\Utils\make_progress_bar('Migrating suppliers', $total);
    
    $migrated = 0;
    $errors = 0;
    
    foreach ($supplier_posts as $post) {
        $result = $wpdb->update(
            $wpdb->posts,
            array('post_type' => 'administration'),
            array('ID' => $post->ID),
            array('%s'),
            array('%d')
        );
        
        if ($result !== false) {
            $migrated++;
            clean_post_cache($post->ID);
        } else {
            $errors++;
            WP_CLI::warning("Failed to migrate post #{$post->ID}: {$post->post_title}");
        }
        
        $progress->tick();
    }
    
    $progress->finish();
    
    WP_CLI::log('');
    WP_CLI::log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    WP_CLI::success("✅ Migration complete!");
    WP_CLI::log("Migrated: {$migrated}");
    if ($errors > 0) {
        WP_CLI::log("Errors: {$errors}");
    }
    WP_CLI::log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    WP_CLI::log('');
    WP_CLI::log('Next steps:');
    WP_CLI::log('1. Check admin → Administration posts');
    WP_CLI::log('2. Verify forms are working');
    WP_CLI::log('3. Clear caches');
}

// Run migration
if (defined('WP_CLI')) {
    haruv_cli_migrate_suppliers();
} elseif (defined('ABSPATH')) {
    // If running via wp eval-file (not WP_CLI context)
    echo "Running migration...\n";
    haruv_cli_migrate_suppliers_direct();
}

function haruv_cli_migrate_suppliers_direct() {
    global $wpdb;
    
    echo "🔄 Starting supplier → administration migration...\n\n";
    
    $supplier_posts = $wpdb->get_results(
        "SELECT ID, post_title, post_status 
         FROM {$wpdb->posts} 
         WHERE post_type = 'supplier'"
    );
    
    if (empty($supplier_posts)) {
        echo "✅ No suppliers to migrate!\n";
        return;
    }
    
    $total = count($supplier_posts);
    echo "Found {$total} suppliers to migrate\n\n";
    
    $migrated = 0;
    foreach ($supplier_posts as $post) {
        $result = $wpdb->update(
            $wpdb->posts,
            array('post_type' => 'administration'),
            array('ID' => $post->ID),
            array('%s'),
            array('%d')
        );
        
        if ($result !== false) {
            $migrated++;
            echo "✓ Migrated #{$post->ID}: {$post->post_title}\n";
            clean_post_cache($post->ID);
        } else {
            echo "✗ Failed #{$post->ID}: {$post->post_title}\n";
        }
    }
    
    echo "\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
    echo "✅ Migration complete! Migrated: {$migrated}/{$total}\n";
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
}
