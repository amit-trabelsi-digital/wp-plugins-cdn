<?php
/**
 * Migration Helper for Haruv Suppliers
 *
 * This file helps migrate from theme-based suppliers to plugin-based
 * Run this once after plugin activation to clean up theme code
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Check for theme-based suppliers code
 */
function haruv_check_theme_suppliers_code() {
    $theme_suppliers_path = get_template_directory() . '/inc/suppliers';
    $issues = array();

    // Check if theme has suppliers folder
    if (file_exists($theme_suppliers_path)) {
        $issues[] = 'Theme contains suppliers folder: ' . $theme_suppliers_path;
    }

    // Check for specific files
    $files_to_check = array(
        'suppliers.php',
        'suppliers-api.php',
        'post-types.php',
        'taxonomies.php',
        'ajax-handlers.php',
        'suppliers-table.php'
    );

    foreach ($files_to_check as $file) {
        $file_path = $theme_suppliers_path . '/' . $file;
        if (file_exists($file_path)) {
            $issues[] = 'Theme file found: ' . $file_path;
        }
    }

    // Check for ACF fields folder
    $acf_path = $theme_suppliers_path . '/fields';
    if (file_exists($acf_path)) {
        $issues[] = 'Theme ACF fields folder found: ' . $acf_path;
    }

    return $issues;
}

/**
 * Generate migration report
 */
function haruv_generate_migration_report() {
    $issues = haruv_check_theme_suppliers_code();
    $report = array(
        'timestamp' => current_time('Y-m-d H:i:s'),
        'plugin_active' => is_plugin_active('haruv-suppliers/haruv-suppliers.php'),
        'theme_has_code' => !empty($issues),
        'issues' => $issues,
        'recommendations' => array()
    );

    if (!empty($issues)) {
        $report['recommendations'][] = 'Backup your site before proceeding';
        $report['recommendations'][] = 'Test all supplier functionality after migration';
        $report['recommendations'][] = 'Remove theme suppliers code after confirming everything works';
        $report['recommendations'][] = 'Check that all ACF fields are properly migrated';
        $report['recommendations'][] = 'Verify REST API endpoints are working';
    } else {
        $report['recommendations'][] = 'No theme code conflicts detected - plugin ready to use!';
    }

    return $report;
}

/**
 * Display migration status in admin
 */
function haruv_display_migration_status() {
    if (!current_user_can('manage_options')) {
        return;
    }

    $report = haruv_generate_migration_report();

    // Check for conflicts with theme code
    if (defined('HARUV_SUPPLIERS_THEME_ACTIVE')) {
        echo '<div class="notice notice-info">';
        echo '<h3>Haruv Suppliers - Theme Code Active</h3>';
        echo '<p>The plugin detected that theme-based supplier code is currently active. The plugin is running in compatibility mode to prevent conflicts.</p>';
        echo '<p><strong>API Endpoints:</strong> Using theme endpoints for compatibility</p>';
        echo '<p><strong>Custom Post Types:</strong> Using theme CPTs</p>';
        echo '<p><strong>Taxonomies:</strong> Using theme taxonomies</p>';
        echo '</div>';
        return;
    }

    if ($report['theme_has_code']) {
        echo '<div class="notice notice-warning is-dismissible">';
        echo '<h3>Haruv Suppliers - Migration Required</h3>';
        echo '<p>The plugin detected existing suppliers code in your theme. This may cause conflicts.</p>';

        if (!empty($report['issues'])) {
            echo '<h4>Issues Found:</h4>';
            echo '<ul>';
            foreach ($report['issues'] as $issue) {
                echo '<li>' . esc_html($issue) . '</li>';
            }
            echo '</ul>';
        }

        echo '<h4>Recommendations:</h4>';
        echo '<ul>';
        foreach ($report['recommendations'] as $rec) {
            echo '<li>' . esc_html($rec) . '</li>';
        }
        echo '</ul>';

        echo '<p><strong>After testing, you can safely remove the theme suppliers code.</strong></p>';
        echo '</div>';
    } else {
        echo '<div class="notice notice-success is-dismissible">';
        echo '<h3>Haruv Suppliers - Migration Complete</h3>';
        echo '<p>No conflicts detected. The plugin is ready to use!</p>';
        echo '</div>';
    }
}
add_action('admin_notices', 'haruv_display_migration_status');

/**
 * Add migration helper to tools menu
 */
function haruv_add_migration_page() {
    add_submenu_page(
        'tools.php',
        'Haruv Suppliers Migration',
        'Suppliers Migration',
        'manage_options',
        'haruv-migration',
        'haruv_migration_page'
    );
}
add_action('admin_menu', 'haruv_add_migration_page');

/**
 * Migration helper page
 */
function haruv_migration_page() {
    if (!current_user_can('manage_options')) {
        wp_die('Insufficient permissions');
    }

    $report = haruv_generate_migration_report();

    ?>
    <div class="wrap">
        <h1>Haruv Suppliers Migration Helper</h1>

        <div class="haruv-migration-report">
            <h2>Migration Report</h2>
            <table class="widefat">
                <tbody>
                    <tr>
                        <td><strong>Plugin Active:</strong></td>
                        <td><?php echo $report['plugin_active'] ? '✅ Yes' : '❌ No'; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Theme Code Found:</strong></td>
                        <td><?php echo $report['theme_has_code'] ? '⚠️ Yes' : '✅ No'; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Timestamp:</strong></td>
                        <td><?php echo esc_html($report['timestamp']); ?></td>
                    </tr>
                </tbody>
            </table>

            <?php if (!empty($report['issues'])): ?>
                <h3>Issues Found</h3>
                <ul class="haruv-issues-list">
                    <?php foreach ($report['issues'] as $issue): ?>
                        <li><?php echo esc_html($issue); ?></li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>

            <h3>Recommendations</h3>
            <ul class="haruv-recommendations-list">
                <?php foreach ($report['recommendations'] as $rec): ?>
                    <li><?php echo esc_html($rec); ?></li>
                <?php endforeach; ?>
            </ul>

            <div class="haruv-migration-actions">
                <h3>Next Steps</h3>
                <ol>
                    <li>Test all supplier functionality (CPTs, ACF fields, REST API)</li>
                    <li>Verify no errors in debug logs</li>
                    <li>Remove theme suppliers code (see instructions below)</li>
                    <li>Run this migration helper again to confirm clean state</li>
                </ol>
            </div>

            <div class="haruv-cleanup-instructions">
                <h3>Cleanup Instructions</h3>
                <p><strong>To remove theme suppliers code:</strong></p>
                <ol>
                    <li>Navigate to your theme folder: <code><?php echo esc_html(get_template_directory()); ?></code></li>
                    <li>Delete the entire <code>inc/suppliers/</code> folder</li>
                    <li>Remove suppliers-related code from <code>functions.php</code> if any</li>
                    <li>Clear any caching plugins</li>
                    <li>Refresh permalinks</li>
                </ol>

                <div class="haruv-warning">
                    <strong>⚠️ Important:</strong> Backup your site before removing theme code!
                </div>
            </div>
        </div>

        <style>
            .haruv-migration-report { margin-top: 20px; }
            .haruv-issues-list { background: #fff3cd; padding: 15px; border-radius: 5px; }
            .haruv-recommendations-list { background: #d1ecf1; padding: 15px; border-radius: 5px; }
            .haruv-migration-actions { background: #d4edda; padding: 15px; border-radius: 5px; margin: 20px 0; }
            .haruv-cleanup-instructions { background: #f8f9fa; padding: 15px; border-radius: 5px; border-left: 4px solid #007cba; }
            .haruv-warning { background: #f8d7da; color: #721c24; padding: 10px; border-radius: 3px; margin-top: 10px; }
            .haruv-cleanup-instructions code { background: #e9ecef; padding: 2px 4px; border-radius: 3px; }
        </style>
    </div>
    <?php
}

// Only load this file if we're in admin and need migration help
if (is_admin() && isset($_GET['page']) && $_GET['page'] === 'haruv-migration') {
    // File is loaded when needed
}
