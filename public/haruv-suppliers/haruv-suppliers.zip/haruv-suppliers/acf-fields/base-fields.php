<?php
/**
 * ACF Fields for Haruv Suppliers
 * 
 * Note: Fields are now managed via JSON files in this directory.
 * This file is kept to maintain directory structure but no longer registers fields via PHP.
 *
 * @package HaruvSuppliers
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Fields are now loaded from JSON files in the 'acf-fields' directory.
// See: group_haruv_supplier_base.json, group_haruv_venue_details.json, group_haruv_catering_details.json
