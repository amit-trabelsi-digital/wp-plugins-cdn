<?php
/**
 * Plugin Name: Haruv Suppliers Management
 * Plugin URI: https://github.com/amit-trabelsi-digital/haruv-suppliers-private
 * Description: Comprehensive suppliers management system for Haruv platform. Handles venues, catering, hotels, printing, photographers, and administration services with REST API and ACF integration.
 * Version:           1.6.9
 * Author: Amit Trabelsi
 * Author URI: https://amit-trabelsi.co.il
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: haruv-suppliers-plugin
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 * Network: false
 * Update URI: https://updates.amiteam.io/haruv-suppliers/plugin-info.json
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('HARUV_SUPPLIERS_VERSION', '1.6.9');
define('HARUV_SUPPLIERS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('HARUV_SUPPLIERS_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include ACF fields JSON directory for auto-sync
define('HARUV_SUPPLIERS_ACF_JSON_DIR', HARUV_SUPPLIERS_PLUGIN_DIR . 'acf-fields/');

/**
 * Main Plugin Class
 */
class HaruvSuppliers {

    /**
     * Constructor - Initialize the plugin
     */
    public function __construct() {
        add_action('plugins_loaded', array($this, 'init'), 10);
        add_action('init', array($this, 'load_textdomain'));
    }

    /**
     * Initialize the plugin
     */
    public function init() {
        // Check for ACF dependency
        if (!$this->check_dependencies()) {
            return;
        }

        // Textdomain is now loaded in load_textdomain() method on init hook

        // Include all plugin files
        $this->include_files();

        // Update checker — pulls updates from the AT private CDN (updates.amiteam.io).
        // Replaces the legacy S3-based update-checker.php.
        require_once HARUV_SUPPLIERS_PLUGIN_DIR . 'includes/class-private-cdn-updater.php';
        new Haruv_Suppliers_Private_CDN_Updater(
            'haruv-suppliers',
            'haruv-suppliers/haruv-suppliers.php',
            HARUV_SUPPLIERS_VERSION,
            'https://updates.amiteam.io/haruv-suppliers/plugin-info.json'
        );

        // Include migration helper (admin only)
        if (is_admin()) {
            require_once HARUV_SUPPLIERS_PLUGIN_DIR . 'migration-helper.php';
            require_once HARUV_SUPPLIERS_PLUGIN_DIR . 'includes/migrate-supplier-to-administration.php';
        }

        // Initialize ACF JSON sync
        $this->setup_acf_sync();

        // Hook into WordPress
        $this->setup_hooks();
        
        // Cleanup duplicates (can be removed after running once)
        add_action('admin_init', array($this, 'cleanup_duplicate_field_groups'));
    }

    /**
     * Cleanup duplicate field groups that remain in DB but deleted from JSON
     */
    public function cleanup_duplicate_field_groups() {
        if (!function_exists('acf_delete_field_group')) {
            return;
        }

        // Array of keys to delete
        $keys_to_delete = array(
            'group_haruv_supplier_base',
            'group_haruv_venue_details',
            'group_haruv_catering_details'
        );

        foreach ($keys_to_delete as $key) {
            // Get field group by key
            $group = acf_get_field_group($key);
            
            // If group exists, delete it
            if ($group) {
                acf_delete_field_group($group['ID']);
            }
        }
    }

    /**
     * Load plugin textdomain
     */
    public function load_textdomain() {
        load_plugin_textdomain('haruv-suppliers-plugin', false, dirname(plugin_basename(__FILE__)) . '/languages/');
    }

    /**
     * Check for required dependencies
     */
    private function check_dependencies() {
        if (!class_exists('ACF')) {
            add_action('admin_notices', array($this, 'acf_missing_notice'));
            return false;
        }
        return true;
    }

    /**
     * Include all plugin files
     */
    private function include_files() {
        // Core files
        require_once HARUV_SUPPLIERS_PLUGIN_DIR . 'includes/cpt-registration.php';
        require_once HARUV_SUPPLIERS_PLUGIN_DIR . 'includes/additional-cpt-registration.php';
        require_once HARUV_SUPPLIERS_PLUGIN_DIR . 'includes/taxonomies.php';
        require_once HARUV_SUPPLIERS_PLUGIN_DIR . 'includes/rest-api.php';
        require_once HARUV_SUPPLIERS_PLUGIN_DIR . 'includes/ajax-handlers.php';
        require_once HARUV_SUPPLIERS_PLUGIN_DIR . 'includes/security.php';
        require_once HARUV_SUPPLIERS_PLUGIN_DIR . 'includes/settings.php';
        require_once HARUV_SUPPLIERS_PLUGIN_DIR . 'includes/email-notifications.php';
        require_once HARUV_SUPPLIERS_PLUGIN_DIR . 'includes/registration-handler.php';
        require_once HARUV_SUPPLIERS_PLUGIN_DIR . 'includes/rate-audit.php';
        require_once HARUV_SUPPLIERS_PLUGIN_DIR . 'includes/api-documentation.php';
        require_once HARUV_SUPPLIERS_PLUGIN_DIR . 'includes/privacy-consent.php';
        require_once HARUV_SUPPLIERS_PLUGIN_DIR . 'includes/unified-suppliers-admin.php';
        require_once HARUV_SUPPLIERS_PLUGIN_DIR . 'includes/supplier-form-ux.php';

        // Consent system files
        require_once HARUV_SUPPLIERS_PLUGIN_DIR . 'includes/consent-tokens.php';
        require_once HARUV_SUPPLIERS_PLUGIN_DIR . 'includes/consent-emails.php';
        require_once HARUV_SUPPLIERS_PLUGIN_DIR . 'includes/consent-admin.php';
        require_once HARUV_SUPPLIERS_PLUGIN_DIR . 'includes/consent-form-handler.php';

        // ACF field groups
        $acf_files = glob(HARUV_SUPPLIERS_PLUGIN_DIR . 'acf-fields/*.php');
        if ($acf_files) {
            foreach ($acf_files as $acf_file) {
                require_once $acf_file;
            }
        }
    }

    /**
     * Setup ACF JSON sync
     */
    private function setup_acf_sync() {
        add_filter('acf/settings/save_json', array($this, 'acf_json_save_point'));
        add_filter('acf/settings/load_json', array($this, 'acf_json_load_point'));
    }

    /**
     * ACF JSON save location
     */
    public function acf_json_save_point($path) {
        $path = HARUV_SUPPLIERS_ACF_JSON_DIR;
        return $path;
    }

    /**
     * ACF JSON load locations
     */
    public function acf_json_load_point($paths) {
        unset($paths[0]); // Remove original path
        $paths[] = HARUV_SUPPLIERS_ACF_JSON_DIR;
        return $paths;
    }

    /**
     * Setup WordPress hooks
     */
    private function setup_hooks() {
        // Activation/Deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));

        // Admin menu
        add_action('admin_menu', array($this, 'add_admin_menu'));

        // Enqueue scripts and styles
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        
        // Frontend styles
        add_action('wp_head', array($this, 'frontend_styles'));
    }

    /**
     * Add frontend styles
     */
    public function frontend_styles() {
        ?>
        <style>
            .haruv-internal-field {
                display: none !important;
            }
        </style>
        <?php
    }

    /**
     * Plugin activation
     */
    public function activate() {
        // Flush rewrite rules
        flush_rewrite_rules();

        // Create ACF JSON directory if it doesn't exist
        if (!file_exists(HARUV_SUPPLIERS_ACF_JSON_DIR)) {
            wp_mkdir_p(HARUV_SUPPLIERS_ACF_JSON_DIR);
        }
    }

    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Flush rewrite rules
        flush_rewrite_rules();
    }

    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        // Main "ניהול ספקים" menu — its landing page IS the "כל הספקים" list.
        $unified_cb = function_exists('haruv_unified_suppliers_page') ? 'haruv_unified_suppliers_page' : array($this, 'admin_page');
        add_menu_page(
            __('ניהול ספקים', 'haruv-suppliers'),
            __('ניהול ספקים', 'haruv-suppliers'),
            'manage_options',
            'haruv-suppliers-main',
            $unified_cb,
            'dashicons-businessman',
            5
        );

        // First submenu = "כל הספקים" (same slug as parent → replaces the duplicate first item).
        add_submenu_page(
            'haruv-suppliers-main',
            __('כל הספקים', 'haruv-suppliers'),
            __('כל הספקים', 'haruv-suppliers'),
            'manage_options',
            'haruv-suppliers-main',
            $unified_cb
        );

        // Suppliers (כללי)
        if (post_type_exists('supplier')) {
            add_submenu_page(
                'haruv-suppliers-main',
                __('ספקים כללי', 'haruv-suppliers'),
                __('ספקים כללי', 'haruv-suppliers'),
                'manage_options',
                'edit.php?post_type=supplier'
            );
        }
        
        // Venues (אולמות)
        if (post_type_exists('venue')) {
            add_submenu_page(
                'haruv-suppliers-main',
                __('אולמות', 'haruv-suppliers'),
                __('אולמות', 'haruv-suppliers'),
                'manage_options',
                'edit.php?post_type=venue'
            );
        }
        
        // Catering (הסעדה)
        if (post_type_exists('catering')) {
            add_submenu_page(
                'haruv-suppliers-main',
                __('הסעדה', 'haruv-suppliers'),
                __('הסעדה', 'haruv-suppliers'),
                'manage_options',
                'edit.php?post_type=catering'
            );
        }
        
        // Photographers (צלמים)
        if (post_type_exists('photographer')) {
            add_submenu_page(
                'haruv-suppliers-main',
                __('צלמים', 'haruv-suppliers'),
                __('צלמים', 'haruv-suppliers'),
                'manage_options',
                'edit.php?post_type=photographer'
            );
        }
        
        // Printing (בתי דפוס)
        if (post_type_exists('printing')) {
            add_submenu_page(
                'haruv-suppliers-main',
                __('בתי דפוס', 'haruv-suppliers'),
                __('בתי דפוס', 'haruv-suppliers'),
                'manage_options',
                'edit.php?post_type=printing'
            );
        }
        
        // Hotels (מלונות)
        if (post_type_exists('hotel')) {
            add_submenu_page(
                'haruv-suppliers-main',
                __('מלונות', 'haruv-suppliers'),
                __('מלונות', 'haruv-suppliers'),
                'manage_options',
                'edit.php?post_type=hotel'
            );
        }
        
        // Gifts (מתנות)
        if (post_type_exists('gifts')) {
            add_submenu_page(
                'haruv-suppliers-main',
                __('מתנות', 'haruv-suppliers'),
                __('מתנות', 'haruv-suppliers'),
                'manage_options',
                'edit.php?post_type=gifts'
            );
        }
        
        // Administration (אדמיניסטרציה)
        if (post_type_exists('administration')) {
            add_submenu_page(
                'haruv-suppliers-main',
                __('אדמיניסטרציה', 'haruv-suppliers'),
                __('אדמיניסטרציה', 'haruv-suppliers'),
                'manage_options',
                'edit.php?post_type=administration'
            );
        }

        // Workshops (סדנאות)
        if (post_type_exists('workshop')) {
            add_submenu_page(
                'haruv-suppliers-main',
                __('סדנאות', 'haruv-suppliers'),
                __('סדנאות', 'haruv-suppliers'),
                'manage_options',
                'edit.php?post_type=workshop'
            );
        }

        // Consent requests (בקשת הסכמה למדיניות)
        if (function_exists('haruv_consent_requests_page')) {
            add_submenu_page(
                'haruv-suppliers-main',
                __('בקשת הסכמה למדיניות', 'haruv-suppliers'),
                __('בקשת הסכמה למדיניות', 'haruv-suppliers'),
                'manage_options',
                'haruv-consent-requests',
                'haruv_consent_requests_page'
            );
        }
        
        // Rate/degree audit (פערי עלות/תואר)
        if (function_exists('haruv_rate_audit_page')) {
            add_submenu_page(
                'haruv-suppliers-main',
                __('פערי עלות/תואר', 'haruv-suppliers'),
                __('פערי עלות/תואר', 'haruv-suppliers'),
                'manage_options',
                'haruv-rate-audit',
                'haruv_rate_audit_page'
            );
        }

        // Developers (תיעוד API + כלי המרה) — combined in one tabbed screen.
        if (function_exists('haruv_developers_page')) {
            add_submenu_page(
                'haruv-suppliers-main',
                __('מפתחים', 'haruv-suppliers-plugin'),
                __('מפתחים', 'haruv-suppliers-plugin'),
                'manage_options',
                'haruv-developers',
                'haruv_developers_page'
            );
        }
    }

    /**
     * Download Postman Collection
     */
    public function download_postman_collection() {
        $collection_file = HARUV_SUPPLIERS_PLUGIN_DIR . 'postman/haruv-suppliers-api.postman_collection.json';

        if (file_exists($collection_file)) {
            header('Content-Type: application/json');
            header('Content-Disposition: attachment; filename="haruv-suppliers-api.postman_collection.json"');
            header('Content-Length: ' . filesize($collection_file));
            readfile($collection_file);
            exit;
        } else {
            wp_die(__('קובץ הקולקשן לא נמצא.', 'haruv-suppliers'));
        }
    }

    /**
     * Admin page callback
     */
    public function admin_page() {
        ?>
        <div class="wrap">
            <h1><?php _e('מערכת ניהול ספקים - חרוב', 'haruv-suppliers'); ?></h1>
            <p><?php _e('נהל את כל סוגי הספקים: אולמות, הסעדה, מלונות, דפוס, צלמים ושירותי אדמיניסטרציה.', 'haruv-suppliers'); ?></p>

            <div class="haruv-suppliers-dashboard">
                <div class="supplier-type-card">
                    <h3><?php _e('אולמות', 'haruv-suppliers'); ?></h3>
                    <p><?php _e('נהל אולמות אירועים ומיקומים', 'haruv-suppliers'); ?></p>
                    <a href="<?php echo admin_url('edit.php?post_type=venue'); ?>" class="button"><?php _e('נהל אולמות', 'haruv-suppliers'); ?></a>
                </div>

                <div class="supplier-type-card">
                    <h3><?php _e('הסעדה', 'haruv-suppliers'); ?></h3>
                    <p><?php _e('נהל שירותי הסעדה וספקים', 'haruv-suppliers'); ?></p>
                    <a href="<?php echo admin_url('edit.php?post_type=catering'); ?>" class="button"><?php _e('נהל הסעדה', 'haruv-suppliers'); ?></a>
                </div>

                <div class="supplier-type-card">
                    <h3><?php _e('מלונות', 'haruv-suppliers'); ?></h3>
                    <p><?php _e('נהל לינה בבתי מלון', 'haruv-suppliers'); ?></p>
                    <a href="<?php echo admin_url('edit.php?post_type=hotel'); ?>" class="button"><?php _e('נהל מלונות', 'haruv-suppliers'); ?></a>
                </div>

                <div class="supplier-type-card">
                    <h3><?php _e('בתי דפוס', 'haruv-suppliers'); ?></h3>
                    <p><?php _e('נהל שירותי דפוס', 'haruv-suppliers'); ?></p>
                    <a href="<?php echo admin_url('edit.php?post_type=printing'); ?>" class="button"><?php _e('נהל בתי דפוס', 'haruv-suppliers'); ?></a>
                </div>

                <div class="supplier-type-card">
                    <h3><?php _e('צלמים', 'haruv-suppliers'); ?></h3>
                    <p><?php _e('נהל שירותי צילום', 'haruv-suppliers'); ?></p>
                    <a href="<?php echo admin_url('edit.php?post_type=photographer'); ?>" class="button"><?php _e('נהל צלמים', 'haruv-suppliers'); ?></a>
                </div>

                <div class="supplier-type-card">
                    <h3><?php _e('אדמיניסטרציה', 'haruv-suppliers'); ?></h3>
                    <p><?php _e('נהל שירותי אדמיניסטרציה', 'haruv-suppliers'); ?></p>
                    <a href="<?php echo admin_url('edit.php?post_type=administration'); ?>" class="button"><?php _e('נהל אדמיניסטרציה', 'haruv-suppliers'); ?></a>
                </div>

                <div class="supplier-type-card">
                    <h3><?php _e('סדנאות', 'haruv-suppliers'); ?></h3>
                    <p><?php _e('נהל סדנאות', 'haruv-suppliers'); ?></p>
                    <a href="<?php echo admin_url('edit.php?post_type=workshop'); ?>" class="button"><?php _e('נהל סדנאות', 'haruv-suppliers'); ?></a>
                </div>
            </div>

            <style>
                .haruv-suppliers-dashboard {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                    gap: 20px;
                    margin-top: 20px;
                }
                .supplier-type-card {
                    background: #fff;
                    border: 1px solid #ccc;
                    border-radius: 5px;
                    padding: 20px;
                    text-align: center;
                }
                .supplier-type-card h3 {
                    margin-top: 0;
                    color: #23282d;
                }
                .supplier-type-card p {
                    color: #666;
                    margin-bottom: 15px;
                }
            </style>
        </div>
        <?php
    }

    /**
     * Enqueue admin scripts and styles
     */
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'haruv-suppliers') !== false) {
            wp_enqueue_style('haruv-suppliers-admin', HARUV_SUPPLIERS_PLUGIN_URL . 'assets/css/admin.css', array(), HARUV_SUPPLIERS_VERSION);
            wp_enqueue_script('haruv-suppliers-admin', HARUV_SUPPLIERS_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), HARUV_SUPPLIERS_VERSION, true);
        }
    }

    /**
     * ACF missing notice
     */
    public function acf_missing_notice() {
        ?>
        <div class="error">
            <p><?php _e('Haruv Suppliers requires Advanced Custom Fields plugin to be installed and activated.', 'haruv-suppliers'); ?></p>
        </div>
        <?php
    }
}

// Initialize the plugin
new HaruvSuppliers();
