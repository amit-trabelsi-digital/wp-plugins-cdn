<?php
/**
 * Plugin Name:       Haruv Content Importer
 * Plugin URI:        https://amit-trabelsi.co.il
 * Description:       ייבוא תוכן מהאתר הישן (haruv.org.il) אל האתר החדש מתוך קובץ JSON עצמאי — עמודים, מאמרים, צוות, אירועים ועוד — כטיוטות לבדיקה, כולל שדות ACF, מדיה וטקסונומיות. ללא תלות באתר הישן.
 * Version:           0.4.1
 * Author:            Amit Trabelsi
 * Author URI:        https://amit-trabelsi.co.il
 * License:           GPL-2.0-or-later
 * Text Domain:       haruv-content-importer
 * Domain Path:       /languages
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Update URI:        https://updates.amiteam.io/haruv-content-importer/plugin-info.json
 *
 * @package HaruvContentImporter
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( defined( 'HCI_VERSION' ) ) {
	return; // conflict guard
}

define( 'HCI_VERSION', '0.4.1' );
define( 'HCI_FILE', __FILE__ );
define( 'HCI_PATH', plugin_dir_path( __FILE__ ) );
define( 'HCI_URL', plugin_dir_url( __FILE__ ) );
define( 'HCI_CAP', 'manage_options' );
define( 'HCI_NONCE', 'hci_nonce' );

require_once HCI_PATH . 'includes/class-hci-elementor.php';
require_once HCI_PATH . 'includes/class-hci-importer.php';
require_once HCI_PATH . 'includes/class-hci-admin.php';
require_once HCI_PATH . 'includes/class-hci-ajax.php';

add_action(
	'plugins_loaded',
	static function () {
		load_plugin_textdomain( 'haruv-content-importer', false, dirname( plugin_basename( HCI_FILE ) ) . '/languages' );
		( new HCI_Admin() )->hooks();
		( new HCI_Ajax() )->hooks();
	}
);

/**
 * Register this plugin in AT Agency Manager's admin-bar "Versions" widget.
 * Uses its public filter so the sites-manager plugin itself stays untouched;
 * a no-op when that plugin is not installed.
 */
add_filter(
	'at_agency_manager_version_items',
	static function ( $items ) {
		$items['haruv-content-importer'] = array(
			'id'          => 'haruv-content-importer',
			'name'        => __( 'Haruv Content Importer', 'haruv-content-importer' ),
			'version'     => HCI_VERSION,
			'color'       => 'green',
			'description' => __( 'ייבוא תוכן מהאתר הישן', 'haruv-content-importer' ),
		);
		return $items;
	}
);

/** Bundled snapshots shipped with the plugin (read from data/index.json — cheap). */
function hci_bundled_snapshots() {
	$manifest = HCI_PATH . 'data/index.json';
	if ( ! is_readable( $manifest ) ) {
		return array();
	}
	$data = json_decode( file_get_contents( $manifest ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	if ( ! is_array( $data ) || empty( $data['snapshots'] ) ) {
		return array();
	}
	$out = array();
	foreach ( $data['snapshots'] as $s ) {
		$file = isset( $s['file'] ) ? basename( $s['file'] ) : '';
		if ( '' === $file || ! is_readable( HCI_PATH . 'data/' . $file ) ) {
			continue;
		}
		$out[] = array(
			'file'    => $file,
			'type'    => isset( $s['type'] ) ? $s['type'] : '',
			'label'   => isset( $s['label'] ) ? $s['label'] : $file,
			'suggest' => isset( $s['suggest'] ) ? $s['suggest'] : '',
			'count'   => isset( $s['count'] ) ? (int) $s['count'] : 0,
		);
	}
	return $out;
}

/** Resolve a bundled snapshot filename to a safe absolute path (or '' if invalid). */
function hci_bundled_path( $file ) {
	$file = basename( (string) $file ); // strip any path traversal
	if ( ! preg_match( '/^[A-Za-z0-9._-]+\.json$/', $file ) || 'index.json' === $file ) {
		return '';
	}
	$path = HCI_PATH . 'data/' . $file;
	return is_readable( $path ) ? $path : '';
}

/** Storage dir for uploaded JSON snapshots (inside uploads, protected). */
function hci_storage_dir() {
	$up  = wp_upload_dir();
	$dir = trailingslashit( $up['basedir'] ) . 'haruv-content-importer';
	if ( ! is_dir( $dir ) ) {
		wp_mkdir_p( $dir );
		// Block direct web access to uploaded snapshots.
		@file_put_contents( $dir . '/.htaccess', "Require all denied\n" );
		@file_put_contents( $dir . '/index.php', "<?php // Silence is golden.\n" );
	}
	return $dir;
}
