/* global HCI, jQuery */
( function ( $ ) {
	'use strict';

	var items = [];

	function esc( s ) {
		return $( '<div/>' ).text( s == null ? '' : String( s ) ).html();
	}

	function suggestFor( srcType ) {
		var pref = { 'article': 'post', 'conf-events': 'product', 'inter-activ': 'product', 'team': 'team_member', 'research-info': 'research' };
		return pref[ srcType ] || srcType;
	}

	function fillTypes( target ) {
		var $s = $( '#hci-map-to' ).empty();
		( HCI.types || [] ).forEach( function ( t ) {
			$s.append( $( '<option/>' ).val( t.name ).text( t.label ) );
		} );
		if ( target && $s.find( 'option[value="' + target + '"]' ).length ) {
			$s.val( target );
		}
	}

	function onLoaded( resp, target ) {
		items = resp.data.items || [];
		fillTypes( target || suggestFor( resp.data.source_type ) );
		var isEvent = resp.data.source_type === 'conf-events' || resp.data.source_type === 'inter-activ';
		$( '#hci-as-event' ).prop( 'checked', isEvent );
		renderRows();
		$( '#hci-controls, #hci-table' ).removeClass( 'hci-hidden' );
		$( '#hci-load-status' ).text( '✓ ' + resp.data.count + ' פריטים' );
	}

	// Populate the bundled-snapshot selector.
	( function () {
		var b = HCI.bundled || [];
		if ( ! b.length ) {
			$( '#hci-bundled-row' ).hide();
			return;
		}
		var $s = $( '#hci-bundled' ).empty();
		b.forEach( function ( s ) {
			$s.append( $( '<option/>' ).val( s.file ).attr( 'data-suggest', s.suggest || '' ).text( s.label + ' (' + s.count + ')' ) );
		} );
	} )();

	$( '#hci-load-bundled' ).on( 'click', function ( e ) {
		e.preventDefault();
		var $opt = $( '#hci-bundled option:selected' );
		if ( ! $opt.val() ) {
			return;
		}
		$( '#hci-load-status' ).text( HCI.i18n.loading );
		$.post( HCI.ajax, { action: 'hci_load_bundled', nonce: HCI.nonce, file: $opt.val() } )
			.done( function ( resp ) {
				if ( ! resp || ! resp.success ) {
					$( '#hci-load-status' ).text( ( resp && resp.data && resp.data.message ) || 'Error' );
					return;
				}
				onLoaded( resp, $opt.attr( 'data-suggest' ) );
			} )
			.fail( function () {
				$( '#hci-load-status' ).text( 'שגיאת רשת' );
			} );
	} );

	// What the imported body will be built from, shown before importing.
	function contentCell( it ) {
		if ( it.content === 'elementor' ) {
			return '<span class="hci-badge hci-badge-elem">Elementor → בלוקים (' + it.widgets + ')</span>';
		}
		if ( it.content === 'html' ) {
			return '<span class="hci-badge">HTML</span>';
		}
		return '<span class="hci-badge hci-badge-empty">ריק</span>';
	}

	function renderRows() {
		var $tb = $( '#hci-tbody' ).empty();
		items.forEach( function ( it ) {
			var $tr = $(
				'<tr data-idx="' + it.idx + '">' +
				'<td class="check-column"><input type="checkbox" class="hci-cb" /></td>' +
				'<td class="hci-title">' + esc( it.title ) + '</td>' +
				'<td>' + esc( it.type ) + '</td>' +
				'<td>' + contentCell( it ) + '</td>' +
				'<td>' + ( it.acf ? it.acf : '–' ) + '</td>' +
				'<td class="hci-terms">' + esc( it.terms ) + '</td>' +
				'<td class="hci-result"></td>' +
				'</tr>'
			);
			$tb.append( $tr );
		} );
	}

	function selectedRows() {
		return $( '#hci-tbody tr' ).filter( function () {
			return $( this ).find( '.hci-cb' ).prop( 'checked' );
		} );
	}

	// --- Load / preview ---
	$( '#hci-load' ).on( 'click', function ( e ) {
		e.preventDefault();
		var f = $( '#hci-file' )[ 0 ].files[ 0 ];
		if ( ! f ) {
			$( '#hci-load-status' ).text( HCI.i18n.noFile );
			return;
		}
		var fd = new FormData();
		fd.append( 'action', 'hci_load' );
		fd.append( 'nonce', HCI.nonce );
		fd.append( 'file', f );
		$( '#hci-load-status' ).text( HCI.i18n.loading );
		$.ajax( { url: HCI.ajax, method: 'POST', data: fd, processData: false, contentType: false } )
			.done( function ( resp ) {
				if ( ! resp || ! resp.success ) {
					$( '#hci-load-status' ).text( ( resp && resp.data && resp.data.message ) || 'Error' );
					return;
				}
				onLoaded( resp );
			} )
			.fail( function () {
				$( '#hci-load-status' ).text( 'שגיאת רשת' );
			} );
	} );

	$( '#hci-check-all' ).on( 'change', function () {
		$( '.hci-cb' ).prop( 'checked', $( this ).prop( 'checked' ) );
	} );
	$( '#hci-select-all' ).on( 'click', function ( e ) {
		e.preventDefault();
		$( '.hci-cb, #hci-check-all' ).prop( 'checked', true );
	} );

	// --- Import (batched) ---
	$( '#hci-import' ).on( 'click', function ( e ) {
		e.preventDefault();
		var $rows = selectedRows();
		if ( ! $rows.length ) {
			$( '#hci-import-status' ).text( HCI.i18n.noneSel );
			return;
		}
		if ( ! window.confirm( HCI.i18n.confirm ) ) {
			return;
		}
		var idxs = $rows.map( function () { return parseInt( $( this ).data( 'idx' ), 10 ); } ).get();
		var mapTo = $( '#hci-map-to' ).val();
		var withMedia = $( '#hci-with-media' ).prop( 'checked' );
		var withTerms = $( '#hci-with-terms' ).prop( 'checked' );
		var asEvent = $( '#hci-as-event' ).prop( 'checked' );
		var convertElementor = $( '#hci-convert-elementor' ).prop( 'checked' );
		var cleanStyles = $( '#hci-clean-styles' ).prop( 'checked' );
		var contentMedia = $( '#hci-content-media' ).prop( 'checked' );
		var openAccess = $( '#hci-open-access' ).prop( 'checked' );
		// Sideloading body media is slow — smaller batches keep each request well
		// inside PHP's max_execution_time.
		var total = idxs.length, done = 0, batch = contentMedia ? 2 : 4;

		$( '#hci-progress' ).removeClass( 'hci-hidden' );
		$( '#hci-import' ).prop( 'disabled', true );
		$( '#hci-import-status' ).text( HCI.i18n.importing );

		function paint( r ) {
			var $cell = $( '#hci-tbody tr[data-idx="' + r.idx + '"] .hci-result' );
			if ( r.action === 'error' ) {
				$cell.html( '<span class="hci-err">✗ ' + esc( r.note || 'error' ) + '</span>' );
			} else {
				var label = r.action === 'update' ? 'עודכן' : 'נוצר';
				var link = r.edit ? ' <a href="' + esc( r.edit ) + '" target="_blank">עריכה ↗</a>' : '';
				var note = r.note ? ' <span class="hci-note">' + esc( r.note ) + '</span>' : '';
				$cell.html( '<span class="hci-ok">✓ ' + label + ' #' + r.new_id + '</span>' + link + note );
			}
		}

		function step( start ) {
			if ( start >= total ) {
				$( '#hci-import' ).prop( 'disabled', false );
				$( '#hci-import-status' ).text( HCI.i18n.done + ' (' + total + ')' );
				return;
			}
			var chunk = idxs.slice( start, start + batch );
			$.post( HCI.ajax, {
				action: 'hci_import',
				nonce: HCI.nonce,
				map_to: mapTo,
				with_media: withMedia ? 'true' : 'false',
				with_terms: withTerms ? 'true' : 'false',
				as_event: asEvent ? 'true' : 'false',
				convert_elementor: convertElementor ? 'true' : 'false',
				clean_styles: cleanStyles ? 'true' : 'false',
				content_media: contentMedia ? 'true' : 'false',
				open_access: openAccess ? 'true' : 'false',
				indices: chunk
			} ).done( function ( resp ) {
				if ( resp && resp.success && resp.data.results ) {
					resp.data.results.forEach( paint );
				}
			} ).always( function () {
				done += chunk.length;
				$( '#hci-progress-bar' ).css( 'width', Math.round( ( done / total ) * 100 ) + '%' );
				step( start + batch );
			} );
		}
		step( 0 );
	} );
} )( jQuery );
