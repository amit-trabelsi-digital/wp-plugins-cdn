<?php
/**
 * Elementor → Gutenberg converter.
 *
 * The old site stores most of its body content inside Elementor's `_elementor_data`
 * JSON; `post_content` is empty for those records. This class walks that tree and
 * emits clean core blocks, so imported posts have real, editable content instead of
 * an empty editor.
 *
 * Pure string work — no WP media calls here. Image/file URLs are left pointing at the
 * old domain and are sideloaded + rewritten afterwards by HCI_Importer::rewrite_media().
 *
 * @package HaruvContentImporter
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class HCI_Elementor {

	/** Inline CSS properties worth keeping; everything else in a style="" is dropped. */
	private $keep_css = array( 'text-align' );

	/** Widget types that carry no content worth migrating. */
	private $ignore_widgets = array( 'spacer', 'icon', 'html', 'shortcode', 'global', 'menu-anchor' );

	/** @var array Widget types encountered with no handler. */
	private $unknown = array();

	/** @var int Widgets that produced at least one block. */
	private $converted = 0;

	/** @var bool Strip Elementor's inline colours / paddings. */
	private $clean_styles = true;

	/**
	 * Convert an Elementor data blob into serialized block markup.
	 *
	 * @param string $json  Raw `_elementor_data` JSON.
	 * @param array  $opts  { clean_styles:bool }
	 * @return array { content:string, converted:int, unknown:string[] }
	 */
	public function convert( $json, array $opts = array() ) {
		$this->unknown      = array();
		$this->converted    = 0;
		$this->clean_styles = ! isset( $opts['clean_styles'] ) || $opts['clean_styles'];

		$tree = is_array( $json ) ? $json : json_decode( (string) $json, true );
		if ( ! is_array( $tree ) ) {
			return array(
				'content'   => '',
				'converted' => 0,
				'unknown'   => array(),
			);
		}

		$blocks = $this->walk( $tree );

		return array(
			'content'   => implode( "\n\n", array_filter( $blocks ) ),
			'converted' => $this->converted,
			'unknown'   => array_values( array_unique( $this->unknown ) ),
		);
	}

	/** Depth-first walk over containers/sections/columns, collecting widget blocks. */
	private function walk( array $nodes ) {
		$out = array();
		foreach ( $nodes as $node ) {
			if ( ! is_array( $node ) ) {
				continue;
			}
			if ( isset( $node['elType'] ) && 'widget' === $node['elType'] ) {
				$blocks = $this->widget( (string) ( isset( $node['widgetType'] ) ? $node['widgetType'] : '' ), isset( $node['settings'] ) && is_array( $node['settings'] ) ? $node['settings'] : array() );
				if ( $blocks ) {
					$this->converted++;
					$out = array_merge( $out, $blocks );
				}
			}
			if ( ! empty( $node['elements'] ) && is_array( $node['elements'] ) ) {
				$out = array_merge( $out, $this->walk( $node['elements'] ) );
			}
		}
		return $out;
	}

	/**
	 * Map one Elementor widget to zero or more block strings.
	 *
	 * @param string $type Widget type.
	 * @param array  $s    Widget settings.
	 * @return string[]
	 */
	private function widget( $type, array $s ) {
		if ( in_array( $type, $this->ignore_widgets, true ) ) {
			return array();
		}

		switch ( $type ) {
			case 'heading':
				return $this->heading( $s );

			case 'text-editor':
				return $this->html_to_blocks( isset( $s['editor'] ) ? (string) $s['editor'] : '' );

			case 'image':
				return $this->image( isset( $s['image'] ) ? $s['image'] : array() );

			case 'divider':
				return array( "<!-- wp:separator -->\n<hr class=\"wp-block-separator has-alpha-channel-opacity\"/>\n<!-- /wp:separator -->" );

			case 'button':
				return $this->button(
					isset( $s['text'] ) ? $s['text'] : '',
					isset( $s['link']['url'] ) ? $s['link']['url'] : ''
				);

			case 'eael-creative-button':
				return $this->button(
					isset( $s['creative_button_text'] ) ? $s['creative_button_text'] : '',
					isset( $s['creative_button_link_url']['url'] ) ? $s['creative_button_link_url']['url'] : ''
				);

			case 'icon-list':
				return $this->list_block( $this->pluck_list( isset( $s['icon_list'] ) ? $s['icon_list'] : array(), 'text', 'link' ) );

			case 'eael-feature-list':
				return $this->list_block( $this->pluck_list( isset( $s['eael_feature_list'] ) ? $s['eael_feature_list'] : array(), 'eael_feature_list_content', '' ) );

			case 'price-list':
				return $this->price_list( isset( $s['price_list'] ) ? $s['price_list'] : array() );

			case 'image-box':
				return $this->image_box( $s );

			case 'eael-data-table':
				return $this->data_table( $s );

			case 'video':
				return $this->video( $s );

			case 'image-gallery':
				return $this->gallery( $this->pluck_urls( isset( $s['wp_gallery'] ) ? $s['wp_gallery'] : array() ) );

			case 'media-carousel':
				$urls = array();
				foreach ( (array) ( isset( $s['slides'] ) ? $s['slides'] : array() ) as $slide ) {
					if ( is_array( $slide ) && ! empty( $slide['image']['url'] ) ) {
						$urls[] = (string) $slide['image']['url'];
					}
				}
				return $this->gallery( $urls );
		}

		// Unknown widget — salvage any obvious text payload rather than losing it.
		$this->unknown[] = $type;
		foreach ( array( 'editor', 'text', 'title', 'description_text', 'content' ) as $k ) {
			if ( ! empty( $s[ $k ] ) && is_string( $s[ $k ] ) ) {
				return $this->html_to_blocks( $s[ $k ] );
			}
		}
		return array();
	}

	/* ---------------------------------------------------------------- widgets */

	private function heading( array $s ) {
		$text = isset( $s['title'] ) ? trim( wp_strip_all_tags( (string) $s['title'] ) ) : '';
		if ( '' === $text ) {
			return array();
		}
		$tag   = isset( $s['header_size'] ) ? strtolower( (string) $s['header_size'] ) : 'h2';
		$level = preg_match( '/^h([1-6])$/', $tag, $m ) ? (int) $m[1] : 2;
		// An <h1> in the body duplicates the post title — demote it.
		if ( 1 === $level ) {
			$level = 2;
		}
		return array( $this->heading_block( $level, esc_html( $text ) ) );
	}

	private function image( $img ) {
		$url = is_array( $img ) && ! empty( $img['url'] ) ? (string) $img['url'] : '';
		if ( '' === $url ) {
			return array();
		}
		$alt = is_array( $img ) && ! empty( $img['alt'] ) ? (string) $img['alt'] : '';
		return array( $this->image_block( $url, $alt ) );
	}

	private function button( $text, $url ) {
		$text = trim( wp_strip_all_tags( (string) $text ) );
		$url  = trim( (string) $url );
		if ( '' === $text ) {
			return array();
		}
		if ( '' === $url ) {
			// A button with no destination is just a label — keep the text, drop the button.
			return array( $this->paragraph_block( esc_html( $text ) ) );
		}
		return array(
			"<!-- wp:buttons -->\n<div class=\"wp-block-buttons\"><!-- wp:button -->\n"
			. '<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="' . esc_url( $url ) . '">' . esc_html( $text ) . "</a></div>\n"
			. "<!-- /wp:button --></div>\n<!-- /wp:buttons -->",
		);
	}

	/** Normalise an Elementor repeater into [ [text, url], … ]. */
	private function pluck_list( $rows, $text_key, $link_key ) {
		$out = array();
		foreach ( (array) $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$text = isset( $row[ $text_key ] ) ? trim( wp_strip_all_tags( (string) $row[ $text_key ] ) ) : '';
			if ( '' === $text ) {
				continue;
			}
			$url = ( $link_key && isset( $row[ $link_key ]['url'] ) ) ? (string) $row[ $link_key ]['url'] : '';
			$out[] = array( $text, $url );
		}
		return $out;
	}

	private function list_block( array $rows ) {
		if ( ! $rows ) {
			return array();
		}
		$items = '';
		foreach ( $rows as $row ) {
			list( $text, $url ) = $row;
			$inner = esc_html( $text );
			if ( '' !== $url ) {
				$inner = '<a href="' . esc_url( $url ) . '">' . $inner . '</a>';
			}
			$items .= "<!-- wp:list-item -->\n<li>" . $inner . "</li>\n<!-- /wp:list-item -->\n";
		}
		return array( "<!-- wp:list -->\n<ul class=\"wp-block-list\">" . $items . "</ul>\n<!-- /wp:list -->" );
	}

	/** Elementor price-list → a definition-style list (title — price + description). */
	private function price_list( $rows ) {
		$items = '';
		foreach ( (array) $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$title = isset( $row['title'] ) ? trim( wp_strip_all_tags( (string) $row['title'] ) ) : '';
			$price = isset( $row['price'] ) ? trim( wp_strip_all_tags( (string) $row['price'] ) ) : '';
			$desc  = isset( $row['item_description'] ) ? trim( wp_strip_all_tags( (string) $row['item_description'] ) ) : '';
			if ( '' === $title && '' === $price ) {
				continue;
			}
			$line = '<strong>' . esc_html( $title ) . '</strong>';
			if ( '' !== $price ) {
				$line .= ' — ' . esc_html( $price );
			}
			if ( '' !== $desc ) {
				$line .= '<br>' . esc_html( $desc );
			}
			$items .= "<!-- wp:list-item -->\n<li>" . $line . "</li>\n<!-- /wp:list-item -->\n";
		}
		if ( '' === $items ) {
			return array();
		}
		return array( "<!-- wp:list -->\n<ul class=\"wp-block-list\">" . $items . "</ul>\n<!-- /wp:list -->" );
	}

	/** Elementor video → core/embed for the provider actually selected on the widget. */
	private function video( array $s ) {
		$type = isset( $s['video_type'] ) ? (string) $s['video_type'] : 'youtube';
		$key  = 'hosted' === $type ? 'hosted_url' : $type . '_url';
		$url  = isset( $s[ $key ]['url'] ) ? (string) $s[ $key ]['url'] : ( isset( $s[ $key ] ) && is_string( $s[ $key ] ) ? $s[ $key ] : '' );
		if ( '' === trim( $url ) ) {
			return array();
		}
		if ( 'hosted' === $type ) {
			return array(
				"<!-- wp:video -->\n<figure class=\"wp-block-video\"><video controls src=\"" . esc_url( $url ) . "\"></video></figure>\n<!-- /wp:video -->",
			);
		}
		$provider = in_array( $type, array( 'youtube', 'vimeo', 'dailymotion' ), true ) ? $type : 'youtube';
		return array(
			'<!-- wp:embed {"url":"' . esc_url( $url ) . '","type":"video","providerNameSlug":"' . $provider . '","responsive":true} -->' . "\n"
			. '<figure class="wp-block-embed is-type-video is-provider-' . $provider . ' wp-block-embed-' . $provider . ' wp-embed-aspect-16-9 wp-has-aspect-ratio"><div class="wp-block-embed__wrapper">' . "\n"
			. esc_url( $url ) . "\n</div></figure>\n<!-- /wp:embed -->",
		);
	}

	/** @return string[] */
	private function pluck_urls( $rows ) {
		$out = array();
		foreach ( (array) $rows as $row ) {
			if ( is_array( $row ) && ! empty( $row['url'] ) ) {
				$out[] = (string) $row['url'];
			}
		}
		return $out;
	}

	private function gallery( array $urls ) {
		$urls = array_values( array_unique( array_filter( $urls ) ) );
		if ( ! $urls ) {
			return array();
		}
		$inner = '';
		foreach ( $urls as $url ) {
			$inner .= $this->image_block( $url ) . "\n";
		}
		return array(
			"<!-- wp:gallery {\"linkTo\":\"none\"} -->\n<figure class=\"wp-block-gallery has-nested-images columns-default is-cropped\">\n"
			. $inner . "</figure>\n<!-- /wp:gallery -->",
		);
	}

	private function image_box( array $s ) {
		$out   = $this->image( isset( $s['image'] ) ? $s['image'] : array() );
		$title = isset( $s['title_text'] ) ? trim( wp_strip_all_tags( (string) $s['title_text'] ) ) : '';
		if ( '' !== $title ) {
			$out[] = $this->heading_block( 3, esc_html( $title ) );
		}
		if ( ! empty( $s['description_text'] ) ) {
			$out = array_merge( $out, $this->html_to_blocks( (string) $s['description_text'] ) );
		}
		return $out;
	}

	/**
	 * Essential Addons data-table → core/table.
	 *
	 * The widget flattens everything into one `eael_data_table_content_rows` list: entries
	 * with `..._row_type === 'col'` are cells, and any other entry starts a new row.
	 */
	private function data_table( array $s ) {
		$head = array();
		foreach ( (array) ( isset( $s['eael_data_table_header_cols_data'] ) ? $s['eael_data_table_header_cols_data'] : array() ) as $col ) {
			if ( is_array( $col ) && isset( $col['eael_data_table_header_col'] ) ) {
				$head[] = trim( wp_strip_all_tags( (string) $col['eael_data_table_header_col'] ) );
			}
		}

		$rows    = array();
		$current = null;
		foreach ( (array) ( isset( $s['eael_data_table_content_rows'] ) ? $s['eael_data_table_content_rows'] : array() ) as $cell ) {
			if ( ! is_array( $cell ) ) {
				continue;
			}
			$is_col = isset( $cell['eael_data_table_content_row_type'] ) && 'col' === $cell['eael_data_table_content_row_type'];
			if ( ! $is_col ) {
				if ( null !== $current ) {
					$rows[] = $current;
				}
				$current = array();
				continue;
			}
			$use_editor = isset( $cell['eael_data_table_content_type'] ) && 'editor' === $cell['eael_data_table_content_type'];
			$raw        = $use_editor && isset( $cell['eael_data_table_content_row_content'] )
				? (string) $cell['eael_data_table_content_row_content']
				: ( isset( $cell['eael_data_table_content_row_title'] ) ? (string) $cell['eael_data_table_content_row_title'] : '' );
			$text       = trim( wp_strip_all_tags( $raw ) );
			if ( 'Content' === $text ) {
				$text = ''; // Elementor's untouched placeholder.
			}
			if ( null === $current ) {
				$current = array();
			}
			$current[] = $text;
		}
		if ( null !== $current ) {
			$rows[] = $current;
		}
		$rows = array_values(
			array_filter(
				$rows,
				static function ( $r ) {
					return (bool) array_filter( $r, static function ( $c ) { return '' !== $c; } );
				}
			)
		);

		if ( ! $rows && ! $head ) {
			return array();
		}

		$html = '<figure class="wp-block-table"><table>';
		if ( $head ) {
			$html .= '<thead><tr>';
			foreach ( $head as $h ) {
				$html .= '<th>' . esc_html( $h ) . '</th>';
			}
			$html .= '</tr></thead>';
		}
		$html .= '<tbody>';
		foreach ( $rows as $r ) {
			$html .= '<tr>';
			foreach ( $r as $c ) {
				$html .= '<td>' . esc_html( $c ) . '</td>';
			}
			$html .= '</tr>';
		}
		$html .= '</tbody></table></figure>';

		return array( "<!-- wp:table -->\n" . $html . "\n<!-- /wp:table -->" );
	}

	/* ------------------------------------------------------------ html → blocks */

	/**
	 * Turn a chunk of legacy WYSIWYG HTML into core blocks.
	 * Top-level elements map 1:1 where a core block exists; anything else falls back
	 * to core/html so nothing is silently dropped.
	 *
	 * @param string $html
	 * @return string[]
	 */
	public function html_to_blocks( $html ) {
		$html = $this->clean_html( (string) $html );
		if ( '' === trim( wp_strip_all_tags( $html ) ) && ! preg_match( '/<img\b/i', $html ) ) {
			return array();
		}

		$dom = $this->load_dom( $html );
		if ( ! $dom ) {
			return array( "<!-- wp:html -->\n" . $html . "\n<!-- /wp:html -->" );
		}

		$blocks = array();
		$body   = $dom->getElementsByTagName( 'body' )->item( 0 );
		if ( ! $body ) {
			return array( "<!-- wp:html -->\n" . $html . "\n<!-- /wp:html -->" );
		}

		$loose = ''; // bare text / inline nodes accumulate into one paragraph
		foreach ( iterator_to_array( $body->childNodes ) as $node ) {
			if ( XML_TEXT_NODE === $node->nodeType ) {
				$loose .= $node->textContent;
				continue;
			}
			if ( XML_ELEMENT_NODE !== $node->nodeType ) {
				continue;
			}
			$tag = strtolower( $node->nodeName );

			if ( in_array( $tag, array( 'span', 'strong', 'em', 'b', 'i', 'a', 'br' ), true ) ) {
				$loose .= $this->inner_html( $dom, $node, true );
				continue;
			}
			if ( '' !== trim( $loose ) ) {
				$blocks[] = $this->paragraph_block( trim( $loose ) );
			}
			$loose = '';

			$blocks = array_merge( $blocks, $this->element_to_blocks( $dom, $node, $tag ) );
		}
		if ( '' !== trim( $loose ) ) {
			$blocks[] = $this->paragraph_block( trim( $loose ) );
		}

		return array_filter( $blocks );
	}

	/** @return string[] */
	private function element_to_blocks( DOMDocument $dom, DOMNode $node, $tag ) {
		$inner = trim( $this->inner_html( $dom, $node ) );

		if ( preg_match( '/^h([1-6])$/', $tag, $m ) ) {
			if ( '' === trim( wp_strip_all_tags( $inner ) ) ) {
				return array();
			}
			$level = max( 2, (int) $m[1] ); // never emit an in-body <h1>
			return array( $this->heading_block( $level, $inner ) );
		}

		switch ( $tag ) {
			case 'p':
			case 'div':
				if ( '' === trim( wp_strip_all_tags( $inner ) ) ) {
					// An empty <p> that only wraps an image still matters.
					return preg_match( '/<img\b/i', $inner ) ? $this->images_from( $inner ) : array();
				}
				return array( $this->paragraph_block( $inner ) );

			case 'ul':
			case 'ol':
				return array( $this->list_from_dom( $dom, $node, 'ol' === $tag ) );

			case 'blockquote':
				return array( "<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\">" . $inner . "</blockquote>\n<!-- /wp:quote -->" );

			case 'hr':
				return array( "<!-- wp:separator -->\n<hr class=\"wp-block-separator has-alpha-channel-opacity\"/>\n<!-- /wp:separator -->" );

			case 'img':
				return $this->images_from( $dom->saveHTML( $node ) );

			case 'figure':
			case 'table':
			case 'iframe':
				$outer = $dom->saveHTML( $node );
				if ( 'table' === $tag ) {
					return array( "<!-- wp:table -->\n<figure class=\"wp-block-table\">" . $outer . "</figure>\n<!-- /wp:table -->" );
				}
				return array( "<!-- wp:html -->\n" . $outer . "\n<!-- /wp:html -->" );
		}

		return array( "<!-- wp:html -->\n" . $dom->saveHTML( $node ) . "\n<!-- /wp:html -->" );
	}

	private function list_from_dom( DOMDocument $dom, DOMNode $node, $ordered ) {
		$items = '';
		foreach ( $node->childNodes as $li ) {
			if ( XML_ELEMENT_NODE !== $li->nodeType || 'li' !== strtolower( $li->nodeName ) ) {
				continue;
			}
			$items .= "<!-- wp:list-item -->\n<li>" . trim( $this->inner_html( $dom, $li ) ) . "</li>\n<!-- /wp:list-item -->\n";
		}
		if ( '' === $items ) {
			return '';
		}
		$tag  = $ordered ? 'ol' : 'ul';
		$attr = $ordered ? ' {"ordered":true}' : '';
		return "<!-- wp:list" . $attr . " -->\n<{$tag} class=\"wp-block-list\">" . $items . "</{$tag}>\n<!-- /wp:list -->";
	}

	/** Pull every <img> out of a fragment and emit one core/image block per image. */
	private function images_from( $fragment ) {
		if ( ! preg_match_all( '/<img\b[^>]*>/i', $fragment, $m ) ) {
			return array();
		}
		$out = array();
		foreach ( $m[0] as $img ) {
			if ( ! preg_match( '/\bsrc=["\']([^"\']+)["\']/i', $img, $src ) ) {
				continue;
			}
			$alt   = preg_match( '/\balt=["\']([^"\']*)["\']/i', $img, $a ) ? $a[1] : '';
			$out[] = $this->image_block( $src[1], $alt );
		}
		return $out;
	}

	/* ------------------------------------------------------------------ helpers */

	private function heading_block( $level, $inner ) {
		$attr = 2 === (int) $level ? '' : ' {"level":' . (int) $level . '}';
		return "<!-- wp:heading{$attr} -->\n<h{$level}>" . $inner . "</h{$level}>\n<!-- /wp:heading -->";
	}

	private function paragraph_block( $inner ) {
		return "<!-- wp:paragraph -->\n<p>" . $inner . "</p>\n<!-- /wp:paragraph -->";
	}

	/**
	 * core/image with a placeholder id — HCI_Importer::rewrite_media() swaps in the real
	 * attachment id and local URL after sideloading.
	 */
	private function image_block( $url, $alt = '' ) {
		return "<!-- wp:image {\"id\":0,\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->\n"
			. '<figure class="wp-block-image size-large"><img src="' . esc_url( $url ) . '" alt="' . esc_attr( $alt ) . '" class="wp-image-0"/></figure>' . "\n"
			. '<!-- /wp:image -->';
	}

	/**
	 * Strip Elementor's presentational noise so the imported content inherits the new
	 * theme's typography and colour tokens instead of hard-coded hex values.
	 */
	private function clean_html( $html ) {
		$html = str_replace( array( "\r\n", "\r" ), "\n", $html );
		if ( ! $this->clean_styles ) {
			return $html;
		}

		// Keep only whitelisted declarations inside style="".
		$keep = $this->keep_css;
		$html = preg_replace_callback(
			'/\sstyle=(["\'])(.*?)\1/is',
			static function ( $m ) use ( $keep ) {
				$out = array();
				foreach ( explode( ';', $m[2] ) as $decl ) {
					$parts = explode( ':', $decl, 2 );
					if ( count( $parts ) < 2 ) {
						continue;
					}
					$prop = strtolower( trim( $parts[0] ) );
					if ( in_array( $prop, $keep, true ) && '' !== trim( $parts[1] ) ) {
						$out[] = $prop . ': ' . trim( $parts[1] );
					}
				}
				return $out ? ' style="' . implode( '; ', $out ) . '"' : '';
			},
			$html
		);

		// Drop Elementor/EAEL utility classes, then any now-empty class attribute.
		$html = preg_replace( '/\sclass=(["\'])\s*(elementor|eael|body)[^"\']*\1/i', '', $html );
		// Unwrap <span> tags left with no attributes at all.
		$html = preg_replace( '/<span\s*>(.*?)<\/span>/is', '$1', $html );
		$html = preg_replace( '/<span\s*>(.*?)<\/span>/is', '$1', $html ); // one nesting level
		// Collapse Elementor's &nbsp;-only paragraphs.
		$html = preg_replace( '/<p>(\s|&nbsp;|<br\s*\/?>)*<\/p>/i', '', $html );

		return $html;
	}

	private function load_dom( $html ) {
		if ( ! class_exists( 'DOMDocument' ) ) {
			return null;
		}
		$prev = libxml_use_internal_errors( true );
		$dom  = new DOMDocument( '1.0', 'UTF-8' );
		$ok   = $dom->loadHTML( '<?xml encoding="UTF-8">' . '<body>' . $html . '</body>', LIBXML_NOWARNING | LIBXML_NOERROR );
		libxml_clear_errors();
		libxml_use_internal_errors( $prev );
		return $ok ? $dom : null;
	}

	/** innerHTML of a node (or outerHTML when $outer is true). */
	private function inner_html( DOMDocument $dom, DOMNode $node, $outer = false ) {
		if ( $outer ) {
			return (string) $dom->saveHTML( $node );
		}
		$html = '';
		foreach ( $node->childNodes as $child ) {
			$html .= $dom->saveHTML( $child );
		}
		return $html;
	}
}
