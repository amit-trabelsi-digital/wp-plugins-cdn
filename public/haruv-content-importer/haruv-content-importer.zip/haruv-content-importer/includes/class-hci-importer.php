<?php
/**
 * Core import logic — consumes a `haruv-import export` JSON snapshot and creates/updates
 * draft posts on this site. Fully offline (no old-site dependency). Idempotent via the
 * `_haruv_src` provenance meta.
 *
 * @package HaruvContentImporter
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class HCI_Importer {

	/** Meta keys never copied from the snapshot. */
	private $meta_denylist = array( '_thumbnail_id', '_wp_page_template', '_edit_lock', '_edit_last' );

	/**
	 * Old-site flags that hide content from visitors. On the old site the basic posts are
	 * readable only by logged-in users; on the new site the same content must be open, so
	 * these are forced to '0' when the "open access" option is on.
	 */
	private $access_meta = array( 'exclude_from_search', 'exclude_from_search_engine', 'hide_the_post', 'hide_the_post_hp_slider' );

	/** Host of the old site — only URLs under it are sideloaded from post content. */
	private $old_host = 'haruv.org.il';

	/** @var array url => attachment id, cached for the lifetime of the request. */
	private static $media_cache = array();

	/**
	 * Old event category (conf-events-category term name) → new `event_type` term name.
	 * Normalises Polylang language variants and "past" markers to a canonical type.
	 * Unmapped names are used as-is (term created if missing).
	 */
	private $event_type_map = array(
		'ימי עיון'                       => 'יום עיון',
		'ימי עיון קודמים'                => 'יום עיון',
		'Conferences'                    => 'כנס',
		'المؤتمرات المنتهية'             => 'כנס',
		'المؤتمرات والأيام التعليمية'    => 'כנס',
		'וובינרים'                       => 'וובינר',
		'Past Activities'                => 'פעילות',
	);

	/** Category names that are not real event types (never become event_type terms). */
	private $event_cat_skip = array( 'Registration Policy - Courses' );

	/**
	 * Import one snapshot record.
	 *
	 * @param array  $rec     One item from the export JSON `items[]`.
	 * @param string $map_to  Target post type on this site.
	 * @param array  $opts    { with_media:bool, with_terms:bool, status:string, source_db:string,
	 *                         convert_elementor:bool, clean_styles:bool, content_media:bool,
	 *                         open_access:bool }
	 * @return array Result row.
	 */
	public function import_record( array $rec, $map_to, array $opts ) {
		$status    = ! empty( $opts['status'] ) ? $opts['status'] : 'draft';
		$source_db = ! empty( $opts['source_db'] ) ? $opts['source_db'] : 'json';
		$src_id    = isset( $rec['id'] ) ? (int) $rec['id'] : 0;
		$src_type  = isset( $rec['type'] ) ? (string) $rec['type'] : '';
		$src_key   = $source_db . '#' . $src_type . '#' . $src_id;

		$title   = isset( $rec['title'] ) ? (string) $rec['title'] : '';
		$is_elem = ! empty( $rec['is_elementor'] );

		$row = array(
			'src_id' => $src_id,
			'title'  => $title,
			'render' => $is_elem ? 'elementor' : 'native',
			'new_id' => 0,
			'action' => 'skip',
			'note'   => '',
		);

		$resolved = $this->resolve_content( $rec, $opts );
		$content  = $resolved['content'];
		if ( '' !== $resolved['note'] ) {
			$row['note'] .= $resolved['note'];
		}
		if ( 'blocks' === $resolved['source'] ) {
			$row['render'] = 'elementor→blocks';
		}

		if ( ! post_type_exists( $map_to ) ) {
			$row['action'] = 'error';
			$row['note']   = 'target post type missing: ' . $map_to;
			return $row;
		}

		$existing = $this->find_existing( $src_key );
		$postarr  = array(
			'post_type'    => $map_to,
			'post_status'  => $status,
			'post_title'   => wp_strip_all_tags( $title ),
			'post_content' => $content,
			'post_excerpt' => isset( $rec['excerpt'] ) ? wp_kses_post( $rec['excerpt'] ) : '',
			'post_name'    => isset( $rec['slug'] ) ? sanitize_title( $rec['slug'] ) : '',
			'post_date'    => isset( $rec['date'] ) ? $rec['date'] : '',
			'menu_order'   => isset( $rec['menu_order'] ) ? (int) $rec['menu_order'] : 0,
			// The old site gates these posts behind a login; the new one must not.
			'post_password' => '',
		);

		if ( $existing ) {
			$postarr['ID'] = $existing;
			$new_id        = wp_update_post( $postarr, true );
			$row['action'] = 'update';
		} else {
			$new_id        = wp_insert_post( $postarr, true );
			$row['action'] = 'create';
		}

		if ( is_wp_error( $new_id ) ) {
			$row['action'] = 'error';
			$row['note']   = $new_id->get_error_message();
			return $row;
		}
		$row['new_id'] = (int) $new_id;

		update_post_meta( $new_id, '_haruv_src', $src_key );
		update_post_meta( $new_id, '_haruv_render', $row['render'] );

		$this->apply_meta( $new_id, $rec );

		if ( ! isset( $opts['open_access'] ) || $opts['open_access'] ) {
			$this->open_access( $new_id );
		}

		// Images/files inside the body still point at the old domain — pull them in and rewrite.
		if ( ! empty( $opts['content_media'] ) && '' !== $content ) {
			$rewritten = $this->rewrite_media( $content, $new_id );
			if ( $rewritten['count'] ) {
				wp_update_post(
					array(
						'ID'           => $new_id,
						'post_content' => $rewritten['content'],
					)
				);
				$row['note'] .= 'media:' . $rewritten['count'] . ';';
			}
			if ( $rewritten['failed'] ) {
				$row['note'] .= 'media-failed:' . $rewritten['failed'] . ';';
			}
		}

		if ( ! empty( $opts['as_event'] ) ) {
			$this->apply_event( $new_id, $rec, $opts );
			$row['note'] .= 'event;';
		}

		if ( ! empty( $opts['with_media'] ) && ! empty( $rec['featured_image'] ) ) {
			$att = $this->sideload( $rec['featured_image'], $new_id );
			if ( ! is_wp_error( $att ) && $att ) {
				set_post_thumbnail( $new_id, $att );
				$row['note'] .= 'thumb;';
			}
		}

		if ( ! empty( $opts['with_terms'] ) && ! empty( $rec['terms'] ) && is_array( $rec['terms'] ) ) {
			$n = $this->apply_terms( $new_id, $map_to, $rec['terms'] );
			if ( $n ) {
				$row['note'] .= "terms:{$n};";
			}
		}

		return $row;
	}

	/**
	 * Decide what goes into `post_content`.
	 *
	 * Snapshots never carry `content_rendered`, and for Elementor records `content_raw` is
	 * empty — everything lives in `elementor_data`. So: use whatever HTML the snapshot has,
	 * and otherwise (or when explicitly asked) convert the Elementor tree to core blocks.
	 *
	 * @return array { content:string, source:string, note:string }
	 */
	private function resolve_content( array $rec, array $opts ) {
		$html = isset( $rec['content_rendered'] ) && '' !== trim( (string) $rec['content_rendered'] )
			? (string) $rec['content_rendered']
			: ( isset( $rec['content_raw'] ) ? (string) $rec['content_raw'] : '' );

		$has_html  = '' !== trim( wp_strip_all_tags( $html ) ) || preg_match( '/<img\b/i', $html );
		$has_elem  = ! empty( $rec['elementor_data'] );
		$convert   = ! isset( $opts['convert_elementor'] ) || $opts['convert_elementor'];

		// Convert when asked and there is a tree to convert — an Elementor record's
		// `content_raw` is a stale leftover, so the tree wins when both exist.
		if ( $convert && $has_elem && ( ! $has_html || ! empty( $rec['is_elementor'] ) ) ) {
			if ( ! class_exists( 'HCI_Elementor' ) ) {
				require_once HCI_PATH . 'includes/class-hci-elementor.php';
			}
			$conv = ( new HCI_Elementor() )->convert(
				$rec['elementor_data'],
				array( 'clean_styles' => ! isset( $opts['clean_styles'] ) || $opts['clean_styles'] )
			);
			if ( '' !== trim( $conv['content'] ) ) {
				// Without a media pass the id placeholders never get resolved — strip them
				// so the blocks stay valid (images then keep their old-domain src).
				if ( empty( $opts['content_media'] ) ) {
					$conv['content'] = str_replace( array( '"id":0,', ' wp-image-0' ), '', $conv['content'] );
				}
				$note = 'blocks:' . (int) $conv['converted'] . ';';
				if ( ! empty( $conv['unknown'] ) ) {
					$note .= 'unmapped:' . implode( ',', array_slice( $conv['unknown'], 0, 4 ) ) . ';';
				}
				return array(
					'content' => $conv['content'],
					'source'  => 'blocks',
					'note'    => $note,
				);
			}
		}

		if ( ! $has_html && $has_elem ) {
			return array(
				'content' => '',
				'source'  => 'none',
				'note'    => 'no-content(elementor);',
			);
		}

		return array(
			'content' => $html,
			'source'  => $has_html ? 'html' : 'none',
			'note'    => $has_html ? '' : 'no-content;',
		);
	}

	/**
	 * Undo the old site's "logged-in users only" posture: no post password, and none of the
	 * legacy hide/exclude flags carried over from the export.
	 */
	private function open_access( $post_id ) {
		foreach ( $this->access_meta as $key ) {
			if ( '' !== (string) get_post_meta( $post_id, $key, true ) ) {
				update_post_meta( $post_id, $key, '0' );
			}
		}
		$post = get_post( $post_id );
		if ( $post && '' !== $post->post_password ) {
			wp_update_post(
				array(
					'ID'            => $post_id,
					'post_password' => '',
				)
			);
		}
	}

	/**
	 * Sideload every old-site upload referenced by the content (img src and file links),
	 * then rewrite the markup to the local copies.
	 *
	 * Also fills in the `id:0` / `wp-image-0` placeholders that HCI_Elementor emits, so
	 * core/image blocks validate in the editor.
	 *
	 * @return array { content:string, count:int, failed:int }
	 */
	private function rewrite_media( $content, $post_id ) {
		// Legacy markup carries srcset/sizes listing every generated thumbnail. Importing
		// those as separate attachments would duplicate each image several times over —
		// drop them and let WordPress rebuild responsive images from the attachment id.
		$content = preg_replace( '/\s(?:srcset|sizes)=(["\']).*?\1/is', '', $content );

		$urls = array();
		if ( preg_match_all( '/(?:src|href)=["\']([^"\']+)["\']/i', $content, $m ) ) {
			foreach ( $m[1] as $url ) {
				$host = wp_parse_url( $url, PHP_URL_HOST );
				$path = (string) wp_parse_url( $url, PHP_URL_PATH );
				if ( ! $host || false === strpos( $host, $this->old_host ) ) {
					continue;
				}
				if ( false === strpos( $path, '/wp-content/uploads/' ) ) {
					continue;
				}
				$urls[ $url ] = true;
			}
		}
		if ( ! $urls ) {
			return array(
				'content' => $content,
				'count'   => 0,
				'failed'  => 0,
			);
		}

		$count    = 0;
		$failed   = 0;
		$by_local = array(); // local url => attachment id
		foreach ( array_keys( $urls ) as $url ) {
			$att   = $this->attachment_for_url( $url, $post_id );
			$local = $att ? wp_get_attachment_url( $att ) : '';
			if ( ! $att || ! $local ) {
				$failed++;
				continue;
			}
			$content            = str_replace( $url, $local, $content );
			$by_local[ $local ] = (int) $att;
			$count++;
		}

		// Plain <img> tags (legacy WYSIWYG markup, not core/image blocks) need the
		// wp-image-N class for WordPress to attach responsive srcset on render.
		foreach ( $by_local as $local => $att ) {
			$content = preg_replace_callback(
				'/<img\b[^>]*\ssrc="' . preg_quote( $local, '/' ) . '"[^>]*>/i',
				static function ( $m ) use ( $att ) {
					if ( false !== strpos( $m[0], 'wp-image-' ) ) {
						return $m[0];
					}
					if ( preg_match( '/\sclass="([^"]*)"/i', $m[0] ) ) {
						return preg_replace( '/\sclass="([^"]*)"/i', ' class="$1 wp-image-' . $att . '"', $m[0], 1 );
					}
					return preg_replace( '/<img\b/i', '<img class="wp-image-' . $att . '"', $m[0], 1 );
				},
				$content
			);
		}

		// Stamp the real attachment id onto every core/image block we emitted with id:0.
		$content = preg_replace_callback(
			'/<!-- wp:image (\{.*?\}) -->(.*?)<!-- \/wp:image -->/s',
			static function ( $m ) use ( $by_local ) {
				if ( ! preg_match( '/<img[^>]*\ssrc="([^"]+)"/i', $m[2], $s ) ) {
					return $m[0];
				}
				$att = isset( $by_local[ $s[1] ] ) ? $by_local[ $s[1] ] : 0;
				if ( ! $att ) {
					// Media could not be fetched — drop the placeholder id so the editor
					// does not report the block as invalid.
					return '<!-- wp:image ' . str_replace( '"id":0,', '', $m[1] ) . ' -->'
						. str_replace( ' wp-image-0', '', $m[2] ) . '<!-- /wp:image -->';
				}
				return '<!-- wp:image ' . str_replace( '"id":0', '"id":' . $att, $m[1] ) . ' -->'
					. str_replace( 'wp-image-0', 'wp-image-' . $att, $m[2] ) . '<!-- /wp:image -->';
			},
			$content
		);

		return array(
			'content' => $content,
			'count'   => $count,
			'failed'  => $failed,
		);
	}

	/** Sideload a URL once per request/site; reuses an existing attachment when present. */
	private function attachment_for_url( $url, $post_id ) {
		if ( isset( self::$media_cache[ $url ] ) ) {
			return self::$media_cache[ $url ];
		}

		// `…-300x180.jpg` is a generated thumbnail; prefer the original so the new site can
		// generate its own sizes. Falls back to the thumbnail if the original is gone.
		$candidates = array( $url );
		if ( preg_match( '/^(.+)-\d+x\d+(\.[A-Za-z0-9]{2,5})$/', $url, $m ) ) {
			array_unshift( $candidates, $m[1] . $m[2] );
		}

		$att = 0;
		foreach ( $candidates as $candidate ) {
			if ( ! empty( self::$media_cache[ $candidate ] ) ) {
				$att = self::$media_cache[ $candidate ];
				break;
			}
			$existing = get_posts(
				array(
					'post_type'   => 'attachment',
					'post_status' => 'any',
					'meta_key'    => '_haruv_src_url',
					'meta_value'  => $candidate,
					'fields'      => 'ids',
					'numberposts' => 1,
				)
			);
			if ( $existing ) {
				$att = (int) $existing[0];
				self::$media_cache[ $candidate ] = $att;
				break;
			}
			$try = $this->sideload( $candidate, $post_id );
			if ( ! is_wp_error( $try ) && $try ) {
				$att = (int) $try;
				update_post_meta( $att, '_haruv_src_url', $candidate );
				self::$media_cache[ $candidate ] = $att;
				break;
			}
		}

		self::$media_cache[ $url ] = $att;
		return $att;
	}

	/**
	 * Map an old event (conf-events / inter-activ) onto a new WooCommerce event product:
	 * product_type=event, _event_* meta, event_type taxonomy from the old category, and
	 * the header image. Past events are marked out-of-stock.
	 */
	private function apply_event( $new_id, array $rec, array $opts ) {
		$m = isset( $rec['meta'] ) && is_array( $rec['meta'] ) ? $rec['meta'] : array();

		// WooCommerce product type.
		wp_set_object_terms( $new_id, 'event', 'product_type', false );

		// Dates: old Ymd + Hi → 'Y-m-d H:i:s'.
		$start = $this->combine_datetime( isset( $m['start_date'] ) ? $m['start_date'] : '', isset( $m['start_time'] ) ? $m['start_time'] : '' );
		$end   = $this->combine_datetime( isset( $m['finish_date'] ) ? $m['finish_date'] : '', isset( $m['finish_time'] ) ? $m['finish_time'] : '' );
		if ( $start ) {
			update_post_meta( $new_id, '_event_date', $start );
		}
		if ( $end ) {
			update_post_meta( $new_id, '_event_end_date', $end );
		}
		if ( ! empty( $m['place'] ) ) {
			update_post_meta( $new_id, '_event_location', is_scalar( $m['place'] ) ? (string) $m['place'] : '' );
		}
		update_post_meta( $new_id, '_event_type', 'physical' );
		if ( ! empty( $m['form'] ) ) {
			// Old Gravity Forms id — won't match the new site, kept for reference only.
			update_post_meta( $new_id, '_haruv_old_gf_form_id', (string) $m['form'] );
		}

		// event_type taxonomy from the old category (the required "categorise by event type").
		$cats    = isset( $rec['terms']['conf-events-category'] ) ? (array) $rec['terms']['conf-events-category'] : array();
		$is_past = false;
		$targets = array();
		foreach ( $cats as $c ) {
			$name = isset( $c['name'] ) ? $c['name'] : ( is_string( $c ) ? $c : '' );
			if ( '' === $name || in_array( $name, $this->event_cat_skip, true ) ) {
				continue;
			}
			if ( preg_match( '/קודמים|Past|المنتهية/u', $name ) ) {
				$is_past = true;
			}
			$targets[ isset( $this->event_type_map[ $name ] ) ? $this->event_type_map[ $name ] : $name ] = true;
		}
		foreach ( array_keys( $targets ) as $tn ) {
			$term = get_term_by( 'name', $tn, 'event_type' );
			if ( ! $term ) {
				$ins = wp_insert_term( $tn, 'event_type' );
				if ( ! is_wp_error( $ins ) ) {
					$term = get_term( $ins['term_id'], 'event_type' );
				}
			}
			if ( $term && ! is_wp_error( $term ) ) {
				wp_set_object_terms( $new_id, (int) $term->term_id, 'event_type', true );
			}
		}

		// Past detection (category marker or a start date already elapsed).
		if ( ! $is_past && $start && $start < current_time( 'Y-m-d H:i:s' ) ) {
			$is_past = true;
		}
		update_post_meta( $new_id, '_stock_status', $is_past ? 'outofstock' : 'instock' );
		if ( $is_past ) {
			update_post_meta( $new_id, '_haruv_event_past', '1' );
		}
		// Default price (free / archival) unless already priced.
		if ( '' === get_post_meta( $new_id, '_price', true ) ) {
			update_post_meta( $new_id, '_price', '0' );
			update_post_meta( $new_id, '_regular_price', '0' );
		}

		// Featured image from the old header image (resolved to a URL at export time).
		if ( ! empty( $opts['with_media'] ) && ! get_post_thumbnail_id( $new_id ) ) {
			$media = isset( $rec['media'] ) && is_array( $rec['media'] ) ? $rec['media'] : array();
			$img   = '';
			foreach ( array( 'header_image', 'header_image_mobile' ) as $f ) {
				if ( ! empty( $media[ $f ] ) ) {
					$img = $media[ $f ];
					break;
				}
			}
			if ( '' === $img && ! empty( $rec['featured_image'] ) ) {
				$img = $rec['featured_image'];
			}
			if ( $img ) {
				$att = $this->sideload( $img, $new_id );
				if ( ! is_wp_error( $att ) && $att ) {
					set_post_thumbnail( $new_id, $att );
				}
			}
		}
	}

	/** Old ACF date (Ymd) + time (Hi) → 'Y-m-d H:i:s' (empty on bad input). */
	private function combine_datetime( $ymd, $hi ) {
		$ymd = preg_replace( '/\D/', '', (string) $ymd );
		if ( strlen( $ymd ) < 8 ) {
			return '';
		}
		$hi = preg_replace( '/\D/', '', (string) $hi );
		$hi = str_pad( substr( $hi, 0, 4 ), 4, '0', STR_PAD_LEFT );
		return sprintf(
			'%s-%s-%s %s:%s:00',
			substr( $ymd, 0, 4 ),
			substr( $ymd, 4, 2 ),
			substr( $ymd, 6, 2 ),
			substr( $hi, 0, 2 ),
			substr( $hi, 2, 2 )
		);
	}

	/** Copy snapshot meta (already ACF-inclusive: values + `_field` refs) minus a small denylist. */
	private function apply_meta( $new_id, array $rec ) {
		$meta = isset( $rec['meta'] ) && is_array( $rec['meta'] ) ? $rec['meta'] : array();
		foreach ( $meta as $key => $val ) {
			if ( '' === $key || in_array( $key, $this->meta_denylist, true ) ) {
				continue;
			}
			update_post_meta( $new_id, $key, $val );
		}
		if ( ! empty( $rec['elementor_data'] ) ) {
			update_post_meta( $new_id, '_haruv_elementor_data', $rec['elementor_data'] );
		}
	}

	/** Best-effort taxonomy mapping: only into taxonomies that exist on the target type. */
	private function apply_terms( $new_id, $map_to, array $terms ) {
		$valid = get_object_taxonomies( $map_to );
		$count = 0;
		foreach ( $terms as $tax => $items ) {
			if ( ! in_array( $tax, $valid, true ) || ! taxonomy_exists( $tax ) ) {
				continue;
			}
			$slugs = array();
			foreach ( (array) $items as $t ) {
				$name = isset( $t['name'] ) ? $t['name'] : ( is_string( $t ) ? $t : '' );
				$slug = isset( $t['slug'] ) ? $t['slug'] : sanitize_title( $name );
				if ( '' === $slug ) {
					continue;
				}
				$term = get_term_by( 'slug', $slug, $tax );
				if ( ! $term && $name ) {
					$new = wp_insert_term( $name, $tax, array( 'slug' => $slug ) );
					if ( ! is_wp_error( $new ) ) {
						$slugs[] = $slug;
					}
				} elseif ( $term ) {
					$slugs[] = $slug;
				}
			}
			if ( $slugs ) {
				wp_set_object_terms( $new_id, $slugs, $tax, false );
				$count += count( $slugs );
			}
		}
		return $count;
	}

	private function sideload( $url, $post_id ) {
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		// Old-site uploads have Hebrew filenames; percent-encode the path so the request
		// is valid, but keep the decoded name for the local file.
		$path    = (string) wp_parse_url( $url, PHP_URL_PATH );
		$encoded = $url;
		if ( '' !== $path && preg_match( '/[^\x20-\x7e]/', $path ) ) {
			$segments = array_map( 'rawurlencode', explode( '/', rawurldecode( $path ) ) );
			$encoded  = str_replace( $path, implode( '/', $segments ), $url );
		}

		$tmp = download_url( $encoded, 60 );
		if ( is_wp_error( $tmp ) ) {
			return $tmp;
		}
		$name = sanitize_file_name( rawurldecode( basename( $path ) ) );
		if ( '' === $name || ! preg_match( '/\.[A-Za-z0-9]{2,5}$/', $name ) ) {
			@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			return new WP_Error( 'hci_bad_filename', 'unsupported media filename: ' . $url );
		}
		$file = array(
			'name'     => $name,
			'tmp_name' => $tmp,
		);
		$id = media_handle_sideload( $file, $post_id );
		if ( is_wp_error( $id ) && file_exists( $tmp ) ) {
			@unlink( $tmp );
		}
		return $id;
	}

	private function find_existing( $src_key ) {
		$q = get_posts(
			array(
				'post_type'   => 'any',
				'post_status' => 'any',
				'meta_key'    => '_haruv_src',
				'meta_value'  => $src_key,
				'fields'      => 'ids',
				'numberposts' => 1,
			)
		);
		return $q ? (int) $q[0] : 0;
	}
}
