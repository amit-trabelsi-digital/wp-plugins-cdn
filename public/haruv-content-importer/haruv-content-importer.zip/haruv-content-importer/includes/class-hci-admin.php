<?php
/**
 * Admin menu, page markup, and asset loading.
 *
 * @package HaruvContentImporter
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class HCI_Admin {

	const SLUG = 'haruv-content-importer';

	public function hooks() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
	}

	public function menu() {
		add_menu_page(
			__( 'ייבוא תוכן מחרוב', 'haruv-content-importer' ),
			__( 'ייבוא חרוב', 'haruv-content-importer' ),
			HCI_CAP,
			self::SLUG,
			array( $this, 'render' ),
			'dashicons-download',
			58
		);
	}

	public function assets( $hook ) {
		if ( 'toplevel_page_' . self::SLUG !== $hook ) {
			return;
		}
		wp_enqueue_style( 'hci-admin', HCI_URL . 'assets/css/admin.css', array(), HCI_VERSION );
		wp_enqueue_script( 'hci-admin', HCI_URL . 'assets/js/admin.js', array( 'jquery' ), HCI_VERSION, true );
		wp_localize_script(
			'hci-admin',
			'HCI',
			array(
				'ajax'    => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( HCI_NONCE ),
				'types'   => $this->post_type_choices(),
				'bundled' => hci_bundled_snapshots(),
				'i18n'   => array(
					'noFile'    => __( 'בחר/י קובץ JSON קודם.', 'haruv-content-importer' ),
					'loading'   => __( 'טוען…', 'haruv-content-importer' ),
					'importing' => __( 'מייבא…', 'haruv-content-importer' ),
					'selectAll' => __( 'בחר/י הכל', 'haruv-content-importer' ),
					'done'      => __( 'הסתיים', 'haruv-content-importer' ),
					'noneSel'   => __( 'לא נבחרו פריטים.', 'haruv-content-importer' ),
					'confirm'   => __( 'לייבא את הפריטים הנבחרים כטיוטות?', 'haruv-content-importer' ),
				),
			)
		);
	}

	/** Public post types + a few relevant non-public ones, for the target selector. */
	private function post_type_choices() {
		$out  = array();
		$types = get_post_types( array( 'show_ui' => true ), 'objects' );
		$skip  = array( 'attachment', 'wp_block', 'wp_template', 'wp_template_part', 'wp_navigation', 'nav_menu_item' );
		foreach ( $types as $t ) {
			if ( in_array( $t->name, $skip, true ) ) {
				continue;
			}
			$out[] = array(
				'name'  => $t->name,
				'label' => $t->labels->singular_name . ' (' . $t->name . ')',
			);
		}
		return $out;
	}

	public function render() {
		if ( ! current_user_can( HCI_CAP ) ) {
			wp_die( esc_html__( 'אין הרשאה.', 'haruv-content-importer' ) );
		}
		?>
		<div class="wrap hci-wrap" dir="rtl">
			<h1><?php esc_html_e( 'ייבוא תוכן מחרוב הישן', 'haruv-content-importer' ); ?></h1>
			<p class="hci-lead">
				<?php esc_html_e( 'העלו קובץ JSON שיוצא מהאתר הישן, סמנו את הפריטים לייבוא, בחרו סוג תוכן יעד, וייבאו — כטיוטות לבדיקה. הפעולה ניתנת לחזרה (לא משכפלת פריט שכבר יובא).', 'haruv-content-importer' ); ?>
			</p>

			<div class="hci-card">
				<div class="hci-row" id="hci-bundled-row">
					<label for="hci-bundled"><strong><?php esc_html_e( 'מאגר מובנה (מהאתר הישן):', 'haruv-content-importer' ); ?></strong></label>
					<select id="hci-bundled"></select>
					<button class="button button-primary" id="hci-load-bundled"><?php esc_html_e( 'טען מאגר', 'haruv-content-importer' ); ?></button>
					<span class="hci-status" id="hci-load-status"></span>
				</div>
				<div class="hci-row hci-sub">
					<label for="hci-file"><?php esc_html_e( 'או העלאת קובץ JSON:', 'haruv-content-importer' ); ?></label>
					<input type="file" id="hci-file" accept="application/json,.json" />
					<button class="button" id="hci-load"><?php esc_html_e( 'טען קובץ', 'haruv-content-importer' ); ?></button>
				</div>
			</div>

			<div class="hci-card hci-hidden" id="hci-controls">
				<div class="hci-row">
					<label><strong><?php esc_html_e( 'ייבא לסוג תוכן:', 'haruv-content-importer' ); ?></strong></label>
					<select id="hci-map-to"></select>
					<label><input type="checkbox" id="hci-with-media" checked /> <?php esc_html_e( 'ייבא מדיה (תמונה ראשית)', 'haruv-content-importer' ); ?></label>
					<label><input type="checkbox" id="hci-with-terms" checked /> <?php esc_html_e( 'ייבא טקסונומיות', 'haruv-content-importer' ); ?></label>
					<label id="hci-as-event-wrap"><input type="checkbox" id="hci-as-event" /> <?php esc_html_e( 'ייבא כאירוע (מוצר event + סיווג לפי סוג האירוע)', 'haruv-content-importer' ); ?></label>
				</div>
				<div class="hci-row hci-sub">
					<label><input type="checkbox" id="hci-convert-elementor" checked /> <?php esc_html_e( 'המר תוכן Elementor לבלוקים', 'haruv-content-importer' ); ?></label>
					<label><input type="checkbox" id="hci-clean-styles" checked /> <?php esc_html_e( 'נקה עיצוב מוטבע (צבעים/ריווח מהאתר הישן)', 'haruv-content-importer' ); ?></label>
					<label><input type="checkbox" id="hci-content-media" checked /> <?php esc_html_e( 'ייבא מדיה מגוף התוכן (תמונות וקבצים)', 'haruv-content-importer' ); ?></label>
					<label><input type="checkbox" id="hci-open-access" checked /> <?php esc_html_e( 'ללא הגבלות גישה (מבטל סיסמה והסתרה מהאתר הישן)', 'haruv-content-importer' ); ?></label>
				</div>
				<div class="hci-row">
					<button class="button" id="hci-select-all"><?php esc_html_e( 'בחר/י הכל', 'haruv-content-importer' ); ?></button>
					<button class="button button-primary" id="hci-import"><?php esc_html_e( 'ייבא נבחרים כטיוטות', 'haruv-content-importer' ); ?></button>
					<span class="hci-status" id="hci-import-status"></span>
				</div>
				<div class="hci-progress hci-hidden" id="hci-progress"><div class="hci-progress-bar" id="hci-progress-bar"></div></div>
			</div>

			<table class="widefat striped hci-table hci-hidden" id="hci-table">
				<thead>
					<tr>
						<th class="check-column"><input type="checkbox" id="hci-check-all" /></th>
						<th><?php esc_html_e( 'כותרת', 'haruv-content-importer' ); ?></th>
						<th><?php esc_html_e( 'סוג', 'haruv-content-importer' ); ?></th>
						<th><?php esc_html_e( 'תוכן', 'haruv-content-importer' ); ?></th>
						<th>ACF</th>
						<th><?php esc_html_e( 'טקסונומיות', 'haruv-content-importer' ); ?></th>
						<th><?php esc_html_e( 'תוצאה', 'haruv-content-importer' ); ?></th>
					</tr>
				</thead>
				<tbody id="hci-tbody"></tbody>
			</table>
		</div>
		<?php
	}
}
