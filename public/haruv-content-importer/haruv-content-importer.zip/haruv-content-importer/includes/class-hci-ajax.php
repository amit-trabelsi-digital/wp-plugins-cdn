<?php
/**
 * AJAX handlers: load a JSON snapshot (preview) and import selected items (batched).
 *
 * @package HaruvContentImporter
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class HCI_Ajax {

	public function hooks() {
		add_action( 'wp_ajax_hci_load', array( $this, 'load' ) );
		add_action( 'wp_ajax_hci_load_bundled', array( $this, 'load_bundled' ) );
		add_action( 'wp_ajax_hci_import', array( $this, 'import' ) );
	}

	private function guard() {
		if ( ! current_user_can( HCI_CAP ) ) {
			wp_send_json_error( array( 'message' => __( 'אין הרשאה.', 'haruv-content-importer' ) ), 403 );
		}
		if ( ! check_ajax_referer( HCI_NONCE, 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'אימות נכשל, רענן/י את הדף.', 'haruv-content-importer' ) ), 400 );
		}
	}

	/** Receive an uploaded JSON snapshot, validate, persist per-user, return a preview list. */
	public function load() {
		$this->guard();

		if ( empty( $_FILES['file'] ) || ! isset( $_FILES['file']['tmp_name'] ) || ! is_uploaded_file( $_FILES['file']['tmp_name'] ) ) {
			wp_send_json_error( array( 'message' => __( 'לא התקבל קובץ.', 'haruv-content-importer' ) ), 400 );
		}
		if ( (int) $_FILES['file']['size'] > 50 * MB_IN_BYTES ) {
			wp_send_json_error( array( 'message' => __( 'הקובץ גדול מדי (מקסימום 50MB).', 'haruv-content-importer' ) ), 400 );
		}

		$raw  = file_get_contents( $_FILES['file']['tmp_name'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$data = json_decode( $raw, true );
		if ( ! is_array( $data ) || empty( $data['items'] ) || ! is_array( $data['items'] ) ) {
			wp_send_json_error( array( 'message' => __( 'קובץ לא תקין — צריך להיות קובץ ייצוא של haruv-import.', 'haruv-content-importer' ) ), 400 );
		}

		$this->persist_and_respond( $data );
	}

	/** Load a snapshot bundled with the plugin (data/<file>.json). */
	public function load_bundled() {
		$this->guard();

		$file = isset( $_POST['file'] ) ? sanitize_file_name( wp_unslash( $_POST['file'] ) ) : '';
		$path = hci_bundled_path( $file );
		if ( '' === $path ) {
			wp_send_json_error( array( 'message' => __( 'מאגר לא נמצא.', 'haruv-content-importer' ) ), 400 );
		}
		$data = json_decode( file_get_contents( $path ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! is_array( $data ) || empty( $data['items'] ) ) {
			wp_send_json_error( array( 'message' => __( 'המאגר פגום.', 'haruv-content-importer' ) ), 500 );
		}
		$this->persist_and_respond( $data );
	}

	/** Persist the snapshot for this user and return its preview list. */
	private function persist_and_respond( array $data ) {
		$path = $this->user_snapshot_path();
		if ( false === file_put_contents( $path, wp_json_encode( $data, JSON_UNESCAPED_UNICODE ) ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
			wp_send_json_error( array( 'message' => __( 'שמירת הקובץ נכשלה.', 'haruv-content-importer' ) ), 500 );
		}
		$preview = $this->build_preview( $data['items'] );
		wp_send_json_success(
			array(
				'source_type' => isset( $data['source_type'] ) ? $data['source_type'] : '',
				'source_db'   => isset( $data['source_db'] ) ? $data['source_db'] : 'json',
				'count'       => count( $preview ),
				'items'       => $preview,
			)
		);
	}

	private function build_preview( array $items ) {
		$preview = array();
		foreach ( $items as $i => $rec ) {
			$meta      = isset( $rec['meta'] ) && is_array( $rec['meta'] ) ? $rec['meta'] : array();
			$acf_count = 0;
			foreach ( $meta as $k => $v ) {
				if ( '' !== $k && '_' !== $k[0] ) {
					$acf_count++;
				}
			}
			$term_names = array();
			if ( ! empty( $rec['terms'] ) && is_array( $rec['terms'] ) ) {
				foreach ( $rec['terms'] as $tax => $tItems ) {
					foreach ( (array) $tItems as $t ) {
						$term_names[] = isset( $t['name'] ) ? $t['name'] : '';
					}
				}
			}
			// What the body will actually come from — makes "content missing" visible
			// before anything is imported.
			$raw      = isset( $rec['content_raw'] ) ? (string) $rec['content_raw'] : '';
			$has_html = '' !== trim( wp_strip_all_tags( $raw ) ) || (bool) preg_match( '/<img\b/i', $raw );
			$widgets  = $this->count_widgets( isset( $rec['elementor_data'] ) ? $rec['elementor_data'] : '' );
			if ( $widgets ) {
				$content_src = 'elementor';
			} elseif ( $has_html ) {
				$content_src = 'html';
			} else {
				$content_src = 'empty';
			}

			$preview[] = array(
				'idx'        => (int) $i,
				'id'         => isset( $rec['id'] ) ? (int) $rec['id'] : 0,
				'title'      => isset( $rec['title'] ) ? (string) $rec['title'] : '',
				'type'       => isset( $rec['type'] ) ? (string) $rec['type'] : '',
				'elementor'  => ! empty( $rec['is_elementor'] ),
				'widgets'    => $widgets,
				'content'    => $content_src,
				'acf'        => $acf_count,
				'terms'      => implode( ', ', array_filter( $term_names ) ),
			);
		}
		return $preview;
	}

	/** Count content-bearing Elementor widgets in a record (0 when there is no tree). */
	private function count_widgets( $json ) {
		if ( empty( $json ) ) {
			return 0;
		}
		$tree = is_array( $json ) ? $json : json_decode( (string) $json, true );
		if ( ! is_array( $tree ) ) {
			return 0;
		}
		$skip  = array( 'spacer', 'icon', 'divider' );
		$count = 0;
		$walk  = static function ( $nodes ) use ( &$walk, &$count, $skip ) {
			foreach ( $nodes as $n ) {
				if ( ! is_array( $n ) ) {
					continue;
				}
				if ( isset( $n['elType'] ) && 'widget' === $n['elType']
					&& ! in_array( isset( $n['widgetType'] ) ? $n['widgetType'] : '', $skip, true ) ) {
					$count++;
				}
				if ( ! empty( $n['elements'] ) && is_array( $n['elements'] ) ) {
					$walk( $n['elements'] );
				}
			}
		};
		$walk( $tree );
		return $count;
	}

	/** Import a batch of selected items (by their indices in the persisted snapshot). */
	public function import() {
		$this->guard();

		$map_to = isset( $_POST['map_to'] ) ? sanitize_key( wp_unslash( $_POST['map_to'] ) ) : '';
		if ( ! post_type_exists( $map_to ) ) {
			wp_send_json_error( array( 'message' => __( 'סוג תוכן יעד לא קיים.', 'haruv-content-importer' ) ), 400 );
		}
		$indices = isset( $_POST['indices'] ) ? array_map( 'intval', (array) wp_unslash( $_POST['indices'] ) ) : array();
		if ( empty( $indices ) ) {
			wp_send_json_error( array( 'message' => __( 'לא נבחרו פריטים.', 'haruv-content-importer' ) ), 400 );
		}

		$path = $this->user_snapshot_path();
		if ( ! is_readable( $path ) ) {
			wp_send_json_error( array( 'message' => __( 'לא נמצא קובץ טעון — טען/י מחדש.', 'haruv-content-importer' ) ), 400 );
		}
		$data = json_decode( file_get_contents( $path ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! is_array( $data ) || empty( $data['items'] ) ) {
			wp_send_json_error( array( 'message' => __( 'הקובץ הטעון פגום.', 'haruv-content-importer' ) ), 400 );
		}

		$opts = array(
			'status'            => 'draft',
			'with_media'        => $this->flag( 'with_media' ),
			'with_terms'        => $this->flag( 'with_terms' ),
			'as_event'          => $this->flag( 'as_event' ),
			'convert_elementor' => $this->flag( 'convert_elementor' ),
			'clean_styles'      => $this->flag( 'clean_styles' ),
			'content_media'     => $this->flag( 'content_media' ),
			'open_access'       => $this->flag( 'open_access' ),
			'source_db'         => isset( $data['source_db'] ) ? $data['source_db'] : 'json',
		);

		$importer = new HCI_Importer();
		$results  = array();
		foreach ( $indices as $idx ) {
			if ( ! isset( $data['items'][ $idx ] ) || ! is_array( $data['items'][ $idx ] ) ) {
				continue;
			}
			$res            = $importer->import_record( $data['items'][ $idx ], $map_to, $opts );
			$res['idx']     = $idx;
			$res['edit']    = $res['new_id'] ? get_edit_post_link( $res['new_id'], 'raw' ) : '';
			$results[]      = $res;
		}

		wp_send_json_success( array( 'results' => $results ) );
	}

	/** Read a boolean checkbox posted as the string 'true'/'false'. */
	private function flag( $key ) {
		return isset( $_POST[ $key ] ) && 'true' === $_POST[ $key ]; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- guard() ran.
	}

	private function user_snapshot_path() {
		return trailingslashit( hci_storage_dir() ) . 'snapshot-' . get_current_user_id() . '.json';
	}
}
