<?php
/**
 * Plugin Name: AT Agency Sites Manager (Beta)
 * Description: מנהל האתרים של סוכנות AT עם מיתוג מותאם אישית, ניטור וניהול אתרים
 * Version: 0.21.2
 * Author: Amit Trabelsi
 * Author URI: https://atd.digital
 * Text Domain: at-agency-manager
 * Domain Path: /languages
 * Requires at least: 5.2
 * Update URI: https://updates.amiteam.io/at-agency-sites-manager/plugin-info.json
 * Tested up to: 6.3
 * Requires PHP: 7.0
 * License: GPL v2 or later
 */

defined('ABSPATH') or die('Direct access not allowed');

// FIX: Ensure WP_User class is loaded and current user is properly initialized
// This prevents "Call to undefined method stdClass::has_cap()" errors
if (!class_exists('WP_User') && file_exists(ABSPATH . 'wp-includes/class-wp-user.php')) {
    require_once ABSPATH . 'wp-includes/class-wp-user.php';
}

if (!function_exists('wp_get_current_user')) {
    require_once ABSPATH . 'wp-includes/pluggable.php';
}

// Ensure current user is properly loaded before init hook
if (!did_action('init')) {
    $GLOBALS['current_user'] = wp_get_current_user();
    
    // If we still have a stdClass, convert it to proper WP_User object
    if (is_object($GLOBALS['current_user']) && !($GLOBALS['current_user'] instanceof WP_User)) {
        $user_id = isset($GLOBALS['current_user']->ID) ? intval($GLOBALS['current_user']->ID) : 0;
        if ($user_id > 0) {
            $GLOBALS['current_user'] = new WP_User($user_id);
        }
    }
}

// Define plugin constants
define('AT_AGENCY_MANAGER_VERSION', '0.21.2');
define('AT_AGENCY_MANAGER_PATH', plugin_dir_path(__FILE__));
define('AT_AGENCY_MANAGER_URL', plugin_dir_url(__FILE__));
define('AT_AGENCY_MANAGER_BASENAME', plugin_basename(__FILE__));
define('AT_AGENCY_MANAGER_LOADED', true); // סימון שהתוסף הראשי טעון - מנע כפילות עם at-branding

// Load core plugin files
require_once AT_AGENCY_MANAGER_PATH . 'includes/class-core.php';
require_once AT_AGENCY_MANAGER_PATH . 'includes/class-private-cdn-updater.php';
require_once AT_AGENCY_MANAGER_PATH . 'includes/class-i18n.php';
require_once AT_AGENCY_MANAGER_PATH . 'includes/class-logger.php';
require_once AT_AGENCY_MANAGER_PATH . 'includes/class-suite-core.php';
require_once AT_AGENCY_MANAGER_PATH . 'includes/class-environment.php';
require_once AT_AGENCY_MANAGER_PATH . 'includes/class-health-dashboard.php';
require_once AT_AGENCY_MANAGER_PATH . 'includes/class-admin-bar-versions.php';
require_once AT_AGENCY_MANAGER_PATH . 'includes/class-settings.php';
require_once AT_AGENCY_MANAGER_PATH . 'includes/class-branding.php';
require_once AT_AGENCY_MANAGER_PATH . 'includes/class-smtp.php';
require_once AT_AGENCY_MANAGER_PATH . 'includes/class-api.php';
require_once AT_AGENCY_MANAGER_PATH . 'includes/class-abilities-api.php';
require_once AT_AGENCY_MANAGER_PATH . 'includes/class-development-manager.php';
require_once AT_AGENCY_MANAGER_PATH . 'includes/class-webhook-manager.php';
require_once AT_AGENCY_MANAGER_PATH . 'includes/class-webhook-integrations.php';
require_once AT_AGENCY_MANAGER_PATH . 'includes/class-ecosystem.php';
require_once AT_AGENCY_MANAGER_PATH . 'includes/functions.php';
require_once AT_AGENCY_MANAGER_PATH . 'modules/protected-files.php';

// Plugin activation/deactivation hooks
register_activation_hook(__FILE__, array('AT_Agency_Manager_Core', 'activate'));
register_deactivation_hook(__FILE__, array('AT_Agency_Manager_Core', 'deactivate'));
register_uninstall_hook(__FILE__, array('AT_Agency_Manager_Core', 'uninstall'));

// Fix for WordPress capability system - ensure current user is properly initialized
// This must run BEFORE init hook when kses_init is called
// We use a direct action hook that fires very early
if (!has_action('init', 'at_fix_current_user_object')) {
    // Add the function at priority -999999 to run before everything else
    add_filter('init', 'at_fix_current_user_object', -999999);
}

function at_fix_current_user_object() {
    // Ensure current user is properly initialized as WP_User object
    // This prevents "Call to undefined method stdClass::has_cap()" errors during kses_init
    if (function_exists('wp_get_current_user') && function_exists('wp_set_current_user')) {
        global $current_user;
        
        // Check if current_user is stdClass instead of WP_User
        if (is_object($current_user) && !($current_user instanceof WP_User) && isset($current_user->ID)) {
            $user_id = intval($current_user->ID);
            wp_set_current_user($user_id);
        }
    }
    
    return;
}

// Ensure tables exist on every page load (in case activation didn't run properly)
add_action('wp_loaded', function() {
    require_once AT_AGENCY_MANAGER_PATH . 'includes/class-core.php';
    
    // Check if tables exist, if not create them
    global $wpdb;
    $table_name = $wpdb->prefix . 'at_agency_manager_logs';
    
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") !== $table_name) {
        // Table doesn't exist, create it with all required columns
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            type varchar(50) NOT NULL,
            message text NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'info',
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            user_id bigint(20) unsigned DEFAULT NULL,
            ip_address varchar(45) DEFAULT NULL,
            context longtext DEFAULT NULL,
            file_path varchar(255) DEFAULT NULL,
            line_number int(11) DEFAULT NULL,
            development_mode varchar(20) DEFAULT NULL,
            site_type varchar(20) DEFAULT NULL,
            PRIMARY KEY  (id),
            KEY idx_type_status (type, status),
            KEY idx_created_at (created_at),
            KEY idx_user_id (user_id),
            KEY idx_development_mode (development_mode)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    } else {
        // Table exists, check if it has all required columns
        $columns = $wpdb->get_results("DESCRIBE $table_name");
        $column_names = array_map(function($col) { return $col->Field; }, $columns);
        
        // Required columns that might be missing
        $required = array('status', 'user_id', 'ip_address', 'context', 'development_mode', 'site_type');
        $missing = array_diff($required, $column_names);
        
        if (!empty($missing)) {
            // Add missing columns
            foreach ($missing as $col) {
                $alter_sql = '';
                if ($col === 'status') {
                    $alter_sql = "ALTER TABLE $table_name ADD COLUMN status varchar(20) NOT NULL DEFAULT 'info'";
                } elseif ($col === 'user_id') {
                    $alter_sql = "ALTER TABLE $table_name ADD COLUMN user_id bigint(20) unsigned DEFAULT NULL";
                } elseif ($col === 'ip_address') {
                    $alter_sql = "ALTER TABLE $table_name ADD COLUMN ip_address varchar(45) DEFAULT NULL";
                } elseif ($col === 'context') {
                    $alter_sql = "ALTER TABLE $table_name ADD COLUMN context longtext DEFAULT NULL";
                } elseif ($col === 'development_mode') {
                    $alter_sql = "ALTER TABLE $table_name ADD COLUMN development_mode varchar(20) DEFAULT NULL";
                } elseif ($col === 'site_type') {
                    $alter_sql = "ALTER TABLE $table_name ADD COLUMN site_type varchar(20) DEFAULT NULL";
                }
                
                if ($alter_sql) {
                    $wpdb->query($alter_sql);
                }
            }
        }
    }
}, 1);

// Initialize the plugin
function run_at_agency_manager() {
    try {
        new AT_Agency_Manager_Private_CDN_Updater(
            'at-agency-sites-manager',
            AT_AGENCY_MANAGER_BASENAME,
            AT_AGENCY_MANAGER_VERSION,
            'https://updates.amiteam.io/at-agency-sites-manager/plugin-info.json'
        );

        // Always-on suite core: stays active even when all modules are disabled.
        $suite_core = AT_Agency_Manager_Suite_Core::get_instance();

        $i18n = new AT_Agency_Manager_i18n();
        $i18n->load_plugin_textdomain();
        
        $logger = new AT_Agency_Manager_Logger();
        $smtp = new AT_Agency_Manager_SMTP($logger);
        $settings = new AT_Agency_Manager_Settings($logger);
        $branding = new AT_Agency_Manager_Branding();
        $api = new AT_Agency_Manager_API($logger);

        // Register base services for cross-plugin communication.
        $suite_core->register_service('logger', $logger, array('owner' => 'at-agency-manager'));
        $suite_core->register_service('api', $api, array('owner' => 'at-agency-manager'));

        // Initialize Development Manager for WP_DEVELOPMENT_MODE support
        $development_manager = new AT_Agency_Manager_Development_Manager();

        // Initialize Webhook Manager for external notifications
        $webhook_manager = new AT_Agency_Manager_Webhook_Manager($logger);

        // Initialize WordPress Abilities API integration
        $abilities_api = new AT_Agency_Manager_Abilities_API($logger);
        
        // Initialize Admin Bar Versions
        AT_Agency_Manager_Admin_Bar_Versions::add_default_versions();
        AT_Agency_Manager_Admin_Bar_Versions::init();
        
        // Initialize Ecosystem Manager
        AT_Agency_Manager_Ecosystem::init();
        $suite_core->emit_event('ecosystem_initialized', array(
            'owner' => 'at-agency-manager',
        ));
        
        // Register Site Health checks
        AT_Agency_Manager_Environment::register_site_health_checks();
        
        // Add link to settings in plugins page
        add_filter('plugin_action_links_' . AT_AGENCY_MANAGER_BASENAME, function($links) {
            $settings_link = '<a href="' . admin_url('admin.php?page=at-agency-manager') . '">' . __('Settings', 'at-agency-manager') . '</a>';
            array_unshift($links, $settings_link);
            return $links;
        });

        // Add suite badge to plugin row
        add_filter('plugin_row_meta', function($meta, $plugin_file) {
            if ($plugin_file === AT_AGENCY_MANAGER_BASENAME) {
                $meta[] = '<span style="color: var(--at-color-primary, #4ec5e0); font-weight: 600;">AT Suite Core</span>';
                if (defined('AT_SUITE_CONTRACT_VERSION')) {
                    $meta[] = sprintf(
                        '<span class="at-suite-badge" style="display:inline-block;padding:2px 8px;background:rgba(78,197,224,0.1);border:1px solid rgba(78,197,224,0.3);border-radius:4px;font-size:11px;color:var(--at-color-primary,#4ec5e0);">Contract v%s</span>',
                        esc_html(AT_SUITE_CONTRACT_VERSION)
                    );
                }
            }
            return $meta;
        }, 10, 2);
        
        // Add admin notice if WordPress Abilities API is not loaded
        if (!$abilities_api->is_loaded()) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-warning is-dismissible">';
                echo '<p>' . __('WordPress Abilities API is not installed or activated. Some features related to AI assistants may not work. Please install the Abilities API plugin or package.', 'at-agency-manager') . '</p>';
                echo '</div>';
            });
        }
    } catch (Exception $e) {
        // Log the error but don't crash the site
        if (defined('WP_DEBUG_LOG') && WP_DEBUG_LOG) {
            error_log('[AT Agency Manager] Error during initialization: ' . $e->getMessage());
        }
    }
}

// Hook the plugin initialization - must run before admin_menu to register pages
// init hook runs before admin_menu, and our current_user fix ensures user is loaded
add_action('init', 'run_at_agency_manager', 1);
