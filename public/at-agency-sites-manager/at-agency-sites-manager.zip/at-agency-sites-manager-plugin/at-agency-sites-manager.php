<?php

/**
 * Plugin Name: AT Agency Sites Manager
 * Description: Secure remote management, monitoring and control for WordPress sites.
 * Version: 1.0.0-beta.3
 * Author: Amit Trabelsi
 * Author URI: https://atd.digital
 * Text Domain: at-agency-manager
 * Domain Path: /languages
 * Requires at least: 6.4
 * Requires PHP: 8.1
 * Update URI: https://updates.amiteam.io/at-agency-sites-manager/plugin-info.json
 * Tested up to: 6.9
 * License: GPL v2 or later
 */

defined('ABSPATH') || exit;

define('AT_AGENCY_MANAGER_VERSION', '1.0.0-beta.3');
define('AT_AGENCY_MANAGER_SCHEMA_VERSION', '2.1.0');
define('AT_AGENCY_MANAGER_PATH', plugin_dir_path(__FILE__));
define('AT_AGENCY_MANAGER_URL', plugin_dir_url(__FILE__));
define('AT_AGENCY_MANAGER_BASENAME', plugin_basename(__FILE__));
define('AT_AGENCY_MANAGER_LOADED', true);

require_once AT_AGENCY_MANAGER_PATH . 'includes/class-private-cdn-updater.php';
require_once AT_AGENCY_MANAGER_PATH . 'src/V2/Autoload.php';

use AT\AgencyManager\V2\PluginRuntime;

new AT_Agency_Manager_Private_CDN_Updater(
    'at-agency-sites-manager',
    AT_AGENCY_MANAGER_BASENAME,
    AT_AGENCY_MANAGER_VERSION,
    'https://updates.amiteam.io/at-agency-sites-manager/plugin-info.json'
);

register_activation_hook(__FILE__, array(PluginRuntime::class, 'activate'));
register_deactivation_hook(__FILE__, array(PluginRuntime::class, 'deactivate'));
register_uninstall_hook(__FILE__, array(PluginRuntime::class, 'uninstall'));

PluginRuntime::instance()->boot();

if (!function_exists('at_sites_runtime')) {
    function at_sites_runtime(): PluginRuntime
    {
        return PluginRuntime::instance();
    }
}
