=== AT Sites Manager ===
Contributors: amittrabelsi
Requires at least: 6.4
Tested up to: 6.9
Requires PHP: 8.1
Stable tag: 1.0.0-beta.2
License: GPLv2 or later

Secure, control-only WordPress agent for AT Sites Manager.

== Description ==

Fresh installations enable pairing, inventory, health, audit and signed remote command handling only.
Optional site modules remain disabled until explicitly enabled.

== Changelog ==

= 1.0.0-beta.2 =
* Introduces the signed v2 control plane and zero-module installation mode.
* Adds the isolated at-plugin-telemetry/1.0 integration registry.
