<?php

namespace AT\AgencyManager\V2;

use AT\AgencyManager\V2\Admin\ConnectionPage;
use AT\AgencyManager\V2\Commands\WordPressCommandHandler;
use AT\AgencyManager\V2\Contracts\CommandHandler;
use AT\AgencyManager\V2\Contracts\Runtime;
use AT\AgencyManager\V2\Domain\Command;
use AT\AgencyManager\V2\Domain\CommandContext;
use AT\AgencyManager\V2\Domain\Job;
use AT\AgencyManager\V2\Http\LegacyController;
use AT\AgencyManager\V2\Http\RestController;
use AT\AgencyManager\V2\Infrastructure\ConnectionStore;
use AT\AgencyManager\V2\Infrastructure\Migrator;
use AT\AgencyManager\V2\Modules\ModuleLoader;
use AT\AgencyManager\V2\Security\Crypto;
use AT\AgencyManager\V2\Security\Policy;
use AT\AgencyManager\V2\Security\ReplayGuard;
use AT\AgencyManager\V2\Services\AuditLog;
use AT\AgencyManager\V2\Services\CapabilityRegistry;
use AT\AgencyManager\V2\Services\CommandBus;
use AT\AgencyManager\V2\Services\ExchangeService;
use AT\AgencyManager\V2\Services\IntegrationRegistry;
use AT\AgencyManager\V2\Services\JobStore;
use AT\AgencyManager\V2\Services\PairingService;
use AT\AgencyManager\V2\Services\SnapshotService;
use Throwable;

final class PluginRuntime implements Runtime
{
    private static ?self $instance = null;
    private ?CapabilityRegistry $registry = null;
    private ?CommandBus $bus = null;
    private ?SnapshotService $snapshots = null;
    private ?ExchangeService $exchange = null;

    public static function instance(): self
    {
        return self::$instance ??= new self();
    }

    public function boot(): void
    {
        add_filter('cron_schedules', array($this, 'cronSchedules'));
        add_action('plugins_loaded', array($this, 'initialize'), 5);
    }

    public function initialize(): void
    {
        if (!$this->requirementsMet()) {
            add_action('admin_notices', array($this, 'requirementsNotice'));
            return;
        }

        $migrator = new Migrator();
        $migrator->maybeMigrate();
        $connections = new ConnectionStore();
        $crypto = new Crypto();
        $audit = new AuditLog();
        $jobs = new JobStore();
        $integrations = new IntegrationRegistry();
        do_action('at_control_register_integrations', $integrations);
        $this->snapshots = new SnapshotService($integrations);
        $this->registry = new CapabilityRegistry();
        $this->registry->register(new WordPressCommandHandler($this->snapshots));
        do_action('at_control_register_capabilities', $this->registry);
        $this->bus = new CommandBus($this->registry, $jobs, $audit, new Policy());
        $this->exchange = new ExchangeService($connections, $crypto, new ReplayGuard(), $this->snapshots, $jobs, $this->bus, $this->registry, $audit);
        $pairing = new PairingService($connections, $crypto, $audit);

        add_action('rest_api_init', array(new RestController($connections, $this->exchange), 'register'));
        add_action('rest_api_init', array(new LegacyController($this->snapshots), 'register'));
        add_action(Migrator::CRON_HOOK, array($this, 'runExchange'));
        (new ConnectionPage($connections, $pairing, $this->exchange))->hooks();
        (new ModuleLoader())->loadEnabled();
    }

    /** @param array<string, array<string, mixed>> $schedules @return array<string, array<string, mixed>> */
    public function cronSchedules(array $schedules): array
    {
        $schedules['at_control_minute'] = array('interval' => 60, 'display' => 'AT Control every minute');
        return $schedules;
    }

    public function runExchange(): void
    {
        if (!$this->exchange) {
            return;
        }
        try {
            $this->exchange->exchange();
            delete_option('at_control_last_exchange_error');
        } catch (Throwable $error) {
            update_option('at_control_last_exchange_error', sanitize_text_field($error->getMessage()), false);
        }
    }

    public function registerCapability(string $name, CommandHandler $handler): void
    {
        if (!$this->registry) {
            throw new \LogicException('Runtime has not initialized.');
        }
        if (!in_array($name, $handler->capabilities(), true)) {
            throw new \InvalidArgumentException('Handler does not declare the requested capability.');
        }
        $this->registry->register($handler);
    }

    public function snapshot(array $sections = array()): array
    {
        if (!$this->snapshots) {
            throw new \LogicException('Runtime has not initialized.');
        }
        return $this->snapshots->collect($sections);
    }

    public function submit(Command $command, CommandContext $context): Job
    {
        if (!$this->bus) {
            throw new \LogicException('Runtime has not initialized.');
        }
        return $this->bus->submit($command, $context);
    }

    public static function activate(): void
    {
        if (version_compare(PHP_VERSION, '8.1', '<') || !extension_loaded('sodium')) {
            wp_die('AT Agency Sites Manager requires PHP 8.1 or newer and the Sodium extension.');
        }
        global $wp_version;
        if (version_compare((string) $wp_version, '6.4', '<')) {
            wp_die('AT Agency Sites Manager requires WordPress 6.4 or newer.');
        }
        (new Migrator())->migrate();
    }

    public static function deactivate(): void
    {
        (new Migrator())->deactivate();
    }

    public static function uninstall(): void
    {
        if (!defined('WP_UNINSTALL_PLUGIN')) {
            return;
        }
        (new Migrator())->uninstall();
    }

    public function requirementsNotice(): void
    {
        echo '<div class="notice notice-error"><p>' . esc_html__('AT Agency Sites Manager requires WordPress 6.4+, PHP 8.1+ and Sodium.', 'at-agency-manager') . '</p></div>';
    }

    private function requirementsMet(): bool
    {
        global $wp_version;
        return version_compare(PHP_VERSION, '8.1', '>=') && version_compare((string) $wp_version, '6.4', '>=') && extension_loaded('sodium');
    }
}
