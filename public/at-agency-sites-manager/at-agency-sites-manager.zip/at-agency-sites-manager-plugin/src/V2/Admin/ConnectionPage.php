<?php

namespace AT\AgencyManager\V2\Admin;

use AT\AgencyManager\V2\Infrastructure\ConnectionStore;
use AT\AgencyManager\V2\Modules\ModuleLoader;
use AT\AgencyManager\V2\Services\ExchangeService;
use AT\AgencyManager\V2\Services\PairingService;
use Throwable;

final class ConnectionPage
{
    public function __construct(
        private readonly ConnectionStore $connections,
        private readonly PairingService $pairing,
        private readonly ExchangeService $exchange
    ) {
    }

    public function hooks(): void
    {
        add_action('admin_menu', array($this, 'menu'));
        add_action('admin_post_at_control_pair', array($this, 'pair'));
        add_action('admin_post_at_control_disconnect', array($this, 'disconnect'));
        add_action('admin_post_at_control_sync', array($this, 'sync'));
        add_action('admin_post_at_control_only', array($this, 'controlOnly'));
        add_filter('plugin_action_links_' . AT_AGENCY_MANAGER_BASENAME, array($this, 'actionLinks'));
    }

    public function menu(): void
    {
        add_management_page('AT Site Control', 'AT Site Control', 'manage_options', 'at-site-control', array($this, 'render'));
    }

    /** @param list<string> $links @return list<string> */
    public function actionLinks(array $links): array
    {
        array_unshift($links, '<a href="' . esc_url(admin_url('tools.php?page=at-site-control')) . '">' . esc_html__('Remote control', 'at-agency-manager') . '</a>');
        return $links;
    }

    public function pair(): void
    {
        $this->guard('at_control_pair');
        try {
            $this->pairing->enroll(sanitize_text_field(wp_unslash($_POST['pairing_code'] ?? '')));
            $this->redirect('paired');
        } catch (Throwable $error) {
            $this->redirect('error', $error->getMessage());
        }
    }

    public function disconnect(): void
    {
        $this->guard('at_control_disconnect');
        $this->pairing->revoke();
        $this->redirect('disconnected');
    }

    public function sync(): void
    {
        $this->guard('at_control_sync');
        try {
            $this->exchange->exchange();
            $this->redirect('synced');
        } catch (Throwable $error) {
            $this->redirect('error', $error->getMessage());
        }
    }

    public function controlOnly(): void
    {
        $this->guard('at_control_only');
        update_option('at_agency_manager_modules', array_fill_keys(ModuleLoader::catalog(), 0), false);
        $this->redirect('control_only');
    }

    public function render(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Insufficient permissions.', 'at-agency-manager'));
        }
        $connection = $this->connections->get();
        $notice = sanitize_key(wp_unslash($_GET['at_notice'] ?? ''));
        $message = sanitize_text_field(wp_unslash($_GET['at_message'] ?? ''));
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('AT Site Remote Control', 'at-agency-manager'); ?></h1>
            <?php if ($notice) : ?>
                <div class="notice <?php echo 'error' === $notice ? 'notice-error' : 'notice-success'; ?>"><p><?php echo esc_html($message ?: $notice); ?></p></div>
            <?php endif; ?>
            <?php if ($this->connections->isConnected()) : ?>
                <p><strong><?php esc_html_e('Connected', 'at-agency-manager'); ?></strong></p>
                <p><?php echo esc_html((string) ($connection['connection_id'] ?? '')); ?></p>
                <p><?php printf(esc_html__('Last exchange: %s', 'at-agency-manager'), esc_html((string) get_option('at_control_last_exchange_at', 'Never'))); ?></p>
                <?php $this->buttonForm('at_control_sync', 'at_control_sync', __('Sync now', 'at-agency-manager')); ?>
                <?php $this->buttonForm('at_control_disconnect', 'at_control_disconnect', __('Disconnect', 'at-agency-manager'), true); ?>
            <?php else : ?>
                <p><?php esc_html_e('Create a pairing session in Agency Site Manager, then enter the one-time code below.', 'at-agency-manager'); ?></p>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <input type="hidden" name="action" value="at_control_pair">
                    <?php wp_nonce_field('at_control_pair'); ?>
                    <label for="pairing_code"><?php esc_html_e('Pairing code', 'at-agency-manager'); ?></label>
                    <input id="pairing_code" name="pairing_code" type="text" class="regular-text code" required autocomplete="off">
                    <?php submit_button(__('Connect', 'at-agency-manager')); ?>
                </form>
            <?php endif; ?>
            <hr>
            <h2><?php esc_html_e('Optional modules', 'at-agency-manager'); ?></h2>
            <p><?php esc_html_e('New installations keep every optional module disabled. This action disables all modules on an upgraded site.', 'at-agency-manager'); ?></p>
            <?php $this->buttonForm('at_control_only', 'at_control_only', __('Switch to control-only mode', 'at-agency-manager'), true); ?>
        </div>
        <?php
    }

    private function buttonForm(string $action, string $nonce, string $label, bool $secondary = false): void
    {
        ?>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline-block;margin-right:8px">
            <input type="hidden" name="action" value="<?php echo esc_attr($action); ?>">
            <?php wp_nonce_field($nonce); ?>
            <?php submit_button($label, $secondary ? 'secondary' : 'primary', 'submit', false); ?>
        </form>
        <?php
    }

    private function guard(string $action): void
    {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('Insufficient permissions.', 'at-agency-manager'));
        }
        check_admin_referer($action);
    }

    private function redirect(string $notice, string $message = ''): never
    {
        wp_safe_redirect(add_query_arg(array('page' => 'at-site-control', 'at_notice' => $notice, 'at_message' => $message), admin_url('tools.php')));
        exit;
    }
}
