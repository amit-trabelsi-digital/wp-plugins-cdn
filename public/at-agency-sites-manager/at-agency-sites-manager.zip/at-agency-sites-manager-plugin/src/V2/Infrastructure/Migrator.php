<?php

namespace AT\AgencyManager\V2\Infrastructure;

final class Migrator
{
    public const CRON_HOOK = 'at_control_exchange';

    /** @var array<string, int> */
    private const MODULE_DEFAULTS = array(
        'activity_log' => 0, 'site_health' => 0, 'hide_login' => 0,
        'acf_copy_tool' => 0, 'acf_elementor_tag' => 0, 'acf_local_json' => 0,
        'email_log' => 0, 'backup' => 0, 'url_shortener' => 0,
        'page_ordering' => 0, 's3_media_sync' => 0, 'newrelic_monitoring' => 0,
        'protected_files' => 0, 'gf_autofill' => 0,
    );

    public function maybeMigrate(): void
    {
        if (AT_AGENCY_MANAGER_SCHEMA_VERSION !== get_option('at_control_schema_version')) {
            $this->migrate();
        }
    }

    public function migrate(): void
    {
        global $wpdb;
        $upgradeApi = wp_normalize_path(ABSPATH . 'wp-admin/includes/upgrade.php');
        require_once $upgradeApi;
        $collate = $wpdb->get_charset_collate();
        $jobs = $wpdb->prefix . 'at_control_jobs';
        $audit = $wpdb->prefix . 'at_control_audit';

        dbDelta("CREATE TABLE {$jobs} (
            id varchar(64) NOT NULL,
            idempotency_key varchar(128) NOT NULL,
            command_name varchar(100) NOT NULL,
            state varchar(20) NOT NULL DEFAULT 'queued',
            payload longtext NOT NULL,
            result longtext NULL,
            error longtext NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY idempotency_key (idempotency_key),
            KEY state_created (state, created_at)
        ) {$collate};");

        dbDelta("CREATE TABLE {$audit} (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            event_type varchar(100) NOT NULL,
            actor varchar(191) NULL,
            command_id varchar(64) NULL,
            outcome varchar(30) NOT NULL,
            context longtext NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY (id),
            KEY event_created (event_type, created_at),
            KEY command_id (command_id)
        ) {$collate};");

        if (false === get_option('at_agency_manager_modules', false)) {
            add_option('at_agency_manager_modules', self::MODULE_DEFAULTS, '', false);
        }
        if (false === get_option('at_control_delete_data_on_uninstall', false)) {
            add_option('at_control_delete_data_on_uninstall', 0, '', false);
        }
        if (get_option('at_agency_manager_auth_key', '')) {
            add_option('at_control_legacy_bridge_enabled', 1, '', false);
        }

        update_option('at_control_schema_version', AT_AGENCY_MANAGER_SCHEMA_VERSION, false);
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time() + random_int(30, 180), 'at_control_minute', self::CRON_HOOK);
        }
    }

    public function deactivate(): void
    {
        wp_clear_scheduled_hook(self::CRON_HOOK);
        delete_option('at_control_command_lock');
    }

    public function uninstall(): void
    {
        if (!get_option('at_control_delete_data_on_uninstall', false)) {
            return;
        }
        global $wpdb;
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}at_control_jobs");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}at_control_audit");
        foreach (array('at_control_schema_version', 'at_control_connection', 'at_control_legacy_bridge_enabled', 'at_control_delete_data_on_uninstall', 'at_control_command_lock') as $option) {
            delete_option($option);
        }
    }
}
