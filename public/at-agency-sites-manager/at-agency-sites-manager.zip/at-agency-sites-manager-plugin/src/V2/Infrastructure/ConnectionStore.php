<?php

namespace AT\AgencyManager\V2\Infrastructure;

final class ConnectionStore
{
    private const OPTION = 'at_control_connection';

    /** @return array<string, mixed> */
    public function get(): array
    {
        $value = get_option(self::OPTION, array());
        return is_array($value) ? $value : array();
    }

    /** @param array<string, mixed> $connection */
    public function save(array $connection): void
    {
        if (false === get_option(self::OPTION, false)) {
            add_option(self::OPTION, $connection, '', false);
            return;
        }
        update_option(self::OPTION, $connection, false);
    }

    public function revoke(): void
    {
        delete_option(self::OPTION);
    }

    public function isConnected(): bool
    {
        $connection = $this->get();
        return !empty($connection['connection_id']) && !empty($connection['server_public_key']) && !empty($connection['encrypted_private_key']);
    }
}
