<?php

namespace AT\AgencyManager\V2\Domain;

final class Job
{
    /** @param array<string, mixed>|null $error */
    public function __construct(
        public readonly string $id,
        public readonly string $state,
        public readonly mixed $result = null,
        public readonly ?array $error = null
    ) {
    }

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return array_filter(
            array(
                'id' => $this->id,
                'state' => $this->state,
                'result' => $this->result,
                'error' => $this->error,
            ),
            static fn (mixed $value): bool => null !== $value
        );
    }
}
