<?php

namespace AT\AgencyManager\V2\Domain;

final class CommandContext
{
    /** @param array<string, mixed> $actor */
    public function __construct(
        public readonly array $actor,
        public readonly string $approvalLevel,
        public readonly string $traceId,
        public readonly ?string $approvalToken = null
    ) {
    }
}
