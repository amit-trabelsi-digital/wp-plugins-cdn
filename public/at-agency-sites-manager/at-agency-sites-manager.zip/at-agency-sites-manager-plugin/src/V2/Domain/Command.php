<?php

namespace AT\AgencyManager\V2\Domain;

use InvalidArgumentException;

final class Command
{
    /** @param array<string, mixed> $input @param array<string, mixed> $preconditions */
    public function __construct(
        public readonly string $id,
        public readonly string $name,
        public readonly array $input,
        public readonly string $idempotencyKey,
        public readonly int $issuedAt,
        public readonly int $expiresAt,
        public readonly array $preconditions = array()
    ) {
        if (!preg_match('/^[a-z][a-z0-9_.-]+$/', $name)) {
            throw new InvalidArgumentException('Invalid command name.');
        }
        if ('' === $id || '' === $idempotencyKey) {
            throw new InvalidArgumentException('Command and idempotency identifiers are required.');
        }
        if ($expiresAt <= $issuedAt) {
            throw new InvalidArgumentException('Command expiry must follow issue time.');
        }
    }

    /** @param array<string, mixed> $payload */
    public static function fromArray(array $payload): self
    {
        return new self(
            trim((string) ($payload['id'] ?? '')),
            trim((string) ($payload['name'] ?? '')),
            is_array($payload['input'] ?? null) ? $payload['input'] : array(),
            trim((string) ($payload['idempotency_key'] ?? '')),
            (int) ($payload['issued_at'] ?? 0),
            (int) ($payload['expires_at'] ?? 0),
            is_array($payload['preconditions'] ?? null) ? $payload['preconditions'] : array()
        );
    }
}
