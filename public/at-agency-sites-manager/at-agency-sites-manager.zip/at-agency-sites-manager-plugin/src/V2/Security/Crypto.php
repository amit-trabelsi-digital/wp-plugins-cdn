<?php

namespace AT\AgencyManager\V2\Security;

use RuntimeException;

final class Crypto
{
    /** @return array{public_key:string, encrypted_private_key:string} */
    public function generateKeyPair(): array
    {
        if (!extension_loaded('sodium')) {
            throw new RuntimeException('The Sodium extension is required for pairing.');
        }

        $pair = sodium_crypto_sign_keypair();
        return array(
            'public_key' => base64_encode(sodium_crypto_sign_publickey($pair)),
            'encrypted_private_key' => $this->encrypt(sodium_crypto_sign_secretkey($pair)),
        );
    }

    public function sign(array $payload, string $encryptedPrivateKey): string
    {
        $privateKey = $this->decrypt($encryptedPrivateKey);
        try {
            return base64_encode(sodium_crypto_sign_detached(CanonicalJson::encode($payload), $privateKey));
        } finally {
            sodium_memzero($privateKey);
        }
    }

    public function verify(array $payload, string $signature, string $publicKey): bool
    {
        $decodedSignature = base64_decode($signature, true);
        $decodedPublicKey = base64_decode($publicKey, true);
        if (false === $decodedSignature || false === $decodedPublicKey) {
            return false;
        }
        if (SODIUM_CRYPTO_SIGN_BYTES !== strlen($decodedSignature) || SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES !== strlen($decodedPublicKey)) {
            return false;
        }

        return sodium_crypto_sign_verify_detached($decodedSignature, CanonicalJson::encode($payload), $decodedPublicKey);
    }

    private function encrypt(string $plaintext): string
    {
        $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        $ciphertext = sodium_crypto_secretbox($plaintext, $nonce, $this->encryptionKey());
        sodium_memzero($plaintext);
        return base64_encode($nonce . $ciphertext);
    }

    private function decrypt(string $encoded): string
    {
        $payload = base64_decode($encoded, true);
        if (false === $payload || strlen($payload) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES) {
            throw new RuntimeException('Stored private key is invalid.');
        }

        $nonce = substr($payload, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        $plaintext = sodium_crypto_secretbox_open(substr($payload, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES), $nonce, $this->encryptionKey());
        if (false === $plaintext) {
            throw new RuntimeException('Stored private key cannot be decrypted.');
        }
        return $plaintext;
    }

    private function encryptionKey(): string
    {
        return hash('sha256', wp_salt('auth') . '|' . wp_salt('secure_auth') . '|at-control-v2', true);
    }
}
