<?php

namespace AT\AgencyManager\V2\Security;

use WP_Error;

final class Policy
{
    private const AUTOMATIC = array(
        'snapshot.refresh', 'health.get', 'diagnostics.run', 'cache.purge',
        'plugin.update', 'theme.update',
    );

    private const DESTRUCTIVE = array(
        'plugin.delete', 'theme.delete', 'user.delete', 'user.promote_admin',
    );

    public function authorize(string $command, string $approvalLevel, ?string $approvalToken = null): bool|WP_Error
    {
        if (in_array($command, self::AUTOMATIC, true)) {
            return true;
        }

        $required = in_array($command, self::DESTRUCTIVE, true) ? 'step_up' : 'confirmed';
        $levels = array('none' => 0, 'confirmed' => 1, 'step_up' => 2);
        if (($levels[$approvalLevel] ?? 0) < $levels[$required]) {
            return new WP_Error('at_control_approval_required', 'This command requires a higher approval level.', array('status' => 403, 'required' => $required));
        }
        if (!$approvalToken) {
            return new WP_Error('at_control_approval_token_required', 'This command requires a signed short-lived approval token.', array('status' => 403, 'required' => $required));
        }

        return true;
    }
}
