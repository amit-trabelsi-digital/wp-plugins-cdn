<?php

namespace AT\AgencyManager\V2\Security;

final class ReplayGuard
{
    public function consume(string $connectionId, string $nonce, int $expiresAt): bool
    {
        if ('' === $nonce || $expiresAt <= time()) {
            return false;
        }

        $key = 'at_cp_' . hash('sha256', $connectionId . '|' . $nonce);
        if (!wp_cache_add($key, 1, 'at_control_replay', max(1, $expiresAt - time()))) {
            return false;
        }
        if (false !== get_transient($key)) {
            return false;
        }
        set_transient($key, 1, max(1, $expiresAt - time()));
        return true;
    }
}
