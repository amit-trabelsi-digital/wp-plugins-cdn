<?php

namespace AT\AgencyManager\V2\Services;

use AT\AgencyManager\V2\Infrastructure\ConnectionStore;
use AT\AgencyManager\V2\Security\Crypto;
use RuntimeException;

final class PairingService
{
    public function __construct(
        private readonly ConnectionStore $connections,
        private readonly Crypto $crypto,
        private readonly AuditLog $audit
    ) {
    }

    /** @return array<string, mixed> */
    public function enroll(string $code): array
    {
        $code = strtoupper(preg_replace('/[^A-Z0-9-]/i', '', $code));
        if (strlen($code) < 8) {
            throw new RuntimeException('A valid pairing code is required.');
        }
        $keys = $this->crypto->generateKeyPair();
        $endpoint = $this->endpoint('agent-control');
        $response = wp_safe_remote_post(
            $endpoint,
            array(
                'timeout' => 20,
                'redirection' => 0,
                'headers' => array('Content-Type' => 'application/json'),
                'body' => wp_json_encode(
                    array(
                        'op' => 'enroll',
                        'pairing_code' => $code,
                        'site_url' => home_url('/'),
                        'agent_public_key' => $keys['public_key'],
                        'agent_version' => AT_AGENCY_MANAGER_VERSION,
                        'wp_version' => get_bloginfo('version'),
                    )
                ),
            )
        );
        if (is_wp_error($response)) {
            throw new RuntimeException($response->get_error_message());
        }
        $status = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($status < 200 || $status >= 300 || !is_array($body) || empty($body['connection_id']) || empty($body['server_public_key'])) {
            throw new RuntimeException(is_array($body) && !empty($body['error']) ? sanitize_text_field((string) $body['error']) : 'Pairing failed.');
        }
        $connection = array(
            'connection_id' => sanitize_text_field((string) $body['connection_id']),
            'site_id' => sanitize_text_field((string) ($body['site_id'] ?? '')),
            'agent_public_key' => $keys['public_key'],
            'encrypted_private_key' => $keys['encrypted_private_key'],
            'server_public_key' => sanitize_text_field((string) $body['server_public_key']),
            'exchange_url' => esc_url_raw((string) ($body['exchange_url'] ?? $this->endpoint('agent-exchange'))),
            'paired_at' => gmdate('c'),
        );
        $this->connections->save($connection);
        delete_option('at_agency_manager_auth_key');
        update_option('at_control_legacy_bridge_enabled', 0, false);
        $this->audit->record('connection.paired', 'succeeded', array('connection_id' => $connection['connection_id']), null, (string) get_current_user_id());
        return $connection;
    }

    public function revoke(): void
    {
        $connection = $this->connections->get();
        $this->connections->revoke();
        $this->audit->record('connection.revoked', 'succeeded', array('connection_id' => $connection['connection_id'] ?? null), null, (string) get_current_user_id());
    }

    private function endpoint(string $function): string
    {
        $base = (string) apply_filters('at_control_plane_base_url', 'https://zjosyyjygxwxtcgfwbgf.supabase.co/functions/v1');
        $url = trailingslashit($base) . sanitize_key($function);
        if (!$this->isAllowedUrl($url)) {
            throw new RuntimeException('Control plane URL is not approved.');
        }
        return $url;
    }

    private function isAllowedUrl(string $url): bool
    {
        $host = wp_parse_url($url, PHP_URL_HOST);
        $allowed = (array) apply_filters('at_control_plane_hosts', array('zjosyyjygxwxtcgfwbgf.supabase.co'));
        return 'https' === wp_parse_url($url, PHP_URL_SCHEME) && $host && in_array(strtolower($host), array_map('strtolower', $allowed), true);
    }
}
