<?php

namespace AT\AgencyManager\V2\Services;

use AT\AgencyManager\V2\Domain\Command;
use AT\AgencyManager\V2\Domain\Job;

final class JobStore
{
    /** @return list<array<string, mixed>> */
    public function latest(int $limit = 20): array
    {
        global $wpdb;
        $limit = max(1, min(100, $limit));
        $rows = $wpdb->get_results("SELECT id, command_name, state, result, error, updated_at FROM {$wpdb->prefix}at_control_jobs ORDER BY updated_at DESC LIMIT {$limit}", ARRAY_A);
        return array_map(
            static fn (array $row): array => array(
                'id' => $row['id'],
                'name' => $row['command_name'],
                'state' => $row['state'],
                'result' => $row['result'] ? json_decode((string) $row['result'], true) : null,
                'error' => $row['error'] ? json_decode((string) $row['error'], true) : null,
                'updated_at' => mysql2date('c', (string) $row['updated_at'], false),
            ),
            is_array($rows) ? $rows : array()
        );
    }

    public function findByIdempotencyKey(string $key): ?Job
    {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}at_control_jobs WHERE idempotency_key = %s", $key), ARRAY_A);
        return $row ? $this->hydrate($row) : null;
    }

    public function create(Command $command): Job
    {
        global $wpdb;
        $now = current_time('mysql', true);
        $wpdb->insert(
            $wpdb->prefix . 'at_control_jobs',
            array(
                'id' => $command->id,
                'idempotency_key' => $command->idempotencyKey,
                'command_name' => $command->name,
                'state' => 'queued',
                'payload' => wp_json_encode($command->input),
                'created_at' => $now,
                'updated_at' => $now,
            ),
            array('%s', '%s', '%s', '%s', '%s', '%s', '%s')
        );
        return new Job($command->id, 'queued');
    }

    public function complete(string $id, mixed $result): Job
    {
        $this->update($id, 'succeeded', $result, null);
        return new Job($id, 'succeeded', $result);
    }

    /** @param array<string, mixed> $error */
    public function fail(string $id, array $error): Job
    {
        $this->update($id, 'failed', null, $error);
        return new Job($id, 'failed', null, $error);
    }

    private function update(string $id, string $state, mixed $result, ?array $error): void
    {
        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . 'at_control_jobs',
            array(
                'state' => $state,
                'result' => null === $result ? null : wp_json_encode($result),
                'error' => null === $error ? null : wp_json_encode($error),
                'updated_at' => current_time('mysql', true),
            ),
            array('id' => $id),
            array('%s', '%s', '%s', '%s'),
            array('%s')
        );
    }

    /** @param array<string, mixed> $row */
    private function hydrate(array $row): Job
    {
        return new Job(
            (string) $row['id'],
            (string) $row['state'],
            $row['result'] ? json_decode((string) $row['result'], true) : null,
            $row['error'] ? json_decode((string) $row['error'], true) : null
        );
    }
}
