<?php

namespace AT\AgencyManager\V2\Services;

use AT\AgencyManager\V2\Domain\Command;
use AT\AgencyManager\V2\Domain\CommandContext;
use AT\AgencyManager\V2\Domain\Job;
use AT\AgencyManager\V2\Security\Policy;
use Throwable;

final class CommandBus
{
    public function __construct(
        private readonly CapabilityRegistry $registry,
        private readonly JobStore $jobs,
        private readonly AuditLog $audit,
        private readonly Policy $policy
    ) {
    }

    public function submit(Command $command, CommandContext $context): Job
    {
        $lockToken = bin2hex(random_bytes(16));
        if (!$this->acquireLock($lockToken)) {
            return new Job($command->id, 'rejected', null, array('code' => 'agent_busy', 'retryable' => true));
        }
        try {
            return $this->submitLocked($command, $context);
        } finally {
            $this->releaseLock($lockToken);
        }
    }

    private function submitLocked(Command $command, CommandContext $context): Job
    {
        if ($command->expiresAt <= time() || $command->issuedAt > time() + 300) {
            return new Job($command->id, 'rejected', null, array('code' => 'expired_command', 'retryable' => false));
        }
        $existing = $this->jobs->findByIdempotencyKey($command->idempotencyKey);
        if ($existing) {
            return $existing;
        }
        $authorization = $this->policy->authorize($command->name, $context->approvalLevel, $context->approvalToken);
        if (is_wp_error($authorization)) {
            return new Job($command->id, 'rejected', null, array('code' => $authorization->get_error_code(), 'message' => $authorization->get_error_message(), 'retryable' => false));
        }
        $handler = $this->registry->resolve($command->name);
        if (!$handler) {
            return new Job($command->id, 'rejected', null, array('code' => 'unsupported_capability', 'retryable' => false));
        }

        $this->jobs->create($command);
        $this->audit->record('command.accepted', 'accepted', array('name' => $command->name), $command->id, (string) ($context->actor['id'] ?? 'system'));
        try {
            $result = $handler->execute($command, $context);
            if (is_wp_error($result)) {
                throw new \RuntimeException($result->get_error_message(), (int) $result->get_error_code());
            }
            $this->audit->record('command.completed', 'succeeded', array('name' => $command->name), $command->id, (string) ($context->actor['id'] ?? 'system'));
            return $this->jobs->complete($command->id, $result);
        } catch (Throwable $error) {
            $payload = array('code' => 'execution_failed', 'message' => $error->getMessage(), 'retryable' => false);
            $this->audit->record('command.completed', 'failed', array('name' => $command->name, 'error' => $error->getMessage()), $command->id, (string) ($context->actor['id'] ?? 'system'));
            return $this->jobs->fail($command->id, $payload);
        }
    }

    private function acquireLock(string $token): bool
    {
        $current = get_option('at_control_command_lock', array());
        if (is_array($current) && isset($current['created_at']) && (int) $current['created_at'] < time() - 900) {
            delete_option('at_control_command_lock');
        }
        return add_option('at_control_command_lock', array('token' => $token, 'created_at' => time()), '', false);
    }

    private function releaseLock(string $token): void
    {
        $current = get_option('at_control_command_lock', array());
        if (is_array($current) && hash_equals((string) ($current['token'] ?? ''), $token)) {
            delete_option('at_control_command_lock');
        }
    }
}
