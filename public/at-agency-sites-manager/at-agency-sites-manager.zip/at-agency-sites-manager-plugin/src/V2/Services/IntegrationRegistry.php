<?php

namespace AT\AgencyManager\V2\Services;

use InvalidArgumentException;
use Throwable;

final class IntegrationRegistry
{
    /** @var array<string, callable(): array<string, mixed>> */
    private array $providers = array();

    /** @param callable(): array<string, mixed> $provider */
    public function register(string $id, callable $provider): void
    {
        $id = sanitize_key($id);
        if ('' === $id || isset($this->providers[$id])) {
            throw new InvalidArgumentException('Integration IDs must be unique, non-empty slugs.');
        }
        $this->providers[$id] = $provider;
    }

    /** @return array<string, array<string, mixed>> */
    public function collect(): array
    {
        $integrations = array();
        foreach ($this->providers as $id => $provider) {
            try {
                $integrations[$id] = $this->normalize($id, $provider());
            } catch (Throwable) {
                $integrations[$id] = array(
                    'id' => $id,
                    'name' => $id,
                    'version' => null,
                    'status' => 'error',
                    'status_reason' => 'provider_failed',
                    'capabilities' => array(),
                    'metrics' => array(),
                    'links' => array(),
                );
            }
        }
        ksort($integrations);
        return $integrations;
    }

    /** @return list<string> */
    public function manifest(): array
    {
        $ids = array_keys($this->providers);
        sort($ids);
        return $ids;
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function normalize(string $id, array $data): array
    {
        $allowedStatuses = array('ready', 'degraded', 'error', 'disabled', 'unknown');
        $status = sanitize_key((string) ($data['status'] ?? 'unknown'));
        if (!in_array($status, $allowedStatuses, true)) {
            $status = 'unknown';
        }

        $capabilities = array_values(array_unique(array_filter(array_map(
            static function ($capability): string {
                $capability = strtolower((string) $capability);
                return preg_replace('/[^a-z0-9_.-]/', '', $capability) ?? '';
            },
            is_array($data['capabilities'] ?? null) ? $data['capabilities'] : array()
        ))));
        sort($capabilities);

        $metrics = is_array($data['metrics'] ?? null) ? $data['metrics'] : array();
        $links = is_array($data['links'] ?? null) ? $data['links'] : array();

        return array(
            'id' => $id,
            'name' => sanitize_text_field((string) ($data['name'] ?? $id)),
            'version' => isset($data['version']) ? sanitize_text_field((string) $data['version']) : null,
            'status' => $status,
            'status_reason' => isset($data['status_reason']) ? sanitize_text_field((string) $data['status_reason']) : null,
            'capabilities' => $capabilities,
            'metrics' => $this->sanitizeMap($metrics),
            'links' => $this->sanitizeLinks($links),
        );
    }

    /**
     * @param array<string, mixed> $values
     * @return array<string, scalar|null>
     */
    private function sanitizeMap(array $values): array
    {
        $sanitized = array();
        foreach ($values as $key => $value) {
            if (is_scalar($value) || null === $value) {
                $sanitized[sanitize_key((string) $key)] = is_string($value)
                    ? sanitize_text_field($value)
                    : $value;
            }
        }
        return $sanitized;
    }

    /**
     * @param array<string, mixed> $links
     * @return array<string, string>
     */
    private function sanitizeLinks(array $links): array
    {
        $sanitized = array();
        foreach ($links as $key => $value) {
            if (!is_string($value)) {
                continue;
            }
            $url = esc_url_raw($value);
            if ('' !== $url) {
                $sanitized[sanitize_key((string) $key)] = $url;
            }
        }
        return $sanitized;
    }
}
