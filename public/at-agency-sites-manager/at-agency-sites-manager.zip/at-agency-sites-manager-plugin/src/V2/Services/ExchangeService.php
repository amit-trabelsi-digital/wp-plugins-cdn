<?php

namespace AT\AgencyManager\V2\Services;

use AT\AgencyManager\V2\Domain\Command;
use AT\AgencyManager\V2\Domain\CommandContext;
use AT\AgencyManager\V2\Infrastructure\ConnectionStore;
use AT\AgencyManager\V2\Security\Crypto;
use AT\AgencyManager\V2\Security\ReplayGuard;
use RuntimeException;

final class ExchangeService
{
    public function __construct(
        private readonly ConnectionStore $connections,
        private readonly Crypto $crypto,
        private readonly ReplayGuard $replay,
        private readonly SnapshotService $snapshots,
        private readonly JobStore $jobs,
        private readonly CommandBus $commands,
        private readonly CapabilityRegistry $capabilities,
        private readonly AuditLog $audit
    ) {
    }

    /** @return array<string, mixed> */
    public function exchange(): array
    {
        $connection = $this->connections->get();
        if (!$this->connections->isConnected()) {
            return array('status' => 'not_connected');
        }
        $body = array(
            'connection_id' => $connection['connection_id'],
            'heartbeat' => array('sent_at' => gmdate('c'), 'agent_version' => AT_AGENCY_MANAGER_VERSION),
            'manifest' => array(
                'protocol' => 'at-control/2.0',
                'capabilities' => $this->capabilities->manifest(),
                'integration_contract' => 'at-plugin-telemetry/1.0',
            ),
            'snapshot' => $this->snapshots->collect(),
            'results' => $this->jobs->latest(),
        );
        $envelope = array(
            'protocol' => 'at-control/2.0',
            'connection_id' => $connection['connection_id'],
            'timestamp' => time(),
            'expires_at' => time() + 300,
            'nonce' => bin2hex(random_bytes(16)),
            'body' => $body,
        );
        $envelope['signature'] = $this->crypto->sign($envelope, (string) $connection['encrypted_private_key']);

        $url = (string) $connection['exchange_url'];
        if (!$this->isAllowedUrl($url)) {
            throw new RuntimeException('Exchange URL is not approved.');
        }
        $response = wp_safe_remote_post($url, array('timeout' => 25, 'redirection' => 0, 'headers' => array('Content-Type' => 'application/json'), 'body' => wp_json_encode($envelope)));
        if (is_wp_error($response)) {
            throw new RuntimeException($response->get_error_message());
        }
        $status = wp_remote_retrieve_response_code($response);
        $payload = json_decode(wp_remote_retrieve_body($response), true);
        if ($status < 200 || $status >= 300 || !is_array($payload)) {
            throw new RuntimeException('Control plane exchange failed.');
        }
        $this->verifyServerEnvelope($payload, $connection);

        $completed = array();
        foreach ((array) ($payload['body']['commands'] ?? array()) as $item) {
            if (!is_array($item)) {
                continue;
            }
            $command = Command::fromArray($item);
            $context = new CommandContext(
                is_array($item['actor'] ?? null) ? $item['actor'] : array('id' => 'system'),
                sanitize_key((string) ($item['approval_level'] ?? 'none')),
                sanitize_text_field((string) ($item['trace_id'] ?? $command->id)),
                !empty($item['approval_token']) ? sanitize_text_field((string) $item['approval_token']) : null
            );
            $completed[] = $this->commands->submit($command, $context)->toArray();
        }
        update_option('at_control_last_exchange_at', gmdate('c'), false);
        $this->audit->record('exchange.completed', 'succeeded', array('commands' => count($completed)));
        return array('status' => 'ok', 'commands' => $completed);
    }

    /** @param array<string, mixed> $payload @param array<string, mixed> $connection */
    public function verifyServerEnvelope(array $payload, array $connection): void
    {
        $signature = (string) ($payload['signature'] ?? '');
        unset($payload['signature']);
        if (!$this->crypto->verify($payload, $signature, (string) $connection['server_public_key'])) {
            throw new RuntimeException('Invalid control plane signature.');
        }
        if ((int) ($payload['expires_at'] ?? 0) <= time() || (int) ($payload['timestamp'] ?? 0) > time() + 300) {
            throw new RuntimeException('Control plane response expired.');
        }
        if (!$this->replay->consume((string) $connection['connection_id'], (string) ($payload['nonce'] ?? ''), (int) $payload['expires_at'])) {
            throw new RuntimeException('Control plane response was replayed.');
        }
    }

    private function isAllowedUrl(string $url): bool
    {
        $host = wp_parse_url($url, PHP_URL_HOST);
        $allowed = (array) apply_filters('at_control_plane_hosts', array('zjosyyjygxwxtcgfwbgf.supabase.co'));
        return 'https' === wp_parse_url($url, PHP_URL_SCHEME) && $host && in_array(strtolower($host), array_map('strtolower', $allowed), true);
    }
}
