<?php

namespace AT\AgencyManager\V2\Services;

final class AuditLog
{
    private const REDACT_KEYS = array('password', 'token', 'secret', 'private_key', 'authorization', 'api_key');

    /** @param array<string, mixed> $context */
    public function record(string $event, string $outcome, array $context = array(), ?string $commandId = null, ?string $actor = null): void
    {
        global $wpdb;
        $wpdb->insert(
            $wpdb->prefix . 'at_control_audit',
            array(
                'event_type' => sanitize_key($event),
                'actor' => $actor ? sanitize_text_field($actor) : null,
                'command_id' => $commandId ? sanitize_text_field($commandId) : null,
                'outcome' => sanitize_key($outcome),
                'context' => wp_json_encode($this->redact($context)),
                'created_at' => current_time('mysql', true),
            ),
            array('%s', '%s', '%s', '%s', '%s', '%s')
        );
    }

    private function redact(mixed $value, string $key = ''): mixed
    {
        if (in_array(strtolower($key), self::REDACT_KEYS, true)) {
            return '[REDACTED]';
        }
        if (!is_array($value)) {
            return $value;
        }
        foreach ($value as $childKey => $childValue) {
            $value[$childKey] = $this->redact($childValue, (string) $childKey);
        }
        return $value;
    }
}
