<?php

namespace AT\AgencyManager\V2\Services;

use AT\AgencyManager\V2\Contracts\CommandHandler;

final class CapabilityRegistry
{
    /** @var array<string, CommandHandler> */
    private array $handlers = array();

    public function register(CommandHandler $handler): void
    {
        foreach ($handler->capabilities() as $capability) {
            $this->handlers[$capability] = $handler;
        }
    }

    public function resolve(string $capability): ?CommandHandler
    {
        return $this->handlers[$capability] ?? null;
    }

    /** @return list<string> */
    public function manifest(): array
    {
        $capabilities = array_keys($this->handlers);
        sort($capabilities);
        return $capabilities;
    }
}
