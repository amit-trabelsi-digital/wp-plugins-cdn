<?php

namespace AT\AgencyManager\V2\Services;

final class SnapshotService
{
    public function __construct(private readonly IntegrationRegistry $integrations)
    {
    }

    /** @return array<string, mixed> */
    public function collect(array $sections = array(), bool $fresh = false): array
    {
        $sections = $sections ?: array('site', 'health', 'software', 'users', 'modules', 'integrations', 'agent');
        $cacheKey = 'at_control_snapshot_' . md5(wp_json_encode($sections));
        if (!$fresh) {
            $cached = get_transient($cacheKey);
            if (is_array($cached)) {
                return $cached;
            }
        }

        $snapshot = array(
            'captured_at' => gmdate('c'),
            'fresh_for_seconds' => 60,
            'fresh_until' => gmdate('c', time() + 60),
        );
        if (in_array('site', $sections, true)) {
            global $wp_version;
            $snapshot['site'] = array(
                'name' => get_bloginfo('name'),
                'url' => home_url('/'),
                'environment' => wp_get_environment_type(),
                'wp_version' => $wp_version,
                'php_version' => PHP_VERSION,
                'multisite' => is_multisite(),
            );
        }
        if (in_array('health', $sections, true)) {
            global $wpdb;
            $uploads = wp_upload_dir();
            $snapshot['health'] = array(
                'database' => (bool) $wpdb->check_connection(false),
                'filesystem' => empty($uploads['error']) && wp_is_writable($uploads['basedir']),
                'cron_disabled' => defined('DISABLE_WP_CRON') && DISABLE_WP_CRON,
                'https' => is_ssl() || str_starts_with(home_url('/'), 'https://'),
            );
        }
        if (in_array('software', $sections, true)) {
            $snapshot['software'] = $this->software();
        }
        if (in_array('users', $sections, true)) {
            $snapshot['users'] = array_map(
                static fn (\WP_User $user): array => array(
                    'id' => $user->ID,
                    'username' => $user->user_login,
                    'roles' => array_values($user->roles),
                    'registered' => $user->user_registered,
                ),
                get_users(array('fields' => 'all'))
            );
        }
        if (in_array('modules', $sections, true)) {
            $snapshot['modules'] = get_option('at_agency_manager_modules', array());
        }
        if (in_array('integrations', $sections, true)) {
            $snapshot['integrations'] = $this->integrations->collect();
        }
        if (in_array('agent', $sections, true)) {
            $exchangeError = (string) get_option('at_control_last_exchange_error', '');
            $cronDisabled = defined('DISABLE_WP_CRON') && DISABLE_WP_CRON;
            $snapshot['agent'] = array(
                'version' => AT_AGENCY_MANAGER_VERSION,
                'protocol' => 'at-control/2.0',
                'last_exchange_at' => get_option('at_control_last_exchange_at'),
                'status' => $cronDisabled || '' !== $exchangeError ? 'degraded' : 'ready',
                'degraded_reason' => $cronDisabled ? 'wp_cron_disabled' : ($exchangeError ?: null),
                'manual_sync_available' => true,
            );
        }

        $snapshot['etag'] = hash('sha256', wp_json_encode($snapshot));
        set_transient($cacheKey, $snapshot, 60);
        return $snapshot;
    }

    /** @return array<string, mixed> */
    private function software(): array
    {
        if (!function_exists('get_plugins')) {
            $pluginApi = wp_normalize_path(ABSPATH . 'wp-admin/includes/plugin.php');
            require_once $pluginApi;
        }
        $active = (array) get_option('active_plugins', array());
        $updates = get_site_transient('update_plugins');
        $plugins = array();
        foreach (get_plugins() as $file => $data) {
            $plugins[] = array(
                'id' => $file,
                'name' => $data['Name'],
                'version' => $data['Version'],
                'active' => in_array($file, $active, true),
                'available' => isset($updates->response[$file]) ? $updates->response[$file]->new_version : null,
            );
        }
        $themes = array();
        $themeUpdates = get_site_transient('update_themes');
        foreach (wp_get_themes() as $slug => $theme) {
            $themes[] = array(
                'id' => $slug,
                'name' => $theme->get('Name'),
                'version' => $theme->get('Version'),
                'active' => get_stylesheet() === $slug,
                'available' => $themeUpdates->response[$slug]['new_version'] ?? null,
            );
        }
        return array('plugins' => $plugins, 'themes' => $themes);
    }
}
