<?php

namespace AT\AgencyManager\V2\Contracts;

use AT\AgencyManager\V2\Domain\Command;
use AT\AgencyManager\V2\Domain\CommandContext;
use AT\AgencyManager\V2\Domain\Job;

interface Runtime
{
    public function registerCapability(string $name, CommandHandler $handler): void;

    /** @return array<string, mixed> */
    public function snapshot(array $sections = array()): array;

    public function submit(Command $command, CommandContext $context): Job;
}
