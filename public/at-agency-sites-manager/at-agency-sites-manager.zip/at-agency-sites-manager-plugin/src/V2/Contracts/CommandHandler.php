<?php

namespace AT\AgencyManager\V2\Contracts;

use AT\AgencyManager\V2\Domain\Command;
use AT\AgencyManager\V2\Domain\CommandContext;

interface CommandHandler
{
    /** @return list<string> */
    public function capabilities(): array;

    public function execute(Command $command, CommandContext $context): mixed;
}
