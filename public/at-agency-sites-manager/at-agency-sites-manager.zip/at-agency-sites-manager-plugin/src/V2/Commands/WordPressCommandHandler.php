<?php

namespace AT\AgencyManager\V2\Commands;

use AT\AgencyManager\V2\Contracts\CommandHandler;
use AT\AgencyManager\V2\Domain\Command;
use AT\AgencyManager\V2\Domain\CommandContext;
use AT\AgencyManager\V2\Modules\ModuleLoader;
use AT\AgencyManager\V2\Services\SnapshotService;
use RuntimeException;
use WP_Error;

final class WordPressCommandHandler implements CommandHandler
{
    private const CAPABILITIES = array(
        'snapshot.refresh', 'health.get', 'diagnostics.run', 'cache.purge',
        'plugin.install', 'plugin.update', 'plugin.activate', 'plugin.deactivate', 'plugin.delete',
        'theme.install', 'theme.update', 'theme.activate', 'theme.delete', 'core.update',
        'user.create', 'user.update', 'user.delete', 'user.promote_admin',
        'module.set', 'maintenance.set', 'settings.patch',
    );

    public function __construct(private readonly SnapshotService $snapshots)
    {
    }

    public function capabilities(): array
    {
        return self::CAPABILITIES;
    }

    public function execute(Command $command, CommandContext $context): mixed
    {
        if (is_multisite() && !empty($command->input['network_wide'])) {
            throw new RuntimeException('Network-wide commands are not supported by protocol v2.0.');
        }
        $this->assertPreconditions($command);
        return match ($command->name) {
            'snapshot.refresh' => $this->snapshots->collect(array(), true),
            'health.get' => $this->snapshots->collect(array('health', 'agent'), true),
            'diagnostics.run' => $this->diagnostics(),
            'cache.purge' => $this->purgeCache(),
            'plugin.install' => $this->installPlugin($command->input),
            'plugin.update' => $this->updatePlugin($command->input),
            'plugin.activate' => $this->activatePlugin($command->input),
            'plugin.deactivate' => $this->deactivatePlugin($command->input),
            'plugin.delete' => $this->deletePlugin($command->input),
            'theme.install' => $this->installTheme($command->input),
            'theme.update' => $this->updateTheme($command->input),
            'theme.activate' => $this->activateTheme($command->input),
            'theme.delete' => $this->deleteTheme($command->input),
            'core.update' => $this->updateCore(),
            'user.create' => $this->createUser($command->input, $context),
            'user.update' => $this->updateUser($command->input, $context, false),
            'user.promote_admin' => $this->updateUser($command->input, $context, true),
            'user.delete' => $this->deleteUser($command->input),
            'module.set' => $this->setModule($command->input),
            'maintenance.set' => $this->setMaintenance($command->input),
            'settings.patch' => $this->patchSettings($command->input),
            default => throw new RuntimeException('Unsupported command.'),
        };
    }

    private function installPlugin(array $input): array
    {
        $this->loadUpgrader();
        $package = $this->approvedPackage($input, 'plugin');
        $upgrader = new \Plugin_Upgrader(new \Automatic_Upgrader_Skin());
        $result = $upgrader->install($package);
        $this->assertUpgraderResult($result, $upgrader);
        return array('installed' => true, 'plugin' => $upgrader->plugin_info());
    }

    private function updatePlugin(array $input): array
    {
        $plugin = $this->pluginId($input);
        $this->loadUpgrader();
        wp_update_plugins();
        $upgrader = new \Plugin_Upgrader(new \Automatic_Upgrader_Skin());
        $result = $upgrader->upgrade($plugin);
        $this->assertUpgraderResult($result, $upgrader);
        return array('plugin' => $plugin, 'updated' => true);
    }

    private function activatePlugin(array $input): array
    {
        $plugin = $this->pluginId($input);
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        $result = activate_plugin($plugin, '', false, true);
        if (is_wp_error($result)) {
            throw new RuntimeException($result->get_error_message());
        }
        return array('plugin' => $plugin, 'active' => true);
    }

    private function deactivatePlugin(array $input): array
    {
        $plugin = $this->pluginId($input);
        $this->assertNotSelf($plugin);
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        deactivate_plugins($plugin, true, false);
        return array('plugin' => $plugin, 'active' => false);
    }

    private function deletePlugin(array $input): array
    {
        $plugin = $this->pluginId($input);
        $this->assertNotSelf($plugin);
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        if (is_plugin_active($plugin)) {
            throw new RuntimeException('Active plugins must be deactivated before deletion.');
        }
        $result = delete_plugins(array($plugin));
        if (is_wp_error($result)) {
            throw new RuntimeException($result->get_error_message());
        }
        return array('plugin' => $plugin, 'deleted' => true);
    }

    private function installTheme(array $input): array
    {
        $this->loadUpgrader();
        $package = $this->approvedPackage($input, 'theme');
        $upgrader = new \Theme_Upgrader(new \Automatic_Upgrader_Skin());
        $result = $upgrader->install($package);
        $this->assertUpgraderResult($result, $upgrader);
        return array('installed' => true);
    }

    private function updateTheme(array $input): array
    {
        $theme = sanitize_key((string) ($input['theme'] ?? ''));
        if ('' === $theme) {
            throw new RuntimeException('Theme is required.');
        }
        $this->loadUpgrader();
        wp_update_themes();
        $upgrader = new \Theme_Upgrader(new \Automatic_Upgrader_Skin());
        $result = $upgrader->upgrade($theme);
        $this->assertUpgraderResult($result, $upgrader);
        return array('theme' => $theme, 'updated' => true);
    }

    private function activateTheme(array $input): array
    {
        $theme = sanitize_key((string) ($input['theme'] ?? ''));
        if (!wp_get_theme($theme)->exists()) {
            throw new RuntimeException('Theme does not exist.');
        }
        switch_theme($theme);
        return array('theme' => $theme, 'active' => true);
    }

    private function deleteTheme(array $input): array
    {
        $theme = sanitize_key((string) ($input['theme'] ?? ''));
        if (get_stylesheet() === $theme || get_template() === $theme) {
            throw new RuntimeException('The active theme cannot be deleted.');
        }
        require_once ABSPATH . 'wp-admin/includes/theme.php';
        $result = delete_theme($theme);
        if (is_wp_error($result)) {
            throw new RuntimeException($result->get_error_message());
        }
        return array('theme' => $theme, 'deleted' => true);
    }

    private function updateCore(): array
    {
        $this->loadUpgrader();
        wp_version_check(array(), true);
        $updates = get_core_updates(array('dismissed' => false));
        $update = is_array($updates) ? current(array_filter($updates, static fn ($item): bool => 'upgrade' === $item->response)) : false;
        if (!$update) {
            return array('updated' => false, 'reason' => 'already_current');
        }
        $upgrader = new \Core_Upgrader(new \Automatic_Upgrader_Skin());
        $result = $upgrader->upgrade($update);
        $this->assertUpgraderResult($result, $upgrader);
        return array('updated' => true, 'version' => $update->current);
    }

    private function createUser(array $input, CommandContext $context): array
    {
        $username = sanitize_user((string) ($input['username'] ?? ''), true);
        $email = sanitize_email((string) ($input['email'] ?? ''));
        $role = sanitize_key((string) ($input['role'] ?? 'subscriber'));
        if ('' === $username || !is_email($email) || !get_role($role)) {
            throw new RuntimeException('Valid username, email and role are required.');
        }
        if ('administrator' === $role && 'step_up' !== $context->approvalLevel) {
            throw new RuntimeException('Creating an administrator requires step-up approval.');
        }
        $password = wp_generate_password(32, true, true);
        $id = wp_create_user($username, $password, $email);
        if (is_wp_error($id)) {
            throw new RuntimeException($id->get_error_message());
        }
        (new \WP_User($id))->set_role($role);
        wp_new_user_notification($id, null, 'user');
        return array('user_id' => $id, 'invite_sent' => true);
    }

    private function updateUser(array $input, CommandContext $context, bool $promotion): array
    {
        $id = absint($input['user_id'] ?? 0);
        $user = get_user_by('id', $id);
        if (!$user) {
            throw new RuntimeException('User not found.');
        }
        if (!empty($input['email']) && !is_email($input['email'])) {
            throw new RuntimeException('Invalid email.');
        }
        $payload = array('ID' => $id);
        if (!empty($input['email'])) {
            $payload['user_email'] = sanitize_email((string) $input['email']);
        }
        $result = wp_update_user($payload);
        if (is_wp_error($result)) {
            throw new RuntimeException($result->get_error_message());
        }
        if (!empty($input['role'])) {
            $role = sanitize_key((string) $input['role']);
            if (!get_role($role)) {
                throw new RuntimeException('Invalid role.');
            }
            if ('administrator' === $role && (!$promotion || 'step_up' !== $context->approvalLevel)) {
                throw new RuntimeException('Administrator promotion requires its dedicated step-up command.');
            }
            $user->set_role($role);
        }
        return array('user_id' => $id, 'updated' => true);
    }

    private function deleteUser(array $input): array
    {
        $id = absint($input['user_id'] ?? 0);
        $user = get_user_by('id', $id);
        if (!$user) {
            throw new RuntimeException('User not found.');
        }
        if (in_array('administrator', $user->roles, true)) {
            $admins = get_users(array('role' => 'administrator', 'fields' => 'ids'));
            if (count($admins) <= 1) {
                throw new RuntimeException('The last administrator cannot be deleted.');
            }
        }
        require_once ABSPATH . 'wp-admin/includes/user.php';
        if (!wp_delete_user($id, absint($input['reassign_to'] ?? 0) ?: null)) {
            throw new RuntimeException('User deletion failed.');
        }
        return array('user_id' => $id, 'deleted' => true);
    }

    private function setModule(array $input): array
    {
        $module = sanitize_key((string) ($input['module'] ?? ''));
        if (!in_array($module, ModuleLoader::catalog(), true)) {
            throw new RuntimeException('Unknown module.');
        }
        if ('s3_media_sync' === $module && !empty($input['enabled']) && !class_exists('Aws\\S3\\S3Client')) {
            throw new RuntimeException('The S3 module requires an approved optional AWS provider.');
        }
        $modules = get_option('at_agency_manager_modules', array());
        $modules[$module] = !empty($input['enabled']) ? 1 : 0;
        update_option('at_agency_manager_modules', $modules, false);
        return array('module' => $module, 'enabled' => (bool) $modules[$module], 'effective_after_reload' => true);
    }

    private function setMaintenance(array $input): array
    {
        $this->loadUpgrader();
        $enabled = !empty($input['enabled']);
        (new \WP_Upgrader(new \Automatic_Upgrader_Skin()))->maintenance_mode($enabled);
        return array('enabled' => $enabled);
    }

    private function patchSettings(array $input): array
    {
        $allowlist = (array) apply_filters('at_control_settings_allowlist', array('blogname', 'blogdescription', 'timezone_string', 'date_format', 'time_format'));
        $values = is_array($input['values'] ?? null) ? $input['values'] : array();
        $updated = array();
        foreach ($values as $key => $value) {
            $key = sanitize_key((string) $key);
            if (!in_array($key, $allowlist, true) || !is_scalar($value)) {
                continue;
            }
            update_option($key, sanitize_text_field((string) $value));
            $updated[] = $key;
        }
        return array('updated' => $updated);
    }

    private function diagnostics(): array
    {
        global $wpdb;
        $uploads = wp_upload_dir();
        return array(
            'database' => (bool) $wpdb->check_connection(false),
            'uploads_writable' => empty($uploads['error']) && wp_is_writable($uploads['basedir']),
            'disk_free_bytes' => @disk_free_space(ABSPATH) ?: null,
            'cron_disabled' => defined('DISABLE_WP_CRON') && DISABLE_WP_CRON,
            'sodium' => extension_loaded('sodium'),
        );
    }

    private function purgeCache(): array
    {
        wp_cache_flush();
        return array('purged' => true);
    }

    private function pluginId(array $input): string
    {
        $plugin = plugin_basename(sanitize_text_field((string) ($input['plugin'] ?? '')));
        if ('' === $plugin || !str_contains($plugin, '.php')) {
            throw new RuntimeException('Plugin identifier is required.');
        }
        return $plugin;
    }

    private function assertNotSelf(string $plugin): void
    {
        if (AT_AGENCY_MANAGER_BASENAME === $plugin) {
            throw new RuntimeException('The control agent cannot modify itself.');
        }
    }

    private function assertPreconditions(Command $command): void
    {
        if (isset($command->preconditions['agent_version']) && AT_AGENCY_MANAGER_VERSION !== (string) $command->preconditions['agent_version']) {
            throw new RuntimeException('Agent version precondition failed.');
        }
        if (isset($command->preconditions['wp_version'])) {
            global $wp_version;
            if ((string) $wp_version !== (string) $command->preconditions['wp_version']) {
                throw new RuntimeException('WordPress version precondition failed.');
            }
        }
        if (isset($command->preconditions['plugin_version']) && !empty($command->input['plugin'])) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
            $plugin = $this->pluginId($command->input);
            $plugins = get_plugins();
            if (!isset($plugins[$plugin]) || (string) $plugins[$plugin]['Version'] !== (string) $command->preconditions['plugin_version']) {
                throw new RuntimeException('Plugin version precondition failed.');
            }
        }
    }

    private function approvedPackage(array $input, string $type): string
    {
        if (!empty($input['slug'])) {
            $slug = sanitize_key((string) $input['slug']);
            if ('theme' === $type) {
                require_once ABSPATH . 'wp-admin/includes/theme.php';
                $api = themes_api('theme_information', array('slug' => $slug, 'fields' => array('sections' => false)));
            } else {
                require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
                $api = plugins_api('plugin_information', array('slug' => $slug, 'fields' => array('sections' => false)));
            }
            if (is_wp_error($api) || empty($api->download_link)) {
                throw new RuntimeException(is_wp_error($api) ? $api->get_error_message() : 'Approved package not found.');
            }
            return $api->download_link;
        }

        $url = esc_url_raw((string) ($input['package_url'] ?? ''));
        $checksum = strtolower(sanitize_text_field((string) ($input['sha256'] ?? '')));
        $host = wp_parse_url($url, PHP_URL_HOST);
        $hosts = (array) apply_filters('at_control_approved_artifact_hosts', array('updates.amiteam.io'));
        if (!$host || !in_array(strtolower($host), array_map('strtolower', $hosts), true) || !preg_match('/^[a-f0-9]{64}$/', $checksum)) {
            throw new RuntimeException('Private package source is not approved.');
        }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        $file = download_url($url, 30);
        if (is_wp_error($file)) {
            throw new RuntimeException($file->get_error_message());
        }
        if (!hash_equals($checksum, hash_file('sha256', $file))) {
            @unlink($file);
            throw new RuntimeException('Private package checksum mismatch.');
        }
        return $file;
    }

    private function loadUpgrader(): void
    {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
    }

    private function assertUpgraderResult(mixed $result, \WP_Upgrader $upgrader): void
    {
        if (is_wp_error($result)) {
            throw new RuntimeException($result->get_error_message());
        }
        if (!$result) {
            $errors = $upgrader->skin->get_errors();
            throw new RuntimeException($errors->has_errors() ? $errors->get_error_message() : 'WordPress upgrader failed.');
        }
    }
}
