<?php

namespace AT\AgencyManager\V2\Http;

use AT\AgencyManager\V2\Infrastructure\ConnectionStore;
use AT\AgencyManager\V2\Infrastructure\Migrator;
use AT\AgencyManager\V2\Services\ExchangeService;
use Throwable;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

final class RestController
{
    private ?array $verifiedEnvelope = null;

    public function __construct(
        private readonly ConnectionStore $connections,
        private readonly ExchangeService $exchange
    ) {
    }

    public function register(): void
    {
        register_rest_route(
            'at-sites-manager/v2',
            '/ping',
            array(
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => array($this, 'ping'),
                'permission_callback' => array($this, 'authorize'),
                'args' => array(
                    'protocol' => array('type' => 'string', 'required' => true),
                    'connection_id' => array('type' => 'string', 'required' => true),
                    'timestamp' => array('type' => 'integer', 'required' => true),
                    'expires_at' => array('type' => 'integer', 'required' => true),
                    'nonce' => array('type' => 'string', 'required' => true),
                    'body' => array('type' => 'object', 'required' => true),
                    'signature' => array('type' => 'string', 'required' => true),
                ),
            )
        );
    }

    public function authorize(WP_REST_Request $request): bool|WP_Error
    {
        $connection = $this->connections->get();
        if (!$this->connections->isConnected()) {
            return new WP_Error('at_control_not_connected', 'Site is not paired.', array('status' => 401));
        }
        $envelope = $request->get_json_params();
        if (!is_array($envelope)) {
            return new WP_Error('at_control_invalid_envelope', 'Invalid signed envelope.', array('status' => 400));
        }
        try {
            $this->exchange->verifyServerEnvelope($envelope, $connection);
            $rateKey = 'at_control_ping_rate_' . gmdate('YmdHi');
            $requests = (int) get_transient($rateKey);
            if ($requests >= 30) {
                return new WP_Error('at_control_rate_limited', 'Too many signed pings.', array('status' => 429));
            }
            set_transient($rateKey, $requests + 1, 120);
            $this->verifiedEnvelope = $envelope;
            return true;
        } catch (Throwable $error) {
            return new WP_Error('at_control_unauthorized', $error->getMessage(), array('status' => 401));
        }
    }

    public function ping(): WP_REST_Response
    {
        if (!wp_next_scheduled(Migrator::CRON_HOOK)) {
            wp_schedule_single_event(time() + 1, Migrator::CRON_HOOK);
        }
        return new WP_REST_Response(array('accepted' => true, 'request_id' => $this->verifiedEnvelope['body']['request_id'] ?? null), 202);
    }
}
