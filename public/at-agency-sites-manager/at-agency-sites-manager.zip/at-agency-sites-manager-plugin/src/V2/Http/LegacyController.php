<?php

namespace AT\AgencyManager\V2\Http;

use AT\AgencyManager\V2\Services\SnapshotService;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

final class LegacyController
{
    public function __construct(private readonly SnapshotService $snapshots)
    {
    }

    public function register(): void
    {
        if (!get_option('at_control_legacy_bridge_enabled', false) || !get_option('at_agency_manager_auth_key', '')) {
            return;
        }
        foreach (array('at-sites-mng/v1', 'at-agency-manager/v1') as $namespace) {
            foreach (array('site-info', 'plugins', 'users', 'health') as $route) {
                register_rest_route(
                    $namespace,
                    '/' . $route,
                    array(
                        'methods' => WP_REST_Server::READABLE,
                        'callback' => fn (WP_REST_Request $request): WP_REST_Response => $this->respond($route),
                        'permission_callback' => array($this, 'authorize'),
                    )
                );
            }
        }
    }

    public function authorize(WP_REST_Request $request): bool|WP_Error
    {
        $provided = (string) ($request->get_header('X-AT-Sites-Manager-Key') ?: $request->get_header('X-AT-Agency-Manager-Key'));
        $stored = (string) get_option('at_agency_manager_auth_key', '');
        if ('' === $provided || '' === $stored || !hash_equals($stored, $provided)) {
            return new WP_Error('at_control_legacy_auth_failed', 'Invalid legacy credential.', array('status' => 401));
        }
        return true;
    }

    private function respond(string $route): WP_REST_Response
    {
        $sections = match ($route) {
            'site-info' => array('site', 'agent'),
            'plugins' => array('software'),
            'users' => array('users'),
            'health' => array('health'),
            default => array(),
        };
        $snapshot = $this->snapshots->collect($sections);
        $data = match ($route) {
            'plugins' => array_map(
                static fn (array $plugin): array => array_merge(
                    $plugin,
                    array('needs_update' => !empty($plugin['available']))
                ),
                $snapshot['software']['plugins'] ?? array()
            ),
            'users' => array_map(
                static fn (array $user): array => array_merge($user, array('last_login' => null)),
                $snapshot['users'] ?? array()
            ),
            'health' => array_merge($snapshot['health'] ?? array(), array('smtp' => null)),
            default => array_merge(
                $snapshot['site'] ?? array(),
                array(
                    'version' => $snapshot['site']['wp_version'] ?? null,
                    'last_updated' => $snapshot['captured_at'] ?? gmdate('c'),
                    'agent' => $snapshot['agent'] ?? array(),
                )
            ),
        };
        $response = new WP_REST_Response($data, 200);
        $response->header('Deprecation', 'true');
        $response->header('Sunset', '2026-10-15');
        $response->header('Link', '<' . rest_url('at-sites-manager/v2') . '>; rel="successor-version"');
        return $response;
    }
}
