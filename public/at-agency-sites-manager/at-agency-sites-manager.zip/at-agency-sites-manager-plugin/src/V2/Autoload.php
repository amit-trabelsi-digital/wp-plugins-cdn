<?php

defined('ABSPATH') || exit;

spl_autoload_register(
    static function (string $class): void {
        $prefix = 'AT\\AgencyManager\\V2\\';
        if (!str_starts_with($class, $prefix)) {
            return;
        }

        $relative = substr($class, strlen($prefix));
        $file = __DIR__ . '/' . str_replace('\\', '/', $relative) . '.php';
        if (is_readable($file)) {
            require_once $file;
        }
    }
);
