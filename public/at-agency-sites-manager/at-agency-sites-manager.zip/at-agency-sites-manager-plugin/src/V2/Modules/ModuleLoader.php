<?php

namespace AT\AgencyManager\V2\Modules;

final class ModuleLoader
{
    /** @var array<string, string> */
    private const FILES = array(
        'activity_log' => 'modules/activity-log.php', 'site_health' => 'modules/site-health.php',
        'hide_login' => 'modules/hide-login.php', 'acf_copy_tool' => 'modules/acf-copy-tool.php',
        'acf_local_json' => 'modules/acf-local-json.php', 'email_log' => 'modules/email-log.php',
        'url_shortener' => 'modules/url-shortener/class-url-shortener.php', 'page_ordering' => 'modules/page-ordering.php',
        's3_media_sync' => 'modules/s3-media-sync.php', 'newrelic_monitoring' => 'modules/newrelic-monitoring.php',
        'protected_files' => 'modules/protected-files.php', 'gf_autofill' => 'modules/gf-autofill.php',
    );

    /** @var array<string, non-empty-string> */
    private const PROVIDERS = array(
        's3_media_sync' => 'Aws\\S3\\S3Client',
    );

    public function loadEnabled(): void
    {
        $enabled = get_option('at_agency_manager_modules', array());
        if (!is_array($enabled)) {
            return;
        }
        foreach (self::FILES as $module => $relativePath) {
            if (empty($enabled[$module])) {
                continue;
            }
            if (!$this->providerAvailable($module)) {
                $enabled[$module] = 0;
                update_option('at_agency_manager_modules', $enabled, false);
                update_option('at_control_last_module_error', $module . ': optional provider is unavailable', false);
                continue;
            }
            $file = AT_AGENCY_MANAGER_PATH . $relativePath;
            if (is_readable($file)) {
                require_once $file;
            }
        }
    }

    /** @return list<string> */
    public static function catalog(): array
    {
        return array_keys(self::FILES);
    }

    private function providerAvailable(string $module): bool
    {
        if (!isset(self::PROVIDERS[$module])) {
            return true;
        }
        $available = class_exists(self::PROVIDERS[$module]);
        return (bool) apply_filters('at_control_module_provider_available', $available, $module, self::PROVIDERS[$module]);
    }
}
