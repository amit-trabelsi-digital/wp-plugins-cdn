<?php
namespace AT\AgencyManager\Core;

use AT\AgencyManager\Interfaces\ModuleInterface;

/**
 * מחלקת בסיס לכל המודולים בתוסף
 */
abstract class AbstractModule implements ModuleInterface {
    /**
     * שם המודול
     * @var string
     */
    protected $name;

    /**
     * תיאור המודול
     * @var string
     */
    protected $description;

    /**
     * גרסת המודול
     * @var string
     */
    protected $version;

    /**
     * מופע הלוגר
     * @var Logger
     */
    protected $logger;

    /**
     * אתחול המודול
     */
    public function __construct() {
        $this->logger = new Logger();
        $this->init();
    }

    /**
     * קבלת שם המודול
     * 
     * @return string
     */
    public function getName(): string {
        return $this->name;
    }

    /**
     * קבלת תיאור המודול
     * 
     * @return string
     */
    public function getDescription(): string {
        return $this->description;
    }

    /**
     * קבלת גרסת המודול
     * 
     * @return string
     */
    public function getVersion(): string {
        return $this->version;
    }

    /**
     * רישום אירוע בלוג
     * 
     * @param string $type סוג האירוע
     * @param string $message הודעת האירוע
     * @param string $level רמת האירוע
     */
    protected function log(string $type, string $message, string $level = 'info'): void {
        $this->logger->log($type, $message, $level);
    }

    /**
     * בדיקת הרשאות
     * 
     * @param string $capability ההרשאה הנדרשת
     * @return bool
     */
    protected function checkCapability(string $capability): bool {
        return current_user_can($capability);
    }

    /**
     * בדיקת nonce
     * 
     * @param string $nonce ה-nonce לבדיקה
     * @param string $action הפעולה
     * @return bool
     */
    protected function verifyNonce(string $nonce, string $action): bool {
        return wp_verify_nonce($nonce, $action) !== false;
    }

    /**
     * ניקוי קלט
     * 
     * @param mixed $input הקלט לניקוי
     * @return mixed הקלט המנוקה
     */
    protected function sanitizeInput($input) {
        if (is_array($input)) {
            return array_map([$this, 'sanitizeInput'], $input);
        }
        return sanitize_text_field($input);
    }

    /**
     * ניקוי פלט
     * 
     * @param mixed $output הפלט לניקוי
     * @return mixed הפלט המנוקה
     */
    protected function sanitizeOutput($output) {
        if (is_array($output)) {
            return array_map([$this, 'sanitizeOutput'], $output);
        }
        return esc_html($output);
    }
} 