<?php
namespace AT\AgencyManager\Core;

/**
 * מחלקת הבסיס של התוסף
 * 
 * מחלקה זו אחראית על אתחול התוסף וניהול המחזור החיים שלו
 */
class Plugin {
    /**
     * גרסת התוסף
     * @var string
     */
    private const VERSION = '0.6.0';

    /**
     * מופע יחיד של המחלקה
     * @var Plugin|null
     */
    private static $instance = null;

    /**
     * מחזיר מופע יחיד של המחלקה
     * 
     * @return Plugin
     */
    public static function getInstance(): Plugin {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * אתחול התוסף
     */
    public function init(): void {
        $this->defineConstants();
        $this->loadDependencies();
        $this->initComponents();
        $this->setupHooks();
    }

    /**
     * הגדרת קבועים
     */
    private function defineConstants(): void {
        define('AT_AGENCY_MANAGER_VERSION', self::VERSION);
        define('AT_AGENCY_MANAGER_PATH', plugin_dir_path(dirname(dirname(__FILE__))));
        define('AT_AGENCY_MANAGER_URL', plugin_dir_url(dirname(dirname(__FILE__))));
        define('AT_AGENCY_MANAGER_BASENAME', plugin_basename(dirname(dirname(__FILE__))));
    }

    /**
     * טעינת תלויות
     */
    private function loadDependencies(): void {
        require_once AT_AGENCY_MANAGER_PATH . 'vendor/autoload.php';
    }

    /**
     * אתחול רכיבים
     */
    private function initComponents(): void {
        // אתחול רכיבי הליבה
        new \AT\AgencyManager\Core\I18n();
        new \AT\AgencyManager\Core\Logger();
        new \AT\AgencyManager\Core\Settings();
        new \AT\AgencyManager\Core\Branding();
        new \AT\AgencyManager\Core\API();
    }

    /**
     * הגדרת hooks
     */
    private function setupHooks(): void {
        add_action('plugins_loaded', [$this, 'loadModules']);
        add_filter('plugin_action_links_' . AT_AGENCY_MANAGER_BASENAME, [$this, 'addSettingsLink']);
    }

    /**
     * טעינת מודולים
     */
    public function loadModules(): void {
        $modules = get_option('at_agency_manager_modules', []);
        
        foreach ($modules as $module => $enabled) {
            if ($enabled) {
                $this->loadModule($module);
            }
        }
    }

    /**
     * טעינת מודול ספציפי
     * 
     * @param string $module שם המודול
     */
    private function loadModule(string $module): void {
        $modulePath = AT_AGENCY_MANAGER_PATH . "src/Modules/{$module}/Module.php";
        
        if (file_exists($modulePath)) {
            require_once $modulePath;
            $className = "\\AT\\AgencyManager\\Modules\\{$module}\\Module";
            if (class_exists($className)) {
                new $className();
            }
        }
    }

    /**
     * הוספת קישור להגדרות בדף התוספים
     * 
     * @param array $links קישורים קיימים
     * @return array קישורים מעודכנים
     */
    public function addSettingsLink(array $links): array {
        $settingsLink = '<a href="' . admin_url('admin.php?page=at-agency-manager') . '">' . 
            __('Settings', 'at-agency-manager') . '</a>';
        array_unshift($links, $settingsLink);
        return $links;
    }
} 