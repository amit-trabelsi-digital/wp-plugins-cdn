<?php
namespace AT\AgencyManager\Interfaces;

/**
 * ממשק בסיסי לכל המודולים בתוסף
 */
interface ModuleInterface {
    /**
     * אתחול המודול
     */
    public function init(): void;

    /**
     * הפעלת המודול
     */
    public function activate(): void;

    /**
     * ביטול המודול
     */
    public function deactivate(): void;

    /**
     * קבלת שם המודול
     * 
     * @return string
     */
    public function getName(): string;

    /**
     * קבלת תיאור המודול
     * 
     * @return string
     */
    public function getDescription(): string;

    /**
     * קבלת גרסת המודול
     * 
     * @return string
     */
    public function getVersion(): string;
} 