<?php
namespace AT\AgencyManager\Modules\Security\Services;

/**
 * שירות דיבאג
 */
class DebugService {
    /**
     * אתחול השירות
     */
    public function init(): void {
        if ($this->shouldDisplayDebug()) {
            $this->enableDebug();
        }
    }

    /**
     * בדיקה האם להציג דיבאג
     * 
     * @return bool
     */
    private function shouldDisplayDebug(): bool {
        if (!get_option('at_security_debug_enabled', false)) {
            return false;
        }

        $display = get_option('at_security_debug_display', 'none');
        
        if ($display === 'screen') {
            return true;
        }
        
        if ($display === 'url') {
            $param = get_option('at_security_debug_url_param', 'debug');
            return isset($_GET[$param]);
        }
        
        return false;
    }

    /**
     * הפעלת מצב דיבאג
     */
    private function enableDebug(): void {
        if (!defined('WP_DEBUG')) {
            define('WP_DEBUG', true);
        }
        
        if (!defined('WP_DEBUG_DISPLAY')) {
            define('WP_DEBUG_DISPLAY', true);
        }
        
        if (!defined('WP_DEBUG_LOG')) {
            define('WP_DEBUG_LOG', true);
        }
        
        if (!defined('SCRIPT_DEBUG')) {
            define('SCRIPT_DEBUG', true);
        }
        
        error_reporting(E_ALL);
        ini_set('display_errors', 1);
    }

    /**
     * בדיקת מצב דיבאג
     * 
     * @return array
     */
    public function getDebugStatus(): array {
        return [
            'debug_enabled' => get_option('at_security_debug_enabled', false),
            'debug_display' => get_option('at_security_debug_display', 'none'),
            'debug_url_param' => get_option('at_security_debug_url_param', 'debug'),
            'wp_debug' => defined('WP_DEBUG') && WP_DEBUG,
            'wp_debug_display' => defined('WP_DEBUG_DISPLAY') && WP_DEBUG_DISPLAY,
            'wp_debug_log' => defined('WP_DEBUG_LOG') && WP_DEBUG_LOG,
            'script_debug' => defined('SCRIPT_DEBUG') && SCRIPT_DEBUG,
            'error_reporting' => error_reporting(),
            'display_errors' => ini_get('display_errors'),
            'server_time' => current_time('mysql'),
            'server_timezone' => date_default_timezone_get()
        ];
    }

    /**
     * עדכון הגדרות דיבאג
     * 
     * @param array $settings
     * @return bool
     */
    public function updateDebugSettings(array $settings): bool {
        $allowed_keys = [
            'debug_enabled',
            'debug_display',
            'debug_url_param'
        ];

        foreach ($settings as $key => $value) {
            if (in_array($key, $allowed_keys)) {
                update_option("at_security_{$key}", $value);
            }
        }

        return true;
    }
} 