<?php
namespace AT\AgencyManager\Modules\Security\Services;

/**
 * שירות לוגים
 */
class LogService {
    /**
     * תיקיית הלוגים
     * @var string
     */
    private $logDirectory;

    /**
     * פורמט תאריך
     * @var string
     */
    private $dateFormat;

    /**
     * פורמט שעה
     * @var string
     */
    private $timeFormat;

    /**
     * אזור זמן
     * @var string
     */
    private $timezone;

    /**
     * אתחול השירות
     */
    public function __construct() {
        $this->logDirectory = get_option('at_security_log_directory', WP_CONTENT_DIR . '/logs/at-agency-manager');
        $this->dateFormat = get_option('at_security_log_date_format', 'Y-m-d');
        $this->timeFormat = get_option('at_security_log_time_format', 'H:i:s');
        $this->timezone = get_option('at_security_log_timezone', 'Asia/Jerusalem');
        
        date_default_timezone_set($this->timezone);
    }

    /**
     * יצירת תיקיית הלוגים
     */
    public function createLogDirectory(): void {
        if (!file_exists($this->logDirectory)) {
            wp_mkdir_p($this->logDirectory);
        }
    }

    /**
     * יצירת קובץ .htaccess להגנה על התיקייה
     */
    public function createHtaccessFile(): void {
        $htaccess = $this->logDirectory . '/.htaccess';
        
        if (!file_exists($htaccess)) {
            $content = "Order deny,allow\nDeny from all";
            file_put_contents($htaccess, $content);
        }
    }

    /**
     * הגנה על תיקיית הלוגים
     */
    public function protectLogDirectory(): void {
        if (strpos($_SERVER['REQUEST_URI'], '/wp-content/logs/at-agency-manager') !== false) {
            if (!current_user_can('manage_options')) {
                wp_die('גישה נדחתה', 'שגיאת גישה', ['response' => 403]);
            }
        }
    }

    /**
     * כתיבת לוג
     * 
     * @param string $message
     * @param string $type
     * @return bool
     */
    public function log(string $message, string $type = 'info'): bool {
        if (!get_option('at_security_log_enabled', true)) {
            return false;
        }

        $date = date($this->dateFormat);
        $time = date($this->timeFormat);
        $logFile = $this->logDirectory . "/{$date}.log";
        
        $logMessage = "[{$time}] [{$type}] {$message}\n";
        
        return file_put_contents($logFile, $logMessage, FILE_APPEND) !== false;
    }

    /**
     * כתיבת לוג מייל
     * 
     * @param string $message
     * @return bool
     */
    public function logEmail(string $message): bool {
        if (!get_option('at_security_log_separate_email', true)) {
            return $this->log($message, 'email');
        }

        $date = date($this->dateFormat);
        $time = date($this->timeFormat);
        $logFile = $this->logDirectory . "/{$date}-email.log";
        
        $logMessage = "[{$time}] [email] {$message}\n";
        
        return file_put_contents($logFile, $logMessage, FILE_APPEND) !== false;
    }

    /**
     * לוג שגיאת מייל
     * 
     * @param \WP_Error $error
     */
    public function logEmailError(\WP_Error $error): void {
        $message = sprintf(
            'שגיאת שליחת מייל: %s',
            $error->get_error_message()
        );
        
        $this->logEmail($message);
    }

    /**
     * קבלת רשימת קבצי לוג
     * 
     * @return array
     */
    public function getLogFiles(): array {
        $files = [];
        
        if (is_dir($this->logDirectory)) {
            $items = scandir($this->logDirectory);
            
            foreach ($items as $item) {
                if ($item === '.' || $item === '..' || $item === '.htaccess') {
                    continue;
                }
                
                $path = $this->logDirectory . '/' . $item;
                
                if (is_file($path)) {
                    $files[] = [
                        'name' => $item,
                        'size' => filesize($path),
                        'modified' => filemtime($path),
                        'type' => strpos($item, '-email.log') !== false ? 'email' : 'general'
                    ];
                }
            }
        }
        
        return $files;
    }

    /**
     * קריאת קובץ לוג
     * 
     * @param string $filename
     * @return string|false
     */
    public function readLogFile(string $filename): string|false {
        $path = $this->logDirectory . '/' . basename($filename);
        
        if (!file_exists($path) || !is_file($path)) {
            return false;
        }
        
        return file_get_contents($path);
    }

    /**
     * עדכון הגדרות לוג
     * 
     * @param array $settings
     * @return bool
     */
    public function updateLogSettings(array $settings): bool {
        $allowed_keys = [
            'log_enabled',
            'log_directory',
            'log_separate_email',
            'log_timezone',
            'log_date_format',
            'log_time_format'
        ];

        foreach ($settings as $key => $value) {
            if (in_array($key, $allowed_keys)) {
                update_option("at_security_{$key}", $value);
            }
        }

        return true;
    }
} 