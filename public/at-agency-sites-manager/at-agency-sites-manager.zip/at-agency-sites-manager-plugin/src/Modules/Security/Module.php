<?php
namespace AT\AgencyManager\Modules\Security;

use AT\AgencyManager\Core\AbstractModule;
use AT\AgencyManager\Modules\Security\Services\DebugService;
use AT\AgencyManager\Modules\Security\Services\LogService;
use AT\AgencyManager\Modules\Security\Controllers\SecurityController;

/**
 * מודול אבטחה
 */
class Module extends AbstractModule {
    /**
     * שם המודול
     * @var string
     */
    protected $name = 'security';

    /**
     * תיאור המודול
     * @var string
     */
    protected $description = 'מודול אבטחה עם יכולות דיבאג ולוגים';

    /**
     * גרסת המודול
     * @var string
     */
    protected $version = '1.0.0';

    /**
     * שירות הדיבאג
     * @var DebugService
     */
    private $debugService;

    /**
     * שירות הלוגים
     * @var LogService
     */
    private $logService;

    /**
     * בקר האבטחה
     * @var SecurityController
     */
    private $controller;

    /**
     * אתחול המודול
     */
    public function init(): void {
        $this->debugService = new DebugService();
        $this->logService = new LogService();
        $this->controller = new SecurityController($this->debugService, $this->logService);

        // רישום הוקים
        add_action('admin_menu', [$this->controller, 'registerMenu']);
        add_action('admin_init', [$this->controller, 'registerSettings']);
        add_action('rest_api_init', [$this->controller, 'registerRoutes']);
        
        // הוקים לדיבאג ולוגים
        add_action('init', [$this->debugService, 'init']);
        add_action('wp_mail_failed', [$this->logService, 'logEmailError']);
        
        // הגנה על תיקיית הלוגים
        add_action('init', [$this->logService, 'protectLogDirectory']);
    }

    /**
     * הפעלת המודול
     */
    public function activate(): void {
        // יצירת תיקיית הלוגים
        $this->logService->createLogDirectory();
        
        // יצירת קובץ .htaccess להגנה על התיקייה
        $this->logService->createHtaccessFile();
        
        // הגדרות ברירת מחדל
        $this->setDefaultSettings();
    }

    /**
     * ביטול המודול
     */
    public function deactivate(): void {
        // לא מוחקים את הלוגים בביטול המודול
    }

    /**
     * הגדרת הגדרות ברירת מחדל
     */
    private function setDefaultSettings(): void {
        $defaults = [
            'debug_enabled' => false,
            'debug_display' => 'none', // none, screen, url
            'debug_url_param' => 'debug',
            'log_enabled' => true,
            'log_directory' => WP_CONTENT_DIR . '/logs/at-agency-manager',
            'log_separate_email' => true,
            'log_timezone' => 'Asia/Jerusalem',
            'log_date_format' => 'Y-m-d',
            'log_time_format' => 'H:i:s'
        ];

        foreach ($defaults as $key => $value) {
            if (get_option("at_security_{$key}") === false) {
                update_option("at_security_{$key}", $value);
            }
        }
    }
} 