<?php
/**
 * מחלקה לניהול נקודות הקצה של ה-API
 */
class AT_Agency_Manager_API {
    /**
     * @var string מרחב השמות של ה-API
     */
    private $api_namespace = 'at-agency-manager/v1';
    
    /**
     * @var string מפתח האימות
     */
    private $auth_key;
    
    /**
     * @var AT_Agency_Manager_Logger מופע של מחלקת הלוגר
     */
    private $logger;

    /**
     * אתחול המחלקה וטעינת מפתח האימות
     * 
     * @param AT_Agency_Manager_Logger $logger מופע של מחלקת הלוגר
     */
    public function __construct($logger) {
        $this->logger = $logger;
        $this->auth_key = get_option('at_agency_manager_auth_key');
        
        add_action('rest_api_init', array($this, 'register_routes'));
    }

    /**
     * רישום נקודות קצה של ה-API
     */
    public function register_routes() {
        // בדיקה אם Remote API מותר
        $remote_api_allowed = AT_Agency_Manager_Environment::is_remote_api_allowed();
        
        // רישום endpoints בסיסיים - זמינים תמיד (עם אימות)
        register_rest_route($this->api_namespace, '/site-info', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_site_info'),
            'permission_callback' => array($this, 'check_auth')
        ));

        register_rest_route($this->api_namespace, '/plugins', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_plugins_info'),
            'permission_callback' => array($this, 'check_auth')
        ));

        register_rest_route($this->api_namespace, '/users', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_users_info'),
            'permission_callback' => array($this, 'check_auth')
        ));

        register_rest_route($this->api_namespace, '/health', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_health_status'),
            'permission_callback' => array($this, 'check_auth')
        ));

        // Remote API endpoints - זמינים רק אם מופעל ובסביבת פיתוח
        if ($remote_api_allowed) {
            register_rest_route($this->api_namespace, '/logs', array(
                'methods' => 'GET',
                'callback' => array($this, 'get_logs'),
                'permission_callback' => array($this, 'check_auth')
            ));
            
            register_rest_route($this->api_namespace, '/test-email', array(
                'methods' => 'POST',
                'callback' => array($this, 'test_email'),
                'permission_callback' => array($this, 'check_auth')
            ));

            // נקודות קצה לפיתוח - זמינות רק בסביבת פיתוח
            if (AT_Agency_Manager_Environment::is_development()) {
                register_rest_route($this->api_namespace, '/development-info', array(
                    'methods' => 'GET',
                    'callback' => array($this, 'get_development_info'),
                    'permission_callback' => array($this, 'check_development_auth')
                ));

                register_rest_route($this->api_namespace, '/debug-logs', array(
                    'methods' => 'GET',
                    'callback' => array($this, 'get_debug_logs'),
                    'permission_callback' => array($this, 'check_development_auth')
                ));

                register_rest_route($this->api_namespace, '/environment-status', array(
                    'methods' => 'GET',
                    'callback' => array($this, 'get_environment_status'),
                    'permission_callback' => array($this, 'check_development_auth')
                ));
            }
        }
    }

    /**
     * בדיקת אימות לבקשות API
     * 
     * @param WP_REST_Request $request הבקשה
     * @return bool|WP_Error האם האימות תקין
     */
    public function check_auth($request) {
        // בדיקה אם Remote API מותר
        if (!AT_Agency_Manager_Environment::is_remote_api_allowed()) {
            $this->logger->log_api_request(
                $request->get_route(),
                'blocked_environment'
            );
            return new WP_Error(
                'rest_forbidden',
                __('Remote API is not allowed in this environment.', 'at-agency-manager'),
                array('status' => 403)
            );
        }
        
        $auth_header = (string) $request->get_header('X-AT-Agency-Manager-Key');
        $result = !empty($auth_header)
            && !empty($this->auth_key)
            && hash_equals((string) $this->auth_key, $auth_header);
        
        $this->logger->log_api_request(
            $request->get_route(),
            $result ? 'success' : 'auth_failed'
        );
        
        if ($result) {
            return true;
        }

        return new WP_Error(
            'rest_forbidden',
            __('Authentication required.', 'at-agency-manager'),
            array('status' => 401)
        );
    }

    /**
     * מידע בסיסי על האתר
     * 
     * @return WP_REST_Response תשובת ה-API
     */
    public function get_site_info() {
        global $wp_version;
        
        return new WP_REST_Response(array(
            'version' => $wp_version,
            'name' => get_bloginfo('name'),
            'url' => get_site_url(),
            'admin_email' => get_bloginfo('admin_email'),
            'last_updated' => get_lastpostmodified('GMT'),
            'environment' => $this->get_environment_info(),
            'security' => $this->get_security_info()
        ), 200);
    }

    /**
     * מידע על תוספים באתר
     * 
     * @return WP_REST_Response תשובת ה-API
     */
    public function get_plugins_info() {
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        
        $all_plugins = get_plugins();
        $active_plugins = get_option('active_plugins');
        $updates = get_site_transient('update_plugins');
        
        $plugins_data = array();
        foreach ($all_plugins as $plugin_path => $plugin_data) {
            $needs_update = false;
            if (isset($updates->response[$plugin_path])) {
                $needs_update = true;
            }
            
            $plugins_data[] = array(
                'name' => $plugin_data['Name'],
                'version' => $plugin_data['Version'],
                'active' => in_array($plugin_path, $active_plugins),
                'needs_update' => $needs_update,
                'author' => $plugin_data['Author'],
                'description' => $plugin_data['Description']
            );
        }
        
        return new WP_REST_Response($plugins_data, 200);
    }

    /**
     * מידע על משתמשים באתר
     * 
     * @return WP_REST_Response תשובת ה-API
     */
    public function get_users_info() {
        $users = get_users(array('fields' => array('ID', 'user_login', 'user_email', 'user_registered')));
        $users_data = array();
        
        foreach ($users as $user) {
            $user_meta = get_user_meta($user->ID);
            $last_login = get_user_meta($user->ID, 'last_login', true);
            
            $users_data[] = array(
                'username' => $user->user_login,
                'email' => $user->user_email,
                'registered' => $user->user_registered,
                'last_login' => $last_login ? $last_login : null,
                'roles' => $this->get_user_role($user->ID)
            );
        }
        
        return new WP_REST_Response($users_data, 200);
    }

    /**
     * מידע על בריאות האתר
     * 
     * @return WP_REST_Response תשובת ה-API
     */
    public function get_health_status() {
        global $wpdb;
        
        // בדיקת חיבור למסד נתונים
        $db_status = true;
        if (!$wpdb->check_connection()) {
            $db_status = false;
        }
        
        // בדיקת גישה לכתיבה במערכת הקבצים
        $upload_dir = wp_upload_dir();
        $fs_status = wp_is_writable($upload_dir['basedir']);
        
        // מידע על תוספים שדורשים עדכון
        $plugins_need_update = 0;
        $themes_need_update = 0;
        
        if (function_exists('wp_get_update_data')) {
            $update_data = wp_get_update_data();
            $plugins_need_update = $update_data['counts']['plugins'];
            $themes_need_update = $update_data['counts']['themes'];
        }
        
        // בדיקת עדכוני WP Core
        $core_update = false;
        $update_core = get_site_transient('update_core');
        if ($update_core && !empty($update_core->updates)) {
            foreach ($update_core->updates as $update) {
                if ($update->response == 'upgrade') {
                    $core_update = true;
                    break;
                }
            }
        }
        
        return new WP_REST_Response(array(
            'database' => $db_status,
            'filesystem' => $fs_status,
            'php_version' => PHP_VERSION,
            'wp_memory_limit' => WP_MEMORY_LIMIT,
            'max_execution_time' => ini_get('max_execution_time'),
            'plugins_need_update' => $plugins_need_update,
            'themes_need_update' => $themes_need_update,
            'core_update_available' => $core_update,
            'site_type' => get_option('at_agency_manager_site_type')
        ), 200);
    }

    /**
     * לוגים של המערכת
     * 
     * @param WP_REST_Request $request הבקשה
     * @return WP_REST_Response תשובת ה-API
     */
    public function get_logs(WP_REST_Request $request) {
        $limit = $request->get_param('limit') ? intval($request->get_param('limit')) : 100;
        $logs = $this->logger->get_logs($limit);
        
        return new WP_REST_Response($logs, 200);
    }

    /**
     * בדיקת שליחת אימייל
     * 
     * @param WP_REST_Request $request הבקשה
     * @return WP_REST_Response תשובת ה-API
     */
    public function test_email(WP_REST_Request $request) {
        $to = $request->get_param('email') ? $request->get_param('email') : get_option('admin_email');
        $subject = __('SMTP Test Email from AT Agency Manager', 'at-agency-manager');
        $message = __('This is a test email sent from the AT Agency Manager plugin.', 'at-agency-manager');
        
        $headers = array('Content-Type: text/html; charset=UTF-8');
        
        try {
            $result = wp_mail($to, $subject, $message, $headers);
            $status = $result ? 'success' : 'failed';
            $this->logger->log_email($to, $subject, $status);
            
            return new WP_REST_Response(array(
                'success' => $result,
                'message' => $result ? 
                    __('Email sent successfully', 'at-agency-manager') : 
                    __('Email could not be sent', 'at-agency-manager')
            ), 200);
        } catch (Exception $e) {
            $this->logger->log_email($to, $subject, 'error: ' . $e->getMessage());
            
            return new WP_REST_Response(array(
                'success' => false,
                'message' => $e->getMessage()
            ), 500);
        }
    }
    
    /**
     * קבלת התפקיד של משתמש
     * 
     * @param int $user_id מזהה המשתמש
     * @return array רשימת התפקידים
     */
    private function get_user_role($user_id) {
        $user = get_userdata($user_id);
        return $user->roles;
    }
    
    /**
     * קבלת מידע על הסביבה
     * 
     * @return array מידע סביבתי
     */
    private function get_environment_info() {
        return array(
            'server_software' => $_SERVER['SERVER_SOFTWARE'],
            'php_version' => PHP_VERSION,
            'mysql_version' => $GLOBALS['wpdb']->db_version(),
            'web_server' => isset($_SERVER['SERVER_SOFTWARE']) ? $_SERVER['SERVER_SOFTWARE'] : '',
            'php_max_input_vars' => ini_get('max_input_vars'),
            'php_post_max_size' => ini_get('post_max_size'),
            'php_upload_max_filesize' => ini_get('upload_max_filesize'),
            'php_max_execution_time' => ini_get('max_execution_time')
        );
    }
    
    /**
     * קבלת מידע אבטחה
     * 
     * @return array מידע אבטחה
     */
    private function get_security_info() {
        return array(
            'ssl_enabled' => is_ssl(),
            'hide_errors' => !(defined('WP_DEBUG') && WP_DEBUG),
            'failed_login_attempts' => $this->get_failed_login_attempts(),
            'file_permissions' => $this->check_file_permissions()
        );
    }
    
    /**
     * קבלת ניסיונות כניסה כושלים
     * 
     * @return int מספר הניסיונות
     */
    private function get_failed_login_attempts() {
        global $wpdb;
        
        $count = 0;
        
        if (class_exists('WP_Statistics')) {
            // עדיפות לנתונים מ-WP Statistics אם מותקן
            $count = $wpdb->get_var("SELECT SUM(failed_login) FROM wp_statistics_useronline");
        }
        
        return $count;
    }
    
    /**
     * בדיקת הרשאות קבצים
     * 
     * @return array מידע על הרשאות
     */
    private function check_file_permissions() {
        $permissions = array();
        
        // בדיקת הרשאות wp-config.php
        $config_file = ABSPATH . 'wp-config.php';
        if (file_exists($config_file)) {
            $permissions['wp_config'] = substr(sprintf('%o', fileperms($config_file)), -4);
        }
        
        // בדיקת הרשאות תיקיית התכנים
        $upload_dir = wp_upload_dir();
        $permissions['uploads_dir'] = substr(sprintf('%o', fileperms($upload_dir['basedir'])), -4);
        
        return $permissions;
    }

    /**
     * בדיקת אימות לפיתוח
     *
     * @param WP_REST_Request $request הבקשה
     * @return bool|WP_Error האם מורשה
     */
    public function check_development_auth($request) {
        // בדיקה אם בסביבת פיתוח
        if (!AT_Agency_Manager_Environment::is_development()) {
            return new WP_Error(
                'rest_forbidden',
                __('Development endpoints are only available in development or local environments.', 'at-agency-manager'),
                array('status' => 403)
            );
        }

        // בדיקת מפתח API או הרשאת מנהל
        $api_key = $request->get_header('X-AT-Agency-Manager-Key');
        $stored_key = get_option('at_agency_manager_auth_key');

        if (!empty($api_key) && !empty($stored_key) && hash_equals((string) $stored_key, (string) $api_key)) {
            return true;
        }

        // הרשאת מנהל כגיבוי (רק בסביבת פיתוח)
        if (current_user_can('manage_options')) {
            return true;
        }

        return new WP_Error(
            'rest_forbidden',
            __('Authentication required.', 'at-agency-manager'),
            array('status' => 401)
        );
    }

    /**
     * מידע על סביבת הפיתוח
     *
     * @return WP_REST_Response תשובת ה-API
     */
    public function get_development_info() {
        global $wp_version;

        $development_info = array(
            'development_mode' => at_get_development_mode(),
            'is_development' => at_is_development_environment(),
            'site_type' => get_option('at_agency_manager_site_type', 'production'),
            'wp_environment' => wp_get_environment_type(),
            'wp_debug' => defined('WP_DEBUG') ? WP_DEBUG : false,
            'wp_version' => $wp_version,
            'php_version' => PHP_VERSION,
            'server_info' => array(
                'software' => isset($_SERVER['SERVER_SOFTWARE']) ? $_SERVER['SERVER_SOFTWARE'] : 'Unknown',
                'php_sapi' => php_sapi_name()
            ),
            'memory_limit' => ini_get('memory_limit'),
            'max_execution_time' => ini_get('max_execution_time'),
            'upload_max_filesize' => ini_get('upload_max_filesize'),
            'post_max_size' => ini_get('post_max_size')
        );

        return new WP_REST_Response($development_info, 200);
    }

    /**
     * לוגים דיבוג לפיתוח
     *
     * @param WP_REST_Request $request הבקשה
     * @return WP_REST_Response תשובת ה-API
     */
    public function get_debug_logs(WP_REST_Request $request) {
        $limit = $request->get_param('limit') ?: 50;
        $level = $request->get_param('level') ?: '';

        // קבלת לוגים ממסד הנתונים
        global $wpdb;
        $table_name = $wpdb->prefix . 'at_site_manager_logs';

        $where_clause = "1=1";
        if (!empty($level)) {
            $where_clause .= $wpdb->prepare(" AND status = %s", $level);
        }

        $logs = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table_name}
             WHERE {$where_clause}
             ORDER BY created_at DESC
             LIMIT %d",
            $limit
        ));

        // עיבוד הלוגים
        $processed_logs = array();
        foreach ($logs as $log) {
            $processed_logs[] = array(
                'id' => $log->id,
                'type' => $log->type,
                'message' => $log->message,
                'status' => $log->status,
                'created_at' => $log->created_at,
                'user_id' => $log->user_id,
                'ip_address' => $log->ip_address,
                'development_mode' => $log->development_mode,
                'site_type' => $log->site_type,
                'context' => !empty($log->context) ? maybe_unserialize($log->context) : null
            );
        }

        return new WP_REST_Response(array(
            'logs' => $processed_logs,
            'total' => count($processed_logs),
            'limit' => $limit
        ), 200);
    }

    /**
     * סטטוס סביבה מפורט
     *
     * @return WP_REST_Response תשובת ה-API
     */
    public function get_environment_status() {
        $status = array(
            'environment' => array(
                'type' => wp_get_environment_type(),
                'is_production' => wp_get_environment_type() === 'production',
                'is_development' => at_is_development_environment()
            ),
            'development' => array(
                'mode' => at_get_development_mode(),
                'features_enabled' => array(
                    'debug_notices' => get_option('at_agency_manager_show_debug_notices', true),
                    'debug_info' => get_option('at_agency_manager_show_debug_info', true),
                    'remote_api' => get_option('at_agency_manager_enable_remote_api', false)
                )
            ),
            'site' => array(
                'type' => get_option('at_agency_manager_site_type', 'production'),
                'url' => get_site_url(),
                'name' => get_bloginfo('name')
            ),
            'security' => array(
                'wp_debug' => defined('WP_DEBUG') ? WP_DEBUG : false,
                'wp_debug_display' => defined('WP_DEBUG_DISPLAY') ? WP_DEBUG_DISPLAY : false,
                'wp_debug_log' => defined('WP_DEBUG_LOG') ? WP_DEBUG_LOG : false
            ),
            'modules' => array(
                's3_sync_enabled' => get_option('at_agency_manager_modules')['s3_media_sync'] ?? false,
                'backup_enabled' => get_option('at_agency_manager_modules')['backup'] ?? false,
                'email_log_enabled' => get_option('at_agency_manager_modules')['email_log'] ?? false
            ),
            'suite_core' => array(
                'active' => function_exists('at_is_suite_core_active') ? at_is_suite_core_active() : false,
                'version' => defined('AT_AGENCY_MANAGER_VERSION') ? AT_AGENCY_MANAGER_VERSION : null,
            ),
        );

        return new WP_REST_Response($status, 200);
    }
} 
