<?php
/**
 * מחלקה לניהול עמוד לוגים מאוחד
 * 
 * מאחד את כל הלוגים: System Logs, Activity Log, Email Log
 * עם יכולות חיפוש, סינון, מיון וניהול מלא
 */
class AT_Agency_Manager_Unified_Logs {
    /**
     * @var AT_Agency_Manager_Logger
     */
    private $logger;
    
    /**
     * @var string סוג הלוג הנוכחי (system, activity, email)
     */
    private $current_log_type = 'system';
    
    /**
     * Constructor
     */
    public function __construct($logger) {
        $this->logger = $logger;
    }
    
    /**
     * הצגת עמוד הלוגים המאוחד
     */
    public function render() {
        // בדיקת הרשאות
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'at-agency-manager'));
        }
        
        // קבלת סוג הלוג הנוכחי
        $this->current_log_type = isset($_GET['log_type']) ? sanitize_text_field($_GET['log_type']) : 'system';
        
        // פרמטרים לסינון וחיפוש
        $per_page = isset($_GET['per_page']) ? intval($_GET['per_page']) : 20;
        $page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
        
        // קבלת הלוגים לפי סוג
        $logs_data = $this->get_logs_by_type($this->current_log_type, $per_page, $page, $search);
        
        ?>
        <div class="wrap at-agency-manager-wrap">
            <h1><?php _e('Logs Management', 'at-agency-manager'); ?></h1>
            
            <!-- טאבים -->
            <nav class="nav-tab-wrapper" style="margin-bottom: 20px;">
                <a href="?page=at-agency-manager-logs&log_type=system" 
                   class="nav-tab <?php echo $this->current_log_type === 'system' ? 'nav-tab-active' : ''; ?>">
                    <?php _e('System Logs', 'at-agency-manager'); ?>
                    <span class="count">(<?php echo number_format_i18n($this->get_log_count('system')); ?>)</span>
                </a>
                <?php if (class_exists('AT_Activity_Log')): ?>
                <a href="?page=at-agency-manager-logs&log_type=activity" 
                   class="nav-tab <?php echo $this->current_log_type === 'activity' ? 'nav-tab-active' : ''; ?>">
                    <?php _e('Activity Log', 'at-agency-manager'); ?>
                    <span class="count">(<?php echo number_format_i18n($this->get_log_count('activity')); ?>)</span>
                </a>
                <?php endif; ?>
                <?php if (class_exists('AT_Email_Log')): ?>
                <a href="?page=at-agency-manager-logs&log_type=email" 
                   class="nav-tab <?php echo $this->current_log_type === 'email' ? 'nav-tab-active' : ''; ?>">
                    <?php _e('Email Log', 'at-agency-manager'); ?>
                    <span class="count">(<?php echo number_format_i18n($this->get_log_count('email')); ?>)</span>
                </a>
                <?php endif; ?>
            </nav>
            
            <!-- חיפוש וסינון -->
            <div class="tablenav top">
                <form method="get" style="display: flex; gap: 10px; align-items: center; margin-bottom: 20px;">
                    <input type="hidden" name="page" value="at-agency-manager-logs">
                    <input type="hidden" name="log_type" value="<?php echo esc_attr($this->current_log_type); ?>">
                    
                    <div class="search-box" style="flex: 1;">
                        <input type="search" 
                               name="s" 
                               value="<?php echo esc_attr($search); ?>" 
                               placeholder="<?php _e('Search logs...', 'at-agency-manager'); ?>"
                               class="regular-text">
                    </div>
                    
                    <?php echo $this->render_filters(); ?>
                    
                    <select name="per_page" style="width: 100px;">
                        <option value="20" <?php selected($per_page, 20); ?>>20</option>
                        <option value="50" <?php selected($per_page, 50); ?>>50</option>
                        <option value="100" <?php selected($per_page, 100); ?>>100</option>
                    </select>
                    
                    <input type="submit" class="button" value="<?php _e('Filter', 'at-agency-manager'); ?>">
                    
                    <?php if ($search): ?>
                        <a href="?page=at-agency-manager-logs&log_type=<?php echo esc_attr($this->current_log_type); ?>" 
                           class="button">
                            <?php _e('Clear', 'at-agency-manager'); ?>
                        </a>
                    <?php endif; ?>
                </form>
                
                <!-- פעולות -->
                <div class="alignleft actions" style="margin-bottom: 10px;">
                    <button type="button" 
                            class="button button-secondary" 
                            id="export-logs-btn"
                            data-log-type="<?php echo esc_attr($this->current_log_type); ?>">
                        <?php _e('Export', 'at-agency-manager'); ?>
                    </button>
                    <button type="button" 
                            class="button button-secondary" 
                            id="clear-logs-btn"
                            data-log-type="<?php echo esc_attr($this->current_log_type); ?>">
                        <?php _e('Clear All', 'at-agency-manager'); ?>
                    </button>
                    <span id="logs-action-status"></span>
                </div>
                
                <!-- Pagination -->
                <?php if ($logs_data['total_pages'] > 1): ?>
                    <div class="tablenav-pages">
                        <span class="displaying-num">
                            <?php printf(
                                _n('%s item', '%s items', $logs_data['total_items'], 'at-agency-manager'),
                                number_format_i18n($logs_data['total_items'])
                            ); ?>
                        </span>
                        <?php
                        echo paginate_links(array(
                            'base' => add_query_arg('paged', '%#%'),
                            'format' => '',
                            'prev_text' => '&laquo;',
                            'next_text' => '&raquo;',
                            'total' => $logs_data['total_pages'],
                            'current' => $page
                        ));
                        ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- טבלת הלוגים -->
            <?php $this->render_logs_table($logs_data['logs']); ?>
        </div>
        
        <style>
            .log-status, .email-status {
                display: inline-block;
                padding: 3px 8px;
                border-radius: 3px;
                font-size: 12px;
                font-weight: bold;
            }
            .log-status-info, .email-status-sent {
                background-color: #e5f5fa;
                color: #0086b3;
            }
            .log-status-success {
                background-color: #ecf9ec;
                color: #008a20;
            }
            .log-status-warning {
                background-color: #fff8e5;
                color: #ca8a00;
            }
            .log-status-error, .email-status-failed {
                background-color: #fef1f1;
                color: #d63638;
            }
            .nav-tab .count {
                margin-right: 5px;
                font-weight: normal;
                color: #666;
            }
            .log-details {
                display: none;
                background: #f9f9f9;
                padding: 10px;
                margin-top: 5px;
                border-radius: 3px;
            }
            .log-details.show {
                display: block;
            }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            // הצגת/הסתרת פרטים
            $('.toggle-log-details').on('click', function(e) {
                e.preventDefault();
                var details = $(this).closest('tr').next('.log-details-row');
                details.toggleClass('show');
            });
            
            // Resend email
            $('.resend-email-btn').on('click', function(e) {
                e.preventDefault();
                var logId = $(this).data('log-id');
                var originalEmail = $(this).data('email');
                var newEmail = prompt('<?php echo esc_js(__('Enter recipient email address:', 'at-agency-manager')); ?>', originalEmail);
                
                if (newEmail !== null) {
                    var btn = $(this);
                    var originalText = btn.text();
                    btn.text('<?php echo esc_js(__('Sending...', 'at-agency-manager')); ?>');
                    
                    $.post(ajaxurl, {
                        action: 'at_resend_email',
                        log_id: logId,
                        recipient: newEmail,
                        nonce: '<?php echo wp_create_nonce('at_resend_email'); ?>'
                    }, function(response) {
                        if (response.success) {
                            alert(response.data);
                        } else {
                            alert('<?php echo esc_js(__('Error:', 'at-agency-manager')); ?> ' + response.data);
                        }
                        btn.text(originalText);
                    });
                }
            });
            
            // Export logs
            $('#export-logs-btn').on('click', function() {
                var logType = $(this).data('log-type');
                window.location.href = ajaxurl.replace('admin-ajax.php', 'admin-post.php') + 
                    '?action=at_export_logs&log_type=' + logType + 
                    '&nonce=<?php echo wp_create_nonce('at_export_logs'); ?>';
            });
            
            // Clear logs
            $('#clear-logs-btn').on('click', function() {
                if (!confirm('<?php _e('Are you sure you want to delete ALL logs? This action cannot be undone.', 'at-agency-manager'); ?>')) {
                    return;
                }
                
                var btn = $(this);
                var status = $('#logs-action-status');
                var logType = btn.data('log-type');
                
                btn.prop('disabled', true);
                status.html('<?php _e('Clearing...', 'at-agency-manager'); ?>');
                
                $.post(ajaxurl, {
                    action: 'at_clear_logs',
                    log_type: logType,
                    nonce: '<?php echo wp_create_nonce('at_clear_logs'); ?>'
                }, function(response) {
                    if (response.success) {
                        status.html('<span style="color:green;">✓ ' + response.data + '</span>');
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        status.html('<span style="color:red;">✗ ' + response.data + '</span>');
                        btn.prop('disabled', false);
                    }
                });
            });
        });
        </script>
        <?php
    }
    
    /**
     * קבלת לוגים לפי סוג
     */
    private function get_logs_by_type($type, $per_page, $page, $search) {
        global $wpdb;
        
        $offset = ($page - 1) * $per_page;
        $logs = array();
        $total_items = 0;
        
        switch ($type) {
            case 'system':
                $table_name = $wpdb->prefix . 'at_agency_manager_logs';
                $query = "SELECT SQL_CALC_FOUND_ROWS * FROM {$table_name} WHERE 1=1";
                $query_args = array();
                
                if ($search) {
                    $query .= " AND (message LIKE %s OR type LIKE %s)";
                    $query_args[] = '%' . $wpdb->esc_like($search) . '%';
                    $query_args[] = '%' . $wpdb->esc_like($search) . '%';
                }
                
                // סינון לפי status
                if (isset($_GET['status']) && $_GET['status']) {
                    $query .= " AND status = %s";
                    $query_args[] = sanitize_text_field($_GET['status']);
                }
                
                // סינון לפי type
                if (isset($_GET['type']) && $_GET['type']) {
                    $query .= " AND type = %s";
                    $query_args[] = sanitize_text_field($_GET['type']);
                }
                
                $query .= " ORDER BY created_at DESC LIMIT %d, %d";
                $query_args[] = $offset;
                $query_args[] = $per_page;
                
                $logs = $wpdb->get_results($wpdb->prepare($query, $query_args));
                $total_items = $wpdb->get_var("SELECT FOUND_ROWS()");
                break;
                
            case 'activity':
                if (!class_exists('AT_Activity_Log')) {
                    break;
                }
                $table_name = $wpdb->prefix . 'at_activity_log';
                $query = "SELECT SQL_CALC_FOUND_ROWS * FROM {$table_name} WHERE 1=1";
                $query_args = array();
                
                if ($search) {
                    $query .= " AND (action LIKE %s OR object_name LIKE %s OR user_name LIKE %s)";
                    $query_args[] = '%' . $wpdb->esc_like($search) . '%';
                    $query_args[] = '%' . $wpdb->esc_like($search) . '%';
                    $query_args[] = '%' . $wpdb->esc_like($search) . '%';
                }
                
                // סינון לפי user
                if (isset($_GET['user']) && $_GET['user']) {
                    $query .= " AND user_id = %d";
                    $query_args[] = intval($_GET['user']);
                }
                
                // סינון לפי action
                if (isset($_GET['action']) && $_GET['action']) {
                    $query .= " AND action = %s";
                    $query_args[] = sanitize_text_field($_GET['action']);
                }
                
                // סינון לפי object_type
                if (isset($_GET['object_type']) && $_GET['object_type']) {
                    $query .= " AND object_type = %s";
                    $query_args[] = sanitize_text_field($_GET['object_type']);
                }
                
                $query .= " ORDER BY created_at DESC LIMIT %d, %d";
                $query_args[] = $offset;
                $query_args[] = $per_page;
                
                $logs = $wpdb->get_results($wpdb->prepare($query, $query_args));
                $total_items = $wpdb->get_var("SELECT FOUND_ROWS()");
                break;
                
            case 'email':
                if (!class_exists('AT_Email_Log')) {
                    break;
                }
                $table_name = $wpdb->prefix . 'at_email_log';
                $query = "SELECT SQL_CALC_FOUND_ROWS * FROM {$table_name} WHERE 1=1";
                $query_args = array();
                
                if ($search) {
                    $query .= " AND (email_to LIKE %s OR subject LIKE %s)";
                    $query_args[] = '%' . $wpdb->esc_like($search) . '%';
                    $query_args[] = '%' . $wpdb->esc_like($search) . '%';
                }
                
                // סינון לפי status
                if (isset($_GET['email_status']) && $_GET['email_status']) {
                    $query .= " AND status = %s";
                    $query_args[] = sanitize_text_field($_GET['email_status']);
                }
                
                $query .= " ORDER BY time DESC LIMIT %d, %d";
                $query_args[] = $offset;
                $query_args[] = $per_page;
                
                $logs = $wpdb->get_results($wpdb->prepare($query, $query_args));
                $total_items = $wpdb->get_var("SELECT FOUND_ROWS()");
                break;
        }
        
        return array(
            'logs' => $logs,
            'total_items' => $total_items,
            'total_pages' => ceil($total_items / $per_page)
        );
    }
    
    /**
     * הצגת פילטרים לפי סוג הלוג
     */
    private function render_filters() {
        global $wpdb;
        $output = '';
        
        switch ($this->current_log_type) {
            case 'system':
                // פילטר לפי status
                $statuses = $wpdb->get_col("SELECT DISTINCT status FROM {$wpdb->prefix}at_agency_manager_logs WHERE status IS NOT NULL");
                if (!empty($statuses)) {
                    $output .= '<select name="status">';
                    $output .= '<option value="">' . __('All Statuses', 'at-agency-manager') . '</option>';
                    foreach ($statuses as $status) {
                        $selected = isset($_GET['status']) && $_GET['status'] === $status ? 'selected' : '';
                        $output .= '<option value="' . esc_attr($status) . '" ' . $selected . '>' . esc_html(ucfirst($status)) . '</option>';
                    }
                    $output .= '</select>';
                }
                
                // פילטר לפי type
                $types = $wpdb->get_col("SELECT DISTINCT type FROM {$wpdb->prefix}at_agency_manager_logs WHERE type IS NOT NULL");
                if (!empty($types)) {
                    $output .= '<select name="type">';
                    $output .= '<option value="">' . __('All Types', 'at-agency-manager') . '</option>';
                    foreach ($types as $type) {
                        $selected = isset($_GET['type']) && $_GET['type'] === $type ? 'selected' : '';
                        $output .= '<option value="' . esc_attr($type) . '" ' . $selected . '>' . esc_html($type) . '</option>';
                    }
                    $output .= '</select>';
                }
                break;
                
            case 'activity':
                // פילטר לפי user
                $users = get_users(array('fields' => array('ID', 'display_name')));
                if (!empty($users)) {
                    $output .= '<select name="user">';
                    $output .= '<option value="">' . __('All Users', 'at-agency-manager') . '</option>';
                    foreach ($users as $user) {
                        $selected = isset($_GET['user']) && intval($_GET['user']) === $user->ID ? 'selected' : '';
                        $output .= '<option value="' . esc_attr($user->ID) . '" ' . $selected . '>' . esc_html($user->display_name) . '</option>';
                    }
                    $output .= '</select>';
                }
                
                // פילטר לפי action
                $actions = $wpdb->get_col("SELECT DISTINCT action FROM {$wpdb->prefix}at_activity_log WHERE action IS NOT NULL");
                if (!empty($actions)) {
                    $output .= '<select name="action">';
                    $output .= '<option value="">' . __('All Actions', 'at-agency-manager') . '</option>';
                    foreach ($actions as $action) {
                        $selected = isset($_GET['action']) && $_GET['action'] === $action ? 'selected' : '';
                        $output .= '<option value="' . esc_attr($action) . '" ' . $selected . '>' . esc_html($action) . '</option>';
                    }
                    $output .= '</select>';
                }
                
                // פילטר לפי object_type
                $object_types = $wpdb->get_col("SELECT DISTINCT object_type FROM {$wpdb->prefix}at_activity_log WHERE object_type IS NOT NULL");
                if (!empty($object_types)) {
                    $output .= '<select name="object_type">';
                    $output .= '<option value="">' . __('All Types', 'at-agency-manager') . '</option>';
                    foreach ($object_types as $type) {
                        $selected = isset($_GET['object_type']) && $_GET['object_type'] === $type ? 'selected' : '';
                        $output .= '<option value="' . esc_attr($type) . '" ' . $selected . '>' . esc_html($type) . '</option>';
                    }
                    $output .= '</select>';
                }
                break;
                
            case 'email':
                // פילטר לפי status
                $output .= '<select name="email_status">';
                $output .= '<option value="">' . __('All Statuses', 'at-agency-manager') . '</option>';
                $output .= '<option value="sent" ' . (isset($_GET['email_status']) && $_GET['email_status'] === 'sent' ? 'selected' : '') . '>' . __('Sent', 'at-agency-manager') . '</option>';
                $output .= '<option value="failed" ' . (isset($_GET['email_status']) && $_GET['email_status'] === 'failed' ? 'selected' : '') . '>' . __('Failed', 'at-agency-manager') . '</option>';
                $output .= '</select>';
                break;
        }
        
        return $output;
    }
    
    /**
     * הצגת טבלת הלוגים
     */
    private function render_logs_table($logs) {
        ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <?php echo $this->get_table_headers(); ?>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($logs)): ?>
                    <tr>
                        <td colspan="<?php echo $this->get_column_count(); ?>">
                            <?php _e('No logs found.', 'at-agency-manager'); ?>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($logs as $log): ?>
                        <?php echo $this->render_log_row($log); ?>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
        <?php
    }
    
    /**
     * קבלת כותרות הטבלה לפי סוג הלוג
     */
    private function get_table_headers() {
        switch ($this->current_log_type) {
            case 'system':
                return '<th>' . __('Time', 'at-agency-manager') . '</th>' .
                       '<th>' . __('Type', 'at-agency-manager') . '</th>' .
                       '<th>' . __('Message', 'at-agency-manager') . '</th>' .
                       '<th>' . __('Status', 'at-agency-manager') . '</th>' .
                       '<th>' . __('User', 'at-agency-manager') . '</th>' .
                       '<th>' . __('IP', 'at-agency-manager') . '</th>';
                       
            case 'activity':
                return '<th>' . __('Date & Time', 'at-agency-manager') . '</th>' .
                       '<th>' . __('User', 'at-agency-manager') . '</th>' .
                       '<th>' . __('Action', 'at-agency-manager') . '</th>' .
                       '<th>' . __('Object Type', 'at-agency-manager') . '</th>' .
                       '<th>' . __('Object', 'at-agency-manager') . '</th>' .
                       '<th>' . __('IP', 'at-agency-manager') . '</th>';
                       
            case 'email':
                return '<th>' . __('Time', 'at-agency-manager') . '</th>' .
                       '<th>' . __('To', 'at-agency-manager') . '</th>' .
                       '<th>' . __('Subject', 'at-agency-manager') . '</th>' .
                       '<th>' . __('Status', 'at-agency-manager') . '</th>' .
                       '<th>' . __('Actions', 'at-agency-manager') . '</th>';
        }
    }
    
    /**
     * קבלת מספר העמודות
     */
    private function get_column_count() {
        switch ($this->current_log_type) {
            case 'system': return 6;
            case 'activity': return 6;
            case 'email': return 5;
            default: return 4;
        }
    }
    
    /**
     * הצגת שורת לוג
     */
    private function render_log_row($log) {
        switch ($this->current_log_type) {
            case 'system':
                $user = $log->user_id ? get_user_by('id', $log->user_id) : null;
                $user_name = $user ? $user->display_name : __('System', 'at-agency-manager');
                
                return '<tr>' .
                       '<td>' . esc_html($log->created_at) . '</td>' .
                       '<td><code>' . esc_html($log->type) . '</code></td>' .
                       '<td>' . esc_html($log->message) . '</td>' .
                       '<td><span class="log-status log-status-' . esc_attr($log->status) . '">' . esc_html(ucfirst($log->status)) . '</span></td>' .
                       '<td>' . esc_html($user_name) . '</td>' .
                       '<td><code>' . esc_html($log->ip_address) . '</code></td>' .
                       '</tr>';
                       
            case 'activity':
                $user_link = $log->user_id ? 
                    '<a href="' . esc_url(admin_url('user-edit.php?user_id=' . $log->user_id)) . '">' . esc_html($log->user_name) . '</a>' :
                    esc_html($log->user_name);
                $user_role = $log->user_role ? ' <small>(' . esc_html($log->user_role) . ')</small>' : '';
                
                $object_link = '';
                if ($log->object_id && in_array($log->object_type, array('post', 'page', 'product'))) {
                    $object_link = '<a href="' . esc_url(get_edit_post_link($log->object_id)) . '">' . esc_html($log->object_name) . '</a>';
                } else {
                    $object_link = esc_html($log->object_name);
                }
                
                return '<tr>' .
                       '<td>' . esc_html($log->created_at) . '</td>' .
                       '<td>' . $user_link . $user_role . '</td>' .
                       '<td><code>' . esc_html($log->action) . '</code></td>' .
                       '<td>' . esc_html($log->object_type) . '</td>' .
                       '<td>' . $object_link . '</td>' .
                       '<td><code>' . esc_html($log->ip_address) . '</code></td>' .
                       '</tr>';
                       
            case 'email':
                $status_class = $log->status === 'sent' ? 'email-status-sent' : 'email-status-failed';
                $status_text = $log->status === 'sent' ? __('Sent', 'at-agency-manager') : __('Failed', 'at-agency-manager');
                
                return '<tr>' .
                       '<td>' . esc_html($log->time) . '</td>' .
                       '<td>' . esc_html($log->email_to) . '</td>' .
                       '<td>' . esc_html($log->subject) . '</td>' .
                       '<td><span class="email-status ' . $status_class . '" title="' . esc_attr($log->error_message ?: '') . '">' . $status_text . '</span></td>' .
                       '<td><a href="#" class="toggle-log-details" data-log-id="' . esc_attr($log->id) . '">' . __('View', 'at-agency-manager') . '</a> | ' .
                       '<a href="#" class="resend-email-btn" data-log-id="' . esc_attr($log->id) . '" data-email="' . esc_attr($log->email_to) . '">' . __('Resend', 'at-agency-manager') . '</a></td>' .
                       '</tr>' .
                       '<tr class="log-details-row" style="display:none;">' .
                       '<td colspan="5">' .
                       '<div class="log-details">' .
                       '<strong>' . __('Subject:', 'at-agency-manager') . '</strong> ' . esc_html($log->subject) . '<br>' .
                       '<strong>' . __('To:', 'at-agency-manager') . '</strong> ' . esc_html($log->email_to) . '<br>' .
                       '<strong>' . __('Date:', 'at-agency-manager') . '</strong> ' . esc_html($log->time) . '<br><br>' .
                       '<strong>' . __('Message:', 'at-agency-manager') . '</strong><br>' .
                       '<div style="background: #fff; border: 1px solid #ddd; padding: 10px; margin-top: 5px; max-height: 300px; overflow-y: auto;">' . 
                       nl2br(esc_html($log->message)) . 
                       '</div>' .
                       ($log->error_message ? '<br><strong style="color:red;">' . __('Error:', 'at-agency-manager') . '</strong> <span style="color:red;">' . esc_html($log->error_message) . '</span>' : '') .
                       '</div>' .
                       '</td>' .
                       '</tr>';
        }
    }
    
    /**
     * קבלת מספר הלוגים לפי סוג
     */
    private function get_log_count($type) {
        global $wpdb;
        
        switch ($type) {
            case 'system':
                return $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}at_agency_manager_logs");
                
            case 'activity':
                if (!class_exists('AT_Activity_Log')) {
                    return 0;
                }
                return $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}at_activity_log");
                
            case 'email':
                if (!class_exists('AT_Email_Log')) {
                    return 0;
                }
                return $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}at_email_log");
        }
        
        return 0;
    }
}

