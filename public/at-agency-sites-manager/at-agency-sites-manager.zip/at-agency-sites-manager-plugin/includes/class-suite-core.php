<?php
/**
 * AT Suite Core Runtime
 *
 * Keeps AT Agency Manager as the central suite core even when all modules are disabled.
 */
defined('ABSPATH') || exit;

class AT_Agency_Manager_Suite_Core {
    /**
     * @var AT_Agency_Manager_Suite_Core|null
     */
    private static $instance = null;

    /**
     * @var array<string, array{service:mixed,meta:array}>
     */
    private $services = array();

    /**
     * Registered admin menu items keyed by slug.
     *
     * @var array<string, array{args:array,meta:array}>
     */
    private $admin_menu_items = array();

    /**
     * Boot singleton instance.
     *
     * @return AT_Agency_Manager_Suite_Core
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Register always-on core hooks.
     */
    private function __construct() {
        if (!defined('AT_AGENCY_SUITE_CORE_ACTIVE')) {
            define('AT_AGENCY_SUITE_CORE_ACTIVE', true);
        }

        if (!defined('AT_SUITE_CONTRACT_VERSION')) {
            define('AT_SUITE_CONTRACT_VERSION', '1.0.0');
        }

        if (!defined('AT_SUITE_PUBLIC_API')) {
            define('AT_SUITE_PUBLIC_API', true);
        }

        add_action('init', array($this, 'boot'), 0);
        add_action('rest_api_init', array($this, 'register_rest_routes'));
        add_action('admin_bar_menu', array($this, 'admin_bar_status'), 80);
        add_action('admin_menu', array($this, 'register_admin_menu_items'), 100);
    }

    /**
     * Add suite status to admin bar.
     * 
     * @param WP_Admin_Bar $wp_admin_bar
     */
    public function admin_bar_status($wp_admin_bar) {
        if (!current_user_can('manage_options')) {
            return;
        }

        $status = $this->get_status();
        $services_count = count($status['services']);

        // Parent node
        $wp_admin_bar->add_node(array(
            'id'    => 'at-suite-status',
            'title' => sprintf('AT Suite (%d)', $services_count),
            'href'  => admin_url('admin.php?page=at-agency-manager&tab=suite'),
            'meta'  => array(
                'title' => __('AT Suite Ecosystem Status', 'at-agency-manager'),
            ),
        ));

        // Child: each registered service
        foreach ($status['services'] as $service_key) {
            $wp_admin_bar->add_node(array(
                'parent' => 'at-suite-status',
                'id'     => 'at-suite-svc-' . $service_key,
                'title'  => ucfirst(str_replace('_', ' ', $service_key)),
            ));
        }

        // Child: link to REST status
        $wp_admin_bar->add_node(array(
            'parent' => 'at-suite-status',
            'id'     => 'at-suite-rest',
            'title'  => __('API Status', 'at-agency-manager'),
            'href'   => rest_url('at-suite/v1/status'),
            'meta'   => array('target' => '_blank'),
        ));
    }

    /**
     * Emit boot event for suite plugins.
     */
    public function boot() {
        do_action('at_suite_core_booted', $this);
    }

    /**
     * Register a reusable service for other suite plugins.
     *
     * @param string $key
     * @param mixed  $service
     * @param array  $meta
     * @return void
     */
    public function register_service($key, $service, $meta = array()) {
        $key = sanitize_key($key);
        if (empty($key)) {
            return;
        }

        $meta = wp_parse_args($meta, array(
            'owner'        => '',
            'version'      => '',
            'capabilities' => array(),
        ));

        $this->services[$key] = array(
            'service' => $service,
            'meta' => is_array($meta) ? $meta : array(),
        );

        do_action('at_suite_service_registered', $key, $service, $meta);
    }

    /**
     * Get registered service by key.
     *
     * @param string $key
     * @param mixed  $default
     * @return mixed
     */
    public function get_service($key, $default = null) {
        $key = sanitize_key($key);
        if (isset($this->services[$key])) {
            return $this->services[$key]['service'];
        }

        return $default;
    }

    /**
     * Get service metadata.
     *
     * @param string $key
     * @return array|null
     */
    public function get_service_meta($key) {
        $key = sanitize_key($key);
        if (isset($this->services[$key])) {
            return $this->services[$key]['meta'];
        }

        return null;
    }

    /**
     * Emit a cross-plugin event inside the suite.
     *
     * @param string $event
     * @param array  $payload
     * @return void
     */
    public function emit_event($event, $payload = array()) {
        $event = sanitize_key($event);
        if (empty($event)) {
            return;
        }

        $payload = is_array($payload) ? $payload : array('value' => $payload);

        do_action('at_suite_event', $event, $payload);
        do_action('at_suite_event_' . $event, $payload);
    }

    /**
     * Get lightweight status for UI/API.
     *
     * @return array
     */
    public function get_status() {
        return array(
            'core_active' => true,
            'contract_version' => defined('AT_SUITE_CONTRACT_VERSION') ? AT_SUITE_CONTRACT_VERSION : null,
            'version' => defined('AT_AGENCY_MANAGER_VERSION') ? AT_AGENCY_MANAGER_VERSION : null,
            'services' => array_keys($this->services),
            'modules_enabled_count' => count(array_filter((array) get_option('at_agency_manager_modules', array()))),
        );
    }

    /**
     * Get settings schema from all registered plugins.
     * 
     * @return array
     */
    public function get_settings_schema() {
        return apply_filters('at_suite_settings_schema', array());
    }

    /**
     * Get settings values from all registered plugins.
     * 
     * @return array
     */
    public function get_settings_values() {
        return apply_filters('at_suite_settings_values', array());
    }

    /**
     * Fire settings saved action.
     * 
     * @param array $registered_schemas
     */
    public function settings_saved($registered_schemas) {
        do_action('at_suite_settings_saved', $registered_schemas);
    }

    /**
     * Register a submenu item through the suite registry.
     *
     * @param string $slug
     * @param array  $args
     * @param array  $meta
     * @return bool
     */
    public function register_admin_menu_item($slug, $args = array(), $meta = array()) {
        $registration_key = sanitize_key($slug);
        if (empty($registration_key)) {
            return false;
        }

        $defaults = array(
            'parent_slug' => 'at-agency-manager',
            'page_title' => '',
            'menu_title' => '',
            'capability' => 'manage_options',
            'menu_slug' => $registration_key,
            'callback' => null,
            'position' => null,
        );

        $item_args = wp_parse_args($args, $defaults);
        $menu_slug = isset($item_args['menu_slug']) ? sanitize_key($item_args['menu_slug']) : '';
        if (empty($menu_slug)) {
            $menu_slug = $registration_key;
        }
        $item_args['menu_slug'] = $menu_slug;

        if (!is_callable($item_args['callback'])) {
            $this->warn('Admin menu item callback is not callable.', array('slug' => $menu_slug));
            return false;
        }

        if (isset($this->admin_menu_items[$menu_slug])) {
            $this->warn('Duplicate admin menu slug registration ignored.', array(
                'slug' => $menu_slug,
                'existing_source' => isset($this->admin_menu_items[$menu_slug]['meta']['source_id']) ? $this->admin_menu_items[$menu_slug]['meta']['source_id'] : '',
                'new_source' => isset($meta['source_id']) ? $meta['source_id'] : '',
            ));
            return false;
        }

        $item_meta = is_array($meta) ? $meta : array();
        $item_meta['registration_key'] = $registration_key;

        $this->admin_menu_items[$menu_slug] = array(
            'args' => $item_args,
            'meta' => $item_meta,
        );

        do_action('at_suite_admin_menu_registered', $menu_slug, $item_args, $item_meta);

        return true;
    }

    /**
     * Return all registered admin menu items.
     *
     * @return array<string, array{args:array,meta:array}>
     */
    public function get_admin_menu_items() {
        return $this->admin_menu_items;
    }

    /**
     * Register queued admin menu items and prevent slug conflicts.
     *
     * @return void
     */
    public function register_admin_menu_items() {
        foreach ($this->admin_menu_items as $registered_menu_slug => $item) {
            $menu_slug = isset($item['args']['menu_slug']) ? $item['args']['menu_slug'] : $registered_menu_slug;

            if ($this->is_menu_slug_registered($menu_slug)) {
                $this->warn('Admin menu slug already exists. Skipping suite registration.', array('slug' => $menu_slug));
                continue;
            }

            $args = $item['args'];
            add_submenu_page(
                $args['parent_slug'],
                $args['page_title'],
                $args['menu_title'],
                $args['capability'],
                $args['menu_slug'],
                $args['callback'],
                $args['position']
            );
        }
    }

    /**
     * Get branding configuration.
     * 
     * @return array
     */
    public function get_branding_config() {
        return apply_filters('at_suite_branding_config', array(
            'logo_url' => AT_AGENCY_MANAGER_URL . 'assets/images/at-logo.png',
            'credit_text' => 'הקמה וניהול: עמית טרבלסי דיגיטל',
            'credit_url' => 'http://atd.digital',
            'admin_favicon' => AT_AGENCY_MANAGER_URL . 'assets/images/admin.ico',
        ));
    }

    /**
     * Render the unified admin footer.
     */
    public function render_admin_footer() {
        $config = $this->get_branding_config();
        
        ?>
        <div class="at-suite-footer" style="text-align: right; direction: ltr;">
            <span style="line-height: 2;"> <?php echo esc_html($config['credit_text']); ?> </span>
            <a href="<?php echo esc_url($config['credit_url']); ?>" target="_blank" rel="noopener noreferrer">
                <?php if (!empty($config['logo_url'])): ?>
                    <img width="20px" src="<?php echo esc_url($config['logo_url']); ?>" alt="<?php echo esc_attr($config['credit_text']); ?>" style="vertical-align: middle;">
                <?php else: ?>
                    <?php echo esc_html($config['credit_text']); ?>
                <?php endif; ?>
            </a>
        </div>
        <?php
    }

    /**
     * Register suite-level REST endpoints.
     *
     * @return void
     */
    public function register_rest_routes() {
        register_rest_route('at-suite/v1', '/status', array(
            'methods' => 'GET',
            'callback' => array($this, 'rest_status'),
            'permission_callback' => function() {
                return current_user_can('manage_options');
            },
        ));
    }

    /**
     * REST callback for suite status.
     *
     * @return WP_REST_Response
     */
    public function rest_status() {
        return new WP_REST_Response($this->get_status(), 200);
    }

    /**
     * Check if a menu slug is already registered in WP globals.
     *
     * @param string $slug
     * @return bool
     */
    private function is_menu_slug_registered($slug) {
        global $menu, $submenu;

        if (is_array($menu)) {
            foreach ($menu as $item) {
                if (isset($item[2]) && $item[2] === $slug) {
                    return true;
                }
            }
        }

        if (is_array($submenu)) {
            foreach ($submenu as $submenu_items) {
                if (!is_array($submenu_items)) {
                    continue;
                }
                foreach ($submenu_items as $item) {
                    if (isset($item[2]) && $item[2] === $slug) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    /**
     * Emit warning to error log and hook listeners.
     *
     * @param string $message
     * @param array  $context
     * @return void
     */
    private function warn($message, $context = array()) {
        if (defined('WP_DEBUG_LOG') && WP_DEBUG_LOG) {
            error_log('[AT Suite Core] ' . $message . ' ' . wp_json_encode($context));
        }

        do_action('at_suite_warning', $message, $context);
    }
}
