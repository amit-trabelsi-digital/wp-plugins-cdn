<?php
/**
 * מחלקה למסך בריאות האתר
 * 
 * מציג מידע על בריאות האתר, עדכוני תוספים, וסטטוס כללי
 */
class AT_Agency_Manager_Health_Dashboard {
    
    /**
     * הצגת מסך הבריאות
     */
    public static function render($args = array()) {
        // בדיקת הרשאות
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'at-agency-manager'));
        }

        $args = wp_parse_args($args, array(
            'embedded' => false,
        ));
        $embedded = !empty($args['embedded']);
        
        $env = AT_Agency_Manager_Environment::get_environment_type();
        $dev_mode = AT_Agency_Manager_Environment::get_development_mode();
        $health_checks = self::get_health_checks();
        $plugin_updates = self::get_plugin_updates();
        $core_updates = self::get_core_updates();
        ?>
        <?php if (!$embedded) : ?>
        <div class="wrap at-health-dashboard at-agency-manager-wrap" style="margin-top: 20px;">
            <?php settings_errors(); ?>
        <?php else : ?>
        <div class="at-health-dashboard at-agency-manager-wrap" style="margin-top: 20px;">
        <?php endif; ?>
            
            <!-- סטטוס סביבה -->
            <div class="card" style="margin-top: 20px;">
                <h2><?php _e('Environment Status', 'at-agency-manager'); ?></h2>
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('Environment Type', 'at-agency-manager'); ?></th>
                        <td>
                            <strong><?php echo esc_html(ucfirst($env)); ?></strong>
                            <span class="dashicons dashicons-<?php echo $env === 'production' ? 'yes-alt' : 'warning'; ?>" 
                                  style="color: <?php echo $env === 'production' ? '#46b450' : '#f0b849'; ?>;"></span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Development Mode', 'at-agency-manager'); ?></th>
                        <td>
                            <?php if ($dev_mode): ?>
                                <strong><?php echo esc_html(ucfirst($dev_mode)); ?></strong>
                            <?php else: ?>
                                <em><?php _e('Not configured', 'at-agency-manager'); ?></em>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('WP_DEBUG', 'at-agency-manager'); ?></th>
                        <td>
                            <?php if (defined('WP_DEBUG') && WP_DEBUG): ?>
                                <span style="color: #d63638;"><?php _e('Enabled', 'at-agency-manager'); ?></span>
                            <?php else: ?>
                                <span style="color: #46b450;"><?php _e('Disabled', 'at-agency-manager'); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
            </div>
            
            <!-- בדיקות בריאות -->
            <div class="card" style="margin-top: 20px;">
                <h2><?php _e('Health Checks', 'at-agency-manager'); ?></h2>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php _e('Check', 'at-agency-manager'); ?></th>
                            <th><?php _e('Status', 'at-agency-manager'); ?></th>
                            <th><?php _e('Description', 'at-agency-manager'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($health_checks as $check): ?>
                            <tr>
                                <td><strong><?php echo esc_html($check['label']); ?></strong></td>
                                <td>
                                    <?php
                                    $status_icon = 'yes-alt';
                                    $status_color = '#46b450';
                                    if ($check['status'] === 'warning') {
                                        $status_icon = 'warning';
                                        $status_color = '#f0b849';
                                    } elseif ($check['status'] === 'critical') {
                                        $status_icon = 'dismiss';
                                        $status_color = '#d63638';
                                    }
                                    ?>
                                    <span class="dashicons dashicons-<?php echo $status_icon; ?>" 
                                          style="color: <?php echo $status_color; ?>;"></span>
                                    <?php echo esc_html(ucfirst($check['status'])); ?>
                                </td>
                                <td><?php echo esc_html($check['description']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- עדכוני תוספים -->
            <?php if (!empty($plugin_updates)): ?>
                <div class="card" style="margin-top: 20px;">
                    <h2><?php _e('Plugin Updates Available', 'at-agency-manager'); ?></h2>
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th><?php _e('Plugin', 'at-agency-manager'); ?></th>
                                <th><?php _e('Current Version', 'at-agency-manager'); ?></th>
                                <th><?php _e('New Version', 'at-agency-manager'); ?></th>
                                <th><?php _e('Action', 'at-agency-manager'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($plugin_updates as $plugin): ?>
                                <tr>
                                    <td><strong><?php echo esc_html($plugin['name']); ?></strong></td>
                                    <td><?php echo esc_html($plugin['current_version']); ?></td>
                                    <td><strong style="color: #d63638;"><?php echo esc_html($plugin['new_version']); ?></strong></td>
                                    <td>
                                        <a href="<?php echo esc_url(admin_url('update-core.php')); ?>" class="button button-primary">
                                            <?php _e('Update Now', 'at-agency-manager'); ?>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
            
            <!-- עדכוני WordPress Core -->
            <?php if (!empty($core_updates)): ?>
                <div class="card" style="margin-top: 20px; border-left: 4px solid #d63638;">
                    <h2><?php _e('WordPress Core Update Available', 'at-agency-manager'); ?></h2>
                    <p>
                        <strong><?php _e('Current Version:', 'at-agency-manager'); ?></strong> 
                        <?php echo esc_html($core_updates['current_version']); ?><br>
                        <strong><?php _e('New Version:', 'at-agency-manager'); ?></strong> 
                        <span style="color: #d63638;"><?php echo esc_html($core_updates['new_version']); ?></span>
                    </p>
                    <p>
                        <a href="<?php echo esc_url(admin_url('update-core.php')); ?>" class="button button-primary button-large">
                            <?php _e('Update WordPress', 'at-agency-manager'); ?>
                        </a>
                    </p>
                </div>
            <?php endif; ?>
            
            <!-- קישורים מהירים -->
            <div class="card" style="margin-top: 20px;">
                <h2><?php _e('Quick Links', 'at-agency-manager'); ?></h2>
                <p>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=at-agency-manager&tab=settings')); ?>" class="button">
                        <?php _e('Settings', 'at-agency-manager'); ?>
                    </a>
                    <a href="<?php echo esc_url(admin_url('site-health.php')); ?>" class="button">
                        <?php _e('WordPress Site Health', 'at-agency-manager'); ?>
                    </a>
                    <a href="<?php echo esc_url(admin_url('update-core.php')); ?>" class="button">
                        <?php _e('Updates', 'at-agency-manager'); ?>
                    </a>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=at-agency-manager-logs')); ?>" class="button">
                        <?php _e('Logs', 'at-agency-manager'); ?>
                    </a>
                </p>
            </div>
        </div>

        <?php if (!$embedded) : ?>
        <style>
            .at-health-dashboard .card {
                background: #fff;
                border: 1px solid #ccd0d4;
                box-shadow: 0 1px 1px rgba(0,0,0,.04);
                padding: 20px;
            }
            .at-health-dashboard .card h2 {
                margin-top: 0;
                padding-bottom: 10px;
                border-bottom: 1px solid #eee;
            }
        </style>
        <?php endif; ?>
        <?php
    }
    
    /**
     * הצגת סטטוס המודולים בדשבורד עם חיווי מפורט והגדרות
     */
    public static function render_modules_status() {
        $modules = get_option('at_agency_manager_modules', []);
        $module_configs = self::get_module_configs();
        
        ?>
        <div class="wrap at-health-dashboard at-agency-manager-wrap" style="margin-top: 20px;">
            <?php settings_errors(); ?>
            
            <!-- הגדרות כלליות -->
            <div class="card" style="margin-top: 20px;">
                <h2><?php _e('General Settings', 'at-agency-manager'); ?></h2>
                <form method="post" action="options.php" style="margin-top: 15px;">
                    <?php
                    settings_fields('at_agency_manager_general');
                    do_settings_sections('at_agency_manager_general');
                    ?>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php _e('API Key', 'at-agency-manager'); ?></th>
                            <td>
                                <div style="display: flex; gap: 10px; align-items: center;">
                                    <input type="text" 
                                           id="at_agency_manager_auth_key" 
                                           name="at_agency_manager_auth_key" 
                                           value="<?php echo esc_attr(get_option('at_agency_manager_auth_key')); ?>" 
                                           class="regular-text"
                                           readonly
                                           style="font-family: monospace; direction: ltr; text-align: left;"
                                    />
                                    <button type="button"
                                            id="generate-api-key-btn"
                                            class="button button-secondary"
                                            data-nonce="<?php echo wp_create_nonce('at_agency_manager_nonce'); ?>">
                                        <?php _e('Generate New Key', 'at-agency-manager'); ?>
                                    </button>
                                    <button type="button"
                                            id="copy-api-key-btn"
                                            class="button button-secondary">
                                        <?php _e('Copy', 'at-agency-manager'); ?>
                                    </button>
                                </div>
                                <p class="description">
                                    <?php _e('This key is required to authenticate API requests. Use the header: X-AT-Agency-Manager-Key', 'at-agency-manager'); ?>
                                </p>
                                <?php 
                                // הצגת מידע על בקשת API אחרונה
                                $last_api_request = self::get_last_api_request();
                                if ($last_api_request): ?>
                                    <p class="description" style="margin-top: 5px;">
                                        <strong><?php _e('Last API Request:', 'at-agency-manager'); ?></strong> 
                                        <?php echo esc_html($last_api_request); ?>
                                    </p>
                                <?php endif; ?>
                                <p class="description">
                                    <a href="<?php echo admin_url('admin.php?page=at-agency-manager-api-docs'); ?>">
                                        <?php _e('View API Documentation', 'at-agency-manager'); ?>
                                    </a>
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Site Type', 'at-agency-manager'); ?></th>
                            <td>
                                <select name="at_agency_manager_site_type">
                                    <option value="production" <?php selected(get_option('at_agency_manager_site_type'), 'production'); ?>><?php _e('Production', 'at-agency-manager'); ?></option>
                                    <option value="staging" <?php selected(get_option('at_agency_manager_site_type'), 'staging'); ?>><?php _e('Staging', 'at-agency-manager'); ?></option>
                                    <option value="development" <?php selected(get_option('at_agency_manager_site_type'), 'development'); ?>><?php _e('Development', 'at-agency-manager'); ?></option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Notifications', 'at-agency-manager'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" 
                                           name="at_agency_manager_notifications[plugins]" 
                                           value="1" 
                                           <?php checked(get_option('at_agency_manager_notifications')['plugins'] ?? false); ?>
                                    />
                                    <?php _e('Plugin Updates', 'at-agency-manager'); ?>
                                </label><br>
                                <label>
                                    <input type="checkbox" 
                                           name="at_agency_manager_notifications[core]" 
                                           value="1" 
                                           <?php checked(get_option('at_agency_manager_notifications')['core'] ?? false); ?>
                                    />
                                    <?php _e('WordPress Core Updates', 'at-agency-manager'); ?>
                                </label><br>
                                <label>
                                    <input type="checkbox" 
                                           name="at_agency_manager_notifications[security]" 
                                           value="1" 
                                           <?php checked(get_option('at_agency_manager_notifications')['security'] ?? false); ?>
                                    />
                                    <?php _e('Security Alerts', 'at-agency-manager'); ?>
                                </label>
                            </td>
                        </tr>
                        <tr id="login-url-settings">
                             <th scope="row"><?php _e('Custom Login URL', 'at-agency-manager'); ?></th>
                             <td>
                                 <input type="text" name="at_custom_login_slug" value="<?php echo esc_attr(get_option('at_custom_login_slug', 'login')); ?>" class="regular-text" />
                                 <p class="description"><?php _e('Change the default wp-login.php slug. Example: my-login', 'at-agency-manager'); ?></p>
                             </td>
                         </tr>
                    </table>
                    
                    <h3 style="margin-top: 30px; margin-bottom: 15px;"><?php _e('Modules', 'at-agency-manager'); ?></h3>
                    <p class="description" style="margin-bottom: 15px;"><?php _e('Enable or disable modules below. Active modules will show detailed status information.', 'at-agency-manager'); ?></p>
                    
                    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(450px, 1fr)); gap: 15px; margin-bottom: 20px;">
                        <?php foreach ($module_configs as $module_key => $config):
                            $is_enabled = !empty($modules[$module_key]);
                            $is_installed = $config['installed'];
                            
                            // ערכת סטטוס צבעים
                            if (!$is_installed) {
                                $status_badge = '<span style="background: #ffeaa7; color: #d63638; padding: 2px 8px; border-radius: 3px; font-size: 11px; font-weight: bold; margin-left: 5px;">' . __('Unavailable', 'at-agency-manager') . '</span>';
                                $border_color = '#ffcccb';
                            } elseif ($is_enabled) {
                                $status_badge = '<span style="background: #a4de6c; color: #008a20; padding: 2px 8px; border-radius: 3px; font-size: 11px; font-weight: bold; margin-left: 5px;">' . __('Active', 'at-agency-manager') . '</span>';
                                $border_color = '#a4de6c';
                            } else {
                                $status_badge = '<span style="background: #e0e0e0; color: #666; padding: 2px 8px; border-radius: 3px; font-size: 11px; font-weight: bold; margin-left: 5px;">' . __('Inactive', 'at-agency-manager') . '</span>';
                                $border_color = '#e0e0e0';
                            }
                        ?>
                            <div style="padding: 15px; background: #fff; border: 2px solid <?php echo esc_attr($border_color); ?>; border-radius: 8px; transition: all 0.3s ease; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                                <div style="display: flex; align-items: flex-start; gap: 12px; margin-bottom: 10px;">
                                    <input type="checkbox"
                                           name="at_agency_manager_modules[<?php echo esc_attr($module_key); ?>]"
                                           value="1"
                                           <?php checked($is_enabled && $is_installed); ?>
                                           <?php disabled(!$is_installed); ?>
                                           style="margin-top: 3px; width: 18px; height: 18px; cursor: pointer;"
                                    />
                                    <div style="flex: 1;">
                                        <div style="margin-bottom: 8px;">
                                            <strong style="font-size: 14px; color: #1d2327;"><?php echo esc_html($config['label']); ?></strong>
                                            <?php echo wp_kses_post($status_badge); ?>
                                        </div>
                                        
                                        <?php if (!empty($config['description'])): ?>
                                            <p style="margin: 0; font-size: 13px; color: #646970; line-height: 1.5;">
                                                <?php echo esc_html($config['description']); ?>
                                            </p>
                                        <?php endif; ?>
                                        
                                        <?php if (!$is_installed && !empty($config['error'])): ?>
                                            <div style="margin-top: 8px; padding: 8px; background: #fef1f1; border-radius: 4px;">
                                                <span style="color: #d63638; font-size: 12px; display: flex; align-items: center; gap: 5px;">
                                                    <span class="dashicons dashicons-warning" style="width: 16px; height: 16px; font-size: 16px;"></span>
                                                    <?php echo esc_html($config['error']); ?>
                                                </span>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <?php submit_button(); ?>
                </form>
            </div>
            
            <!-- סטטוס מפורט של המודולים -->
            <div class="card" style="margin-top: 20px;">
                <h2><?php _e('Module Status & Details', 'at-agency-manager'); ?></h2>
                <p class="description"><?php _e('Detailed status information for all modules', 'at-agency-manager'); ?></p>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(380px, 1fr)); gap: 20px; margin-top: 20px;">
                    <?php foreach ($module_configs as $module_key => $config): ?>
                        <?php
                        $is_enabled = !empty($modules[$module_key]);
                        $is_installed = $config['installed'];
                        $status_icon = 'disabled';
                        $status_color = '#ccc';
                        $status_text = __('Inactive', 'at-agency-manager');
                        $border_color = '#e0e0e0';
                        
                        if ($is_enabled) {
                            if ($is_installed) {
                                $status_icon = 'yes-alt';
                                $status_color = '#46b450';
                                $status_text = __('Active', 'at-agency-manager');
                                $border_color = '#a4de6c';
                            } else {
                                $status_icon = 'warning';
                                $status_color = '#d63638';
                                $status_text = __('Error', 'at-agency-manager');
                                $border_color = '#ffcccb';
                            }
                        } elseif (!$is_installed) {
                            $status_icon = 'dismiss';
                            $status_color = '#f0b849';
                            $status_text = __('Unavailable', 'at-agency-manager');
                            $border_color = '#ffeaa7';
                        }
                        
                        // קבלת מידע מפורט לפי מודול
                        $module_details = self::get_module_details($module_key, $is_enabled, $is_installed);
                        ?>
                        <div class="at-module-card" style="border: 2px solid <?php echo esc_attr($border_color); ?>; border-radius: 8px; padding: 18px; background: #fff; box-shadow: 0 2px 4px rgba(0,0,0,0.08); transition: all 0.3s ease;">
                            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 15px; padding-bottom: 12px; border-bottom: 2px solid #f5f5f5;">
                                <h4 style="margin: 0; flex: 1; font-size: 16px; font-weight: 600; color: #1d2327;"><?php echo esc_html($config['label']); ?></h4>
                                <span class="dashicons dashicons-<?php echo esc_attr($status_icon); ?>" 
                                      style="color: <?php echo esc_attr($status_color); ?>; font-size: 24px; width: 24px; height: 24px;"></span>
                            </div>
                            
                            <div style="margin-bottom: 15px;">
                                <div style="margin-bottom: 12px;">
                                    <span style="display: inline-block; padding: 4px 10px; background: <?php echo esc_attr($border_color); ?>; color: <?php echo esc_attr($status_color); ?>; border-radius: 4px; font-size: 12px; font-weight: 600;">
                                        <?php echo esc_html($status_text); ?>
                                    </span>
                                </div>
                                
                                <?php if (!empty($config['description'])): ?>
                                    <p style="margin: 0 0 12px 0; font-size: 13px; color: #646970; line-height: 1.6;">
                                        <?php echo esc_html($config['description']); ?>
                                    </p>
                                <?php endif; ?>
                                
                                <?php if (!empty($module_details)): ?>
                                    <div class="module-details" style="margin-top: 12px; padding: 12px; background: #f9f9f9; border-radius: 6px; border-right: 3px solid <?php echo esc_attr($status_color); ?>;">
                                        <?php echo $module_details; ?>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if (!$is_installed && !empty($config['error'])): ?>
                                    <div style="margin-top: 12px; padding: 10px; background: #fef1f1; border-radius: 6px; border-right: 3px solid #d63638;">
                                        <span style="color: #d63638; font-size: 12px; display: flex; align-items: center; gap: 6px;">
                                            <span class="dashicons dashicons-warning" style="width: 16px; height: 16px; font-size: 16px;"></span>
                                            <?php echo esc_html($config['error']); ?>
                                        </span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div style="display: flex; gap: 10px; margin-top: 15px; padding-top: 15px; border-top: 2px solid #f5f5f5;">
                                <?php if ($is_enabled && $is_installed): ?>
                                    <?php if (!empty($config['settings_url'])): ?>
                                        <a href="<?php echo esc_url($config['settings_url']); ?>" class="button button-primary button-small" style="flex: 1; text-align: center; padding: 6px 12px;">
                                            <span class="dashicons dashicons-admin-settings" style="font-size: 14px; width: 14px; height: 14px; margin-top: 2px; margin-left: 4px;"></span>
                                            <?php _e('Settings', 'at-agency-manager'); ?>
                                        </a>
                                    <?php endif; ?>
                                    
                                    <?php 
                                    // כפתורים מותאמים לפי מודול
                                    $action_button = self::get_module_action_button($module_key, $is_enabled, $is_installed);
                                    if ($action_button) {
                                        echo $action_button;
                                    }
                                    ?>
                                <?php else: ?>
                                    <a href="<?php echo esc_url(admin_url('admin.php?page=at-agency-manager&tab=dashboard')); ?>" class="button button-secondary button-small" style="flex: 1; text-align: center; padding: 6px 12px;">
                                        <span class="dashicons dashicons-admin-generic" style="font-size: 14px; width: 14px; height: 14px; margin-top: 2px; margin-left: 4px;"></span>
                                        <?php _e('Configure', 'at-agency-manager'); ?>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        
        <style>
        .at-health-dashboard .card {
            background: #fff;
            border: 1px solid #ddd;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            padding: 20px;
            border-radius: 8px;
        }
        .at-health-dashboard .card h2 {
            margin-top: 0;
            padding-bottom: 15px;
            border-bottom: 2px solid #f5f5f5;
            color: #1d2327;
            font-weight: 600;
        }
        .at-module-card {
            transition: all 0.3s ease;
        }
        .at-module-card:hover {
            box-shadow: 0 4px 12px rgba(0,0,0,0.12) !important;
            transform: translateY(-2px);
        }
        .module-details {
            font-size: 12px;
            line-height: 1.6;
        }
        .module-details .detail-row {
            margin: 6px 0;
            padding: 4px 0;
        }
        .module-details .detail-label {
            font-weight: 600;
            color: #555;
            display: inline-block;
            min-width: 100px;
        }
        .module-details .detail-value {
            color: #333;
        }
        .module-details .detail-value code {
            background: #f5f5f5;
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 11px;
            font-family: monospace;
        }
        
        /* רספונסיביות לגרידים */
        @media screen and (max-width: 1400px) {
            .at-health-dashboard [style*="grid-template-columns"] {
                grid-template-columns: repeat(auto-fill, minmax(350px, 1fr)) !important;
            }
        }
        
        @media screen and (max-width: 782px) {
            .at-health-dashboard [style*="grid-template-columns"] {
                grid-template-columns: 1fr !important;
            }
            .at-module-card {
                margin: 0 !important;
            }
        }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            // Generate API Key
            $('#generate-api-key-btn').on('click', function() {
                var button = $(this);
                var nonce = button.data('nonce');
                var originalText = button.text();
                
                button.prop('disabled', true).text('<?php _e('Generating...', 'at-agency-manager'); ?>');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'at_generate_api_key',
                        nonce: nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#at_agency_manager_auth_key').val(response.data.key);
                            alert('<?php _e('New API key generated successfully!', 'at-agency-manager'); ?>');
                        } else {
                            alert('<?php _e('Error: ', 'at-agency-manager'); ?>' + (response.data.message || '<?php _e('Unknown error', 'at-agency-manager'); ?>'));
                        }
                        button.prop('disabled', false).text(originalText);
                    },
                    error: function() {
                        alert('<?php _e('Error generating API key. Please try again.', 'at-agency-manager'); ?>');
                        button.prop('disabled', false).text(originalText);
                    }
                });
            });
            
            // Copy API Key
            $('#copy-api-key-btn').on('click', function() {
                var keyInput = $('#at_agency_manager_auth_key');
                keyInput.select();
                document.execCommand('copy');
                
                var button = $(this);
                var originalText = button.text();
                button.text('<?php _e('Copied!', 'at-agency-manager'); ?>');
                setTimeout(function() {
                    button.text(originalText);
                }, 2000);
            });
        });
        </script>
        <?php
    }
    
    /**
     * קבלת פרטים מפורטים למודול ספציפי
     */
    private static function get_module_details($module_key, $is_enabled, $is_installed) {
        if (!$is_enabled || !$is_installed) {
            return '';
        }
        
        $details = '';
        
        switch ($module_key) {
            case 'hide_login':
                $current_slug = get_option('at_custom_login_slug', 'login');
                $login_url = site_url($current_slug, 'login');
                $details .= '<div class="detail-row">';
                $details .= '<span class="detail-label">' . __('Current URL:', 'at-agency-manager') . '</span> ';
                $details .= '<span class="detail-value"><code>' . esc_html($login_url) . '</code></span>';
                $details .= '</div>';
                break;
                
            case 'backup':
                $last_backup = get_option('at_backup_last_success');
                $cloud_service = get_option('at_backup_cloud_service', 'local');
                $backup_dir = trailingslashit(wp_upload_dir()['basedir']) . 'at-backups';
                $total_size = 0;
                
                if (file_exists($backup_dir) && is_dir($backup_dir)) {
                    $files = glob($backup_dir . '/*.zip');
                    if ($files) {
                        foreach ($files as $file) {
                            $total_size += filesize($file);
                        }
                    }
                }
                
                $details .= '<div class="detail-row">';
                $details .= '<span class="detail-label">' . __('Last Backup:', 'at-agency-manager') . '</span> ';
                $details .= '<span class="detail-value">' . ($last_backup ? esc_html($last_backup) : __('Never', 'at-agency-manager')) . '</span>';
                $details .= '</div>';
                
                $details .= '<div class="detail-row">';
                $details .= '<span class="detail-label">' . __('Destination:', 'at-agency-manager') . '</span> ';
                $destination_names = [
                    'local' => __('Local Storage', 'at-agency-manager'),
                    'google_drive' => __('Google Drive', 'at-agency-manager'),
                    'dropbox' => __('Dropbox', 'at-agency-manager'),
                    's3' => __('Amazon S3', 'at-agency-manager')
                ];
                $details .= '<span class="detail-value">' . ($destination_names[$cloud_service] ?? ucfirst($cloud_service)) . '</span>';
                $details .= '</div>';
                
                if ($total_size > 0) {
                    $details .= '<div class="detail-row">';
                    $details .= '<span class="detail-label">' . __('Total Size:', 'at-agency-manager') . '</span> ';
                    $details .= '<span class="detail-value">' . size_format($total_size) . '</span>';
                    $details .= '</div>';
                }
                break;
                
            case 's3_media_sync':
                $s3_installed = class_exists('Aws\\S3\\S3Client');
                if (!$s3_installed) {
                    $details .= '<div class="detail-row">';
                    $details .= '<span style="color: #d63638; font-weight: 600;">' . __('AWS SDK not installed', 'at-agency-manager') . '</span>';
                    $details .= '</div>';
                } else {
                    $details .= '<div class="detail-row">';
                    $details .= '<span class="detail-label">' . __('Status:', 'at-agency-manager') . '</span> ';
                    $details .= '<span class="detail-value" style="color: #46b450;">' . __('Ready', 'at-agency-manager') . '</span>';
                    $details .= '</div>';
                }
                break;
                
            case 'newrelic_monitoring':
                $nr_active = extension_loaded('newrelic');
                if ($nr_active) {
                    // נסה לקבל שגיאות מ-24 שעות האחרונות
                    // זה דורש גישה ל-New Relic API, בינתיים נציג רק שהמודול פעיל
                    $details .= '<div class="detail-row">';
                    $details .= '<span class="detail-label">' . __('Status:', 'at-agency-manager') . '</span> ';
                    $details .= '<span class="detail-value" style="color: #46b450;">' . __('Active', 'at-agency-manager') . '</span>';
                    $details .= '</div>';
                    
                    // TODO: הוסף חיבור ל-New Relic API לקבלת מספר שגיאות
                    // $errors_count = self::get_newrelic_errors_last_24h();
                    // $details .= '<div class="detail-row">';
                    // $details .= '<span class="detail-label">' . __('Errors (24h):', 'at-agency-manager') . '</span> ';
                    // $details .= '<span class="detail-value">' . intval($errors_count) . '</span>';
                    // $details .= '</div>';
                }
                break;
                
            case 'acf_local_json':
                if (function_exists('acf_get_field_groups')) {
                    $acf_json_path = get_stylesheet_directory() . '/acf-json';
                    $json_files = glob($acf_json_path . '/*.json');
                    $field_groups = acf_get_field_groups();
                    $json_count = is_array($json_files) ? count($json_files) : 0;
                    $groups_count = is_array($field_groups) ? count($field_groups) : 0;
                    
                    // בדיקת סנכרון
                    $needs_sync = false;
                    $needs_import = false;
                    
                    if (!empty($field_groups)) {
                        foreach ($field_groups as $group) {
                            $json_file = $acf_json_path . '/' . $group['key'] . '.json';
                            if (!file_exists($json_file)) {
                                $needs_sync = true;
                            } elseif (file_exists($json_file)) {
                                $json_data = json_decode(file_get_contents($json_file), true);
                                if ($json_data && isset($json_data['modified']) && $group['modified'] < $json_data['modified']) {
                                    $needs_import = true;
                                }
                            }
                        }
                    }
                    
                    $details .= '<div class="detail-row">';
                    $details .= '<span class="detail-label">' . __('Field Groups:', 'at-agency-manager') . '</span> ';
                    $details .= '<span class="detail-value">' . intval($groups_count) . '</span>';
                    $details .= '</div>';
                    
                    $details .= '<div class="detail-row">';
                    $details .= '<span class="detail-label">' . __('JSON Files:', 'at-agency-manager') . '</span> ';
                    $details .= '<span class="detail-value">' . intval($json_count) . '</span>';
                    $details .= '</div>';
                    
                    if ($needs_sync) {
                        $details .= '<div class="detail-row">';
                        $details .= '<span style="color: #f0b849; font-weight: 600;">' . __('⚠ Needs sync to JSON', 'at-agency-manager') . '</span>';
                        $details .= '</div>';
                    } elseif ($needs_import) {
                        $details .= '<div class="detail-row">';
                        $details .= '<span style="color: #f0b849; font-weight: 600;">' . __('⚠ Needs import from JSON', 'at-agency-manager') . '</span>';
                        $details .= '</div>';
                    } else {
                        $details .= '<div class="detail-row">';
                        $details .= '<span style="color: #46b450; font-weight: 600;">' . __('✓ Synchronized', 'at-agency-manager') . '</span>';
                        $details .= '</div>';
                    }
                }
                break;
        }
        
        // REST API - זה לא מודול נפרד אבל צריך להציג אותו
        // נציג אותו כחלק מההגדרות הכלליות
        
        return $details;
    }
    
    /**
     * קבלת זמן בקשת API אחרונה מהלוגים
     */
    private static function get_last_api_request() {
        global $wpdb;
        $logger = new AT_Agency_Manager_Logger();
        $table_name = $wpdb->prefix . 'at_agency_manager_logs';
        
        $last_log = $wpdb->get_row(
            "SELECT created_at, message 
             FROM {$table_name} 
             WHERE type = 'api' 
             ORDER BY created_at DESC 
             LIMIT 1"
        );
        
        if ($last_log) {
            return sprintf(
                __('%s - %s', 'at-agency-manager'),
                date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($last_log->created_at)),
                esc_html($last_log->message)
            );
        }
        
        return null;
    }
    
    /**
     * קבלת כפתור פעולה מותאם למודול
     */
    private static function get_module_action_button($module_key, $is_enabled, $is_installed) {
        if (!$is_enabled || !$is_installed) {
            return '';
        }
        
        $button = '';
        
        switch ($module_key) {
            case 'hide_login':
                $button = '<a href="' . esc_url(admin_url('admin.php?page=at-agency-manager&tab=dashboard')) . '#login-url-settings" class="button button-secondary button-small">' . 
                          __('Configure Secure Path', 'at-agency-manager') . '</a>';
                break;
                
            case 's3_media_sync':
                if (!class_exists('Aws\\S3\\S3Client')) {
                    // קישור להנחיות - בדיקה אם קיים README-S3
                    $readme_path = AT_AGENCY_MANAGER_PATH . '../README-S3-Media-Sync-Integration.md';
                    $readme_url = '';
                    if (file_exists($readme_path)) {
                        $readme_url = plugins_url('README-S3-Media-Sync-Integration.md', dirname(AT_AGENCY_MANAGER_PATH));
                    } else {
                        // קישור לדף ההגדרות של S3
                        $readme_url = admin_url('admin.php?page=s3-media-sync-settings');
                    }
                    $button = '<a href="' . esc_url($readme_url) . '" target="_blank" class="button button-secondary button-small">' . 
                              __('Install SDK / View Instructions', 'at-agency-manager') . '</a>';
                }
                break;
        }
        
        return $button;
    }
    
    /**
     * קבלת הגדרות כל המודולים
     */
    private static function get_module_configs() {
        $elementor_installed = did_action('elementor/loaded');
        $acf_installed = (class_exists('ACF', false) || function_exists('acf_get_field_groups'));
        
        return array(
            'acf_elementor_tag' => array(
                'label' => __('ACF Enhanced Elementor Tag', 'at-agency-manager'),
                'description' => __('מאפשר שימוש בשדות ACF מתקדמים בתוך Elementor עם תמיכה בתצוגות מותאמות אישית, טרנספורמציות ועיצוב דינמי.', 'at-agency-manager'),
                'installed' => $elementor_installed && $acf_installed,
                'error' => (!$elementor_installed || !$acf_installed) ? __('(Requires Elementor and ACF)', 'at-agency-manager') : '',
                'settings_url' => null
            ),
            'acf_local_json' => array(
                'label' => __('ACF Local JSON Manager', 'at-agency-manager'),
                'description' => __('מנהל ייצוא וייבוא אוטומטי של קבוצות שדות ACF לקבצי JSON, מאפשר סנכרון בין סביבות ושליטה בגרסאות.', 'at-agency-manager'),
                'installed' => $acf_installed,
                'error' => !$acf_installed ? __('(ACF plugin not installed)', 'at-agency-manager') : '',
                'settings_url' => admin_url('admin.php?page=at-acf-local-json')
            ),
            'acf_copy_tool' => array(
                'label' => __('ACF Copy Fields Tool', 'at-agency-manager'),
                'description' => __('כלי להעתקה מהירה של שדות ACF בין קבוצות שדות שונות, חוסך זמן ומונע טעויות.', 'at-agency-manager'),
                'installed' => true,
                'error' => '',
                'settings_url' => admin_url('admin.php?page=at-acf-copy-tool')
            ),
            'site_health' => array(
                'label' => __('Site Health Panel', 'at-agency-manager'),
                'description' => __('לוח בקרה מרכזי המציג מצב בריאות האתר, ביצועים, עדכונים ותקלות אפשריות במקום אחד.', 'at-agency-manager'),
                'installed' => true,
                'error' => '',
                'settings_url' => admin_url('admin.php?page=at-agency-manager&tab=dashboard')
            ),
            'hide_login' => array(
                'label' => __('Custom Login URL (Hide wp-login.php)', 'at-agency-manager'),
                'description' => __('משנה את כתובת עמוד ההתחברות לכתובת מותאמת אישית, מגן מפני התקפות brute-force ומשפר אבטחת האתר.', 'at-agency-manager'),
                'installed' => true,
                'error' => '',
                'settings_url' => admin_url('admin.php?page=at-hide-login-settings')
            ),
            'activity_log' => array(
                'label' => __('Activity Log', 'at-agency-manager'),
                'description' => __('רושם את כל הפעולות של משתמשים באתר: התחברות, עריכת תכנים, שינויי הגדרות ועוד. מועיל לניטור ומעקב.', 'at-agency-manager'),
                'installed' => true,
                'error' => '',
                'settings_url' => admin_url('admin.php?page=at-activity-log')
            ),
            'email_log' => array(
                'label' => __('Email Log', 'at-agency-manager'),
                'description' => __('מתעד את כל המיילים שנשלחו מהאתר, כולל סטטוס משלוח, שגיאות ותוכן ההודעה לצורך איתור תקלות.', 'at-agency-manager'),
                'installed' => true,
                'error' => '',
                'settings_url' => admin_url('admin.php?page=at-email-log')
            ),
            'backup' => array(
                'label' => __('Site Backup (Google Drive/Dropbox/S3)', 'at-agency-manager'),
                'description' => __('יוצר גיבויים אוטומטיים מלאים של האתר ומאחסן אותם ב-Google Drive, Dropbox או Amazon S3 לשמירה מאובטחת.', 'at-agency-manager'),
                'installed' => true,
                'error' => '',
                'settings_url' => admin_url('admin.php?page=at-agency-manager-backup')
            ),
            's3_media_sync' => array(
                'label' => __('S3 Media Sync (Amazon S3)', 'at-agency-manager'),
                'description' => __('מסנכרן אוטומטית את ספריית המדיה לAmazon S3, משפר מהירות טעינה ומפחית עומס על השרת.', 'at-agency-manager'),
                'installed' => class_exists('Aws\\S3\\S3Client'),
                'error' => !class_exists('Aws\\S3\\S3Client') ? __('(AWS SDK not installed)', 'at-agency-manager') : '',
                'settings_url' => admin_url('admin.php?page=at-agency-s3-sync')
            ),
            'newrelic_monitoring' => array(
                'label' => __('New Relic Monitoring', 'at-agency-manager'),
                'description' => __('אינטגרציה עם New Relic לניטור ביצועים מתקדם, איתור צווארי בקבוק וניתוח שגיאות בזמן אמת.', 'at-agency-manager'),
                'installed' => extension_loaded('newrelic'),
                'error' => !extension_loaded('newrelic') ? __('(New Relic PHP extension not installed)', 'at-agency-manager') : '',
                'settings_url' => admin_url('admin.php?page=at-newrelic-settings')
            ),
            'page_ordering' => array(
                'label' => __('Page Ordering (Drag & Drop)', 'at-agency-manager'),
                'description' => __('מאפשר סידור מחדש של עמודים בממשק הניהול באמצעות גרירה ושחרור פשוט, ללא צורך בקידוד.', 'at-agency-manager'),
                'installed' => true,
                'error' => '',
                'settings_url' => admin_url('admin.php?page=at-page-ordering-settings')
            ),
        );
    }

    /**
     * קבלת רשימת בדיקות בריאות
     * 
     * @return array
     */
    private static function get_health_checks() {
        $checks = [];
        
        // בדיקת סביבה
        $env_check = AT_Agency_Manager_Environment::get_environment_health_check();
        if ($env_check) {
            $checks[] = $env_check;
        }
        
        // בדיקת עדכוני תוספים
        $plugin_updates = self::get_plugin_updates();
        if (!empty($plugin_updates)) {
            $checks[] = [
                'status' => 'warning',
                'label' => __('Plugin Updates Available', 'at-agency-manager'),
                'description' => sprintf(
                    __('%d plugin(s) have updates available.', 'at-agency-manager'),
                    count($plugin_updates)
                ),
            ];
        }
        
        // בדיקת עדכוני Core
        $core_updates = self::get_core_updates();
        if (!empty($core_updates)) {
            $checks[] = [
                'status' => 'critical',
                'label' => __('WordPress Core Update Available', 'at-agency-manager'),
                'description' => sprintf(
                    __('WordPress %s is available. Please update.', 'at-agency-manager'),
                    $core_updates['new_version']
                ),
            ];
        }
        
        // בדיקת WP_DEBUG ב-production
        if (AT_Agency_Manager_Environment::is_production() && defined('WP_DEBUG') && WP_DEBUG) {
            $checks[] = [
                'status' => 'warning',
                'label' => __('WP_DEBUG Enabled in Production', 'at-agency-manager'),
                'description' => __('WP_DEBUG is enabled in production environment. This should be disabled.', 'at-agency-manager'),
            ];
        }
        
        // אם אין בעיות, הוסף הודעה חיובית
        if (empty($checks)) {
            $checks[] = [
                'status' => 'good',
                'label' => __('All Systems Operational', 'at-agency-manager'),
                'description' => __('No issues detected. Your site is healthy.', 'at-agency-manager'),
            ];
        }
        
        return $checks;
    }
    
    /**
     * קבלת רשימת עדכוני תוספים
     * 
     * @return array
     */
    private static function get_plugin_updates() {
        if (!function_exists('get_plugin_updates')) {
            require_once ABSPATH . 'wp-admin/includes/update.php';
        }
        
        $plugin_updates = get_plugin_updates();
        $updates = [];
        
        foreach ($plugin_updates as $plugin_file => $plugin_data) {
            $updates[] = [
                'name' => $plugin_data->Name,
                'current_version' => $plugin_data->Version,
                'new_version' => $plugin_data->update->new_version,
                'file' => $plugin_file,
            ];
        }
        
        return $updates;
    }
    
    /**
     * קבלת מידע על עדכוני WordPress Core
     * 
     * @return array|null
     */
    private static function get_core_updates() {
        if (!function_exists('get_core_updates')) {
            require_once ABSPATH . 'wp-admin/includes/update.php';
        }
        
        $core_updates = get_core_updates();
        
        if (empty($core_updates) || $core_updates[0]->response === 'latest') {
            return null;
        }
        
        return [
            'current_version' => get_bloginfo('version'),
            'new_version' => $core_updates[0]->version,
        ];
    }
}
