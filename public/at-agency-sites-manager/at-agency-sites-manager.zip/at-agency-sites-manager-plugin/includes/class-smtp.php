<?php
/**
 * מחלקה לניהול שליחת מיילים דרך SMTP
 */
class AT_Agency_Manager_SMTP {
    /**
     * @var AT_Agency_Manager_Logger מופע של מחלקת הלוגר
     */
    private $logger;

    /**
     * אתחול המחלקה והגדרת האזנה לאירועים רלוונטיים
     * 
     * @param AT_Agency_Manager_Logger $logger מופע של מחלקת הלוגר
     */
    public function __construct($logger) {
        $this->logger = $logger;
        
        // רק אם מופעלת תמיכה ב-SMTP
        if (get_option('at_use_sendgrid') || get_option('at_agency_manager_smtp_host')) {
            add_action('phpmailer_init', array($this, 'configure_smtp'));
            add_action('wp_mail_failed', array($this, 'log_mail_error'));
            add_filter('wp_mail', array($this, 'format_html_email'));
        }
    }

    /**
     * הגדרת ה-SMTP במערכת שליחת המיילים
     * 
     * @param PHPMailer $phpmailer אובייקט ה-phpmailer
     */
    public function configure_smtp($phpmailer) {
        // בדיקה אם שליחת מיילים מורשית בסביבת פיתוח
        if (!$this->is_email_allowed_in_development()) {
            // חסימת שליחת מיילים בסביבת פיתוח אלא אם אושר במפורש
            $phpmailer->ClearAllRecipients();
            $phpmailer->ClearAttachments();
            $phpmailer->ClearCustomHeaders();
            $phpmailer->ClearReplyTos();

            // רישום בלוג
            if ($this->logger) {
                $this->logger->log('email_blocked', 'Email sending blocked in development environment', 'warning');
            }

            // הוספת התראה למנהל
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error is-dismissible">';
                echo '<p><strong>📧 ' . __('Email Blocked', 'at-agency-manager') . ':</strong> ';
                echo __('Email sending has been blocked in development environment for safety.', 'at-agency-manager') . '</p>';
                echo '<p><a href="' . admin_url('admin.php?page=at-agency-manager') . '">' . __('Enable email sending', 'at-agency-manager') . '</a></p>';
                echo '</div>';
            });

            return;
        }

        $phpmailer->isSMTP();
        $phpmailer->SMTPAuth = true;
        $phpmailer->IsHTML(true);

        // בדיקה אם אנחנו בסביבת פיתוח
        $is_dev = $this->is_development_environment();

        if ($is_dev) {
            // הגדרות סביבת פיתוח - Mailtrap כברירת מחדל
            $dev_smtp_host = get_option('at_agency_manager_dev_smtp_host', 'smtp.mailtrap.io');
            $dev_smtp_port = get_option('at_agency_manager_dev_smtp_port', '2525');
            $dev_smtp_user = get_option('at_agency_manager_dev_smtp_user', 'd3338ad3f09d56');
            $dev_smtp_pass = get_option('at_agency_manager_dev_smtp_pass', '6850d48f7af7b6');

            $phpmailer->Port = $dev_smtp_port;
            $phpmailer->Host = $dev_smtp_host;
            $phpmailer->Username = $dev_smtp_user;
            $phpmailer->Password = $dev_smtp_pass;

            // רישום בלוג על שליחת מייל בסביבת פיתוח
            if ($this->logger) {
                $this->logger->log('email_dev_mode', 'Email sent in development mode using ' . $dev_smtp_host, 'info');
            }
        } else {
            // הגדרות סביבת ייצור
            $use_custom_smtp = get_option('at_agency_manager_smtp_host');
            
            if ($use_custom_smtp) {
                // השתמש בהגדרות המותאמות אישית
                $phpmailer->Host = get_option('at_agency_manager_smtp_host');
                $phpmailer->Port = get_option('at_agency_manager_smtp_port', 587);
                $phpmailer->Username = get_option('at_agency_manager_smtp_user');
                $phpmailer->Password = get_option('at_agency_manager_smtp_pass');
                $phpmailer->SMTPSecure = 'tls';
            } else {
                // השתמש בהגדרות SendGrid
                $phpmailer->Host = 'smtp.sendgrid.net';
                $phpmailer->Port = 25;
                $phpmailer->Username = 'apikey';
                $phpmailer->Password = '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';
                $phpmailer->SMTPSecure = 'tls';
            }
        }
        
        // הגדרת שם השולח וכתובת המייל
        $phpmailer->FromName = $this->get_from_name();
        $phpmailer->From = $this->get_from_email();
    }

    /**
     * קבלת שם השולח
     * 
     * @return string שם השולח
     */
    public function get_from_name() {
        $at_sender_email_name = get_option('at_sender_email_name');
        return $at_sender_email_name ? $at_sender_email_name : get_bloginfo('name');
    }

    /**
     * קבלת כתובת המייל של השולח
     * 
     * @return string כתובת המייל של השולח
     */
    public function get_from_email() {
        $at_sender_email_address = get_option('at_sender_email_address');
        
        if ($at_sender_email_address) {
            return $at_sender_email_address;
        }
        
        // יצירת כתובת מייל על בסיס דומיין האתר
        $protocols = array('http://','https://', 'http://www.', 'https://www.', 'www.');
        $site = str_replace($protocols, '', get_bloginfo('wpurl'));
        return 'info@' . $site;
    }

    /**
     * רישום לוג של שגיאות בשליחת מיילים
     * 
     * @param WP_Error $wp_error אובייקט השגיאה
     */
    public function log_mail_error($wp_error) {
        $fn = ABSPATH . '/mail.log';
        $fp = fopen($fn, 'a');
        fputs($fp, "Mailer Error: " . $wp_error->get_error_message() . "\n");
        fclose($fp);
        
        // לוג גם במערכת הלוגים של התוסף
        $this->logger->log('email_error', $wp_error->get_error_message(), 'error');
    }

    /**
     * עיצוב מיילים כ-HTML
     * 
     * @param array $atts מאפייני המייל
     * @return array מאפייני המייל המעודכנים
     */
    public function format_html_email($atts) {
        // ודא ש-headers הוא מערך
        if (!isset($atts['headers'])) {
            $atts['headers'] = array();
        } elseif (is_string($atts['headers'])) {
            $atts['headers'] = array($atts['headers']);
        }
        
        // הוסף כותרת HTML לדואר
        $atts['headers'][] = 'Content-Type: text/html; charset=UTF-8';
        
        $base = $atts['message'];
        ob_start();
        include AT_AGENCY_MANAGER_PATH . 'templates/email-template.php';
        $message = ob_get_contents();
        ob_end_clean();
        
        $atts['message'] = $message;
        return $atts;
    }

    /**
     * שליחת מייל בדיקה
     * 
     * @return bool האם המייל נשלח בהצלחה
     */
    public function send_test_email() {
        $to = get_option('admin_email');
        $subject = __('SMTP Test Email', 'at-agency-manager');
        $message = __('This is a test email from AT Agency Manager plugin.', 'at-agency-manager');
        
        $result = wp_mail($to, $subject, $message);
        $this->logger->log_email($to, $subject, $result ? 'success' : 'error');
        
        return $result;
    }

    /**
     * בדיקה אם שליחת מיילים מורשית בסביבת פיתוח
     *
     * @return bool האם מורשה לשלוח מיילים
     */
    private function is_email_allowed_in_development() {
        // אם לא בסביבת פיתוח - מורשה תמיד
        if (!$this->is_development_environment()) {
            return true;
        }

        // בדיקת הגדרת התוסף
        return get_option('at_agency_manager_enable_remote_api', false);
    }

    /**
     * בדיקה אם אנחנו בסביבת פיתוח
     *
     * @return bool האם בסביבת פיתוח
     */
    private function is_development_environment() {
        // בדיקת WP_DEBUG
        if (!defined('WP_DEBUG') || !WP_DEBUG) {
            return false;
        }

        // בדיקת סוג סביבה
        $env_type = wp_get_environment_type();
        if (in_array($env_type, array('local', 'development'))) {
            return true;
        }

        // בדיקת הגדרת התוסף
        $site_type = get_option('at_agency_manager_site_type', 'production');
        if ($site_type === 'development') {
            return true;
        }

        return false;
    }
}