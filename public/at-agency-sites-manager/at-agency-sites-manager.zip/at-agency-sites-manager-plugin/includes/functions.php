<?php
// Exit if accessed directly
defined('ABSPATH') || exit;

/**
 * פונקציות עזר לתוסף AT Agency Manager
 */

// הגדרת קבוע עבור סביבת פיתוח
if (!defined('WP_DEV')) {
    define('WP_DEV', get_option('wp_at_env') === 'PROD' ? false : true);
}

// הוספת קובץ התוכן לשורת Admin Bar
add_action('admin_bar_menu', 'at_show_template_file', 124);
add_action('admin_head', 'at_agency_admin_css');

/**
 * הצגת שם קובץ התבנית בשורת הכלים העליונה
 */
function at_show_template_file() {
    if (!is_admin() && current_user_can('manage_options') && is_admin_bar_showing()) {
        global $template, $wp_admin_bar;
        
        $str_trim = dirname(__FILE__) . '/';
        $template_text = trim($template, $str_trim);
        $template_text = str_replace($str_trim, " File Name: ", $template);
        $path = explode('/', $template_text);

        $suite_parent = $wp_admin_bar->get_node('at-suite-status') ? 'at-suite-status' : false;

        $wp_admin_bar->add_menu(array(
            'parent' => $suite_parent,
            'id' => 'template',
            'title' => 'Template: ' . end($path),
            'href' => '#',
            'meta' => array(
                'class' => 'at-suite-source at-suite-source-template',
                'title' => $template_text,
            )
        ));
    }
}

/**
 * הוספת סגנון CSS לביטול אייקונים
 */
function at_agency_admin_css() {
    ?>
    <style>
    /* עיצוב לוגים בתצוגות שגיאה */
    .xdebug-var-dump {
        background: #fef9fb !important;
        color: #000 !important;
        padding: 4px 8px !important;
        margin: 5px 10px !important;
        text-align: left !important;
        font-family: Menlo, Monaco, "Consolas", "Lucida Console", "courier new" !important;
        -moz-border-radius: 10px !important;
        -webkit-border-radius: 10px !important;
        -o-border-radius: 10px !important;
        border-radius: 10px !important;
        border: solid 3px #942343 !important;
        font-size: 10px;
        z-index: 999999 !important;
        display: block;
        position: inherit;
    }
    </style>
    <?php
}

/**
 * ביטול תמיכה באמוג'י
 */
add_action('init', 'at_disable_wp_emojicons');
function at_disable_wp_emojicons() {
    // הסרת כל הפעולות הקשורות לאמוג'י
    remove_action('admin_print_styles', 'print_emoji_styles');
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('admin_print_scripts', 'print_emoji_detection_script');
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_filter('wp_mail', 'wp_staticize_emoji_for_email');
    remove_filter('the_content_feed', 'wp_staticize_emoji');
    remove_filter('comment_text_rss', 'wp_staticize_emoji');
}

/**
 * רישום שגיאות דואר
 */
add_action('wp_mail_failed', 'at_log_mailer_errors', 10, 1);
function at_log_mailer_errors($wp_error) {
    $fn = ABSPATH . '/mail.log';
    $fp = fopen($fn, 'a');
    fputs($fp, "Mailer Error: " . $wp_error->get_error_message() . "\n");
    fclose($fp);
}

/**
 * הגדרת תוכן המייל כ-HTML
 */
add_filter("wp_mail_content_type", "at_mail_content_type");
function at_mail_content_type() {
    return "text/html";
}

/**
 * שינוי הגדרות סביבה לפי בקשת GET
 */
function at_environment_store() {
    if (isset($_GET['wp_at_env']) && current_user_can('manage_options')) {
        // בדיקת nonce לאבטחה
        if (!isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'at_environment_store')) {
            wp_die(__('Security check failed', 'at-agency-manager'));
        }

        $env = $_GET['wp_at_env'] == 'PROD' ? 'DEV' : 'PROD';
        update_option('wp_at_env', $env);

        if (isset($_GET['re'])) {
            // שימוש ב-wp_safe_redirect במקום wp_redirect למניעת open redirect vulnerability
            wp_safe_redirect(sanitize_text_field($_GET['re']));
            exit;
        }
    }
}
add_action('init', 'at_environment_store');

/**
 * קבלת מצב הפיתוח הנוכחי
 *
 * @return string
 */
function at_get_development_mode() {
    if (function_exists('wp_get_development_mode')) {
        return wp_get_development_mode();
    }

    if (defined('WP_DEVELOPMENT_MODE')) {
        $mode = WP_DEVELOPMENT_MODE;
        $valid_modes = array('core', 'plugin', 'theme', 'all', '');
        return in_array($mode, $valid_modes, true) ? $mode : '';
    }

    return '';
}

/**
 * בדיקה אם מצב פיתוח ספציפי מופעל
 *
 * @param string $mode מצב הפיתוח לבדיקה
 * @return bool
 */
function at_is_development_mode($mode = '') {
    if (function_exists('wp_is_development_mode')) {
        return wp_is_development_mode($mode);
    }

    $current_mode = at_get_development_mode();

    if (empty($mode)) {
        return !empty($current_mode);
    }

    if ($current_mode === 'all') {
        return true;
    }

    return $current_mode === $mode;
}

/**
 * בדיקה אם מדובר בסביבת פיתוח
 * משתמש בשיטה המאוחדת מ-AT_Agency_Manager_Environment
 *
 * @return bool
 */
function at_is_development_environment() {
    // Use the unified environment detection from AT_Agency_Manager_Environment
    if (class_exists('AT_Agency_Manager_Environment')) {
        return AT_Agency_Manager_Environment::is_development();
    }
    
    // Fallback for when the class is not available yet
    $env_type = wp_get_environment_type();
    if (in_array($env_type, array('local', 'development'))) {
        return true;
    }

    // Check plugin setting as secondary indicator
    $site_type = get_option('at_agency_manager_site_type', 'production');
    return $site_type === 'development';
}

/**
 * בדיקה אם יש להפעיל פיצ'ר ספציפי בסביבת פיתוח
 *
 * @param string $feature שם הפיצ'ר
 * @return bool
 */
function at_should_enable_development_feature($feature) {
    if (!at_is_development_environment()) {
        return false;
    }

    $development_features = get_option('at_agency_manager_development_features', array());
    return isset($development_features[$feature]) && $development_features[$feature];
}

/**
 * לוג עם הקשר פיתוח
 *
 * @param string $type סוג הלוג
 * @param string $message הודעת הלוג
 * @param string $status סטטוס הלוג
 * @param array $extra_context הקשר נוסף
 */
function at_log_with_development_context($type, $message, $status = 'info', $extra_context = array()) {
    $context = array_merge($extra_context, array(
        'development_mode' => at_get_development_mode(),
        'site_type' => get_option('at_agency_manager_site_type', 'production'),
        'wp_environment' => wp_get_environment_type(),
        'wp_debug' => defined('WP_DEBUG') ? WP_DEBUG : false,
        'user_id' => get_current_user_id(),
        'ip_address' => at_get_client_ip(),
        'request_uri' => isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '',
        'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : ''
    ));

    // הוספת הקשר לפיילטר
    add_filter('at_agency_manager_log_context', function($current_context) use ($context) {
        return array_merge($current_context, $context);
    });

    // לוג באמצעות המערכת הקיימת
    global $at_logger;
    if ($at_logger) {
        $at_logger->log($type, $message, $status);
    }
}

/**
 * קבלת כתובת ה-IP של המשתמש
 *
 * @return string
 */
function at_get_client_ip() {
    $ip_headers = array(
        'HTTP_CF_CONNECTING_IP',
        'HTTP_CLIENT_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_FORWARDED',
        'HTTP_X_CLUSTER_CLIENT_IP',
        'HTTP_FORWARDED_FOR',
        'HTTP_FORWARDED',
        'REMOTE_ADDR'
    );

    foreach ($ip_headers as $header) {
        if (!empty($_SERVER[$header])) {
            $ip = $_SERVER[$header];

            // טיפול בכתובות IP מרובות (מאחורי proxy)
            if (strpos($ip, ',') !== false) {
                $ip = trim(explode(',', $ip)[0]);
            }

            // ולידציה של כתובת IP
            if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                return $ip;
            }
        }
    }

    return '127.0.0.1';
}

/**
 * קבלת הגרסה הנוכחית של התוסף
 */
function at_agency_get_plugin_version() {
    static $version = null;
    
    if ($version === null) {
        if (!function_exists('get_plugin_data')) {
            require_once(ABSPATH . 'wp-admin/includes/plugin.php');
        }
        $plugin_data = get_plugin_data(AT_AGENCY_MANAGER_PATH . 'at-agency-sites-manager.php');
        $version = $plugin_data['Version'];
    }
    
    return $version;
}

// ---------------------------------------------------------------
//  מודולים שחייבים לרוץ גם בצד הקדמי (frontend / REST)
// ---------------------------------------------------------------
// at_agency_manager_load_modules() רץ אך ורק ב-admin. מודולים שמספקים
// התנהגות ציבורית (למשל ניתוב /s/<hash> של מקצר הכתובות) חייבים להיטען
// גם כשאין הקשר אדמין, אחרת ה-hooks שלהם לעולם לא נרשמים והבקשה נופלת ל-404.
add_action('plugins_loaded', 'at_agency_manager_load_public_modules', 5);
function at_agency_manager_load_public_modules() {
    if (is_admin()) {
        // בצד האדמין (כולל admin-ajax) הטעינה נעשית ב-at_agency_manager_load_modules
        return;
    }

    static $loaded = false;
    if ($loaded) {
        return;
    }
    $loaded = true;

    $modules = get_option('at_agency_manager_modules', []);

    // Module: URL Shortener — נדרש בצד הקדמי כדי לנתב את הקישורים המקוצרים
    if (!empty($modules['url_shortener'])) {
        $file_path = AT_AGENCY_MANAGER_PATH . 'modules/url-shortener/class-url-shortener.php';
        if (file_exists($file_path)) {
            require_once $file_path;
            if (class_exists('AT_Url_Shortener')) {
                AT_Url_Shortener::get_instance();
            }
        }
    }
}

// ---------------------------------------------------------------
//  טעינת מודולים על-פי הגדרות התוסף (unified loading system)
// ---------------------------------------------------------------
// טעינה ב-admin_menu עם priority נמוך מאוד כדי שה-hooks ירשמו בזמן
add_action('admin_menu', 'at_agency_manager_load_modules', 1);
add_action('admin_init', 'at_agency_manager_load_modules', 1);
function at_agency_manager_load_modules() {
    // Only load modules if in admin and WordPress is fully initialized
    if (!is_admin()) {
        return;
    }
    
    // מניעת טעינה כפולה
    static $loaded = false;
    if ($loaded) {
        return;
    }
    $loaded = true;
    
    // Ensure current user is set before loading modules
    if (!function_exists('wp_get_current_user')) {
        return;
    }
    
    $modules = get_option('at_agency_manager_modules', []);
    $logger = null;
    
    // Try to get logger instance for error reporting
    if (class_exists('AT_Agency_Manager_Logger')) {
        $logger = new AT_Agency_Manager_Logger();
    }
    
    // Helper function for safe file loading
    $safe_require = function($file_path, $module_name) use ($logger) {
        if (file_exists($file_path)) {
            require_once $file_path;
            return true;
        } else {
            if ($logger) {
                $logger->log('module_error', "Module file not found: {$file_path}", 'error');
            }
            
            // Disable the module in settings to prevent future errors
            $modules = get_option('at_agency_manager_modules', []);
            if (isset($modules[$module_name])) {
                $modules[$module_name] = 0;
                update_option('at_agency_manager_modules', $modules);
            }
            
            return false;
        }
    };

    // Module: ACF Copy Tool
    if (!empty($modules['acf_copy_tool'])) {
        $safe_require(AT_AGENCY_MANAGER_PATH . 'modules/acf-copy-tool.php', 'acf_copy_tool');
    }

    // Module: Site Health Panel
    if (!empty($modules['site_health'])) {
        $safe_require(AT_AGENCY_MANAGER_PATH . 'modules/site-health.php', 'site_health');
    }

    // Module: Custom Login URL
    if (!empty($modules['hide_login'])) {
        $safe_require(AT_AGENCY_MANAGER_PATH . 'modules/hide-login.php', 'hide_login');
    }

    // Module: Site Backup
    if (!empty($modules['backup'])) {
        // Load admin page first
        $safe_require(AT_AGENCY_MANAGER_PATH . 'modules/backup/admin-page.php', 'backup_admin_page');
        // Then load backup module
        if ($safe_require(AT_AGENCY_MANAGER_PATH . 'modules/backup/backup.php', 'backup')) {
            if (class_exists('AT_Backup_Module')) {
                AT_Backup_Module::get_instance();
            }
        }
    }

    // Module: Activity Log
    if (!empty($modules['activity_log'])) {
        $safe_require(AT_AGENCY_MANAGER_PATH . 'modules/activity-log.php', 'activity_log');
    }

    // Module: Email Log
    if (!empty($modules['email_log'])) {
        $safe_require(AT_AGENCY_MANAGER_PATH . 'modules/email-log.php', 'email_log');
    }

    // Module: Page Ordering
    if (!empty($modules['page_ordering'])) {
        if ($safe_require(AT_AGENCY_MANAGER_PATH . 'modules/page-ordering.php', 'page_ordering')) {
            // Load Page Ordering settings page
            $safe_require(AT_AGENCY_MANAGER_PATH . 'modules/page-ordering-settings.php', 'page_ordering_settings');
        }
    }

    // Module: S3 Media Sync
    if (!empty($modules['s3_media_sync'])) {
        $safe_require(AT_AGENCY_MANAGER_PATH . 'modules/s3-media-sync.php', 's3_media_sync');
    }

    // Module: New Relic Monitoring
    if (!empty($modules['newrelic_monitoring'])) {
        if ($safe_require(AT_AGENCY_MANAGER_PATH . 'modules/newrelic-monitoring.php', 'newrelic_monitoring')) {
            if (function_exists('init_at_agency_newrelic_monitoring')) {
                init_at_agency_newrelic_monitoring($logger);
            }
        }
        // Load New Relic settings page
        $safe_require(AT_AGENCY_MANAGER_PATH . 'modules/newrelic-settings.php', 'newrelic_settings');
    }

    // Module: ACF Enhanced Elementor Tag (requires Elementor)
    if (!empty($modules['acf_elementor_tag'])) {
        if (did_action('elementor/loaded') && function_exists('get_field')) {
            if ($safe_require(AT_AGENCY_MANAGER_PATH . 'modules/elementor-custom-tags/acf-enhanced-tag.php', 'acf_elementor_tag')) {
                add_action('elementor/dynamic_tags/register', function ($dynamic_tags_manager) {
                    if (class_exists('\Elementor\Plugin')) {
                        \Elementor\Plugin::$instance->dynamic_tags->register_group(
                            'acf-custom',
                            ['title' => 'ACF משופר']
                        );
                        if (class_exists('ACF_Enhanced_Dynamic_Tag')) {
                            $dynamic_tags_manager->register(new \ACF_Enhanced_Dynamic_Tag());
                        }
                    }
                });
            }
        } else {
            if ($logger) {
                $logger->log('module_error', "Elementor is not installed or activated. ACF Enhanced Elementor Tag module requires Elementor.", 'error');
            }
            
            // Disable the module
            $modules['acf_elementor_tag'] = 0;
            update_option('at_agency_manager_modules', $modules);
            
            add_action('admin_notices', function() {
                echo '<div class="notice notice-warning is-dismissible">';
                echo '<p>' . __('The ACF Enhanced Elementor Tag module requires Elementor to be installed and activated. The module has been disabled.', 'at-agency-manager') . '</p>';
                echo '</div>';
            });
        }
    }

    // Module: ACF Local JSON Manager (loaded at acf/init to prevent early translation loading)
    if (!empty($modules['acf_local_json'])) {
        add_action('acf/init', function() {
            $file_path = AT_AGENCY_MANAGER_PATH . 'modules/acf-local-json.php';
            if (file_exists($file_path)) {
                require_once $file_path;
                // Initialize the class after file is loaded and translations are ready
                if (class_exists('AT_ACF_Local_JSON_Manager')) {
                    new AT_ACF_Local_JSON_Manager();
                }
            }
        }, 11); // priority 11 to run after ACF translations are loaded (acf/init default is 10)
    }

    // Module: Abilities API Admin (always loaded - core functionality)
    $abilities_api_admin_path = AT_AGENCY_MANAGER_PATH . 'modules/abilities-api-demo.php';
    if (file_exists($abilities_api_admin_path)) {
        require_once $abilities_api_admin_path;
        // Initialize the module if class exists and logger is available
        if (class_exists('AT_Agency_Manager_Abilities_API_Admin') && $logger) {
            new AT_Agency_Manager_Abilities_API_Admin($logger);
        }
    }

    // Module: URL Shortener
    if (!empty($modules['url_shortener'])) {
        if ($safe_require(AT_AGENCY_MANAGER_PATH . 'modules/url-shortener/class-url-shortener.php', 'url_shortener')) {
            if (class_exists('AT_Url_Shortener')) {
                // טעינה ישירה כדי שה-hooks ירשמו בזמן
                AT_Url_Shortener::get_instance();
            }
        }
    }
}

/**
 * Access the always-on suite core instance.
 *
 * @return AT_Agency_Manager_Suite_Core|null
 */
function at_suite_core() {
    if (class_exists('AT_Agency_Manager_Suite_Core')) {
        return AT_Agency_Manager_Suite_Core::get_instance();
    }

    return null;
}

/**
 * Check whether suite core is active.
 *
 * @return bool
 */
function at_is_suite_core_active() {
    return defined('AT_AGENCY_SUITE_CORE_ACTIVE') && AT_AGENCY_SUITE_CORE_ACTIVE;
}

/**
 * Register a service in the suite service registry.
 *
 * @param string $key
 * @param mixed  $service
 * @param array  $meta
 * @return void
 */
function at_suite_register_service($key, $service, $meta = array()) {
    $core = at_suite_core();
    if ($core) {
        $core->register_service($key, $service, $meta);
    }
}

/**
 * Resolve a service from the suite service registry.
 *
 * @param string $key
 * @param mixed  $default
 * @return mixed
 */
function at_suite_get_service($key, $default = null) {
    $core = at_suite_core();
    if ($core) {
        return $core->get_service($key, $default);
    }

    return $default;
}

/**
 * Emit suite event for cross-plugin communication.
 *
 * @param string $event
 * @param array  $payload
 * @return void
 */
function at_suite_emit_event($event, $payload = array()) {
    $core = at_suite_core();
    if ($core) {
        $core->emit_event($event, $payload);
    }
}

/**
 * Register an admin submenu item through the suite registry.
 *
 * @param string $slug
 * @param array  $args
 * @param array  $meta
 * @return bool
 */
function at_suite_register_admin_menu_item($slug, $args = array(), $meta = array()) {
    $core = at_suite_core();
    if (!$core) {
        return false;
    }

    return $core->register_admin_menu_item($slug, $args, $meta);
}

/**
 * Return registered suite admin menu items.
 *
 * @return array
 */
function at_suite_get_admin_menu_items() {
    $core = at_suite_core();
    if (!$core) {
        return array();
    }

    return $core->get_admin_menu_items();
}

/**
 * Render the unified admin footer.
 *
 * @return void
 */
function at_suite_render_admin_footer() {
    $core = at_suite_core();
    if ($core) {
        $core->render_admin_footer();
    }
}

/**
 * Return a menu/admin label by active admin locale (Hebrew/English).
 *
 * @param string $en
 * @param string $he
 * @return string
 */
function at_agency_manager_admin_label($en, $he) {
    $locale = function_exists('determine_locale') ? determine_locale() : get_locale();
    $locale = is_string($locale) ? strtolower($locale) : '';

    if (0 === strpos($locale, 'he')) {
        return $he;
    }

    return $en;
}
