<?php
/**
 * מנהל וובהוקים - מערכת התראות חיצונית
 */

// Fallback functions for when WordPress is not loaded
if (!function_exists('get_option')) {
    function get_option($key, $default = '') {
        return $default;
    }
}

if (!function_exists('update_option')) {
    function update_option($key, $value) {
        return true;
    }
}

if (!function_exists('current_time')) {
    function current_time($type = 'timestamp') {
        return time();
    }
}

if (!function_exists('wp_get_current_user')) {
    function wp_get_current_user() {
        return (object) array('ID' => 0, 'user_login' => 'system');
    }
}

if (!function_exists('get_userdata')) {
    function get_userdata($user_id) {
        return (object) array(
            'ID' => $user_id,
            'user_login' => 'user_' . $user_id,
            'user_email' => 'user' . $user_id . '@localhost.local',
            'roles' => array('subscriber')
        );
    }
}

if (!function_exists('is_user_logged_in')) {
    function is_user_logged_in() {
        return false;
    }
}

if (!function_exists('wp_get_environment_type')) {
    function wp_get_environment_type() {
        return 'production';
    }
}

if (!function_exists('wp_remote_request')) {
    function wp_remote_request($url, $args = array()) {
        return array('response' => array('code' => 200));
    }
}

if (!function_exists('is_wp_error')) {
    function is_wp_error($thing) {
        return false;
    }
}

if (!function_exists('wp_remote_retrieve_response_code')) {
    function wp_remote_retrieve_response_code($response) {
        return 200;
    }
}

if (!function_exists('get_current_user_id')) {
    function get_current_user_id() {
        return 0;
    }
}

if (!function_exists('get_post')) {
    function get_post($post_id) {
        return (object) array(
            'ID' => $post_id,
            'post_title' => 'Post ' . $post_id,
            'post_type' => 'post',
            'post_author' => 1
        );
    }
}

if (!function_exists('get_comment')) {
    function get_comment($comment_id) {
        return (object) array(
            'comment_ID' => $comment_id,
            'comment_post_ID' => 1,
            'comment_approved' => 1
        );
    }
}

if (!function_exists('get_the_title')) {
    function get_the_title($post_id) {
        return 'Post Title ' . $post_id;
    }
}

if (!function_exists('add_action')) {
    function add_action($hook, $callback, $priority = 10, $args = 1) {
        // Do nothing in standalone mode
        return true;
    }
}

if (!function_exists('do_action')) {
    function do_action($hook, ...$args) {
        // Do nothing in standalone mode
        return true;
    }
}

if (!function_exists('sanitize_key')) {
    function sanitize_key($key) {
        return preg_replace('/[^a-z0-9_\-]/', '', strtolower($key));
    }
}

if (!function_exists('sanitize_text_field')) {
    function sanitize_text_field($text) {
        return trim($text);
    }
}

if (!function_exists('esc_url_raw')) {
    function esc_url_raw($url) {
        return $url;
    }
}

if (!function_exists('filter_var')) {
    function filter_var($value, $filter) {
        if ($filter === FILTER_VALIDATE_URL) {
            return preg_match('/^https?:\/\/.+/i', $value);
        }
        return false;
    }
}

if (!function_exists('wp_json_encode')) {
    function wp_json_encode($data) {
        return json_encode($data);
    }
}

if (!function_exists('maybe_serialize')) {
    function maybe_serialize($data) {
        return serialize($data);
    }
}

class AT_Agency_Manager_Webhook_Manager {
    /**
     * @var array רשימת הוובהוקים הרשומים
     */
    private $webhooks = array();

    /**
     * @var AT_Agency_Manager_Logger מופע הלוגר
     */
    private $logger;

    /**
     * אתחול המנהל
     */
    public function __construct($logger = null) {
        $this->logger = $logger;
        $this->load_webhooks();
        $this->register_hooks();
    }

    /**
     * טעינת וובהוקים מהגדרות
     */
    private function load_webhooks() {
        $this->webhooks = get_option('at_agency_manager_webhooks', array());
    }

    /**
     * שמירת וובהוקים להגדרות
     */
    private function save_webhooks() {
        update_option('at_agency_manager_webhooks', $this->webhooks);
    }

    /**
     * רישום הווקים לאירועים שונים
     */
    private function register_hooks() {
        // אירועי יוזרים
        add_action('user_register', array($this, 'on_user_register'));
        add_action('wp_login', array($this, 'on_user_login'), 10, 2);
        add_action('wp_logout', array($this, 'on_user_logout'));
        add_action('profile_update', array($this, 'on_user_profile_update'), 10, 2);
        add_action('delete_user', array($this, 'on_user_delete'));

        // אירועי פוסטים ועמודים
        add_action('publish_post', array($this, 'on_post_publish'), 10, 2);
        add_action('publish_page', array($this, 'on_page_publish'), 10, 2);
        add_action('delete_post', array($this, 'on_post_delete'));

        // אירועי תגובות
        add_action('comment_post', array($this, 'on_comment_post'), 10, 3);
        add_action('wp_set_comment_status', array($this, 'on_comment_status_change'), 10, 2);

        // אירועי תוספים
        add_action('activated_plugin', array($this, 'on_plugin_activate'));
        add_action('deactivated_plugin', array($this, 'on_plugin_deactivate'));

        // אירועי עדכונים
        add_action('upgrader_process_complete', array($this, 'on_core_update'), 10, 2);
        add_action('_core_updated_successfully', array($this, 'on_core_update_success'));

        // אירועי אבטחה
        add_action('wp_login_failed', array($this, 'on_login_failed'));
    }

    /**
     * הוספת וובהוק חדש
     */
    public function add_webhook($name, $url, $events = array(), $settings = array()) {
        if (empty($name) || empty($url) || !filter_var($url, FILTER_VALIDATE_URL)) {
            return false;
        }

        $webhook_id = sanitize_key($name);
        $this->webhooks[$webhook_id] = array(
            'name' => sanitize_text_field($name),
            'url' => esc_url_raw($url),
            'events' => array_map('sanitize_text_field', $events),
            'settings' => array(
                'enabled' => true,
                'method' => isset($settings['method']) ? $settings['method'] : 'POST',
                'headers' => isset($settings['headers']) ? $settings['headers'] : array(),
                'timeout' => isset($settings['timeout']) ? intval($settings['timeout']) : 30,
                'retries' => isset($settings['retries']) ? intval($settings['retries']) : 3,
                'user_roles' => isset($settings['user_roles']) ? $settings['user_roles'] : array(),
                'specific_users' => isset($settings['specific_users']) ? $settings['specific_users'] : array(),
                'content_type' => isset($settings['content_type']) ? $settings['content_type'] : 'json'
            ),
            'created_at' => current_time('mysql'),
            'last_triggered' => null,
            'success_count' => 0,
            'error_count' => 0
        );

        $this->save_webhooks();
        return true;
    }

    /**
     * קבלת רשימת וובהוקים
     */
    public function get_webhooks() {
        return $this->webhooks;
    }

    /**
     * בדיקה אם וובהוק פעיל לאירוע מסוים
     */
    public function is_webhook_active_for_event($webhook_id, $event) {
        $webhook = isset($this->webhooks[$webhook_id]) ? $this->webhooks[$webhook_id] : null;
        if (!$webhook || !$webhook['settings']['enabled']) {
            return false;
        }

        return in_array($event, $webhook['events']);
    }

    /**
     * שליחת וובהוק
     */
    public function send_webhook($webhook_id, $event, $data = array()) {
        $webhook = isset($this->webhooks[$webhook_id]) ? $this->webhooks[$webhook_id] : null;
        if (!$webhook || !$this->is_webhook_active_for_event($webhook_id, $event)) {
            return false;
        }

        // הכנת הנתונים לשליחה
        $payload = array(
            'event' => $event,
            'timestamp' => current_time('timestamp'),
            'site_url' => get_site_url(),
            'site_name' => get_bloginfo('name'),
            'data' => $data
        );

        // הוספת מידע על המשתמש הנוכחי אם קיים
        if (is_user_logged_in()) {
            $current_user = wp_get_current_user();
            $payload['user'] = array(
                'id' => $current_user->ID,
                'login' => $current_user->user_login,
                'email' => $current_user->user_email,
                'display_name' => $current_user->display_name,
                'roles' => $current_user->roles
            );
        }

        // בדיקת הרשאות משתמש
        if (!$this->check_user_permissions($webhook, $payload)) {
            return false;
        }

        // שליחת הוובהוק
        return $this->send_http_request($webhook, $payload);
    }

    /**
     * בדיקת הרשאות משתמש
     */
    private function check_user_permissions($webhook, $payload) {
        $settings = $webhook['settings'];

        // אם לא הוגדרו הגבלות - מורשה
        if (empty($settings['user_roles']) && empty($settings['specific_users'])) {
            return true;
        }

        // אם אין מידע על המשתמש - לא מורשה
        if (!isset($payload['user'])) {
            return false;
        }

        $user = $payload['user'];

        // בדיקת משתמשים ספציפיים
        if (!empty($settings['specific_users']) && in_array($user['id'], $settings['specific_users'])) {
            return true;
        }

        // בדיקת תפקידי משתמש
        if (!empty($settings['user_roles'])) {
            foreach ($settings['user_roles'] as $role) {
                if (in_array($role, $user['roles'])) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * שליחת בקשת HTTP לוובהוק
     */
    private function send_http_request($webhook, $payload) {
        $url = $webhook['url'];
        $method = $webhook['settings']['method'];
        $headers = $webhook['settings']['headers'];
        $timeout = $webhook['settings']['timeout'];
        $content_type = $webhook['settings']['content_type'];

        // הוספת Content-Type
        if ($content_type === 'json') {
            $headers['Content-Type'] = 'application/json';
            $body = wp_json_encode($payload);
        } else {
            $body = http_build_query($payload);
        }

        $args = array(
            'method' => $method,
            'headers' => $headers,
            'body' => $body,
            'timeout' => $timeout,
            'redirection' => 5,
            'httpversion' => '1.1',
            'blocking' => false, // אסינכרוני
            'sslverify' => true
        );

        // שליחת הבקשה
        $response = wp_remote_request($url, $args);

        // טיפול בתגובה
        $this->handle_response($webhook, $response, $payload);

        return !is_wp_error($response);
    }

    /**
     * טיפול בתגובת הוובהוק
     */
    private function handle_response($webhook, $response, $payload) {
        $webhook_id = array_search($webhook, $this->webhooks);

        if (is_wp_error($response)) {
            $this->webhooks[$webhook_id]['error_count']++;
            $this->log_webhook_error($webhook_id, $response->get_error_message(), $payload);
        } else {
            $response_code = wp_remote_retrieve_response_code($response);
            if ($response_code >= 200 && $response_code < 300) {
                $this->webhooks[$webhook_id]['success_count']++;
                $this->webhooks[$webhook_id]['last_triggered'] = current_time('mysql');
            } else {
                $this->webhooks[$webhook_id]['error_count']++;
                $this->log_webhook_error($webhook_id, 'HTTP ' . $response_code, $payload);
            }
        }

        $this->save_webhooks();
    }

    /**
     * רישום שגיאת וובהוק
     */
    private function log_webhook_error($webhook_id, $error, $payload) {
        if ($this->logger) {
            $this->logger->log('webhook_error', sprintf(
                'Webhook %s failed: %s (Event: %s)',
                $webhook_id,
                $error,
                $payload['event']
            ), 'error');
        }
    }

    // ==================== אירועי יוזרים ====================

    /**
     * אירוע יצירת יוזר חדש
     */
    public function on_user_register($user_id) {
        $user = get_userdata($user_id);
        if ($user) {
            $this->trigger_event('user_register', array(
                'user_id' => $user_id,
                'user_login' => $user->user_login,
                'user_email' => $user->user_email,
                'user_roles' => $user->roles,
                'registered_at' => $user->user_registered
            ));
        }
    }

    /**
     * אירוע התחברות יוזר
     */
    public function on_user_login($user_login, $user) {
        if ($user) {
            $this->trigger_event('user_login', array(
                'user_id' => $user->ID,
                'user_login' => $user_login,
                'user_email' => $user->user_email,
                'user_roles' => $user->roles,
                'login_time' => current_time('mysql'),
                'ip_address' => $this->get_client_ip()
            ));
        }
    }

    /**
     * אירוע התנתקות יוזר
     */
    public function on_user_logout() {
        $user = wp_get_current_user();
        if ($user->ID) {
            $this->trigger_event('user_logout', array(
                'user_id' => $user->ID,
                'user_login' => $user->user_login,
                'logout_time' => current_time('mysql')
            ));
        }
    }

    /**
     * אירוע עדכון פרופיל יוזר
     */
    public function on_user_profile_update($user_id, $old_user_data) {
        $user = get_userdata($user_id);
        if ($user) {
            // Convert objects to arrays, handling nested objects
            $new_data = (array)$user->data;
            $old_data = (array)$old_user_data;
            
            // Only compare scalar values
            $new_scalar = array_filter($new_data, function($v) {
                return is_scalar($v) || $v === null;
            });
            $old_scalar = array_filter($old_data, function($v) {
                return is_scalar($v) || $v === null;
            });
            
            $this->trigger_event('user_profile_update', array(
                'user_id' => $user_id,
                'user_login' => $user->user_login,
                'changes' => array_diff($new_scalar, $old_scalar)
            ));
        }
    }

    /**
     * אירוע מחיקת יוזר
     */
    public function on_user_delete($user_id) {
        $this->trigger_event('user_delete', array(
            'user_id' => $user_id,
            'deleted_by' => get_current_user_id(),
            'deleted_at' => current_time('mysql')
        ));
    }

    // ==================== אירועי תוכן ====================

    /**
     * אירוע פרסום פוסט
     */
    public function on_post_publish($post_id, $post) {
        if ($post) {
            $this->trigger_event('post_publish', array(
                'post_id' => $post_id,
                'post_title' => $post->post_title,
                'post_type' => $post->post_type,
                'post_author' => $post->post_author,
                'post_status' => $post->post_status,
                'published_at' => $post->post_date
            ));
        }
    }

    /**
     * אירוע פרסום עמוד
     */
    public function on_page_publish($page_id, $page) {
        if ($page) {
            $this->trigger_event('page_publish', array(
                'page_id' => $page_id,
                'page_title' => $page->post_title,
                'page_author' => $page->post_author,
                'published_at' => $page->post_date
            ));
        }
    }

    /**
     * אירוע מחיקת פוסט/עמוד
     */
    public function on_post_delete($post_id) {
        $post = get_post($post_id);
        if ($post) {
            $this->trigger_event('post_delete', array(
                'post_id' => $post_id,
                'post_title' => $post->post_title,
                'post_type' => $post->post_type,
                'deleted_by' => get_current_user_id(),
                'deleted_at' => current_time('mysql')
            ));
        }
    }

    // ==================== אירועי תגובות ====================

    /**
     * אירוע פרסום תגובה חדשה
     */
    public function on_comment_post($comment_id, $comment_approved, $commentdata) {
        if ($comment_approved === 1) {
            $this->trigger_event('comment_post', array(
                'comment_id' => $comment_id,
                'post_id' => $commentdata['comment_post_ID'],
                'author' => $commentdata['comment_author'],
                'author_email' => $commentdata['comment_author_email'],
                'content' => $commentdata['comment_content'],
                'posted_at' => current_time('mysql')
            ));
        }
    }

    /**
     * אירוע שינוי סטטוס תגובה
     */
    public function on_comment_status_change($comment_id, $comment_status) {
        $comment = get_comment($comment_id);
        if ($comment) {
            $this->trigger_event('comment_status_change', array(
                'comment_id' => $comment_id,
                'post_id' => $comment->comment_post_ID,
                'old_status' => $comment->comment_approved,
                'new_status' => $comment_status,
                'changed_by' => get_current_user_id(),
                'changed_at' => current_time('mysql')
            ));
        }
    }

    // ==================== אירועי תוספים ====================

    /**
     * אירוע הפעלת תוסף
     */
    public function on_plugin_activate($plugin) {
        $this->trigger_event('plugin_activate', array(
            'plugin' => $plugin,
            'activated_by' => get_current_user_id(),
            'activated_at' => current_time('mysql')
        ));
    }

    /**
     * אירוע ביטול תוסף
     */
    public function on_plugin_deactivate($plugin) {
        $this->trigger_event('plugin_deactivate', array(
            'plugin' => $plugin,
            'deactivated_by' => get_current_user_id(),
            'deactivated_at' => current_time('mysql')
        ));
    }

    // ==================== אירועי עדכונים ====================

    /**
     * אירוע עדכון ליבה
     */
    public function on_core_update($upgrader_object, $options) {
        if ($options['action'] === 'update' && $options['type'] === 'core') {
            $this->trigger_event('core_update', array(
                'update_type' => 'core',
                'successful' => true,
                'updated_by' => get_current_user_id(),
                'updated_at' => current_time('mysql')
            ));
        }
    }

    /**
     * אירוע עדכון ליבה מוצלח
     */
    public function on_core_update_success($wp_version) {
        $this->trigger_event('core_update_success', array(
            'new_version' => $wp_version,
            'updated_at' => current_time('mysql')
        ));
    }

    // ==================== אירועי אבטחה ====================

    /**
     * אירוע התחברות נכשלה
     */
    public function on_login_failed($username) {
        $this->trigger_event('login_failed', array(
            'username' => $username,
            'ip_address' => $this->get_client_ip(),
            'failed_at' => current_time('mysql'),
            'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : ''
        ));
    }

    // ==================== שיטות עזר ====================

    /**
     * הפעלת אירוע בוובהוקים
     */
    private function trigger_event($event, $data) {
        foreach ($this->webhooks as $webhook_id => $webhook) {
            if ($this->is_webhook_active_for_event($webhook_id, $event)) {
                $this->send_webhook($webhook_id, $event, $data);
            }
        }
    }

    /**
     * קבלת כתובת IP של הלקוח
     */
    private function get_client_ip() {
        $ip_headers = array(
            'HTTP_CF_CONNECTING_IP',
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_X_CLUSTER_CLIENT_IP',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED',
            'REMOTE_ADDR'
        );

        foreach ($ip_headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip = $_SERVER[$header];
                if (strpos($ip, ',') !== false) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }

        return '127.0.0.1';
    }
}
