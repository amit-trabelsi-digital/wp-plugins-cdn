<?php
/**
 * מחלקת הליבה של התוסף
 * 
 * אחראית על אתחול התוסף, הפעלה, ביטול הפעלה והסרה
 */
class AT_Agency_Manager_Core {
    /**
     * אתחול התוסף
     */
    public static function activate() {
        // יצירת טבלאות נדרשות
        self::create_tables();
        
        // הגדרת ברירות מחדל
        self::set_default_options();
        
        // Flush rewrite rules עבור קישורים מקוצרים
        $url_shortener_file = AT_AGENCY_MANAGER_PATH . 'modules/url-shortener/class-url-shortener.php';
        if (file_exists($url_shortener_file)) {
            require_once $url_shortener_file;
            if (class_exists('AT_Url_Shortener')) {
                AT_Url_Shortener::flush_rewrite_rules_on_activation();
            }
        }
        
        // ניקוי מטמון
        wp_cache_flush();
        
        // רישום אירוע הפעלה
        flush_rewrite_rules();
    }
    
    /**
     * ביטול הפעלת התוסף
     */
    public static function deactivate() {
        // ניקוי מטמון
        wp_cache_flush();
        
        // רישום אירוע ביטול הפעלה
        flush_rewrite_rules();
    }
    
    /**
     * הסרת התוסף
     */
    public static function uninstall() {
        // מחיקת טבלאות
        self::drop_tables();
        
        // מחיקת הגדרות
        self::delete_options();
        
        // ניקוי מטמון
        wp_cache_flush();
    }
    
    /**
     * יצירת טבלאות נדרשות
     */
    private static function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // טבלת לוגים - עם כל העמודות הנדרשות
        $table_name = $wpdb->prefix . 'at_agency_manager_logs';
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            type varchar(50) NOT NULL,
            message text NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'info',
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            user_id bigint(20) unsigned DEFAULT NULL,
            ip_address varchar(45) DEFAULT NULL,
            context longtext DEFAULT NULL,
            file_path varchar(255) DEFAULT NULL,
            line_number int(11) DEFAULT NULL,
            development_mode varchar(20) DEFAULT NULL,
            site_type varchar(20) DEFAULT NULL,
            PRIMARY KEY  (id),
            KEY idx_type_status (type, status),
            KEY idx_created_at (created_at),
            KEY idx_user_id (user_id),
            KEY idx_development_mode (development_mode)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        // טבלת קישורים מקוצרים
        $short_links_table = $wpdb->prefix . 'at_short_links';
        $short_links_sql = "CREATE TABLE IF NOT EXISTS $short_links_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            post_id bigint(20) unsigned DEFAULT NULL,
            hash varchar(20) NOT NULL,
            original_url text NOT NULL,
            short_url varchar(255) NOT NULL,
            clicks int(11) NOT NULL DEFAULT 0,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            created_by bigint(20) unsigned DEFAULT NULL,
            is_manual tinyint(1) NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            UNIQUE KEY hash (hash),
            KEY idx_post_id (post_id),
            KEY idx_created_at (created_at),
            KEY idx_created_by (created_by)
        ) $charset_collate;";
        
        dbDelta($short_links_sql);
    }
    
    /**
     * מחיקת טבלאות
     */
    private static function drop_tables() {
        global $wpdb;
        
        // טבלת לוגים
        $table_name = $wpdb->prefix . 'at_agency_manager_logs';
        $wpdb->query("DROP TABLE IF EXISTS $table_name");
        
        // טבלת קישורים מקוצרים
        $short_links_table = $wpdb->prefix . 'at_short_links';
        $wpdb->query("DROP TABLE IF EXISTS $short_links_table");
    }
    
    /**
     * הגדרת ברירות מחדל
     */
    private static function set_default_options() {
        // הגדרות מודולים
        $modules = [
            'activity_log' => 1,
            'site_health' => 1,
            'hide_login' => 0,
            'acf_copy_tool' => 0,
            'acf_elementor_tag' => 0,
            'email_log' => 0,
            'backup' => 0,
            'url_shortener' => 0,
            'gf_autofill' => 1
        ];
        
        update_option('at_agency_manager_modules', $modules);
        
        // הגדרות אבטחה
        $security = [
            'debug_mode' => 0,
            'log_level' => 'error',
            'log_retention' => 30
        ];
        
        update_option('at_security_settings', $security);
    }
    
    /**
     * מחיקת הגדרות
     */
    private static function delete_options() {
        delete_option('at_agency_manager_modules');
        delete_option('at_security_settings');
        delete_option('at_agency_manager_auth_key');
        delete_option('at_short_links_domain');
        delete_option('at_short_links_domain_status');
        delete_option('at_short_links_qr_logo');
    }
} 