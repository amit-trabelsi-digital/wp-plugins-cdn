<?php
/**
 * מנהל פיתוח האתר - תמיכה מלאה ב-WP_DEVELOPMENT_MODE
 */
class AT_Agency_Manager_Development_Manager {
    /**
     * @var string מצב הפיתוח הנוכחי
     */
    private $development_mode;

    /**
     * @var bool האם מדובר בסביבת פיתוח
     */
    private $is_development;

    /**
     * אתחול המנהל
     */
    public function __construct() {
        $this->development_mode = $this->get_current_development_mode();
        $this->is_development = $this->is_development_environment();

        // הגדרת הוקים
        add_action('init', array($this, 'init_development_hooks'));
        add_action('admin_init', array($this, 'init_admin_hooks'));
        add_filter('at_agency_manager_environment_info', array($this, 'add_environment_info'));
    }

    /**
     * קבלת מצב הפיתוח הנוכחי
     *
     * @return string
     */
    public function get_current_development_mode() {
        // שימוש בפונקציית WordPress החדשה אם קיימת
        if (function_exists('wp_get_development_mode')) {
            return wp_get_development_mode();
        }

        // חזרה לפתרון ידני אם הפונקציה לא קיימת
        if (defined('WP_DEVELOPMENT_MODE')) {
            $mode = WP_DEVELOPMENT_MODE;
            $valid_modes = array('core', 'plugin', 'theme', 'all', '');
            return in_array($mode, $valid_modes, true) ? $mode : '';
        }

        return '';
    }

    /**
     * בדיקה אם מצב פיתוח ספציפי מופעל
     *
     * @param string $mode מצב הפיתוח לבדיקה
     * @return bool
     */
    public function is_development_mode($mode = '') {
        // שימוש בפונקציית WordPress החדשה אם קיימת
        if (function_exists('wp_is_development_mode')) {
            return wp_is_development_mode($mode);
        }

        // חזרה לפתרון ידני
        $current_mode = $this->get_current_development_mode();

        if (empty($mode)) {
            return !empty($current_mode);
        }

        if ($current_mode === 'all') {
            return true;
        }

        return $current_mode === $mode;
    }

    /**
     * בדיקה אם מדובר בסביבת פיתוח
     * משתמש בשיטה המאוחדת מ-AT_Agency_Manager_Environment
     *
     * @return bool
     */
    public function is_development_environment() {
        // Use the unified environment detection from AT_Agency_Manager_Environment
        if (class_exists('AT_Agency_Manager_Environment')) {
            return AT_Agency_Manager_Environment::is_development();
        }
        
        // Fallback for when the class is not available yet
        $env_type = wp_get_environment_type();
        if (in_array($env_type, array('local', 'development'))) {
            return true;
        }

        // Check plugin setting as secondary indicator
        $site_type = get_option('at_agency_manager_site_type', 'production');
        return $site_type === 'development';
    }

    /**
     * בדיקה אם יש להציג התראות דיבוג
     *
     * @return bool
     */
    public function should_show_debug_notices() {
        // לא להציג בסביבת פרודקשן
        if (!$this->is_development_environment()) {
            return false;
        }

        // בדיקת הגדרת התוסף
        return get_option('at_agency_manager_show_debug_notices', true);
    }

    /**
     * בדיקה אם יש להפעיל לוגים מתקדמים
     *
     * @return bool
     */
    public function should_enable_advanced_logging() {
        return $this->is_development_environment() && $this->is_development_mode();
    }

    /**
     * בדיקה אם יש להפעיל API מרחוק
     *
     * @return bool
     */
    public function should_enable_remote_api() {
        return $this->is_development_environment() && get_option('at_agency_manager_enable_remote_api', false);
    }

    /**
     * בדיקה אם יש להפעיל בדיקות אבטחה מתקדמות
     *
     * @return bool
     */
    public function should_enable_security_checks() {
        return $this->is_development_environment() || $this->is_development_mode();
    }

    /**
     * בדיקה אם יש להציג מידע דיבוג בדיבאר המנהל
     *
     * @return bool
     */
    public function should_show_debug_info() {
        return $this->is_development_environment() && get_option('at_agency_manager_show_debug_info', true);
    }

    /**
     * אתחול הוקים לפיתוח
     */
    public function init_development_hooks() {
        // הוספת מידע סביבה לפיילוג
        if ($this->should_enable_advanced_logging()) {
            add_filter('at_agency_manager_log_context', array($this, 'add_development_context'));
        }

        // הוספת בדיקות אבטחה מתקדמות
        if ($this->should_enable_security_checks()) {
            add_action('admin_init', array($this, 'perform_security_checks'));
        }
    }

    /**
     * אתחול הוקים למנהל
     */
    public function init_admin_hooks() {
        // הוספת התראות דיבוג
        if ($this->should_show_debug_notices()) {
            add_action('admin_notices', array($this, 'show_development_notices'));
        }

        // הוספת מידע דיבוג לדיבאר המנהל
        if ($this->should_show_debug_info()) {
            add_action('admin_bar_menu', array($this, 'add_debug_info_to_admin_bar'), 999);
        }
    }

    /**
     * הצגת התראות פיתוח
     */
    public function show_development_notices() {
        $development_mode = $this->get_current_development_mode();
        $site_type = get_option('at_agency_manager_site_type', 'production');
        $modules = get_option('at_agency_manager_modules', array());

        // התראת מצב פיתוח
        if (!empty($development_mode)) {
            $mode_text = $this->get_mode_display_text($development_mode);
            echo '<div class="notice notice-info is-dismissible" style="border-left: 4px solid #ffb900;">';
            echo '<p><strong>🔧 ' . __('Development Mode Active', 'at-agency-manager') . ':</strong> ';
            echo sprintf(__('Current mode: %s', 'at-agency-manager'), $mode_text) . '</p>';
            echo '</div>';
        }

        // התראת סביבת פיתוח
        if ($site_type === 'development') {
            echo '<div class="notice notice-warning is-dismissible" style="border-left: 4px solid #ff8c00;">';
            echo '<p><strong>⚠️ ' . __('Development Environment', 'at-agency-manager') . ':</strong> ';
            echo __('This site is configured as a development environment. Some features may behave differently.', 'at-agency-manager') . '</p>';
            echo '</div>';
        }

        // אזהרת מודולי פיתוח מסוכנים
        $dangerous_modules = array(
            's3_media_sync' => __('S3 Media Sync is enabled - files will be uploaded to remote storage', 'at-agency-manager'),
            'backup' => __('Automatic backups are enabled - large files may be generated', 'at-agency-manager'),
            'email_log' => __('Email logging is enabled - all emails will be logged', 'at-agency-manager')
        );

        foreach ($dangerous_modules as $module_key => $warning_text) {
            if (!empty($modules[$module_key])) {
                echo '<div class="notice notice-error is-dismissible" style="border-left: 4px solid #dc3232;">';
                echo '<p><strong>🚨 ' . __('Development Module Warning', 'at-agency-manager') . ':</strong> ';
                echo $warning_text . '</p>';
                echo '<p><a href="' . admin_url('admin.php?page=at-agency-manager') . '">' . __('Manage modules', 'at-agency-manager') . '</a></p>';
                echo '</div>';
            }
        }

        // אזהרת שליחת אימיילים
        $smtp_provider = get_option('at_agency_manager_smtp_host');
        if (!empty($smtp_provider) && $site_type === 'development') {
            echo '<div class="notice notice-warning is-dismissible" style="border-left: 4px solid #f39c12;">';
            echo '<p><strong>📧 ' . __('Email Configuration Notice', 'at-agency-manager') . ':</strong> ';
            echo __('SMTP is configured. Emails may be sent to real addresses in development mode.', 'at-agency-manager') . '</p>';
            echo '<p>' . __('Consider using test email addresses or Mailtrap for development.', 'at-agency-manager') . '</p>';
            echo '</div>';
        }

        // אזהרת מנוע חיפוש
        if ($site_type === 'development' && get_option('blog_public') == '1') {
            echo '<div class="notice notice-error is-dismissible" style="border-left: 4px solid #e74c3c;">';
            echo '<p><strong>🔍 ' . __('Search Engine Visibility Warning', 'at-agency-manager') . ':</strong> ';
            echo __('This development site is visible to search engines. This may affect SEO testing.', 'at-agency-manager') . '</p>';
            echo '<p><a href="' . admin_url('options-reading.php') . '">' . __('Disable search engine visibility', 'at-agency-manager') . '</a></p>';
            echo '</div>';
        }
    }

    /**
     * הוספת מידע דיבוג לדיבאר המנהל
     */
    public function add_debug_info_to_admin_bar($wp_admin_bar) {
        $development_mode = $this->get_current_development_mode();
        $site_type = get_option('at_agency_manager_site_type', 'production');
        $modules = get_option('at_agency_manager_modules', array());
        $suite_parent = $wp_admin_bar->get_node('at-suite-status') ? 'at-suite-status' : false;

        if (!empty($development_mode) || $site_type === 'development') {
            // חיווי ראשי עם אייקון ברור
            $indicator_color = ($site_type === 'development') ? '#dc3232' : '#ffb900';
            $indicator_icon = ($site_type === 'development') ? '⚠️' : '🔧';

            $wp_admin_bar->add_node(array(
                'parent' => $suite_parent,
                'id' => 'at_development_indicator',
                'title' => '<span style="color: ' . $indicator_color . '; font-weight: bold;">AT ' . $indicator_icon . ' DEV</span>',
                'href' => '#',
                'meta' => array(
                    'class' => 'at-development-indicator at-suite-source at-suite-source-development',
                    'title' => __('Development Environment Active', 'at-agency-manager')
                )
            ));

            // תפריט ראשי עם מידע מפורט
            $wp_admin_bar->add_node(array(
                'parent' => $suite_parent,
                'id' => 'at_development_info',
                'title' => '<span class="ab-icon dashicons dashicons-info" style="color: #ffb900;"></span> AT ' . __('Development Status', 'at-agency-manager'),
                'href' => '#',
                'meta' => array(
                    'class' => 'at-development-info at-suite-source at-suite-source-development',
                    'title' => __('Development Information', 'at-agency-manager')
                )
            ));

            // מצב פיתוח
            if (!empty($development_mode)) {
                $wp_admin_bar->add_node(array(
                    'parent' => 'at_development_info',
                    'id' => 'at_dev_mode',
                    'title' => '🔧 ' . sprintf(__('Mode: %s', 'at-agency-manager'), $this->get_mode_display_text($development_mode)),
                    'href' => '#'
                ));
            }

            // סוג אתר
            $site_color = ($site_type === 'development') ? '#dc3232' : '#46b450';
            $wp_admin_bar->add_node(array(
                'parent' => 'at_development_info',
                'id' => 'at_site_type',
                'title' => '<span style="color: ' . $site_color . ';">●</span> ' . sprintf(__('Site Type: %s', 'at-agency-manager'), ucfirst($site_type)),
                'href' => '#'
            ));

            // סביבת WordPress
            $env_type = wp_get_environment_type();
            $env_color = ($env_type === 'production') ? '#dc3232' : '#ffb900';
            $wp_admin_bar->add_node(array(
                'parent' => 'at_development_info',
                'id' => 'at_wp_env',
                'title' => '<span style="color: ' . $env_color . ';">●</span> ' . sprintf(__('WP Environment: %s', 'at-agency-manager'), ucfirst($env_type)),
                'href' => '#'
            ));

            // מודולים מסוכנים
            $dangerous_modules = array(
                's3_media_sync' => '☁️ S3 Sync',
                'backup' => '💾 Backup',
                'email_log' => '📧 Email Log'
            );

            $active_dangerous = array_filter($dangerous_modules, function($module) use ($modules) {
                return !empty($modules[$module]);
            }, ARRAY_FILTER_USE_KEY);

            if (!empty($active_dangerous)) {
                $wp_admin_bar->add_node(array(
                    'parent' => 'at_development_info',
                    'id' => 'at_dangerous_modules',
                    'title' => '🚨 ' . __('Active Modules', 'at-agency-manager'),
                    'href' => '#'
                ));

                foreach ($active_dangerous as $module_key => $module_name) {
                    $wp_admin_bar->add_node(array(
                        'parent' => 'at_dangerous_modules',
                        'id' => 'at_module_' . $module_key,
                        'title' => $module_name,
                        'href' => admin_url('admin.php?page=at-agency-manager')
                    ));
                }
            }

            // קישור לניהול
            $wp_admin_bar->add_node(array(
                'parent' => 'at_development_info',
                'id' => 'at_manage_settings',
                'title' => '⚙️ ' . __('Manage Settings', 'at-agency-manager'),
                'href' => admin_url('admin.php?page=at-agency-manager')
            ));

            // קישור להגדרות חיפוש
            if (get_option('blog_public') == '1') {
                $wp_admin_bar->add_node(array(
                    'parent' => 'at_development_info',
                    'id' => 'at_search_settings',
                    'title' => '🔍 ' . __('Disable Search Engines', 'at-agency-manager'),
                    'href' => admin_url('options-reading.php'),
                    'meta' => array('target' => '_blank')
                ));
            }
        }
    }

    /**
     * הוספת הקשר פיתוח ללוגים
     */
    public function add_development_context($context) {
        $context['development_mode'] = $this->get_current_development_mode();
        $context['site_type'] = get_option('at_agency_manager_site_type', 'production');
        $context['wp_environment'] = wp_get_environment_type();
        $context['wp_debug'] = defined('WP_DEBUG') ? WP_DEBUG : false;

        return $context;
    }

    /**
     * ביצוע בדיקות אבטחה
     */
    public function perform_security_checks() {
        // בדיקת הרשאות קבצים
        $this->check_file_permissions();

        // בדיקת הגדרות אבטחה
        $this->check_security_settings();
    }

    /**
     * בדיקת הרשאות קבצים
     */
    private function check_file_permissions() {
        // Check for actual critical files in the WordPress root, not the plugin directory
        $critical_files = array(
            ABSPATH . 'wp-config.php',
            ABSPATH . '.htaccess',
            ABSPATH . 'debug.log'
        );

        foreach ($critical_files as $file) {
            if (file_exists($file) && is_writable($file)) {
                add_action('admin_notices', function() use ($file) {
                    echo '<div class="notice notice-error is-dismissible">';
                    echo '<p><strong>' . __('Security Warning', 'at-agency-manager') . ':</strong> ';
                    echo sprintf(__('File %s is writable. This may pose a security risk.', 'at-agency-manager'), basename($file)) . '</p>';
                    echo '</div>';
                });
            }
        }
    }

    /**
     * בדיקת הגדרות אבטחה
     */
    private function check_security_settings() {
        // בדיקת מפתח API
        if (empty(get_option('at_agency_manager_auth_key'))) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-warning is-dismissible">';
                echo '<p><strong>' . __('Security Notice', 'at-agency-manager') . ':</strong> ';
                echo __('API authentication key is not set. Please configure it in the plugin settings.', 'at-agency-manager') . '</p>';
                echo '</div>';
            });
        }
    }

    /**
     * הוספת מידע סביבה
     */
    public function add_environment_info($info) {
        $info['development_mode'] = $this->get_current_development_mode();
        $info['site_type'] = get_option('at_agency_manager_site_type', 'production');
        $info['wp_environment'] = wp_get_environment_type();
        $info['wp_debug'] = defined('WP_DEBUG') ? WP_DEBUG : false;
        $info['security_checks'] = $this->should_enable_security_checks();

        return $info;
    }

    /**
     * קבלת טקסט תצוגה למצב פיתוח
     */
    private function get_mode_display_text($mode) {
        $texts = array(
            'core' => __('WordPress Core', 'at-agency-manager'),
            'plugin' => __('Plugin Development', 'at-agency-manager'),
            'theme' => __('Theme Development', 'at-agency-manager'),
            'all' => __('All Development', 'at-agency-manager')
        );

        return isset($texts[$mode]) ? $texts[$mode] : __('Unknown', 'at-agency-manager');
    }

    /**
     * קבלת מידע מלא על סביבת הפיתוח
     */
    public function get_development_info() {
        return array(
            'development_mode' => $this->get_current_development_mode(),
            'is_development' => $this->is_development_environment(),
            'site_type' => get_option('at_agency_manager_site_type', 'production'),
            'wp_environment' => wp_get_environment_type(),
            'wp_debug' => defined('WP_DEBUG') ? WP_DEBUG : false,
            'show_debug_notices' => $this->should_show_debug_notices(),
            'advanced_logging' => $this->should_enable_advanced_logging(),
            'remote_api' => $this->should_enable_remote_api(),
            'security_checks' => $this->should_enable_security_checks(),
            'debug_info' => $this->should_show_debug_info()
        );
    }

    /**
     * עדכון הגדרות פיתוח
     */
    public function update_development_settings($settings) {
        $updated = array();

        foreach ($settings as $key => $value) {
            $option_key = 'at_agency_manager_' . $key;
            if (update_option($option_key, $value)) {
                $updated[$key] = $value;
            }
        }

        return $updated;
    }
}
