<?php
/**
 * מחלקה לניהול סביבות פיתוח והגדרות סביבה
 * 
 * מיישמת את התקן הרשמי של WordPress:
 * - WP_ENVIRONMENT_TYPE (local|development|staging|production)
 * - WP_DEVELOPMENT_MODE (core|plugin|theme|all|'')
 */
class AT_Agency_Manager_Environment {
    
    /**
     * קבלת סוג הסביבה הנוכחי
     * 
     * @return string 'local'|'development'|'staging'|'production'
     */
    public static function get_environment_type() {
        if (function_exists('wp_get_environment_type')) {
            return wp_get_environment_type();
        }
        
        // Fallback אם הפונקציה לא קיימת
        if (defined('WP_ENVIRONMENT_TYPE')) {
            return WP_ENVIRONMENT_TYPE;
        }
        
        return 'production';
    }
    
    /**
     * בדיקה אם הסביבה היא production
     * 
     * @return bool
     */
    public static function is_production() {
        return self::get_environment_type() === 'production';
    }
    
    /**
     * בדיקה אם הסביבה היא non-production
     * 
     * @return bool
     */
    public static function is_non_production() {
        return !self::is_production();
    }
    
    /**
     * בדיקה אם הסביבה היא development או local
     * הערה: לא דורשת WP_DEBUG להיות פעיל - בודקת רק את סוג הסביבה
     * 
     * @return bool
     */
    public static function is_development() {
        $env = self::get_environment_type();
        return in_array($env, ['development', 'local']);
    }
    
    /**
     * קבלת מצב הפיתוח הנוכחי
     * 
     * @return string 'core'|'plugin'|'theme'|'all'|''
     */
    public static function get_development_mode() {
        if (function_exists('wp_get_development_mode')) {
            return wp_get_development_mode();
        }
        
        if (defined('WP_DEVELOPMENT_MODE')) {
            $mode = WP_DEVELOPMENT_MODE;
            $valid_modes = ['core', 'plugin', 'theme', 'all', ''];
            return in_array($mode, $valid_modes, true) ? $mode : '';
        }
        
        return '';
    }
    
    /**
     * בדיקה אם מצב פיתוח ספציפי מופעל
     * 
     * @param string $mode מצב הפיתוח לבדיקה ('core'|'plugin'|'theme'|'all')
     * @return bool
     */
    public static function is_development_mode($mode = '') {
        if (function_exists('wp_is_development_mode')) {
            return wp_is_development_mode($mode);
        }
        
        $current_mode = self::get_development_mode();
        
        if (empty($mode)) {
            return !empty($current_mode);
        }
        
        if ($current_mode === 'all') {
            return true;
        }
        
        return $current_mode === $mode;
    }
    
    /**
     * בדיקה אם יש להציג Debug Notices
     * 
     * @return bool
     */
    public static function should_show_debug_notices() {
        $show_option = get_option('at_agency_manager_show_debug_notices', null);
        
        // אם הוגדר במפורש, השתמש בערך
        if ($show_option !== null) {
            return (bool) $show_option;
        }
        
        // ברירת מחדל: הצג רק ב-development/local או אם WP_DEBUG מופעל
        return self::is_development() || (defined('WP_DEBUG') && WP_DEBUG);
    }
    
    /**
     * בדיקה אם יש להציג Debug Info ב-admin bar
     * 
     * @return bool
     */
    public static function should_show_debug_info() {
        $show_option = get_option('at_agency_manager_show_debug_info', null);
        
        // אם הוגדר במפורש, השתמש בערך
        if ($show_option !== null) {
            return (bool) $show_option;
        }
        
        // ברירת מחדל: הצג רק ב-development/local או אם WP_DEBUG מופעל
        return self::is_development() || (defined('WP_DEBUG') && WP_DEBUG);
    }
    
    /**
     * בדיקה אם Remote API מותר
     * 
     * @return bool
     */
    public static function is_remote_api_allowed() {
        $enabled = get_option('at_agency_manager_enable_remote_api', false);
        
        if (!$enabled) {
            return false;
        }
        
        // Remote API מותר רק ב-development/local
        return self::is_development();
    }
    
    /**
     * בדיקה אם מודול צריך להיות פעיל לפי הסביבה
     * 
     * @param string $module_name שם המודול
     * @return bool
     */
    public static function should_enable_module($module_name) {
        $modules = get_option('at_agency_manager_modules', []);
        $module_enabled = !empty($modules[$module_name]);
        
        // כללי סביבה למודולים ספציפיים
        $env_rules = [
            'backup' => true, // פעיל בכל סביבה
            'site_health' => true, // פעיל בכל סביבה
            'activity_log' => true, // פעיל בכל סביבה
            'email_log' => true, // פעיל בכל סביבה, אך ב-production לאגור מינימלית
            'hide_login' => self::is_production() || self::get_environment_type() === 'staging', // מומלץ ב-production/staging
        ];
        
        // אם יש כלל סביבה, בדוק אותו
        if (isset($env_rules[$module_name])) {
            // אם הכלל אומר true, אפשר הפעלה
            // אם הכלל אומר false, חסום הפעלה
            if ($env_rules[$module_name] === false) {
                return false;
            }
        }
        
        return $module_enabled;
    }
    
    /**
     * קבלת הודעת סביבה לבדיקת Site Health
     * 
     * @return array|null מערך עם פרטי הבדיקה או null אם אין בעיה
     */
    public static function get_environment_health_check() {
        $env_type = self::get_environment_type();
        $stored_type = get_option('at_agency_manager_site_type', '');
        
        // בדיקה אם יש חוסר התאמה
        if (!empty($stored_type) && $stored_type !== $env_type) {
            return [
                'status' => 'warning',
                'label' => __('Environment Type Mismatch', 'at-agency-manager'),
                'description' => sprintf(
                    __('The stored site type (%s) does not match the actual environment type (%s). The actual environment type is determined by WP_ENVIRONMENT_TYPE in wp-config.php or server configuration.', 'at-agency-manager'),
                    $stored_type,
                    $env_type
                ),
                'actions' => [
                    [
                        'label' => __('Update stored type', 'at-agency-manager'),
                        'url' => admin_url('admin.php?page=at-agency-manager'),
                    ],
                ],
            ];
        }
        
        // בדיקה אם Remote API מופעל בסביבה לא מתאימה
        if (get_option('at_agency_manager_enable_remote_api', false) && !self::is_development()) {
            return [
                'status' => 'critical',
                'label' => __('Remote API Enabled in Production', 'at-agency-manager'),
                'description' => __('Remote API is enabled but the environment is not development or local. This is a security risk and should be disabled.', 'at-agency-manager'),
                'actions' => [
                    [
                        'label' => __('Disable Remote API', 'at-agency-manager'),
                        'url' => admin_url('admin.php?page=at-agency-manager'),
                    ],
                ],
            ];
        }
        
        return null;
    }
    
    /**
     * קבלת מידע סביבה לבדיקת Site Health Info
     * 
     * @return array מערך עם פרטי הסביבה
     */
    public static function get_environment_info() {
        return [
            'wp_environment_type' => self::get_environment_type(),
            'wp_development_mode' => self::get_development_mode() ?: __('Not configured', 'at-agency-manager'),
            'wp_debug' => defined('WP_DEBUG') ? (WP_DEBUG ? __('Enabled', 'at-agency-manager') : __('Disabled', 'at-agency-manager')) : __('Not defined', 'at-agency-manager'),
            'stored_site_type' => get_option('at_agency_manager_site_type', __('Not set', 'at-agency-manager')),
        ];
    }
    
    /**
     * רישום Site Health checks
     */
    public static function register_site_health_checks() {
        // הוספת בדיקת סביבה
        add_filter('site_status_tests', function($tests) {
            $tests['direct']['at_environment_type'] = [
                'label' => __('Environment Type Configuration', 'at-agency-manager'),
                'test' => [__CLASS__, 'test_environment_type'],
            ];
            
            $tests['direct']['at_development_mode'] = [
                'label' => __('Development Mode Configuration', 'at-agency-manager'),
                'test' => [__CLASS__, 'test_development_mode'],
            ];
            
            return $tests;
        });
        
        // הוספת מידע לסביבה ב-Site Health Info
        add_filter('debug_information', function($info) {
            $info['at-environment'] = [
                'label' => __('AT Agency Manager Environment', 'at-agency-manager'),
                'fields' => self::get_environment_info(),
            ];
            
            return $info;
        });
    }
    
    /**
     * בדיקת Site Health - Environment Type
     */
    public static function test_environment_type() {
        $env_type = self::get_environment_type();
        $stored_type = get_option('at_agency_manager_site_type', '');
        
        $result = [
            'label' => __('Environment type is properly configured', 'at-agency-manager'),
            'status' => 'good',
            'badge' => [
                'label' => __('Environment', 'at-agency-manager'),
                'color' => 'blue',
            ],
            'description' => sprintf(
                '<p>%s: <strong>%s</strong></p>',
                __('Current environment type', 'at-agency-manager'),
                esc_html(ucfirst($env_type))
            ),
            'actions' => '',
            'test' => 'at_environment_type',
        ];
        
        // אזהרה אם יש חוסר התאמה
        if (!empty($stored_type) && $stored_type !== $env_type) {
            $result['status'] = 'recommended';
            $result['label'] = __('Environment type mismatch detected', 'at-agency-manager');
            $result['description'] = sprintf(
                '<p>%s</p><p>%s: <strong>%s</strong><br>%s: <strong>%s</strong></p>',
                __('The stored site type does not match the actual environment type.', 'at-agency-manager'),
                __('Stored type', 'at-agency-manager'),
                esc_html($stored_type),
                __('Actual type', 'at-agency-manager'),
                esc_html($env_type)
            );
        }
        
        return $result;
    }
    
    /**
     * בדיקת Site Health - Development Mode
     */
    public static function test_development_mode() {
        $dev_mode = self::get_development_mode();
        $env_type = self::get_environment_type();
        
        $result = [
            'label' => __('Development mode is properly configured', 'at-agency-manager'),
            'status' => 'good',
            'badge' => [
                'label' => __('Development', 'at-agency-manager'),
                'color' => 'blue',
            ],
            'description' => sprintf(
                '<p>%s: <strong>%s</strong></p>',
                __('Development mode', 'at-agency-manager'),
                $dev_mode ? esc_html(ucfirst($dev_mode)) : __('Not configured', 'at-agency-manager')
            ),
            'actions' => '',
            'test' => 'at_development_mode',
        ];
        
        // אזהרה אם Development Mode מופעל ב-Production
        if ($env_type === 'production' && !empty($dev_mode)) {
            $result['status'] = 'critical';
            $result['label'] = __('Development mode should not be enabled in production', 'at-agency-manager');
            $result['description'] = sprintf(
                '<p>%s</p><p>%s: <strong>%s</strong></p>',
                __('Development mode is enabled in production environment. This should be disabled.', 'at-agency-manager'),
                __('Current mode', 'at-agency-manager'),
                esc_html($dev_mode)
            );
        }
        
        return $result;
    }
}

