<?php
/**
 * מחלקה לניהול האקו-סיסטם של AT Agency
 * 
 * אחראית על:
 * - גילוי תוספים אחרים באקו-סיסטם
 * - הצגת סטטוס ב-Site Health
 * - אפשרות להתקנה מהירה של תוספים חסרים
 */
class AT_Agency_Manager_Ecosystem {
    
    /**
     * רשימת התוספים באקו-סיסטם (Internal cache)
     */
    private static $ecosystem_plugins_cache = null;

    /**
     * Get ecosystem plugins list (filtered and discovered).
     * 
     * @return array
     */
    public static function get_ecosystem_plugins() {
        if (self::$ecosystem_plugins_cache !== null) {
            return self::$ecosystem_plugins_cache;
        }

        // Built-in ecosystem plugins (first-party)
        $plugins = [
            'wordpress-ai-assistant' => [
                'name' => 'WordPress AI Assistant',
                'slug' => 'wordpress-ai-assistant',
                'file' => 'wordpress-ai-assistant/wordpress-ai-assistant.php',
                'download_url' => 'https://github.com/athbss/wp-ai-bro/archive/refs/heads/main.zip',
                'description' => 'תוסף AI מתקדם לשיפור תהליכי עבודה',
                'constant' => 'WORDPRESS_AI_ASSISTANT_VERSION',
                'tier' => 'first-party',
            ]
        ];

        // Allow third-party plugins to register
        $plugins = apply_filters('at_ecosystem_plugins', $plugins);

        // Auto-discover plugins with AT Suite header
        $discovered = self::discover_suite_plugins();
        $plugins = array_merge($plugins, $discovered);

        self::$ecosystem_plugins_cache = $plugins;
        return $plugins;
    }

    /**
     * Discover plugins declaring AT Suite membership via plugin header.
     *
     * Third-party plugins can add this header to their main file:
     *   AT Suite: at-agency-manager
     *   AT Suite Role: analytics
     */
    public static function discover_suite_plugins() {
        // Check transient first
        $cached = get_transient('at_suite_discovered_plugins');
        if ($cached !== false) {
            return $cached;
        }

        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $all_plugins = get_plugins();
        $discovered = array();

        foreach ($all_plugins as $file => $data) {
            // Read extra headers
            $plugin_path = WP_PLUGIN_DIR . '/' . $file;
            $extra = get_file_data($plugin_path, array(
                'at_suite'      => 'AT Suite',
                'at_suite_role' => 'AT Suite Role',
            ));

            if (!empty($extra['at_suite']) && $extra['at_suite'] === 'at-agency-manager') {
                $slug = dirname($file);
                // Skip if already in built-in list
                if ($slug === 'wordpress-ai-assistant') {
                    continue;
                }

                $discovered[$slug] = array(
                    'name'        => $data['Name'],
                    'slug'        => $slug,
                    'file'        => $file,
                    'description' => $data['Description'],
                    'version'     => $data['Version'],
                    'role'        => $extra['at_suite_role'] ?: 'extension',
                    'tier'        => 'third-party',
                    'auto_discovered' => true,
                    // Download URL is unknown for auto-discovered plugins unless they register via filter
                    'download_url' => '', 
                );
            }
        }

        // Cache for 1 hour
        set_transient('at_suite_discovered_plugins', $discovered, HOUR_IN_SECONDS);

        return $discovered;
    }

    /**
     * אתחול המחלקה
     */
    public static function init() {
        // רישום בדיקות Site Health
        add_filter('site_status_tests', [__CLASS__, 'register_site_health_checks']);
        
        // רישום AJAX להתקנה
        add_action('wp_ajax_at_agency_install_plugin', [__CLASS__, 'ajax_install_plugin']);
    }

    /**
     * רישום בדיקות Site Health
     */
    public static function register_site_health_checks($tests) {
        $tests['direct']['at_ecosystem'] = [
            'label' => __('AT Agency Ecosystem', 'at-agency-manager'),
            'test' => [__CLASS__, 'test_ecosystem_status'],
        ];
        return $tests;
    }

    /**
     * בדיקת סטטוס האקו-סיסטם
     */
    public static function test_ecosystem_status() {
        $result = [
            'label' => __('AT Agency Ecosystem Status', 'at-agency-manager'),
            'status' => 'good',
            'badge' => [
                'label' => __('Ecosystem', 'at-agency-manager'),
                'color' => 'blue',
            ],
            'description' => sprintf('<p>%s</p>', __('כל תוספי המערכת מותקנים ופעילים.', 'at-agency-manager')),
            'actions' => '',
            'test' => 'at_ecosystem',
        ];

        $missing_plugins = [];
        $plugins = self::get_ecosystem_plugins();
        
        foreach ($plugins as $key => $plugin) {
            if (!self::is_plugin_installed($plugin)) {
                $missing_plugins[$key] = $plugin;
            }
        }

        if (!empty($missing_plugins)) {
            $result['status'] = 'recommended';
            $result['label'] = __('Missing Ecosystem Plugins', 'at-agency-manager');
            $result['description'] = sprintf(
                '<p>%s</p><ul>', 
                __('התוספים הבאים חסרים במערכת ומומלצים להתקנה:', 'at-agency-manager')
            );

            foreach ($missing_plugins as $key => $plugin) {
                $result['description'] .= sprintf(
                    '<li><strong>%s</strong>: %s</li>',
                    esc_html($plugin['name']),
                    esc_html($plugin['description'])
                );
            }
            $result['description'] .= '</ul>';

            // הוספת כפתורי פעולה
            // הערה: ב-Site Health כפתורי פעולה הם קישורים. נשתמש בקישור לסקריפט שיוצר AJAX
            // או פשוט נציג הסבר. לצערי Site Health לא תומך בכפתורי AJAX ישירים בקלות.
            // לכן נוסיף קישור לעמוד הניהול שלנו שבו נוסיף כפתור התקנה.
            $result['actions'] = sprintf(
                '<p><a href="%s" class="button">%s</a></p>',
                admin_url('admin.php?page=at-agency-manager&tab=suite'),
                __('Manage Ecosystem', 'at-agency-manager')
            );
        }

        return $result;
    }

    /**
     * בדיקה האם תוסף מותקן
     */
    private static function is_plugin_installed($plugin) {
        if (!function_exists('is_plugin_active')) {
            include_once(ABSPATH . 'wp-admin/includes/plugin.php');
        }
        
        return is_plugin_active($plugin['file']) || (isset($plugin['constant']) && defined($plugin['constant']));
    }

    /**
     * AJAX: התקנת תוסף
     */
    public static function ajax_install_plugin() {
        check_ajax_referer('at_agency_install_plugin', 'nonce');

        if (!current_user_can('install_plugins')) {
            wp_send_json_error(__('Permission denied', 'at-agency-manager'));
        }

        $slug = sanitize_text_field($_POST['slug'] ?? '');
        $plugins = self::get_ecosystem_plugins();
        
        if (!isset($plugins[$slug])) {
            wp_send_json_error(__('Plugin not found', 'at-agency-manager'));
        }

        $plugin = $plugins[$slug];
        
        if (empty($plugin['download_url'])) {
            wp_send_json_error(__('Plugin download URL not available', 'at-agency-manager'));
        }
        
        include_once(ABSPATH . 'wp-admin/includes/class-wp-upgrader.php');
        include_once(ABSPATH . 'wp-admin/includes/plugin-install.php');
        include_once(ABSPATH . 'wp-admin/includes/plugin.php');

        // If plugin already exists but inactive, just activate.
        if (file_exists(WP_PLUGIN_DIR . '/' . $plugin['file']) && !is_plugin_active($plugin['file'])) {
            $activate = activate_plugin($plugin['file']);
            if (is_wp_error($activate)) {
                wp_send_json_error($activate->get_error_message());
            }
            wp_send_json_success(__('Plugin activated successfully', 'at-agency-manager'));
        }
        if (file_exists(WP_PLUGIN_DIR . '/' . $plugin['file']) && is_plugin_active($plugin['file'])) {
            wp_send_json_success(__('Plugin is already installed and active', 'at-agency-manager'));
        }

        $upgrader = new Plugin_Upgrader(new WP_Ajax_Upgrader_Skin());
        $result = $upgrader->install($plugin['download_url']);

        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        }

        if (!$result) {
            wp_send_json_error(__('Installation failed', 'at-agency-manager'));
        }

        // ניסיון הפעלה בדרך הקנונית
        $activate = activate_plugin($plugin['file']);
        if (!is_wp_error($activate)) {
            wp_send_json_success(__('Plugin installed and activated', 'at-agency-manager'));
        }

        // Fallback: GitHub ZIP often changes directory name. Find matching plugin header by slug/name.
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $all_plugins = get_plugins();
        foreach ($all_plugins as $plugin_file => $data) {
            $dir = dirname($plugin_file);
            $name = isset($data['Name']) ? sanitize_title($data['Name']) : '';
            if ($dir === $slug || $name === $slug) {
                $fallback_activate = activate_plugin($plugin_file);
                if (!is_wp_error($fallback_activate)) {
                    wp_send_json_success(__('Plugin installed and activated', 'at-agency-manager'));
                }
            }
        }

        wp_send_json_error(__('Installed but failed to activate automatically. Please activate from Plugins screen.', 'at-agency-manager'));
    }
}
