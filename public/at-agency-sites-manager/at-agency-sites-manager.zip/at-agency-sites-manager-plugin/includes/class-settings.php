<?php
/**
 * מחלקה לניהול הגדרות התוסף
 */
class AT_Agency_Manager_Settings {
    /**
     * @var AT_Agency_Manager_Logger מופע של מחלקת הלוגר
     */
    private $logger;

    /**
     * אתחול המחלקה והגדרת האזנה לאירועים רלוונטיים
     * 
     * @param AT_Agency_Manager_Logger $logger מופע של מחלקת הלוגר
     */
    public function __construct($logger) {
        $this->logger = $logger;
        
        // Initialize Settings Schema Registry
        require_once AT_AGENCY_MANAGER_PATH . 'includes/class-settings-schema.php';
        AT_Agency_Manager_Settings_Schema::get_instance()->init();

        add_action('admin_menu', array($this, 'add_settings_pages'));
        add_action('admin_init', array($this, 'handle_legacy_log_routes'), 1);
        add_action('admin_init', array($this, 'handle_legacy_site_health_route'), 1);
        add_action('admin_page_access_denied', array($this, 'handle_legacy_log_routes'), 1);
        add_action('admin_page_access_denied', array($this, 'handle_legacy_site_health_route'), 1);
        add_action('admin_init', array($this, 'register_settings'));
        add_action('wp_ajax_at_generate_api_key', array($this, 'ajax_generate_api_key'));
        add_action('wp_ajax_at_clear_logs', array($this, 'ajax_clear_logs'));
        add_action('wp_ajax_at_resend_email', array($this, 'ajax_resend_email'));
        add_action('admin_post_at_export_logs', array($this, 'export_logs'));
        add_action('admin_head', array($this, 'custom_menu_styling'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        
        // Ensure API key exists on initialization
        $this->ensure_api_key_exists();
    }
    
    /**
     * סגנון מותאם לתפריט של התוסף
     */
    public function custom_menu_styling() {
        ?>
        <style>
            /* תפריט AT Agency Manager בצבע מיוחד */
            #adminmenu #toplevel_page_at-agency-manager {
                margin-top: 20px;
                padding-top: 20px;
                border-top: 1px solid rgba(240, 246, 252, 0.1);
                position: relative;
            }

            /* Suite group label */
            #adminmenu #toplevel_page_at-agency-manager::before {
                content: "AT Suite";
                display: block;
                padding: 4px 12px 2px;
                font-size: 10px;
                text-transform: uppercase;
                letter-spacing: 0.5px;
                color: rgba(240, 246, 252, 0.4);
                margin-bottom: 4px;
            }
            
            #adminmenu #toplevel_page_at-agency-manager .wp-menu-image {
                background-color: rgba(78, 197, 224, 0.1);
                border-radius: 4px;
            }
            
            #adminmenu #toplevel_page_at-agency-manager:hover .wp-menu-image,
            #adminmenu #toplevel_page_at-agency-manager.current .wp-menu-image {
                background-color: rgba(78, 197, 224, 0.2);
            }
            
            #adminmenu #toplevel_page_at-agency-manager .wp-menu-image img {
                padding: 6px;
            }
            
            #adminmenu #toplevel_page_at-agency-manager .wp-menu-name {
                color: #4ec5e0 !important;
                font-weight: 500;
            }
            
            #adminmenu #toplevel_page_at-agency-manager:hover .wp-menu-name,
            #adminmenu #toplevel_page_at-agency-manager.current .wp-menu-name {
                color: #6dd6eb !important;
            }
            
            /* תפריט WordPress AI Assistant מתחת לAT */
            #adminmenu #toplevel_page_wordpress-ai-assistant {
                margin-top: 0;
            }
            
            #adminmenu #toplevel_page_wordpress-ai-assistant .wp-menu-image {
                background-color: rgba(138, 43, 226, 0.1);
                border-radius: 4px;
            }
            
            #adminmenu #toplevel_page_wordpress-ai-assistant:hover .wp-menu-image,
            #adminmenu #toplevel_page_wordpress-ai-assistant.current .wp-menu-image {
                background-color: rgba(138, 43, 226, 0.2);
            }
        </style>
        <?php
    }
    
    /**
     * טעינת קבצי CSS ו-JS למסך הניהול
     */
    public function enqueue_admin_assets($hook) {
        // Load only on plugin pages
        if (strpos($hook, 'at-agency-manager') === false && 
            strpos($hook, 'at-site-health') === false && 
            strpos($hook, 'at-activity-log') === false && 
            strpos($hook, 'at-email-log') === false) {
            return;
        }
        
        wp_enqueue_style(
            'at-suite-tokens',
            AT_AGENCY_MANAGER_URL . 'assets/css/suite-tokens.css',
            array(),
            AT_AGENCY_MANAGER_VERSION
        );

        wp_enqueue_style(
            'at-agency-manager-admin',
            AT_AGENCY_MANAGER_URL . 'assets/css/admin.css',
            array('at-suite-tokens'),
            AT_AGENCY_MANAGER_VERSION
        );
        
        wp_enqueue_style(
            'at-agency-manager-admin-styles',
            AT_AGENCY_MANAGER_URL . 'assets/css/admin-styles.css',
            array(),
            AT_AGENCY_MANAGER_VERSION
        );

        wp_enqueue_style(
            'at-agency-manager-admin-layout',
            AT_AGENCY_MANAGER_URL . 'assets/css/admin-layout.css',
            array('at-agency-manager-admin-styles'),
            AT_AGENCY_MANAGER_VERSION
        );
    }

    /**
     * הוספת דפי הגדרות לתפריט הניהול
     */
    public function add_settings_pages() {
        // Load module files if enabled
        $modules = get_option('at_agency_manager_modules', []);
        
        // Load page ordering settings
        if (!empty($modules['page_ordering'])) {
            $page_ordering_settings_file = AT_AGENCY_MANAGER_PATH . 'modules/page-ordering-settings.php';
            if (file_exists($page_ordering_settings_file)) {
                require_once $page_ordering_settings_file;
            }
        }
        
        // Load activity log
        if (!empty($modules['activity_log'])) {
            $activity_log_file = AT_AGENCY_MANAGER_PATH . 'modules/activity-log.php';
            if (file_exists($activity_log_file)) {
                require_once $activity_log_file;
            }
        }
        
        // Load email log
        if (!empty($modules['email_log'])) {
            $email_log_file = AT_AGENCY_MANAGER_PATH . 'modules/email-log.php';
            if (file_exists($email_log_file)) {
                require_once $email_log_file;
            }
        }

        // Load Gravity Forms Autofill
        if (!empty($modules['gf_autofill'])) {
            $gf_autofill_file = AT_AGENCY_MANAGER_PATH . 'modules/gf-autofill.php';
            if (file_exists($gf_autofill_file)) {
                require_once $gf_autofill_file;
            }
        }
        
        $menu_title = at_agency_manager_admin_label(
            'WPAT <span style="font-size: 9px; opacity: 0.7;">(Beta)</span>',
            'WPAT <span style="font-size: 9px; opacity: 0.7;">(בטא)</span>'
        );

        add_menu_page(
            at_agency_manager_admin_label('AT Agency Manager', 'מנהל האתרים AT'),
            $menu_title,
            'manage_options',
            'at-agency-manager',
            array($this, 'render_main_settings'),
            AT_AGENCY_MANAGER_URL . 'assets/images/at-icon.png',
            99998
        );

        add_submenu_page(
            'at-agency-manager',
            at_agency_manager_admin_label('General Settings', 'הגדרות כלליות'),
            at_agency_manager_admin_label('Settings', 'הגדרות'),
            'manage_options',
            'at-agency-manager',
            array($this, 'render_main_settings')
        );

        add_submenu_page(
            'at-agency-manager',
            at_agency_manager_admin_label('Site Health', 'בריאות האתר'),
            at_agency_manager_admin_label('Site Health', 'בריאות האתר'),
            'manage_options',
            'at-site-health',
            array($this, 'redirect_to_main_health_tab')
        );
        remove_submenu_page('at-agency-manager', 'at-site-health');

        add_submenu_page(
            'at-agency-manager',
            at_agency_manager_admin_label('Email Settings', 'הגדרות אימייל'),
            at_agency_manager_admin_label('Email', 'אימייל'),
            'manage_options',
            'at-agency-manager-email',
            array($this, 'render_email_settings')
        );

        // Unified Logs page - replaces separate log pages
        add_submenu_page(
            'at-agency-manager',
            at_agency_manager_admin_label('Logs Management', 'ניהול לוגים'),
            at_agency_manager_admin_label('Logs', 'לוגים'),
            'manage_options',
            'at-agency-manager-logs',
            array($this, 'render_unified_logs')
        );

        add_submenu_page(
            'at-agency-manager',
            at_agency_manager_admin_label('API Documentation', 'תיעוד API'),
            at_agency_manager_admin_label('API Docs', 'תיעוד API'),
            'manage_options',
            'at-agency-manager-api-docs',
            array($this, 'render_api_documentation')
        );

		add_submenu_page(
			'at-agency-manager',
			at_agency_manager_admin_label('Page Ordering Settings', 'הגדרות סדר עמודים'),
			at_agency_manager_admin_label('Page Ordering', 'סדר עמודים'),
			'manage_options',
			'at-page-ordering-settings',
			'at_render_page_ordering_settings_page'
		);
		
		// Legacy routes for backward compatibility.
		add_submenu_page(
			'at-agency-manager',
			at_agency_manager_admin_label('Activity Log', 'יומן פעילות'),
			at_agency_manager_admin_label('Activity Log', 'יומן פעילות'),
			'manage_options',
			'at-activity-log',
			array($this, 'redirect_to_unified_logs_activity')
		);

		add_submenu_page(
			'at-agency-manager',
			at_agency_manager_admin_label('Email Log', 'יומן אימיילים'),
			at_agency_manager_admin_label('Email Log', 'יומן אימיילים'),
			'manage_options',
			'at-email-log',
			array($this, 'redirect_to_unified_logs_email')
		);

		// Hide legacy entries from visible menu but keep routes alive.
		remove_submenu_page('at-agency-manager', 'at-activity-log');
		remove_submenu_page('at-agency-manager', 'at-email-log');
    }

    /**
     * רישום הגדרות התוסף
     */
    public function register_settings() {
        // הגדרות כלליות
        register_setting('at_agency_manager_general', 'at_agency_manager_auth_key');
        register_setting('at_agency_manager_general', 'at_agency_manager_site_type');
        register_setting('at_agency_manager_general', 'at_agency_manager_notifications');
        register_setting('at_agency_manager_general', 'at_agency_manager_enable_file_logging');
        // רישום מודולים שניתנים לכיבוי/הפעלה
        register_setting('at_agency_manager_general', 'at_agency_manager_modules');
        // נתיב התחברות מותאם
        register_setting('at_agency_manager_general', 'at_custom_login_slug');

        // הגדרות דוא"ל
        register_setting('at_agency_manager_email', 'at_agency_manager_smtp_host');
        register_setting('at_agency_manager_email', 'at_agency_manager_smtp_port');
        register_setting('at_agency_manager_email', 'at_agency_manager_smtp_user');
        register_setting('at_agency_manager_email', 'at_agency_manager_smtp_pass');
        register_setting('at_agency_manager_email', 'at_agency_manager_smtp_from');
        register_setting('at_agency_manager_email', 'at_use_sendgrid');
        register_setting('at_agency_manager_email', 'at_sender_email_name');
        register_setting('at_agency_manager_email', 'at_sender_email_address');
        register_setting('at_agency_manager_email', 'at_sent_to_admin_default');
        
        // הגדרות מיתוג
        register_setting('at-branding', 'clients_main_color');
        register_setting('at-branding', 'clients_logo_file');
        register_setting('at-branding', 'admin_favicon_file');
        register_setting('at-branding', 'at_login_bg_color');
        register_setting('at-branding', 'at_button_color');
        register_setting('at-branding', 'at_admin_font');
        
        // הגדרות קישורים מקוצרים
        register_setting('at_short_links_settings', 'at_short_links_domain');
        register_setting('at_short_links_settings', 'at_short_links_qr_logo');
    }

    /**
     * הצגת דף ההגדרות הראשי
     */
    public function render_main_settings() {
        // בדיקת הרשאות
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'at-agency-manager'));
        }
        
        $current_tab = isset($_GET['tab']) ? sanitize_key(wp_unslash($_GET['tab'])) : 'dashboard';
        if ('health' === $current_tab) {
            $current_tab = 'dashboard';
        }
        if (in_array($current_tab, array('ecosystem', 'about'), true)) {
            $current_tab = 'suite';
        }
        if (!in_array($current_tab, array('dashboard', 'suite', 'settings'), true)) {
            $current_tab = 'dashboard';
        }
        ?>
        <div class="wrap at-agency-manager-wrap">
            <h1><?php _e('AT Agency Manager', 'at-agency-manager'); ?></h1>
            
            <!-- טאבים -->
            <nav class="nav-tab-wrapper" style="margin-bottom: 20px;">
                <a href="?page=at-agency-manager&tab=dashboard" class="nav-tab <?php echo $current_tab === 'dashboard' ? 'nav-tab-active' : ''; ?>">
                    <?php _e('Dashboard', 'at-agency-manager'); ?>
                </a>
                <a href="?page=at-agency-manager&tab=settings" class="nav-tab <?php echo $current_tab === 'settings' ? 'nav-tab-active' : ''; ?>">
                    <?php _e('Settings', 'at-agency-manager'); ?>
                </a>
                <a href="?page=at-agency-manager&tab=suite" class="nav-tab <?php echo $current_tab === 'suite' ? 'nav-tab-active' : ''; ?>">
                    <?php _e('Suite', 'at-agency-manager'); ?>
                </a>
            </nav>
            
            <?php
            if ($current_tab === 'dashboard') {
                $this->render_dashboard_tab();
            } elseif ($current_tab === 'settings') {
                $this->render_settings_tab();
            } elseif ($current_tab === 'suite') {
                $this->render_suite_tab();
            } else {
                $this->render_dashboard_tab();
            }
            ?>
        </div>
        <?php
    }

    /**
     * הצגת טאב Dashboard
     */
    private function render_dashboard_tab() {
        $env_info = AT_Agency_Manager_Environment::get_environment_info();
        ?>
        <div class="card" style="margin-top: 20px;">
            <h2><?php _e('Site Health & Overview', 'at-agency-manager'); ?></h2>
            <p class="description"><?php _e('This screen combines live health signals, environment state, and maintenance actions in one place.', 'at-agency-manager'); ?></p>
        </div>

        <?php AT_Agency_Manager_Health_Dashboard::render(array('embedded' => true)); ?>

        <div class="card" style="margin-top: 20px;">
            <h2><?php _e('Environment Snapshot', 'at-agency-manager'); ?></h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; margin-top: 16px;">
                <?php foreach ($env_info as $label => $value): ?>
                    <div style="background: #fff; border: 1px solid #e2e2e2; border-radius: 6px; padding: 16px;">
                        <p style="margin: 0 0 8px; color: #555;"><?php echo esc_html(ucfirst(str_replace('_', ' ', $label))); ?></p>
                        <p style="margin: 0; font-size: 18px; font-weight: 600;"><?php echo esc_html($value); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="card" style="margin-top: 20px;">
            <h2><?php _e('Quick Actions', 'at-agency-manager'); ?></h2>
            <p style="margin-top: 10px;">
                <a href="?page=at-agency-manager&tab=settings" class="button button-primary">
                    <?php _e('Manage Settings & Modules', 'at-agency-manager'); ?>
                </a>
                <a href="<?php echo esc_url(admin_url('admin.php?page=at-agency-manager-logs')); ?>" class="button button-secondary">
                    <?php _e('Open Logs', 'at-agency-manager'); ?>
                </a>
                <a href="<?php echo esc_url(admin_url('admin.php?page=at-agency-manager-backup')); ?>" class="button button-secondary">
                    <?php _e('Open Backup', 'at-agency-manager'); ?>
                </a>
            </p>
        </div>
        <?php $this->render_missing_ecosystem_plugins_card(); ?>
        <?php $this->render_ecosystem_install_script(); ?>
        <?php
    }
    
    /**
     * הצגת טאב Suite (איחוד Ecosystem + About)
     */
    private function render_suite_tab() {
        ?>
        <div class="card" style="margin-top: 20px;">
            <h2><?php _e('Suite Overview', 'at-agency-manager'); ?></h2>
            <p><?php _e('Central view for AT Suite identity, versioning, and ecosystem plugin lifecycle.', 'at-agency-manager'); ?></p>
            <table class="form-table">
                <tr>
                    <th scope="row"><?php _e('Plugin Version', 'at-agency-manager'); ?></th>
                    <td><?php echo esc_html(AT_AGENCY_MANAGER_VERSION); ?></td>
                </tr>
                <tr>
                    <th scope="row"><?php _e('Author', 'at-agency-manager'); ?></th>
                    <td><a href="https://atd.digital" target="_blank" rel="noopener noreferrer">Amit Trabelsi</a></td>
                </tr>
                <tr>
                    <th scope="row"><?php _e('Resources', 'at-agency-manager'); ?></th>
                    <td>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=at-agency-manager-api-docs')); ?>"><?php _e('API Documentation', 'at-agency-manager'); ?></a>
                        |
                        <a href="https://github.com/amit-trabelski-digital/at-agency-sites-manager-wp-plugin" target="_blank" rel="noopener noreferrer"><?php _e('GitHub Repository', 'at-agency-manager'); ?></a>
                    </td>
                </tr>
            </table>
        </div>

        <div class="card" style="margin-top: 20px;">
            <h2><?php _e('AT Agency Ecosystem', 'at-agency-manager'); ?></h2>
            <p><?php _e('Install, activate, and manage suite plugins from one table.', 'at-agency-manager'); ?></p>
            <?php $this->render_ecosystem_table(); ?>
        </div>

        <?php $this->render_ecosystem_install_script(); ?>
        <?php
    }

    /**
     * Ecosystem table renderer reused by Suite tab.
     *
     * @return void
     */
    private function render_ecosystem_table() {
        if (!function_exists('is_plugin_active')) {
            include_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $plugins = AT_Agency_Manager_Ecosystem::get_ecosystem_plugins();
        ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php _e('Plugin', 'at-agency-manager'); ?></th>
                    <th><?php _e('Description', 'at-agency-manager'); ?></th>
                    <th><?php _e('Status', 'at-agency-manager'); ?></th>
                    <th><?php _e('Action', 'at-agency-manager'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($plugins as $slug => $plugin) : ?>
                    <?php
                    $is_installed = file_exists(WP_PLUGIN_DIR . '/' . $plugin['file']);
                    $is_active = $is_installed && is_plugin_active($plugin['file']);
                    ?>
                    <tr>
                        <td>
                            <strong><?php echo esc_html($plugin['name']); ?></strong>
                            <?php if (isset($plugin['tier']) && 'first-party' === $plugin['tier']) : ?>
                                <span class="at-suite-badge" style="background:#e6f7ff;color:#0073aa;border:1px solid #b3d7ff;">Official</span>
                            <?php elseif (isset($plugin['tier']) && 'third-party' === $plugin['tier']) : ?>
                                <span class="at-suite-badge" style="background:#f0f0f1;color:#646970;border:1px solid #c3c4c7;">Community</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo esc_html($plugin['description']); ?></td>
                        <td>
                            <?php if ($is_active) : ?>
                                <span style="color: green; font-weight: bold;"><?php _e('Active', 'at-agency-manager'); ?></span>
                            <?php elseif ($is_installed) : ?>
                                <span style="color: orange; font-weight: bold;"><?php _e('Installed', 'at-agency-manager'); ?></span>
                            <?php else : ?>
                                <span style="color: red; font-weight: bold;"><?php _e('Missing', 'at-agency-manager'); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($is_active) : ?>
                                <button class="button" disabled><?php _e('Installed', 'at-agency-manager'); ?></button>
                            <?php elseif ($is_installed) : ?>
                                <?php $activate_url = wp_nonce_url('plugins.php?action=activate&plugin=' . $plugin['file'], 'activate-plugin_' . $plugin['file']); ?>
                                <a href="<?php echo esc_url($activate_url); ?>" class="button button-primary"><?php _e('Activate', 'at-agency-manager'); ?></a>
                            <?php elseif (!empty($plugin['download_url'])) : ?>
                                <button class="button button-primary install-plugin-btn" data-slug="<?php echo esc_attr($slug); ?>" data-nonce="<?php echo esc_attr(wp_create_nonce('at_agency_install_plugin')); ?>"><?php _e('Install Now', 'at-agency-manager'); ?></button>
                            <?php else : ?>
                                <span class="description"><?php _e('Manual install required', 'at-agency-manager'); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div id="installation-log" style="margin-top: 20px; display: none; background: #f0f0f1; padding: 10px; border: 1px solid #ccc;"></div>
        <?php
    }

    /**
     * Dashboard card to quickly install missing ecosystem plugins.
     *
     * @return void
     */
    private function render_missing_ecosystem_plugins_card() {
        if (!class_exists('AT_Agency_Manager_Ecosystem')) {
            return;
        }
        if (!function_exists('is_plugin_active')) {
            include_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $plugins = AT_Agency_Manager_Ecosystem::get_ecosystem_plugins();
        $missing = array();
        foreach ($plugins as $slug => $plugin) {
            $installed = !empty($plugin['file']) && file_exists(WP_PLUGIN_DIR . '/' . $plugin['file']);
            $active = $installed && is_plugin_active($plugin['file']);
            if (!$installed || !$active) {
                $missing[$slug] = $plugin;
            }
        }

        if (empty($missing)) {
            return;
        }
        ?>
        <div class="card" style="margin-top: 20px;">
            <h2><?php _e('Additional Suite Plugins', 'at-agency-manager'); ?></h2>
            <p><?php _e('The following plugins are missing or inactive. Click install to fetch and install directly from the source.', 'at-agency-manager'); ?></p>
            <ul style="margin: 0; padding-right: 20px;">
                <?php foreach ($missing as $slug => $plugin) : ?>
                    <li style="margin-bottom: 8px;">
                        <strong><?php echo esc_html($plugin['name']); ?></strong>
                        <span style="color:#646970;"> - <?php echo esc_html($plugin['description']); ?></span>
                        <?php if (!empty($plugin['download_url'])) : ?>
                            <button class="button button-primary install-plugin-btn"
                                    style="margin-right: 10px;"
                                    data-slug="<?php echo esc_attr($slug); ?>"
                                    data-nonce="<?php echo esc_attr(wp_create_nonce('at_agency_install_plugin')); ?>">
                                <?php _e('Install Now', 'at-agency-manager'); ?>
                            </button>
                        <?php else : ?>
                            <span class="description" style="margin-right: 10px;"><?php _e('No download source configured', 'at-agency-manager'); ?></span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
            <div id="installation-log" style="margin-top: 15px; display: none; background: #f0f0f1; padding: 10px; border: 1px solid #ccc;"></div>
        </div>
        <?php
    }

    /**
     * Shared install script for ecosystem install buttons.
     *
     * @return void
     */
    private function render_ecosystem_install_script() {
        static $script_rendered = false;
        if ($script_rendered) {
            return;
        }
        $script_rendered = true;
        ?>
        <script>
        jQuery(document).ready(function($) {
            const installingLabel = <?php echo wp_json_encode(__('Installing...', 'at-agency-manager')); ?>;
            const installingMessage = <?php echo wp_json_encode(__('Starting installation...', 'at-agency-manager')); ?>;
            const installedLabel = <?php echo wp_json_encode(__('Installed!', 'at-agency-manager')); ?>;
            const installNowLabel = <?php echo wp_json_encode(__('Install Now', 'at-agency-manager')); ?>;

            $(document).on('click', '.install-plugin-btn', function() {
                var btn = $(this);
                var slug = btn.data('slug');
                var nonce = btn.data('nonce');
                var log = $('#installation-log');

                btn.prop('disabled', true).text(installingLabel);
                log.show().html('<p>' + installingMessage + '</p>');

                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'at_agency_install_plugin',
                        slug: slug,
                        nonce: nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            log.append('<p style="color: green;">' + response.data + '</p>');
                            btn.text(installedLabel);
                            setTimeout(function() {
                                location.reload();
                            }, 1200);
                        } else {
                            log.append('<p style="color: red;">Error: ' + response.data + '</p>');
                            btn.prop('disabled', false).text(installNowLabel);
                        }
                    },
                    error: function() {
                        log.append('<p style="color: red;">Ajax Error</p>');
                        btn.prop('disabled', false).text(installNowLabel);
                    }
                });
            });
        });
        </script>
        <?php
    }
    
    /**
     * הצגת טאב הגדרות
     */
    private function render_settings_tab() {
        ?>
        <style>
            .at-agency-settings-shell {
                max-width: 1400px;
                width: 100%;
            }
            .at-agency-settings-shell .form-table {
                width: 100%;
            }
            .at-agency-settings-shell .form-table th {
                width: 200px;
                vertical-align: top;
                padding-top: 20px;
            }
            .at-agency-settings-shell .form-table td {
                width: auto;
                padding-top: 20px;
            }
            .at-agency-settings-shell .api-key-wrapper {
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
                align-items: center;
            }
            .at-agency-settings-shell .api-key-wrapper input {
                flex: 1;
                min-width: 300px;
                max-width: 600px;
            }
            .at-agency-settings-shell .modules-grid {
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(450px, 1fr));
                gap: 15px;
                margin-top: 10px;
            }
            .at-agency-settings-shell .module-card {
                padding: 15px;
                background: #fff;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                transition: all 0.3s ease;
                box-shadow: 0 1px 3px rgba(0,0,0,0.05);
            }
            .at-agency-settings-shell .module-card:hover {
                box-shadow: 0 2px 6px rgba(0,0,0,0.1);
            }
            .at-agency-settings-shell .module-card.active {
                border-color: #a4de6c;
            }
            .at-agency-settings-shell .module-card.unavailable {
                border-color: #ffcccb;
            }
            .at-agency-settings-shell .module-header {
                display: flex;
                align-items: flex-start;
                gap: 12px;
                margin-bottom: 10px;
            }
            .at-agency-settings-shell .module-header input[type="checkbox"] {
                margin-top: 3px;
                width: 18px;
                height: 18px;
                cursor: pointer;
            }
            .at-agency-settings-shell .module-title {
                flex: 1;
            }
            .at-agency-settings-shell .module-title strong {
                font-size: 14px;
                color: #1d2327;
            }
            .at-agency-settings-shell .status-badge {
                padding: 2px 8px;
                border-radius: 3px;
                font-size: 11px;
                font-weight: bold;
                margin-left: 5px;
            }
            .at-agency-settings-shell .status-badge.active {
                background: #a4de6c;
                color: #008a20;
            }
            .at-agency-settings-shell .status-badge.inactive {
                background: #e0e0e0;
                color: #666;
            }
            .at-agency-settings-shell .status-badge.unavailable {
                background: #ffeaa7;
                color: #d63638;
            }
            .at-agency-settings-shell .module-error {
                color: #d63638;
                font-size: 12px;
                margin-top: 5px;
            }
            .at-agency-settings-shell .module-actions {
                margin-top: 10px;
                display: flex;
                gap: 10px;
            }
        </style>
        <div class="wrap at-agency-manager-wrap at-agency-settings-shell">
            <?php settings_errors(); ?>
            <form method="post" action="options.php">
                <?php
                settings_fields('at_agency_manager_general');
                do_settings_sections('at_agency_manager_general');
                ?>
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('API Key', 'at-agency-manager'); ?></th>
                        <td>
                            <div class="api-key-wrapper">
                                <input type="text" 
                                       id="at_agency_manager_auth_key" 
                                       name="at_agency_manager_auth_key" 
                                       value="<?php echo esc_attr(get_option('at_agency_manager_auth_key')); ?>" 
                                       class="regular-text"
                                       readonly
                                       style="font-family: monospace;"
                                />
                                <button type="button"
                                        id="generate-api-key-btn"
                                        class="button button-secondary"
                                        data-nonce="<?php echo wp_create_nonce('at_agency_manager_nonce'); ?>">
                                    <?php _e('Generate New Key', 'at-agency-manager'); ?>
                                </button>
                                <button type="button"
                                        id="copy-api-key-btn"
                                        class="button button-secondary">
                                    <?php _e('Copy', 'at-agency-manager'); ?>
                                </button>
                            </div>
                            <p class="description">
                                <?php _e('This key is required to authenticate API requests. Use the header: X-AT-Agency-Manager-Key', 'at-agency-manager'); ?>
                            </p>
                            <p class="description">
                                <a href="<?php echo admin_url('admin.php?page=at-agency-manager-api-docs'); ?>">
                                    <?php _e('View API Documentation', 'at-agency-manager'); ?>
                                </a>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Site Type', 'at-agency-manager'); ?></th>
                        <td>
                            <?php 
                            $current_env = AT_Agency_Manager_Environment::get_environment_type();
                            $is_defined_constant = defined('WP_ENVIRONMENT_TYPE');
                            ?>
                            <input type="text" 
                                   value="<?php echo esc_attr(ucfirst($current_env)); ?>" 
                                   class="regular-text" 
                                   readonly 
                                   disabled
                                   style="background-color: #f0f0f1; color: #666;"
                            />
                            <p class="description">
                                <?php 
                                if ($is_defined_constant) {
                                    printf(
                                        __('Environment is defined by %s constant in wp-config.php.', 'at-agency-manager'),
                                        '<code>WP_ENVIRONMENT_TYPE</code>'
                                    );
                                } else {
                                    _e('Environment is determined by WordPress system configuration.', 'at-agency-manager');
                                }
                                ?>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Notifications', 'at-agency-manager'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" 
                                       name="at_agency_manager_notifications[plugins]" 
                                       value="1" 
                                       <?php checked(get_option('at_agency_manager_notifications')['plugins'] ?? false); ?>
                                />
                                <?php _e('Plugin Updates', 'at-agency-manager'); ?>
                            </label><br>
                            <label>
                                <input type="checkbox" 
                                       name="at_agency_manager_notifications[core]" 
                                       value="1" 
                                       <?php checked(get_option('at_agency_manager_notifications')['core'] ?? false); ?>
                                />
                                <?php _e('WordPress Core Updates', 'at-agency-manager'); ?>
                            </label><br>
                            <label>
                                <input type="checkbox" 
                                       name="at_agency_manager_notifications[security]" 
                                       value="1" 
                                       <?php checked(get_option('at_agency_manager_notifications')['security'] ?? false); ?>
                                />
                                <?php _e('Security Alerts', 'at-agency-manager'); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('File Logging', 'at-agency-manager'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" 
                                       name="at_agency_manager_enable_file_logging" 
                                       value="1" 
                                       <?php checked(get_option('at_agency_manager_enable_file_logging'), 1); ?>
                                />
                                <?php _e('Enable logging to file', 'at-agency-manager'); ?>
                            </label>
                            <p class="description">
                                <?php _e('Logs will be saved to wp-content/uploads/at-agency-manager-logs/. Files are rotated daily and limited to 10MB.', 'at-agency-manager'); ?>
                            </p>
                        </td>
                    </tr>
                    <tr>
                         <th scope="row">
                             <?php _e('Modules', 'at-agency-manager'); ?>
                             <p class="description" style="font-weight: normal; margin-top: 5px;">
                                 <?php _e('Enable or disable modules below. Active modules will show detailed status information.', 'at-agency-manager'); ?>
                             </p>
                             <p class="description" style="font-weight: normal; margin-top: 5px; color: #008a20;">
                                 <?php _e('Suite Core is always active. Even if all modules are disabled, this plugin remains the core runtime for the ecosystem.', 'at-agency-manager'); ?>
                             </p>
                         </th>
                         <td>
                             <?php 
                             $modules = get_option('at_agency_manager_modules', []);
                             
                             // בדיקות dependencies
                             $elementor_installed = did_action('elementor/loaded');
                             
                             // הגדרת מודולים עם בדיקות dependencies
                             $module_configs = array(
                                 'acf_elementor_tag' => array(
                                     'label' => __('ACF Enhanced Elementor Tag', 'at-agency-manager'),
                                     'installed' => $elementor_installed,
                                     'error' => $elementor_installed ? '' : __('(Elementor is not installed or activated)', 'at-agency-manager'),
                                     'settings_url' => null
                                 ),
                                 'acf_local_json' => array(
                                     'label' => __('ACF Local JSON Manager', 'at-agency-manager'),
                                     'installed' => class_exists('ACF', false) || function_exists('acf_get_field_groups'),
                                     'error' => (class_exists('ACF', false) || function_exists('acf_get_field_groups')) ? '' : __('(ACF plugin not installed)', 'at-agency-manager'),
                                     'settings_url' => null
                                 ),
                                 'acf_copy_tool' => array(
                                     'label' => __('ACF Copy Fields Tool', 'at-agency-manager'),
                                     'installed' => true,
                                     'error' => '',
                                     'settings_url' => null
                                 ),
                                 'site_health' => array(
                                     'label' => __('Site Health Panel', 'at-agency-manager'),
                                     'installed' => true,
                                     'error' => '',
                                     'settings_url' => admin_url('admin.php?page=at-agency-manager&tab=dashboard')
                                 ),
                                 'hide_login' => array(
                                     'label' => __('Custom Login URL (Hide wp-login.php)', 'at-agency-manager'),
                                     'installed' => true,
                                     'error' => '',
                                     'settings_url' => null
                                 ),
                                 'protected_files' => array(
                                     'label' => __('Protected Files (Logged-in access only)', 'at-agency-manager'),
                                     'installed' => true,
                                     'error' => '',
                                     'settings_url' => admin_url('admin.php?page=at-protected-files')
                                 ),
                                 'activity_log' => array(
                                     'label' => __('Activity Log', 'at-agency-manager'),
                                     'installed' => true,
                                     'error' => '',
                                     'settings_url' => null
                                 ),
                                 'email_log' => array(
                                     'label' => __('Email Log', 'at-agency-manager'),
                                     'installed' => true,
                                     'error' => '',
                                     'settings_url' => null
                                 ),
                                 'backup' => array(
                                     'label' => __('Site Backup (Google Drive)', 'at-agency-manager'),
                                     'installed' => true,
                                     'error' => '',
                                     'settings_url' => admin_url('admin.php?page=at-agency-manager-backup')
                                 ),
                                 's3_media_sync' => array(
                                     'label' => __('S3 Media Sync (Amazon S3)', 'at-agency-manager'),
                                     'installed' => class_exists('Aws\\S3\\S3Client'),
                                     'error' => class_exists('Aws\\S3\\S3Client') ? '' : __('(AWS SDK not installed)', 'at-agency-manager'),
                                     'settings_url' => admin_url('admin.php?page=s3-media-sync-settings')
                                 ),
                                 'newrelic_monitoring' => array(
                                     'label' => __('New Relic Monitoring', 'at-agency-manager'),
                                     'installed' => extension_loaded('newrelic'),
                                     'error' => extension_loaded('newrelic') ? '' : __('(New Relic PHP extension not installed)', 'at-agency-manager'),
                                     'settings_url' => admin_url('admin.php?page=at-agency-manager-newrelic')
                                 ),
                                 'page_ordering' => array(
                                     'label' => __('Page Ordering (Drag & Drop)', 'at-agency-manager'),
                                     'installed' => true,
                                     'error' => '',
                                     'settings_url' => admin_url('admin.php?page=at-page-ordering-settings')
                                 ),
                                 'url_shortener' => array(
                                     'label' => __('URL Shortener', 'at-agency-manager'),
                                     'installed' => true,
                                     'error' => '',
                                     'settings_url' => admin_url('admin.php?page=at-short-links')
                                 ),
                                 'gf_autofill' => array(
                                     'label' => __('Gravity Forms Autofill', 'at-agency-manager'),
                                     'installed' => class_exists('GFAPI'),
                                     'error' => class_exists('GFAPI') ? '' : __('(Gravity Forms not installed)', 'at-agency-manager'),
                                     'settings_url' => null
                                 ),
                             );
                             ?>
                             <div class="modules-grid">
                             <?php foreach ($module_configs as $module_key => $config):
                                 $is_enabled = !empty($modules[$module_key]);
                                 $is_installed = $config['installed'];
                                 
                                 // קביעת מחלקות CSS
                                 $card_class = 'module-card';
                                 if (!$is_installed) {
                                     $card_class .= ' unavailable';
                                     $status_class = 'unavailable';
                                     $status_text = __('Unavailable', 'at-agency-manager');
                                 } elseif ($is_enabled) {
                                     $card_class .= ' active';
                                     $status_class = 'active';
                                     $status_text = __('Active', 'at-agency-manager');
                                 } else {
                                     $status_class = 'inactive';
                                     $status_text = __('Inactive', 'at-agency-manager');
                                 }
                             ?>
                                 <div class="<?php echo esc_attr($card_class); ?>">
                                     <div class="module-header">
                                     <input type="checkbox"
                                            name="at_agency_manager_modules[<?php echo esc_attr($module_key); ?>]"
                                            value="1"
                                            <?php checked($is_enabled && $is_installed); ?>
                                            <?php disabled(!$is_installed); ?>
                                     />
                                         <div class="module-title">
                                         <strong><?php echo esc_html($config['label']); ?></strong>
                                             <span class="status-badge <?php echo esc_attr($status_class); ?>"><?php echo esc_html($status_text); ?></span>
                                         <?php if (!$is_installed && !empty($config['error'])): ?>
                                                 <div class="module-error"><?php echo esc_html($config['error']); ?></div>
                                         <?php endif; ?>
                                         </div>
                                     </div>
                                     <?php if ($is_enabled && $is_installed && !empty($config['settings_url'])): ?>
                                         <div class="module-actions">
                                         <a href="<?php echo esc_url($config['settings_url']); ?>"
                                                class="button button-small">
                                             <?php _e('Settings', 'at-agency-manager'); ?>
                                         </a>
                                         </div>
                                     <?php endif; ?>
                                 </div>
                             <?php endforeach; ?>
                             </div>
                         </td>
                     </tr>
                    <tr>
                         <th scope="row"><?php _e('Custom Login URL', 'at-agency-manager'); ?></th>
                         <td>
                             <input type="text" name="at_custom_login_slug" value="<?php echo esc_attr(get_option('at_custom_login_slug', 'login')); ?>" class="regular-text" />
                             <p class="description"><?php _e('Change the default wp-login.php slug. Example: my-login', 'at-agency-manager'); ?></p>
                         </td>
                     </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // Generate API Key
            $('#generate-api-key-btn').on('click', function() {
                var button = $(this);
                var nonce = button.data('nonce');
                var originalText = button.text();
                
                button.prop('disabled', true).text('<?php _e('Generating...', 'at-agency-manager'); ?>');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'at_generate_api_key',
                        nonce: nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#at_agency_manager_auth_key').val(response.data.key);
                            alert('<?php _e('New API key generated successfully!', 'at-agency-manager'); ?>');
                        } else {
                            alert('<?php _e('Error: ', 'at-agency-manager'); ?>' + (response.data.message || '<?php _e('Unknown error', 'at-agency-manager'); ?>'));
                        }
                        button.prop('disabled', false).text(originalText);
                    },
                    error: function() {
                        alert('<?php _e('Error generating API key. Please try again.', 'at-agency-manager'); ?>');
                        button.prop('disabled', false).text(originalText);
                    }
                });
            });
            
            // Copy API Key
            $('#copy-api-key-btn').on('click', function() {
                var keyInput = $('#at_agency_manager_auth_key');
                keyInput.select();
                document.execCommand('copy');
                
                var button = $(this);
                var originalText = button.text();
                button.text('<?php _e('Copied!', 'at-agency-manager'); ?>');
                setTimeout(function() {
                    button.text(originalText);
                }, 2000);
            });
        });
        </script>
        <?php
    }

    /**
     * הצגת דף הגדרות הדוא"ל
     */
    public function render_email_settings() {
        // בדיקת הרשאות
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'at-agency-manager'));
        }
        
        ?>
        <div class="wrap at-agency-manager-wrap">
            <h1><?php _e('Email Settings', 'at-agency-manager'); ?></h1>
            <?php $active_mailer = $this->get_active_mailer_mode(); ?>
            <div class="notice notice-info" style="margin: 16px 0; padding: 12px;">
                <p style="margin:0 0 4px;"><strong><?php _e('Current Sending Method', 'at-agency-manager'); ?>:</strong> <?php echo esc_html($active_mailer['label']); ?></p>
                <?php if (!empty($active_mailer['details'])): ?>
                    <p style="margin:0; color:#50575e;"><?php echo esc_html($active_mailer['details']); ?></p>
                <?php endif; ?>
            </div>
            <?php settings_errors(); ?>
            <form method="post" action="options.php">
                <?php
                settings_fields('at_agency_manager_email');
                do_settings_sections('at_agency_manager_email');
                ?>
                
                <h2><?php _e('Email Provider', 'at-agency-manager'); ?></h2>
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('Use SendGrid', 'at-agency-manager'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" 
                                       name="at_use_sendgrid" 
                                       value="1" 
                                       <?php checked(get_option('at_use_sendgrid'), 1); ?>
                                />
                                <?php _e('Use SendGrid for email delivery', 'at-agency-manager'); ?>
                            </label>
                        </td>
                    </tr>
                </table>
                
                <div id="custom-smtp-settings" style="<?php echo get_option('at_use_sendgrid') ? 'display:none;' : ''; ?>">
                    <h2><?php _e('Custom SMTP Settings', 'at-agency-manager'); ?></h2>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php _e('SMTP Host', 'at-agency-manager'); ?></th>
                            <td>
                                <input type="text" 
                                       name="at_agency_manager_smtp_host" 
                                       value="<?php echo esc_attr(get_option('at_agency_manager_smtp_host')); ?>" 
                                       class="regular-text"
                                />
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('SMTP Port', 'at-agency-manager'); ?></th>
                            <td>
                                <input type="number" 
                                       name="at_agency_manager_smtp_port" 
                                       value="<?php echo esc_attr(get_option('at_agency_manager_smtp_port')); ?>" 
                                       class="small-text"
                                />
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('SMTP Username', 'at-agency-manager'); ?></th>
                            <td>
                                <input type="text" 
                                       name="at_agency_manager_smtp_user" 
                                       value="<?php echo esc_attr(get_option('at_agency_manager_smtp_user')); ?>" 
                                       class="regular-text"
                                />
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('SMTP Password', 'at-agency-manager'); ?></th>
                            <td>
                                <input type="password" 
                                       name="at_agency_manager_smtp_pass" 
                                       value="<?php echo esc_attr(get_option('at_agency_manager_smtp_pass')); ?>" 
                                       class="regular-text"
                                />
                            </td>
                        </tr>
                    </table>
                </div>
                
                <h2><?php _e('Email Settings', 'at-agency-manager'); ?></h2>
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('From Name', 'at-agency-manager'); ?></th>
                        <td>
                            <input type="text" 
                                   name="at_sender_email_name" 
                                   value="<?php echo esc_attr(get_option('at_sender_email_name')); ?>" 
                                   class="regular-text"
                            />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('From Email', 'at-agency-manager'); ?></th>
                        <td>
                            <input type="email" 
                                   name="at_sender_email_address" 
                                   value="<?php echo esc_attr(get_option('at_sender_email_address')); ?>" 
                                   class="regular-text"
                            />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Default Admin Email', 'at-agency-manager'); ?></th>
                        <td>
                            <input type="email" 
                                   name="at_sent_to_admin_default" 
                                   value="<?php echo esc_attr(get_option('at_sent_to_admin_default')); ?>" 
                                   class="regular-text"
                            />
                            <p class="description"><?php _e('Used for forms and notifications in Gravity Forms', 'at-agency-manager'); ?></p>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button(); ?>
                
                <div class="card">
                    <h2><?php _e('Test Email Settings', 'at-agency-manager'); ?></h2>
                    <p><?php _e('Send a test email to verify your settings are working correctly.', 'at-agency-manager'); ?></p>
                    <button type="button" id="at-test-email" class="button button-secondary">
                        <?php _e('Send Test Email', 'at-agency-manager'); ?>
                    </button>
                    <span id="at-test-email-result"></span>
                </div>
            </form>

            <?php $this->render_email_logs_inline(); ?>
        </div>
        
        <script>
            jQuery(document).ready(function($) {
                $('input[name="at_use_sendgrid"]').change(function() {
                    if ($(this).is(':checked')) {
                        $('#custom-smtp-settings').hide();
                    } else {
                        $('#custom-smtp-settings').show();
                    }
                });
                
                $('#at-test-email').click(function() {
                    var button = $(this);
                    var result = $('#at-test-email-result');
                    
                    button.prop('disabled', true);
                    result.html('<?php _e('Sending...', 'at-agency-manager'); ?>');
                    
                    $.ajax({
                        url: '<?php echo get_rest_url(null, 'at-agency-manager/v1/test-email'); ?>',
                        type: 'POST',
                        beforeSend: function(xhr) {
                            xhr.setRequestHeader('X-AT-Agency-Manager-Key', '<?php echo get_option('at_agency_manager_auth_key'); ?>');
                        },
                        success: function(response) {
                            if (response.success) {
                                result.html('<span style="color:green"><?php _e('Email sent successfully!', 'at-agency-manager'); ?></span>');
                            } else {
                                result.html('<span style="color:red"><?php _e('Failed: ', 'at-agency-manager'); ?>' + response.message + '</span>');
                            }
                            button.prop('disabled', false);
                        },
                        error: function(error) {
                            result.html('<span style="color:red"><?php _e('Error: could not send test email', 'at-agency-manager'); ?></span>');
                            button.prop('disabled', false);
                        }
                    });
                });
            });
        </script>
        <?php
    }

    /**
     * הצגת עמוד הלוגים המאוחד
     */
    public function render_unified_logs() {
        require_once AT_AGENCY_MANAGER_PATH . 'includes/class-unified-logs.php';
        $unified_logs = new AT_Agency_Manager_Unified_Logs($this->logger);
        $unified_logs->render();
    }

    /**
     * Render Site Health as part of main plugin page.
     *
     * @return void
     */
    private function render_health_tab() {
        AT_Agency_Manager_Health_Dashboard::render(array('embedded' => true));
    }
    
    /**
     * הפניה לעמוד הלוגים המאוחד עם טאב Activity
     */
    public function redirect_to_unified_logs_activity() {
        $this->redirect_to_unified_logs_tab('activity');
    }
    
    /**
     * הפניה לעמוד הלוגים המאוחד עם טאב Email
     */
    public function redirect_to_unified_logs_email() {
        $this->redirect_to_unified_logs_tab('email');
    }

    /**
     * Redirect legacy Site Health page to main plugin health tab.
     *
     * @return void
     */
    public function redirect_to_main_health_tab() {
        $url = admin_url('admin.php?page=at-agency-manager&tab=dashboard');
        if (!headers_sent()) {
            wp_safe_redirect($url);
            exit;
        }

        echo '<script>window.location.href=' . wp_json_encode($url) . ';</script>';
        echo '<noscript><meta http-equiv="refresh" content="0;url=' . esc_url($url) . '"></noscript>';
        exit;
    }

    /**
     * Redirect legacy log routes to unified logs with robust fallback.
     *
     * @param string $tab
     * @return void
     */
    private function redirect_to_unified_logs_tab($tab) {
        $tab = sanitize_key($tab);
        $url = admin_url('admin.php?page=at-agency-manager-logs&log_type=' . $tab);

        if (!headers_sent()) {
            wp_safe_redirect($url);
            exit;
        }

        echo '<script>window.location.href=' . wp_json_encode($url) . ';</script>';
        echo '<noscript><meta http-equiv="refresh" content="0;url=' . esc_url($url) . '"></noscript>';
        exit;
    }

    /**
     * Handle legacy log routes even when hidden submenu callbacks are bypassed.
     *
     * @return void
     */
    public function handle_legacy_log_routes() {
        if (!is_admin() || !current_user_can('manage_options')) {
            return;
        }

        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

        if ('at-activity-log' === $page) {
            $this->redirect_to_unified_logs_activity();
        }

        if ('at-email-log' === $page) {
            $this->redirect_to_unified_logs_email();
        }
    }

    /**
     * Handle legacy site health route.
     *
     * @return void
     */
    public function handle_legacy_site_health_route() {
        if (!is_admin() || !current_user_can('manage_options')) {
            return;
        }

        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        if ('at-site-health' === $page) {
            $this->redirect_to_main_health_tab();
        }
    }

    /**
     * Resolve currently active outbound email mode.
     *
     * @return array{label:string,details:string}
     */
    private function get_active_mailer_mode() {
        $smtp_host = trim((string) get_option('at_agency_manager_smtp_host', ''));
        $smtp_port = (string) get_option('at_agency_manager_smtp_port', '587');
        $use_sendgrid = (bool) get_option('at_use_sendgrid');
        $env_type = AT_Agency_Manager_Environment::get_environment_type();
        $is_dev = in_array($env_type, array('local', 'development'), true) || get_option('at_agency_manager_site_type', 'production') === 'development';

        if (!$use_sendgrid && '' === $smtp_host) {
            return array(
                'label' => __('WordPress Default (PHP mail)', 'at-agency-manager'),
                'details' => __('No custom SMTP provider is active.', 'at-agency-manager'),
            );
        }

        if ($is_dev) {
            $dev_host = (string) get_option('at_agency_manager_dev_smtp_host', 'smtp.mailtrap.io');
            $dev_port = (string) get_option('at_agency_manager_dev_smtp_port', '2525');
            return array(
                'label' => __('Development SMTP (Mailtrap)', 'at-agency-manager'),
                'details' => sprintf(__('Host: %s:%s', 'at-agency-manager'), $dev_host, $dev_port),
            );
        }

        if ('' !== $smtp_host) {
            return array(
                'label' => __('Custom SMTP', 'at-agency-manager'),
                'details' => sprintf(__('Host: %s:%s', 'at-agency-manager'), $smtp_host, $smtp_port),
            );
        }

        return array(
            'label' => __('SendGrid SMTP', 'at-agency-manager'),
            'details' => __('Host: smtp.sendgrid.net:25', 'at-agency-manager'),
        );
    }

    /**
     * Inline email logs for SMTP settings screen.
     *
     * @return void
     */
    private function render_email_logs_inline() {
        global $wpdb;

        if (!class_exists('AT_Email_Log')) {
            echo '<div class="card" style="margin-top:20px;"><h2>' . esc_html__('Email Logs', 'at-agency-manager') . '</h2><p>' . esc_html__('Enable the Email Log module to view logs here.', 'at-agency-manager') . '</p></div>';
            return;
        }

        $table_name = $wpdb->prefix . 'at_email_log';
        $table_exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table_name));
        if ($table_exists !== $table_name) {
            echo '<div class="card" style="margin-top:20px;"><h2>' . esc_html__('Email Logs', 'at-agency-manager') . '</h2><p>' . esc_html__('Email logs table was not found yet.', 'at-agency-manager') . '</p></div>';
            return;
        }

        $logs = $wpdb->get_results("SELECT id, time, email_to, subject, status FROM {$table_name} ORDER BY id DESC LIMIT 20");
        ?>
        <div class="card" style="margin-top: 20px;">
            <h2><?php _e('Recent Email Logs', 'at-agency-manager'); ?></h2>
            <p>
                <a class="button button-secondary" href="<?php echo esc_url(admin_url('admin.php?page=at-agency-manager-logs&log_type=email')); ?>">
                    <?php _e('Open Full Email Logs', 'at-agency-manager'); ?>
                </a>
            </p>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('Time', 'at-agency-manager'); ?></th>
                        <th><?php _e('To', 'at-agency-manager'); ?></th>
                        <th><?php _e('Subject', 'at-agency-manager'); ?></th>
                        <th><?php _e('Status', 'at-agency-manager'); ?></th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($logs)) : ?>
                    <tr>
                        <td colspan="4"><?php _e('No email logs found.', 'at-agency-manager'); ?></td>
                    </tr>
                <?php else : ?>
                    <?php foreach ($logs as $log) : ?>
                        <tr>
                            <td><?php echo esc_html($log->time); ?></td>
                            <td><?php echo esc_html($log->email_to); ?></td>
                            <td><?php echo esc_html($log->subject); ?></td>
                            <td><?php echo esc_html(ucfirst((string) $log->status)); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    /**
     * בדיקה ויצירת API key אם לא קיים
     */
    private function ensure_api_key_exists() {
        $existing_key = get_option('at_agency_manager_auth_key');
        if (empty($existing_key)) {
            $new_key = $this->generate_api_key();
            update_option('at_agency_manager_auth_key', $new_key);
        }
    }

    /**
     * יצירת מפתח API חדש
     * 
     * @return string מפתח API חדש (64 תווים hex)
     */
    private function generate_api_key() {
        return bin2hex(random_bytes(32)); // 64 תווים hex
    }

    /**
     * AJAX handler ליצירת מפתח API חדש
     */
    public function ajax_generate_api_key() {
        check_ajax_referer('at_agency_manager_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Insufficient permissions', 'at-agency-manager')));
        }
        
        $new_key = $this->generate_api_key();
        update_option('at_agency_manager_auth_key', $new_key);
        
        wp_send_json_success(array('key' => $new_key));
    }

    /**
     * הצגת דף דוקומנטציה API
     */
    public function render_api_documentation() {
        // בדיקת הרשאות
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'at-agency-manager'));
        }
        
        $api_key = get_option('at_agency_manager_auth_key');
        $base_url = get_site_url();
        $api_base = $base_url . '/wp-json/at-agency-manager/v1';
        $postman_collection_url = AT_AGENCY_MANAGER_URL . 'docs/api/at-agency-manager.postman_collection.json';
        
        ?>
        <div class="wrap at-agency-manager-wrap">
            <h1><?php _e('API Documentation', 'at-agency-manager'); ?></h1>
            
            <div class="card" style="max-width: 1200px;">
                <h2><?php _e('Quick Start', 'at-agency-manager'); ?></h2>
                <p><?php _e('All API requests require authentication using the API key in the header:', 'at-agency-manager'); ?></p>
                <pre style="background: #f5f5f5; padding: 15px; border-radius: 4px; overflow-x: auto;"><code>X-AT-Agency-Manager-Key: <?php echo esc_html($api_key); ?></code></pre>
                
                <p><strong><?php _e('Base URL:', 'at-agency-manager'); ?></strong> <code><?php echo esc_html($api_base); ?></code></p>
                
                <p>
                    <a href="<?php echo esc_url($postman_collection_url); ?>" 
                       class="button button-primary" 
                       download="at-agency-manager-api.postman_collection.json">
                        <?php _e('Download Postman Collection', 'at-agency-manager'); ?>
                    </a>
                </p>
            </div>

            <div class="card" style="max-width: 1200px; margin-top: 20px;">
                <h2><?php _e('Available Endpoints', 'at-agency-manager'); ?></h2>
                
                <h3><?php _e('Site Information', 'at-agency-manager'); ?></h3>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php _e('Method', 'at-agency-manager'); ?></th>
                            <th><?php _e('Endpoint', 'at-agency-manager'); ?></th>
                            <th><?php _e('Description', 'at-agency-manager'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><code>GET</code></td>
                            <td><code>/site-info</code></td>
                            <td><?php _e('Get basic site information (version, name, URL, admin email)', 'at-agency-manager'); ?></td>
                        </tr>
                        <tr>
                            <td><code>GET</code></td>
                            <td><code>/plugins</code></td>
                            <td><?php _e('Get list of installed plugins with versions', 'at-agency-manager'); ?></td>
                        </tr>
                        <tr>
                            <td><code>GET</code></td>
                            <td><code>/users</code></td>
                            <td><?php _e('Get list of users (admin users only)', 'at-agency-manager'); ?></td>
                        </tr>
                        <tr>
                            <td><code>GET</code></td>
                            <td><code>/health</code></td>
                            <td><?php _e('Get site health status and diagnostics', 'at-agency-manager'); ?></td>
                        </tr>
                    </tbody>
                </table>

                <?php if (AT_Agency_Manager_Environment::is_remote_api_allowed()): ?>
                <h3 style="margin-top: 30px;"><?php _e('Remote API Endpoints', 'at-agency-manager'); ?></h3>
                <p class="description"><?php _e('These endpoints are only available when Remote API is enabled in development/local environments.', 'at-agency-manager'); ?></p>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php _e('Method', 'at-agency-manager'); ?></th>
                            <th><?php _e('Endpoint', 'at-agency-manager'); ?></th>
                            <th><?php _e('Description', 'at-agency-manager'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><code>GET</code></td>
                            <td><code>/logs</code></td>
                            <td><?php _e('Get plugin activity logs', 'at-agency-manager'); ?></td>
                        </tr>
                        <tr>
                            <td><code>POST</code></td>
                            <td><code>/test-email</code></td>
                            <td><?php _e('Send a test email', 'at-agency-manager'); ?></td>
                        </tr>
                        <?php if (AT_Agency_Manager_Environment::is_development()): ?>
                        <tr>
                            <td><code>GET</code></td>
                            <td><code>/development-info</code></td>
                            <td><?php _e('Get development environment information', 'at-agency-manager'); ?></td>
                        </tr>
                        <tr>
                            <td><code>GET</code></td>
                            <td><code>/debug-logs</code></td>
                            <td><?php _e('Get debug logs (development only)', 'at-agency-manager'); ?></td>
                        </tr>
                        <tr>
                            <td><code>GET</code></td>
                            <td><code>/environment-status</code></td>
                            <td><?php _e('Get environment status and configuration', 'at-agency-manager'); ?></td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <?php else: ?>
                <div class="notice notice-warning inline" style="margin: 20px 0;">
                    <p><?php _e('Remote API endpoints are disabled. Enable "Remote API" in Settings to access these endpoints (development/local environments only).', 'at-agency-manager'); ?></p>
                </div>
                <?php endif; ?>
            </div>

            <div class="card" style="max-width: 1200px; margin-top: 20px;">
                <h2><?php _e('Example Requests', 'at-agency-manager'); ?></h2>
                
                <h3><?php _e('cURL Example', 'at-agency-manager'); ?></h3>
                <pre style="background: #f5f5f5; padding: 15px; border-radius: 4px; overflow-x: auto;"><code>curl -X GET "<?php echo esc_html($api_base); ?>/site-info" \
  -H "X-AT-Agency-Manager-Key: <?php echo esc_html($api_key); ?>"</code></pre>

                <h3><?php _e('JavaScript (Fetch) Example', 'at-agency-manager'); ?></h3>
                <pre style="background: #f5f5f5; padding: 15px; border-radius: 4px; overflow-x: auto;"><code>fetch('<?php echo esc_html($api_base); ?>/site-info', {
  method: 'GET',
  headers: {
    'X-AT-Agency-Manager-Key': '<?php echo esc_html($api_key); ?>'
  }
})
.then(response => response.json())
.then(data => console.log(data));</code></pre>

                <h3><?php _e('PHP (WP_Http) Example', 'at-agency-manager'); ?></h3>
                <pre style="background: #f5f5f5; padding: 15px; border-radius: 4px; overflow-x: auto;"><code>$response = wp_remote_get('<?php echo esc_html($api_base); ?>/site-info', [
    'headers' => [
        'X-AT-Agency-Manager-Key' => '<?php echo esc_html($api_key); ?>'
    ]
]);

$body = wp_remote_retrieve_body($response);
$data = json_decode($body, true);</code></pre>
            </div>

            <div class="card" style="max-width: 1200px; margin-top: 20px;">
                <h2><?php _e('Response Format', 'at-agency-manager'); ?></h2>
                <p><?php _e('All successful responses return JSON with the following structure:', 'at-agency-manager'); ?></p>
                <pre style="background: #f5f5f5; padding: 15px; border-radius: 4px; overflow-x: auto;"><code>{
  "version": "6.4",
  "name": "Site Name",
  "url": "https://example.com",
  "admin_email": "admin@example.com",
  ...
}</code></pre>
                
                <p><?php _e('Error responses:', 'at-agency-manager'); ?></p>
                <pre style="background: #f5f5f5; padding: 15px; border-radius: 4px; overflow-x: auto;"><code>{
  "code": "rest_forbidden",
  "message": "Remote API is not allowed in this environment.",
  "data": {
    "status": 403
  }
}</code></pre>
            </div>

            <div class="card" style="max-width: 1200px; margin-top: 20px;">
                <h2><?php _e('Security Notes', 'at-agency-manager'); ?></h2>
                <ul>
                    <li><?php _e('API key is required for all requests', 'at-agency-manager'); ?></li>
                    <li><?php _e('Remote API endpoints are only available in development/local environments', 'at-agency-manager'); ?></li>
                    <li><?php _e('Development endpoints require development environment or admin authentication', 'at-agency-manager'); ?></li>
                    <li><?php _e('Keep your API key secure and never expose it in client-side code', 'at-agency-manager'); ?></li>
                    <li><?php _e('Regenerate your API key if it\'s compromised', 'at-agency-manager'); ?></li>
                </ul>
            </div>
        </div>
        <?php
    }
    
    /**
     * הצגת טאב About
     */
    private function render_about_tab() {
        $this->render_suite_tab();
    }
    
    /**
     * AJAX handler למחיקת לוגים
     */
    public function ajax_clear_logs() {
        check_ajax_referer('at_clear_logs', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions', 'at-agency-manager'));
        }
        
        $log_type = isset($_POST['log_type']) ? sanitize_text_field($_POST['log_type']) : 'system';
        global $wpdb;
        
        switch ($log_type) {
            case 'system':
                $table_name = $wpdb->prefix . 'at_agency_manager_logs';
                $result = $wpdb->query("TRUNCATE TABLE {$table_name}");
                break;
                
            case 'activity':
                if (!class_exists('AT_Activity_Log')) {
                    wp_send_json_error(__('Activity Log module is not enabled', 'at-agency-manager'));
                }
                $table_name = $wpdb->prefix . 'at_activity_log';
                $result = $wpdb->query("TRUNCATE TABLE {$table_name}");
                break;
                
            case 'email':
                if (!class_exists('AT_Email_Log')) {
                    wp_send_json_error(__('Email Log module is not enabled', 'at-agency-manager'));
                }
                $table_name = $wpdb->prefix . 'at_email_log';
                $result = $wpdb->query("TRUNCATE TABLE {$table_name}");
                break;
                
            default:
                wp_send_json_error(__('Invalid log type', 'at-agency-manager'));
        }
        
        if ($result !== false) {
            wp_send_json_success(__('All logs cleared successfully', 'at-agency-manager'));
        } else {
            wp_send_json_error(__('Failed to clear logs', 'at-agency-manager'));
        }
    }
    
    /**
     * AJAX handler לשליחה חוזרת של מייל
     */
    public function ajax_resend_email() {
        check_ajax_referer('at_resend_email', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions', 'at-agency-manager'));
        }
        
        $log_id = isset($_POST['log_id']) ? intval($_POST['log_id']) : 0;
        $recipient = isset($_POST['recipient']) ? sanitize_email($_POST['recipient']) : '';
        
        if (!$log_id) {
            wp_send_json_error(__('Invalid log ID', 'at-agency-manager'));
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'at_email_log';
        $email = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} WHERE id = %d", $log_id));
        
        if (!$email) {
            wp_send_json_error(__('Email log not found', 'at-agency-manager'));
        }
        
        // שימוש בנמען החדש אם סופק, אחרת בנמען המקורי
        $to = $recipient ?: $email->email_to;
        
        // שליחת המייל
        $headers = $email->headers ? explode("\n", $email->headers) : array();
        
        // הסרת כותרות בעייתיות לשליחה חוזרת
        $clean_headers = array();
        foreach ($headers as $header) {
            if (stripos($header, 'Message-ID:') === false && stripos($header, 'Date:') === false) {
                $clean_headers[] = $header;
            }
        }
        
        $sent = wp_mail($to, $email->subject, $email->message, $clean_headers);
        
        if ($sent) {
            wp_send_json_success(__('Email resent successfully', 'at-agency-manager'));
        } else {
            wp_send_json_error(__('Failed to resend email', 'at-agency-manager'));
        }
    }
    
    /**
     * Export logs to CSV
     */
    public function export_logs() {
        check_admin_referer('at_export_logs', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Insufficient permissions', 'at-agency-manager'));
        }
        
        $log_type = isset($_GET['log_type']) ? sanitize_text_field($_GET['log_type']) : 'system';
        global $wpdb;
        
        $filename = 'at-agency-logs-' . $log_type . '-' . date('Y-m-d') . '.csv';
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $filename);
        header('Pragma: no-cache');
        header('Expires: 0');
        
        $output = fopen('php://output', 'w');
        
        // BOM for UTF-8
        fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
        
        switch ($log_type) {
            case 'system':
                $table_name = $wpdb->prefix . 'at_agency_manager_logs';
                $logs = $wpdb->get_results("SELECT * FROM {$table_name} ORDER BY created_at DESC");
                
                fputcsv($output, array(
                    __('Time', 'at-agency-manager'),
                    __('Type', 'at-agency-manager'),
                    __('Message', 'at-agency-manager'),
                    __('Status', 'at-agency-manager'),
                    __('User ID', 'at-agency-manager'),
                    __('IP Address', 'at-agency-manager')
                ));
                
                foreach ($logs as $log) {
                    fputcsv($output, array(
                        $log->created_at,
                        $log->type,
                        $log->message,
                        $log->status,
                        $log->user_id,
                        $log->ip_address
                    ));
                }
                break;
                
            case 'activity':
                if (!class_exists('AT_Activity_Log')) {
                    wp_die(__('Activity Log module is not enabled', 'at-agency-manager'));
                }
                $table_name = $wpdb->prefix . 'at_activity_log';
                $logs = $wpdb->get_results("SELECT * FROM {$table_name} ORDER BY created_at DESC");
                
                fputcsv($output, array(
                    __('Date & Time', 'at-agency-manager'),
                    __('User', 'at-agency-manager'),
                    __('Action', 'at-agency-manager'),
                    __('Object Type', 'at-agency-manager'),
                    __('Object', 'at-agency-manager'),
                    __('IP Address', 'at-agency-manager')
                ));
                
                foreach ($logs as $log) {
                    fputcsv($output, array(
                        $log->created_at,
                        $log->user_name,
                        $log->action,
                        $log->object_type,
                        $log->object_name,
                        $log->ip_address
                    ));
                }
                break;
                
            case 'email':
                if (!class_exists('AT_Email_Log')) {
                    wp_die(__('Email Log module is not enabled', 'at-agency-manager'));
                }
                $table_name = $wpdb->prefix . 'at_email_log';
                $logs = $wpdb->get_results("SELECT * FROM {$table_name} ORDER BY time DESC");
                
                fputcsv($output, array(
                    __('Time', 'at-agency-manager'),
                    __('To', 'at-agency-manager'),
                    __('Subject', 'at-agency-manager'),
                    __('Status', 'at-agency-manager'),
                    __('Error Message', 'at-agency-manager')
                ));
                
                foreach ($logs as $log) {
                    fputcsv($output, array(
                        $log->time,
                        $log->email_to,
                        $log->subject,
                        $log->status,
                        $log->error_message ?: ''
                    ));
                }
                break;
        }
        
        fclose($output);
        exit;
    }
}
