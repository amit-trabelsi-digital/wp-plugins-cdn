<?php
/**
 * מחלקה לטיפול בתרגומים
 * 
 * אחראית על טעינת קבצי תרגום ותמיכה בעברית
 */
class AT_Agency_Manager_i18n {

    /**
     * טעינת קבצי תרגום
     */
    public function load_plugin_textdomain() {
        $domain = 'at-agency-manager';
        $plugin_rel_path = dirname(dirname(plugin_basename(__FILE__))) . '/languages/';
        
        // טעינת תרגומים
        load_plugin_textdomain($domain, false, $plugin_rel_path);
        
        // אם השפה היא עברית, וודא שהתרגומים נטענו
        if (get_locale() === 'he_IL' || get_user_locale() === 'he_IL') {
            // טעינה מפורשת של קובץ התרגום העברי
            $mofile = AT_AGENCY_MANAGER_PATH . 'languages/' . $domain . '-he_IL.mo';
            if (file_exists($mofile)) {
                load_textdomain($domain, $mofile);
            }
        }
        
        // הוספת תמיכה ב-RTL
        add_action('admin_head', array($this, 'add_rtl_support'));
        add_action('wp_head', array($this, 'add_rtl_support'));
    }
    
    /**
     * הוספת תמיכה ב-RTL
     */
    public function add_rtl_support() {
        if (is_rtl()) {
            ?>
            <style>
                /* תמיכה מלאה ב-RTL לממשק הניהול */
                .at-agency-manager-wrap,
                .wrap[class*="at-"],
                #at-agency-manager-settings,
                .at-health-dashboard {
                    direction: rtl;
                }
                
                /* טבלאות */
                .at-agency-manager-wrap .form-table th,
                .at-agency-manager-wrap .wp-list-table th {
                    text-align: right;
                }
                
                .at-agency-manager-wrap .form-table td {
                    text-align: right;
                }
                
                /* טאבים - מיושרים לפי שפת ממשק הניהול (RTL/ LTR) */
                .at-agency-manager-wrap .nav-tab-wrapper {
                    direction: rtl;
                }
                
                /* כותרות */
                .at-agency-manager-wrap h1,
                .at-agency-manager-wrap h2,
                .at-agency-manager-wrap h3 {
                    text-align: right;
                }
                
                /* טפסים */
                .at-agency-manager-wrap input[type="text"],
                .at-agency-manager-wrap input[type="email"],
                .at-agency-manager-wrap input[type="password"],
                .at-agency-manager-wrap input[type="number"],
                .at-agency-manager-wrap textarea,
                .at-agency-manager-wrap select {
                    direction: rtl;
                    text-align: right;
                }
                
                /* תיאורים */
                .at-agency-manager-wrap .description,
                .at-agency-manager-wrap p.description {
                    text-align: right;
                }
                
                /* כרטיסים */
                .at-agency-manager-wrap .card {
                    direction: rtl;
                }
                
                .at-agency-manager-wrap .card h2,
                .at-agency-manager-wrap .card h3 {
                    text-align: right;
                }
                
                /* כפתורים */
                .at-agency-manager-wrap .button {
                    margin-left: 5px;
                    margin-right: 0;
                }
                
                /* רשימות */
                .at-agency-manager-wrap ul,
                .at-agency-manager-wrap ol {
                    padding-right: 20px;
                    padding-left: 0;
                }
                
                /* טבלאות רוחב */
                .at-agency-manager-wrap .wp-list-table.widefat th,
                .at-agency-manager-wrap .wp-list-table.widefat td {
                    text-align: right;
                }
                
                /* שדות מיוחדים - אימייל, טלפון, קוד */
                .at-agency-manager-wrap input[type="email"],
                .at-agency-manager-wrap input[type="tel"],
                .at-agency-manager-wrap input[type="number"],
                .at-agency-manager-wrap input[placeholder*="@"],
                .at-agency-manager-wrap input[placeholder*="0"] {
                    direction: ltr;
                    text-align: left;
                }
                
                /* תאריכים ושעות */
                .at-agency-manager-wrap input[type="date"],
                .at-agency-manager-wrap input[type="time"],
                .at-agency-manager-wrap input[type="datetime-local"] {
                    direction: ltr;
                }
                
                /* סטטוסים ותגים */
                .at-agency-manager-wrap .log-status,
                .at-agency-manager-wrap .status-badge {
                    margin-right: 5px;
                    margin-left: 0;
                }
                
                /* רווחים */
                .at-agency-manager-wrap .form-table th {
                    padding-right: 20px;
                    padding-left: 10px;
                }
                
                .at-agency-manager-wrap .form-table td {
                    padding-right: 10px;
                    padding-left: 20px;
                }
            </style>
            <?php
        }
    }
} 
