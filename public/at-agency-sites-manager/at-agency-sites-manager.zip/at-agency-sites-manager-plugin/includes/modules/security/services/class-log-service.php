<?php
namespace AT\AgencyManager\Modules\Security\Services;

/**
 * שירות לוגים למודול האבטחה
 */
class LogService {
    /**
     * מחזיר לוגים מהמערכת
     * @param int $limit כמות רשומות
     * @param string $level רמת לוג (error/info/warning וכו')
     * @return array
     */
    public function getLogs($limit = 50, $level = null) {
        global $wpdb;
        $table = $wpdb->prefix . 'at_agency_manager_logs';
        $query = "SELECT * FROM $table";
        $where = [];
        $params = [];
        if ($level) {
            $where[] = "level = %s";
            $params[] = $level;
        }
        if ($where) {
            $query .= ' WHERE ' . implode(' AND ', $where);
        }
        $query .= " ORDER BY created_at DESC LIMIT %d";
        $params[] = $limit;
        $prepared = $wpdb->prepare($query, ...$params);
        $results = $wpdb->get_results($prepared, ARRAY_A);
        return $results ?: [];
    }
} 