<?php
namespace AT\AgencyManager\Modules\Security\Services;

/**
 * שירות דיבאג למודול האבטחה
 */
class DebugService {
    /**
     * מחזיר מידע דיבאג בסיסי על האתר
     * @return array
     */
    public function getDebugData(): array {
        global $wpdb;
        return [
            'php_version' => phpversion(),
            'wp_version' => get_bloginfo('version'),
            'db_version' => $wpdb->db_version(),
            'active_plugins' => get_option('active_plugins'),
            'theme' => wp_get_theme()->get('Name'),
            'site_url' => site_url(),
            'home_url' => home_url(),
            'debug_mode' => defined('WP_DEBUG') && WP_DEBUG,
        ];
    }
} 