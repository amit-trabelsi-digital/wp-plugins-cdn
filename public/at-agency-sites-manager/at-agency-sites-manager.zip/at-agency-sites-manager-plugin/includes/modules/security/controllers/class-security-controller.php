<?php
namespace AT\AgencyManager\Modules\Security\Controllers;

use AT\AgencyManager\Modules\Security\Services\DebugService;
use AT\AgencyManager\Modules\Security\Services\LogService;

/**
 * בקר אבטחה
 * 
 * אחראי על ניהול ממשק המשתמש והגדרות מודול האבטחה
 */
class SecurityController {
    /**
     * שירות הדיבאג
     * @var DebugService
     */
    private $debugService;
    
    /**
     * שירות הלוגים
     * @var LogService
     */
    private $logService;
    
    /**
     * אתחול הבקר עם שירותים נדרשים
     * 
     * @param DebugService $debugService שירות הדיבאג
     * @param LogService $logService שירות הלוגים
     */
    public function __construct(DebugService $debugService, LogService $logService) {
        $this->debugService = $debugService;
        $this->logService = $logService;
    }
    
    /**
     * רישום תפריט הגדרות בלוח הניהול
     */
    public function registerMenu(): void {
        add_submenu_page(
            'at-agency-manager',
            'הגדרות אבטחה',
            'אבטחה',
            'manage_options',
            'at-security-settings',
            [$this, 'renderSettingsPage']
        );
    }
    
    /**
     * רישום הגדרות המודול
     */
    public function registerSettings(): void {
        register_setting('at_security_settings', 'at_security_debug_mode');
        register_setting('at_security_settings', 'at_security_log_level');
        register_setting('at_security_settings', 'at_security_log_retention');
    }
    
    /**
     * הצגת דף ההגדרות
     */
    public function renderSettingsPage(): void {
        // בדיקת הרשאות
        if (!current_user_can('manage_options')) {
            wp_die('אין לך הרשאה לגשת לדף זה.');
        }
        
        // הצגת התבנית
        include AT_AGENCY_MANAGER_PATH . 'templates/security-settings.php';
    }
    
    /**
     * רישום נקודות קצה ב-REST API
     */
    public function registerRoutes(): void {
        $namespace = 'at-agency-manager/v1';
        
        register_rest_route($namespace, '/security/debug', [
            'methods' => 'GET',
            'callback' => [$this, 'getDebugInfo'],
            'permission_callback' => [$this, 'checkApiPermission']
        ]);
        
        register_rest_route($namespace, '/security/logs', [
            'methods' => 'GET',
            'callback' => [$this, 'getLogs'],
            'permission_callback' => [$this, 'checkApiPermission']
        ]);
    }
    
    /**
     * בדיקת הרשאות לגישה ל-API
     * 
     * @param \WP_REST_Request $request בקשת ה-API
     * @return bool
     */
    public function checkApiPermission($request): bool {
        $auth_key = get_option('at_agency_manager_auth_key');
        $header_key = $request->get_header('X-AT-Agency-Manager-Key');
        
        return $auth_key === $header_key;
    }
    
    /**
     * החזרת מידע דיבאג
     * 
     * @param \WP_REST_Request $request בקשת ה-API
     * @return \WP_REST_Response
     */
    public function getDebugInfo($request): \WP_REST_Response {
        $debug_data = $this->debugService->getDebugData();
        return new \WP_REST_Response($debug_data, 200);
    }
    
    /**
     * החזרת לוגים
     * 
     * @param \WP_REST_Request $request בקשת ה-API
     * @return \WP_REST_Response
     */
    public function getLogs($request): \WP_REST_Response {
        $params = $request->get_params();
        $limit = isset($params['limit']) ? (int)$params['limit'] : 50;
        $level = isset($params['level']) ? sanitize_text_field($params['level']) : null;
        
        $logs = $this->logService->getLogs($limit, $level);
        return new \WP_REST_Response($logs, 200);
    }
} 