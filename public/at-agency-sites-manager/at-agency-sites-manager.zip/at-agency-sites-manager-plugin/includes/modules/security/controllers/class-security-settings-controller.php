class Security_Settings_Controller {
    public function __construct() {
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
    }

    public function enqueue_scripts($hook) {
        if ('settings_page_at-security-settings' !== $hook) {
            return;
        }

        wp_enqueue_style(
            'at-security-settings',
            plugins_url('assets/css/security-settings.css', AT_PLUGIN_FILE),
            array(),
            AT_PLUGIN_VERSION
        );

        wp_enqueue_script(
            'at-security-settings',
            plugins_url('assets/js/security-settings.js', AT_PLUGIN_FILE),
            array('jquery'),
            AT_PLUGIN_VERSION,
            true
        );

        wp_localize_script('at-security-settings', 'atSecuritySettings', array(
            'restUrl' => rest_url('at/v1/'),
            'nonce' => wp_create_nonce('wp_rest'),
            'i18n' => array(
                'errorLoading' => __('שגיאה בטעינת המידע', 'at-agency-sites-manager'),
                'noLogs' => __('לא נמצאו רשומות', 'at-agency-sites-manager'),
                'timestamp' => __('זמן', 'at-agency-sites-manager'),
                'level' => __('רמה', 'at-agency-sites-manager'),
                'message' => __('הודעה', 'at-agency-sites-manager'),
            )
        ));
    }

    // ... existing code ...
} 