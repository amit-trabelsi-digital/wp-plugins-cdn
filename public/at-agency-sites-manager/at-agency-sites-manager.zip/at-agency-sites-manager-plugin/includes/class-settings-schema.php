<?php
/**
 * AT Agency Manager Settings Schema Registry
 *
 * Handles registration and rendering of settings fields via schema.
 */
defined('ABSPATH') || exit;

class AT_Agency_Manager_Settings_Schema {

    /**
     * @var AT_Agency_Manager_Settings_Schema|null
     */
    private static $instance = null;

    /**
     * Get singleton instance.
     *
     * @return AT_Agency_Manager_Settings_Schema
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Initialize the schema registry.
     */
    public function init() {
        add_action('admin_init', array($this, 'register_schema_settings'));
    }

    /**
     * Register settings defined via schema.
     */
    public function register_schema_settings() {
        $suite_core = at_suite_core();
        if (!$suite_core) {
            return;
        }

        // Get schema from all registered plugins
        // This applies the 'at_suite_settings_schema' filter
        $schemas = $suite_core->get_settings_schema();

        if (empty($schemas) || !is_array($schemas)) {
            return;
        }

        foreach ($schemas as $section_id => $fields) {
            if (empty($fields) || !is_array($fields)) {
                continue;
            }

            // Register the setting group (one array per section/plugin)
            register_setting(
                'at_agency_manager_general', // We attach to the general group for now, or could be dynamic
                'at_suite_settings_' . $section_id,
                array(
                    'sanitize_callback' => array($this, 'sanitize_settings_group')
                )
            );

            // Add section if it doesn't exist (we might need a way to define section titles)
            // For now, we assume these append to existing sections or create generic ones
            add_settings_section(
                'at_suite_section_' . $section_id,
                ucfirst(str_replace(array('_', '-'), ' ', $section_id)), // Fallback title
                null,
                'at_agency_manager_general'
            );

            foreach ($fields as $field_id => $field_args) {
                add_settings_field(
                    $field_id,
                    isset($field_args['label']) ? $field_args['label'] : $field_id,
                    array($this, 'render_field'),
                    'at_agency_manager_general',
                    'at_suite_section_' . $section_id,
                    array(
                        'section_id' => $section_id,
                        'field_id'   => $field_id,
                        'args'       => $field_args
                    )
                );
            }
        }
    }

    /**
     * Render a single field based on schema.
     *
     * @param array $params
     */
    public function render_field($params) {
        $section_id = $params['section_id'];
        $field_id   = $params['field_id'];
        $args       = $params['args'];
        
        $option_name = 'at_suite_settings_' . $section_id;
        $options     = get_option($option_name, array());
        $value       = isset($options[$field_id]) ? $options[$field_id] : (isset($args['default']) ? $args['default'] : '');
        
        $type        = isset($args['type']) ? $args['type'] : 'text';
        $description = isset($args['description']) ? $args['description'] : '';
        $placeholder = isset($args['placeholder']) ? $args['placeholder'] : '';
        $class       = isset($args['class']) ? $args['class'] : 'regular-text';

        switch ($type) {
            case 'text':
            case 'password':
            case 'email':
            case 'number':
            case 'url':
                printf(
                    '<input type="%s" name="%s[%s]" value="%s" class="%s" placeholder="%s" />',
                    esc_attr($type),
                    esc_attr($option_name),
                    esc_attr($field_id),
                    esc_attr($value),
                    esc_attr($class),
                    esc_attr($placeholder)
                );
                break;

            case 'textarea':
                printf(
                    '<textarea name="%s[%s]" class="%s" placeholder="%s" rows="5" cols="30">%s</textarea>',
                    esc_attr($option_name),
                    esc_attr($field_id),
                    esc_attr($class),
                    esc_attr($placeholder),
                    esc_textarea($value)
                );
                break;

            case 'checkbox':
                printf(
                    '<label><input type="checkbox" name="%s[%s]" value="1" %s /> %s</label>',
                    esc_attr($option_name),
                    esc_attr($field_id),
                    checked(1, $value, false),
                    esc_html($description) // Description often goes next to checkbox
                );
                $description = ''; // Clear description to avoid duplication below
                break;

            case 'select':
                echo '<select name="' . esc_attr($option_name) . '[' . esc_attr($field_id) . ']" class="' . esc_attr($class) . '">';
                if (!empty($args['options']) && is_array($args['options'])) {
                    foreach ($args['options'] as $opt_value => $opt_label) {
                        printf(
                            '<option value="%s" %s>%s</option>',
                            esc_attr($opt_value),
                            selected($value, $opt_value, false),
                            esc_html($opt_label)
                        );
                    }
                }
                echo '</select>';
                break;
        }

        if (!empty($description)) {
            printf('<p class="description">%s</p>', wp_kses_post($description));
        }
    }

    /**
     * Sanitize the entire settings group.
     *
     * @param array $input
     * @return array
     */
    public function sanitize_settings_group($input) {
        // We could implement schema-based sanitization here if we had access to the schema context easily.
        // For now, we do basic sanitization.
        // Ideally, we would re-fetch the schema to know types.
        
        $suite_core = at_suite_core();
        if (!$suite_core) {
            return $input;
        }
        
        // This is a bit expensive, but safe.
        $schemas = $suite_core->get_settings_schema();
        
        // Find which section this input belongs to.
        // Since we don't have the section ID in the input directly, we might need to rely on the option name passed to the callback?
        // Actually, register_setting callback receives the value.
        // We registered 'at_suite_settings_' . $section_id.
        // But we don't know $section_id inside this callback easily without a closure or class state.
        // However, we can iterate schemas and check keys, but that's ambiguous.
        
        // BETTER APPROACH: Use a closure in register_schema_settings for the callback.
        // But for this class method, let's just sanitize recursively for safety.
        
        if (is_array($input)) {
            foreach ($input as $key => $value) {
                if (is_string($value)) {
                    $input[$key] = sanitize_text_field($value);
                }
            }
        }
        
        // Trigger saved action
        // Note: This runs on every save, for every section.
        // We might want to debounce or check if it's the right hook.
        // But 'at_suite_settings_saved' implies ANY suite setting.
        if ($suite_core) {
            // We pass the input as the saved data
            $suite_core->settings_saved($input);
        }

        return $input;
    }
}
