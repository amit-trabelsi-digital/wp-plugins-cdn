<?php
/**
 * WordPress Abilities API Integration
 * 
 * This file integrates the WordPress Abilities API with the AT Agency Manager plugin
 * to enable LLM functionality and AI assistants to interact with the plugin.
 *
 * @package AT_Agency_Manager
 * @since 0.10.0
 */

defined('ABSPATH') or die('Direct access not allowed');

/**
 * Class AT_Agency_Manager_Abilities_API
 *
 * Handles the integration with WordPress Abilities API for LLM support
 */
class AT_Agency_Manager_Abilities_API {
    /**
     * @var AT_Agency_Manager_Logger
     */
    private $logger;

    /**
     * @var bool
     */
    private $is_abilities_api_loaded = false;

    /**
     * Constructor
     *
     * @param AT_Agency_Manager_Logger $logger Logger instance
     */
    public function __construct($logger) {
        $this->logger = $logger;

        // Only setup if logger is valid
        if ($this->logger && method_exists($this->logger, 'log')) {
            $this->setup_abilities_api();
        } else {
            // Fallback: log to error_log if logger is not available
            error_log('AT Agency Manager: Logger not available for Abilities API initialization');
        }
    }

    /**
     * Setup the Abilities API integration
     */
    public function setup_abilities_api() {
        // Check if Abilities API functions exist or if the plugin is active
        // This supports both the plugin version and core integration (future)
        if (function_exists('wp_register_ability') || 
            (function_exists('is_plugin_active') && is_plugin_active('abilities-api/abilities-api.php')) ||
            class_exists('WordPress\\AbilitiesAPI\\Registry')) {
            
            // Register categories first
            add_action('wp_abilities_api_categories_init', array($this, 'register_categories'));
            
            // Register abilities
            add_action('wp_abilities_api_init', array($this, 'register_abilities'));
            
            $this->is_abilities_api_loaded = true;
            // Removed noisy log: $this->logger->log('abilities_api', 'WordPress Abilities API loaded successfully', 'info');
        } else {
            // Only log once per day to avoid spam
            $last_logged = get_transient('at_agency_abilities_api_warning_logged');
            if (!$last_logged) {
                $this->logger->log('abilities_api', 'WordPress Abilities API not found. Please install the Abilities API plugin.', 'warning');
                // Set transient for 24 hours to prevent duplicate logs
                set_transient('at_agency_abilities_api_warning_logged', time(), DAY_IN_SECONDS);
            }
        }
    }

    /**
     * Check if Abilities API is loaded successfully
     *
     * @return bool
     */
    public function is_loaded() {
        return $this->is_abilities_api_loaded;
    }

    /**
     * Register ability categories
     */
    public function register_categories() {
        if (!function_exists('wp_register_ability_category')) {
            return;
        }

        wp_register_ability_category('at-agency-manager', array(
            'label' => __('AT Agency Manager', 'at-agency-manager'),
            'description' => __('Abilities related to AT Agency Manager plugin functionality', 'at-agency-manager'),
        ));
    }

    /**
     * Register all plugin abilities with the WordPress Abilities API
     */
    public function register_abilities() {
        if (!function_exists('wp_register_ability')) {
            return;
        }

        // Site Information Ability
        wp_register_ability('at-agency-manager/site-info', array(
            'label' => 'AT Agency Site Information',
            'description' => 'Get information about the WordPress site managed by AT Agency',
            'category' => 'at-agency-manager',
            'input_schema' => array(
                'type' => 'object',
                'properties' => array(
                    'include_stats' => array(
                        'type' => 'boolean',
                        'description' => 'Whether to include site statistics',
                        'default' => false,
                    ),
                ),
            ),
            'execute_callback' => array($this, 'get_site_info'),
            'permission_callback' => function() {
                return current_user_can('manage_options');
            },
        ));

        // Modules Management Ability
        wp_register_ability('at-agency-manager/modules', array(
            'label' => 'AT Agency Modules Management',
            'description' => 'List, enable, or disable AT Agency Manager modules',
            'category' => 'at-agency-manager',
            'input_schema' => array(
                'type' => 'object',
                'properties' => array(
                    'action' => array(
                        'type' => 'string',
                        'description' => 'Action to perform (list, enable, disable)',
                        'enum' => ['list', 'enable', 'disable'],
                        'default' => 'list',
                    ),
                    'module' => array(
                        'type' => 'string',
                        'description' => 'Module name (e.g., activity_log, site_health, backup)',
                    ),
                ),
                'required' => ['action'],
            ),
            'execute_callback' => array($this, 'manage_modules'),
            'permission_callback' => function() {
                return current_user_can('manage_options');
            },
        ));

        // SMTP Settings Ability
        wp_register_ability('at-agency-manager/smtp-settings', array(
            'label' => 'AT Agency SMTP Settings',
            'description' => 'Get or update SMTP settings for email delivery',
            'category' => 'at-agency-manager',
            'input_schema' => array(
                'type' => 'object',
                'properties' => array(
                    'action' => array(
                        'type' => 'string',
                        'description' => 'Action to perform (get, update)',
                        'enum' => ['get', 'update'],
                        'default' => 'get',
                    ),
                    'host' => array(
                        'type' => 'string',
                        'description' => 'SMTP host',
                    ),
                    'port' => array(
                        'type' => 'integer',
                        'description' => 'SMTP port',
                    ),
                    'username' => array(
                        'type' => 'string',
                        'description' => 'SMTP username',
                    ),
                    'password' => array(
                        'type' => 'string',
                        'description' => 'SMTP password',
                    ),
                    'encryption' => array(
                        'type' => 'string',
                        'description' => 'SMTP encryption type',
                        'enum' => ['none', 'ssl', 'tls'],
                    ),
                ),
                'required' => ['action'],
            ),
            'execute_callback' => array($this, 'manage_smtp_settings'),
            'permission_callback' => function() {
                return current_user_can('manage_options');
            },
        ));

        $this->logger->log('abilities_api', 'AT Agency Manager abilities registered with WordPress Abilities API', 'info');
    }

    /**
     * Ability callback: Get site information
     *
     * @param array $params Parameters received from the ability call
     * @return array|WP_Error Site information or error
     */
    public function get_site_info($params) {
        $include_stats = isset($params['include_stats']) ? (bool) $params['include_stats'] : false;
        
        $site_info = array(
            'name' => get_bloginfo('name'),
            'description' => get_bloginfo('description'),
            'url' => site_url(),
            'admin_url' => admin_url(),
            'version' => get_bloginfo('version'),
            'timezone' => wp_timezone_string(),
            'language' => get_locale(),
            'agency_manager_version' => AT_AGENCY_MANAGER_VERSION,
        );
        
        if ($include_stats) {
            // Add basic site statistics
            $post_count = wp_count_posts();
            $page_count = wp_count_posts('page');
            $user_count = count_users();
            
            $site_info['statistics'] = array(
                'posts' => $post_count->publish,
                'pages' => $page_count->publish,
                'users' => $user_count['total_users'],
                'comments' => wp_count_comments()->approved,
                'plugins' => count(get_plugins()),
            );
        }
        
        return $site_info;
    }

    /**
     * Ability callback: Manage modules
     *
     * @param array $params Parameters received from the ability call
     * @return array|WP_Error Result or error
     */
    public function manage_modules($params) {
        $action = isset($params['action']) ? sanitize_text_field($params['action']) : 'list';
        $module = isset($params['module']) ? sanitize_key($params['module']) : '';
        
        $modules = get_option('at_agency_manager_modules', array());
        
        // Define available modules with descriptions
        $available_modules = array(
            'activity_log' => __('Tracks user activity on the site', 'at-agency-manager'),
            'site_health' => __('Monitors site health and provides recommendations', 'at-agency-manager'),
            'hide_login' => __('Customizes the WordPress login URL', 'at-agency-manager'),
            'acf_copy_tool' => __('Tool for copying ACF fields between sites', 'at-agency-manager'),
            'acf_elementor_tag' => __('Enhanced Elementor integration with ACF fields', 'at-agency-manager'),
            'email_log' => __('Logs all emails sent from the site', 'at-agency-manager'),
            'backup' => __('Site backup functionality', 'at-agency-manager'),
        );
        
        switch ($action) {
            case 'list':
                $result = array();
                
                foreach ($available_modules as $mod_key => $mod_desc) {
                    $result[$mod_key] = array(
                        'name' => $mod_key,
                        'description' => $mod_desc,
                        'enabled' => isset($modules[$mod_key]) && $modules[$mod_key] ? true : false,
                    );
                }
                
                return $result;
                
            case 'enable':
                if (empty($module) || !array_key_exists($module, $available_modules)) {
                    return new WP_Error('invalid_module', __('Invalid module specified', 'at-agency-manager'));
                }
                
                $modules[$module] = 1;
                update_option('at_agency_manager_modules', $modules);
                
                // Reload modules if possible or just return success (reload happens on next page load)
                if (function_exists('load_at_agency_modules')) {
                    load_at_agency_modules($this->logger);
                }
                
                return array(
                    'success' => true,
                    'message' => sprintf(__('Module %s enabled successfully', 'at-agency-manager'), $module),
                    'module' => $module,
                    'status' => 'enabled',
                );
                
            case 'disable':
                if (empty($module) || !array_key_exists($module, $available_modules)) {
                    return new WP_Error('invalid_module', __('Invalid module specified', 'at-agency-manager'));
                }
                
                $modules[$module] = 0;
                update_option('at_agency_manager_modules', $modules);
                
                return array(
                    'success' => true,
                    'message' => sprintf(__('Module %s disabled successfully', 'at-agency-manager'), $module),
                    'module' => $module,
                    'status' => 'disabled',
                );
                
            default:
                return new WP_Error('invalid_action', __('Invalid action specified', 'at-agency-manager'));
        }
    }

    /**
     * Ability callback: Manage SMTP settings
     *
     * @param array $params Parameters received from the ability call
     * @return array|WP_Error Result or error
     */
    public function manage_smtp_settings($params) {
        $action = isset($params['action']) ? sanitize_text_field($params['action']) : 'get';
        
        // Get current SMTP settings
        $smtp_settings = get_option('at_agency_manager_smtp', array(
            'enabled' => false,
            'host' => '',
            'port' => 587,
            'username' => '',
            'password' => '',
            'encryption' => 'tls',
            'from_email' => '',
            'from_name' => '',
        ));
        
        if ($action === 'get') {
            // Don't return the password for security reasons
            $smtp_settings['password'] = '';
            return $smtp_settings;
        } elseif ($action === 'update') {
            // Update SMTP settings
            $fields_to_update = array('host', 'port', 'username', 'encryption');
            
            foreach ($fields_to_update as $field) {
                if (isset($params[$field])) {
                    $smtp_settings[$field] = sanitize_text_field($params[$field]);
                }
            }
            
            // Special handling for password - only update if provided
            if (isset($params['password']) && !empty($params['password'])) {
                $smtp_settings['password'] = $params['password'];
            }
            
            // Enable SMTP if we have valid settings
            if (!empty($smtp_settings['host']) && !empty($smtp_settings['username'])) {
                $smtp_settings['enabled'] = true;
            }
            
            update_option('at_agency_manager_smtp', $smtp_settings);
            
            // Don't return the password for security reasons
            $smtp_settings['password'] = '';
            
            return array(
                'success' => true,
                'message' => __('SMTP settings updated successfully', 'at-agency-manager'),
                'settings' => $smtp_settings,
            );
        }
        
        return new WP_Error('invalid_action', __('Invalid action specified', 'at-agency-manager'));
    }
}
