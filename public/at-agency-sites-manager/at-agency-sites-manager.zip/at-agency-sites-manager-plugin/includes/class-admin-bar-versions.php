<?php
/**
 * מחלקה לניהול הצגת מספרי גרסאות ב-Admin Bar
 * 
 * מאפשרת לתוספים ותבניות להוסיף מספרי גרסאות בקלות
 */
class AT_Agency_Manager_Admin_Bar_Versions {
    
    private static $version_items = [];
    
    /**
     * אתחול המחלקה
     */
    public static function init() {
        // הוספת גרסאות רק אם Debug Info מופעל
        if (AT_Agency_Manager_Environment::should_show_debug_info()) {
            add_action('admin_bar_menu', [__CLASS__, 'add_version_info'], 100);
            add_action('admin_head', [__CLASS__, 'add_styles']);
            add_action('wp_head', [__CLASS__, 'add_styles']);
        }
    }
    
    /**
     * הוספת סגנונות CSS
     */
    public static function add_styles() {
        ?>
        <style>
            #wpadminbar .at-version-info-node > .ab-item {
                font-weight: 600;
            }
            #wpadminbar .at-version-color-blue strong {
                color: #2271b1;
            }
            #wpadminbar .at-version-color-green strong {
                color: #00a32a;
            }
            #wpadminbar .at-version-color-red strong {
                color: #d63638;
            }
            #wpadminbar .at-version-color-orange strong {
                color: #d54e21;
            }
            #wpadminbar .at-version-color-purple strong {
                color: #826eb4;
            }
        </style>
        <?php
    }
    
    /**
     * הוספת מידע גרסאות ל-Admin Bar
     * 
     * @param WP_Admin_Bar $wp_admin_bar
     */
    public static function add_version_info($wp_admin_bar) {
        // קבלת כל פריטי הגרסאות (מהפלאגין ותוספים אחרים)
        $version_items = apply_filters('at_agency_manager_version_items', self::$version_items);
        
        if (empty($version_items)) {
            return;
        }
        
        $suite_parent = $wp_admin_bar->get_node('at-suite-status') ? 'at-suite-status' : false;

        // יצירת תפריט ראשי
        $wp_admin_bar->add_node([
            'parent' => $suite_parent,
            'id' => 'at-version-info',
            'title' => 'AT: ' . self::format_version_title($version_items),
            'meta' => [
                'class' => 'at-version-info-node at-suite-source at-suite-source-versions',
            ],
        ]);
        
        // הוספת פריטי משנה
        foreach ($version_items as $item) {
            $wp_admin_bar->add_node([
                'id' => 'at-version-' . sanitize_key($item['id']),
                'parent' => 'at-version-info',
                'title' => self::format_version_item($item),
                'meta' => [
                    'class' => isset($item['color']) ? 'at-version-item-' . sanitize_key($item['color']) : '',
                    'title' => isset($item['description']) ? $item['description'] : '',
                ],
            ]);
        }
    }
    
    /**
     * הוספת פריט גרסה
     * 
     * @param string $id מזהה ייחודי
     * @param string $name שם הפריט
     * @param string $version מספר הגרסה
     * @param string $color צבע (blue|green|red|orange|purple)
     * @param string $description תיאור (אופציונלי)
     */
    public static function add_version_item($id, $name, $version, $color = 'blue', $description = '') {
        self::$version_items[$id] = [
            'id' => $id,
            'name' => $name,
            'version' => $version,
            'color' => $color,
            'description' => $description,
        ];
    }
    
    /**
     * פורמט כותרת הגרסאות
     * 
     * @param array $items רשימת פריטים
     * @return string
     */
    private static function format_version_title($items) {
        // מציאת הגרסה הראשית (הפלאגין)
        $main_version = '';
        foreach ($items as $item) {
            if ($item['id'] === 'at-agency-manager') {
                $main_version = $item['version'];
                break;
            }
        }
        
        if ($main_version) {
            return sprintf(__('Versions (%s)', 'at-agency-manager'), $main_version);
        }
        
        return __('Versions', 'at-agency-manager');
    }
    
    /**
     * פורמט פריט גרסה
     * 
     * @param array $item פרטי הפריט
     * @return string
     */
    private static function format_version_item($item) {
        $color_class = isset($item['color']) ? 'at-version-color-' . sanitize_key($item['color']) : '';
        return sprintf(
            '<span class="%s">%s: <strong>%s</strong></span>',
            esc_attr($color_class),
            esc_html($item['name']),
            esc_html($item['version'])
        );
    }
    
    /**
     * הוספת גרסאות ברירת מחדל (הפלאגין והתבנית)
     */
    public static function add_default_versions() {
        // גרסת הפלאגין
        self::add_version_item(
            'at-agency-manager',
            __('AT Agency Manager', 'at-agency-manager'),
            AT_AGENCY_MANAGER_VERSION,
            'blue',
            __('Main plugin version', 'at-agency-manager')
        );
        
        // גרסת התבנית
        $theme = wp_get_theme();
        if ($theme->exists()) {
            self::add_version_item(
                'active-theme',
                $theme->get('Name'),
                $theme->get('Version'),
                'green',
                __('Active theme version', 'at-agency-manager')
            );
        }
        
        // גרסת WordPress
        self::add_version_item(
            'wordpress',
            __('WordPress', 'at-agency-manager'),
            get_bloginfo('version'),
            'orange',
            __('WordPress core version', 'at-agency-manager')
        );
        
        // גרסת WordPress AI Assistant (אם מותקן)
        if (defined('WORDPRESS_AI_ASSISTANT_VERSION')) {
            self::add_version_item(
                'wordpress-ai-assistant',
                __('WordPress AI Assistant', 'at-agency-manager'),
                WORDPRESS_AI_ASSISTANT_VERSION,
                'purple',
                __('WordPress AI Assistant plugin version', 'at-agency-manager')
            );
        }
    }
}
