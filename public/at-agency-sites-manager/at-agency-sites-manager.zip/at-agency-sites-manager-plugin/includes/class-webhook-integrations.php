<?php
/**
 * אינטגרציות וובהוקים עם שירותים חיצוניים
 */

// Fallback functions for when WordPress is not loaded
if (!function_exists('__')) {
    function __($text, $domain = '') {
        return $text;
    }
}

if (!function_exists('_e')) {
    function _e($text, $domain = '') {
        echo $text;
    }
}

class AT_Agency_Manager_Webhook_Integrations {
    /**
     * יצירת וובהוק מותאם ל-Slack
     *
     * @param string $webhook_url כתובת הוובהוק של Slack
     * @param string $channel ערוץ Slack (אופציונלי)
     * @param string $username שם המשתמש (אופציונלי)
     * @return array נתוני הוובהוק
     */
    public static function create_slack_webhook($webhook_url, $channel = null, $username = 'AT Agency Bot') {
        return array(
            'name' => __('Slack Notifications', 'at-agency-manager'),
            'url' => $webhook_url,
            'events' => array(
                'user_register',
                'user_login',
                'post_publish',
                'comment_post',
                'login_failed'
            ),
            'settings' => array(
                'enabled' => true,
                'method' => 'POST',
                'headers' => array(
                    'Content-Type' => 'application/json'
                ),
                'timeout' => 30,
                'retries' => 3,
                'user_roles' => array(),
                'specific_users' => array(),
                'content_type' => 'json',
                'slack_channel' => $channel,
                'slack_username' => $username,
                'integration_type' => 'slack'
            )
        );
    }

    /**
     * יצירת וובהוק מותאם ל-Microsoft Teams
     *
     * @param string $webhook_url כתובת הוובהוק של Teams
     * @param string $title כותרת ההודעה (אופציונלי)
     * @return array נתוני הוובהוק
     */
    public static function create_teams_webhook($webhook_url, $title = 'AT Agency Alert') {
        return array(
            'name' => __('Teams Notifications', 'at-agency-manager'),
            'url' => $webhook_url,
            'events' => array(
                'user_register',
                'user_login',
                'post_publish',
                'core_update',
                'login_failed'
            ),
            'settings' => array(
                'enabled' => true,
                'method' => 'POST',
                'headers' => array(
                    'Content-Type' => 'application/json'
                ),
                'timeout' => 30,
                'retries' => 3,
                'user_roles' => array(),
                'specific_users' => array(),
                'content_type' => 'json',
                'teams_title' => $title,
                'integration_type' => 'teams'
            )
        );
    }

    /**
     * יצירת וובהוק מותאם ל-Discord
     *
     * @param string $webhook_url כתובת הוובהוק של Discord
     * @param string $username שם הבוט (אופציונלי)
     * @param string $avatar_url כתובת תמונת הבוט (אופציונלי)
     * @return array נתוני הוובהוק
     */
    public static function create_discord_webhook($webhook_url, $username = 'AT Agency Bot', $avatar_url = null) {
        return array(
            'name' => __('Discord Notifications', 'at-agency-manager'),
            'url' => $webhook_url,
            'events' => array(
                'user_register',
                'user_login',
                'post_publish',
                'comment_post',
                'login_failed'
            ),
            'settings' => array(
                'enabled' => true,
                'method' => 'POST',
                'headers' => array(
                    'Content-Type' => 'application/json'
                ),
                'timeout' => 30,
                'retries' => 3,
                'user_roles' => array(),
                'specific_users' => array(),
                'content_type' => 'json',
                'discord_username' => $username,
                'discord_avatar_url' => $avatar_url,
                'integration_type' => 'discord'
            )
        );
    }

    /**
     * עיצוב הודעה עבור Slack
     *
     * @param string $event שם האירוע
     * @param array $data נתוני האירוע
     * @param array $webhook נתוני הוובהוק
     * @return array נתוני ההודעה
     */
    public static function format_slack_message($event, $data, $webhook) {
        $settings = $webhook['settings'];

        $message = array(
            'username' => $settings['slack_username'] ?? 'AT Agency Bot',
            'icon_emoji' => ':bell:',
            'attachments' => array()
        );

        // הוספת ערוץ אם הוגדר
        if (!empty($settings['slack_channel'])) {
            $message['channel'] = $settings['slack_channel'];
        }

        // עיצוב ההודעה לפי סוג האירוע
        $attachment = self::format_event_attachment($event, $data, 'slack');
        $message['attachments'][] = $attachment;

        return $message;
    }

    /**
     * עיצוב הודעה עבור Microsoft Teams
     *
     * @param string $event שם האירוע
     * @param array $data נתוני האירוע
     * @param array $webhook נתוני הוובהוק
     * @return array נתוני ההודעה
     */
    public static function format_teams_message($event, $data, $webhook) {
        $settings = $webhook['settings'];

        $title = $settings['teams_title'] ?? 'AT Agency Alert';
        $color = self::get_event_color($event);

        $message = array(
            '@type' => 'MessageCard',
            '@context' => 'http://schema.org/extensions',
            'themeColor' => $color,
            'title' => $title,
            'text' => self::format_event_text($event, $data, 'teams'),
            'sections' => array(
                array(
                    'facts' => self::format_event_facts($event, $data)
                )
            )
        );

        return $message;
    }

    /**
     * עיצוב הודעה עבור Discord
     *
     * @param string $event שם האירוע
     * @param array $data נתוני האירוע
     * @param array $webhook נתוני הוובהוק
     * @return array נתוני ההודעה
     */
    public static function format_discord_message($event, $data, $webhook) {
        $settings = $webhook['settings'];

        $message = array(
            'username' => $settings['discord_username'] ?? 'AT Agency Bot',
            'embeds' => array(
                array(
                    'title' => self::get_event_title($event),
                    'description' => self::format_event_text($event, $data, 'discord'),
                    'color' => hexdec(self::get_event_color($event)),
                    'fields' => self::format_event_fields($event, $data),
                    'timestamp' => current_time('c'),
                    'footer' => array(
                        'text' => get_bloginfo('name')
                    )
                )
            )
        );

        // הוספת תמונת בוט אם הוגדרה
        if (!empty($settings['discord_avatar_url'])) {
            $message['avatar_url'] = $settings['discord_avatar_url'];
        }

        return $message;
    }

    /**
     * קבלת צבע לפי סוג האירוע
     *
     * @param string $event שם האירוע
     * @return string קוד צבע hex
     */
    private static function get_event_color($event) {
        $colors = array(
            'user_register' => '36a64f',      // ירוק
            'user_login' => '0052cc',         // כחול
            'user_logout' => '808080',        // אפור
            'post_publish' => '28a745',       // ירוק כהה
            'page_publish' => '28a745',       // ירוק כהה
            'comment_post' => 'ffc107',       // צהוב
            'login_failed' => 'dc3545',       // אדום
            'user_delete' => 'dc3545',        // אדום
            'plugin_activate' => '17a2b8',    // תכלת
            'plugin_deactivate' => '6c757d',  // אפור כהה
            'core_update' => 'ff8c00'         // כתום
        );

        return isset($colors[$event]) ? $colors[$event] : '808080';
    }

    /**
     * קבלת כותרת לאירוע
     *
     * @param string $event שם האירוע
     * @return string כותרת האירוע
     */
    private static function get_event_title($event) {
        $titles = array(
            'user_register' => __('New User Registration', 'at-agency-manager'),
            'user_login' => __('User Login', 'at-agency-manager'),
            'user_logout' => __('User Logout', 'at-agency-manager'),
            'post_publish' => __('Post Published', 'at-agency-manager'),
            'page_publish' => __('Page Published', 'at-agency-manager'),
            'comment_post' => __('New Comment', 'at-agency-manager'),
            'login_failed' => __('Failed Login Attempt', 'at-agency-manager'),
            'user_delete' => __('User Deleted', 'at-agency-manager'),
            'plugin_activate' => __('Plugin Activated', 'at-agency-manager'),
            'plugin_deactivate' => __('Plugin Deactivated', 'at-agency-manager'),
            'core_update' => __('WordPress Updated', 'at-agency-manager')
        );

        return isset($titles[$event]) ? $titles[$event] : __('System Event', 'at-agency-manager');
    }

    /**
     * עיצוב טקסט האירוע
     *
     * @param string $event שם האירוע
     * @param array $data נתוני האירוע
     * @param string $platform פלטפורמה (slack/teams/discord)
     * @return string טקסט מעוצב
     */
    private static function format_event_text($event, $data, $platform = 'slack') {
        switch ($event) {
            case 'user_register':
                return sprintf(__('New user registered: %s (%s)', 'at-agency-manager'),
                    $data['user_login'], $data['user_email']);

            case 'user_login':
                return sprintf(__('User logged in: %s', 'at-agency-manager'), $data['user_login']);

            case 'user_logout':
                return sprintf(__('User logged out: %s', 'at-agency-manager'), $data['user_login']);

            case 'post_publish':
                return sprintf(__('New post published: "%s" by %s', 'at-agency-manager'),
                    $data['post_title'], get_userdata($data['post_author'])->display_name);

            case 'page_publish':
                return sprintf(__('New page published: "%s" by %s', 'at-agency-manager'),
                    $data['page_title'], get_userdata($data['page_author'])->display_name);

            case 'comment_post':
                return sprintf(__('New comment on "%s"', 'at-agency-manager'),
                    get_the_title($data['post_id']));

            case 'login_failed':
                return sprintf(__('Failed login attempt for user: %s', 'at-agency-manager'), $data['username']);

            default:
                return sprintf(__('System event: %s', 'at-agency-manager'), $event);
        }
    }

    /**
     * עיצוב צרופות לאירוע (ל-Slack)
     *
     * @param string $event שם האירוע
     * @param array $data נתוני האירוע
     * @param string $platform פלטפורמה
     * @return array צרופת האירוע
     */
    private static function format_event_attachment($event, $data, $platform) {
        $attachment = array(
            'color' => self::get_event_color($event),
            'fields' => self::format_event_fields($event, $data)
        );

        return $attachment;
    }

    /**
     * עיצוב שדות האירוע
     *
     * @param string $event שם האירוע
     * @param array $data נתוני האירוע
     * @return array שדות האירוע
     */
    private static function format_event_fields($event, $data) {
        $fields = array();

        switch ($event) {
            case 'user_register':
                $fields[] = array(
                    'name' => __('Username', 'at-agency-manager'),
                    'value' => $data['user_login'],
                    'inline' => true
                );
                $fields[] = array(
                    'name' => __('Email', 'at-agency-manager'),
                    'value' => $data['user_email'],
                    'inline' => true
                );
                $fields[] = array(
                    'name' => __('Roles', 'at-agency-manager'),
                    'value' => implode(', ', $data['user_roles']),
                    'inline' => true
                );
                break;

            case 'user_login':
                $fields[] = array(
                    'name' => __('Username', 'at-agency-manager'),
                    'value' => $data['user_login'],
                    'inline' => true
                );
                $fields[] = array(
                    'name' => __('Login Time', 'at-agency-manager'),
                    'value' => $data['login_time'],
                    'inline' => true
                );
                break;

            case 'post_publish':
            case 'page_publish':
                $post_type = isset($data['post_type']) ? $data['post_type'] : 'page';
                $title_key = $post_type === 'post' ? 'post_title' : 'page_title';
                $author_key = $post_type === 'post' ? 'post_author' : 'page_author';

                $fields[] = array(
                    'name' => __('Title', 'at-agency-manager'),
                    'value' => $data[$title_key],
                    'inline' => false
                );
                $fields[] = array(
                    'name' => __('Author', 'at-agency-manager'),
                    'value' => get_userdata($data[$author_key])->display_name,
                    'inline' => true
                );
                $fields[] = array(
                    'name' => __('Published', 'at-agency-manager'),
                    'value' => $data['published_at'],
                    'inline' => true
                );
                break;
        }

        return $fields;
    }

    /**
     * עיצוב עובדות לאירוע (ל-Teams)
     *
     * @param string $event שם האירוע
     * @param array $data נתוני האירוע
     * @return array עובדות האירוע
     */
    private static function format_event_facts($event, $data) {
        $facts = array();

        // הוספת זמן האירוע
        $facts[] = array(
            'name' => __('Time', 'at-agency-manager'),
            'value' => current_time('F j, Y, g:i a')
        );

        // הוספת אתר
        $facts[] = array(
            'name' => __('Site', 'at-agency-manager'),
            'value' => get_bloginfo('name')
        );

        // עובדות ספציפיות לאירוע
        switch ($event) {
            case 'user_register':
                $facts[] = array(
                    'name' => __('New User', 'at-agency-manager'),
                    'value' => $data['user_login']
                );
                break;

            case 'user_login':
                $facts[] = array(
                    'name' => __('User', 'at-agency-manager'),
                    'value' => $data['user_login']
                );
                break;
        }

        return $facts;
    }

    /**
     * דוגמאות לשימוש
     *
     * @return array דוגמאות לאינטגרציות
     */
    public static function get_integration_examples() {
        return array(
            'slack' => array(
                'title' => 'Slack Integration',
                'description' => __('Send notifications to Slack channels', 'at-agency-manager'),
                'example_url' => 'https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX',
                'setup_instructions' => array(
                    __('1. Go to Slack and create a new webhook', 'at-agency-manager'),
                    __('2. Copy the webhook URL', 'at-agency-manager'),
                    __('3. Use the create_slack_webhook() function', 'at-agency-manager')
                )
            ),
            'teams' => array(
                'title' => 'Microsoft Teams Integration',
                'description' => __('Send notifications to Teams channels', 'at-agency-manager'),
                'example_url' => 'https://outlook.office.com/webhook/...',
                'setup_instructions' => array(
                    __('1. Go to Teams and create a new webhook connector', 'at-agency-manager'),
                    __('2. Copy the webhook URL', 'at-agency-manager'),
                    __('3. Use the create_teams_webhook() function', 'at-agency-manager')
                )
            ),
            'discord' => array(
                'title' => 'Discord Integration',
                'description' => __('Send notifications to Discord channels', 'at-agency-manager'),
                'example_url' => 'https://discord.com/api/webhooks/...',
                'setup_instructions' => array(
                    __('1. Go to Discord server settings', 'at-agency-manager'),
                    __('2. Create a new webhook in Integrations', 'at-agency-manager'),
                    __('3. Copy the webhook URL', 'at-agency-manager'),
                    __('4. Use the create_discord_webhook() function', 'at-agency-manager')
                )
            )
        );
    }
}
