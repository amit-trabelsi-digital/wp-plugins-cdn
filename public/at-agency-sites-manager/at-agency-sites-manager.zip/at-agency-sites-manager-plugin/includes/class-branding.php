<?php
/**
 * מחלקה לניהול הברנדינג המותאם אישית
 */
class AT_Agency_Manager_Branding {
    /**
     * @var string צבע המותג הראשי של at
     */
    public $atColor = "#4ec5e0";

    /**
     * @var string לוגו המותג של at
     */
    public $atLogo;

    /**
     * @var string כתובת אתר at
     */
    public $atURL = "http://atd.digital";

    /**
     * @var string אייקון המנהל
     */
    public $atAdminFavicon;

    /**
     * אתחול המחלקה והגדרת האזנה לאירועים רלוונטיים
     */
    public function __construct() {
        $this->atLogo = AT_AGENCY_MANAGER_URL . 'assets/images/at-logo.png';
        $this->atAdminFavicon = AT_AGENCY_MANAGER_URL . 'assets/images/admin.ico';

        add_action('admin_init', array($this, 'at_init'));
        add_action('init', array($this, 'at_translate'));
        add_action('admin_menu', array($this, 'at_menu'));
        add_action('admin_enqueue_scripts', array($this, 'at_assets'));
        add_action('login_head', array($this, 'at_login_css'));
        add_action('login_footer', array($this, 'at_login_footer'));
        add_action('login_head', array($this, 'at_admin_favicon'));
        add_action('admin_head', array($this, 'at_admin_favicon'));
        add_action('admin_head', array($this, 'at_admin_css'));
        add_action('wp_dashboard_setup', array($this, 'at_add_dashboard_widgets'));
        add_action('wp_dashboard_setup', array($this, 'at_remove_dashboard_widgets'));
        add_action('wp_dashboard_setup', array($this, 'at_remove_activity_dashboard_widget'));

        add_filter('login_headertitle', array($this, 'at_login_title'));
        add_filter('login_headerurl', array($this, 'at_login_url'));
        add_filter('admin_footer_text', array($this, 'at_admin_footer'));
        
        // הסרת חלונית ברוכים הבאים
        remove_action('welcome_panel', 'wp_welcome_panel');
        
        // Update checks are handled by the shared private CDN updater.
        
        // הוספת פעולות LTR בלוח הניהול
        add_action('admin_enqueue_scripts', array($this, 'admin_body_ltr_scripts'));
        add_action('admin_bar_menu', array($this, 'admin_body_ltr_adminbar'), 100);
        
        // הוספת תמיכה ב-SVG
        add_filter('upload_mimes', array($this, 'add_svg_mime_support'));
    }

    /**
     * פעולות אתחול בלוח הניהול
     */
    public function at_init() {
        // רישום הגדרות התוסף
        register_setting('at-branding', 'clients_main_color');
        register_setting('at-branding', 'clients_logo_file');
        register_setting('at-branding', 'admin_favicon_file');
        register_setting('at-branding', 'at_use_sendgrid');
        register_setting('at-branding', 'at_sender_email_name');
        register_setting('at-branding', 'at_sender_email_address');
        register_setting('at-branding', 'at_sent_to_admin_default');
    }

    /**
     * הפעלת תרגום התוסף
     */
    public function at_translate() {
        load_plugin_textdomain('at', false, dirname(plugin_basename(__FILE__)) . '/../languages/');
    }

    /**
     * הגדרת תפריט ההגדרות בלוח הניהול
     */
    public function at_menu() {
        // הוספת דף ההגדרות של המיתוג כתת-תפריט בתפריט הראשי של התוסף
        // כך המשתמש ימצא את ההגדרות באותו מקום ולא בלשונית "Settings" הכללית
        add_submenu_page(
            'at-agency-manager',                           // סלג של התפריט הראשי
            at_agency_manager_admin_label('AT Custom Branding', 'מיתוג מותאם AT'),
            at_agency_manager_admin_label('Branding', 'מיתוג'),
            'manage_options',                               // יכולת נדרשת
            'at-custom-branding',                           // סלג הדף
            array($this, 'at_branding_page')                // פונקציית callback
        );
    }

    /**
     * טעינת נכסי התוסף (CSS, JS) בלוח הניהול
     */
    public function at_assets() {
        // רישום סקריפטים וסגנונות
        wp_register_script('at-media-upload', AT_AGENCY_MANAGER_URL . 'assets/js/admin-scripts.js');
        wp_register_style('at-settings-css', AT_AGENCY_MANAGER_URL . 'assets/css/admin-styles.css');

        $screen = get_current_screen();
        if ($screen && strpos($screen->id, 'at-custom-branding') !== false) {
            wp_enqueue_script('jquery');
            wp_enqueue_script('thickbox');
            wp_enqueue_script('media-upload');
            wp_enqueue_script('at-media-upload');

            wp_enqueue_style('thickbox');
            wp_enqueue_style('at-settings-css');
        }
    }

    /**
     * הדפסת CSS בעמוד ההתחברות
     */
    public function at_login_css() {
        $clientColor = (get_option('clients_main_color') == '') ? $this->atColor : get_option('clients_main_color');
        $clientLogo = (get_option('clients_logo_file') == '') ? $this->atLogo : get_option('clients_logo_file');

        include_once(AT_AGENCY_MANAGER_PATH . 'templates/login-css.php');
    }

    /**
     * הוספת תוכן כותרת תחתונה בעמוד ההתחברות
     */
    public function at_login_footer() {
        // אם at-branding פעיל, הוא כבר מוסיף את הקרדיט - נמנע מכפילות
        if (class_exists('AT_Branding')) {
            return;
        }
        
        echo '<div id="at-footer" style="text-align: center; direction: ltr">';
        echo '	<a href="' . $this->atURL . '">';
        echo '		הקמה וניהול:  <img width="20px" src="' . $this->atLogo . '" alt="' . __('Amit Trabelsi Digital LTD', 'at-agency-manager') . '">';
        echo '	</a>';
        echo '</div>';
    }

    /**
     * שינוי כותרת הלוגו בעמוד ההתחברות
     * 
     * @return string כותרת הלוגו
     */
    public function at_login_title() {
        return get_bloginfo('name');
    }

    /**
     * שינוי כתובת ה-URL של הלוגו בעמוד ההתחברות
     * 
     * @return string כתובת ה-URL
     */
    public function at_login_url() {
        return get_bloginfo('url');
    }

    /**
     * הוספת כותרת תחתונה מותאמת אישית בלוח הניהול
     */
    public function at_admin_footer($text) {
        ob_start();
        if (function_exists('at_suite_render_admin_footer')) {
            at_suite_render_admin_footer();
        } else {
            // Fallback if suite function not available
            ?>
            <div style="text-align: right;direction: ltr;" class="alignleft">
                <span style="line-height: 2;"> הקמה וניהול: </span>
                <a href="<?php echo $this->atURL; ?>">
                    עמית טרבלסי דיגיטל
                </a>
            </div>
            <?php
        }
        return ob_get_clean();
    }

    /**
     * בניית והצגת עמוד ההגדרות של התוסף
     */
    public function at_branding_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You are not allowed to access this page - insufficient permissions', 'at-agency-manager'));
        }

        include_once(AT_AGENCY_MANAGER_PATH . 'templates/settings-page.php');
    }

    /**
     * הגדרת אייקון מותאם אישית ללוח הניהול
     */
    public function at_admin_favicon() {
        $favicon_url = (get_option('admin_favicon_file') == '') ? $this->atAdminFavicon : get_option('admin_favicon_file');
        echo '<link rel="shortcut icon" href="' . $favicon_url . '" />';
    }

    /**
     * הוספת וידג'ט ללוח המחוונים
     */
    public function at_add_dashboard_widgets() {
        wp_add_dashboard_widget(
            'at_contact_details',
            'AT contact',
            array($this, 'at_dashboard_widget_function')
        );
    }

    /**
     * תוכן וידג'ט לוח המחוונים
     */
    public function at_dashboard_widget_function() {
        // בדיקת סטטוס שרת מיילים
        $email_status = $this->check_email_server_status();
        
        ?>
        <div id="contact_logo" align="center">
            <a href="https://atd.digital" target="_blank">
                <img src="<?php echo $this->atLogo; ?>" style="width:60%">
            </a>
        </div>
        <div>
            <div class="contact"><?php _e('הרשנזון 14, רחובות', 'at-agency-manager'); ?></div>
            <div class="contact">שירות: <a href="https://amit-trabelsi.co.il/%d7%90%d7%96%d7%95%d7%a8-%d7%9c%d7%a7%d7%95%d7%97%d7%95%d7%aa/">פתיחת פנייה</a></div>
            <div class="contact">טלפון: <a href="tel:+972506362008">+972-50-6362008</a></div>
            <div class="contact">אימייל: <a href="mailto:sos@atd.digital">sos@atd.digital</a></div>
        </div>
        
        <!-- סטטוס שרת מיילים -->
        <div style="margin-top: 20px; padding-top: 15px; border-top: 1px solid #eee;">
            <h4><?php _e('Email Server Status', 'at-agency-manager'); ?></h4>
            <div style="display: flex; align-items: center; gap: 10px;">
                <span style="display: inline-block; width: 12px; height: 12px; border-radius: 50%; background-color: <?php echo $email_status['color']; ?>;"></span>
                <span>
                    <strong><?php echo esc_html($email_status['status']); ?></strong><br>
                    <small><?php echo esc_html($email_status['details']); ?></small>
                </span>
            </div>
        </div>
        <?php
    }
    
    /**
     * בדיקת סטטוס שרת המיילים
     */
    private function check_email_server_status() {
        $smtp_host = get_option('at_agency_manager_smtp_host');
        $use_sendgrid = get_option('at_use_sendgrid');
        
        if ($use_sendgrid) {
            return [
                'status' => __('SendGrid', 'at-agency-manager'),
                'details' => __('Using SendGrid for email sending', 'at-agency-manager'),
                'color' => '#28a745'
            ];
        }
        
        if ($smtp_host) {
            $smtp_port = get_option('at_agency_manager_smtp_port', '587');
            $smtp_user = get_option('at_agency_manager_smtp_user');
            
            if ($this->test_smtp_connection($smtp_host, $smtp_port)) {
                return [
                    'status' => __('SMTP Connected', 'at-agency-manager'),
                    'details' => sprintf(__('Host: %s:%s', 'at-agency-manager'), esc_html($smtp_host), esc_html($smtp_port)),
                    'color' => '#28a745'
                ];
            } else {
                return [
                    'status' => __('SMTP Error', 'at-agency-manager'),
                    'details' => sprintf(__('Cannot connect to %s:%s', 'at-agency-manager'), esc_html($smtp_host), esc_html($smtp_port)),
                    'color' => '#dc3545'
                ];
            }
        }
        
        return [
            'status' => __('PHP Mail (Default)', 'at-agency-manager'),
            'details' => __('Using server default email configuration', 'at-agency-manager'),
            'color' => '#ffc107'
        ];
    }
    
    /**
     * בדיקת חיבור SMTP
     */
    private function test_smtp_connection($host, $port) {
        $connection = @fsockopen($host, intval($port), $errno, $errstr, 5);
        if ($connection) {
            fclose($connection);
            return true;
        }
        return false;
    }

    /**
     * הסרת וידג'טים מלוח המחוונים
     */
    public function at_remove_dashboard_widgets() {
        global $wp_meta_boxes;

        unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_quick_press']);
        unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_incoming_links']);
        unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_right_now']);
        unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_plugins']);
        unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_recent_drafts']);
        unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_recent_comments']);
        unset($wp_meta_boxes['dashboard']['normal']['core']['dashboard_activity']);
        unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_primary']);
        unset($wp_meta_boxes['dashboard']['side']['core']['dashboard_secondary']);
    }

    /**
     * הסרת וידג'ט הפעילות מלוח המחוונים
     */
    public function at_remove_activity_dashboard_widget() {
        remove_meta_box('dashboard_activity', 'dashboard', 'side');
    }

    /**
     * בדיקת עדכונים זמינים לתוסף
     * 
     * @param object $transient אובייקט ה-transient
     * @return object אובייקט ה-transient המעודכן
     */
    public function check_for_plugin_update($transient) {
        if (empty($transient->checked)) {
            return $transient;
        }

        // URL של קובץ ה-JSON בגיטהאב
        $update_uri = 'https://raw.githubusercontent.com/amit-trabelsi-digital/at-agency-sites-manager-wp-plugin/main/plugin-info.json';
        
        $remote_info = wp_remote_get($update_uri);

        if (!is_wp_error($remote_info) && isset($remote_info['response']['code']) && $remote_info['response']['code'] == 200) {
            $remote_info = json_decode(wp_remote_retrieve_body($remote_info), true);

            // בדיקת תקינות המידע
            if (!$remote_info || !isset($remote_info['version'])) {
                return $transient;
            }

            // השוואת גרסאות
            if (version_compare(AT_AGENCY_MANAGER_VERSION, $remote_info['version'], '<')) {
                $obj = new stdClass();
                $obj->slug = 'at-agency-sites-manager';
                $obj->new_version = $remote_info['version'];
                $obj->url = 'https://github.com/amit-trabelsi-digital/at-agency-sites-manager-wp-plugin';
                $obj->package = $remote_info['download_url'];
                $obj->icons = array(
                    '1x' => 'https://raw.githubusercontent.com/amit-trabelsi-digital/at-agency-sites-manager-wp-plugin/main/assets/icon-128x128.png',
                    '2x' => 'https://raw.githubusercontent.com/amit-trabelsi-digital/at-agency-sites-manager-wp-plugin/main/assets/icon-256x256.png'
                );
                
                $transient->response[AT_AGENCY_MANAGER_BASENAME] = $obj;
            }
        }

        return $transient;
    }

    /**
     * קבלת מידע על התוסף עבור חלון העדכון
     * 
     * @param mixed $result תוצאה
     * @param string $action פעולה
     * @param object $args ארגומנטים
     * @return mixed תוצאה מעודכנת
     */
    public function plugin_api_call($result, $action, $args) {
        if ($action !== 'plugin_information') {
            return $result;
        }

        if ('at-agency-sites-manager' !== $args->slug) {
            return $result;
        }

        // URL של קובץ ה-JSON בגיטהאב
        $update_uri = 'https://raw.githubusercontent.com/amit-trabelsi-digital/at-agency-sites-manager-wp-plugin/main/plugin-info.json';
        
        $remote_info = wp_remote_get($update_uri);

        if (!is_wp_error($remote_info) && isset($remote_info['response']['code']) && $remote_info['response']['code'] == 200) {
            $remote_info = json_decode(wp_remote_retrieve_body($remote_info), true);

            // בדיקת תקינות המידע
            if ($remote_info) {
                $result = (object) array(
                    'name' => isset($remote_info['name']) ? $remote_info['name'] : 'AT Agency Sites Manager',
                    'slug' => 'at-agency-sites-manager',
                    'version' => isset($remote_info['version']) ? $remote_info['version'] : '',
                    'author' => isset($remote_info['author']) ? $remote_info['author'] : '',
                    'requires' => isset($remote_info['requires']) ? $remote_info['requires'] : '5.2',
                    'tested' => isset($remote_info['tested']) ? $remote_info['tested'] : get_bloginfo('version'),
                    'last_updated' => isset($remote_info['last_updated']) ? $remote_info['last_updated'] : date('Y-m-d'),
                    'sections' => isset($remote_info['sections']) ? $remote_info['sections'] : array(
                        'description' => 'תוסף לניהול אתרים של סוכנות עם מיתוג מותאם אישית, ניטור וניהול אתרים'
                    ),
                    'download_link' => isset($remote_info['download_url']) ? $remote_info['download_url'] : '',
                    'banners' => array(
                        'low' => 'https://raw.githubusercontent.com/amit-trabelsi-digital/at-agency-sites-manager-wp-plugin/main/assets/banner-772x250.png',
                        'high' => 'https://raw.githubusercontent.com/amit-trabelsi-digital/at-agency-sites-manager-wp-plugin/main/assets/banner-1544x500.png'
                    )
                );
            }
        }

        return $result;
    }

    /**
     * טעינת סקריפטים וסגנונות עבור ממשק LTR בלוח הניהול
     */
    public function admin_body_ltr_scripts() {
        wp_enqueue_style('admin-body-ltr', AT_AGENCY_MANAGER_URL . 'assets/css/ltr-admin.css');
        wp_enqueue_script('admin-body-ltr', AT_AGENCY_MANAGER_URL . 'assets/js/ltr-admin.js', array('jquery'), '0.1', true);

        wp_localize_script('admin-body-ltr', 'script_vars', array(
            'AJAXurl' => admin_url('admin-ajax.php')
        ));
    }

    /**
     * הוספת כפתורים לשורת הניהול העליונה
     * 
     * @param WP_Admin_Bar $wp_admin_bar אובייקט שורת הניהול
     */
    public function admin_body_ltr_adminbar($wp_admin_bar) {
        // שימוש ב-Environment Type הרשמי
        $env_type = AT_Agency_Manager_Environment::get_environment_type();
        $env = in_array($env_type, ['development', 'local']) ? 'DEV' : 'PROD';
        $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        $suite_parent = $wp_admin_bar->get_node('at-suite-status') ? 'at-suite-status' : false;
        
        $args = array(
            'parent' => $suite_parent,
            'id' => 'at_env' . '_' . strtolower($env),
            'title' => '<span id="at_env">AT: ' . $env . '</span>',
            'href' => admin_url('admin.php?page=at-agency-manager&tab=settings'),
            'meta' => array(
                'class' => 'admin-env-btn-adminbar at-suite-source at-suite-source-branding',
                'title' => sprintf(__('Environment: %s (Click to view settings)', 'at-agency-manager'), ucfirst($env_type))
            )
        );

        $wp_admin_bar->add_node($args);

        if (!is_admin()) {
            return;
        }

        // כפתורי RTL/LTR - עם פונקציונליות
        $current_dir = isset($_COOKIE['at_admin_dir']) ? $_COOKIE['at_admin_dir'] : (is_rtl() ? 'rtl' : 'ltr');
        $args = array(
            'parent' => $suite_parent,
            'id' => 'custom-button',
            'title' => 'AT: <span id="dir-rtl" class="' . ($current_dir === 'rtl' ? 'active' : '') . '">RTL</span><i></i><span id="dir-ltr" class="' . ($current_dir === 'ltr' ? 'active' : '') . '">LTR</span>',
            'href' => '#',
            'meta' => array(
                'class' => 'admin-body-ltr-adminbar at-suite-source at-suite-source-branding' . ($current_dir === 'ltr' ? ' active' : ''),
                'title' => __('Switch admin content direction between RTL and LTR', 'at-agency-manager')
            )
        );

        $wp_admin_bar->add_node($args);
    }

    /**
     * הוספת CSS מותאם אישית ללוח הניהול
     */
    public function at_admin_css() {
        ?>
        <style>
        #adminmenu .wp-menu-image img {
            opacity: 1;
            padding: 5px 0 0;
            max-width: 20px;
            max-height: 20px;
        }
        
        #wpfooter {
            direction: ltr;
        }
        </style>
        <?php
    }

    /**
     * הוספת תמיכה בהעלאת קבצי SVG
     * 
     * @param array $mimes סוגי קבצים מורשים
     * @return array סוגי קבצים מורשים מעודכנים
     */
    public function add_svg_mime_support($mimes) {
        $mimes['svg'] = 'image/svg+xml';
        return $mimes;
    }
} 
