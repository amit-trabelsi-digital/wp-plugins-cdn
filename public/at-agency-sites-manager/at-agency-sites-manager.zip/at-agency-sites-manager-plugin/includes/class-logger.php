<?php
/**
 * מחלקה לניהול רישום הלוגים של התוסף
 */
class AT_Agency_Manager_Logger {
    private $table_name;

    /**
     * אתחול המחלקה וקביעת שם הטבלה
     */
    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'at_agency_manager_logs';
        
        // Register shutdown function to catch fatal errors
        register_shutdown_function(array($this, 'shutdown_handler'));
    }

    /**
     * טיפול בשגיאות קריטיות (Fatal Errors)
     */
    public function shutdown_handler() {
        $error = error_get_last();
        
        // Only handle fatal errors
        if ($error && in_array($error['type'], array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR, E_RECOVERABLE_ERROR))) {
            $message = "Fatal Error: {$error['message']} in {$error['file']} on line {$error['line']}";
            
            // Log to file directly since DB might be inaccessible during crash
            // We use a simplified version of write_to_file logic here
            if (get_option('at_agency_manager_enable_file_logging')) {
                $upload_dir = wp_upload_dir();
                $log_dir = $upload_dir['basedir'] . '/at-agency-manager-logs';
                
                if (file_exists($log_dir)) {
                    $date = date('Y-m-d');
                    $file_path = $log_dir . "/error-log-{$date}.log";
                    $time = date('Y-m-d H:i:s');
                    
                    $log_entry = "[{$time}] [system] [critical] [User: " . get_current_user_id() . "] " . $message . PHP_EOL;
                    
                    @file_put_contents($file_path, $log_entry, FILE_APPEND);
                }
            }
        }
    }

    /**
     * קבלת כתובת ה-IP של המשתמש
     *
     * @return string כתובת ה-IP
     */
    private function get_client_ip() {
        $ip = '';

        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }

        return sanitize_text_field($ip);
    }

    /**
     * רישום לוג כללי
     * 
     * @param string $type סוג הלוג
     * @param string $message הודעת הלוג
     * @param string $status סטטוס הפעולה (info, success, warning, error)
     * 
     * @return int|false מזהה הרשומה או false במקרה של כישלון
     */
    public function log($type, $message, $status = 'info') {
        global $wpdb;
        
        // Filter out Feature/Abilities API warnings as requested
        if ($type === 'feature_api' || $type === 'abilities_api' || 
            strpos($message, 'WordPress Feature API package not found') !== false ||
            strpos($message, 'WordPress Abilities API not found') !== false) {
            return false;
        }
        
        // בדיקה אם הטבלה קיימת
        if (!$this->table_exists()) {
            $this->create_table();
        }
        
        // וודא שהעמודות הנדרשות קיימות
        $this->ensure_columns_exist();
        
        // הוספת הקשר פיתוח אם קיים
        $context = apply_filters('at_agency_manager_log_context', array());
        $context_data = !empty($context) ? maybe_serialize($context) : null;

        // קבלת מידע נוסף לפיילוג
        $user_id = get_current_user_id();
        $ip_address = $this->get_client_ip();
        $development_mode = '';
        $site_type = get_option('at_agency_manager_site_type', 'production');

        if (function_exists('wp_get_development_mode')) {
            $development_mode = wp_get_development_mode();
        } elseif (defined('WP_DEVELOPMENT_MODE')) {
            $development_mode = WP_DEVELOPMENT_MODE;
        }

        // כתיבה לקובץ אם מופעל
        $this->write_to_file($type, $message, $status, $context_data);

        // עטוף בחריגה לתפיסת שגיאות DB
        try {
            return $wpdb->insert(
                $this->table_name,
                array(
                    'type' => $type,
                    'message' => $message,
                    'status' => $status,
                    'created_at' => current_time('mysql'),
                    'user_id' => $user_id,
                    'ip_address' => $ip_address,
                    'context' => $context_data,
                    'development_mode' => $development_mode,
                    'site_type' => $site_type
                ),
                array('%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s')
            );
        } catch (Exception $e) {
            // אם הלוג נכשל, לא להשליך שגיאה כדי לא להוביל קריסה
            error_log('[AT Agency Manager Logger Error] ' . $e->getMessage());
            return false;
        }
    }

    /**
     * כתיבת לוג לקובץ אם האפשרות מופעלת
     */
    private function write_to_file($type, $message, $status, $context_data = null) {
        // בדיקה אם רישום לקובץ מופעל
        if (!get_option('at_agency_manager_enable_file_logging')) {
            return;
        }

        $upload_dir = wp_upload_dir();
        $log_dir = $upload_dir['basedir'] . '/at-agency-manager-logs';

        // יצירת התיקייה אם לא קיימת
        if (!file_exists($log_dir)) {
            wp_mkdir_p($log_dir);
            // הוספת הגנה לתיקייה
            file_put_contents($log_dir . '/.htaccess', 'deny from all');
            file_put_contents($log_dir . '/index.php', '<?php // Silence is golden');
        }

        $date = date('Y-m-d');
        
        // בחירת קובץ יעד בהתאם לרמת החומרה
        if (in_array($status, array('error', 'warning', 'critical'))) {
            $base_filename = "error-log-{$date}";
        } else {
            $base_filename = "info-log-{$date}";
        }
        
        $ext = ".log";
        
        $filename = $base_filename . $ext;
        $file_path = $log_dir . '/' . $filename;
        $max_size = 10 * 1024 * 1024; // 10MB

        $counter = 0;
        
        // בדיקת גודל הקובץ ורוטציה
        while (file_exists($file_path) && filesize($file_path) >= $max_size) {
            $counter++;
            $filename = $base_filename . '-' . $counter . $ext;
            $file_path = $log_dir . '/' . $filename;
        }
        
        // הכנת שורת הלוג
        $time = date('Y-m-d H:i:s');
        $user_id = get_current_user_id();
        $ip = $this->get_client_ip();
        
        $context_str = '';
        if ($context_data) {
            $context_unserialized = maybe_unserialize($context_data);
            $context_str = is_array($context_unserialized) || is_object($context_unserialized) 
                ? json_encode($context_unserialized, JSON_UNESCAPED_UNICODE) 
                : $context_unserialized;
            $context_str = " [Context: {$context_str}]";
        }
        
        $log_entry = "[{$time}] [{$type}] [{$status}] [User: {$user_id}] [IP: {$ip}] {$message}{$context_str}" . PHP_EOL;
        
        // כתיבה לקובץ
        file_put_contents($file_path, $log_entry, FILE_APPEND);
    }

    
    /**
     * וודא שכל העמודות הנדרשות קיימות
     */
    private function ensure_columns_exist() {
        global $wpdb;
        
        $columns = $wpdb->get_results("DESCRIBE {$this->table_name}");
        $column_names = array_map(function($col) { return $col->Field; }, $columns);
        
        // קביעת עמודות נדרשות ואפשריות
        $required_columns = array('status', 'user_id', 'ip_address', 'context', 'development_mode', 'site_type');
        
        foreach ($required_columns as $col) {
            if (!in_array($col, $column_names)) {
                $this->add_column_if_missing($col);
            }
        }
    }
    
    /**
     * הוסף עמודה אם חסרה
     */
    private function add_column_if_missing($column_name) {
        global $wpdb;
        
        $sql = '';
        switch ($column_name) {
            case 'status':
                $sql = "ALTER TABLE {$this->table_name} ADD COLUMN status varchar(20) NOT NULL DEFAULT 'info'";
                break;
            case 'user_id':
                $sql = "ALTER TABLE {$this->table_name} ADD COLUMN user_id bigint(20) unsigned DEFAULT NULL";
                break;
            case 'ip_address':
                $sql = "ALTER TABLE {$this->table_name} ADD COLUMN ip_address varchar(45) DEFAULT NULL";
                break;
            case 'context':
                $sql = "ALTER TABLE {$this->table_name} ADD COLUMN context longtext DEFAULT NULL";
                break;
            case 'development_mode':
                $sql = "ALTER TABLE {$this->table_name} ADD COLUMN development_mode varchar(20) DEFAULT NULL";
                break;
            case 'site_type':
                $sql = "ALTER TABLE {$this->table_name} ADD COLUMN site_type varchar(20) DEFAULT NULL";
                break;
        }
        
        if (!empty($sql)) {
            $wpdb->query($sql);
        }
    }
    
    /**
     * בדיקה אם הטבלה קיימת
     * 
     * @return bool true אם הטבלה קיימת, false אחרת
     */
    private function table_exists() {
        global $wpdb;
        
        $table_name = $this->table_name;
        $result = $wpdb->get_var($wpdb->prepare(
            "SHOW TABLES LIKE %s",
            $table_name
        ));
        
        return $result === $table_name;
    }
    
    /**
     * יצירת הטבלה במידה ולא קיימת
     * 
     * @return void
     */
    private function create_table() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS {$this->table_name} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            type varchar(50) NOT NULL,
            message text NOT NULL,
            status varchar(20) NOT NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            user_id bigint(20) unsigned DEFAULT NULL,
            ip_address varchar(45) DEFAULT NULL,
            context longtext DEFAULT NULL,
            file_path varchar(255) DEFAULT NULL,
            line_number int(11) DEFAULT NULL,
            development_mode varchar(20) DEFAULT NULL,
            site_type varchar(20) DEFAULT NULL,
            PRIMARY KEY (id),
            KEY idx_type_status (type, status),
            KEY idx_created_at (created_at),
            KEY idx_user_id (user_id),
            KEY idx_development_mode (development_mode)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    /**
     * רישום לוג של שליחת אימייל
     * 
     * @param string $to כתובת היעד
     * @param string $subject נושא המייל
     * @param string $status סטטוס השליחה
     * 
     * @return int|false מזהה הרשומה או false במקרה של כישלון
     */
    public function log_email($to, $subject, $status) {
        return $this->log('email', "To: $to, Subject: $subject", $status);
    }

    /**
     * רישום לוג של בקשת API
     * 
     * @param string $endpoint הנקודת קצה
     * @param string $status סטטוס הבקשה
     * 
     * @return int|false מזהה הרשומה או false במקרה של כישלון
     */
    public function log_api_request($endpoint, $status) {
        return $this->log('api', "Endpoint: $endpoint", $status);
    }

    /**
     * מחזיר את הלוגים האחרונים
     * 
     * @param int $limit מספר הרשומות לקבלה
     * 
     * @return array רשימת הלוגים
     */
    public function get_logs($limit = 100) {
        global $wpdb;
        
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$this->table_name} ORDER BY created_at DESC LIMIT %d",
                $limit
            )
        );
    }
}