<?php
/**
 * Module: Page Ordering - Shared helpers
 *
 * הפונקציות כאן משותפות למודול עצמו (modules/page-ordering.php) ולעמוד ההגדרות
 * (modules/page-ordering-settings.php). שני הקבצים עשויים להיטען בנפרד זה מזה,
 * ולכן ההגדרות נמצאות בקובץ ייעודי שנטען עם require_once משניהם.
 */

if (!defined('ABSPATH')) exit;

if (!function_exists('at_page_ordering_sanitize_slug_list')) {
    /**
     * נרמול ערך הגדרה לרשימת slugs נקייה.
     *
     * משמש גם כ-sanitize_callback ב-register_setting (מונע שמירת מחרוזת ריקה
     * כשאף checkbox לא סומן) וגם בקריאה מה-DB (מרפא רשומות ישנות שכבר מושחתות).
     *
     * @param mixed $value הערך הגולמי (מערך, מחרוזת, null וכו')
     * @return array רשימת slugs ייחודית ומאונדקסת מחדש
     */
    function at_page_ordering_sanitize_slug_list($value) {
        if (is_object($value)) {
            $value = get_object_vars($value);
        }

        if (!is_array($value)) {
            // מחרוזת בודדת נחשבת לרשימה בת פריט אחד; כל שאר הטיפוסים -> רשימה ריקה
            $value = (is_string($value) && '' !== trim($value)) ? array($value) : array();
        }

        $clean = array();

        foreach ($value as $item) {
            if (!is_scalar($item)) {
                continue;
            }

            $item = sanitize_key((string) $item);

            if ('' === $item) {
                continue;
            }

            $clean[] = $item;
        }

        return array_values(array_unique($clean));
    }
}

if (!function_exists('at_page_ordering_get_enabled_post_types')) {
    /**
     * סוגי התוכן שהופעלו לגרירה ושחרור.
     *
     * @return array
     */
    function at_page_ordering_get_enabled_post_types() {
        return at_page_ordering_sanitize_slug_list(get_option('at_page_ordering_post_types', array()));
    }
}

if (!function_exists('at_page_ordering_get_enabled_taxonomies')) {
    /**
     * הטקסונומיות שהופעלו לגרירה ושחרור.
     *
     * @return array
     */
    function at_page_ordering_get_enabled_taxonomies() {
        return at_page_ordering_sanitize_slug_list(get_option('at_page_ordering_taxonomies', array()));
    }
}
