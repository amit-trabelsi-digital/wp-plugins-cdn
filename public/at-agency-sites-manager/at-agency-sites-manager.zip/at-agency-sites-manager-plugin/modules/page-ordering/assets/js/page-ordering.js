/**
 * AT Page Ordering - JavaScript
 * פונקציונליות גרירה ושחרור עבור הזמנה מותאמת אישית
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        // אתחול גרירה ושחרור
        initSortable();

        // אתחול אירועי שחזור סדר
        initResetOrder();
    });

    /**
     * אתחול פונקציונליות גרירה ושחרור
     */
    function initSortable() {
        // בדיקה אם יש טבלאות עם sortable
        var $sortableTable = $('.wp-list-table tbody');

        if ($sortableTable.length === 0) {
            return;
        }

        // הוספת מחלקה sortable
        $sortableTable.addClass('ui-sortable');

        // אתחול sortable
        $sortableTable.sortable({
            items: 'tr:not(.inline-edit-row)',
            cursor: 'move',
            axis: 'y',
            handle: '.column-title, .column-name',
            placeholder: 'sortable-placeholder',
            start: function(event, ui) {
                ui.placeholder.height(ui.item.height());
                ui.item.addClass('sortable-item');
            },
            update: function(event, ui) {
                updateOrder();
            },
            stop: function(event, ui) {
                ui.item.removeClass('sortable-item');
            }
        });

        // הוספת סטיילינג למחוון גרירה
        addDragIndicator();
    }

    /**
     * הוספת מחוון גרירה לעמודות
     */
    function addDragIndicator() {
        $('.wp-list-table thead th.column-title').each(function() {
            var $th = $(this);
            if (!$th.find('.dashicons-move').length) {
                $th.prepend('<span class="dashicons dashicons-move" style="margin-left: 5px; opacity: 0.5;"></span>');
            }
        });
    }

    /**
     * עדכון סדר הפוסטים בשרת
     */
    function updateOrder() {
        var orderData = $('.wp-list-table tbody').sortable('serialize');
        var postType = getQueryParameter('post_type') || 'post';

        // הוספת סוג התוכן לנתונים
        orderData += '&post_type=' + postType;

        // הצגת טעינה
        showLoading();

        $.ajax({
            url: at_page_ordering_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'at_update_menu_order',
                order: orderData,
                nonce: at_page_ordering_vars.nonce
            },
            success: function(response) {
                hideLoading();
                showSuccessMessage();

                // לוג
                console.log('Page ordering updated successfully');

                // רענון העמוד לאחר זמן קצר
                setTimeout(function() {
                    window.location.reload();
                }, 1000);
            },
            error: function(xhr, status, error) {
                hideLoading();
                showErrorMessage(xhr.responseText || error);

                // שחזור הסדר הישן במקרה של שגיאה
                $('.wp-list-table tbody').sortable('cancel');
            }
        });
    }

    /**
     * קבלת פרמטר מ-URL
     */
    function getQueryParameter(name) {
        var url = window.location.href;
        name = name.replace(/[\[\]]/g, '\\$&');
        var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)');
        var results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, ' '));
    }

    /**
     * הצגת טעינה
     */
    function showLoading() {
        if (!$('#at-page-ordering-loading').length) {
            $('body').append('<div id="at-page-ordering-loading" style="position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; padding: 20px; border: 1px solid #ccc; border-radius: 4px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); z-index: 9999;"><div style="display: flex; align-items: center;"><div class="spinner" style="margin-right: 10px;"></div><span>' + (typeof at_page_ordering_vars !== 'undefined' && at_page_ordering_vars.loading_text ? at_page_ordering_vars.loading_text : 'מעדכן סדר...') + '</span></div></div>');
        }
        $('#at-page-ordering-loading').show();
    }

    /**
     * הסתרת טעינה
     */
    function hideLoading() {
        $('#at-page-ordering-loading').hide();
    }

    /**
     * הצגת הודעת הצלחה
     */
    function showSuccessMessage() {
        var message = typeof at_page_ordering_vars !== 'undefined' && at_page_ordering_vars.success_text ? at_page_ordering_vars.success_text : 'הסדר עודכן בהצלחה!';
        showNotice(message, 'success');
    }

    /**
     * הצגת הודעת שגיאה
     */
    function showErrorMessage(message) {
        message = message || (typeof at_page_ordering_vars !== 'undefined' && at_page_ordering_vars.error_text ? at_page_ordering_vars.error_text : 'אירעה שגיאה בעדכון הסדר');
        showNotice(message, 'error');
    }

    /**
     * הצגת הודעה כללית
     */
    function showNotice(message, type) {
        var noticeClass = type === 'success' ? 'notice-success' : 'notice-error';

        // הסרת הודעות קיימות
        $('.at-page-ordering-notice').remove();

        // יצירת הודעה חדשה
        var $notice = $('<div class="notice ' + noticeClass + ' is-dismissible at-page-ordering-notice"><p>' + message + '</p></div>');

        // הוספת כפתור סגירה
        $notice.append('<button type="button" class="notice-dismiss"><span class="screen-reader-text">סגור הודעה זו</span></button>');

        // הוספת האירוע לכפתור סגירה
        $notice.find('.notice-dismiss').on('click', function() {
            $notice.fadeOut(function() {
                $notice.remove();
            });
        });

        // הוספת ההודעה לעמוד
        $('.wp-header-end').after($notice);

        // הסתרת אוטומטית לאחר 5 שניות
        setTimeout(function() {
            $notice.fadeOut(function() {
                $notice.remove();
            });
        }, 5000);
    }

    /**
     * אתחול אירועי איפוס סדר
     */
    function initResetOrder() {
        // אירוע לכפתור איפוס סדר (אם קיים)
        $(document).on('click', '.at-reset-order-btn', function(e) {
            e.preventDefault();

            if (!confirm('האם אתה בטוח שברצונך לאפס את הסדר? פעולה זו תחזיר את הסדר המקורי.')) {
                return;
            }

            var postTypes = $(this).data('post-types') || [];
            resetOrder(postTypes);
        });
    }

    /**
     * איפוס סדר הפוסטים
     */
    function resetOrder(postTypes) {
        showLoading();

        $.ajax({
            url: at_page_ordering_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'at_reset_order',
                post_types: postTypes,
                nonce: at_page_ordering_vars.nonce
            },
            success: function(response) {
                hideLoading();
                showSuccessMessage();

                // רענון העמוד
                setTimeout(function() {
                    window.location.reload();
                }, 1000);
            },
            error: function(xhr, status, error) {
                hideLoading();
                showErrorMessage(xhr.responseText || error);
            }
        });
    }

    /**
     * תמיכה ב-RTL
     */
    function isRTL() {
        return $('html').attr('dir') === 'rtl' || $('body').hasClass('rtl');
    }

    /**
     * התאמות RTL
     */
    if (isRTL()) {
        // התאמות לכיוון ימין לשמאל
        $('.ui-sortable-handle').css({
            'margin-right': '5px',
            'margin-left': '0'
        });
    }

})(jQuery);
