<?php
/**
 * S3 Media Sync Module for AT Agency Sites Manager
 *
 * This module provides S3 media synchronization functionality
 * integrated with the AT Agency Sites Manager plugin.
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_S3_Media_Sync_Module {

    /**
     * Module settings
     */
    private $settings;

    /**
     * S3 Media Sync instance
     */
    private $s3_sync;

    /**
     * Constructor
     */
    public function __construct() {
        $this->settings = get_option('at_agency_manager_s3_sync_settings', []);
        add_action('plugins_loaded', [$this, 'init']);
    }

    /**
     * Initialize the module
     */
    public function init() {
        // Check if module is enabled
        $modules = get_option('at_agency_manager_modules', []);
        if (empty($modules['s3_media_sync'])) {
            return;
        }

        // Load required files
        $this->load_dependencies();

        // Initialize S3 sync
        $this->initialize_s3_sync();

        // Add admin menu
        add_action('admin_menu', [$this, 'add_admin_menu']);

        // Add settings
        add_action('admin_init', [$this, 'register_settings']);
    }

    /**
     * Load module dependencies
     */
    private function load_dependencies() {
        $module_path = AT_AGENCY_MANAGER_PATH . 'modules/s3-media-sync/inc/';

        // Load value objects first
        require_once $module_path . 'value-objects/class-region.php';
        require_once $module_path . 'value-objects/class-s3-bucket.php';
        require_once $module_path . 'value-objects/class-local-file.php';
        require_once $module_path . 'value-objects/class-s3-file.php';
        require_once $module_path . 'value-objects/class-file-comparison.php';
        require_once $module_path . 'value-objects/class-wordpress-attachment.php';

        // Load exceptions
        require_once $module_path . 'exceptions/class-invalid-bucket-exception.php';
        require_once $module_path . 'exceptions/class-invalid-file-exception.php';
        require_once $module_path . 'exceptions/class-invalid-region-exception.php';

        // Load main classes
        require_once $module_path . 'class-s3-media-sync-client-factory.php';
        require_once $module_path . 'class-s3-media-sync-stream-wrapper.php';
        require_once $module_path . 'class-s3-media-sync-tester.php';
        require_once $module_path . 'class-s3-media-sync-settings.php';
        require_once $module_path . 'class-s3-media-sync-wp-cli.php';
        require_once $module_path . 'class-s3-media-sync.php';

        // Load additional classes
        require_once $module_path . '../includes/class-s3-privacy-manager.php';
    }

    /**
     * Initialize S3 sync
     */
    private function initialize_s3_sync() {
        // Initialize settings handler
        $settings_handler = new S3_Media_Sync_Settings();

        // Override settings with module settings if available
        if (!empty($this->settings)) {
            $settings_handler->update_settings($this->settings);
        }

        // Initialize S3 sync
        $this->s3_sync = new S3_Media_Sync($settings_handler);
        $this->s3_sync->setup();

        // Store reference for later use
        $this->settings_handler = $settings_handler;

        // Add privacy filters
        $this->add_privacy_filters();
    }

    /**
     * Add privacy-related filters
     */
    private function add_privacy_filters() {
        // Hook into WordPress upload to add privacy headers
        add_filter('wp_handle_upload', [$this, 'add_privacy_headers_to_upload'], 20, 2);
        add_filter('wp_update_attachment_metadata', [$this, 'add_privacy_headers_to_metadata'], 20, 2);

        // Hook into S3 sync to modify ACL and headers
        add_filter('s3_media_sync_upload_params', [$this, 'modify_s3_upload_params'], 10, 3);

        // Add attachment privacy controls
        add_filter('attachment_fields_to_edit', [$this, 'add_attachment_privacy_fields'], 10, 2);
        add_filter('attachment_fields_to_save', [$this, 'save_attachment_privacy_fields'], 10, 2);
    }

    /**
     * Add privacy headers to uploaded files
     */
    public function add_privacy_headers_to_upload($upload, $context = 'upload') {
        $settings = get_option('at_agency_manager_s3_sync_settings', []);

        if (empty($settings['search_engine_block']) && empty($settings['hotlink_protection'])) {
            return $upload;
        }

        // Store privacy settings in file metadata for later use
        if (isset($upload['file'])) {
            $privacy_meta = [];

            if (!empty($settings['search_engine_block'])) {
                $privacy_meta['x_robots_tag'] = 'noindex,nofollow,noarchive,nosnippet';
            }

            if (!empty($settings['hotlink_protection']) && !empty($settings['allowed_domains'])) {
                $privacy_meta['allowed_domains'] = explode(',', $settings['allowed_domains']);
            }

            if (!empty($privacy_meta)) {
                update_post_meta($upload['attachment_id'] ?? 0, '_s3_privacy_settings', $privacy_meta);
            }
        }

        return $upload;
    }

    /**
     * Add privacy headers to attachment metadata
     */
    public function add_privacy_headers_to_metadata($metadata, $attachment_id) {
        $settings = get_option('at_agency_manager_s3_sync_settings', []);

        if (empty($settings['search_engine_block']) && empty($settings['hotlink_protection'])) {
            return $metadata;
        }

        $privacy_meta = [];

        if (!empty($settings['search_engine_block'])) {
            $privacy_meta['x_robots_tag'] = 'noindex,nofollow,noarchive,nosnippet';
        }

        if (!empty($settings['hotlink_protection']) && !empty($settings['allowed_domains'])) {
            $privacy_meta['allowed_domains'] = explode(',', $settings['allowed_domains']);
        }

        if (!empty($privacy_meta)) {
            update_post_meta($attachment_id, '_s3_privacy_settings', $privacy_meta);
        }

        return $metadata;
    }

    /**
     * Modify S3 upload parameters based on privacy settings
     */
    public function modify_s3_upload_params($params, $file_path, $attachment_id = null) {
        $settings = get_option('at_agency_manager_s3_sync_settings', []);
        $privacy_level = $settings['privacy_level'] ?? 'public';

        // Get privacy settings from attachment metadata
        $privacy_meta = [];
        if ($attachment_id) {
            $privacy_meta = get_post_meta($attachment_id, '_s3_privacy_settings', true) ?: [];
        }

        // Set ACL based on privacy level
        switch ($privacy_level) {
            case 'private':
                $params['ACL'] = 'private';
                break;
            case 'authenticated':
                $params['ACL'] = 'authenticated-read';
                break;
            case 'restricted':
                $params['ACL'] = 'bucket-owner-read';
                break;
            case 'public':
            default:
                $params['ACL'] = $settings['object_acl'] ?? 'public-read';
                break;
        }

        // Add privacy headers
        $params['Metadata'] = $params['Metadata'] ?? [];

        // Search engine blocking
        if (!empty($privacy_meta['x_robots_tag'])) {
            $params['Metadata']['x-robots-tag'] = $privacy_meta['x_robots_tag'];
        } elseif (!empty($settings['search_engine_block'])) {
            $params['Metadata']['x-robots-tag'] = 'noindex,nofollow,noarchive,nosnippet';
        }

        // Hotlink protection
        if (!empty($privacy_meta['allowed_domains'])) {
            $params['Metadata']['allowed-domains'] = implode(',', $privacy_meta['allowed_domains']);
        } elseif (!empty($settings['hotlink_protection']) && !empty($settings['allowed_domains'])) {
            $params['Metadata']['allowed-domains'] = $settings['allowed_domains'];
        }

        // Add cache control for private files
        if ($privacy_level !== 'public') {
            $params['CacheControl'] = 'private, max-age=0';
        }

        return $params;
    }

    /**
     * Add privacy fields to attachment edit screen
     */
    public function add_attachment_privacy_fields($form_fields, $post) {
        $settings = get_option('at_agency_manager_s3_sync_settings', []);

        if (empty($settings['bucket'])) {
            return $form_fields;
        }

        $privacy_level = get_post_meta($post->ID, '_s3_privacy_level', true) ?: 'public';
        $privacy_meta = get_post_meta($post->ID, '_s3_privacy_settings', true) ?: [];

        // Privacy Level Field
        $form_fields['s3_privacy_level'] = [
            'label' => __('S3 Privacy Level', 'at-agency-manager'),
            'input' => 'html',
            'html' => '<select name="attachments[' . $post->ID . '][s3_privacy_level]" id="s3_privacy_level_' . $post->ID . '">
                <option value="public" ' . selected($privacy_level, 'public', false) . '>' . __('Public', 'at-agency-manager') . '</option>
                <option value="private" ' . selected($privacy_level, 'private', false) . '>' . __('Private (Signed URL)', 'at-agency-manager') . '</option>
                <option value="authenticated" ' . selected($privacy_level, 'authenticated', false) . '>' . __('Authenticated Users Only', 'at-agency-manager') . '</option>
                <option value="restricted" ' . selected($privacy_level, 'restricted', false) . '>' . __('Restricted', 'at-agency-manager') . '</option>
            </select>',
            'helps' => __('Control who can access this file in S3', 'at-agency-manager')
        ];

        // Search Engine Block Field
        $form_fields['s3_search_engine_block'] = [
            'label' => __('Block Search Engines', 'at-agency-manager'),
            'input' => 'html',
            'html' => '<input type="checkbox" name="attachments[' . $post->ID . '][s3_search_engine_block]" id="s3_search_engine_block_' . $post->ID . '" value="1" ' .
                checked($privacy_meta['search_engine_block'] ?? false, true, false) . ' />
                <label for="s3_search_engine_block_' . $post->ID . '">' . __('Block Google, Bing and other search engines', 'at-agency-manager') . '</label>',
            'helps' => __('Prevent search engines from indexing this specific file', 'at-agency-manager')
        ];

        return $form_fields;
    }

    /**
     * Save privacy fields when attachment is updated
     */
    public function save_attachment_privacy_fields($post, $attachment) {
        if (isset($attachment['s3_privacy_level'])) {
            update_post_meta($post['ID'], '_s3_privacy_level', sanitize_text_field($attachment['s3_privacy_level']));
        }

        if (isset($attachment['s3_search_engine_block'])) {
            $privacy_meta = get_post_meta($post['ID'], '_s3_privacy_settings', true) ?: [];
            $privacy_meta['search_engine_block'] = intval($attachment['s3_search_engine_block']);

            if ($privacy_meta['search_engine_block']) {
                $privacy_meta['x_robots_tag'] = 'noindex,nofollow,noarchive,nosnippet';
            } else {
                unset($privacy_meta['x_robots_tag']);
            }

            update_post_meta($post['ID'], '_s3_privacy_settings', $privacy_meta);
        }

        return $post;
    }

    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_submenu_page(
            'at-agency-manager',
            __('S3 Media Sync', 'at-agency-manager'),
            __('S3 Media Sync', 'at-agency-manager'),
            'manage_options',
            'at-agency-s3-sync',
            [$this, 'render_admin_page']
        );
    }

    /**
     * Register settings
     */
    public function register_settings() {
        register_setting(
            'at_agency_s3_sync_settings',
            'at_agency_manager_s3_sync_settings',
            [$this, 'validate_settings']
        );

        add_settings_section(
            'at_agency_s3_sync_main',
            __('S3 Media Sync Settings', 'at-agency-manager'),
            null,
            'at_agency_s3_sync_settings'
        );

        // Add settings fields that mirror the original plugin
        add_settings_field(
            's3_key',
            __('AWS Access Key ID', 'at-agency-manager'),
            [$this, 'render_key_field'],
            'at_agency_s3_sync_settings',
            'at_agency_s3_sync_main'
        );

        add_settings_field(
            's3_secret',
            __('AWS Secret Access Key', 'at-agency-manager'),
            [$this, 'render_secret_field'],
            'at_agency_s3_sync_settings',
            'at_agency_s3_sync_main'
        );

        add_settings_field(
            's3_bucket',
            __('S3 Bucket Name', 'at-agency-manager'),
            [$this, 'render_bucket_field'],
            'at_agency_s3_sync_settings',
            'at_agency_s3_sync_main'
        );

        add_settings_field(
            's3_region',
            __('S3 Region', 'at-agency-manager'),
            [$this, 'render_region_field'],
            'at_agency_s3_sync_settings',
            'at_agency_s3_sync_main'
        );

        add_settings_field(
            'use_acl',
            __('Use ACLs', 'at-agency-manager'),
            [$this, 'render_acl_field'],
            'at_agency_s3_sync_settings',
            'at_agency_s3_sync_main'
        );

        add_settings_field(
            'object_acl',
            __('Object ACL', 'at-agency-manager'),
            [$this, 'render_object_acl_field'],
            'at_agency_s3_sync_settings',
            'at_agency_s3_sync_main'
        );

        add_settings_field(
            'sync_thumbnails',
            __('Sync Thumbnails', 'at-agency-manager'),
            [$this, 'render_thumbnails_field'],
            'at_agency_s3_sync_settings',
            'at_agency_s3_sync_main'
        );

        add_settings_field(
            'privacy_level',
            __('Privacy Level', 'at-agency-manager'),
            [$this, 'render_privacy_level_field'],
            'at_agency_s3_sync_settings',
            'at_agency_s3_sync_main'
        );

        add_settings_field(
            'search_engine_block',
            __('Block Search Engines', 'at-agency-manager'),
            [$this, 'render_search_engine_block_field'],
            'at_agency_s3_sync_settings',
            'at_agency_s3_sync_main'
        );

        add_settings_field(
            'hotlink_protection',
            __('Hotlink Protection', 'at-agency-manager'),
            [$this, 'render_hotlink_protection_field'],
            'at_agency_s3_sync_settings',
            'at_agency_s3_sync_main'
        );
    }

    /**
     * Validate settings
     */
    public function validate_settings($input) {
        // Use the original validation logic
        if ($this->settings_handler) {
            return $this->settings_handler->settings_validation($input);
        }
        return $input;
    }

    /**
     * Render admin page
     */
    public function render_admin_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }

        ?>
        <div class="wrap">
            <h1><?php _e('S3 Media Sync', 'at-agency-manager'); ?></h1>

            <div class="notice notice-info">
                <p><?php _e('This module integrates S3 Media Sync functionality for automatic media file synchronization to Amazon S3.', 'at-agency-manager'); ?></p>
            </div>

            <form action="options.php" method="post">
                <?php
                settings_fields('at_agency_s3_sync_settings');
                do_settings_sections('at_agency_s3_sync_settings');
                submit_button();
                ?>
            </form>

            <?php
            // Test access button
            $saved_settings = get_option('at_agency_manager_s3_sync_settings', []);
            $has_saved_settings = !empty($saved_settings['bucket']) &&
                                  !empty($saved_settings['key']) &&
                                  !empty($saved_settings['secret']) &&
                                  !empty($saved_settings['region']);

            if ($has_saved_settings):
            ?>
                <hr>
                <h3><?php _e('Test S3 Access', 'at-agency-manager'); ?></h3>
                <p><?php _e('Click the button below to test if your credentials have the required permissions.', 'at-agency-manager'); ?></p>
                <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
                    <?php wp_nonce_field('at_agency_s3_sync_test_access'); ?>
                    <input type="hidden" name="action" value="at_agency_s3_sync_test_access">
                    <?php submit_button(__('Test S3 Access', 'at-agency-manager'), 'secondary', 'submit', false); ?>
                </form>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Render settings fields
     */
    public function render_key_field() {
        $options = get_option('at_agency_manager_s3_sync_settings');
        $value = !empty($options['key']) ? $options['key'] : '';
        printf(
            '<input type="text" name="at_agency_manager_s3_sync_settings[key]" value="%s" class="regular-text" />',
            esc_attr($value)
        );
    }

    public function render_secret_field() {
        $options = get_option('at_agency_manager_s3_sync_settings');
        $value = !empty($options['secret']) ? $options['secret'] : '';
        printf(
            '<input type="password" name="at_agency_manager_s3_sync_settings[secret]" value="%s" class="regular-text" />',
            esc_attr($value)
        );
    }

    public function render_bucket_field() {
        $options = get_option('at_agency_manager_s3_sync_settings');
        $value = !empty($options['bucket']) ? $options['bucket'] : '';
        printf(
            '<input type="text" name="at_agency_manager_s3_sync_settings[bucket]" value="%s" class="regular-text" />',
            esc_attr($value)
        );
    }

    public function render_region_field() {
        $options = get_option('at_agency_manager_s3_sync_settings');
        $current_value = !empty($options['region']) ? $options['region'] : '';

        // Include the Region class
        if (class_exists('S3_Media_Sync\Region')) {
            $valid_regions = \S3_Media_Sync\Region::get_valid_regions();
        } else {
            $valid_regions = ['us-east-1', 'us-west-1', 'us-west-2', 'eu-west-1', 'eu-central-1', 'ap-southeast-1'];
        }

        echo '<select name="at_agency_manager_s3_sync_settings[region]" class="regular-text">';
        echo '<option value="">' . esc_html__('Select Region', 'at-agency-manager') . '</option>';

        foreach ($valid_regions as $region) {
            printf(
                '<option value="%s" %s>%s</option>',
                esc_attr($region),
                selected($current_value, $region, false),
                esc_html($region)
            );
        }
        echo '</select>';
    }

    public function render_acl_field() {
        $options = get_option('at_agency_manager_s3_sync_settings');
        $checked = isset($options['use_acl']) ? checked($options['use_acl'], '1', false) : '';
        printf(
            '<input type="checkbox" name="at_agency_manager_s3_sync_settings[use_acl]" value="1" %s />',
            $checked
        );
        echo '<label>' . __('Enable ACL settings for objects', 'at-agency-manager') . '</label>';
    }

    public function render_object_acl_field() {
        $options = get_option('at_agency_manager_s3_sync_settings');
        $value = !empty($options['object_acl']) ? $options['object_acl'] : 'public-read';

        echo '<select name="at_agency_manager_s3_sync_settings[object_acl]">';
        printf('<option value="private" %s>%s</option>', selected($value, 'private', false), __('Private', 'at-agency-manager'));
        printf('<option value="public-read" %s>%s</option>', selected($value, 'public-read', false), __('Public Read', 'at-agency-manager'));
        echo '</select>';
    }

    public function render_thumbnails_field() {
        $options = get_option('at_agency_manager_s3_sync_settings');
        $checked = isset($options['sync_thumbnails']) ? checked($options['sync_thumbnails'], '1', false) : 'checked="checked"';
        printf(
            '<input type="checkbox" name="at_agency_manager_s3_sync_settings[sync_thumbnails]" value="1" %s />',
            $checked
        );
        echo '<label>' . __('Sync image thumbnails and size variations to S3', 'at-agency-manager') . '</label>';
    }

    public function render_privacy_level_field() {
        $options = get_option('at_agency_manager_s3_sync_settings');
        $current_value = !empty($options['privacy_level']) ? $options['privacy_level'] : 'public';

        echo '<select name="at_agency_manager_s3_sync_settings[privacy_level]">';
        printf('<option value="public" %s>%s</option>', selected($current_value, 'public', false), __('Public - Open to everyone', 'at-agency-manager'));
        printf('<option value="private" %s>%s</option>', selected($current_value, 'private', false), __('Private - Signed URLs only', 'at-agency-manager'));
        printf('<option value="authenticated" %s>%s</option>', selected($current_value, 'authenticated', false), __('Authenticated - WordPress users only', 'at-agency-manager'));
        printf('<option value="restricted" %s>%s</option>', selected($current_value, 'restricted', false), __('Restricted - Custom rules', 'at-agency-manager'));
        echo '</select>';
        echo '<p class="description">' . __('Choose the default privacy level for uploaded files', 'at-agency-manager') . '</p>';
    }

    public function render_search_engine_block_field() {
        $options = get_option('at_agency_manager_s3_sync_settings');
        $checked = isset($options['search_engine_block']) ? checked($options['search_engine_block'], '1', false) : '';
        printf(
            '<input type="checkbox" name="at_agency_manager_s3_sync_settings[search_engine_block]" value="1" %s />',
            $checked
        );
        echo '<label>' . __('Block search engines (Google, Bing, etc.) from indexing files', 'at-agency-manager') . '</label>';
        echo '<p class="description">' . __('Adds X-Robots-Tag header to prevent search engine indexing', 'at-agency-manager') . '</p>';
    }

    public function render_hotlink_protection_field() {
        $options = get_option('at_agency_manager_s3_sync_settings');
        $checked = isset($options['hotlink_protection']) ? checked($options['hotlink_protection'], '1', false) : '';
        printf(
            '<input type="checkbox" name="at_agency_manager_s3_sync_settings[hotlink_protection]" value="1" %s />',
            $checked
        );
        echo '<label>' . __('Enable hotlink protection', 'at-agency-manager') . '</label>';
        echo '<p class="description">' . __('Restrict access to specific domains only', 'at-agency-manager') . '</p>';

        $allowed_domains = !empty($options['allowed_domains']) ? $options['allowed_domains'] : get_site_url();
        printf(
            '<br><input type="text" name="at_agency_manager_s3_sync_settings[allowed_domains]" value="%s" class="regular-text" placeholder="example.com,yourdomain.com" />',
            esc_attr($allowed_domains)
        );
        echo '<p class="description">' . __('Comma-separated list of allowed domains (leave empty to allow all)', 'at-agency-manager') . '</p>';
    }

    /**
     * Handle test access
     */
    public function handle_test_access() {
        check_admin_referer('at_agency_s3_sync_test_access');

        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'at-agency-manager'));
        }

        // Use the tester class to handle testing
        $tester = new S3_Media_Sync_Tester($this->settings);
        $tester->run_tests();

        // Redirect back to the settings page
        set_transient('settings_errors', get_settings_errors(), 30);
        wp_redirect(add_query_arg('settings-updated', 'true', wp_get_referer()));
        exit;
    }

    /**
     * Get module info
     */
    public static function get_module_info() {
        return [
            'name' => 'S3 Media Sync',
            'description' => __('Automatically sync media uploads to Amazon S3', 'at-agency-manager'),
            'version' => '1.4.1',
            'requires' => ['PHP 8.1+', 'AWS SDK'],
            'features' => [
                __('Automatic S3 upload on media upload', 'at-agency-manager'),
                __('Thumbnail synchronization', 'at-agency-manager'),
                __('WP-CLI integration', 'at-agency-manager'),
                __('ACL configuration', 'at-agency-manager')
            ]
        ];
    }
}

// Initialize the module if accessed directly
if (!function_exists('at_agency_manager_s3_sync_init')) {
    function at_agency_manager_s3_sync_init() {
        new AT_S3_Media_Sync_Module();
    }
    add_action('plugins_loaded', 'at_agency_manager_s3_sync_init');
}

// Handle test access action
add_action('admin_post_at_agency_s3_sync_test_access', function() {
    $module = new AT_S3_Media_Sync_Module();
    $module->handle_test_access();
});
