<?php
/**
 * Module: Site Health Panel
 * מציג וידג'ט בריאות אתר בלוח המחוונים ו-REST API לקבלת המידע JSON.
 */

if (!defined('ABSPATH')) exit;

class AT_Site_Health {
    public function __construct() {
        add_action('wp_dashboard_setup', [$this, 'register_widget']);
        add_action('rest_api_init', [$this, 'register_rest']);
    }

    // ---------------------------------------------------------------
    // Dashboard Widget
    // ---------------------------------------------------------------
    public function register_widget() {
        wp_add_dashboard_widget('at_site_health', __('AT Site Health', 'at-agency-manager'), [$this, 'render_widget']);
    }

    public function render_widget() {
        $data = $this->get_health_data();
        ?>
        <style>#at-site-health td{padding:4px 10px;} .status-good{color:#46b450} .status-bad{color:#dc3232}</style>
        <table id="at-site-health" class="widefat">
            <tbody>
                <?php foreach ($data as $key => $value): ?>
                    <tr>
                        <td><strong><?php echo esc_html(ucwords(str_replace('_', ' ', $key))); ?></strong></td>
                        <td class="<?php echo is_bool($value) ? ($value ? 'status-good' : 'status-bad') : ''; ?>">
                            <?php
                            if (is_bool($value)) {
                                echo $value ? __('OK', 'at-agency-manager') : __('Issue', 'at-agency-manager');
                            } else {
                                echo esc_html($value);
                            }
                            ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div style="margin-top:15px; padding:15px; border:1px solid #ccd0d4; background:#fff;">
            <h3 style="margin-top:0;"><?php _e('Connect to AT External Sites Manager', 'at-agency-manager'); ?></h3>
            <p><?php _e('Click the button below to send site info and connect this site to the external dashboard.', 'at-agency-manager'); ?></p>
            <button id="at-connect-btn" class="button button-primary"><?php _e('Connect Site', 'at-agency-manager'); ?></button>
            <span id="at-connect-result"></span>
            <script>
            jQuery(function($){
                $('#at-connect-btn').on('click',function(){
                    window.location.href = <?php echo wp_json_encode(admin_url('tools.php?page=at-site-control')); ?>;
                });
            });
            </script>
        </div>
        <?php
    }

    // ---------------------------------------------------------------
    // REST API
    // ---------------------------------------------------------------
    public function register_rest() {
        register_rest_route('at-agency-manager/v1', '/site-health', [
            'methods'  => 'GET',
            'callback' => function() { return $this->get_health_data(); },
            'permission_callback' => [$this, 'check_rest_permission'],
        ]);
    }

    public function check_rest_permission($request) {
        if (current_user_can('manage_options')) {
            return true;
        }

        if (class_exists('AT_Agency_Manager_Environment') && !AT_Agency_Manager_Environment::is_remote_api_allowed()) {
            return new WP_Error(
                'rest_forbidden',
                __('Remote API is disabled.', 'at-agency-manager'),
                ['status' => 403]
            );
        }

        $provided = (string) $request->get_header('X-AT-Agency-Manager-Key');
        $stored = (string) get_option('at_agency_manager_auth_key', '');

        if ($provided !== '' && $stored !== '' && hash_equals($stored, $provided)) {
            return true;
        }

        return new WP_Error(
            'rest_forbidden',
            __('Authentication required.', 'at-agency-manager'),
            ['status' => 401]
        );
    }

    private function get_health_data() {
        global $wpdb; $upload = wp_upload_dir();
        $core_update = false; $update_core = get_site_transient('update_core');
        if ($update_core && !empty($update_core->updates)) {
            foreach ($update_core->updates as $u) { if ($u->response === 'upgrade') { $core_update = true; break; } }
        }

        $data = [
            'php_version'        => PHP_VERSION,
            'mysql_version'      => $wpdb->db_version(),
            'wp_version'         => get_bloginfo('version'),
            'memory_limit'       => WP_MEMORY_LIMIT,
            'max_execution_time' => ini_get('max_execution_time'),
            'db_connection'      => $wpdb->check_connection(),
            'uploads_writable'   => wp_is_writable($upload['basedir']),
            'plugins_need_update'=> function_exists('wp_get_update_data') ? wp_get_update_data()['counts']['plugins'] : 0,
            'themes_need_update' => function_exists('wp_get_update_data') ? wp_get_update_data()['counts']['themes'] : 0,
            'core_update'        => $core_update,
            'is_ssl'             => is_ssl(),
        ];

        // Allow modules to add their own health data
        return apply_filters('at_site_health_data', $data);
    }
}
new AT_Site_Health();
