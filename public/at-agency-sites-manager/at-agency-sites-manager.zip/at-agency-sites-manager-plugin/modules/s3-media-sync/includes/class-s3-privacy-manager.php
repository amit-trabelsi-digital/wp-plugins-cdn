<?php
/**
 * S3 Privacy Manager
 *
 * Handles privacy settings and access control for S3 files
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_S3_Privacy_Manager {

    /**
     * Constructor
     */
    public function __construct() {
        add_action('add_attachment', [$this, 'handle_new_attachment']);
        add_action('attachment_updated', [$this, 'handle_attachment_update']);
        add_filter('wp_get_attachment_url', [$this, 'filter_attachment_url'], 10, 2);
        add_filter('wp_calculate_image_srcset', [$this, 'filter_image_srcset'], 10, 5);
        add_action('wp_ajax_at_s3_update_privacy', [$this, 'ajax_update_privacy']);
        add_action('wp_ajax_at_s3_generate_signed_url', [$this, 'ajax_generate_signed_url']);
    }

    /**
     * Handle new attachment creation
     */
    public function handle_new_attachment($attachment_id) {
        $settings = get_option('at_agency_manager_s3_sync_settings', []);
        $privacy_level = $settings['privacy_level'] ?? 'public';

        // Set default privacy level for new attachments
        update_post_meta($attachment_id, '_s3_privacy_level', $privacy_level);

        // Generate signed URL if private
        if ($privacy_level === 'private') {
            $this->generate_signed_url_for_attachment($attachment_id);
        }
    }

    /**
     * Handle attachment updates
     */
    public function handle_attachment_update($attachment_id) {
        $privacy_level = get_post_meta($attachment_id, '_s3_privacy_level', true);

        if ($privacy_level === 'private') {
            $this->generate_signed_url_for_attachment($attachment_id);
        }
    }

    /**
     * Filter attachment URLs for private files
     */
    public function filter_attachment_url($url, $attachment_id) {
        $privacy_level = get_post_meta($attachment_id, '_s3_privacy_level', true);

        if ($privacy_level === 'private') {
            return $this->get_signed_url($attachment_id);
        }

        if ($privacy_level === 'authenticated' && !is_user_logged_in()) {
            return $this->get_login_url($attachment_id);
        }

        return $url;
    }

    /**
     * Filter image srcset for private files
     */
    public function filter_image_srcset($sources, $size_array, $image_src, $image_meta, $attachment_id) {
        $privacy_level = get_post_meta($attachment_id, '_s3_privacy_level', true);

        if ($privacy_level === 'private' || ($privacy_level === 'authenticated' && !is_user_logged_in())) {
            // Disable responsive images for private/authenticated files
            return false;
        }

        return $sources;
    }

    /**
     * Generate signed URL for attachment
     */
    private function generate_signed_url_for_attachment($attachment_id) {
        $file_path = get_attached_file($attachment_id);

        if (!$file_path) {
            return false;
        }

        // Convert local path to S3 key
        $upload_dir = wp_upload_dir();
        $s3_key = str_replace($upload_dir['basedir'], 'wp-content/uploads', $file_path);
        $s3_key = ltrim($s3_key, '/');

        // Get settings
        $settings = get_option('at_agency_manager_s3_sync_settings', []);

        if (empty($settings['bucket']) || empty($settings['key']) || empty($settings['secret'])) {
            return false;
        }

        try {
            // Create S3 client
            $s3_client = new Aws\S3\S3Client([
                'region' => $settings['region'] ?? 'us-east-1',
                'version' => 'latest',
                'credentials' => [
                    'key' => $settings['key'],
                    'secret' => $settings['secret']
                ]
            ]);

            // Generate signed URL (expires in 1 hour)
            $cmd = $s3_client->getCommand('GetObject', [
                'Bucket' => $settings['bucket'],
                'Key' => $s3_key
            ]);

            $request = $s3_client->createPresignedRequest($cmd, '+1 hour');
            $signed_url = (string) $request->getUri();

            // Store the signed URL
            update_post_meta($attachment_id, '_s3_signed_url', $signed_url);
            update_post_meta($attachment_id, '_s3_signed_url_expires', time() + 3600);

            return $signed_url;

        } catch (Exception $e) {
            error_log('S3 Privacy Manager: Failed to generate signed URL - ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Get signed URL for attachment
     */
    private function get_signed_url($attachment_id) {
        $signed_url = get_post_meta($attachment_id, '_s3_signed_url', true);
        $expires = get_post_meta($attachment_id, '_s3_signed_url_expires', true);

        // Check if URL is still valid (expires in more than 5 minutes)
        if ($signed_url && $expires && $expires > (time() + 300)) {
            return $signed_url;
        }

        // Generate new signed URL
        return $this->generate_signed_url_for_attachment($attachment_id);
    }

    /**
     * Get login URL for authenticated access
     */
    private function get_login_url($attachment_id) {
        $login_url = wp_login_url(get_permalink($attachment_id));
        return add_query_arg('redirect_to', urlencode(get_permalink($attachment_id)), $login_url);
    }

    /**
     * AJAX handler for updating privacy settings
     */
    public function ajax_update_privacy() {
        check_ajax_referer('at_s3_privacy_nonce', 'nonce');

        if (!current_user_can('upload_files')) {
            wp_die(__('Insufficient permissions'));
        }

        $attachment_id = intval($_POST['attachment_id']);
        $privacy_level = sanitize_text_field($_POST['privacy_level']);
        $search_engine_block = isset($_POST['search_engine_block']) ? 1 : 0;
        $hotlink_protection = isset($_POST['hotlink_protection']) ? 1 : 0;

        // Update privacy level
        update_post_meta($attachment_id, '_s3_privacy_level', $privacy_level);

        // Update privacy settings
        $privacy_meta = [
            'search_engine_block' => $search_engine_block,
            'hotlink_protection' => $hotlink_protection
        ];

        if ($search_engine_block) {
            $privacy_meta['x_robots_tag'] = 'noindex,nofollow,noarchive,nosnippet';
        }

        update_post_meta($attachment_id, '_s3_privacy_settings', $privacy_meta);

        // Clear signed URL cache if changing from/to private
        delete_post_meta($attachment_id, '_s3_signed_url');
        delete_post_meta($attachment_id, '_s3_signed_url_expires');

        wp_send_json_success([
            'message' => __('Privacy settings updated successfully', 'at-agency-manager')
        ]);
    }

    /**
     * AJAX handler for generating signed URL
     */
    public function ajax_generate_signed_url() {
        check_ajax_referer('at_s3_privacy_nonce', 'nonce');

        if (!current_user_can('upload_files')) {
            wp_die(__('Insufficient permissions'));
        }

        $attachment_id = intval($_POST['attachment_id']);
        $signed_url = $this->generate_signed_url_for_attachment($attachment_id);

        if ($signed_url) {
            wp_send_json_success([
                'signed_url' => $signed_url,
                'expires' => time() + 3600
            ]);
        } else {
            wp_send_json_error([
                'message' => __('Failed to generate signed URL', 'at-agency-manager')
            ]);
        }
    }

    /**
     * Add privacy controls to attachment edit screen
     */
    public function add_attachment_privacy_controls($form_fields, $post) {
        $settings = get_option('at_agency_manager_s3_sync_settings', []);

        if (empty($settings['bucket'])) {
            return $form_fields;
        }

        $privacy_level = get_post_meta($post->ID, '_s3_privacy_level', true) ?: 'public';
        $privacy_meta = get_post_meta($post->ID, '_s3_privacy_settings', true) ?: [];

        // Privacy Level Field
        $form_fields['s3_privacy_level'] = [
            'label' => __('S3 Privacy Level', 'at-agency-manager'),
            'input' => 'html',
            'html' => '<select name="attachments[' . $post->ID . '][s3_privacy_level]" id="s3_privacy_level_' . $post->ID . '">
                <option value="public" ' . selected($privacy_level, 'public', false) . '>' . __('Public', 'at-agency-manager') . '</option>
                <option value="private" ' . selected($privacy_level, 'private', false) . '>' . __('Private (Signed URL)', 'at-agency-manager') . '</option>
                <option value="authenticated" ' . selected($privacy_level, 'authenticated', false) . '>' . __('Authenticated Users Only', 'at-agency-manager') . '</option>
            </select>',
            'helps' => __('Control who can access this file in S3', 'at-agency-manager')
        ];

        // Search Engine Block Field
        $form_fields['s3_search_engine_block'] = [
            'label' => __('Block Search Engines', 'at-agency-manager'),
            'input' => 'html',
            'html' => '<input type="checkbox" name="attachments[' . $post->ID . '][s3_search_engine_block]" id="s3_search_engine_block_' . $post->ID . '" value="1" ' .
                checked($privacy_meta['search_engine_block'] ?? false, true, false) . ' />',
            'helps' => __('Prevent search engines from indexing this file', 'at-agency-manager')
        ];

        return $form_fields;
    }

    /**
     * Save privacy settings when attachment is updated
     */
    public function save_attachment_privacy_settings($post, $attachment) {
        if (isset($attachment['s3_privacy_level'])) {
            update_post_meta($post['ID'], '_s3_privacy_level', sanitize_text_field($attachment['s3_privacy_level']));
        }

        if (isset($attachment['s3_search_engine_block'])) {
            $privacy_meta = get_post_meta($post['ID'], '_s3_privacy_settings', true) ?: [];
            $privacy_meta['search_engine_block'] = intval($attachment['s3_search_engine_block']);

            if ($privacy_meta['search_engine_block']) {
                $privacy_meta['x_robots_tag'] = 'noindex,nofollow,noarchive,nosnippet';
            } else {
                unset($privacy_meta['x_robots_tag']);
            }

            update_post_meta($post['ID'], '_s3_privacy_settings', $privacy_meta);
        }
    }

    /**
     * Check if user has access to private file
     */
    public function check_file_access($attachment_id) {
        $privacy_level = get_post_meta($attachment_id, '_s3_privacy_level', true);

        if ($privacy_level === 'authenticated') {
            return is_user_logged_in();
        }

        if ($privacy_level === 'private') {
            // For private files, check if user has specific permission
            return current_user_can('upload_files');
        }

        return true;
    }

    /**
     * Add privacy headers to S3 objects
     */
    public function add_privacy_headers_to_s3($attachment_id) {
        $privacy_meta = get_post_meta($attachment_id, '_s3_privacy_settings', true);

        if (empty($privacy_meta)) {
            return [];
        }

        $headers = [];

        if (!empty($privacy_meta['x_robots_tag'])) {
            $headers['x-robots-tag'] = $privacy_meta['x_robots_tag'];
        }

        return $headers;
    }
}

// Initialize privacy manager
new AT_S3_Privacy_Manager();
