<?php
/**
 * Module: Page Ordering Settings Page
 * Provides UI for managing Page Ordering configuration
 */

if (!defined('ABSPATH')) exit;

require_once __DIR__ . '/page-ordering/helpers.php';

// Register Page Ordering settings (menu is registered in class-settings.php)
add_action('admin_init', function() {
    // חובה להגדיר sanitize_callback: בלעדיו, טופס שנשלח בלי אף checkbox מסומן
    // שומר מחרוזת ריקה במקום מערך, ומאותו רגע get_option מחזיר '' ולא את ברירת המחדל.
    $args = array(
        'type'              => 'array',
        'default'           => array(),
        'sanitize_callback' => 'at_page_ordering_sanitize_slug_list',
        'show_in_rest'      => false,
    );

    register_setting('at_page_ordering_settings', 'at_page_ordering_post_types', $args);
    register_setting('at_page_ordering_settings', 'at_page_ordering_taxonomies', $args);
});

/**
 * Render Page Ordering settings page
 */
function at_render_page_ordering_settings_page() {
    // בדיקת הרשאות
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.', 'at-agency-manager'));
    }
    
    // קריאה מוגנת: גם אם ב-DB שמורה מחרוזת ריקה מגרסה קודמת, מתקבל תמיד מערך.
    $enabled_post_types = at_page_ordering_get_enabled_post_types();
    $enabled_taxonomies = at_page_ordering_get_enabled_taxonomies();

    // Get all registered post types
    $post_types = get_post_types(['public' => true], 'objects');
    $exclude_post_types = ['attachment'];
    
    // Get all registered taxonomies
    $taxonomies = get_taxonomies(['public' => true], 'objects');
    $exclude_taxonomies = [];
    
    ?>
    <div class="wrap">
        <h1><?php _e('Page Ordering Settings', 'at-agency-manager'); ?></h1>
        <p class="description"><?php _e('Enable drag-and-drop ordering for the following post types and taxonomies', 'at-agency-manager'); ?></p>
        
        <form method="post" action="options.php" style="margin-top: 20px;">
            <?php settings_fields('at_page_ordering_settings'); ?>
            
            <div class="card" style="max-width: 800px;">
                <h2><?php _e('Post Types', 'at-agency-manager'); ?></h2>
                <p class="description"><?php _e('Select which post types should support drag-and-drop ordering', 'at-agency-manager'); ?></p>
                
                <div style="display: flex; flex-direction: column; gap: 10px; margin: 15px 0;">
                    <?php foreach ($post_types as $post_type):
                        if (in_array($post_type->name, $exclude_post_types)) {
                            continue;
                        }
                        $is_checked = in_array($post_type->name, $enabled_post_types);
                    ?>
                        <label style="display: flex; align-items: center;">
                            <input type="checkbox"
                                   name="at_page_ordering_post_types[]"
                                   value="<?php echo esc_attr($post_type->name); ?>"
                                   <?php checked($is_checked); ?>
                            />
                            <span style="margin-left: 8px;">
                                <strong><?php echo esc_html($post_type->label); ?></strong>
                                <span class="description" style="display: block; margin-left: 0; font-size: 12px;">
                                    <?php echo esc_html($post_type->description ?: $post_type->name); ?>
                                </span>
                            </span>
                        </label>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <div class="card" style="max-width: 800px; margin-top: 20px;">
                <h2><?php _e('Taxonomies', 'at-agency-manager'); ?></h2>
                <p class="description"><?php _e('Select which taxonomies should support drag-and-drop ordering', 'at-agency-manager'); ?></p>
                
                <div style="display: flex; flex-direction: column; gap: 10px; margin: 15px 0;">
                    <?php foreach ($taxonomies as $taxonomy):
                        if (in_array($taxonomy->name, $exclude_taxonomies)) {
                            continue;
                        }
                        $is_checked = in_array($taxonomy->name, $enabled_taxonomies);
                    ?>
                        <label style="display: flex; align-items: center;">
                            <input type="checkbox"
                                   name="at_page_ordering_taxonomies[]"
                                   value="<?php echo esc_attr($taxonomy->name); ?>"
                                   <?php checked($is_checked); ?>
                            />
                            <span style="margin-left: 8px;">
                                <strong><?php echo esc_html($taxonomy->label); ?></strong>
                                <span class="description" style="display: block; margin-left: 0; font-size: 12px;">
                                    <?php echo esc_html($taxonomy->description ?: $taxonomy->name); ?>
                                </span>
                            </span>
                        </label>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <div class="card" style="max-width: 800px; margin-top: 20px;">
                <h2><?php _e('Advanced Options', 'at-agency-manager'); ?></h2>
                
                <p>
                    <button type="button" class="button button-secondary" id="at-reset-order-btn"
                            data-nonce="<?php echo esc_attr(wp_create_nonce('at_page_ordering_nonce')); ?>"
                            style="background-color: #d63638; color: #fff;">
                        <?php _e('Reset All Orders', 'at-agency-manager'); ?>
                    </button>
                </p>
                <p class="description" style="color: #d63638;">
                    <?php _e('WARNING: This will reset the ordering of all selected post types. Click the button below to proceed (you will be asked for confirmation).', 'at-agency-manager'); ?>
                </p>
            </div>
            
            <?php submit_button(__('Save Settings', 'at-agency-manager')); ?>
        </form>
        
        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h2><?php _e('How to Use', 'at-agency-manager'); ?></h2>
            
            <h3><?php _e('Ordering in Admin', 'at-agency-manager'); ?></h3>
            <ol>
                <li><?php _e('Go to the list view of an enabled post type or taxonomy', 'at-agency-manager'); ?></li>
                <li><?php _e('Each row will be draggable - use the icon on the left side to drag', 'at-agency-manager'); ?></li>
                <li><?php _e('Drop items in your desired order', 'at-agency-manager'); ?></li>
                <li><?php _e('The order is saved automatically', 'at-agency-manager'); ?></li>
            </ol>
            
            <h3><?php _e('Frontend Display', 'at-agency-manager'); ?></h3>
            <p><?php _e('Posts and taxonomy terms will be displayed on the frontend according to the order you set. This applies to archives and listings.', 'at-agency-manager'); ?></p>
            
            <h3><?php _e('Technical Details', 'at-agency-manager'); ?></h3>
            <ul>
                <li><?php _e('Posts use the menu_order field', 'at-agency-manager'); ?></li>
                <li><?php _e('Taxonomy terms use a custom term_order column', 'at-agency-manager'); ?></li>
                <li><?php _e('Ordering is applied via the pre_get_posts filter', 'at-agency-manager'); ?></li>
                <li><?php _e('Post navigation (next/previous) respects custom ordering', 'at-agency-manager'); ?></li>
            </ul>
        </div>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        $('#at-reset-order-btn').on('click', function(e) {
            e.preventDefault();
            
            if (!confirm('<?php echo esc_js(__('Are you sure you want to reset all ordering? This action cannot be undone.', 'at-agency-manager')); ?>')) {
                return;
            }

            var button = $(this);
            var post_types = [];

            $('input[name="at_page_ordering_post_types[]"]:checked').each(function() {
                post_types.push($(this).val());
            });

            if (post_types.length === 0) {
                alert('<?php echo esc_js(__('Please select at least one post type', 'at-agency-manager')); ?>');
                return;
            }

            button.prop('disabled', true).text('<?php echo esc_js(__('Resetting...', 'at-agency-manager')); ?>');

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'at_reset_order',
                    // ה-nonce הייעודי של המודול. בעבר נשלח כאן ה-_wpnonce של options.php,
                    // ולכן check_ajax_referer נכשל תמיד והאיפוס לא בוצע.
                    nonce: button.data('nonce'),
                    post_types: post_types
                },
                success: function(response) {
                    alert('<?php echo esc_js(__('Ordering has been reset successfully', 'at-agency-manager')); ?>');
                    button.prop('disabled', false).text('<?php echo esc_js(__('Reset All Orders', 'at-agency-manager')); ?>');
                    location.reload();
                },
                error: function() {
                    alert('<?php echo esc_js(__('Error resetting ordering', 'at-agency-manager')); ?>');
                    button.prop('disabled', false).text('<?php echo esc_js(__('Reset All Orders', 'at-agency-manager')); ?>');
                }
            });
        });
    });
    </script>
    <?php
}

