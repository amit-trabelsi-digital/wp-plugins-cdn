<?php
/**
 * Module: Page Ordering
 * מאפשר הזמנה מותאמת אישית של עמודים וסוגי תוכן עם גרירה ושחרור
 */

if (!defined('ABSPATH')) exit;

require_once __DIR__ . '/page-ordering/helpers.php';

class AT_Page_Ordering {
    /**
     * @var AT_Agency_Manager_Logger מופע הלוגר
     */
    private $logger;

    /**
     * אתחול המודול
     *
     * @param AT_Agency_Manager_Logger $logger מופע הלוגר
     */
    public function __construct($logger) {
        $this->logger = $logger;

        // אתחול הוקים
        add_action('admin_init', array($this, 'init'));
        add_action('wp_ajax_at_update_menu_order', array($this, 'update_menu_order'));
        add_action('wp_ajax_at_update_menu_order_tags', array($this, 'update_menu_order_tags'));
        add_action('pre_get_posts', array($this, 'pre_get_posts'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));

        // הוקים לניווט פוסטים
        add_filter('get_previous_post_where', array($this, 'previous_post_where'));
        add_filter('get_previous_post_sort', array($this, 'previous_post_sort'));
        add_filter('get_next_post_where', array($this, 'next_post_where'));
        add_filter('get_next_post_sort', array($this, 'next_post_sort'));

        // הוקים לטקסונומיות
        add_filter('get_terms_orderby', array($this, 'get_terms_orderby'), 10, 3);
        add_filter('wp_get_object_terms', array($this, 'get_object_terms'), 10, 3);
        add_filter('get_terms', array($this, 'get_object_terms'), 10, 3);

        // הוק לאיפוס סדר
        add_action('wp_ajax_at_reset_order', array($this, 'reset_order'));
    }

    /**
     * אתחול המודול
     */
    public function init() {
        // יצירת עמודת term_order אם לא קיימת
        $this->create_terms_order_table();
    }

    /**
     * יצירת עמודת term_order בטבלת ה-terms אם לא קיימת
     */
    private function create_terms_order_table() {
        global $wpdb;

        $table_name = $wpdb->terms;

        // SHOW COLUMNS ... LIKE אינו מייצר שגיאת MySQL כשהעמודה חסרה (בניגוד ל-DESCRIBE)
        $exists = $wpdb->get_var(
            $wpdb->prepare("SHOW COLUMNS FROM {$table_name} LIKE %s", 'term_order')
        );

        if (!$exists) {
            $wpdb->query("ALTER TABLE {$table_name} ADD `term_order` INT(4) NULL DEFAULT '0'");

            if ($this->logger) {
                $this->logger->log('page_ordering', 'Created term_order column in terms table', 'info');
            }
        }
    }

    /**
     * זיהוי מסך הניהול הנוכחי והאם הוא מופעל לגרירה ושחרור.
     *
     * מחזיר מערך עם type ('post_type' | 'taxonomy') ו-name, או null אם המסך אינו רלוונטי.
     *
     * @return array|null
     */
    private function get_screen_context() {
        if (!is_admin()) {
            return null;
        }

        $pagenow     = isset($GLOBALS['pagenow']) ? (string) $GLOBALS['pagenow'] : '';
        $request_uri = isset($_SERVER['REQUEST_URI']) ? (string) $_SERVER['REQUEST_URI'] : '';

        // מסך ניהול הטרמים של טקסונומיה (edit-tags.php)
        if ('edit-tags.php' === $pagenow || false !== strpos($request_uri, 'edit-tags.php')) {
            $taxonomy = isset($_GET['taxonomy']) ? sanitize_key(wp_unslash($_GET['taxonomy'])) : '';

            if ('' !== $taxonomy && $this->is_taxonomy_enabled($taxonomy)) {
                return array('type' => 'taxonomy', 'name' => $taxonomy);
            }

            return null;
        }

        // מסך רשימת הפוסטים (edit.php)
        if ('edit.php' === $pagenow || false !== strpos($request_uri, 'edit.php')) {
            // עריכה מהירה / עריכה קבוצתית - לא לטעון
            if (isset($_GET['action']) && 'edit' === $_GET['action']) {
                return null;
            }

            $post_type = isset($_GET['post_type']) ? sanitize_key(wp_unslash($_GET['post_type'])) : 'post';

            if ($this->is_post_type_enabled($post_type)) {
                return array('type' => 'post_type', 'name' => $post_type);
            }
        }

        return null;
    }

    /**
     * בדיקה אם סוג תוכן מופעל להזמנה
     *
     * @param string $post_type סוג התוכן
     * @return bool
     */
    private function is_post_type_enabled($post_type) {
        if (!is_string($post_type) || '' === $post_type) {
            return false;
        }

        $enabled_post_types = at_page_ordering_get_enabled_post_types();

        if (empty($enabled_post_types)) {
            return false;
        }

        return in_array($post_type, $enabled_post_types, true);
    }

    /**
     * בדיקה אם טקסונומיה מופעלת להזמנה
     *
     * @param string $taxonomy שם הטקסונומיה
     * @return bool
     */
    private function is_taxonomy_enabled($taxonomy) {
        if (!is_string($taxonomy) || '' === $taxonomy) {
            return false;
        }

        $enabled_taxonomies = at_page_ordering_get_enabled_taxonomies();

        if (empty($enabled_taxonomies)) {
            return false;
        }

        return in_array($taxonomy, $enabled_taxonomies, true);
    }

    /**
     * טעינת סקריפטים וסטיילים
     *
     * @param array $context תוצאת get_screen_context()
     */
    private function load_scripts_styles($context) {
        wp_enqueue_script('jquery');
        wp_enqueue_script('jquery-ui-sortable');

        wp_enqueue_script(
            'at-page-ordering-js',
            AT_AGENCY_MANAGER_URL . 'modules/page-ordering/assets/js/page-ordering.js',
            array('jquery', 'jquery-ui-sortable'),
            AT_AGENCY_MANAGER_VERSION,
            true
        );

        $is_taxonomy = ('taxonomy' === $context['type']);

        wp_localize_script('at-page-ordering-js', 'at_page_ordering_vars', array(
            'ajax_url'     => admin_url('admin-ajax.php'),
            'nonce'        => wp_create_nonce('at_page_ordering_nonce'),
            // המסך קובע לאיזה handler לפנות - פוסטים או טרמים
            'context'      => $context['type'],
            'action'       => $is_taxonomy ? 'at_update_menu_order_tags' : 'at_update_menu_order',
            'post_type'    => $is_taxonomy ? '' : $context['name'],
            'taxonomy'     => $is_taxonomy ? $context['name'] : '',
            'loading_text' => __('Updating order...', 'at-agency-manager'),
            'success_text' => __('Order updated successfully', 'at-agency-manager'),
            'error_text'   => __('An error occurred while updating the order', 'at-agency-manager'),
        ));

        wp_enqueue_style(
            'at-page-ordering-css',
            AT_AGENCY_MANAGER_URL . 'modules/page-ordering/assets/css/page-ordering.css',
            array(),
            AT_AGENCY_MANAGER_VERSION
        );

        // הוספת CSS inline עבור סטיילינג
        add_action('admin_print_styles', array($this, 'print_inline_styles'));
    }

    /**
     * טעינת סקריפטים וסטיילים במסכי הניהול הרלוונטיים
     */
    public function enqueue_scripts($hook) {
        // רשימת פוסטים או רשימת טרמים בלבד
        if ('edit.php' !== $hook && 'edit-tags.php' !== $hook) {
            return;
        }

        $context = $this->get_screen_context();

        if (null === $context) {
            return;
        }

        $this->load_scripts_styles($context);
    }

    /**
     * הוספת CSS inline
     */
    public function print_inline_styles() {
        ?>
        <style>
            .ui-sortable tr:hover {
                cursor: move;
            }

            .ui-sortable tr.alternate {
                background-color: #F9F9F9;
            }

            .ui-sortable tr.ui-sortable-helper {
                background-color: #F9F9F9;
                border-top: 1px solid #DFDFDF;
            }

            .ui-sortable-handle {
                cursor: move;
                opacity: 0.5;
            }

            .ui-sortable-handle:hover {
                opacity: 1;
            }
        </style>
        <?php
    }

    /**
     * פענוח מחרוזת ה-serialize שנשלחה מה-jQuery UI sortable לרשימת מזהים מסודרת.
     *
     * @return array רשימת מזהים לפי הסדר החדש
     */
    private function parse_order_request() {
        $data = isset($_POST['order']) ? wp_unslash($_POST['order']) : '';

        if (!is_string($data) || '' === $data) {
            return array();
        }

        $parsed_data = array();
        parse_str($data, $parsed_data);

        $id_arr = array();

        foreach ((array) $parsed_data as $values) {
            // המחרוזת מכילה גם שדות סקלריים (post_type, taxonomy) - foreach עליהם
            // מייצר Warning ב-PHP 8, ולכן מדלגים על כל מה שאינו מערך.
            if (!is_array($values)) {
                continue;
            }

            foreach ($values as $id) {
                if (!is_scalar($id)) {
                    continue;
                }

                $id = intval($id);

                if ($id > 0) {
                    $id_arr[] = $id;
                }
            }
        }

        return array_values(array_unique($id_arr));
    }

    /**
     * בניית רשימת ערכי סדר לשיבוץ מחדש.
     *
     * הלוגיקה המקורית מיחזרה את ערכי הסדר הקיימים. זה נכשל כשכל הפריטים חולקים
     * את אותו ערך (המצב הרגיל: menu_order/term_order = 0 לכולם) - אז השיבוץ
     * מחדש היה זהה למצב הקודם והגרירה "לא עשתה כלום". לכן, כשאין ערכים ייחודיים
     * מספיק, נוצרת סדרה רציפה מהערך הנמוך ביותר.
     *
     * @param array $existing_values ערכי הסדר הקיימים
     * @param int   $count           מספר הפריטים בסדר החדש
     * @return array
     */
    private function build_order_values($existing_values, $count) {
        $count = (int) $count;

        if ($count < 1) {
            return array();
        }

        $existing_values = array_map('intval', (array) $existing_values);
        sort($existing_values, SORT_NUMERIC);

        if (count($existing_values) !== $count || count(array_unique($existing_values)) !== $count) {
            $base = !empty($existing_values) ? (int) min($existing_values) : 0;
            $existing_values = range($base, $base + $count - 1);
        }

        return $existing_values;
    }

    /**
     * עדכון סדר הפוסטים
     */
    public function update_menu_order() {
        global $wpdb;

        // בדיקת nonce
        check_ajax_referer('at_page_ordering_nonce', 'nonce');

        // בדיקת הרשאות
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(array('message' => __('Insufficient permissions', 'at-agency-manager')), 403);
        }

        $id_arr = $this->parse_order_request();

        if (empty($id_arr)) {
            wp_send_json_error(array('message' => __('No data received', 'at-agency-manager')), 400);
        }

        // קבלת ערכי menu_order קיימים
        $menu_order_arr = array();
        foreach ($id_arr as $id) {
            $menu_order = $wpdb->get_var(
                $wpdb->prepare("SELECT menu_order FROM {$wpdb->posts} WHERE ID = %d", $id)
            );

            if (null !== $menu_order) {
                $menu_order_arr[] = (int) $menu_order;
            }
        }

        $menu_order_arr = $this->build_order_values($menu_order_arr, count($id_arr));

        // עדכון סדר הפוסטים
        foreach ($id_arr as $position => $id) {
            if (!isset($menu_order_arr[$position]) || !current_user_can('edit_post', $id)) {
                continue;
            }

            $wpdb->update(
                $wpdb->posts,
                array('menu_order' => (int) $menu_order_arr[$position]),
                array('ID' => (int) $id),
                array('%d'),
                array('%d')
            );

            clean_post_cache($id);
        }

        // לוג
        if ($this->logger) {
            $this->logger->log('page_ordering', 'Updated menu order for ' . count($id_arr) . ' posts', 'info');
        }

        wp_send_json_success(array('updated' => count($id_arr)));
    }

    /**
     * עדכון סדר הטרמים בטקסונומיה
     */
    public function update_menu_order_tags() {
        global $wpdb;

        // בדיקת nonce
        check_ajax_referer('at_page_ordering_nonce', 'nonce');

        $taxonomy = isset($_POST['taxonomy']) ? sanitize_key(wp_unslash($_POST['taxonomy'])) : '';

        if ('' === $taxonomy || !taxonomy_exists($taxonomy) || !$this->is_taxonomy_enabled($taxonomy)) {
            wp_send_json_error(array('message' => __('Invalid taxonomy', 'at-agency-manager')), 400);
        }

        // בדיקת הרשאות לפי ה-cap של הטקסונומיה עצמה
        $taxonomy_object = get_taxonomy($taxonomy);

        if (!$taxonomy_object || !current_user_can($taxonomy_object->cap->edit_terms)) {
            wp_send_json_error(array('message' => __('Insufficient permissions', 'at-agency-manager')), 403);
        }

        $id_arr = $this->parse_order_request();

        if (empty($id_arr)) {
            wp_send_json_error(array('message' => __('No data received', 'at-agency-manager')), 400);
        }

        // סינון מזהים שאינם שייכים לטקסונומיה הנוכחית
        $placeholders = implode(',', array_fill(0, count($id_arr), '%d'));
        $valid_ids = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT term_id FROM {$wpdb->term_taxonomy} WHERE taxonomy = %s AND term_id IN ({$placeholders})",
                array_merge(array($taxonomy), $id_arr)
            )
        );
        $valid_ids = array_map('intval', (array) $valid_ids);

        $id_arr = array_values(array_filter($id_arr, static function ($id) use ($valid_ids) {
            return in_array((int) $id, $valid_ids, true);
        }));

        if (empty($id_arr)) {
            wp_send_json_error(array('message' => __('No data received', 'at-agency-manager')), 400);
        }

        // קבלת ערכי term_order קיימים
        $term_order_arr = array();
        foreach ($id_arr as $id) {
            $term_order = $wpdb->get_var(
                $wpdb->prepare("SELECT term_order FROM {$wpdb->terms} WHERE term_id = %d", $id)
            );

            if (null !== $term_order) {
                $term_order_arr[] = (int) $term_order;
            }
        }

        $term_order_arr = $this->build_order_values($term_order_arr, count($id_arr));

        // עדכון סדר הטרמים
        foreach ($id_arr as $position => $id) {
            if (!isset($term_order_arr[$position])) {
                continue;
            }

            $wpdb->update(
                $wpdb->terms,
                array('term_order' => (int) $term_order_arr[$position]),
                array('term_id' => (int) $id),
                array('%d'),
                array('%d')
            );

            clean_term_cache($id, $taxonomy);
        }

        // לוג
        if ($this->logger) {
            $this->logger->log('page_ordering', "Updated term order for taxonomy: {$taxonomy}", 'info');
        }

        wp_send_json_success(array('updated' => count($id_arr)));
    }

    /**
     * פונקציית pre_get_posts להזמנה מותאמת
     */
    public function pre_get_posts($wp_query) {
        if (is_admin()) {
            return;
        }

        // בדיקה אם זה שאילתה ראשית
        if (!$wp_query->is_main_query()) {
            return;
        }

        // בדיקה אם זה דף ארכיון או עמוד בית
        if (!$wp_query->is_archive() && !$wp_query->is_home() && !$wp_query->is_front_page()) {
            return;
        }

        // קבלת סוג התוכן (עשוי להגיע כמערך בשאילתות מרובות סוגים)
        $post_type = $wp_query->get('post_type');

        if (is_array($post_type)) {
            // שאילתה מרובת סוגי תוכן - לא ניתן להחיל סדר חד-משמעי
            if (1 !== count($post_type)) {
                return;
            }

            $post_type = reset($post_type);
        }

        if (empty($post_type) || !is_string($post_type)) {
            $post_type = 'post';
        }

        // בדיקה אם סוג התוכן מופעל להזמנה
        if (!$this->is_post_type_enabled($post_type)) {
            return;
        }

        // הגדרת ההזמנה לפי menu_order
        $wp_query->set('orderby', 'menu_order');
        $wp_query->set('order', 'ASC');

        // לוג
        if ($this->logger) {
            $this->logger->log('page_ordering', "Applied custom ordering for post type: {$post_type}", 'info');
        }
    }

    /**
     * פונקציות ניווט פוסטים קודמים/באים
     */
    public function previous_post_where($where) {
        global $post;

        if (!$post || !isset($post->post_type)) {
            return $where;
        }

        if (!$this->is_post_type_enabled($post->post_type)) {
            return $where;
        }

        $where = preg_replace("/p.post_date < \'[0-9\-\s\:]+\'/i", "p.menu_order > '" . $post->menu_order . "'", $where);
        return $where;
    }

    public function previous_post_sort($orderby) {
        global $post;

        if (!$post || !isset($post->post_type)) {
            return $orderby;
        }

        if (!$this->is_post_type_enabled($post->post_type)) {
            return $orderby;
        }

        $orderby = 'ORDER BY p.menu_order ASC LIMIT 1';
        return $orderby;
    }

    public function next_post_where($where) {
        global $post;

        if (!$post || !isset($post->post_type)) {
            return $where;
        }

        if (!$this->is_post_type_enabled($post->post_type)) {
            return $where;
        }

        $where = preg_replace("/p.post_date > \'[0-9\-\s\:]+\'/i", "p.menu_order < '" . $post->menu_order . "'", $where);
        return $where;
    }

    public function next_post_sort($orderby) {
        global $post;

        if (!$post || !isset($post->post_type)) {
            return $orderby;
        }

        if (!$this->is_post_type_enabled($post->post_type)) {
            return $orderby;
        }

        $orderby = 'ORDER BY p.menu_order DESC LIMIT 1';
        return $orderby;
    }

    /**
     * פונקציות טקסונומיות
     */
    public function get_terms_orderby($orderby, $args) {
        $taxonomy = isset($args['taxonomy']) ? $args['taxonomy'] : '';

        if (is_array($taxonomy)) {
            $taxonomy = reset($taxonomy);
        }

        if (!$this->is_taxonomy_enabled($taxonomy)) {
            return $orderby;
        }

        if (is_admin()) {
            // באדמין מיישמים את הסדר רק במסך ניהול הטרמים עצמו, אחרת נשבור
            // מיונים אחרים (תיבות בחירה, מטא-בוקסים, בקשות REST וכו').
            $pagenow = isset($GLOBALS['pagenow']) ? (string) $GLOBALS['pagenow'] : '';

            if ('edit-tags.php' !== $pagenow) {
                return $orderby;
            }

            // אם המשתמש לחץ על כותרת עמודה למיון - מכבדים את בחירתו
            if (!empty($_GET['orderby'])) {
                return $orderby;
            }
        }

        return 't.term_order';
    }

    public function get_object_terms($terms) {
        // get_terms עשוי להחזיר WP_Error, מספר (count) או רשימת מזהים/שמות
        if (!is_array($terms) || empty($terms) || is_admin()) {
            return $terms;
        }

        $enabled_taxonomies = at_page_ordering_get_enabled_taxonomies();

        if (empty($enabled_taxonomies)) {
            return $terms;
        }

        foreach ($terms as $term) {
            if (!is_object($term) || !isset($term->taxonomy)) {
                return $terms;
            }

            if (!in_array($term->taxonomy, $enabled_taxonomies, true)) {
                return $terms;
            }
        }

        usort($terms, array($this, 'taxcmp'));

        return $terms;
    }

    public function taxcmp($a, $b) {
        // term_order אינו חלק מהמאפיינים הסטנדרטיים של WP_Term - חובה לבדוק isset
        $a_order = isset($a->term_order) ? (int) $a->term_order : 0;
        $b_order = isset($b->term_order) ? (int) $b->term_order : 0;

        if ($a_order === $b_order) {
            return 0;
        }

        return ($a_order < $b_order) ? -1 : 1;
    }

    /**
     * איפוס סדר הפוסטים
     */
    public function reset_order() {
        global $wpdb;

        // בדיקת nonce
        check_ajax_referer('at_page_ordering_nonce', 'nonce');

        // פעולה הרסנית וגלובלית - נדרשת הרשאת ניהול
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Insufficient permissions', 'at-agency-manager')), 403);
        }

        $raw_post_types = isset($_POST['post_types']) ? wp_unslash($_POST['post_types']) : array();

        // מגיע כמערך מה-JS, אך עלול להגיע כמחרוזת בודדת - נרמול לפני foreach
        $post_types = at_page_ordering_sanitize_slug_list($raw_post_types);

        // רק סוגי תוכן שהופעלו בהגדרות
        $enabled = at_page_ordering_get_enabled_post_types();
        $post_types = array_values(array_intersect($post_types, $enabled));

        if (empty($post_types)) {
            wp_send_json_error(array('message' => __('No post types selected', 'at-agency-manager')), 400);
        }

        // איפוס הסדר לכל סוגי התוכן שנבחרו
        foreach ($post_types as $post_type) {
            $wpdb->update(
                $wpdb->posts,
                array('menu_order' => 0),
                array('post_type' => $post_type),
                array('%d'),
                array('%s')
            );
        }

        wp_cache_flush();

        // לוג
        if ($this->logger) {
            $this->logger->log('page_ordering', 'Reset order for post types: ' . implode(', ', $post_types), 'info');
        }

        wp_send_json_success(array('message' => __('Order reset successfully', 'at-agency-manager')));
    }
}

// אתחול המודול
// המודול יאותחל רק אם הוא מופעל בהגדרות
$modules = (array) get_option('at_agency_manager_modules', []);
if (!empty($modules['page_ordering'])) {
    $at_page_ordering = new AT_Page_Ordering($GLOBALS['at_logger'] ?? null);
}
