<?php
/**
 * Module: Page Ordering
 * מאפשר הזמנה מותאמת אישית של עמודים וסוגי תוכן עם גרירה ושחרור
 */

if (!defined('ABSPATH')) exit;

class AT_Page_Ordering {
    /**
     * @var AT_Agency_Manager_Logger מופע הלוגר
     */
    private $logger;

    /**
     * אתחול המודול
     *
     * @param AT_Agency_Manager_Logger $logger מופע הלוגר
     */
    public function __construct($logger) {
        $this->logger = $logger;

        // אתחול הוקים
        add_action('admin_init', array($this, 'init'));
        add_action('wp_ajax_at_update_menu_order', array($this, 'update_menu_order'));
        add_action('wp_ajax_at_update_menu_order_tags', array($this, 'update_menu_order_tags'));
        add_action('pre_get_posts', array($this, 'pre_get_posts'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));

        // הוקים לניווט פוסטים
        add_filter('get_previous_post_where', array($this, 'previous_post_where'));
        add_filter('get_previous_post_sort', array($this, 'previous_post_sort'));
        add_filter('get_next_post_where', array($this, 'next_post_where'));
        add_filter('get_next_post_sort', array($this, 'next_post_sort'));

        // הוקים לטקסונומיות
        add_filter('get_terms_orderby', array($this, 'get_terms_orderby'), 10, 3);
        add_filter('wp_get_object_terms', array($this, 'get_object_terms'), 10, 3);
        add_filter('get_terms', array($this, 'get_object_terms'), 10, 3);

        // הוק לאיפוס סדר
        add_action('wp_ajax_at_reset_order', array($this, 'reset_order'));
    }

    /**
     * אתחול המודול
     */
    public function init() {
        // יצירת טבלה לטקסונומיות אם לא קיימת
        $this->create_terms_order_table();

        // טעינת סקריפטים וסטיילים רק בעמודי הרלוונטיים
        if ($this->should_load_scripts()) {
            $this->load_scripts_styles();
        }
    }

    /**
     * יצירת טבלה לטקסונומיות אם לא קיימת
     */
    private function create_terms_order_table() {
        global $wpdb;

        $table_name = $wpdb->terms;
        $result = $wpdb->query("DESCRIBE {$table_name} `term_order`");

        if (!$result) {
            $query = "ALTER TABLE {$table_name} ADD `term_order` INT(4) NULL DEFAULT '0'";
            $wpdb->query($query);

            if ($this->logger) {
                $this->logger->log('page_ordering', 'Created term_order column in terms table', 'info');
            }
        }
    }

    /**
     * בדיקה אם צריך לטעון סקריפטים בעמוד הנוכחי
     *
     * @return bool
     */
    private function should_load_scripts() {
        // בדיקה אם זה עמוד admin
        if (!is_admin()) {
            return false;
        }

        // בדיקה אם זה עמוד עריכה
        if (isset($_GET['action']) && $_GET['action'] === 'edit') {
            return false;
        }

        // בדיקה אם זה עמוד הוספה חדשה
        if (strstr($_SERVER['REQUEST_URI'], 'post-new.php')) {
            return false;
        }

        // בדיקה אם זה עמוד edit.php עם סוג תוכן מורשה
        if (isset($_GET['post_type'])) {
            $post_type = sanitize_text_field($_GET['post_type']);
            return $this->is_post_type_enabled($post_type);
        }

        // בדיקה אם זה עמוד edit.php של פוסטים רגילים
        if (strstr($_SERVER['REQUEST_URI'], 'edit.php') && !isset($_GET['post_type'])) {
            return $this->is_post_type_enabled('post');
        }

        return false;
    }

    /**
     * בדיקה אם סוג תוכן מופעל להזמנה
     *
     * @param string $post_type סוג התוכן
     * @return bool
     */
    private function is_post_type_enabled($post_type) {
        $enabled_post_types = get_option('at_page_ordering_post_types', []);

        if (empty($enabled_post_types)) {
            return false;
        }

        return in_array($post_type, $enabled_post_types);
    }

    /**
     * בדיקה אם טקסונומיה מופעלת להזמנה
     *
     * @param string $taxonomy שם הטקסונומיה
     * @return bool
     */
    private function is_taxonomy_enabled($taxonomy) {
        $enabled_taxonomies = get_option('at_page_ordering_taxonomies', []);

        if (empty($enabled_taxonomies)) {
            return false;
        }

        return in_array($taxonomy, $enabled_taxonomies);
    }

    /**
     * טעינת סקריפטים וסטיילים
     */
    private function load_scripts_styles() {
        wp_enqueue_script('jquery');
        wp_enqueue_script('jquery-ui-sortable');

        wp_enqueue_script(
            'at-page-ordering-js',
            AT_AGENCY_MANAGER_URL . 'modules/page-ordering/assets/js/page-ordering.js',
            array('jquery', 'jquery-ui-sortable'),
            AT_AGENCY_MANAGER_VERSION,
            true
        );

        wp_localize_script('at-page-ordering-js', 'at_page_ordering_vars', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('at_page_ordering_nonce')
        ));

        wp_enqueue_style(
            'at-page-ordering-css',
            AT_AGENCY_MANAGER_URL . 'modules/page-ordering/assets/css/page-ordering.css',
            array(),
            AT_AGENCY_MANAGER_VERSION
        );

        // הוספת CSS inline עבור סטיילינג
        add_action('admin_print_styles', array($this, 'print_inline_styles'));
    }

    /**
     * טעינת סקריפטים וסטיילים באופן חיצוני
     */
    public function enqueue_scripts($hook) {
        // טעינה רק בעמודי edit.php
        if ($hook !== 'edit.php') {
            return;
        }

        if ($this->should_load_scripts()) {
            $this->load_scripts_styles();
        }
    }

    /**
     * הוספת CSS inline
     */
    public function print_inline_styles() {
        ?>
        <style>
            .ui-sortable tr:hover {
                cursor: move;
            }

            .ui-sortable tr.alternate {
                background-color: #F9F9F9;
            }

            .ui-sortable tr.ui-sortable-helper {
                background-color: #F9F9F9;
                border-top: 1px solid #DFDFDF;
            }

            .ui-sortable-handle {
                cursor: move;
                opacity: 0.5;
            }

            .ui-sortable-handle:hover {
                opacity: 1;
            }
        </style>
        <?php
    }

    /**
     * עדכון סדר התפריטים
     */
    public function update_menu_order() {
        global $wpdb;

        // בדיקת הרשאות
        if (!current_user_can('edit_posts')) {
            wp_die(__('Insufficient permissions', 'at-agency-manager'));
        }

        // בדיקת nonce
        check_ajax_referer('at_page_ordering_nonce', 'nonce');

        // קבלת הנתונים
        $data = isset($_POST['order']) ? $_POST['order'] : '';

        if (empty($data)) {
            wp_die(__('No data received', 'at-agency-manager'));
        }

        parse_str($data, $parsed_data);

        if (!is_array($parsed_data)) {
            wp_die(__('Invalid data format', 'at-agency-manager'));
        }

        // איסוף כל ה-IDים
        $id_arr = array();
        foreach ($parsed_data as $key => $values) {
            foreach ($values as $position => $id) {
                $id_arr[] = intval($id);
            }
        }

        // קבלת ערכי menu_order קיימים
        $menu_order_arr = array();
        foreach ($id_arr as $id) {
            $result = $wpdb->get_row(
                $wpdb->prepare("SELECT menu_order FROM {$wpdb->posts} WHERE ID = %d", $id)
            );
            if ($result) {
                $menu_order_arr[] = $result->menu_order;
            }
        }

        sort($menu_order_arr);

        // עדכון סדר הפוסטים
        foreach ($parsed_data as $key => $values) {
            foreach ($values as $position => $id) {
                $id = intval($id);
                $wpdb->update(
                    $wpdb->posts,
                    array('menu_order' => $menu_order_arr[$position]),
                    array('ID' => $id),
                    array('%d'),
                    array('%d')
                );
            }
        }

        wp_cache_flush();

        // לוג
        if ($this->logger) {
            $this->logger->log('page_ordering', 'Updated menu order for posts', 'info');
        }

        wp_die();
    }

    /**
     * עדכון סדר הטקסונומיות
     */
    public function update_menu_order_tags() {
        global $wpdb;

        // בדיקת הרשאות
        if (!current_user_can('edit_posts')) {
            wp_die(__('Insufficient permissions', 'at-agency-manager'));
        }

        // בדיקת nonce
        check_ajax_referer('at_page_ordering_nonce', 'nonce');

        // קבלת הנתונים
        $data = isset($_POST['order']) ? $_POST['order'] : '';

        if (empty($data)) {
            wp_die(__('No data received', 'at-agency-manager'));
        }

        parse_str($data, $parsed_data);

        if (!is_array($parsed_data)) {
            wp_die(__('Invalid data format', 'at-agency-manager'));
        }

        // איסוף כל ה-IDים
        $id_arr = array();
        foreach ($parsed_data as $key => $values) {
            foreach ($values as $position => $id) {
                $id_arr[] = intval($id);
            }
        }

        // קבלת ערכי term_order קיימים
        $menu_order_arr = array();
        foreach ($id_arr as $id) {
            $result = $wpdb->get_row(
                $wpdb->prepare("SELECT term_order FROM {$wpdb->terms} WHERE term_id = %d", $id)
            );
            if ($result) {
                $menu_order_arr[] = $result->term_order;
            }
        }

        sort($menu_order_arr);

        // עדכון סדר הטרמינים
        foreach ($parsed_data as $key => $values) {
            foreach ($values as $position => $id) {
                $id = intval($id);
                $wpdb->update(
                    $wpdb->terms,
                    array('term_order' => $menu_order_arr[$position]),
                    array('term_id' => $id),
                    array('%d'),
                    array('%d')
                );
            }
        }

        wp_cache_flush();

        // לוג
        if ($this->logger) {
            $this->logger->log('page_ordering', 'Updated menu order for terms', 'info');
        }

        wp_die();
    }

    /**
     * פונקציית pre_get_posts להזמנה מותאמת
     */
    public function pre_get_posts($wp_query) {
        if (is_admin()) {
            return;
        }

        // בדיקה אם זה שאילתה ראשית
        if (!$wp_query->is_main_query()) {
            return;
        }

        // בדיקה אם זה דף ארכיון או עמוד בית
        if (!$wp_query->is_archive() && !$wp_query->is_home() && !$wp_query->is_front_page()) {
            return;
        }

        // קבלת סוג התוכן
        $post_type = $wp_query->get('post_type');
        if (empty($post_type)) {
            $post_type = 'post';
        }

        // בדיקה אם סוג התוכן מופעל להזמנה
        if (!$this->is_post_type_enabled($post_type)) {
            return;
        }

        // הגדרת ההזמנה לפי menu_order
        $wp_query->set('orderby', 'menu_order');
        $wp_query->set('order', 'ASC');

        // לוג
        if ($this->logger) {
            $this->logger->log('page_ordering', "Applied custom ordering for post type: {$post_type}", 'info');
        }
    }

    /**
     * פונקציות ניווט פוסטים קודמים/באים
     */
    public function previous_post_where($where) {
        global $post;

        if (!$post || !isset($post->post_type)) {
            return $where;
        }

        if (!$this->is_post_type_enabled($post->post_type)) {
            return $where;
        }

        $where = preg_replace("/p.post_date < \'[0-9\-\s\:]+\'/i", "p.menu_order > '" . $post->menu_order . "'", $where);
        return $where;
    }

    public function previous_post_sort($orderby) {
        global $post;

        if (!$post || !isset($post->post_type)) {
            return $orderby;
        }

        if (!$this->is_post_type_enabled($post->post_type)) {
            return $orderby;
        }

        $orderby = 'ORDER BY p.menu_order ASC LIMIT 1';
        return $orderby;
    }

    public function next_post_where($where) {
        global $post;

        if (!$post || !isset($post->post_type)) {
            return $where;
        }

        if (!$this->is_post_type_enabled($post->post_type)) {
            return $where;
        }

        $where = preg_replace("/p.post_date > \'[0-9\-\s\:]+\'/i", "p.menu_order < '" . $post->menu_order . "'", $where);
        return $where;
    }

    public function next_post_sort($orderby) {
        global $post;

        if (!$post || !isset($post->post_type)) {
            return $orderby;
        }

        if (!$this->is_post_type_enabled($post->post_type)) {
            return $orderby;
        }

        $orderby = 'ORDER BY p.menu_order DESC LIMIT 1';
        return $orderby;
    }

    /**
     * פונקציות טקסונומיות
     */
    public function get_terms_orderby($orderby, $args) {
        if (is_admin()) {
            return $orderby;
        }

        $taxonomy = isset($args['taxonomy']) ? $args['taxonomy'] : '';

        if (is_array($taxonomy)) {
            $taxonomy = $taxonomy[0];
        }

        if (!$this->is_taxonomy_enabled($taxonomy)) {
            return $orderby;
        }

        $orderby = 't.term_order';
        return $orderby;
    }

    public function get_object_terms($terms) {
        $enabled_taxonomies = get_option('at_page_ordering_taxonomies', []);

        if (empty($enabled_taxonomies) || is_admin()) {
            return $terms;
        }

        foreach ($terms as $key => $term) {
            if (is_object($term) && isset($term->taxonomy)) {
                $taxonomy = $term->taxonomy;
                if (!in_array($taxonomy, $enabled_taxonomies, true)) {
                    return $terms;
                }
            } else {
                return $terms;
            }
        }

        if (is_array($terms)) {
            usort($terms, array($this, 'taxcmp'));
        }

        return $terms;
    }

    public function taxcmp($a, $b) {
        if ($a->term_order == $b->term_order) {
            return 0;
        }
        return ($a->term_order < $b->term_order) ? -1 : 1;
    }

    /**
     * איפוס סדר הפוסטים
     */
    public function reset_order() {
        global $wpdb;

        // בדיקת הרשאות
        if (!current_user_can('edit_posts')) {
            wp_die(__('Insufficient permissions', 'at-agency-manager'));
        }

        // בדיקת nonce
        check_ajax_referer('at_page_ordering_nonce', 'nonce');

        $post_types = isset($_POST['post_types']) ? $_POST['post_types'] : array();

        if (empty($post_types)) {
            wp_die(__('No post types selected', 'at-agency-manager'));
        }

        // איפוס הסדר לכל סוגי התוכן שנבחרו
        foreach ($post_types as $post_type) {
            $post_type = sanitize_text_field($post_type);

            $wpdb->update(
                $wpdb->posts,
                array('menu_order' => 0),
                array('post_type' => $post_type),
                array('%d'),
                array('%s')
            );
        }

        wp_cache_flush();

        // לוג
        if ($this->logger) {
            $this->logger->log('page_ordering', 'Reset order for post types: ' . implode(', ', $post_types), 'info');
        }

        wp_die(__('Order reset successfully', 'at-agency-manager'));
    }
}

// אתחול המודול
// המודול יאותחל רק אם הוא מופעל בהגדרות
$modules = get_option('at_agency_manager_modules', []);
if (!empty($modules['page_ordering'])) {
    $at_page_ordering = new AT_Page_Ordering($GLOBALS['at_logger'] ?? null);
}
