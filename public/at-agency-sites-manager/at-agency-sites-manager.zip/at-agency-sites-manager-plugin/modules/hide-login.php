<?php
/**
 * Module: Hide Login / Custom Login URL
 */
if (!defined('ABSPATH')) exit;

class AT_Custom_Login_Slug {
    public function __construct() {
        add_filter('site_url',  [$this, 'filter_login_url'], 10, 4);
        add_filter('wp_redirect', [$this, 'filter_redirect'], 10, 2);
        add_action('template_redirect', [$this, 'maybe_block_wp_login']);
        add_action('init', [$this, 'add_rewrite']);
        add_filter('query_vars', function($vars){$vars[]='at_login_action';return $vars;});
        add_action('template_redirect', [$this, 'handle_custom_login']);
    }

    public function get_slug() {
        $slug = trim(get_option('at_custom_login_slug', 'login'));
        return sanitize_title_with_dashes($slug ?: 'login');
    }

    // החלף קישורים
    public function filter_login_url($url, $path, $orig_scheme, $blog_id) {
        if ($path === 'wp-login.php' || preg_match('/wp-login\.php$/', $url)) {
            $url = str_replace('wp-login.php', $this->get_slug(), $url);
        }
        return $url;
    }

    // רידיירקטים
    public function filter_redirect($location, $status) {
        if (strpos($location, 'wp-login.php') !== false) {
            $location = str_replace('wp-login.php', $this->get_slug(), $location);
        }
        return $location;
    }

    // חסימת גישה ישירה ל-wp-login.php
    public function maybe_block_wp_login() {
        if ($GLOBALS['pagenow'] === 'wp-login.php' && !isset($_GET['action'])) {
            $login_slug = $this->get_slug();
            wp_safe_redirect(site_url($login_slug, 'login'));
            exit;
        }
    }

    public function add_rewrite() {
        // Add rewrite rule for custom login slug
        $slug = $this->get_slug();
        if ($slug !== 'login') {
            add_rewrite_rule('^' . $slug . '/?$', 'index.php?at_login_action=1', 'top');
        }
    }

    public function handle_custom_login() {
        // Handle custom login page request
        if (get_query_var('at_login_action')) {
            // Include WordPress login form
            require_once ABSPATH . 'wp-login.php';
            exit;
        }
    }
}

// Instantiate the class
$at_custom_login = new AT_Custom_Login_Slug();

// Register settings page
add_action('admin_menu', function() {
    $modules = get_option('at_agency_manager_modules', []);
    if (!empty($modules['hide_login'])) {
        add_submenu_page(
            'at-agency-manager',
            __('Custom Login URL Settings', 'at-agency-manager'),
            __('Custom Login', 'at-agency-manager'),
            'manage_options',
            'at-hide-login-settings',
            'at_render_hide_login_settings_page'
        );
    }
});

/**
 * Render Hide Login settings page
 */
function at_render_hide_login_settings_page() {
    // בדיקת הרשאות
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.', 'at-agency-manager'));
    }
    
    $current_slug = get_option('at_custom_login_slug', 'login');
    $login_url = site_url($current_slug, 'login');
    ?>
    <div class="wrap">
        <h1><?php _e('Custom Login URL Settings', 'at-agency-manager'); ?></h1>
        
        <div class="card" style="max-width: 600px; margin-top: 20px;">
            <h2><?php _e('Current Login URL', 'at-agency-manager'); ?></h2>
            <p><strong><?php echo esc_url($login_url); ?></strong></p>
            <p class="description"><?php _e('This is your custom login URL. Use this instead of wp-login.php', 'at-agency-manager'); ?></p>
        </div>
        
        <div class="card" style="max-width: 600px; margin-top: 20px;">
            <h2><?php _e('Test Login URL', 'at-agency-manager'); ?></h2>
            <p><a href="<?php echo esc_url($login_url); ?>" class="button button-primary" target="_blank">
                <?php _e('Open Login Page', 'at-agency-manager'); ?>
            </a></p>
        </div>
        
        <div class="card" style="max-width: 600px; margin-top: 20px; border-left: 4px solid #f0b849;">
            <h2><?php _e('Security Notes', 'at-agency-manager'); ?></h2>
            <ul>
                <li><?php _e('The default wp-login.php will redirect to your custom URL', 'at-agency-manager'); ?></li>
                <li><?php _e('Bookmark your login URL for easy access', 'at-agency-manager'); ?></li>
                <li><?php _e('Do not share your login URL in public places', 'at-agency-manager'); ?></li>
                <li><?php _e('To change the URL, go to AT Agency Settings tab', 'at-agency-manager'); ?></li>
            </ul>
        </div>
        
        <div class="card" style="max-width: 600px; margin-top: 20px; border-left: 4px solid #46b450;">
            <h2><?php _e('Module Status', 'at-agency-manager'); ?></h2>
            <p><span class="dashicons dashicons-yes-alt" style="color: #46b450;"></span> <?php _e('Active', 'at-agency-manager'); ?></p>
            <p class="description"><?php _e('Custom login URL is currently active', 'at-agency-manager'); ?></p>
        </div>
    </div>
    <?php
} 