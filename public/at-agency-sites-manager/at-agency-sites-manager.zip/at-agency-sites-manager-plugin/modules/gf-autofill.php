<?php
/**
 * Module: Gravity Forms Autofill
 * Automatically fill Gravity Forms fields for logged-in users using data from their profile.
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class AT_GF_Autofill {
    /**
     * Mapping of GF parameter names to user data sources.
     * Left side: Parameter name in GF (set in field settings -> Allow field to be populated dynamically)
     * Right side: User field (standard WP_User field or meta key)
     */
    private $params_map = array(
        'first_name' => 'first_name',
        'last_name'  => 'last_name',
        'email'      => 'user_email',
        'user_email' => 'user_email',
        'phone'      => 'phone',
        'user_phone' => 'phone',
        'occupation' => 'occupation',
        'role'       => 'occupation',
        'workplace'  => 'workplace',
        'company'    => 'workplace',
        'title'      => 'title',
        'user_title' => 'title',
        'region'     => 'region',
        'gender'     => 'gender',
        'sex'        => 'sex',
    );

    public function __construct() {
        // Only run if Gravity Forms is active
        if (!class_exists('GFAPI')) {
            return;
        }

        $this->init_filters();
    }

    /**
     * Initialize Gravity Forms dynamic population filters.
     */
    private function init_filters() {
        foreach ($this->params_map as $param => $meta_key) {
            add_filter("gform_field_value_{$param}", array($this, 'get_user_value_for_param'), 10, 1);
        }
    }

    /**
     * Callback for gform_field_value_{parameter_name} filter.
     * 
     * @param mixed $value The current field value.
     * @return mixed The populated value if user is logged in, otherwise original value.
     */
    public function get_user_value_for_param($value) {
        if (!is_user_logged_in()) {
            return $value;
        }

        // Get parameter name from the filter tag
        $current_filter = current_filter();
        $param = str_replace('gform_field_value_', '', $current_filter);

        if (!isset($this->params_map[$param])) {
            return $value;
        }

        $meta_key = $this->params_map[$param];
        $current_user = wp_get_current_user();

        // Handle standard user object fields
        if (in_array($meta_key, array('first_name', 'last_name', 'user_email'))) {
            return $current_user->$meta_key;
        }

        // Handle user meta fields
        $meta_value = get_user_meta($current_user->ID, $meta_key, true);
        
        return !empty($meta_value) ? $meta_value : $value;
    }
}

// Initialize the module if enabled in settings
$modules = get_option('at_agency_manager_modules', []);
if (!empty($modules['gf_autofill'])) {
    new AT_GF_Autofill();
}
