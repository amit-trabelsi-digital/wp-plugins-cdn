<?php
/**
 * Module: Activity Log
 * מעקב אחר פעילות משתמשים באתר וורדפרס כולל התחברויות, עריכות תוכן ושינויי הגדרות
 * נטען רק אם המודול הופעל במסך ההגדרות (at_agency_manager_modules[activity_log]).
 */

// הגנה מפני גישה ישירה
if (!defined('ABSPATH')) {
    exit;
}

/**
 * מחלקה לניהול מעקב אחר פעילות משתמשים
 */
class AT_Activity_Log {
    /**
     * @var AT_Agency_Manager_Logger מופע של מחלקת הלוגר
     */
    private $logger;
    
    /**
     * @var string שם הטבלה לשמירת הפעילויות
     */
    private $table_name;
    
    /**
     * אתחול המחלקה והגדרת האזנה לאירועים רלוונטיים
     */
    public function __construct() {
        global $wpdb;

        // אתחול הלוגר אם קיים
        if (class_exists('AT_Agency_Manager_Logger')) {
            $this->logger = new AT_Agency_Manager_Logger();
        }

        // הגדרת שם הטבלה
        $this->table_name = $wpdb->prefix . 'at_activity_log';

        // הרשמה לאירועים
        add_action('wp_login', array($this, 'log_user_login'), 10, 2);
        add_action('wp_logout', array($this, 'log_user_logout'));
        add_action('user_register', array($this, 'log_user_registered'));
        add_action('profile_update', array($this, 'log_profile_updated'));
        add_action('save_post', array($this, 'log_post_saved'), 10, 3);
        add_action('delete_post', array($this, 'log_post_deleted'));
        add_action('activated_plugin', array($this, 'log_plugin_activated'));
        add_action('deactivated_plugin', array($this, 'log_plugin_deactivated'));
        add_action('switch_theme', array($this, 'log_theme_changed'));
        add_action('updated_option', array($this, 'log_option_updated'), 10, 3);

        // הוספת דף ניהול
        add_action('admin_menu', array($this, 'add_activity_menu'));

        // יצירת טבלת הפעילות אם לא קיימת
        add_action('init', array($this, 'maybe_create_table'));

        // ניקוי אוטומטי של לוגים ישנים
        add_action('at_activity_log_cleanup', array($this, 'cleanup_old_logs'));

        // רישום הגדרות
        add_action('admin_init', array($this, 'register_settings'));

        // AJAX למחיקת לוגים
        add_action('wp_ajax_at_activity_log_clear', array($this, 'ajax_clear_logs'));

        // הפעלת cleanup יומי אם לא מתוזמן
        if (!wp_next_scheduled('at_activity_log_cleanup')) {
            wp_schedule_event(time(), 'daily', 'at_activity_log_cleanup');
        }
    }
    
    /**
     * יצירת טבלת הפעילות אם לא קיימת
     */
    public function maybe_create_table() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS {$this->table_name} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL DEFAULT 0,
            user_name varchar(255) NOT NULL,
            user_role varchar(255) NOT NULL,
            action varchar(255) NOT NULL,
            object_type varchar(255) NOT NULL,
            object_id bigint(20) DEFAULT NULL,
            object_name varchar(255) DEFAULT NULL,
            ip_address varchar(45) NOT NULL,
            user_agent text,
            created_at datetime NOT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY action (action),
            KEY object_type (object_type),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    /**
     * הוספת דף ניהול לפעילויות
     * NOTE: Menu is now registered in class-settings.php to avoid duplicate registration
     */
    public function add_activity_menu() {
        // Menu registration moved to class-settings.php
        // This method kept for backward compatibility but does nothing
    }
    
    /**
     * הצגת דף ניהול הפעילויות
     */
    public function render_activity_page() {
        // בדיקת הרשאות
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'at-agency-manager'));
        }
        
        global $wpdb;
        
        // מספר פעילויות לעמוד
        $per_page = 20;
        
        // מספר העמוד הנוכחי
        $page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        
        // פילטרים
        $user_filter = isset($_GET['user']) ? intval($_GET['user']) : 0;
        $action_filter = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : '';
        $type_filter = isset($_GET['type']) ? sanitize_text_field($_GET['type']) : '';
        
        // בניית השאילתה
        $query = "SELECT SQL_CALC_FOUND_ROWS * FROM {$this->table_name} WHERE 1=1";
        $query_args = array();
        
        if ($user_filter) {
            $query .= " AND user_id = %d";
            $query_args[] = $user_filter;
        }
        
        if ($action_filter) {
            $query .= " AND action = %s";
            $query_args[] = $action_filter;
        }
        
        if ($type_filter) {
            $query .= " AND object_type = %s";
            $query_args[] = $type_filter;
        }
        
        // סידור לפי זמן יצירה
        $query .= " ORDER BY created_at DESC";
        
        // הגבלת מספר התוצאות לעמוד
        $query .= " LIMIT %d, %d";
        $query_args[] = ($page - 1) * $per_page;
        $query_args[] = $per_page;
        
        // ביצוע השאילתה
        $activities = $wpdb->get_results($wpdb->prepare($query, $query_args));
        
        // מספר התוצאות הכולל
        $total_items = $wpdb->get_var("SELECT FOUND_ROWS()");
        $total_pages = ceil($total_items / $per_page);
        
        // קבלת רשימת המשתמשים לפילטר
        $users = get_users(array('fields' => array('ID', 'display_name')));
        
        // פעולות אפשריות
        $actions = $wpdb->get_col("SELECT DISTINCT action FROM {$this->table_name}");
        
        // סוגי אובייקטים
        $object_types = $wpdb->get_col("SELECT DISTINCT object_type FROM {$this->table_name}");
        
        // קבלת סטטיסטיקות
        $total_count = $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_name}");
        $oldest_log = $wpdb->get_var("SELECT created_at FROM {$this->table_name} ORDER BY created_at ASC LIMIT 1");

        // הגדרות מגבלת שמירה
        $retention_months = get_option('at_activity_log_retention_months', 0);
        $max_records = get_option('at_activity_log_max_records', 0);

        ?>
        <div class="wrap">
            <h1><?php _e('Activity Log', 'at-agency-manager'); ?></h1>

            <!-- סטטיסטיקות ומידע -->
            <div class="notice notice-info" style="margin-bottom:20px;">
                <p>
                    <strong><?php _e('Statistics:', 'at-agency-manager'); ?></strong><br>
                    <?php _e('Total Records:', 'at-agency-manager'); ?> <strong><?php echo number_format_i18n($total_count); ?></strong>
                    <?php if ($oldest_log): ?>
                        | <?php _e('Oldest Record:', 'at-agency-manager'); ?> <strong><?php echo esc_html($oldest_log); ?></strong>
                    <?php endif; ?>
                </p>
            </div>

            <!-- הגדרות מגבלת שמירה -->
            <h2><?php _e('Retention Settings', 'at-agency-manager'); ?></h2>
            <form method="post" action="options.php" style="margin-bottom:20px;">
                <?php settings_fields('at_activity_log_settings'); ?>
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('Keep logs for (months)', 'at-agency-manager'); ?></th>
                        <td>
                            <input type="number" name="at_activity_log_retention_months" value="<?php echo esc_attr($retention_months); ?>" min="0" class="small-text" />
                            <p class="description"><?php _e('0 = no time limit. Logs older than this will be automatically deleted daily.', 'at-agency-manager'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Maximum records', 'at-agency-manager'); ?></th>
                        <td>
                            <input type="number" name="at_activity_log_max_records" value="<?php echo esc_attr($max_records); ?>" min="0" class="regular-text" />
                            <p class="description"><?php _e('0 = no limit. Only the most recent records up to this number will be kept.', 'at-agency-manager'); ?></p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(__('Save Retention Settings', 'at-agency-manager')); ?>
            </form>

            <div style="margin-bottom:20px;">
                <button type="button" class="button button-secondary" id="at-activity-log-clear-btn">
                    <?php _e('Clear All Logs', 'at-agency-manager'); ?>
                </button>
                <span id="at-activity-log-clear-status"></span>
            </div>

            <h2><?php _e('Activity Records', 'at-agency-manager'); ?></h2>
            <form method="get">
                <input type="hidden" name="page" value="at-activity-log">
                
                <div class="tablenav top">
                    <div class="alignleft actions">
                        <select name="user">
                            <option value="0"><?php _e('All Users', 'at-agency-manager'); ?></option>
                            <?php foreach ($users as $user) : ?>
                                <option value="<?php echo $user->ID; ?>" <?php selected($user_filter, $user->ID); ?>>
                                    <?php echo esc_html($user->display_name); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        
                        <select name="action">
                            <option value=""><?php _e('All Actions', 'at-agency-manager'); ?></option>
                            <?php foreach ($actions as $action) : ?>
                                <option value="<?php echo esc_attr($action); ?>" <?php selected($action_filter, $action); ?>>
                                    <?php echo esc_html($action); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        
                        <select name="type">
                            <option value=""><?php _e('All Types', 'at-agency-manager'); ?></option>
                            <?php foreach ($object_types as $type) : ?>
                                <option value="<?php echo esc_attr($type); ?>" <?php selected($type_filter, $type); ?>>
                                    <?php echo esc_html($type); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        
                        <input type="submit" class="button" value="<?php _e('Filter', 'at-agency-manager'); ?>">
                    </div>
                    
                    <div class="tablenav-pages">
                        <?php if ($total_pages > 1) : ?>
                            <span class="displaying-num">
                                <?php printf(
                                    _n('%s item', '%s items', $total_items, 'at-agency-manager'),
                                    number_format_i18n($total_items)
                                ); ?>
                            </span>
                            
                            <span class="pagination-links">
                                <?php
                                echo paginate_links(array(
                                    'base'      => add_query_arg('paged', '%#%'),
                                    'format'    => '',
                                    'prev_text' => '&laquo;',
                                    'next_text' => '&raquo;',
                                    'total'     => $total_pages,
                                    'current'   => $page
                                ));
                                ?>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('Date & Time', 'at-agency-manager'); ?></th>
                        <th><?php _e('User', 'at-agency-manager'); ?></th>
                        <th><?php _e('Action', 'at-agency-manager'); ?></th>
                        <th><?php _e('Object Type', 'at-agency-manager'); ?></th>
                        <th><?php _e('Object', 'at-agency-manager'); ?></th>
                        <th><?php _e('IP', 'at-agency-manager'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($activities)) : ?>
                        <tr>
                            <td colspan="6"><?php _e('No activities found.', 'at-agency-manager'); ?></td>
                        </tr>
                    <?php else : ?>
                        <?php foreach ($activities as $activity) : ?>
                            <tr>
                                <td><?php echo esc_html($activity->created_at); ?></td>
                                <td>
                                    <?php 
                                    if ($activity->user_id) {
                                        echo '<a href="' . esc_url(admin_url('user-edit.php?user_id=' . $activity->user_id)) . '">';
                                        echo esc_html($activity->user_name);
                                        echo '</a>';
                                        echo ' <small>(' . esc_html($activity->user_role) . ')</small>';
                                    } else {
                                        echo esc_html($activity->user_name);
                                    }
                                    ?>
                                </td>
                                <td><?php echo esc_html($activity->action); ?></td>
                                <td><?php echo esc_html($activity->object_type); ?></td>
                                <td>
                                    <?php 
                                    if ($activity->object_id && in_array($activity->object_type, array('post', 'page', 'product'))) {
                                        echo '<a href="' . esc_url(get_edit_post_link($activity->object_id)) . '">';
                                        echo esc_html($activity->object_name);
                                        echo '</a>';
                                    } else {
                                        echo esc_html($activity->object_name);
                                    }
                                    ?>
                                </td>
                                <td><?php echo esc_html($activity->ip_address); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>

            <script type="text/javascript">
            jQuery(document).ready(function($) {
                $('#at-activity-log-clear-btn').on('click', function() {
                    if (!confirm('<?php _e('Are you sure you want to delete ALL activity logs? This action cannot be undone.', 'at-agency-manager'); ?>')) {
                        return;
                    }

                    var btn = $(this);
                    var status = $('#at-activity-log-clear-status');

                    btn.prop('disabled', true).text('<?php _e('Clearing...', 'at-agency-manager'); ?>');

                    $.post(ajaxurl, {
                        action: 'at_activity_log_clear',
                        nonce: '<?php echo wp_create_nonce('at_activity_log_clear'); ?>'
                    }, function(response) {
                        if (response.success) {
                            status.html('<span style="color:green;"> ✓ ' + response.data + '</span>');
                            setTimeout(function() {
                                location.reload();
                            }, 1000);
                        } else {
                            status.html('<span style="color:red;"> ✗ ' + response.data + '</span>');
                            btn.prop('disabled', false).text('<?php _e('Clear All Logs', 'at-agency-manager'); ?>');
                        }
                    });
                });
            });
            </script>
        </div>
        <?php
    }
    
    /**
     * הוספת רשומת פעילות לטבלה
     * 
     * @param int $user_id מזהה המשתמש
     * @param string $action סוג הפעולה
     * @param string $object_type סוג האובייקט
     * @param int|null $object_id מזהה האובייקט
     * @param string|null $object_name שם האובייקט
     * 
     * @return int|false מזהה הרשומה או false במקרה של כישלון
     */
    public function add_activity($user_id, $action, $object_type, $object_id = null, $object_name = null) {
        global $wpdb;
        
        // קבלת מידע על המשתמש
        if ($user_id) {
            $user = get_user_by('id', $user_id);
            $user_name = $user ? $user->display_name : __('Unknown', 'at-agency-manager');
            $user_roles = $user ? $user->roles : array();
            $user_role = !empty($user_roles) ? reset($user_roles) : '';
        } else {
            $user_name = __('Guest', 'at-agency-manager');
            $user_role = '';
        }
        
        // רישום באמצעות הלוגר אם קיים
        if ($this->logger) {
            $message = sprintf(
                '%s: %s - %s %s',
                $user_name,
                $action,
                $object_type,
                $object_name ? "({$object_name})" : ''
            );
            $this->logger->log('activity', $message, 'info');
        }
        
        // הוספת הרשומה לטבלה
        return $wpdb->insert(
            $this->table_name,
            array(
                'user_id'    => $user_id,
                'user_name'  => $user_name,
                'user_role'  => $user_role,
                'action'     => $action,
                'object_type' => $object_type,
                'object_id'  => $object_id,
                'object_name' => $object_name,
                'ip_address' => $this->get_client_ip(),
                'user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '',
                'created_at' => current_time('mysql')
            ),
            array(
                '%d', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s'
            )
        );
    }
    
    /**
     * קבלת כתובת ה-IP של המשתמש
     * 
     * @return string כתובת ה-IP
     */
    private function get_client_ip() {
        $ip = '';
        
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        
        return sanitize_text_field($ip);
    }
    
    /**
     * רישום התחברות משתמש
     * 
     * @param string $user_login שם המשתמש
     * @param object $user אובייקט המשתמש
     */
    public function log_user_login($user_login, $user) {
        $this->add_activity(
            $user->ID,
            'login',
            'user',
            $user->ID,
            $user->display_name
        );
    }
    
    /**
     * רישום התנתקות משתמש
     */
    public function log_user_logout() {
        $user_id = get_current_user_id();
        if ($user_id) {
            $user = get_user_by('id', $user_id);
            $this->add_activity(
                $user_id,
                'logout',
                'user',
                $user_id,
                $user->display_name
            );
        }
    }
    
    /**
     * רישום רישום משתמש חדש
     * 
     * @param int $user_id מזהה המשתמש
     */
    public function log_user_registered($user_id) {
        $user = get_user_by('id', $user_id);
        $this->add_activity(
            get_current_user_id(),
            'registered',
            'user',
            $user_id,
            $user->display_name
        );
    }
    
    /**
     * רישום עדכון פרופיל משתמש
     * 
     * @param int $user_id מזהה המשתמש
     */
    public function log_profile_updated($user_id) {
        $user = get_user_by('id', $user_id);
        $this->add_activity(
            get_current_user_id(),
            'updated',
            'user',
            $user_id,
            $user->display_name
        );
    }
    
    /**
     * רישום שמירת פוסט
     * 
     * @param int $post_id מזהה הפוסט
     * @param object $post אובייקט הפוסט
     * @param bool $update האם זה עדכון או יצירה
     */
    public function log_post_saved($post_id, $post, $update) {
        // לא לרשום שמירות אוטומטיות וטיוטות
        if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id) || $post->post_status === 'auto-draft') {
            return;
        }
        
        // האם זו יצירה או עדכון
        $action = $update ? 'updated' : 'created';
        
        $this->add_activity(
            get_current_user_id(),
            $action,
            $post->post_type,
            $post_id,
            $post->post_title
        );
    }
    
    /**
     * רישום מחיקת פוסט
     * 
     * @param int $post_id מזהה הפוסט
     */
    public function log_post_deleted($post_id) {
        $post = get_post($post_id);
        
        // וידוא שהפוסט קיים
        if (!$post) {
            return;
        }
        
        $this->add_activity(
            get_current_user_id(),
            'deleted',
            $post->post_type,
            $post_id,
            $post->post_title
        );
    }
    
    /**
     * רישום הפעלת תוסף
     * 
     * @param string $plugin קובץ התוסף
     */
    public function log_plugin_activated($plugin) {
        $plugins = get_plugins();
        $plugin_name = isset($plugins[$plugin]) ? $plugins[$plugin]['Name'] : $plugin;
        
        $this->add_activity(
            get_current_user_id(),
            'activated',
            'plugin',
            null,
            $plugin_name
        );
    }
    
    /**
     * רישום כיבוי תוסף
     * 
     * @param string $plugin קובץ התוסף
     */
    public function log_plugin_deactivated($plugin) {
        $plugins = get_plugins();
        $plugin_name = isset($plugins[$plugin]) ? $plugins[$plugin]['Name'] : $plugin;
        
        $this->add_activity(
            get_current_user_id(),
            'deactivated',
            'plugin',
            null,
            $plugin_name
        );
    }
    
    /**
     * רישום שינוי ערכת נושא
     * 
     * @param string $new_theme שם ערכת הנושא החדשה
     */
    public function log_theme_changed($new_theme) {
        $theme = wp_get_theme($new_theme);
        
        $this->add_activity(
            get_current_user_id(),
            'activated',
            'theme',
            null,
            $theme->get('Name')
        );
    }
    
    /**
     * רישום עדכון הגדרה
     * 
     * @param string $option שם ההגדרה
     * @param mixed $old_value הערך הישן
     * @param mixed $new_value הערך החדש
     */
    public function log_option_updated($option, $old_value, $new_value) {
        // נרשום רק הגדרות חשובות
        $important_options = array(
            'blogname',
            'blogdescription',
            'siteurl',
            'home',
            'admin_email',
            'users_can_register',
            'default_role',
            'mailserver_url',
            'permalink_structure'
        );
        
        if (!in_array($option, $important_options)) {
            return;
        }
        
        $this->add_activity(
            get_current_user_id(),
            'updated',
            'option',
            null,
            $option
        );
    }

    /**
     * רישום הגדרות Activity Log
     */
    public function register_settings() {
        register_setting('at_activity_log_settings', 'at_activity_log_retention_months');
        register_setting('at_activity_log_settings', 'at_activity_log_max_records');
    }

    /**
     * ניקוי לוגים ישנים על פי הגדרות מגבלת השמירה
     */
    public function cleanup_old_logs() {
        global $wpdb;

        $retention_months = get_option('at_activity_log_retention_months', 0);
        $max_records = get_option('at_activity_log_max_records', 0);

        // מחיקה לפי תאריך
        if ($retention_months > 0) {
            $date_threshold = date('Y-m-d H:i:s', strtotime("-{$retention_months} months"));
            $wpdb->query($wpdb->prepare(
                "DELETE FROM {$this->table_name} WHERE created_at < %s",
                $date_threshold
            ));
        }

        // מחיקה לפי מספר רשומות מקסימלי
        if ($max_records > 0) {
            $count = $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_name}");
            if ($count > $max_records) {
                $to_delete = $count - $max_records;
                $wpdb->query($wpdb->prepare(
                    "DELETE FROM {$this->table_name} ORDER BY created_at ASC LIMIT %d",
                    $to_delete
                ));
            }
        }
    }

    /**
     * AJAX: מחיקת כל הלוגים
     */
    public function ajax_clear_logs() {
        // בדיקת הרשאות
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Permission denied', 'at-agency-manager'));
        }

        // בדיקת nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'at_activity_log_clear')) {
            wp_send_json_error(__('Security check failed', 'at-agency-manager'));
        }

        global $wpdb;
        $result = $wpdb->query("TRUNCATE TABLE {$this->table_name}");

        if ($result !== false) {
            wp_send_json_success(__('All activity logs cleared successfully', 'at-agency-manager'));
        } else {
            wp_send_json_error(__('Failed to clear activity logs', 'at-agency-manager'));
        }
    }
}

// אתחול המודול אם מופעל בהגדרות
$modules = get_option('at_agency_manager_modules', []);
if (!empty($modules['activity_log'])) {
    global $at_activity_log_instance;
    $at_activity_log_instance = new AT_Activity_Log();
} 