<?php
/**
 * Module: New Relic Monitoring Settings Page
 * Provides UI for managing New Relic APM configuration
 */

if (!defined('ABSPATH')) exit;

// Register New Relic settings
add_action('admin_init', function() {
    register_setting('at_newrelic_settings', 'at_agency_newrelic_enabled');
    register_setting('at_newrelic_settings', 'at_agency_newrelic_app_name');
    register_setting('at_newrelic_settings', 'at_agency_newrelic_capture_urls');
    register_setting('at_newrelic_settings', 'at_agency_newrelic_error_logging');
    register_setting('at_newrelic_settings', 'at_agency_newrelic_memory_monitoring');
});

// Register New Relic settings page
add_action('admin_menu', function() {
    $modules = get_option('at_agency_manager_modules', []);
    if (!empty($modules['newrelic_monitoring'])) {
        add_submenu_page(
            'at-agency-manager',
            __('New Relic Settings', 'at-agency-manager'),
            __('New Relic', 'at-agency-manager'),
            'manage_options',
            'at-newrelic-settings',
            'at_render_newrelic_settings_page'
        );
    }
});

/**
 * Render New Relic settings page
 */
function at_render_newrelic_settings_page() {
    // בדיקת הרשאות
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.', 'at-agency-manager'));
    }
    
    $nr_extension_loaded = extension_loaded('newrelic');
    $nr_enabled = get_option('at_agency_newrelic_enabled');
    $nr_app_name = get_option('at_agency_newrelic_app_name', '');
    $nr_capture_urls = get_option('at_agency_newrelic_capture_urls');
    $nr_error_logging = get_option('at_agency_newrelic_error_logging');
    $nr_memory_monitoring = get_option('at_agency_newrelic_memory_monitoring');
    
    ?>
    <div class="wrap">
        <h1><?php _e('New Relic Monitoring Settings', 'at-agency-manager'); ?></h1>
        
        <?php if (!$nr_extension_loaded): ?>
            <div class="notice notice-error" style="margin-top: 20px;">
                <p><strong><?php _e('New Relic PHP Extension Not Found', 'at-agency-manager'); ?></strong></p>
                <p><?php _e('The New Relic PHP extension is not installed on this server. Please install and configure it before using this module.', 'at-agency-manager'); ?></p>
            </div>
        <?php else: ?>
            <div class="notice notice-success" style="margin-top: 20px;">
                <p><strong><?php _e('New Relic Extension Status:', 'at-agency-manager'); ?></strong></p>
                <p><span class="dashicons dashicons-yes-alt" style="color: #46b450;"></span> <?php _e('New Relic PHP Extension v' . phpversion('newrelic') . ' is installed and active', 'at-agency-manager'); ?></p>
            </div>
        <?php endif; ?>
        
        <form method="post" action="options.php" style="margin-top: 20px;">
            <?php settings_fields('at_newrelic_settings'); ?>
            
            <div class="card" style="max-width: 800px;">
                <h2><?php _e('Configuration', 'at-agency-manager'); ?></h2>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('New Relic Monitoring', 'at-agency-manager'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" 
                                       name="at_agency_newrelic_enabled" 
                                       value="1" 
                                       <?php checked($nr_enabled, 1); ?>
                                       <?php disabled(!$nr_extension_loaded, true); ?>
                                />
                                <?php _e('Enable New Relic APM Monitoring', 'at-agency-manager'); ?>
                            </label>
                            <p class="description">
                                <?php _e('Enables automatic transaction tracking and performance monitoring.', 'at-agency-manager'); ?>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php _e('Application Name (Override)', 'at-agency-manager'); ?></th>
                        <td>
                            <input type="text" 
                                   name="at_agency_newrelic_app_name" 
                                   value="<?php echo esc_attr($nr_app_name); ?>" 
                                   class="regular-text"
                                   <?php disabled(!$nr_extension_loaded, true); ?>
                            />
                            <p class="description">
                                <?php _e('Leave empty to use the default app name from newrelic.ini', 'at-agency-manager'); ?>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php _e('Tracking Options', 'at-agency-manager'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" 
                                       name="at_agency_newrelic_capture_urls" 
                                       value="1" 
                                       <?php checked($nr_capture_urls, 1); ?>
                                       <?php disabled(!$nr_extension_loaded, true); ?>
                                />
                                <?php _e('Capture Request URLs', 'at-agency-manager'); ?>
                            </label>
                            <p class="description">
                                <?php _e('Track all request URLs in transaction data', 'at-agency-manager'); ?>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php _e('Error Tracking', 'at-agency-manager'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" 
                                       name="at_agency_newrelic_error_logging" 
                                       value="1" 
                                       <?php checked($nr_error_logging, 1); ?>
                                       <?php disabled(!$nr_extension_loaded, true); ?>
                                />
                                <?php _e('Enable Error Logging', 'at-agency-manager'); ?>
                            </label>
                            <p class="description">
                                <?php _e('Send PHP errors and exceptions to New Relic', 'at-agency-manager'); ?>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php _e('Memory Monitoring', 'at-agency-manager'); ?></th>
                        <td>
                            <label>
                                <input type="checkbox" 
                                       name="at_agency_newrelic_memory_monitoring" 
                                       value="1" 
                                       <?php checked($nr_memory_monitoring, 1); ?>
                                       <?php disabled(!$nr_extension_loaded, true); ?>
                                />
                                <?php _e('Monitor Memory Usage', 'at-agency-manager'); ?>
                            </label>
                            <p class="description">
                                <?php _e('Track PHP memory usage and peak memory', 'at-agency-manager'); ?>
                            </p>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button(__('Save Settings', 'at-agency-manager')); ?>
            </div>
        </form>
        
        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h2><?php _e('Information', 'at-agency-manager'); ?></h2>
            
            <h3><?php _e('What is New Relic?', 'at-agency-manager'); ?></h3>
            <p><?php _e('New Relic Application Performance Monitoring (APM) provides real-time insights into your application performance, helping you identify and troubleshoot performance problems.', 'at-agency-manager'); ?></p>
            
            <h3><?php _e('Requirements', 'at-agency-manager'); ?></h3>
            <ul>
                <li><?php _e('New Relic PHP agent installed on your server', 'at-agency-manager'); ?></li>
                <li><?php _e('New Relic account and API key configured', 'at-agency-manager'); ?></li>
                <li><?php _e('Valid license key in newrelic.ini configuration', 'at-agency-manager'); ?></li>
            </ul>
            
            <h3><?php _e('Documentation', 'at-agency-manager'); ?></h3>
            <ul>
                <li><a href="https://docs.newrelic.com/docs/agents/php-agent/installation/" target="_blank">New Relic PHP Agent Installation</a></li>
                <li><a href="https://docs.newrelic.com/docs/agents/php-agent/configuration/" target="_blank">New Relic PHP Agent Configuration</a></li>
                <li><a href="https://docs.newrelic.com/docs/apm/" target="_blank">New Relic APM Documentation</a></li>
            </ul>
        </div>
    </div>
    <?php
}

