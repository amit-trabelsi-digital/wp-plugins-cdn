<?php
/**
 * Module: ACF Local JSON Manager
 * ניהול וצפיה בסטטוס מצב עבודה עם ACF Local JSON
 * מאפשר שמירה וטעינה של שדות ACF מקבצי JSON
 */

if (!defined('ABSPATH')) exit;

class AT_ACF_Local_JSON_Manager {

    public function __construct() {
        // בדיקה ש-ACF מותקן ופועל
        if (!$this->is_acf_active()) {
            add_action('admin_notices', [$this, 'acf_not_installed_notice']);
            return;
        }

        // הוספת פילטרים ACF Local JSON
        // מכיוון שהקונסטרקטור נקרא מ-acf/init, הפילטרים יכולים להירשם מיד
        $this->register_acf_filters();

        // יצירת תיקיות דרושות בעת הפעלה
        add_action('admin_init', [$this, 'ensure_acf_json_directories']);

        // הוספת מידע לעמוד בריאות האתר
        add_filter('at_site_health_data', [$this, 'add_acf_json_health_info']);

        // הוספת עמוד ניהול ACF Local JSON
        add_action('admin_menu', [$this, 'register_acf_json_menu']);
    }

    /**
     * רישום פילטרים ACF - נקרא רק אחרי ש-ACF נטען
     */
    public function register_acf_filters() {
        add_filter('acf/settings/save_json', [$this, 'acf_json_save_path']);
        add_filter('acf/settings/load_json', [$this, 'acf_json_load_paths']);
    }

    /**
     * בדיקה אם ACF מותקן ופועל
     */
    private function is_acf_active() {
        // מכיוון שהמודול נטען ב-acf/init, ACF כבר פעיל
        // השתמש ב-false כדי למנוע autoload שגורם לטעינת תרגומים מוקדמת
        return function_exists('acf_get_field_groups') || class_exists('ACF', false);
    }

    /**
     * הודעת שגיאה אם ACF לא מותקן
     */
    public function acf_not_installed_notice() {
        ?>
        <div class="notice notice-warning is-dismissible">
            <p><?php _e('ACF Local JSON Manager requires Advanced Custom Fields (ACF) plugin to be installed and activated.', 'at-agency-manager'); ?></p>
        </div>
        <?php
    }

    /**
     * הגדרת נתיב שמירת ACF JSON
     */
    public function acf_json_save_path($path) {
        $custom_path = get_stylesheet_directory() . '/acf-json';

        // יצירת התיקיה אם היא לא קיימת
        if (!file_exists($custom_path)) {
            wp_mkdir_p($custom_path);
        }

        return $custom_path;
    }

    /**
     * הגדרת נתיבי טעינת ACF JSON
     */
    public function acf_json_load_paths($paths) {
        // הסרת הנתיב ברירת המחדל
        unset($paths[0]);

        // הוספת הנתיב המותאם אישית
        $custom_path = get_stylesheet_directory() . '/acf-json';
        if (file_exists($custom_path)) {
            $paths[] = $custom_path;
        }

        return $paths;
    }

    /**
     * וודא שתיקיות ACF JSON קיימות וניתנות לכתיבה
     */
    public function ensure_acf_json_directories() {
        $acf_json_path = get_stylesheet_directory() . '/acf-json';

        if (!file_exists($acf_json_path)) {
            wp_mkdir_p($acf_json_path);
        }

        // בדיקה והגדרת הרשאות
        if (!wp_is_writable($acf_json_path)) {
            add_action('admin_notices', function() {
                ?>
                <div class="notice notice-warning is-dismissible">
                    <p><?php printf(__('ACF JSON directory is not writable: %s', 'at-agency-manager'), esc_html(get_stylesheet_directory() . '/acf-json')); ?></p>
                </div>
                <?php
            });
        }
    }

    /**
     * הוספת מידע ACF Local JSON לעמוד הבריאות
     */
    public function add_acf_json_health_info($data) {
        $acf_json_path = get_stylesheet_directory() . '/acf-json';
        $acf_json_exists = file_exists($acf_json_path);
        $acf_json_writable = wp_is_writable($acf_json_path);

        // ספירת קבצי JSON בתיקיה
        $json_files_count = 0;
        if ($acf_json_exists) {
            $json_files = glob($acf_json_path . '/*.json');
            $json_files_count = is_array($json_files) ? count($json_files) : 0;
        }

        // בדיקה אם יש שדות ACF פעילים
        $field_groups_count = 0;
        if ($this->is_acf_active()) {
            $field_groups = acf_get_field_groups();
            $field_groups_count = is_array($field_groups) ? count($field_groups) : 0;
        }

        // הוספת מידע חדש
        $data['acf_json_directory'] = $acf_json_exists ? __('Exists', 'at-agency-manager') : __('Missing', 'at-agency-manager');
        $data['acf_json_writable'] = $acf_json_writable;
        $data['acf_json_files_count'] = $json_files_count;
        $data['acf_field_groups_count'] = $field_groups_count;
        $data['acf_active'] = $this->is_acf_active();

        return $data;
    }

    /**
     * רישום עמוד ניהול ACF Local JSON
     */
    public function register_acf_json_menu() {
        $modules = get_option('at_agency_manager_modules', []);
        if (!empty($modules['acf_local_json'])) {
            add_submenu_page(
                'at-agency-manager',
                __('ACF Local JSON Manager', 'at-agency-manager'),
                __('ACF Local JSON', 'at-agency-manager'),
                'manage_options',
                'at-acf-local-json',
                [$this, 'acf_json_manager_page']
            );
        }
    }

    /**
     * עמוד ניהול ACF Local JSON
     */
    public function acf_json_manager_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions.', 'at-agency-manager'));
        }

        $acf_json_path = get_stylesheet_directory() . '/acf-json';
        $json_files = glob($acf_json_path . '/*.json');
        $field_groups = $this->is_acf_active() ? acf_get_field_groups() : [];
        ?>
        <div class="wrap">
            <h1><?php _e('ACF Local JSON Manager', 'at-agency-manager'); ?></h1>

            <div class="notice notice-info">
                <p><?php _e('This tool manages ACF field groups synchronization with local JSON files.', 'at-agency-manager'); ?></p>
            </div>

            <div class="acf-json-status">
                <h2><?php _e('Status Overview', 'at-agency-manager'); ?></h2>
                <table class="widefat">
                    <tbody>
                        <tr>
                            <td><strong><?php _e('ACF Plugin Status', 'at-agency-manager'); ?></strong></td>
                            <td class="<?php echo $this->is_acf_active() ? 'status-good' : 'status-bad'; ?>">
                                <?php echo $this->is_acf_active() ? __('Active', 'at-agency-manager') : __('Inactive', 'at-agency-manager'); ?>
                            </td>
                        </tr>
                        <tr>
                            <td><strong><?php _e('JSON Directory', 'at-agency-manager'); ?></strong></td>
                            <td class="<?php echo file_exists($acf_json_path) ? 'status-good' : 'status-bad'; ?>">
                                <?php echo esc_html($acf_json_path); ?>
                                <?php echo file_exists($acf_json_path) ? ' (' . __('Exists', 'at-agency-manager') . ')' : ' (' . __('Missing', 'at-agency-manager') . ')'; ?>
                            </td>
                        </tr>
                        <tr>
                            <td><strong><?php _e('Directory Permissions', 'at-agency-manager'); ?></strong></td>
                            <td class="<?php echo wp_is_writable($acf_json_path) ? 'status-good' : 'status-bad'; ?>">
                                <?php echo wp_is_writable($acf_json_path) ? __('Writable', 'at-agency-manager') : __('Not Writable', 'at-agency-manager'); ?>
                            </td>
                        </tr>
                        <tr>
                            <td><strong><?php _e('JSON Files Count', 'at-agency-manager'); ?></strong></td>
                            <td><?php echo is_array($json_files) ? count($json_files) : 0; ?></td>
                        </tr>
                        <tr>
                            <td><strong><?php _e('Field Groups Count', 'at-agency-manager'); ?></strong></td>
                            <td><?php echo is_array($field_groups) ? count($field_groups) : 0; ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <?php if (!empty($json_files)): ?>
            <div class="acf-json-files">
                <h2><?php _e('JSON Files', 'at-agency-manager'); ?></h2>
                <table class="widefat">
                    <thead>
                        <tr>
                            <th><?php _e('File Name', 'at-agency-manager'); ?></th>
                            <th><?php _e('Size', 'at-agency-manager'); ?></th>
                            <th><?php _e('Modified', 'at-agency-manager'); ?></th>
                            <th><?php _e('Actions', 'at-agency-manager'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($json_files as $file): ?>
                            <?php
                            $file_info = pathinfo($file);
                            $file_size = filesize($file);
                            $file_modified = filemtime($file);
                            ?>
                            <tr>
                                <td><?php echo esc_html($file_info['filename'] . '.json'); ?></td>
                                <td><?php echo size_format($file_size); ?></td>
                                <td><?php echo date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $file_modified); ?></td>
                                <td>
                                    <button type="button" class="button view-json-file" data-file="<?php echo esc_attr($file); ?>">
                                        <?php _e('View', 'at-agency-manager'); ?>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>

            <?php if (!empty($field_groups)): ?>
            <div class="acf-field-groups">
                <h2><?php _e('Field Groups', 'at-agency-manager'); ?></h2>
                <table class="widefat">
                    <thead>
                        <tr>
                            <th><?php _e('Title', 'at-agency-manager'); ?></th>
                            <th><?php _e('Key', 'at-agency-manager'); ?></th>
                            <th><?php _e('Location', 'at-agency-manager'); ?></th>
                            <th><?php _e('JSON File', 'at-agency-manager'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($field_groups as $group): ?>
                            <tr>
                                <td><?php echo esc_html($group['title']); ?></td>
                                <td><code><?php echo esc_html($group['key']); ?></code></td>
                                <td>
                                    <?php
                                    $locations = [];
                                    if (!empty($group['location'])) {
                                        foreach ($group['location'] as $location_rule) {
                                            if (!empty($location_rule)) {
                                                $rule_parts = [];
                                                foreach ($location_rule as $rule) {
                                                    $rule_parts[] = $rule['param'] . ' ' . $rule['operator'] . ' ' . $rule['value'];
                                                }
                                                $locations[] = implode(' AND ', $rule_parts);
                                            }
                                        }
                                    }
                                    echo esc_html(implode(' | ', $locations));
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    $json_file = $acf_json_path . '/group_' . $group['key'] . '.json';
                                    if (file_exists($json_file)) {
                                        echo '<span style="color: #46b450;">✓ ' . __('Synced', 'at-agency-manager') . '</span>';
                                    } else {
                                        echo '<span style="color: #dc3232;">✗ ' . __('Not synced', 'at-agency-manager') . '</span>';
                                    }
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>

            <div class="acf-json-actions">
                <h2><?php _e('Actions', 'at-agency-manager'); ?></h2>
                <p>
                    <button type="button" class="button button-primary" id="sync-acf-json">
                        <?php _e('Sync All Field Groups to JSON', 'at-agency-manager'); ?>
                    </button>
                    <span id="sync-result"></span>
                </p>
                <script>
                jQuery(function($){
                    $('#sync-acf-json').on('click', function(){
                        var btn = $(this);
                        var result = $('#sync-result');
                        btn.prop('disabled', true).text('<?php _e('Syncing...', 'at-agency-manager'); ?>');
                        $.post(ajaxurl, {
                            action: 'at_sync_acf_json',
                            nonce: '<?php echo wp_create_nonce('at_sync_acf_json'); ?>'
                        }, function(r){
                            if(r.success){
                                result.css('color','green').text('✓ <?php _e('Synced successfully', 'at-agency-manager'); ?>');
                                location.reload();
                            } else {
                                result.css('color','red').text('✗ '+r.data);
                            }
                            btn.prop('disabled', false).text('<?php _e('Sync All Field Groups to JSON', 'at-agency-manager'); ?>');
                        });
                    });

                    $('.view-json-file').on('click', function(){
                        var file = $(this).data('file');
                        $.post(ajaxurl, {
                            action: 'at_view_json_file',
                            file: file,
                            nonce: '<?php echo wp_create_nonce('at_view_json_file'); ?>'
                        }, function(r){
                            if(r.success){
                                var win = window.open('', '_blank');
                                win.document.write('<pre>' + JSON.stringify(JSON.parse(r.data), null, 2) + '</pre>');
                                win.document.title = '<?php _e('ACF JSON File', 'at-agency-manager'); ?>';
                            } else {
                                alert('<?php _e('Error loading file', 'at-agency-manager'); ?>: ' + r.data);
                            }
                        });
                    });
                });
                </script>
            </div>
        </div>

        <style>
        .acf-json-status td, .acf-json-files td, .acf-field-groups td { padding: 8px 12px; }
        .status-good { color: #46b450; font-weight: bold; }
        .status-bad { color: #dc3232; font-weight: bold; }
        #sync-result { margin-left: 10px; }
        </style>
        <?php
    }
}

// ---------------------------------------------------------------
// AJAX Handlers
// ---------------------------------------------------------------

// AJAX: Sync all ACF field groups to JSON
add_action('wp_ajax_at_sync_acf_json', 'at_sync_acf_json_handler');
function at_sync_acf_json_handler() {
    check_ajax_referer('at_sync_acf_json', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error(__('Insufficient permissions', 'at-agency-manager'));
    }

    if (!function_exists('acf_get_field_groups')) {
        wp_send_json_error(__('ACF not active', 'at-agency-manager'));
    }

    try {
        $field_groups = acf_get_field_groups();
        $synced_count = 0;

        foreach ($field_groups as $field_group) {
            // Force sync to JSON
            $result = acf_write_json_field_group($field_group);
            if ($result) {
                $synced_count++;
            }
        }

        wp_send_json_success(sprintf(__('Synced %d field groups to JSON', 'at-agency-manager'), $synced_count));

    } catch (Exception $e) {
        wp_send_json_error($e->getMessage());
    }
}

// AJAX: View JSON file content
add_action('wp_ajax_at_view_json_file', 'at_view_json_file_handler');
function at_view_json_file_handler() {
    check_ajax_referer('at_view_json_file', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error(__('Insufficient permissions', 'at-agency-manager'));
    }

    $file = isset($_POST['file']) ? sanitize_text_field($_POST['file']) : '';
    $acf_json_path = get_stylesheet_directory() . '/acf-json';

    if (empty($file) || strpos($file, $acf_json_path) !== 0 || !file_exists($file)) {
        wp_send_json_error(__('Invalid file', 'at-agency-manager'));
    }

    $content = file_get_contents($file);
    if ($content === false) {
        wp_send_json_error(__('Cannot read file', 'at-agency-manager'));
    }

    wp_send_json_success($content);
}

// אתחול המודול - הקובץ נטען מ-functions.php ב-acf/init hook
// מכיוון שהקובץ נטען בתוך acf/init, התרגומים כבר נטענו
// אבל רק אם ACF פעיל - טעינת המחלקה תהיה דרך acf/init hook בלבד
// כדי למנוע טעינה מוקדמת, לא נטען את המחלקה כאן ישירות
// במקום זאת, נטען אותה דרך functions.php אחרי acf/init
// (אין קוד כאן - הטעינה נעשית ב-functions.php בשורה 390-394)
