<?php
/**
 * Module: ACF Copy Fields Tool - STUB
 *
 * מודול זה עדיין לא מוטמע במלואו.
 * הוא מסומן כ"לא בוצע" ברשימת המשימות.
 *
 * נטען רק אם המודול הופעל במסך ההגדרות (at_agency_manager_modules[acf_copy_tool]).
 */

// הגנה מפני גישה ישירה
if (!defined('ABSPATH')) {
    exit;
}

// הוספת הודעת אזהרה שהמודול לא מוטמע
add_action('admin_notices', function() {
    $modules = get_option('at_agency_manager_modules', []);
    if (!empty($modules['acf_copy_tool'])) {
        echo '<div class="notice notice-warning is-dismissible">';
        echo '<p><strong>' . __('ACF Copy Tool', 'at-agency-manager') . ':</strong> ';
        echo __('This module is not fully implemented yet. It will be completed in a future update.', 'at-agency-manager');
        echo '</p>';
        echo '</div>';
    }
});

// ---------------------------------------------------------------
//     עמוד ניהול UI להעתקה (גרסה בסיסית)
// ---------------------------------------------------------------
add_action('admin_menu', function() {
    $modules = get_option('at_agency_manager_modules', []);
    if (!empty($modules['acf_copy_tool'])) {
        add_submenu_page(
            'at-agency-manager',
            __('ACF Copy Tool', 'at-agency-manager'),
            __('ACF Copy Tool', 'at-agency-manager'),
            'manage_options',
            'at-acf-copy-tool',
            'at_acf_copy_tool_page'
        );
    }
});

function at_acf_copy_tool_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions.', 'at-agency-manager'));
    }
    ?>
    <div class="wrap">
        <h1><?php _e('ACF Fields Management', 'at-agency-manager'); ?></h1>

        <div class="notice notice-info" style="margin-top: 20px;">
            <p><strong><?php _e('Update: ACF Local JSON Manager', 'at-agency-manager'); ?></strong></p>
            <p><?php _e('The ACF Copy Tool module has been replaced with a more comprehensive solution. Instead of manual copying, we now provide ACF Local JSON Manager which automatically syncs ACF field groups with your version control system.', 'at-agency-manager'); ?></p>
        </div>

        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h2><?php _e('Why ACF Local JSON Manager?', 'at-agency-manager'); ?></h2>
            <p><?php _e('ACF Local JSON Manager provides several advantages over manual field copying:', 'at-agency-manager'); ?></p>
            <ul style="list-style-type: disc; margin-left: 20px;">
                <li><?php _e('Automatic syncing of ACF field groups with JSON files', 'at-agency-manager'); ?></li>
                <li><?php _e('Version control integration - track changes in Git', 'at-agency-manager'); ?></li>
                <li><?php _e('Easy deployment across environments (dev → staging → production)', 'at-agency-manager'); ?></li>
                <li><?php _e('No manual field group copying required', 'at-agency-manager'); ?></li>
                <li><?php _e('Centralized field group management', 'at-agency-manager'); ?></li>
                <li><?php _e('Real-time sync status and health checks', 'at-agency-manager'); ?></li>
            </ul>
        </div>

        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h2><?php _e('Getting Started', 'at-agency-manager'); ?></h2>
            <p>
                <a href="<?php echo esc_url(admin_url('admin.php?page=at-acf-local-json')); ?>" class="button button-primary button-large">
                    <?php _e('Open ACF Local JSON Manager', 'at-agency-manager'); ?>
                </a>
            </p>
        </div>

        <div class="card" style="max-width: 800px; margin-top: 20px; border-left: 4px solid #f0b849;">
            <h2><?php _e('Requirements', 'at-agency-manager'); ?></h2>
            <ul>
                <li><?php _e('Advanced Custom Fields (ACF) Pro plugin', 'at-agency-manager'); ?></li>
                <li><?php _e('WordPress 5.0 or higher', 'at-agency-manager'); ?></li>
                <li><?php _e('Writable theme directory for JSON files', 'at-agency-manager'); ?></li>
            </ul>
        </div>

        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h2><?php _e('How It Works', 'at-agency-manager'); ?></h2>
            <ol style="list-style-type: decimal; margin-left: 20px;">
                <li><?php _e('ACF field groups are automatically saved to JSON files in your theme directory', 'at-agency-manager'); ?></li>
                <li><?php _e('Commit these JSON files to your Git repository', 'at-agency-manager'); ?></li>
                <li><?php _e('Deploy to other environments (staging, production)', 'at-agency-manager'); ?></li>
                <li><?php _e('JSON files are automatically loaded and synced in the target environment', 'at-agency-manager'); ?></li>
                <li><?php _e('No need for manual field group copying or database migrations', 'at-agency-manager'); ?></li>
            </ol>
        </div>

        <div class="card" style="max-width: 800px; margin-top: 20px;">
            <h2><?php _e('Support', 'at-agency-manager'); ?></h2>
            <p><?php _e('For questions or issues related to ACF field management, please refer to the following resources:', 'at-agency-manager'); ?></p>
            <ul>
                <li><a href="https://www.advancedcustomfields.com/resources/" target="_blank">Advanced Custom Fields Documentation</a></li>
                <li><a href="https://www.advancedcustomfields.com/resources/local-json/" target="_blank">ACF Local JSON Guide</a></li>
                <li><a href="<?php echo esc_url(admin_url('admin.php?page=at-acf-local-json')); ?>">AT Agency - ACF Local JSON Manager</a></li>
            </ul>
        </div>
    </div>
    <?php
} 