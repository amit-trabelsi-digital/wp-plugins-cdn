<?php
if (!defined("ABSPATH")) exit; // Exit if accessed directly

// בדיקה אם Elementor מותקן ומופעל
if (!did_action('elementor/loaded')) {
    return;
}

// בדיקה אם המחלקה הנדרשת קיימת
if (!class_exists('\Elementor\Core\DynamicTags\Data_Tag')) {
    return;
}

class ACF_Enhanced_Dynamic_Tag extends \Elementor\Core\DynamicTags\Data_Tag {
    public function get_name() {
        return "acf-enhanced";
    }
    
    public function get_title() {
        return __("שדה ACF משופר", "elementor");
    }
    
    public function get_group() {
        return "acf-custom";
    }
    
    public function get_categories() {
        return [
            \Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY,
            \Elementor\Modules\DynamicTags\Module::URL_CATEGORY,
            \Elementor\Modules\DynamicTags\Module::IMAGE_CATEGORY,
            \Elementor\Modules\DynamicTags\Module::GALLERY_CATEGORY,
        ];
    }
    
    protected function register_controls() {
        $this->add_control(
            "acf_field",
            [
                "label" => __("שדה ACF 3", "elementor"),
                "type" => \Elementor\Controls_Manager::SELECT,
                "options" => $this->get_acf_fields(),
                "label_block" => true,
            ]
        );
        
        $this->add_control(
            "is_repeater",
            [
                "label" => __("שדה ריפיטר?", "elementor"),
                "type" => \Elementor\Controls_Manager::SWITCHER,
                "default" => "",
                "label_on" => __("כן", "elementor"),
                "label_off" => __("לא", "elementor"),
            ]
        );
        
        $this->add_control(
            "repeater_index",
            [
                "label" => __("אינדקס ריפיטר", "elementor"),
                "type" => \Elementor\Controls_Manager::NUMBER,
                "default" => 0,
                "min" => 0,
                "condition" => [
                    "is_repeater" => "yes",
                ],
            ]
        );
        
        $this->add_control(
            "repeater_field",
            [
                "label" => __("שדה בתוך הריפיטר", "elementor"),
                "type" => \Elementor\Controls_Manager::TEXT,
                "condition" => [
                    "is_repeater" => "yes",
                    // הסתר את זה אם בחרו בשדה עם פורמט של ריפיטר:שדה-משנה
                    "acf_field!" => $this->get_repeater_subfields(),
                ],
            ]
        );
        
        $this->add_control(
            "format_date",
            [
                "label" => __("פורמט תאריך?", "elementor"),
                "type" => \Elementor\Controls_Manager::SWITCHER,
                "default" => "",
                "label_on" => __("כן", "elementor"),
                "label_off" => __("לא", "elementor"),
            ]
        );
        
        $this->add_control(
            "date_format",
            [
                "label" => __("פורמט", "elementor"),
                "type" => \Elementor\Controls_Manager::SELECT,
                "options" => [
                    "d/m/Y" => "DD/MM/YYYY",
                    "Y-m-d" => "YYYY-MM-DD",
                    "j F Y" => "יום חודש שנה",
                    "custom" => "מותאם אישית",
                ],
                "default" => "d/m/Y",
                "condition" => [
                    "format_date" => "yes",
                ],
            ]
        );
        
        $this->add_control(
            "custom_date_format",
            [
                "label" => __("פורמט מותאם אישית", "elementor"),
                "type" => \Elementor\Controls_Manager::TEXT,
                "placeholder" => "d/m/Y H:i",
                "condition" => [
                    "format_date" => "yes",
                    "date_format" => "custom",
                ],
            ]
        );
    }
    
    private function get_repeater_subfields() {
        $fields = $this->get_acf_fields();
        $repeater_fields = [];
        
        foreach ($fields as $key => $value) {
            if (strpos($key, ":") !== false) {
                $repeater_fields[] = $key;
            }
        }
        
        return $repeater_fields;
    }
    
    public function get_value(array $options = []) {
        try {
            $field_setting = $this->get_settings("acf_field");
            $is_repeater = $this->get_settings("is_repeater");
            $repeater_index = $this->get_settings("repeater_index");
            $format_date = $this->get_settings("format_date");
            $date_format = $this->get_settings("date_format");
            $custom_date_format = $this->get_settings("custom_date_format");
            
            if (!$field_setting) {
                return '';
            }
            
            // טיפול בשדות ריפיטר
            if (strpos($field_setting, ':') !== false && $is_repeater === 'yes') {
                list($field_name, $repeater_field) = explode(':', $field_setting, 2);
                $repeater_data = get_field($field_name);
                
                if (!$repeater_data || !isset($repeater_data[$repeater_index]) || !isset($repeater_data[$repeater_index][$repeater_field])) {
                    return '';
                }
                
                $value = $repeater_data[$repeater_index][$repeater_field];
            } 
            elseif ($is_repeater === 'yes') {
                $field_name = $field_setting;
                $repeater_field = $this->get_settings('repeater_field');
                $repeater_data = get_field($field_name);
                
                if (!$repeater_data || !isset($repeater_data[$repeater_index]) || !isset($repeater_data[$repeater_index][$repeater_field])) {
                    return '';
                }
                
                $value = $repeater_data[$repeater_index][$repeater_field];
            } else {
                $value = get_field($field_setting);
            }

            // בדיקה אם זה שדה תמונה
            $is_image_field = false;

            // בדיקה לפי שם השדה
            if (strpos($field_setting, 'image') !== false || strpos($field_setting, 'img') !== false) {
                $is_image_field = true;
            }
            // בדיקה לפי מבנה הערך
            elseif (is_array($value) && isset($value['url'])) {
                $is_image_field = true;
            }
            // בדיקה לפי סיומת URL
            elseif (is_string($value) && preg_match('/(\.jpg|\.jpeg|\.png|\.gif|\.webp|\.svg)$/i', $value)) {
                $is_image_field = true;
            }

            // טיפול בתמונות
            if ($is_image_field) {
                // אם יש לנו אובייקט תמונה מלא
                if (is_array($value) && isset($value['url'])) {
                    return [
                        'id' => isset($value['id']) ? $value['id'] : 0,
                        'url' => $value['url']
                    ];
                }
                
                // אם יש לנו URL של תמונה
                if (is_string($value)) {
                    $attachment_id = attachment_url_to_postid($value);
                    
                    // אם לא מצאנו ID, ננסה לחפש לפי שם הקובץ
                    if (!$attachment_id) {
                        global $wpdb;
                        $file_name = basename($value);
                        $attachment = $wpdb->get_col($wpdb->prepare("SELECT ID FROM $wpdb->posts WHERE guid LIKE '%%%s%%' AND post_type = 'attachment'", $file_name));
                        $attachment_id = !empty($attachment) ? $attachment[0] : 0;
                    }
                    
                    return [
                        'id' => $attachment_id,
                        'url' => $value
                    ];
                }
            }
            
            // טיפול בתאריכים
            if ($format_date === 'yes' && $value) {
                $date_obj = is_numeric($value) ? $value : strtotime($value);
                if ($date_obj) {
                    $format = $date_format === 'custom' ? $custom_date_format : $date_format;
                    $value = date($format, $date_obj);
                }
            }
            
            return $value;
            
        } catch (Exception $e) {
            // במקרה של שגיאה, נחזיר ערך ריק
            return '';
        }
    }
    
    private function get_acf_fields() {
        $fields = [];
        
        // קבל את כל השדות המוגדרים
        if (function_exists("acf_get_field_groups")) {
            $field_groups = acf_get_field_groups();
            
            foreach ($field_groups as $field_group) {
                $group_fields = acf_get_fields($field_group);
                
                if (!$group_fields) {
                    continue;
                }
                
                foreach ($group_fields as $field) {
                    // הוסף את השדה הראשי
                    $fields[$field["name"]] = $field["label"];
                    
                    // אם זה שדה מסוג ריפיטר, הוסף גם את שדות המשנה
                    if ($field["type"] === "repeater" && !empty($field["sub_fields"])) {
                        foreach ($field["sub_fields"] as $sub_field) {
                            $fields[$field["name"] . ":" . $sub_field["name"]] = 
                                $field["label"] . " > " . $sub_field["label"];
                        }
                    }
                }
            }
        }
        
        return $fields;
    }
    
    private function get_current_category() {
        try {
            if (isset($GLOBALS['post'])) {
                $post_id = $GLOBALS['post']->ID;
                $post_type = get_post_type($post_id);
                
                // בדיקה אם זה פוסט מסוג תמונה
                if ($post_type === 'attachment' && wp_attachment_is_image($post_id)) {
                    return 'image';
                }
            }
            
            // בדיקה אם אנחנו בתוך אלמנט תמונה באלמנטור
            $document = \Elementor\Plugin::$instance->documents->get_current();
            if ($document) {
                $current_element = $document->get_current_data();
                if (isset($current_element['widgetType']) && $current_element['widgetType'] === 'image') {
                    return 'image';
                }
            }
            
            return 'text';
            
        } catch (Exception $e) {
            return 'text';
        }
    }
}