<?php
/**
 * AT Agency Sites Manager - New Relic Monitoring Module
 *
 * Integrated New Relic APM monitoring functionality
 * Based on WP New Relic plugin (GPL-2.0-or-later compatible)
 *
 * @package AT_Agency_Manager
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * New Relic Monitoring Class
 */
class AT_Agency_Manager_NewRelic {

    private $logger;
    private $config = false;
    private $async_tasks = false;
    protected static $error_log_count = 0;

    public function __construct($logger = null) {
        $this->logger = $logger;

        // Check if New Relic extension is loaded
        if (!extension_loaded('newrelic')) {
            $this->log_error('New Relic PHP extension is not loaded');
            return;
        }

        // Check if module is enabled
        if (!$this->is_module_enabled()) {
            return;
        }

        $this->init_hooks();
        $this->log_info('New Relic monitoring module initialized');
    }

    /**
     * Check if New Relic module is enabled
     */
    private function is_module_enabled() {
        $modules = get_option('at_agency_manager_modules', []);
        return !empty($modules['newrelic_monitoring']);
    }

    /**
     * Initialize all New Relic hooks
     */
    private function init_hooks() {
        add_action('plugins_loaded', array($this, 'setup_config'), 9999);
        add_action('init', array($this, 'set_custom_variables'));
        add_filter('template_include', array($this, 'set_template'), 9999);
        add_action('wp', array($this, 'set_post_id'), 10);

        // Async tasks tracking
        add_action('wp_async_task_before_job', array($this, 'async_before_job_track_time'), 9999, 1);
        add_action('wp_async_task_after_job', array($this, 'async_after_job_set_attribute'), 9999, 1);

        // AMP compatibility
        add_action('pre_amp_render_post', array($this, 'disable_nr_autorum'), 9999, 1);

        if (is_admin()) {
            add_action('admin_init', array($this, 'set_admin_transaction'));
        } else {
            add_action('pre_get_posts', array($this, 'sitemap_check'), 1);
            add_action('wp', array($this, 'set_wp_transaction'));
            add_action('rest_api_init', array($this, 'set_wp_transaction'));
        }
    }

    /**
     * Setup New Relic configuration
     */
    public function setup_config() {
        $this->config = apply_filters('at_agency_nr_config', array(
            'newrelic.appname' => $this->get_appname(),
            'newrelic.capture_params' => $this->is_capture_url_enabled(),
        ));

        if (is_array($this->config)) {
            ini_set('newrelic.framework', 'wordpress');

            if (isset($this->config['newrelic.appname']) && function_exists('newrelic_set_appname')) {
                newrelic_set_appname($this->config['newrelic.appname']);
            }

            if (isset($this->config['newrelic.capture_params']) && function_exists('newrelic_capture_params')) {
                newrelic_capture_params($this->config['newrelic.capture_params']);
            }
        }

        do_action('at_agency_nr_setup_config', $this->config);
    }

    /**
     * Set template custom parameter
     */
    public function set_template($template) {
        if (!is_string($template) && function_exists('newrelic_add_custom_parameter')) {
            newrelic_add_custom_parameter('template_warning',
                sprintf('$template has been converted from a string to a %s by another plugin.', gettype($template)));
        }

        if (is_string($template) && function_exists('newrelic_add_custom_parameter')) {
            newrelic_add_custom_parameter('template', $template);
        }

        return $template;
    }

    /**
     * Set custom variables (user, theme, request type)
     */
    public function set_custom_variables() {
        // Set User
        if (function_exists('newrelic_set_user_attributes')) {
            if (is_user_logged_in()) {
                $user = wp_get_current_user();
                if (isset($user->roles[0])) {
                    newrelic_set_user_attributes($user->ID, '', $user->roles[0]);
                } else {
                    newrelic_set_user_attributes($user->ID, '', 'no-role');
                }
            } else {
                newrelic_set_user_attributes('not-logged-in', '', 'no-role');
            }
        }

        if (function_exists('newrelic_add_custom_parameter')) {
            // Set theme
            $theme = wp_get_theme();
            newrelic_add_custom_parameter('theme', $theme->get('Name'));

            // Set request type
            if (defined('DOING_AJAX') && DOING_AJAX) {
                $req_type = 'ajax';
            } elseif (defined('DOING_CRON') && DOING_CRON) {
                $req_type = 'cron';
            } elseif (defined('WP_CLI') && WP_CLI) {
                $req_type = 'cli';
            } elseif (defined('WP_GEARS') && WP_GEARS) {
                $req_type = 'gearman';
            } else {
                $req_type = 'web';
            }
            newrelic_add_custom_parameter('request_type', apply_filters('at_agency_nr_request_type', $req_type));

            // Add agency-specific custom parameters
            $this->add_agency_custom_parameters();
        }
    }

    /**
     * Add agency-specific custom parameters
     */
    private function add_agency_custom_parameters() {
        if (function_exists('newrelic_add_custom_parameter')) {
            // Add plugin version
            newrelic_add_custom_parameter('at_agency_version', AT_AGENCY_MANAGER_VERSION);

            // Add site info
            newrelic_add_custom_parameter('at_agency_site_url', home_url());
            newrelic_add_custom_parameter('at_agency_admin_email', get_option('admin_email'));

            // Add memory usage if enabled
            if ($this->is_memory_monitoring_enabled()) {
                newrelic_add_custom_parameter('at_agency_memory_usage', $this->get_memory_usage());
            }
        }
    }

    /**
     * Get current memory usage
     */
    private function get_memory_usage() {
        if (function_exists('memory_get_peak_usage')) {
            return round(memory_get_peak_usage(true) / 1024 / 1024, 2) . 'MB';
        }
        return 'unknown';
    }

    /**
     * Set WordPress transaction names
     */
    public function set_wp_transaction() {
        global $wp_query;

        if (!function_exists('newrelic_name_transaction')) {
            return;
        }

        $transaction = false;

        if (is_front_page() && is_home()) {
            $transaction = 'Default Home Page';
        } elseif (is_front_page()) {
            $transaction = 'Front Page';
        } elseif (is_home() && false === get_query_var('sitemap', false)) {
            $transaction = 'Blog Page';
        } elseif (is_single()) {
            $post_type = (!empty($wp_query->query['post_type'])) ? $wp_query->query['post_type'] : 'Post';
            $transaction = 'Single - ' . $post_type;
        } elseif (is_page()) {
            if (isset($wp_query->query['pagename'])) {
                $this->add_custom_parameter('page', $wp_query->query['pagename']);
            }
            $transaction = 'Page';
        } elseif (is_date()) {
            $transaction = 'Date Archive';
        } elseif (is_search()) {
            if (isset($wp_query->query['s'])) {
                $this->add_custom_parameter('search', $wp_query->query['s']);
            }
            $transaction = 'Search Page';
        } elseif (is_feed()) {
            $transaction = 'Feed';
        } elseif (is_post_type_archive()) {
            $post_type = post_type_archive_title('', false);
            $transaction = 'Archive - ' . $post_type;
        } elseif (is_category()) {
            if (isset($wp_query->query['category_name'])) {
                $this->add_custom_parameter('cat_slug', $wp_query->query['category_name']);
            }
            $transaction = 'Category';
        } elseif (is_tag()) {
            if (isset($wp_query->query['tag'])) {
                $this->add_custom_parameter('tag_slug', $wp_query->query['tag']);
            }
            $transaction = 'Tag';
        } elseif (is_tax()) {
            $tax = key($wp_query->tax_query->queried_terms);
            $term = implode(' | ', $wp_query->tax_query->queried_terms[$tax]['terms']);
            $this->add_custom_parameter('term_slug', $term);
            $transaction = 'Tax - ' . $tax;
        } elseif (defined('REST_REQUEST') && filter_var(REST_REQUEST, FILTER_VALIDATE_BOOLEAN)) {
            $transaction = 'REST API';
        }

        $transaction = apply_filters('at_agency_nr_transaction_name', $transaction);

        if (!empty($transaction)) {
            newrelic_name_transaction($transaction);
        }
    }

    /**
     * Handle sitemap requests
     */
    public function sitemap_check($query) {
        if (!function_exists('newrelic_name_transaction')) {
            return;
        }

        if ($query->is_main_query() && $query->get('sitemap', false)) {
            newrelic_name_transaction('Sitemap');
        }
    }

    /**
     * Set admin transaction names
     */
    public function set_admin_transaction() {
        global $pagenow, $taxnow, $typenow;

        if (!function_exists('newrelic_name_transaction')) {
            return;
        }

        $transaction = false;

        $action = '';
        if (isset($_REQUEST['action']) && -1 != $_REQUEST['action']) {
            $action = $_REQUEST['action'];
        } elseif (isset($_REQUEST['action2']) && -1 != $_REQUEST['action2']) {
            $action = $_REQUEST['action2'];
        }

        switch ($pagenow) {
            case 'post.php':
                $transaction = "{$typenow}/{$action}";
                break;

            case 'edit-tags.php':
                $transaction = "{$taxnow}/{$action}";
                break;

            default:
                if (defined('DOING_AJAX') && DOING_AJAX) {
                    $transaction = "wp-ajax/{$action}";
                } elseif (is_network_admin()) {
                    $transaction = 'Network Dashboard';
                } else {
                    $transaction = 'Dashboard';
                }
                break;
        }

        $transaction = apply_filters('at_agency_nr_transaction_name', $transaction);
        if (!empty($transaction)) {
            newrelic_name_transaction($transaction);
        }
    }

    /**
     * Set post ID custom parameter
     */
    public function set_post_id($wp) {
        if (is_single() && function_exists('newrelic_add_custom_parameter')) {
            newrelic_add_custom_parameter('post_id', apply_filters('at_agency_nr_post_id', get_the_ID()));
        }
    }

    /**
     * Add custom parameter with prefix
     */
    public function add_custom_parameter($key, $value) {
        if (function_exists('newrelic_add_custom_parameter')) {
            $key = 'at_agency_' . $key;
            return newrelic_add_custom_parameter($key, apply_filters('at_agency_nr_add_custom_parameter', $value, $key));
        }
        return false;
    }

    /**
     * Check if URL capture is enabled
     */
    private function is_capture_url_enabled() {
        $settings = get_option('at_agency_newrelic_settings', []);
        return !empty($settings['capture_urls']);
    }

    /**
     * Get custom app name from settings
     */
    private function get_custom_app_name() {
        $settings = get_option('at_agency_newrelic_settings', []);
        return !empty($settings['app_name']) ? $settings['app_name'] : null;
    }

    /**
     * Check if error logging is enabled
     */
    private function is_error_logging_enabled() {
        $settings = get_option('at_agency_newrelic_settings', []);
        return !isset($settings['error_logging']) || !empty($settings['error_logging']);
    }

    /**
     * Check if memory monitoring is enabled
     */
    private function is_memory_monitoring_enabled() {
        $settings = get_option('at_agency_newrelic_settings', []);
        return !isset($settings['memory_monitoring']) || !empty($settings['memory_monitoring']);
    }

    /**
     * Get New Relic app name
     */
    private function get_appname() {
        $custom_name = $this->get_custom_app_name();
        if ($custom_name) {
            return apply_filters('at_agency_nr_app_name', $custom_name);
        }

        $home_url = parse_url(home_url());
        $app_name = $home_url['host'] . (isset($home_url['path']) ? $home_url['path'] : '');
        return apply_filters('at_agency_nr_app_name', $app_name);
    }

    /**
     * Log custom errors to New Relic
     */
    public static function log_errors($message, Exception $exception = null) {
        // Check if error logging is enabled
        $settings = get_option('at_agency_newrelic_settings', []);
        $error_logging_enabled = !isset($settings['error_logging']) || !empty($settings['error_logging']);

        if (!$error_logging_enabled) {
            return false;
        }

        if (self::$error_log_count > 0) {
            trigger_error(__('New Relic error logging can only be used once per transaction.', 'at-agency-manager'), E_USER_WARNING);
            return false;
        }

        if (function_exists('newrelic_notice_error')) {
            newrelic_notice_error($message, $exception);
            self::$error_log_count++;
            return true;
        }

        return false;
    }

    /**
     * Track async task start time
     */
    public function async_before_job_track_time($hook) {
        if (false === $this->async_tasks) {
            $this->async_tasks = array();
        }

        $this->async_tasks[$hook] = array(
            'start_time' => time(),
        );
    }

    /**
     * Set async task duration
     */
    public function async_after_job_set_attribute($hook) {
        if (is_array($this->async_tasks) && !empty($this->async_tasks[$hook])) {
            $this->async_tasks[$hook]['end_time'] = time();
            $time_diff = $this->async_tasks[$hook]['end_time'] - $this->async_tasks[$hook]['start_time'];

            if (function_exists('newrelic_add_custom_parameter')) {
                newrelic_add_custom_parameter('at_agency_async_task_' . $hook, $time_diff);
            }
        }
    }

    /**
     * Disable New Relic autorum for AMP
     */
    public function disable_nr_autorum($post_id) {
        if (!function_exists('newrelic_disable_autorum')) {
            return;
        }

        if (apply_filters('at_agency_disable_post_autorum', true, $post_id)) {
            newrelic_disable_autorum();
        }
    }

    /**
     * Log info message
     */
    private function log_info($message) {
        if ($this->logger) {
            $this->logger->log('newrelic_info', $message, 'info');
        }
    }

    /**
     * Log error message
     */
    private function log_error($message) {
        if ($this->logger) {
            $this->logger->log('newrelic_error', $message, 'error');
        }
    }
}

/**
 * Global function for custom error logging
 */
function at_agency_nr_log_errors($message, $exception = null) {
    return AT_Agency_Manager_NewRelic::log_errors($message, $exception);
}

/**
 * Initialize New Relic monitoring if module is enabled
 */
function init_at_agency_newrelic_monitoring($logger = null) {
    new AT_Agency_Manager_NewRelic($logger);
}
