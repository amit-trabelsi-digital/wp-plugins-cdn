<?php
/**
 * Abilities API Management Module
 * 
 * This module provides an admin interface for managing and testing
 * WordPress Abilities API integration with the AT Agency Manager plugin.
 * 
 * @package AT_Agency_Manager
 * @since 0.11.0
 */

defined('ABSPATH') or die('Direct access not allowed');

class AT_Agency_Manager_Abilities_API_Admin {
    /**
     * @var AT_Agency_Manager_Logger
     */
    private $logger;

    /**
     * Initialize the Abilities API admin module
     *
     * @param AT_Agency_Manager_Logger $logger Logger instance
     */
    public function __construct($logger) {
        $this->logger = $logger;
        
        // Register admin page
        add_action('admin_menu', array($this, 'register_admin_page'));
        
        // Register AJAX handlers
        add_action('wp_ajax_at_agency_manager_abilities_api_test', array($this, 'handle_ajax_test'));
    }

    /**
     * Register admin page for Abilities API management
     */
    public function register_admin_page() {
        add_submenu_page(
            'at-agency-manager',
            __('Abilities API', 'at-agency-manager'),
            __('Abilities API', 'at-agency-manager'),
            'manage_options',
            'at-agency-manager-abilities-api',
            array($this, 'render_admin_page')
        );
    }

    /**
     * Render the admin page for Abilities API management
     */
    public function render_admin_page() {
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'at-agency-manager'));
        }
        
        // Check if WP Abilities API is available
        $abilities_api_loaded = function_exists('wp_register_ability');
        
        // Get registered abilities from the registry if available
        $registered_abilities = array();
        if ($abilities_api_loaded) {
            // Try to get abilities from the registry
            if (class_exists('WP_Abilities_Registry')) {
                $registry = WP_Abilities_Registry::get_instance();
                if (method_exists($registry, 'get_abilities')) {
                    $all_abilities = $registry->get_abilities();
                    // Filter for our plugin's abilities
                    $registered_abilities = array_filter($all_abilities, function($ability) {
                        $id = is_object($ability) ? $ability->name : (isset($ability['name']) ? $ability['name'] : '');
                        return strpos($id, 'at-agency-manager/') === 0;
                    });
                }
            }
        }
        
        ?>
        <div class="wrap">
            <h1><?php _e('WordPress Abilities API', 'at-agency-manager'); ?></h1>
            
            <?php if (!$abilities_api_loaded): ?>
                <div class="notice notice-error">
                    <p>
                        <strong><?php _e('WordPress Abilities API is not installed or activated.', 'at-agency-manager'); ?></strong>
                    </p>
                    <p>
                        <?php _e('Please install the WordPress Abilities API plugin to enable AI assistant integration.', 'at-agency-manager'); ?>
                        <a href="https://github.com/WordPress/abilities-api" target="_blank" rel="noopener noreferrer">
                            <?php _e('Learn more', 'at-agency-manager'); ?>
                        </a>
                    </p>
                </div>
            <?php else: ?>
                <div class="notice notice-success">
                    <p><?php _e('WordPress Abilities API is loaded and active!', 'at-agency-manager'); ?></p>
                </div>
                
                <div class="card" style="max-width: 100%; margin-bottom: 20px;">
                    <h2><?php _e('About WordPress Abilities API', 'at-agency-manager'); ?></h2>
                    <p>
                        <?php _e('The WordPress Abilities API is a system for exposing WordPress functionality in a standardized way for use by AI systems like LLMs. It allows your website to be interacted with through natural language commands processed by AI.', 'at-agency-manager'); ?>
                    </p>
                    <p>
                        <a href="https://github.com/WordPress/abilities-api" target="_blank" rel="noopener noreferrer">
                            <?php _e('View documentation', 'at-agency-manager'); ?>
                        </a>
                    </p>
                </div>
                
                <div class="card" style="max-width: 100%; margin-bottom: 20px;">
                    <h2><?php _e('Registered Abilities', 'at-agency-manager'); ?></h2>
                    <p><?php _e('These abilities from AT Agency Manager are available to AI systems:', 'at-agency-manager'); ?></p>
                    
                    <table class="widefat fixed striped">
                        <thead>
                            <tr>
                                <th style="width: 30%;"><?php _e('Ability ID', 'at-agency-manager'); ?></th>
                                <th style="width: 25%;"><?php _e('Label', 'at-agency-manager'); ?></th>
                                <th><?php _e('Description', 'at-agency-manager'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Define our abilities (matching what's in class-abilities-api.php)
                            $our_abilities = array(
                                array(
                                    'id' => 'at-agency-manager/site-info',
                                    'label' => __('AT Agency Site Information', 'at-agency-manager'),
                                    'description' => __('Get information about the WordPress site managed by AT Agency', 'at-agency-manager'),
                                ),
                                array(
                                    'id' => 'at-agency-manager/modules',
                                    'label' => __('AT Agency Modules Management', 'at-agency-manager'),
                                    'description' => __('List, enable, or disable AT Agency Manager modules', 'at-agency-manager'),
                                ),
                                array(
                                    'id' => 'at-agency-manager/smtp-settings',
                                    'label' => __('AT Agency SMTP Settings', 'at-agency-manager'),
                                    'description' => __('Get or update SMTP settings for email delivery', 'at-agency-manager'),
                                ),
                                array(
                                    'id' => 'at-agency-manager/random-post',
                                    'label' => __('AT Agency Get Random Post', 'at-agency-manager'),
                                    'description' => __('Get a random post from the WordPress site', 'at-agency-manager'),
                                ),
                            );
                            
                            if (empty($our_abilities)): ?>
                                <tr>
                                    <td colspan="3"><?php _e('No abilities registered yet.', 'at-agency-manager'); ?></td>
                                </tr>
                            <?php else:
                                foreach ($our_abilities as $ability): ?>
                                    <tr>
                                        <td><code><?php echo esc_html($ability['id']); ?></code></td>
                                        <td><strong><?php echo esc_html($ability['label']); ?></strong></td>
                                        <td><?php echo esc_html($ability['description']); ?></td>
                                    </tr>
                                <?php endforeach;
                            endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="card" style="max-width: 100%; margin-bottom: 20px;">
                    <h2><?php _e('Test Ability', 'at-agency-manager'); ?></h2>
                    <p><?php _e('Test the "Get Random Post" ability:', 'at-agency-manager'); ?></p>
                    
                    <button id="at-abilities-api-test-button" class="button button-primary">
                        <?php _e('Get Random Post', 'at-agency-manager'); ?>
                    </button>
                    
                    <div id="at-abilities-api-test-result" style="margin-top: 20px; padding: 15px; background: #f8f9fa; border: 1px solid #ddd; border-radius: 4px; display: none;">
                        <h3 id="at-abilities-api-test-title" style="margin-top: 0;"></h3>
                        <div id="at-abilities-api-test-content" style="margin-bottom: 10px;"></div>
                        <p id="at-abilities-api-test-url" style="margin-bottom: 0;"></p>
                    </div>
                    
                    <script type="text/javascript">
                        jQuery(document).ready(function($) {
                            $('#at-abilities-api-test-button').on('click', function() {
                                var $button = $(this);
                                $button.prop('disabled', true).text('<?php _e('Loading...', 'at-agency-manager'); ?>');
                                
                                $.ajax({
                                    url: ajaxurl,
                                    type: 'POST',
                                    data: {
                                        action: 'at_agency_manager_abilities_api_test',
                                        nonce: '<?php echo wp_create_nonce('at_agency_manager_abilities_api_test'); ?>'
                                    },
                                    success: function(response) {
                                        if (response.success) {
                                            $('#at-abilities-api-test-title').text(response.data.title);
                                            $('#at-abilities-api-test-content').html('<p>' + response.data.excerpt + '</p>');
                                            $('#at-abilities-api-test-url').html('<a href="' + response.data.url + '" target="_blank" class="button"><?php _e('View Post', 'at-agency-manager'); ?></a>');
                                            $('#at-abilities-api-test-result').show();
                                        } else {
                                            alert('<?php _e('Error:', 'at-agency-manager'); ?> ' + (response.data || '<?php _e('Unknown error', 'at-agency-manager'); ?>'));
                                        }
                                    },
                                    error: function() {
                                        alert('<?php _e('An error occurred while processing the request.', 'at-agency-manager'); ?>');
                                    },
                                    complete: function() {
                                        $button.prop('disabled', false).text('<?php _e('Get Random Post', 'at-agency-manager'); ?>');
                                    }
                                });
                            });
                        });
                    </script>
                </div>
                
                <div class="card" style="max-width: 100%;">
                    <h2><?php _e('Using with AI Chatbots', 'at-agency-manager'); ?></h2>
                    <p><?php _e('To use these abilities with AI chatbots like ChatGPT or Claude, you need to use an agent that supports the WordPress Abilities API.', 'at-agency-manager'); ?></p>
                    <p><strong><?php _e('Example prompts:', 'at-agency-manager'); ?></strong></p>
                    <ul style="list-style: disc; margin-right: 20px;">
                        <li><?php _e('"Can you show me information about this WordPress site?"', 'at-agency-manager'); ?></li>
                        <li><?php _e('"List all available modules and enable the email log module"', 'at-agency-manager'); ?></li>
                        <li><?php _e('"Update the SMTP settings to use smtp.gmail.com"', 'at-agency-manager'); ?></li>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Handle AJAX request for testing abilities
     */
    public function handle_ajax_test() {
        // Verify nonce
        check_ajax_referer('at_agency_manager_abilities_api_test', 'nonce');
        
        // Check if user has permission
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('You do not have permission to perform this action.', 'at-agency-manager'));
            return;
        }
        
        // Test the random post ability by calling it directly
        // This simulates what an AI would do
        if (!function_exists('wp_register_ability')) {
            wp_send_json_error(__('Abilities API is not available.', 'at-agency-manager'));
            return;
        }
        
        // Get a random post
        $args = array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'posts_per_page' => 1,
            'orderby' => 'rand',
        );
        
        $query = new WP_Query($args);
        
        if ($query->have_posts()) {
            $query->the_post();
            
            $post_id = get_the_ID();
            $post_data = array(
                'id' => $post_id,
                'title' => get_the_title(),
                'excerpt' => get_the_excerpt(),
                'url' => get_permalink(),
            );
            
            wp_reset_postdata();
            
            wp_send_json_success($post_data);
        } else {
            wp_send_json_error(__('No posts found', 'at-agency-manager'));
        }
    }
}

// Initialize the module - loaded via at_agency_manager_load_modules() in functions.php
// This ensures proper initialization order and logger availability
