<?php
/**
 * AT Backup Dropbox Client
 * תמיכה בהעלאה ל-Dropbox
 */

if (!defined('ABSPATH')) exit;

class AT_Backup_Dropbox_Client {
    private $app_key;
    private $app_secret;
    private $access_token;
    private $api_url = 'https://content.dropboxapi.com/2/files/upload';
    private $api_url_create_folder = 'https://api.dropboxapi.com/2/files/create_folder_v2';
    private $backup_folder = '/AT-Backups';

    public function __construct($app_key, $app_secret, $access_token) {
        $this->app_key = $app_key;
        $this->app_secret = $app_secret;
        $this->access_token = $access_token;
    }

    /**
     * העלאת קובץ ל-Dropbox
     */
    public function upload($file_path) {
        try {
            // בדיקת קיום הקובץ
            if (!file_exists($file_path)) {
                throw new Exception(__('Backup file does not exist', 'at-agency-manager'));
            }

            // יצירת תיקיית הגיבוי אם לא קיימת
            $this->create_backup_folder();

            // הכנת הנתיב המלא ב-Dropbox
            $file_name = basename($file_path);
            $dropbox_path = $this->backup_folder . '/' . $file_name;

            // קריאת תוכן הקובץ
            $file_content = file_get_contents($file_path);

            if ($file_content === false) {
                throw new Exception(__('Failed to read backup file', 'at-agency-manager'));
            }

            // הכנת ה-headers
            $headers = array(
                'Authorization: Bearer ' . $this->access_token,
                'Content-Type: application/octet-stream',
                'Dropbox-API-Arg: {"path": "' . $dropbox_path . '", "mode": "overwrite"}'
            );

            // ביצוע קריאת API
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $this->api_url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $file_content);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

            $response = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $error = curl_error($ch);
            curl_close($ch);

            if ($error) {
                throw new Exception(__('Dropbox API error: ', 'at-agency-manager') . $error);
            }

            if ($http_code !== 200) {
                $error_data = json_decode($response, true);
                $error_message = isset($error_data['error_summary']) ? $error_data['error_summary'] : __('Unknown error', 'at-agency-manager');
                throw new Exception(__('Dropbox upload failed: ', 'at-agency-manager') . $error_message);
            }

            return array(
                'success' => true,
                'message' => __('File uploaded to Dropbox successfully', 'at-agency-manager'),
                'file_path' => $dropbox_path
            );

        } catch (Exception $e) {
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }

    /**
     * יצירת תיקיית הגיבוי ב-Dropbox
     */
    private function create_backup_folder() {
        $headers = array(
            'Authorization: Bearer ' . $this->access_token,
            'Content-Type: application/json'
        );

        $data = json_encode(array(
            'path' => $this->backup_folder,
            'autorename' => false
        ));

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->api_url_create_folder);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        // אם התיקייה כבר קיימת, זה בסדר
        if ($http_code === 409) {
            return true;
        }

        return $http_code === 200;
    }

    /**
     * קבלת רשימת קבצי הגיבוי
     */
    public function list_backups() {
        try {
            $api_url = 'https://api.dropboxapi.com/2/files/list_folder';
            $headers = array(
                'Authorization: Bearer ' . $this->access_token,
                'Content-Type: application/json'
            );

            $data = json_encode(array(
                'path' => $this->backup_folder,
                'recursive' => false,
                'include_media_info' => false,
                'include_deleted' => false
            ));

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $api_url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

            $response = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($http_code !== 200) {
                throw new Exception(__('Failed to list Dropbox files', 'at-agency-manager'));
            }

            $data = json_decode($response, true);
            $files = array();

            if (isset($data['entries'])) {
                foreach ($data['entries'] as $entry) {
                    if ($entry['.tag'] === 'file') {
                        $files[] = array(
                            'name' => $entry['name'],
                            'size' => $entry['size'],
                            'modified' => $entry['server_modified'],
                            'path' => $entry['path_lower']
                        );
                    }
                }
            }

            return array(
                'success' => true,
                'files' => $files
            );

        } catch (Exception $e) {
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }

    /**
     * מחיקת קובץ גיבוי מ-Dropbox
     */
    public function delete_backup($file_path) {
        try {
            $api_url = 'https://api.dropboxapi.com/2/files/delete_v2';
            $headers = array(
                'Authorization: Bearer ' . $this->access_token,
                'Content-Type: application/json'
            );

            $data = json_encode(array(
                'path' => $file_path
            ));

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $api_url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

            $response = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($http_code !== 200) {
                throw new Exception(__('Failed to delete file from Dropbox', 'at-agency-manager'));
            }

            return array(
                'success' => true,
                'message' => __('File deleted from Dropbox successfully', 'at-agency-manager')
            );

        } catch (Exception $e) {
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }
}
