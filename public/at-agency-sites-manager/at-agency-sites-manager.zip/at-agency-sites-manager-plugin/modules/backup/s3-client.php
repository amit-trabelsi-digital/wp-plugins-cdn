<?php
/**
 * AT Backup S3 Client
 * תמיכה בהעלאה ל-Amazon S3
 */

if (!defined('ABSPATH')) exit;

class AT_Backup_S3_Client {
    private $access_key;
    private $secret_key;
    private $region;
    private $bucket;
    private $folder;
    private $endpoint;

    public function __construct($access_key, $secret_key, $region, $bucket, $folder = 'at-backups') {
        $this->access_key = $access_key;
        $this->secret_key = $secret_key;
        $this->region = $region;
        $this->bucket = $bucket;
        $this->folder = $folder;
        $this->endpoint = "https://{$bucket}.s3.{$region}.amazonaws.com";
    }

    /**
     * יצירת חתימה עבור AWS S3
     */
    private function generate_signature($string_to_sign, $date_stamp) {
        $k_date = hash_hmac('sha256', $date_stamp, 'AWS4' . $this->secret_key, true);
        $k_region = hash_hmac('sha256', $this->region, $k_date, true);
        $k_service = hash_hmac('sha256', 's3', $k_region, true);
        $k_signing = hash_hmac('sha256', 'aws4_request', $k_service, true);

        return hash_hmac('sha256', $string_to_sign, $k_signing);
    }

    /**
     * העלאת קובץ ל-S3
     */
    public function upload($file_path) {
        try {
            // בדיקת קיום הקובץ
            if (!file_exists($file_path)) {
                throw new Exception(__('Backup file does not exist', 'at-agency-manager'));
            }

            $file_name = basename($file_path);
            $s3_key = $this->folder . '/' . $file_name;

            // קריאת תוכן הקובץ
            $file_content = file_get_contents($file_path);
            if ($file_content === false) {
                throw new Exception(__('Failed to read backup file', 'at-agency-manager'));
            }

            $file_size = strlen($file_content);

            // יצירת תאריך וזמן
            $date = gmdate('Ymd\THis\Z');
            $date_stamp = gmdate('Ymd');

            // יצירת canonical request
            $canonical_uri = '/' . $s3_key;
            $canonical_querystring = '';
            $canonical_headers = "host:{$this->bucket}.s3.{$this->region}.amazonaws.com\nx-amz-content-sha256:" . hash('sha256', $file_content) . "\nx-amz-date:{$date}\n";
            $signed_headers = 'host;x-amz-content-sha256;x-amz-date';

            $canonical_request = "PUT\n{$canonical_uri}\n{$canonical_querystring}\n{$canonical_headers}\n{$signed_headers}\n" . hash('sha256', $file_content);

            // יצירת string to sign
            $algorithm = 'AWS4-HMAC-SHA256';
            $credential_scope = "{$date_stamp}/{$this->region}/s3/aws4_request";
            $string_to_sign = "{$algorithm}\n{$date}\n{$credential_scope}\n" . hash('sha256', $canonical_request);

            // יצירת חתימה
            $signature = $this->generate_signature($string_to_sign, $date_stamp);

            // יצירת authorization header
            $authorization_header = "{$algorithm} Credential={$this->access_key}/{$credential_scope}, SignedHeaders={$signed_headers}, Signature={$signature}";

            // הכנת headers
            $headers = array(
                "Authorization: {$authorization_header}",
                "x-amz-content-sha256: " . hash('sha256', $file_content),
                "x-amz-date: {$date}",
                "Content-Type: application/octet-stream",
                "Content-Length: {$file_size}"
            );

            // ביצוע קריאת API
            $url = $this->endpoint . '/' . urlencode($s3_key);

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_PUT, true);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_INFILE, fopen($file_path, 'r'));
            curl_setopt($ch, CURLOPT_INFILESIZE, $file_size);

            $response = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $error = curl_error($ch);
            curl_close($ch);

            if ($error) {
                throw new Exception(__('S3 API error: ', 'at-agency-manager') . $error);
            }

            if ($http_code !== 200) {
                throw new Exception(__('S3 upload failed with HTTP code: ', 'at-agency-manager') . $http_code);
            }

            return array(
                'success' => true,
                'message' => __('File uploaded to Amazon S3 successfully', 'at-agency-manager'),
                'file_path' => $s3_key,
                'url' => $url
            );

        } catch (Exception $e) {
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }

    /**
     * קבלת רשימת קבצי הגיבוי מ-S3
     */
    public function list_backups() {
        try {
            $date = gmdate('Ymd\THis\Z');
            $date_stamp = gmdate('Ymd');

            // יצירת canonical request עבור list objects
            $canonical_uri = "/{$this->bucket}/?prefix=" . urlencode($this->folder) . '/';
            $canonical_querystring = "prefix=" . urlencode($this->folder) . '/';
            $canonical_headers = "host:{$this->bucket}.s3.{$this->region}.amazonaws.com\nx-amz-date:{$date}\n";
            $signed_headers = 'host;x-amz-date';

            $canonical_request = "GET\n{$canonical_uri}\n{$canonical_querystring}\n{$canonical_headers}\n{$signed_headers}\nUNSIGNED-PAYLOAD";

            // יצירת string to sign
            $algorithm = 'AWS4-HMAC-SHA256';
            $credential_scope = "{$date_stamp}/{$this->region}/s3/aws4_request";
            $string_to_sign = "{$algorithm}\n{$date}\n{$credential_scope}\n" . hash('sha256', $canonical_request);

            // יצירת חתימה
            $signature = $this->generate_signature($string_to_sign, $date_stamp);

            // יצירת authorization header
            $authorization_header = "{$algorithm} Credential={$this->access_key}/{$credential_scope}, SignedHeaders={$signed_headers}, Signature={$signature}";

            // הכנת headers
            $headers = array(
                "Authorization: {$authorization_header}",
                "x-amz-date: {$date}"
            );

            // ביצוע קריאת API
            $url = $this->endpoint . "/?prefix=" . urlencode($this->folder) . '/';

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            $response = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($http_code !== 200) {
                throw new Exception(__('Failed to list S3 files', 'at-agency-manager'));
            }

            // ניתוח תגובת XML
            $xml = simplexml_load_string($response);
            $files = array();

            if ($xml && isset($xml->Contents)) {
                foreach ($xml->Contents as $content) {
                    $key = (string)$content->Key;
                    if (strpos($key, $this->folder . '/') === 0) {
                        $files[] = array(
                            'name' => basename($key),
                            'size' => (int)$content->Size,
                            'modified' => (string)$content->LastModified,
                            'path' => $key
                        );
                    }
                }
            }

            return array(
                'success' => true,
                'files' => $files
            );

        } catch (Exception $e) {
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }

    /**
     * מחיקת קובץ גיבוי מ-S3
     */
    public function delete_backup($file_path) {
        try {
            $date = gmdate('Ymd\THis\Z');
            $date_stamp = gmdate('Ymd');

            // יצירת canonical request
            $canonical_uri = '/' . $file_path;
            $canonical_querystring = '';
            $canonical_headers = "host:{$this->bucket}.s3.{$this->region}.amazonaws.com\nx-amz-date:{$date}\n";
            $signed_headers = 'host;x-amz-date';

            $canonical_request = "DELETE\n{$canonical_uri}\n{$canonical_querystring}\n{$canonical_headers}\n{$signed_headers}\nUNSIGNED-PAYLOAD";

            // יצירת string to sign
            $algorithm = 'AWS4-HMAC-SHA256';
            $credential_scope = "{$date_stamp}/{$this->region}/s3/aws4_request";
            $string_to_sign = "{$algorithm}\n{$date}\n{$credential_scope}\n" . hash('sha256', $canonical_request);

            // יצירת חתימה
            $signature = $this->generate_signature($string_to_sign, $date_stamp);

            // יצירת authorization header
            $authorization_header = "{$algorithm} Credential={$this->access_key}/{$credential_scope}, SignedHeaders={$signed_headers}, Signature={$signature}";

            // הכנת headers
            $headers = array(
                "Authorization: {$authorization_header}",
                "x-amz-date: {$date}"
            );

            // ביצוע קריאת API
            $url = $this->endpoint . '/' . urlencode($file_path);

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            $response = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($http_code !== 204) {
                throw new Exception(__('Failed to delete file from S3', 'at-agency-manager'));
            }

            return array(
                'success' => true,
                'message' => __('File deleted from S3 successfully', 'at-agency-manager')
            );

        } catch (Exception $e) {
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }
}
