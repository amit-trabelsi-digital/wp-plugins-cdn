<?php
if (!defined('ABSPATH')) exit;

function at_run_backup() {
    // יצירת גיבוי - פעולות:
    // 1. יצירת רשימת קבצים לגיבוי
    // 2. יצירת ZIP
    // 3. יצירת גיבוי DB (אם נדרש)
    // 4. העלאה ל-Drive
    
    // 1. רשימת קבצים לגיבוי, לפי הגדרות המשתמש
    $backup_content = get_option('at_backup_content', [
        'plugins' => true,
        'themes' => true,
        'uploads' => true,
        'database' => true,
        'wp_config' => false,
        'custom' => '',
    ]);
    
    // יצירת נתיב לתיקיית temp עבור הגיבוי
    $temp_dir = trailingslashit(wp_upload_dir()['basedir']) . 'at-backups';
    if (!file_exists($temp_dir)) {
        wp_mkdir_p($temp_dir);
    }
    
    // הסתרת תיקיית הגיבויים באמצעות קובץ index.php
    $index_file = $temp_dir . '/index.php';
    if (!file_exists($index_file)) {
        file_put_contents($index_file, '<?php // Silence is golden');
    }
    
    // יצירת שם ייחודי לקובץ הגיבוי
    $backup_name = 'backup-' . date('YmdHis');
    $backup_file = $temp_dir . '/' . $backup_name . '.zip';
    
    // 2. יצירת ZIP עם הקבצים הנדרשים
    $files_to_backup = [];
    $wp_content_dir = WP_CONTENT_DIR;
    
    // הוספת תיקיות לגיבוי לפי בחירת המשתמש
    if (!empty($backup_content['plugins'])) {
        $files_to_backup[] = $wp_content_dir . '/plugins';
    }
    if (!empty($backup_content['themes'])) {
        $files_to_backup[] = $wp_content_dir . '/themes';
    }
    if (!empty($backup_content['uploads'])) {
        // יצירת רשימת קבצים עם החרגת תיקיית at-backups
        $files_to_backup = array_merge($files_to_backup, at_get_uploads_files_excluding_backup());
    }
    if (!empty($backup_content['wp_config'])) {
        $files_to_backup[] = ABSPATH . 'wp-config.php';
    }
    
    // הוספת נתיבים מותאמים אישית
    if (!empty($backup_content['custom'])) {
        $custom_paths = explode("\n", $backup_content['custom']);
        foreach ($custom_paths as $path) {
            $path = trim($path);
            if ($path) {
                $files_to_backup[] = ABSPATH . $path;
            }
        }
    }
    
    // יצירת ZIP
    if (!empty($files_to_backup)) {
        if (!at_create_zip($files_to_backup, $backup_file)) {
            return ['success' => false, 'message' => __('Failed to create ZIP file', 'at-agency-manager')];
        }
    }
    
    // 3. גיבוי מסד נתונים
    if (!empty($backup_content['database'])) {
        $sql_file = $temp_dir . '/' . $backup_name . '.sql';
        if (!at_backup_database($sql_file)) {
            // אם נכשל גיבוי ה-DB, נמשיך בכל זאת עם הקבצים
            // אבל נדווח על שגיאה
            $db_error = __('Database backup failed', 'at-agency-manager');
        } else {
            // הוספת קובץ ה-SQL לקובץ ה-ZIP
            at_add_to_zip($backup_file, $sql_file, basename($sql_file));
            // מחיקת קובץ ה-SQL הזמני
            @unlink($sql_file);
        }
    }
    
    // 4. העלאה לשירות ענן (אם הוגדר)
    $cloud_service = get_option('at_backup_cloud_service', 'local');

    if ($cloud_service !== 'local') {
        try {
            $upload_result = at_upload_to_cloud($backup_file, $cloud_service);

            if ($upload_result['success']) {
                // מחיקת קובץ ZIP זמני לאחר העלאה מוצלחת
                @unlink($backup_file);
                return $upload_result;
            } else {
                // אם העלאה נכשלה, שמור מקומית
                return ['success' => true, 'message' => sprintf(
                    __('Backup completed locally (cloud upload failed: %s). Saved at %s', 'at-agency-manager'),
                    $upload_result['message'],
                    $backup_file
                )];
            }
        } catch (Exception $e) {
            return ['success' => true, 'message' => sprintf(
                __('Backup completed locally (cloud upload error: %s). Saved at %s', 'at-agency-manager'),
                $e->getMessage(),
                $backup_file
            )];
        }
    } else {
        // אין הגדרות ענן, שומרים את הקובץ מקומית
        return ['success' => true, 'message' => sprintf(
            __('Backup completed and saved locally at %s', 'at-agency-manager'),
            $backup_file
        )];
    }
}

function at_create_zip($files, $destination) {
    // קבלת נתיב תיקיית הגיבויים להחרגה
    $backup_dir = trailingslashit(wp_upload_dir()['basedir']) . 'at-backups';
    $backup_dir_normalized = wp_normalize_path($backup_dir);
    
    // בדיקה אם ZipArchive זמין
    if (class_exists('ZipArchive')) {
        $zip = new ZipArchive();
        
        if ($zip->open($destination, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            return false;
        }
        
        foreach ($files as $file) {
            $file_normalized = wp_normalize_path($file);
            
            // החרגה מפורשת של תיקיית הגיבויים - למניעת לולאה אינסופית
            if (strpos($file_normalized, $backup_dir_normalized) !== false) {
                continue; // דילוג על תיקיית הגיבויים עצמה
            }
            
            if (is_dir($file)) {
                // אם זו תיקייה, הוספה רקורסיבית עם סינון
                $base_name = basename($file);
                $dir_iterator = new RecursiveDirectoryIterator($file, RecursiveDirectoryIterator::SKIP_DOTS);
                $filter = new AT_Backup_Filter($dir_iterator, ['at-backups']);
                $iterator = new RecursiveIteratorIterator($filter, RecursiveIteratorIterator::SELF_FIRST);
                
                foreach ($iterator as $item) {
                    $item_path = wp_normalize_path($item->getPathname());
                    
                    // החרגה נוספת של תיקיית הגיבויים
                    if (strpos($item_path, $backup_dir_normalized) !== false) {
                        continue;
                    }
                    
                    $relative_path = $base_name . '/' . $iterator->getSubPathname();
                    
                    if ($item->isDir()) {
                        $zip->addEmptyDir($relative_path);
                    } else {
                        $zip->addFile($item->getPathname(), $relative_path);
                    }
                }
            } elseif (file_exists($file)) {
                // אם זה קובץ, הוספה ישירה
                $zip->addFile($file, basename($file));
            }
        }
        
        $zip->close();
        return true;
    } else {
        // גיבוי באמצעות PclZip (ספרייה מובנית בוורדפרס)
        require_once(ABSPATH . 'wp-admin/includes/class-pclzip.php');
        
        $zip = new PclZip($destination);
        
        foreach ($files as $file) {
            $file_normalized = wp_normalize_path($file);
            
            // החרגה מפורשת של תיקיית הגיבויים
            if (strpos($file_normalized, $backup_dir_normalized) !== false) {
                continue;
            }
            
            if (is_dir($file)) {
                // אם זו תיקייה - הוספה עם סינון
                $excluded = array_merge(['at-backups'], get_option('at_backup_excluded_items', []));
                $result = $zip->add($file, PCLZIP_OPT_REMOVE_PATH, dirname($file), PCLZIP_OPT_EXCLUDE_PATH, $backup_dir);
            } else {
                // אם זה קובץ
                $result = $zip->add($file, PCLZIP_OPT_REMOVE_PATH, dirname($file));
            }
            
            if ($result == 0) {
                return false;
            }
        }
        
        return true;
    }
}

function at_add_to_zip($zip_file, $file_to_add, $file_name_in_zip) {
    if (class_exists('ZipArchive')) {
        $zip = new ZipArchive();
        
        if ($zip->open($zip_file) !== true) {
            return false;
        }
        
        $zip->addFile($file_to_add, $file_name_in_zip);
        $zip->close();
        
        return true;
    } else {
        require_once(ABSPATH . 'wp-admin/includes/class-pclzip.php');
        
        $zip = new PclZip($zip_file);
        $result = $zip->add($file_to_add, PCLZIP_OPT_REMOVE_ALL_PATH);
        
        return ($result != 0);
    }
}

/**
 * קבלת רשימת קבצי uploads עם החרגת תיקיית at-backups
 */
function at_get_uploads_files_excluding_backup() {
    $upload_dir = wp_upload_dir();
    $base_upload_path = $upload_dir['basedir'];
    $backup_folder = $base_upload_path . '/at-backups';

    // קבלת רשימת תיקיות/קבצים מוחרגים מהגדרות
    $excluded_items = get_option('at_backup_excluded_items', ['at-backups']);

    $files_to_backup = [];

    if (is_dir($base_upload_path)) {
        $iterator = new RecursiveDirectoryIterator($base_upload_path, RecursiveDirectoryIterator::SKIP_DOTS);
        $filter = new AT_Backup_Filter($iterator, $excluded_items);
        $filtered_iterator = new RecursiveIteratorIterator($filter, RecursiveIteratorIterator::SELF_FIRST);

        foreach ($filtered_iterator as $file) {
            if ($file->isDir()) {
                $files_to_backup[] = $file->getPathname();
            } elseif ($file->isFile()) {
                $files_to_backup[] = $file->getPathname();
            }
        }
    }

    return $files_to_backup;
}

/**
 * מחלקה לסינון קבצים ותיקיות בגיבוי
 */
class AT_Backup_Filter extends RecursiveFilterIterator {
    private $excluded_items;

    public function __construct($iterator, $excluded_items) {
        parent::__construct($iterator);
        $this->excluded_items = $excluded_items;
    }

    /**
     * בדיקה אם הפריט הנוכחי צריך להיכלל
     * 
     * @return bool
     */
    #[\ReturnTypeWillChange]
    public function accept(): bool {
        $current = $this->current();
        $filename = $current->getFilename();

        // החרגת פריטים מהרשימה
        foreach ($this->excluded_items as $excluded) {
            if (strpos($current->getPathname(), $excluded) !== false) {
                return false;
            }
        }

        // החרגת קבצי מערכת נפוצים
        $system_files = ['.htaccess', '.htpasswd', 'web.config', '.DS_Store', 'Thumbs.db'];
        if (in_array($filename, $system_files)) {
            return false;
        }

        return true;
    }

    /**
     * קבלת ילדים של האיטרטור הנוכחי
     * 
     * @return RecursiveFilterIterator|null
     */
    #[\ReturnTypeWillChange]
    public function getChildren() {
        $inner_iterator = $this->getInnerIterator();
        if (!($inner_iterator instanceof RecursiveIterator)) {
            return null;
        }
        $children = $inner_iterator->getChildren();
        if ($children === null) {
            return null;
        }
        return new self($children, $this->excluded_items);
    }
}

/**
 * קבלת רשימת תיקיות uploads עם החרגות מותאמות אישית
 */
function at_get_filtered_uploads_files($custom_exclusions = []) {
    $upload_dir = wp_upload_dir();
    $base_upload_path = $upload_dir['basedir'];

    // רשימת ברירת מחדל + החרגות מותאמות אישית
    $excluded_items = array_merge(['at-backups'], $custom_exclusions);

    $files_to_backup = [];

    if (is_dir($base_upload_path)) {
        $iterator = new RecursiveDirectoryIterator($base_upload_path, RecursiveDirectoryIterator::SKIP_DOTS);
        $filter = new AT_Backup_Filter($iterator, $excluded_items);
        $filtered_iterator = new RecursiveIteratorIterator($filter, RecursiveIteratorIterator::SELF_FIRST);

        foreach ($filtered_iterator as $file) {
            $files_to_backup[] = $file->getPathname();
        }
    }

    return $files_to_backup;
}

/**
 * העלאה לשירות ענן
 */
function at_upload_to_cloud($backup_file, $cloud_service) {
    switch ($cloud_service) {
        case 'google_drive':
            return at_upload_to_google_drive($backup_file);
        case 'dropbox':
            return at_upload_to_dropbox($backup_file);
        case 's3':
            return at_upload_to_s3($backup_file);
        default:
            throw new Exception(__('Unsupported cloud service', 'at-agency-manager'));
    }
}

/**
 * העלאה ל-Google Drive
 */
function at_upload_to_google_drive($backup_file) {
    if (!class_exists('AT_Backup_Drive_Client')) {
        require_once __DIR__ . '/drive-client.php';
    }

    $client_id = get_option('at_backup_drive_client_id');
    $client_secret = get_option('at_backup_drive_client_secret');
    $refresh_token = get_option('at_backup_drive_refresh_token');

    if (!$client_id || !$client_secret || !$refresh_token) {
        throw new Exception(__('Google Drive credentials not configured', 'at-agency-manager'));
    }

    try {
        $drive_client = new AT_Backup_Drive_Client($client_id, $client_secret, $refresh_token);
        $folder_id = $drive_client->get_or_create_backup_folder();

        if (!$folder_id) {
            throw new Exception(__('Failed to create/find backup folder', 'at-agency-manager'));
        }

        $result = $drive_client->upload($backup_file, $folder_id);

        if (!$result['success']) {
            throw new Exception($result['message']);
        }

        return ['success' => true, 'message' => __('Backup uploaded to Google Drive successfully', 'at-agency-manager')];

    } catch (Exception $e) {
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

/**
 * העלאה ל-Dropbox
 */
function at_upload_to_dropbox($backup_file) {
    if (!class_exists('AT_Backup_Dropbox_Client')) {
        require_once __DIR__ . '/dropbox-client.php';
    }

    $app_key = get_option('at_backup_dropbox_app_key');
    $app_secret = get_option('at_backup_dropbox_app_secret');
    $access_token = get_option('at_backup_dropbox_access_token');

    if (!$app_key || !$app_secret || !$access_token) {
        throw new Exception(__('Dropbox credentials not configured', 'at-agency-manager'));
    }

    try {
        $dropbox_client = new AT_Backup_Dropbox_Client($app_key, $app_secret, $access_token);
        $result = $dropbox_client->upload($backup_file);

        if (!$result['success']) {
            throw new Exception($result['message']);
        }

        return ['success' => true, 'message' => __('Backup uploaded to Dropbox successfully', 'at-agency-manager')];

    } catch (Exception $e) {
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

/**
 * העלאה ל-Amazon S3
 */
function at_upload_to_s3($backup_file) {
    if (!class_exists('AT_Backup_S3_Client')) {
        require_once __DIR__ . '/s3-client.php';
    }

    $access_key = get_option('at_backup_s3_access_key');
    $secret_key = get_option('at_backup_s3_secret_key');
    $bucket = get_option('at_backup_s3_bucket');
    $region = get_option('at_backup_s3_region');

    if (!$access_key || !$secret_key || !$bucket || !$region) {
        throw new Exception(__('Amazon S3 credentials not configured', 'at-agency-manager'));
    }

    try {
        $s3_client = new AT_Backup_S3_Client($access_key, $secret_key, $region, $bucket);
        $result = $s3_client->upload($backup_file);

        if (!$result['success']) {
            throw new Exception($result['message']);
        }

        return ['success' => true, 'message' => __('Backup uploaded to Amazon S3 successfully', 'at-agency-manager')];

    } catch (Exception $e) {
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

function at_backup_database($output_file) {
    global $wpdb;
    
    // הגדרות בסיסיות
    $tables = $wpdb->get_results('SHOW TABLES', ARRAY_N);
    $output = '';
    
    // יצירת הצהרות DROP TABLE
    foreach ($tables as $table) {
        $table_name = $table[0];
        
        // דילוג על טבלאות לא רלוונטיות (אופציונלי)
        // if (strpos($table_name, $wpdb->prefix) !== 0) continue;
        
        $output .= "DROP TABLE IF EXISTS `$table_name`;\n";
    }
    
    // יצירת מבנה הטבלאות והתוכן
    foreach ($tables as $table) {
        $table_name = $table[0];
        
        // דילוג על טבלאות לא רלוונטיות (אופציונלי)
        // if (strpos($table_name, $wpdb->prefix) !== 0) continue;
        
        // יצירת מבנה הטבלה
        $create_table = $wpdb->get_results("SHOW CREATE TABLE `$table_name`", ARRAY_A);
        $output .= "\n\n" . $create_table[0]['Create Table'] . ";\n\n";
        
        // יצירת ערכי הטבלה
        $rows = $wpdb->get_results("SELECT * FROM `$table_name`", ARRAY_A);
        
        foreach ($rows as $row) {
            $fields = array();
            
            foreach ($row as $field) {
                if (is_null($field)) {
                    $fields[] = "NULL";
                } else {
                    $fields[] = "'" . esc_sql($field) . "'";
                }
            }
            
            $output .= "INSERT INTO `$table_name` VALUES (" . implode(', ', $fields) . ");\n";
        }
        
        $output .= "\n\n";
    }
    
    // כתיבת הקובץ
    $result = file_put_contents($output_file, $output);
    
    return ($result !== false);
} 