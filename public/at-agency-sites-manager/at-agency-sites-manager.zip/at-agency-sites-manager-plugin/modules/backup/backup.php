<?php
if (!defined('ABSPATH')) exit;

// טעינת קבצי עזר
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/drive-client.php';
require_once __DIR__ . '/admin-page.php';

class AT_Backup_Module {
    /**
     * @var AT_Backup_Module|null
     */
    private static $instance = null;

    /**
     * @var bool
     */
    private static $hooks_registered = false;

    /**
     * Singleton access.
     *
     * @return AT_Backup_Module
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function __construct() {
        if (self::$hooks_registered) {
            return;
        }
        self::$hooks_registered = true;

        $this->register_menu_item();
        add_action('admin_init', [$this, 'register_settings']);
        add_action('at_backup_cron', [$this, 'run_backup']);
        add_action('admin_notices', [$this, 'show_backup_notice']);
        add_action('wp_ajax_at_run_backup_now', [$this, 'ajax_run_backup_now']);
        add_action('wp_ajax_at_backup_save_google_keys', [$this, 'ajax_save_google_keys']);
        add_action('wp_ajax_at_backup_check_token', [$this, 'ajax_check_token']);
        add_action('wp_ajax_at_backup_auth_callback', [$this, 'ajax_auth_callback']);
        add_action('wp_ajax_at_delete_backup', [$this, 'ajax_delete_backup']);
        add_action('wp_ajax_at_download_backup', [$this, 'ajax_download_backup']);

        // Setup cron schedule based on settings
        $this->setup_cron_schedules();
    }
    
    public function register_settings() {
        // Google Drive API keys
        register_setting('at_backup_settings', 'at_backup_drive_client_id');
        register_setting('at_backup_settings', 'at_backup_drive_client_secret');
        register_setting('at_backup_settings', 'at_backup_drive_refresh_token');
        register_setting('at_backup_settings', 'at_backup_drive_folder_id');

        // Dropbox API keys
        register_setting('at_backup_settings', 'at_backup_dropbox_app_key');
        register_setting('at_backup_settings', 'at_backup_dropbox_app_secret');
        register_setting('at_backup_settings', 'at_backup_dropbox_access_token');
        register_setting('at_backup_settings', 'at_backup_dropbox_refresh_token');

        // Amazon S3 settings
        register_setting('at_backup_settings', 'at_backup_s3_access_key');
        register_setting('at_backup_settings', 'at_backup_s3_secret_key');
        register_setting('at_backup_settings', 'at_backup_s3_bucket');
        register_setting('at_backup_settings', 'at_backup_s3_region');
        register_setting('at_backup_settings', 'at_backup_s3_folder');

        // Cloud service selection
        register_setting('at_backup_settings', 'at_backup_cloud_service');

        // Backup content settings
        register_setting('at_backup_settings', 'at_backup_content');

        // Backup exclusions
        register_setting('at_backup_settings', 'at_backup_excluded_items');

        // Process excluded items as array
        add_filter('pre_update_option_at_backup_excluded_items', function($value) {
            if (is_string($value)) {
                $value = explode("\n", $value);
                $value = array_map('trim', $value);
                $value = array_filter($value);
                // Always include at-backups
                if (!in_array('at-backups', $value)) {
                    $value[] = 'at-backups';
                }
            }
            return $value;
        });

        // Backup frequency
        register_setting('at_backup_settings', 'at_backup_frequency');

        // Last backup status
        register_setting('at_backup_settings', 'at_backup_last_success');
        register_setting('at_backup_settings', 'at_backup_last_error');
    }
    
    private function register_menu_item() {
        if (function_exists('at_suite_register_admin_menu_item')) {
            $registered = at_suite_register_admin_menu_item(
                'at-agency-manager-backup',
                array(
                    'parent_slug' => 'at-agency-manager',
                    'page_title'  => at_agency_manager_admin_label('Site Backup', 'גיבוי אתר'),
                    'menu_title'  => at_agency_manager_admin_label('Backup', 'גיבוי'),
                    'capability'  => 'manage_options',
                    'menu_slug'   => 'at-agency-manager-backup',
                    'callback'    => array($this, 'render_backup_page'),
                ),
                array(
                    'source' => 'module',
                    'source_id' => 'backup',
                )
            );

            if ($registered) {
                return;
            }
        }

        // Fallback if suite registry is unavailable.
        add_action('admin_menu', array($this, 'add_backup_page_legacy'));
    }

    public function add_backup_page_legacy() {
        add_submenu_page(
            'at-agency-manager',
            at_agency_manager_admin_label('Site Backup', 'גיבוי אתר'),
            at_agency_manager_admin_label('Backup', 'גיבוי'),
            'manage_options',
            'at-agency-manager-backup',
            [$this, 'render_backup_page']
        );
    }
    
    public function render_backup_page() {
        at_render_backup_admin_page();
    }
    
    public function run_backup() {
        $result = at_run_backup();
        if ($result['success']) {
            update_option('at_backup_last_success', current_time('mysql'));
            update_option('at_backup_last_error', '');
        } else {
            update_option('at_backup_last_error', $result['message']);
            // שליחת מייל שגיאה
            wp_mail(get_option('admin_email'), __('Backup Failed', 'at-agency-manager'), $result['message']);
        }
    }
    
    public function show_backup_notice() {
        $err = get_option('at_backup_last_error');
        if ($err) {
            echo '<div class="notice notice-error"><strong>' . __('Backup Error:', 'at-agency-manager') . '</strong> ' . esc_html($err) . '</div>';
        }
    }
    
    public function ajax_run_backup_now() {
        // בדיקת הרשאות
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Permission denied', 'at-agency-manager'));
        }

        // בדיקת nonce לאבטחה
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'at_backup_now')) {
            wp_send_json_error(__('Security check failed', 'at-agency-manager'));
        }

        $this->run_backup();
        wp_send_json_success();
    }
    
    public function ajax_save_google_keys() {
        // בדיקת אבטחה - nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'at_backup_auth')) {
            wp_send_json_error(__('Security check failed', 'at-agency-manager'));
        }
        
        $client_id = sanitize_text_field($_POST['client_id'] ?? '');
        $client_secret = sanitize_text_field($_POST['client_secret'] ?? '');
        
        if (!$client_id || !$client_secret) {
            wp_send_json_error(__('Client ID and Client Secret are required', 'at-agency-manager'));
        }
        
        // שמירת המפתחות להמשך
        update_option('at_backup_drive_client_id', $client_id);
        update_option('at_backup_drive_client_secret', $client_secret);
        
        // יצירת URL האימות
        $redirect_uri = admin_url('admin-ajax.php') . '?action=at_backup_auth_callback';
        $auth_url = 'https://accounts.google.com/o/oauth2/auth?';
        $auth_params = [
            'response_type' => 'code',
            'client_id' => $client_id,
            'redirect_uri' => $redirect_uri,
            'scope' => 'https://www.googleapis.com/auth/drive',
            'access_type' => 'offline',
            'prompt' => 'consent',
        ];
        
        $auth_url .= http_build_query($auth_params);
        
        wp_send_json_success(['auth_url' => $auth_url]);
    }
    
    public function ajax_auth_callback() {
        // לוגיקת CallBack מ-Google OAuth
        $code = sanitize_text_field($_GET['code'] ?? '');
        
        if (!$code) {
            echo "<script>window.close();</script>";
            exit;
        }
        
        $client_id = get_option('at_backup_drive_client_id');
        $client_secret = get_option('at_backup_drive_client_secret');
        $redirect_uri = admin_url('admin-ajax.php') . '?action=at_backup_auth_callback';
        
        // קריאה להחלפת קוד ל-token
        $response = wp_remote_post('https://oauth2.googleapis.com/token', [
            'body' => [
                'code' => $code,
                'client_id' => $client_id,
                'client_secret' => $client_secret,
                'redirect_uri' => $redirect_uri,
                'grant_type' => 'authorization_code',
            ],
        ]);
        
        if (is_wp_error($response)) {
            update_option('at_backup_last_error', $response->get_error_message());
        } else {
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);
            
            if (isset($data['refresh_token'])) {
                // שמירת ה-refresh token לשימוש עתידי
                update_option('at_backup_drive_refresh_token', $data['refresh_token']);
                update_option('at_backup_last_error', '');
            } else {
                update_option('at_backup_last_error', __('No refresh token received', 'at-agency-manager'));
            }
        }
        
        echo "<script>window.close();</script>";
        exit;
    }
    
    public function ajax_check_token() {
        // בדיקת אבטחה - nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'at_backup_auth')) {
            wp_send_json_error(__('Security check failed', 'at-agency-manager'));
        }
        
        $refresh_token = get_option('at_backup_drive_refresh_token');
        
        if ($refresh_token) {
            wp_send_json_success();
        } else {
            wp_send_json_error(__('Authorization failed or canceled', 'at-agency-manager'));
        }
    }

    public function ajax_delete_backup() {
        // בדיקת הרשאות
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Permission denied', 'at-agency-manager'));
        }

        // בדיקת nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'at_delete_backup')) {
            wp_send_json_error(__('Security check failed', 'at-agency-manager'));
        }

        $file_name = isset($_POST['file']) ? sanitize_file_name($_POST['file']) : '';

        if (empty($file_name)) {
            wp_send_json_error(__('Invalid file name', 'at-agency-manager'));
        }

        // וידוא שהקובץ מתחיל ב-backup- ונמצא בתיקייה הנכונה
        if (strpos($file_name, 'backup-') !== 0) {
            wp_send_json_error(__('Invalid backup file', 'at-agency-manager'));
        }

        $backup_dir = trailingslashit(wp_upload_dir()['basedir']) . 'at-backups';
        $file_path = $backup_dir . '/' . $file_name;

        // וידוא שהקובץ קיים ונמצא בתיקייה הנכונה
        if (!file_exists($file_path) || dirname($file_path) !== $backup_dir) {
            wp_send_json_error(__('Backup file not found', 'at-agency-manager'));
        }

        // מחיקת הקובץ
        if (@unlink($file_path)) {
            wp_send_json_success(__('Backup deleted successfully', 'at-agency-manager'));
        } else {
            wp_send_json_error(__('Failed to delete backup file', 'at-agency-manager'));
        }
    }

    public function ajax_download_backup() {
        // בדיקת הרשאות
        if (!current_user_can('manage_options')) {
            wp_die(__('Permission denied', 'at-agency-manager'));
        }

        // בדיקת nonce
        if (!isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'at_download_backup')) {
            wp_die(__('Security check failed', 'at-agency-manager'));
        }

        $file_name = isset($_GET['file']) ? sanitize_file_name($_GET['file']) : '';

        if (empty($file_name)) {
            wp_die(__('Invalid file name', 'at-agency-manager'));
        }

        // וידוא שהקובץ מתחיל ב-backup-
        if (strpos($file_name, 'backup-') !== 0) {
            wp_die(__('Invalid backup file', 'at-agency-manager'));
        }

        $backup_dir = trailingslashit(wp_upload_dir()['basedir']) . 'at-backups';
        $file_path = $backup_dir . '/' . $file_name;

        // וידוא שהקובץ קיים ונמצא בתיקייה הנכונה
        if (!file_exists($file_path) || dirname($file_path) !== $backup_dir) {
            wp_die(__('Backup file not found', 'at-agency-manager'));
        }

        // הורדת הקובץ
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($file_path) . '"');
        header('Content-Length: ' . filesize($file_path));
        readfile($file_path);
        exit;
    }

    private function setup_cron_schedules() {
        $frequency = get_option('at_backup_frequency', 'daily');
        
        // מחיקת לוחות הזמנים הקיימים
        wp_clear_scheduled_hook('at_backup_cron');
        
        // הגדרת לוח זמנים חדש לפי בחירת המשתמש
        if ($frequency === 'hourly') {
            if (!wp_next_scheduled('at_backup_cron')) {
                wp_schedule_event(time(), 'hourly', 'at_backup_cron');
            }
        } elseif ($frequency === 'daily') {
            if (!wp_next_scheduled('at_backup_cron')) {
                wp_schedule_event(time(), 'daily', 'at_backup_cron');
            }
        }
        // מיידי (immediate) לא דורש זימון cron - הגיבוי יופעל מיידית בעת שינויים
    }
}
