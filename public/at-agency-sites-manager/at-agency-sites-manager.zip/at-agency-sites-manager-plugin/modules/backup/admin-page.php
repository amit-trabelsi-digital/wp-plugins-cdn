<?php
if (!defined('ABSPATH')) exit;

function at_render_backup_admin_page() {
    // בדיקת הרשאות
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.', 'at-agency-manager'));
    }
    
    $last = get_option('at_backup_last_success');
    $err = get_option('at_backup_last_error');
    ?>
    <div class="wrap at-agency-manager-wrap">
        <h1><?php _e('Site Backup Settings', 'at-agency-manager'); ?></h1>
        <div class="notice notice-info" style="margin-bottom:20px;">
            <strong><?php _e('Cloud Storage Setup:', 'at-agency-manager'); ?></strong><br>
            <p><?php _e('Choose your preferred cloud storage service. Local storage saves backups to your server.', 'at-agency-manager'); ?></p>
            <br>
            <?php _e('Default backup folder name: ', 'at-agency-manager'); ?>
            <code><?php echo esc_html(sanitize_title(get_bloginfo('name')) . '-backup'); ?></code>
        </div>
        <?php if ($err): ?>
            <div class="notice notice-error"><strong><?php _e('Backup Error:', 'at-agency-manager'); ?></strong> <?php echo esc_html($err); ?></div>
        <?php endif; ?>
        <form method="post" action="options.php">
            <?php settings_fields('at_backup_settings'); ?>
            <table class="form-table">
                <!-- בחירת שירות ענן -->
                <tr>
                    <th><?php _e('Cloud Storage Service', 'at-agency-manager'); ?></th>
                    <td>
                        <select name="at_backup_cloud_service" id="at_backup_cloud_service">
                            <option value="local" <?php selected(get_option('at_backup_cloud_service', 'local'), 'local'); ?>><?php _e('Local Storage', 'at-agency-manager'); ?></option>
                            <option value="google_drive" <?php selected(get_option('at_backup_cloud_service', 'local'), 'google_drive'); ?>><?php _e('Google Drive', 'at-agency-manager'); ?></option>
                            <option value="dropbox" <?php selected(get_option('at_backup_cloud_service', 'local'), 'dropbox'); ?>><?php _e('Dropbox', 'at-agency-manager'); ?></option>
                            <option value="s3" <?php selected(get_option('at_backup_cloud_service', 'local'), 's3'); ?>><?php _e('Amazon S3', 'at-agency-manager'); ?></option>
                        </select>
                        <p class="description"><?php _e('Choose where to store your backups', 'at-agency-manager'); ?></p>
                    </td>
                </tr>

                <!-- Google Drive Settings -->
                <tr class="at-cloud-settings at-google-drive-settings">
                    <th><?php _e('Google Drive Settings', 'at-agency-manager'); ?></th>
                    <td>
                        <div class="notice notice-info inline" style="margin-bottom:10px;">
                            <strong><?php _e('Setup Instructions:', 'at-agency-manager'); ?></strong><br>
                            <ol style="margin:0 0 0 20px;">
                                <li><?php _e('Go to <a href="https://console.cloud.google.com/" target="_blank">Google Cloud Console</a>.', 'at-agency-manager'); ?></li>
                                <li><?php _e('Create a new project or select an existing one.', 'at-agency-manager'); ?></li>
                                <li><?php _e('Go to APIs & Services → Credentials.', 'at-agency-manager'); ?></li>
                                <li><?php _e('Click "Create Credentials" → "OAuth client ID".', 'at-agency-manager'); ?></li>
                                <li><?php _e('Choose "Web application".', 'at-agency-manager'); ?></li>
                                <li><?php printf(__('Add this Redirect URI: <code>%s</code>', 'at-agency-manager'), esc_html(admin_url('admin-ajax.php') . '?action=at_backup_auth_callback')); ?></li>
                                <li><?php _e('Copy the Client ID and Client Secret and paste them below.', 'at-agency-manager'); ?></li>
                            </ol>
                        </div>
                        <p>
                            <input type="text" name="at_backup_drive_client_id" value="<?php echo esc_attr(get_option('at_backup_drive_client_id')); ?>" placeholder="Client ID" class="regular-text" />
                        </p>
                        <p>
                            <input type="text" name="at_backup_drive_client_secret" value="<?php echo esc_attr(get_option('at_backup_drive_client_secret')); ?>" placeholder="Client Secret" class="regular-text" />
                        </p>
                        <p>
                            <button type="button" class="button" id="at-backup-auth-btn"><?php _e('Authorize Google Drive', 'at-agency-manager'); ?></button>
                            <input type="hidden" name="at_backup_drive_refresh_token" value="<?php echo esc_attr(get_option('at_backup_drive_refresh_token')); ?>" />
                            <span id="at-backup-auth-status"></span>
                        </p>
                    </td>
                </tr>

                <!-- Dropbox Settings -->
                <tr class="at-cloud-settings at-dropbox-settings">
                    <th><?php _e('Dropbox Settings', 'at-agency-manager'); ?></th>
                    <td>
                        <div class="notice notice-info inline" style="margin-bottom:10px;">
                            <strong><?php _e('Setup Instructions:', 'at-agency-manager'); ?></strong><br>
                            <ol style="margin:0 0 0 20px;">
                                <li><?php _e('Go to <a href="https://www.dropbox.com/developers/apps" target="_blank">Dropbox App Console</a>.', 'at-agency-manager'); ?></li>
                                <li><?php _e('Click "Create app".', 'at-agency-manager'); ?></li>
                                <li><?php _e('Choose "Scoped access" and "App folder".', 'at-agency-manager'); ?></li>
                                <li><?php _e('Configure the required scopes: files.content.write, files.content.read.', 'at-agency-manager'); ?></li>
                                <li><?php _e('Copy the App key and App secret.', 'at-agency-manager'); ?></li>
                                <li><?php _e('Generate access token for testing.', 'at-agency-manager'); ?></li>
                            </ol>
                        </div>
                        <p>
                            <input type="text" name="at_backup_dropbox_app_key" value="<?php echo esc_attr(get_option('at_backup_dropbox_app_key')); ?>" placeholder="App Key" class="regular-text" />
                        </p>
                        <p>
                            <input type="text" name="at_backup_dropbox_app_secret" value="<?php echo esc_attr(get_option('at_backup_dropbox_app_secret')); ?>" placeholder="App Secret" class="regular-text" />
                        </p>
                        <p>
                            <input type="text" name="at_backup_dropbox_access_token" value="<?php echo esc_attr(get_option('at_backup_dropbox_access_token')); ?>" placeholder="Access Token" class="regular-text" />
                        </p>
                        <p class="description"><?php _e('For production use, implement OAuth 2.0 flow instead of using access token directly.', 'at-agency-manager'); ?></p>
                    </td>
                </tr>

                <!-- Amazon S3 Settings -->
                <tr class="at-cloud-settings at-s3-settings">
                    <th><?php _e('Amazon S3 Settings', 'at-agency-manager'); ?></th>
                    <td>
                        <div class="notice notice-info inline" style="margin-bottom:10px;">
                            <strong><?php _e('Setup Instructions:', 'at-agency-manager'); ?></strong><br>
                            <ol style="margin:0 0 0 20px;">
                                <li><?php _e('Go to <a href="https://console.aws.amazon.com/iam/" target="_blank">AWS IAM Console</a>.', 'at-agency-manager'); ?></li>
                                <li><?php _e('Create a new user with S3 permissions.', 'at-agency-manager'); ?></li>
                                <li><?php _e('Create an access key for the user.', 'at-agency-manager'); ?></li>
                                <li><?php _e('Go to <a href="https://console.aws.amazon.com/s3/" target="_blank">S3 Console</a> and create a bucket.', 'at-agency-manager'); ?></li>
                                <li><?php _e('Copy the access key, secret key, bucket name, and region.', 'at-agency-manager'); ?></li>
                            </ol>
                        </div>
                        <p>
                            <input type="text" name="at_backup_s3_access_key" value="<?php echo esc_attr(get_option('at_backup_s3_access_key')); ?>" placeholder="Access Key ID" class="regular-text" />
                        </p>
                        <p>
                            <input type="password" name="at_backup_s3_secret_key" value="<?php echo esc_attr(get_option('at_backup_s3_secret_key')); ?>" placeholder="Secret Access Key" class="regular-text" />
                        </p>
                        <p>
                            <input type="text" name="at_backup_s3_bucket" value="<?php echo esc_attr(get_option('at_backup_s3_bucket')); ?>" placeholder="Bucket Name" class="regular-text" />
                        </p>
                        <p>
                            <select name="at_backup_s3_region">
                                <option value="us-east-1" <?php selected(get_option('at_backup_s3_region'), 'us-east-1'); ?>>US East (N. Virginia)</option>
                                <option value="us-west-1" <?php selected(get_option('at_backup_s3_region'), 'us-west-1'); ?>>US West (N. California)</option>
                                <option value="us-west-2" <?php selected(get_option('at_backup_s3_region'), 'us-west-2'); ?>>US West (Oregon)</option>
                                <option value="eu-west-1" <?php selected(get_option('at_backup_s3_region'), 'eu-west-1'); ?>>EU (Ireland)</option>
                                <option value="eu-central-1" <?php selected(get_option('at_backup_s3_region'), 'eu-central-1'); ?>>EU (Frankfurt)</option>
                                <option value="ap-southeast-1" <?php selected(get_option('at_backup_s3_region'), 'ap-southeast-1'); ?>>Asia Pacific (Singapore)</option>
                                <option value="ap-northeast-1" <?php selected(get_option('at_backup_s3_region'), 'ap-northeast-1'); ?>>Asia Pacific (Tokyo)</option>
                            </select>
                        </p>
                        <p>
                            <input type="text" name="at_backup_s3_folder" value="<?php echo esc_attr(get_option('at_backup_s3_folder', 'at-backups')); ?>" placeholder="Folder name (optional)" class="regular-text" />
                        </p>
                    </td>
                </tr>

                <tr><th><?php _e('Exclusions', 'at-agency-manager'); ?></th>
                    <td>
                        <p class="description"><?php _e('Exclude specific files and folders from backup (one per line, relative to WordPress root):', 'at-agency-manager'); ?></p>
                        <textarea name="at_backup_excluded_items" rows="5" cols="40" placeholder="wp-content/uploads/at-backups&#10;wp-content/cache&#10;*.log"><?php
                            $excluded = get_option('at_backup_excluded_items', ['at-backups']);
                            echo is_array($excluded) ? esc_textarea(implode("\n", $excluded)) : esc_textarea($excluded);
                        ?></textarea>
                        <p class="description"><?php _e('Note: at-backups folder is always excluded to prevent recursive backup.', 'at-agency-manager'); ?></p>
                    </td>
                </tr>

                <tr><th><?php _e('Backup Content', 'at-agency-manager'); ?></th>
                    <td>
                        <label><input type="checkbox" name="at_backup_content[plugins]" value="1" <?php checked(get_option('at_backup_content')['plugins'] ?? false); ?> /> <?php _e('Plugins', 'at-agency-manager'); ?></label><br>
                        <label><input type="checkbox" name="at_backup_content[themes]" value="1" <?php checked(get_option('at_backup_content')['themes'] ?? false); ?> /> <?php _e('Themes', 'at-agency-manager'); ?></label><br>
                        <label><input type="checkbox" name="at_backup_content[uploads]" value="1" <?php checked(get_option('at_backup_content')['uploads'] ?? false); ?> /> <?php _e('Uploads', 'at-agency-manager'); ?></label><br>
                        <label><?php _e('Custom Paths:', 'at-agency-manager'); ?><br>
                            <textarea name="at_backup_content[custom]" rows="2" cols="40"><?php echo esc_textarea(get_option('at_backup_content')['custom'] ?? ''); ?></textarea>
                        </label><br>
                        <label><input type="checkbox" name="at_backup_content[database]" value="1" <?php checked(get_option('at_backup_content')['database'] ?? true); ?> /> <?php _e('Database', 'at-agency-manager'); ?></label>
                        <br><label><input type="checkbox" name="at_backup_content[wp_config]" value="1" <?php checked(get_option('at_backup_content')['wp_config'] ?? false); ?> /> <?php _e('wp-config.php', 'at-agency-manager'); ?></label>
                    </td>
                </tr>
                <tr><th><?php _e('Frequency', 'at-agency-manager'); ?></th>
                    <td>
                        <select name="at_backup_frequency">
                            <option value="immediate" <?php selected(get_option('at_backup_frequency'), 'immediate'); ?>><?php _e('Immediate (on change)', 'at-agency-manager'); ?></option>
                            <option value="hourly" <?php selected(get_option('at_backup_frequency'), 'hourly'); ?>><?php _e('Hourly', 'at-agency-manager'); ?></option>
                            <option value="daily" <?php selected(get_option('at_backup_frequency'), 'daily'); ?>><?php _e('Daily', 'at-agency-manager'); ?></option>
                        </select>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
        <h2><?php _e('Manual Backup', 'at-agency-manager'); ?></h2>
        <button class="button button-primary" id="at-backup-now-btn"><?php _e('Run Backup Now', 'at-agency-manager'); ?></button>
        <span id="at-backup-now-status"></span>
        <div style="margin-top:15px;">
            <strong><?php _e('Last Successful Backup:', 'at-agency-manager'); ?></strong> <?php echo $last ? esc_html($last) : __('Never', 'at-agency-manager'); ?>
        </div>

        <!-- רשימת גיבויים קיימים -->
        <h2 style="margin-top:30px;"><?php _e('Existing Backups', 'at-agency-manager'); ?></h2>
        <?php
        // קבלת רשימת הגיבויים מהתיקייה המקומית
        $backup_dir = trailingslashit(wp_upload_dir()['basedir']) . 'at-backups';
        $backups = array();
        $total_size = 0;

        if (file_exists($backup_dir) && is_dir($backup_dir)) {
            $files = glob($backup_dir . '/backup-*.zip');
            if ($files) {
                foreach ($files as $file) {
                    $file_name = basename($file);
                    $file_size = filesize($file);
                    $file_time = filemtime($file);
                    $total_size += $file_size;

                    $backups[] = array(
                        'name' => $file_name,
                        'path' => $file,
                        'size' => $file_size,
                        'size_formatted' => size_format($file_size, 2),
                        'date' => date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $file_time),
                        'timestamp' => $file_time
                    );
                }

                // מיון לפי תאריך (החדשים ביותר קודם)
                usort($backups, function($a, $b) {
                    return $b['timestamp'] - $a['timestamp'];
                });
            }
        }
        ?>

        <?php if (!empty($backups)): ?>
            <div class="notice notice-info inline" style="margin-bottom:10px;">
                <p>
                    <strong><?php _e('Total Backups:', 'at-agency-manager'); ?></strong> <?php echo count($backups); ?> |
                    <strong><?php _e('Total Size:', 'at-agency-manager'); ?></strong> <?php echo size_format($total_size, 2); ?>
                </p>
            </div>

            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('File Name', 'at-agency-manager'); ?></th>
                        <th><?php _e('Date & Time', 'at-agency-manager'); ?></th>
                        <th><?php _e('Size', 'at-agency-manager'); ?></th>
                        <th><?php _e('Actions', 'at-agency-manager'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($backups as $backup): ?>
                        <tr>
                            <td><code><?php echo esc_html($backup['name']); ?></code></td>
                            <td><?php echo esc_html($backup['date']); ?></td>
                            <td><?php echo esc_html($backup['size_formatted']); ?></td>
                            <td>
                                <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin-ajax.php?action=at_download_backup&file=' . urlencode($backup['name'])), 'at_download_backup')); ?>" class="button button-small">
                                    <?php _e('Download', 'at-agency-manager'); ?>
                                </a>
                                <button type="button" class="button button-small at-delete-backup" data-file="<?php echo esc_attr($backup['name']); ?>">
                                    <?php _e('Delete', 'at-agency-manager'); ?>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p><?php _e('No backups found.', 'at-agency-manager'); ?></p>
        <?php endif; ?>
        <script>
        jQuery(function($){
            // טעינה ראשונית - הצג את ההגדרות של השירות הנבחר
            toggleCloudSettings();

            // שינוי שירות ענן
            $('#at_backup_cloud_service').on('change', function(){
                toggleCloudSettings();
            });

            // גיבוי ידני
            $('#at-backup-now-btn').on('click',function(){
                var btn=$(this),status=$('#at-backup-now-status');
                btn.prop('disabled',true).text('<?php _e('Backing up...', 'at-agency-manager'); ?>');
                $.post(ajaxurl,{
                    action:'at_run_backup_now',
                    nonce: '<?php echo wp_create_nonce('at_backup_now'); ?>'
                },function(r){
                    status.text(r.success ? '✔' : '✖');
                    btn.prop('disabled',false).text('<?php _e('Run Backup Now', 'at-agency-manager'); ?>');
                });
            });

            // מחיקת גיבוי
            $('.at-delete-backup').on('click', function() {
                if (!confirm('<?php _e('Are you sure you want to delete this backup?', 'at-agency-manager'); ?>')) {
                    return;
                }

                var btn = $(this);
                var fileName = btn.data('file');
                var row = btn.closest('tr');

                btn.prop('disabled', true).text('<?php _e('Deleting...', 'at-agency-manager'); ?>');

                $.post(ajaxurl, {
                    action: 'at_delete_backup',
                    file: fileName,
                    nonce: '<?php echo wp_create_nonce('at_delete_backup'); ?>'
                }, function(response) {
                    if (response.success) {
                        row.fadeOut(function() {
                            row.remove();
                            // אם אין עוד שורות, נטען מחדש את הדף
                            if ($('tbody tr').length === 0) {
                                location.reload();
                            }
                        });
                    } else {
                        alert(response.data);
                        btn.prop('disabled', false).text('<?php _e('Delete', 'at-agency-manager'); ?>');
                    }
                });
            });

            // אימות Google Drive
            $('#at-backup-auth-btn').on('click', function(e){
                e.preventDefault();

                var clientId = $('input[name="at_backup_drive_client_id"]').val().trim();
                var clientSecret = $('input[name="at_backup_drive_client_secret"]').val().trim();
                var status = $('#at-backup-auth-status');

                if(!clientId || !clientSecret) {
                    status.html('<span style="color:red;"><?php _e('Please enter Client ID and Client Secret', 'at-agency-manager'); ?></span>');
                    return;
                }

                status.html('<span style="color:blue;"><?php _e('Connecting...', 'at-agency-manager'); ?></span>');

                $.post(ajaxurl, {
                    action: 'at_backup_save_google_keys',
                    client_id: clientId,
                    client_secret: clientSecret,
                    nonce: '<?php echo wp_create_nonce('at_backup_auth'); ?>'
                }, function(r) {
                    if(r.success) {
                        var authUrl = r.data.auth_url;
                        var authWindow = window.open(authUrl, 'googleauth',
                            'width=600,height=700,status=0,toolbar=0');

                        var authCheckInterval = setInterval(function() {
                            try {
                                if (authWindow.closed) {
                                    clearInterval(authCheckInterval);
                                    $.post(ajaxurl, {
                                        action: 'at_backup_check_token',
                                        nonce: '<?php echo wp_create_nonce('at_backup_auth'); ?>'
                                    }, function(r) {
                                        if(r.success) {
                                            status.html('<span style="color:green;"><?php _e('Connected ✓', 'at-agency-manager'); ?></span>');
                                        } else {
                                            status.html('<span style="color:red;">' + r.data + '</span>');
                                        }
                                    });
                                }
                            } catch(e) {}
                        }, 500);
                    } else {
                        status.html('<span style="color:red;">' + r.data + '</span>');
                    }
                });
            });

            // פונקציה להצגה/הסתרה של הגדרות שירותי ענן
            function toggleCloudSettings() {
                var selectedService = $('#at_backup_cloud_service').val();

                // הסתר את כל ההגדרות
                $('.at-cloud-settings').hide();

                // הצג את ההגדרות של השירות הנבחר
                if (selectedService !== 'local') {
                    $('.at-' + selectedService.replace('_', '-') + '-settings').show();
                }
            }
        });
        </script>

        <style>
            .at-cloud-settings {
                display: none;
            }
            .inline {
                display: inline-block !important;
                margin: 0 !important;
                padding: 5px 10px !important;
            }
        </style>
    </div>
    <?php
} 
