<?php
if (!defined('ABSPATH')) exit;

class AT_Backup_Drive_Client {
    private $client_id;
    private $client_secret;
    private $refresh_token;
    private $access_token;
    private $token_expires;
    
    public function __construct($client_id, $client_secret, $refresh_token) {
        $this->client_id = $client_id;
        $this->client_secret = $client_secret;
        $this->refresh_token = $refresh_token;
        $this->access_token = get_transient('at_backup_drive_access_token');
        $this->token_expires = get_transient('at_backup_drive_token_expires');
        
        // אם אין טוקן גישה תקף, מנסים לחדש
        if (!$this->access_token || time() > $this->token_expires) {
            $this->refresh_access_token();
        }
    }
    
    private function refresh_access_token() {
        if (!$this->refresh_token) {
            return false;
        }
        
        $response = wp_remote_post('https://oauth2.googleapis.com/token', [
            'body' => [
                'client_id' => $this->client_id,
                'client_secret' => $this->client_secret,
                'refresh_token' => $this->refresh_token,
                'grant_type' => 'refresh_token',
            ],
        ]);
        
        if (is_wp_error($response)) {
            return false;
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (isset($data['access_token'])) {
            $this->access_token = $data['access_token'];
            $this->token_expires = time() + $data['expires_in'] - 300; // פחות 5 דקות למקרה שיש עיכוב
            
            // שמירת הטוקן לשימוש עתידי
            set_transient('at_backup_drive_access_token', $this->access_token, $data['expires_in']);
            set_transient('at_backup_drive_token_expires', $this->token_expires, $data['expires_in']);
            
            return true;
        }
        
        return false;
    }
    
    public function create_folder($name, $parent_id = null) {
        if (!$this->access_token) {
            return ['success' => false, 'message' => __('No access token available', 'at-agency-manager')];
        }
        
        $url = 'https://www.googleapis.com/drive/v3/files';
        
        $metadata = [
            'name' => $name,
            'mimeType' => 'application/vnd.google-apps.folder',
        ];
        
        if ($parent_id) {
            $metadata['parents'] = [$parent_id];
        }
        
        $response = wp_remote_post($url, [
            'headers' => [
                'Authorization' => 'Bearer ' . $this->access_token,
                'Content-Type' => 'application/json',
            ],
            'body' => json_encode($metadata),
        ]);
        
        if (is_wp_error($response)) {
            return ['success' => false, 'message' => $response->get_error_message()];
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (isset($data['id'])) {
            return ['success' => true, 'folder_id' => $data['id']];
        }
        
        return ['success' => false, 'message' => __('Failed to create folder', 'at-agency-manager')];
    }
    
    public function upload($file_path, $folder_id = null) {
        if (!$this->access_token) {
            return ['success' => false, 'message' => __('No access token available', 'at-agency-manager')];
        }
        
        if (!file_exists($file_path)) {
            return ['success' => false, 'message' => __('File does not exist', 'at-agency-manager')];
        }
        
        $file_name = basename($file_path);
        $mime_type = mime_content_type($file_path);
        
        // יצירת מטא-דאטה
        $metadata = [
            'name' => $file_name,
        ];
        
        if ($folder_id) {
            $metadata['parents'] = [$folder_id];
        }
        
        $boundary = wp_generate_password(24, false);
        $url = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart';
        
        $content = "--{$boundary}\r\n";
        $content .= "Content-Type: application/json; charset=UTF-8\r\n\r\n";
        $content .= json_encode($metadata) . "\r\n";
        $content .= "--{$boundary}\r\n";
        $content .= "Content-Type: {$mime_type}\r\n\r\n";
        $content .= file_get_contents($file_path) . "\r\n";
        $content .= "--{$boundary}--";
        
        $response = wp_remote_post($url, [
            'headers' => [
                'Authorization' => 'Bearer ' . $this->access_token,
                'Content-Type' => 'multipart/related; boundary=' . $boundary,
                'Content-Length' => strlen($content),
            ],
            'body' => $content,
            'timeout' => 300, // 5 דקות זמן מספיק להעלאה
        ]);
        
        if (is_wp_error($response)) {
            return ['success' => false, 'message' => $response->get_error_message()];
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (isset($data['id'])) {
            return ['success' => true, 'file_id' => $data['id']];
        }
        
        return ['success' => false, 'message' => __('Failed to upload file', 'at-agency-manager')];
    }
    
    public function get_or_create_backup_folder() {
        // קבלת או יצירת תיקיית גיבוי
        $folder_id = get_option('at_backup_drive_folder_id');
        
        if (!$folder_id) {
            // אם אין מזהה תיקייה, ניצור אחת חדשה
            $site_name = sanitize_title(get_bloginfo('name'));
            $folder_name = $site_name . '-backup';
            
            $result = $this->create_folder($folder_name);
            
            if ($result['success']) {
                update_option('at_backup_drive_folder_id', $result['folder_id']);
                return $result['folder_id'];
            }
            
            return false;
        }
        
        return $folder_id;
    }
} 