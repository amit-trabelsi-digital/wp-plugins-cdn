<?php
/**
 * Module: Protected Files
 *
 * Protects local WordPress uploads by moving them outside the public web root
 * and serving them through a logged-in-only endpoint.
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Protected_Files_Module {
    const META_KEY = '_at_protected_file_enabled';
    const QUERY_VAR = 'at_protected_media';
    const ROUTE_BASE = 'at-protected-media';
    const NOTICE_KEY = 'at_protected_files_notice';
    const NONCE_FIELD = 'at_protected_file_nonce';
    const NONCE_PREFIX = 'at_protected_file_attachment_';

    /**
     * @var AT_Protected_Files_Module|null
     */
    protected static $instance = null;

    /**
     * @var string
     */
    protected $settings_page_hook = '';

    /**
     * Register global hooks for the module.
     *
     * These hooks must be registered even when the module is disabled so we can
     * flush rewrite rules when the checkbox changes.
     *
     * @return void
     */
    public static function register_global_hooks() {
        add_action('plugins_loaded', array(__CLASS__, 'maybe_boot'), 20);
        add_action('update_option_at_agency_manager_modules', array(__CLASS__, 'handle_modules_option_change'), 10, 3);
    }

    /**
     * Bootstrap the module only when enabled.
     *
     * @return void
     */
    public static function maybe_boot() {
        if (!self::is_enabled()) {
            return;
        }

        self::get_instance();
    }

    /**
     * Return the singleton instance.
     *
     * @return AT_Protected_Files_Module
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    /**
     * Check whether the module is enabled in plugin settings.
     *
     * @return bool
     */
    public static function is_enabled() {
        $modules = get_option('at_agency_manager_modules', array());

        return !empty($modules['protected_files']);
    }

    /**
     * Handle module toggle changes and flush rewrite rules.
     *
     * @param array  $old_value Previous module configuration.
     * @param array  $value     New module configuration.
     * @param string $option    Option name.
     * @return void
     */
    public static function handle_modules_option_change($old_value, $value, $option) {
        unset($option);

        $was_enabled = !empty($old_value['protected_files']);
        $is_enabled = !empty($value['protected_files']);

        if ($was_enabled === $is_enabled) {
            return;
        }

        if ($is_enabled) {
            $module = self::get_instance();
            $module->register_rewrite();
        }

        flush_rewrite_rules();
    }

    /**
     * Constructor.
     */
    protected function __construct() {
        add_action('init', array($this, 'register_rewrite'));
        add_filter('query_vars', array($this, 'register_query_vars'));
        add_action('template_redirect', array($this, 'maybe_serve_protected_media'), 0);

        add_filter('get_attached_file', array($this, 'filter_attached_file'), 20, 2);
        add_filter('wp_get_attachment_url', array($this, 'filter_attachment_url'), 20, 2);
        add_filter('image_downsize', array($this, 'filter_image_downsize'), 20, 3);
        add_filter('wp_calculate_image_srcset', array($this, 'disable_image_srcset'), 20, 5);
        add_filter('the_content', array($this, 'filter_protected_urls_in_content'), 20);

        if (is_admin()) {
            add_action('admin_menu', array($this, 'register_settings_page'));
            add_action('admin_post_at_protected_files_toggle', array($this, 'handle_single_toggle'));
            add_filter('bulk_actions-upload', array($this, 'register_bulk_actions'));
            add_filter('handle_bulk_actions-upload', array($this, 'handle_bulk_actions'), 10, 3);
            add_action('admin_notices', array($this, 'render_admin_notices'));
            add_filter('attachment_fields_to_edit', array($this, 'add_attachment_fields'), 20, 2);
            add_filter('attachment_fields_to_save', array($this, 'save_attachment_fields'), 20, 2);
            add_filter('media_row_actions', array($this, 'add_media_row_actions'), 20, 2);
            add_filter('manage_media_columns', array($this, 'add_media_column'), 20);
            add_action('manage_media_custom_column', array($this, 'render_media_column'), 20, 2);
            add_filter('wp_prepare_attachment_for_js', array($this, 'prepare_attachment_for_js'), 20, 3);
            add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        }
    }

    /**
     * Register the protected media rewrite rule.
     *
     * @return void
     */
    public function register_rewrite() {
        add_rewrite_tag('%' . self::QUERY_VAR . '%', '([0-9]+)');
        add_rewrite_rule(
            '^' . self::ROUTE_BASE . '/([0-9]+)/?$',
            'index.php?' . self::QUERY_VAR . '=$matches[1]',
            'top'
        );
    }

    /**
     * Register custom query vars.
     *
     * @param array $query_vars Existing query vars.
     * @return array
     */
    public function register_query_vars($query_vars) {
        $query_vars[] = self::QUERY_VAR;

        return $query_vars;
    }

    /**
     * Register the settings/status page for this module.
     *
     * @return void
     */
    public function register_settings_page() {
        $this->settings_page_hook = add_submenu_page(
            'at-agency-manager',
            __('Protected Files', 'at-agency-manager'),
            __('Protected Files', 'at-agency-manager'),
            'upload_files',
            'at-protected-files',
            array($this, 'render_settings_page')
        );
    }

    /**
     * Enqueue admin assets for the media library and post editor.
     *
     * @param string $hook Current admin hook.
     * @return void
     */
    public function enqueue_admin_assets($hook) {
        $style_hooks = array(
            'upload.php',
            'post.php',
            'post-new.php',
            'media-new.php',
            $this->settings_page_hook,
        );

        if (!in_array($hook, $style_hooks, true)) {
            return;
        }

        wp_enqueue_style(
            'at-protected-files-admin',
            AT_AGENCY_MANAGER_URL . 'assets/css/protected-files-admin.css',
            array(),
            AT_AGENCY_MANAGER_VERSION
        );

        $script_hooks = array(
            'upload.php',
            'post.php',
            'post-new.php',
            'media-new.php',
        );

        if (!in_array($hook, $script_hooks, true)) {
            return;
        }

        wp_enqueue_script(
            'at-protected-files-admin',
            AT_AGENCY_MANAGER_URL . 'assets/js/protected-files-admin.js',
            array('jquery', 'media-views', 'underscore'),
            AT_AGENCY_MANAGER_VERSION,
            true
        );

        wp_localize_script(
            'at-protected-files-admin',
            'atProtectedFilesAdmin',
            array(
                'badgeLabel' => __('Protected', 'at-agency-manager'),
                'badgeDescription' => __('Only logged-in users can access this file.', 'at-agency-manager'),
            )
        );
    }

    /**
     * Render the module status page.
     *
     * @return void
     */
    public function render_settings_page() {
        if (!current_user_can('upload_files')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'at-agency-manager'));
        }

        global $wpdb;

        $protected_count = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value = %s",
                self::META_KEY,
                '1'
            )
        );

        $storage_dir = self::get_storage_base_dir();
        $is_writable = $this->is_storage_dir_writable();
        ?>
        <div class="wrap at-protected-files-page">
            <h1><?php esc_html_e('Protected Files', 'at-agency-manager'); ?></h1>

            <div class="card" style="max-width: 1000px; margin-top: 20px;">
                <h2><?php esc_html_e('Module Status', 'at-agency-manager'); ?></h2>
                <table class="form-table" role="presentation">
                    <tbody>
                        <tr>
                            <th scope="row"><?php esc_html_e('Protected attachments', 'at-agency-manager'); ?></th>
                            <td><strong><?php echo esc_html(number_format_i18n($protected_count)); ?></strong></td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Private storage directory', 'at-agency-manager'); ?></th>
                            <td><code><?php echo esc_html($storage_dir); ?></code></td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Storage status', 'at-agency-manager'); ?></th>
                            <td>
                                <?php if ($is_writable) : ?>
                                    <span class="at-protected-file-badge is-protected"><?php esc_html_e('Writable', 'at-agency-manager'); ?></span>
                                <?php else : ?>
                                    <span class="at-protected-file-badge is-public"><?php esc_html_e('Not writable yet', 'at-agency-manager'); ?></span>
                                <?php endif; ?>
                                <p class="description" style="margin-top: 8px;">
                                    <?php esc_html_e('The directory will be created automatically on the first protect action.', 'at-agency-manager'); ?>
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="card" style="max-width: 1000px; margin-top: 20px;">
                <h2><?php esc_html_e('How protection works', 'at-agency-manager'); ?></h2>
                <ol style="margin-inline-start: 20px;">
                    <li><?php esc_html_e('When a file is marked as protected, the plugin moves the original file and generated image sizes to a private directory outside the public web root.', 'at-agency-manager'); ?></li>
                    <li><?php esc_html_e('WordPress keeps the original relative attachment path in the database, while the plugin stores the protection state in attachment meta.', 'at-agency-manager'); ?></li>
                    <li><?php esc_html_e('Attachment URLs are replaced with a secure endpoint under /at-protected-media/{attachment_id}.', 'at-agency-manager'); ?></li>
                    <li><?php esc_html_e('Only logged-in users receive the file. Unauthenticated visitors get a 403 response.', 'at-agency-manager'); ?></li>
                    <li><?php esc_html_e('The secure response sends noindex/noarchive headers and disables public caching.', 'at-agency-manager'); ?></li>
                </ol>
                <p class="description">
                    <?php esc_html_e('Documentation with the full flow diagram lives in docs/PROTECTED_FILES_MODULE.md inside the plugin repository.', 'at-agency-manager'); ?>
                </p>
            </div>

            <div class="card" style="max-width: 1000px; margin-top: 20px;">
                <h2><?php esc_html_e('Operational notes', 'at-agency-manager'); ?></h2>
                <ul style="margin-inline-start: 20px; list-style: disc;">
                    <li><?php esc_html_e('Protect and unprotect actions are available from the Media Library row actions, bulk actions, and attachment details modal.', 'at-agency-manager'); ?></li>
                    <li><?php esc_html_e('This v1 module only supports local uploads. S3-synced media is intentionally out of scope.', 'at-agency-manager'); ?></li>
                    <li><?php esc_html_e('Before disabling or uninstalling the module, unprotect any files you still need to keep publicly reachable through WordPress.', 'at-agency-manager'); ?></li>
                </ul>
            </div>
        </div>
        <?php
    }

    /**
     * Add the protected file field to the attachment edit form/modal.
     *
     * @param array   $form_fields Existing form fields.
     * @param WP_Post $post        Attachment post object.
     * @return array
     */
    public function add_attachment_fields($form_fields, $post) {
        $attachment_id = (int) $post->ID;
        $is_protected = self::is_attachment_protected($attachment_id);
        $is_local = $this->is_local_attachment($attachment_id);
        $secure_url = $is_protected ? $this->build_protected_url($attachment_id) : '';

        $status_label = $is_protected
            ? __('Protected', 'at-agency-manager')
            : __('Public', 'at-agency-manager');

        $status_class = $is_protected ? 'is-protected' : 'is-public';
        $card_class = 'at-protected-file-card ' . ($is_protected ? 'is-protected' : 'is-public');

        $status_html = '<div class="' . esc_attr($card_class) . '">';
        $status_html .= '<div class="at-protected-file-card__header">';
        $status_html .= '<span class="at-protected-file-card__icon" aria-hidden="true"><span class="dashicons ' . ($is_protected ? 'dashicons-shield' : 'dashicons-shield-alt') . '"></span></span>';
        $status_html .= '<span class="at-protected-file-badge ' . esc_attr($status_class) . '">' . esc_html($status_label) . '</span>';
        $status_html .= '</div>';

        if ($secure_url) {
            $status_html .= '<div class="at-protected-file-card__row">';
            $status_html .= '<label class="at-protected-file-card__label">' . esc_html__('Secure URL', 'at-agency-manager') . '</label>';
            $status_html .= '<div class="at-protected-file-card__copy">';
            $status_html .= '<input type="text" readonly onclick="this.select();" value="' . esc_attr($secure_url) . '" class="at-protected-file-card__input" />';
            $status_html .= '<button type="button" class="button at-protected-file-card__copy-btn" data-copy-label="' . esc_attr__('Copy', 'at-agency-manager') . '" data-copied-label="' . esc_attr__('Copied!', 'at-agency-manager') . '" aria-label="' . esc_attr__('Copy secure URL', 'at-agency-manager') . '">';
            $status_html .= '<span class="dashicons dashicons-admin-page" aria-hidden="true"></span>';
            $status_html .= '<span class="at-protected-file-card__copy-text">' . esc_html__('Copy', 'at-agency-manager') . '</span>';
            $status_html .= '</button>';
            $status_html .= '</div>';
            $status_html .= '</div>';
        }

        if (!$is_local) {
            $status_html .= '<p class="at-protected-file-card__note">' . esc_html__('Only local uploads can be protected in v1.', 'at-agency-manager') . '</p>';
        } elseif ($is_protected) {
            $status_html .= '<p class="at-protected-file-card__note">' . esc_html__('This file is served only to logged-in users through the protected endpoint.', 'at-agency-manager') . '</p>';
        } else {
            $status_html .= '<p class="at-protected-file-card__note">' . esc_html__('This file is currently publicly reachable from uploads.', 'at-agency-manager') . '</p>';
        }

        $status_html .= '</div>';

        $form_fields['at_protected_file_status'] = array(
            'label' => __('Protection status', 'at-agency-manager'),
            'input' => 'html',
            'html'  => $status_html,
        );

        $checkbox_html = '<input type="hidden" name="attachments[' . $attachment_id . '][' . self::NONCE_FIELD . ']" value="' . esc_attr(wp_create_nonce(self::NONCE_PREFIX . $attachment_id)) . '" />';
        $checkbox_html .= '<label class="at-protected-file-toggle">';
        $checkbox_html .= '<input type="checkbox" name="attachments[' . $attachment_id . '][at_protected_file_enabled]" value="1" ' . checked($is_protected, true, false) . disabled(!$is_local, true, false) . ' />';
        $checkbox_html .= '<span class="at-protected-file-toggle__icon dashicons dashicons-shield" aria-hidden="true"></span>';
        $checkbox_html .= '<span class="at-protected-file-toggle__text">' . esc_html__('Protect this file and require a logged-in session for access.', 'at-agency-manager') . '</span>';
        $checkbox_html .= '</label>';

        $form_fields['at_protected_file_enabled'] = array(
            'label' => __('Protected file', 'at-agency-manager'),
            'input' => 'html',
            'html'  => $checkbox_html,
        );

        return $form_fields;
    }

    /**
     * Persist attachment field changes.
     *
     * @param array $post       Attachment post data.
     * @param array $attachment Attachment form payload.
     * @return array
     */
    public function save_attachment_fields($post, $attachment) {
        $attachment_id = isset($post['ID']) ? (int) $post['ID'] : 0;

        if (!$attachment_id) {
            return $post;
        }

        if (!isset($attachment[self::NONCE_FIELD])) {
            return $post;
        }

        $nonce = sanitize_text_field(wp_unslash($attachment[self::NONCE_FIELD]));

        if (!wp_verify_nonce($nonce, self::NONCE_PREFIX . $attachment_id)) {
            $post['errors']['at_protected_file_enabled'] = __('Protected file security check failed.', 'at-agency-manager');
            return $post;
        }

        if (!$this->current_user_can_manage_attachment($attachment_id)) {
            $post['errors']['at_protected_file_enabled'] = __('You are not allowed to update this attachment.', 'at-agency-manager');
            return $post;
        }

        $should_be_protected = !empty($attachment['at_protected_file_enabled']);
        $result = $this->set_attachment_protection($attachment_id, $should_be_protected);

        if (is_wp_error($result)) {
            $post['errors']['at_protected_file_enabled'] = $result->get_error_message();
        }

        return $post;
    }

    /**
     * Add protect/unprotect row actions in list view.
     *
     * @param array   $actions Existing row actions.
     * @param WP_Post $post    Attachment post object.
     * @return array
     */
    public function add_media_row_actions($actions, $post) {
        $attachment_id = (int) $post->ID;

        if (!$this->current_user_can_manage_attachment($attachment_id) || !$this->is_local_attachment($attachment_id)) {
            return $actions;
        }

        if (self::is_attachment_protected($attachment_id)) {
            $actions['at_protected_file_unprotect'] = sprintf(
                '<a href="%s">%s</a>',
                esc_url($this->get_toggle_url($attachment_id, false)),
                esc_html__('Unprotect', 'at-agency-manager')
            );
        } else {
            $actions['at_protected_file_protect'] = sprintf(
                '<a href="%s">%s</a>',
                esc_url($this->get_toggle_url($attachment_id, true)),
                esc_html__('Protect', 'at-agency-manager')
            );
        }

        return $actions;
    }

    /**
     * Register media library bulk actions.
     *
     * @param array $bulk_actions Existing bulk actions.
     * @return array
     */
    public function register_bulk_actions($bulk_actions) {
        $bulk_actions['at_protected_files_protect'] = __('Protect files', 'at-agency-manager');
        $bulk_actions['at_protected_files_unprotect'] = __('Unprotect files', 'at-agency-manager');

        return $bulk_actions;
    }

    /**
     * Handle bulk actions from the media library.
     *
     * @param string $redirect_to Redirect URL.
     * @param string $action      Selected action.
     * @param array  $post_ids    Attachment IDs.
     * @return string
     */
    public function handle_bulk_actions($redirect_to, $action, $post_ids) {
        if (!in_array($action, array('at_protected_files_protect', 'at_protected_files_unprotect'), true)) {
            return $redirect_to;
        }

        $nonce = isset($_REQUEST['_wpnonce']) ? sanitize_text_field(wp_unslash($_REQUEST['_wpnonce'])) : '';

        if (!$nonce || !wp_verify_nonce($nonce, 'bulk-media')) {
            return add_query_arg(
                array(
                    self::NOTICE_KEY => 'nonce_error',
                ),
                $redirect_to
            );
        }

        $protect = ('at_protected_files_protect' === $action);
        $successes = 0;
        $failures = 0;

        foreach ((array) $post_ids as $post_id) {
            $attachment_id = (int) $post_id;

            if (!$this->current_user_can_manage_attachment($attachment_id)) {
                $failures++;
                continue;
            }

            $result = $this->set_attachment_protection($attachment_id, $protect);

            if (is_wp_error($result)) {
                $failures++;
            } else {
                $successes++;
            }
        }

        return add_query_arg(
            array(
                self::NOTICE_KEY => $protect ? 'bulk_protected' : 'bulk_unprotected',
                'at_protected_files_success' => $successes,
                'at_protected_files_failed'  => $failures,
            ),
            $redirect_to
        );
    }

    /**
     * Handle single row action toggle requests.
     *
     * @return void
     */
    public function handle_single_toggle() {
        $attachment_id = isset($_GET['attachment_id']) ? absint($_GET['attachment_id']) : 0;
        $protect = isset($_GET['protected']) ? (bool) absint($_GET['protected']) : false;

        if (!$attachment_id) {
            wp_die(__('Invalid attachment ID.', 'at-agency-manager'));
        }

        check_admin_referer('at_protected_file_toggle_' . $attachment_id);

        if (!$this->current_user_can_manage_attachment($attachment_id)) {
            wp_die(__('You are not allowed to update this attachment.', 'at-agency-manager'));
        }

        $result = $this->set_attachment_protection($attachment_id, $protect);
        $redirect_to = wp_get_referer() ? wp_get_referer() : admin_url('upload.php');

        if (is_wp_error($result)) {
            $redirect_to = add_query_arg(
                array(
                    self::NOTICE_KEY => 'single_error',
                    'at_protected_files_message' => rawurlencode($result->get_error_message()),
                ),
                $redirect_to
            );
        } else {
            $redirect_to = add_query_arg(
                array(
                    self::NOTICE_KEY => $protect ? 'protected' : 'unprotected',
                ),
                $redirect_to
            );
        }

        wp_safe_redirect($redirect_to);
        exit;
    }

    /**
     * Render admin notices after single/bulk actions.
     *
     * @return void
     */
    public function render_admin_notices() {
        if (empty($_GET[self::NOTICE_KEY])) {
            return;
        }

        $notice = sanitize_key(wp_unslash($_GET[self::NOTICE_KEY]));
        $successes = isset($_GET['at_protected_files_success']) ? (int) $_GET['at_protected_files_success'] : 0;
        $failures = isset($_GET['at_protected_files_failed']) ? (int) $_GET['at_protected_files_failed'] : 0;
        $message = '';
        $type = 'success';

        switch ($notice) {
            case 'protected':
                $message = __('Attachment protected successfully.', 'at-agency-manager');
                break;

            case 'unprotected':
                $message = __('Attachment restored to public uploads successfully.', 'at-agency-manager');
                break;

            case 'bulk_protected':
                $message = sprintf(
                    __('Protected %1$d attachment(s). %2$d failed.', 'at-agency-manager'),
                    $successes,
                    $failures
                );
                break;

            case 'bulk_unprotected':
                $message = sprintf(
                    __('Unprotected %1$d attachment(s). %2$d failed.', 'at-agency-manager'),
                    $successes,
                    $failures
                );
                break;

            case 'single_error':
                $type = 'error';
                $message = isset($_GET['at_protected_files_message'])
                    ? sanitize_text_field(wp_unslash($_GET['at_protected_files_message']))
                    : __('The attachment could not be updated.', 'at-agency-manager');
                break;

            case 'nonce_error':
                $type = 'error';
                $message = __('Bulk action security check failed. Please try again.', 'at-agency-manager');
                break;
        }

        if (!$message) {
            return;
        }
        ?>
        <div class="notice notice-<?php echo esc_attr($type); ?> is-dismissible">
            <p><?php echo esc_html($message); ?></p>
        </div>
        <?php
    }

    /**
     * Add a dedicated media library column for the protection status.
     *
     * @param array $columns Existing media columns.
     * @return array
     */
    public function add_media_column($columns) {
        $columns['at_protected_file_status'] = __('Protection', 'at-agency-manager');

        return $columns;
    }

    /**
     * Render the protection status column.
     *
     * @param string $column_name Column name.
     * @param int    $post_id     Attachment ID.
     * @return void
     */
    public function render_media_column($column_name, $post_id) {
        if ('at_protected_file_status' !== $column_name) {
            return;
        }

        $is_protected = self::is_attachment_protected($post_id);
        $class_name = $is_protected ? 'is-protected' : 'is-public';
        $icon = $is_protected ? 'dashicons-shield' : 'dashicons-shield-alt';
        $label = $is_protected ? __('Protected', 'at-agency-manager') : __('Public', 'at-agency-manager');

        echo '<span class="at-protected-file-badge ' . esc_attr($class_name) . '">';
        echo '<span class="dashicons ' . esc_attr($icon) . '" aria-hidden="true"></span>';
        echo '<span>' . esc_html($label) . '</span>';
        echo '</span>';
    }

    /**
     * Add protected-file metadata to media library JS responses.
     *
     * @param array   $response   Attachment JS response.
     * @param WP_Post $attachment Attachment object.
     * @param array   $meta       Attachment metadata.
     * @return array
     */
    public function prepare_attachment_for_js($response, $attachment, $meta) {
        unset($meta);

        $response['atProtectedFile'] = self::is_attachment_protected($attachment->ID);

        return $response;
    }

    /**
     * Filter the absolute file path for protected attachments.
     *
     * @param string $file          Original attachment path.
     * @param int    $attachment_id Attachment ID.
     * @return string
     */
    public function filter_attached_file($file, $attachment_id) {
        if (!self::is_attachment_protected($attachment_id)) {
            return $file;
        }

        $private_file = $this->get_private_file_path($attachment_id);

        return $private_file ? $private_file : $file;
    }

    /**
     * Filter attachment URLs so protected files are served through the endpoint.
     *
     * @param string $url           Original attachment URL.
     * @param int    $attachment_id Attachment ID.
     * @return string
     */
    public function filter_attachment_url($url, $attachment_id) {
        if (!self::is_attachment_protected($attachment_id)) {
            return $url;
        }

        return $this->build_protected_url($attachment_id);
    }

    /**
     * Provide secure image URLs for protected images.
     *
     * @param mixed $downsize      Whether to short-circuit the image downsize result.
     * @param int   $attachment_id Attachment ID.
     * @param mixed $size          Requested image size.
     * @return mixed
     */
    public function filter_image_downsize($downsize, $attachment_id, $size) {
        if (!self::is_attachment_protected($attachment_id)) {
            return $downsize;
        }

        $size_data = $this->get_image_size_data($attachment_id, $size);

        if (empty($size_data)) {
            return $downsize;
        }

        $query_args = array();

        if (!empty($size_data['size_key']) && 'full' !== $size_data['size_key']) {
            $query_args['size'] = $size_data['size_key'];
        }

        return array(
            $this->build_protected_url($attachment_id, $query_args),
            (int) $size_data['width'],
            (int) $size_data['height'],
            !empty($size_data['is_intermediate']),
        );
    }

    /**
     * Disable srcset generation for protected attachments.
     *
     * @param array|false $sources       Calculated sources.
     * @param array       $size_array    Requested size array.
     * @param string      $image_src     Current image src.
     * @param array       $image_meta    Image metadata.
     * @param int         $attachment_id Attachment ID.
     * @return false|array
     */
    public function disable_image_srcset($sources, $size_array, $image_src, $image_meta, $attachment_id) {
        unset($size_array, $image_src, $image_meta);

        if (self::is_attachment_protected($attachment_id)) {
            return false;
        }

        return $sources;
    }

    /**
     * Replace raw uploads URLs in rendered content with secure protected URLs.
     *
     * This keeps existing post content working even though the physical files
     * are no longer present under wp-content/uploads.
     *
     * @param string $content Rendered content.
     * @return string
     */
    public function filter_protected_urls_in_content($content) {
        if (empty($content)) {
            return $content;
        }

        $upload_dir = wp_get_upload_dir();

        if (empty($upload_dir['baseurl']) || false === strpos($content, $upload_dir['baseurl'])) {
            return $content;
        }

        if (!class_exists('DOMDocument')) {
            return $content;
        }

        $encoding = get_bloginfo('charset') ? get_bloginfo('charset') : 'UTF-8';
        $flags = 0;

        if (defined('LIBXML_HTML_NOIMPLIED')) {
            $flags |= LIBXML_HTML_NOIMPLIED;
        }

        if (defined('LIBXML_HTML_NODEFDTD')) {
            $flags |= LIBXML_HTML_NODEFDTD;
        }

        $wrapped_content = '<div data-at-protected-root="1">' . $content . '</div>';

        if (function_exists('mb_convert_encoding')) {
            $wrapped_content = mb_convert_encoding($wrapped_content, 'HTML-ENTITIES', $encoding);
        }

        $previous_errors = libxml_use_internal_errors(true);
        $document = new DOMDocument('1.0', $encoding);
        $loaded = $document->loadHTML($wrapped_content, $flags);
        libxml_clear_errors();
        libxml_use_internal_errors($previous_errors);

        if (!$loaded) {
            return $content;
        }

        $changed = false;
        $xpath = new DOMXPath($document);

        foreach ($xpath->query('//*[@src or @href or @srcset]') as $node) {
            if ($node->hasAttribute('src')) {
                $src = $node->getAttribute('src');
                $resolved = $this->resolve_protected_url_from_original($src);

                if ($resolved) {
                    $node->setAttribute('src', $resolved['url']);
                    $changed = true;

                    if ($node->hasAttribute('srcset')) {
                        $node->removeAttribute('srcset');
                    }

                    if ($node->hasAttribute('sizes')) {
                        $node->removeAttribute('sizes');
                    }
                }
            }

            if ($node->hasAttribute('href')) {
                $href = $node->getAttribute('href');
                $resolved = $this->resolve_protected_url_from_original($href);

                if ($resolved) {
                    $node->setAttribute('href', $resolved['url']);
                    $changed = true;
                }
            }

            if ($node->hasAttribute('srcset')) {
                $srcset = $node->getAttribute('srcset');
                $first_srcset_url = $this->get_first_srcset_url($srcset);
                $resolved = $this->resolve_protected_url_from_original($first_srcset_url);

                if ($resolved) {
                    $node->removeAttribute('srcset');
                    $changed = true;
                }
            }
        }

        if (!$changed) {
            return $content;
        }

        $root_nodes = $xpath->query('//*[@data-at-protected-root="1"]');

        if (!$root_nodes || 0 === $root_nodes->length) {
            return $content;
        }

        return $this->get_inner_html($root_nodes->item(0));
    }

    /**
     * Serve the protected file response when the custom endpoint is requested.
     *
     * @return void
     */
    public function maybe_serve_protected_media() {
        $attachment_id = absint(get_query_var(self::QUERY_VAR));

        if (!$attachment_id) {
            return;
        }

        if (!self::is_attachment_protected($attachment_id)) {
            $this->send_error_response(404, __('Protected file not found.', 'at-agency-manager'));
        }

        if (!is_user_logged_in()) {
            $this->send_error_response(403, __('You must be logged in to access this file.', 'at-agency-manager'));
        }

        $requested_size = isset($_GET['size']) ? sanitize_key(wp_unslash($_GET['size'])) : 'full';
        $download = isset($_GET['download']) && '1' === wp_unslash($_GET['download']);
        $file_path = $this->get_private_file_path($attachment_id, $requested_size);

        if (!$file_path || !file_exists($file_path) || !is_readable($file_path)) {
            if ('full' !== $requested_size) {
                $file_path = $this->get_private_file_path($attachment_id, 'full');
            }
        }

        if (!$file_path || !file_exists($file_path) || !is_readable($file_path)) {
            $this->send_error_response(404, __('Protected file is missing from storage.', 'at-agency-manager'));
        }

        $mime_type = $this->get_mime_type($file_path, $attachment_id);
        $filename = basename($file_path);

        status_header(200);
        $this->send_protected_headers();
        header('Content-Type: ' . $mime_type);
        header('Content-Length: ' . filesize($file_path));
        header('Content-Disposition: ' . ($download ? 'attachment' : 'inline') . '; filename="' . $filename . '"');

        while (ob_get_level()) {
            ob_end_clean();
        }

        readfile($file_path);
        exit;
    }

    /**
     * Update a single attachment's protection state.
     *
     * @param int  $attachment_id Attachment ID.
     * @param bool $protect       Whether the attachment should be protected.
     * @return true|WP_Error
     */
    protected function set_attachment_protection($attachment_id, $protect) {
        $attachment_id = (int) $attachment_id;

        if (!$attachment_id || 'attachment' !== get_post_type($attachment_id)) {
            return new WP_Error('invalid_attachment', __('Invalid attachment selected.', 'at-agency-manager'));
        }

        if (!$this->is_local_attachment($attachment_id)) {
            return new WP_Error('non_local_attachment', __('Only local uploads can be protected in v1.', 'at-agency-manager'));
        }

        $is_protected = self::is_attachment_protected($attachment_id);

        if ($protect && $is_protected) {
            return true;
        }

        if (!$protect && !$is_protected) {
            return true;
        }

        $result = $protect
            ? $this->move_attachment_files($attachment_id, true)
            : $this->move_attachment_files($attachment_id, false);

        if (is_wp_error($result)) {
            error_log(sprintf(
                '[AT Protected Files] set_attachment_protection failed for attachment %d (%s): %s',
                $attachment_id,
                $protect ? 'protect' : 'unprotect',
                $result->get_error_message()
            ));
            return $result;
        }

        if ($protect) {
            update_post_meta($attachment_id, self::META_KEY, '1');
        } else {
            delete_post_meta($attachment_id, self::META_KEY);
        }

        clean_attachment_cache($attachment_id);

        return true;
    }

    /**
     * Move a protected attachment between public and private storage.
     *
     * @param int  $attachment_id Attachment ID.
     * @param bool $to_private    True to protect, false to restore.
     * @return true|WP_Error
     */
    protected function move_attachment_files($attachment_id, $to_private) {
        $main_relative_path = $this->get_main_relative_path($attachment_id);
        $relative_paths = $this->get_attachment_relative_paths($attachment_id);

        if (empty($relative_paths) || !$main_relative_path) {
            return new WP_Error('missing_paths', __('No local attachment files were found to move.', 'at-agency-manager'));
        }

        $main_public_path = $this->build_absolute_path($this->get_public_upload_base_dir(), $main_relative_path);
        $main_private_path = $this->build_absolute_path(self::get_storage_base_dir(), $main_relative_path);

        if ($to_private && !file_exists($main_public_path)) {
            return new WP_Error('missing_public_file', __('The original public file could not be found.', 'at-agency-manager'));
        }

        if (!$to_private && !file_exists($main_private_path)) {
            return new WP_Error('missing_private_file', __('The protected file could not be found in private storage.', 'at-agency-manager'));
        }

        if ($to_private) {
            $prepared = $this->ensure_storage_dir();
            if (is_wp_error($prepared)) {
                return $prepared;
            }
        }

        $moved_files = array();

        foreach ($relative_paths as $relative_path) {
            $source = $to_private
                ? $this->build_absolute_path($this->get_public_upload_base_dir(), $relative_path)
                : $this->build_absolute_path(self::get_storage_base_dir(), $relative_path);

            $target = $to_private
                ? $this->build_absolute_path(self::get_storage_base_dir(), $relative_path)
                : $this->build_absolute_path($this->get_public_upload_base_dir(), $relative_path);

            if (!file_exists($source)) {
                continue;
            }

            $move_result = $this->move_single_file($source, $target);

            if (is_wp_error($move_result)) {
                foreach (array_reverse($moved_files) as $rollback) {
                    $this->move_single_file($rollback['target'], $rollback['source']);
                }

                return $move_result;
            }

            $moved_files[] = array(
                'source' => $source,
                'target' => $target,
            );
        }

        return true;
    }

    /**
     * Move a single file safely.
     *
     * @param string $source Source path.
     * @param string $target Target path.
     * @return true|WP_Error
     */
    protected function move_single_file($source, $target) {
        if ($source === $target) {
            return true;
        }

        $target_dir = dirname($target);

        if (!file_exists($target_dir) && !wp_mkdir_p($target_dir)) {
            return new WP_Error('target_dir_failed', __('The destination directory could not be created.', 'at-agency-manager'));
        }

        if (file_exists($target) && !unlink($target)) {
            return new WP_Error('target_exists', __('A destination file already exists and could not be replaced.', 'at-agency-manager'));
        }

        if (@rename($source, $target)) {
            return true;
        }

        if (@copy($source, $target) && @unlink($source)) {
            return true;
        }

        return new WP_Error('move_failed', __('One of the attachment files could not be moved.', 'at-agency-manager'));
    }

    /**
     * Build the secure endpoint URL for an attachment.
     *
     * @param int   $attachment_id Attachment ID.
     * @param array $query_args    Optional query args.
     * @return string
     */
    protected function build_protected_url($attachment_id, $query_args = array()) {
        if ('' === (string) get_option('permalink_structure')) {
            $base_url = add_query_arg(self::QUERY_VAR, absint($attachment_id), home_url('/'));
        } else {
            $base_url = home_url(user_trailingslashit(self::ROUTE_BASE . '/' . absint($attachment_id)));
        }

        if (!empty($query_args)) {
            $base_url = add_query_arg($query_args, $base_url);
        }

        return $base_url;
    }

    /**
     * Resolve a public uploads URL to a protected URL when the attachment is protected.
     *
     * @param string $url Original uploads URL.
     * @return array|false
     */
    protected function resolve_protected_url_from_original($url) {
        if (empty($url) || !is_string($url)) {
            return false;
        }

        $upload_dir = wp_get_upload_dir();

        if (empty($upload_dir['baseurl']) || false === strpos($url, $upload_dir['baseurl'])) {
            return false;
        }

        $url_without_query = preg_replace('/[#?].*$/', '', $url);
        $attachment_id = attachment_url_to_postid($url_without_query);

        if (!$attachment_id || !self::is_attachment_protected($attachment_id)) {
            return false;
        }

        $size_key = $this->match_size_key_from_url($attachment_id, $url_without_query);
        $query_args = array();

        if ($size_key && 'full' !== $size_key) {
            $query_args['size'] = $size_key;
        }

        return array(
            'attachment_id' => $attachment_id,
            'size_key'      => $size_key,
            'url'           => $this->build_protected_url($attachment_id, $query_args),
        );
    }

    /**
     * Match a requested URL to a registered intermediate image size.
     *
     * @param int    $attachment_id Attachment ID.
     * @param string $url           Original uploads URL.
     * @return string
     */
    protected function match_size_key_from_url($attachment_id, $url) {
        $main_relative_path = $this->get_main_relative_path($attachment_id);

        if (!$main_relative_path) {
            return 'full';
        }

        $requested_basename = basename(wp_parse_url($url, PHP_URL_PATH));

        if ($requested_basename === basename($main_relative_path)) {
            return 'full';
        }

        $metadata = wp_get_attachment_metadata($attachment_id);

        if (!empty($metadata['sizes']) && is_array($metadata['sizes'])) {
            foreach ($metadata['sizes'] as $size_key => $size_data) {
                if (!empty($size_data['file']) && $requested_basename === $size_data['file']) {
                    return $size_key;
                }
            }
        }

        return 'full';
    }

    /**
     * Get structured image size data for secure image URLs.
     *
     * @param int   $attachment_id Attachment ID.
     * @param mixed $requested_size Requested size.
     * @return array
     */
    protected function get_image_size_data($attachment_id, $requested_size) {
        $metadata = wp_get_attachment_metadata($attachment_id);
        $size_key = 'full';
        $is_intermediate = false;
        $width = !empty($metadata['width']) ? (int) $metadata['width'] : 0;
        $height = !empty($metadata['height']) ? (int) $metadata['height'] : 0;

        if (!empty($requested_size) && 'full' !== $requested_size && !empty($metadata['sizes']) && is_array($metadata['sizes'])) {
            $matched_size = '';

            if (is_array($requested_size)) {
                $matched_size = $this->match_best_size_key_from_dimensions($metadata['sizes'], $requested_size);
            } else {
                $requested_size = sanitize_key((string) $requested_size);
                if (!empty($metadata['sizes'][$requested_size])) {
                    $matched_size = $requested_size;
                }
            }

            if ($matched_size && !empty($metadata['sizes'][$matched_size])) {
                $size_key = $matched_size;
                $width = !empty($metadata['sizes'][$matched_size]['width']) ? (int) $metadata['sizes'][$matched_size]['width'] : $width;
                $height = !empty($metadata['sizes'][$matched_size]['height']) ? (int) $metadata['sizes'][$matched_size]['height'] : $height;
                $is_intermediate = true;
            }
        }

        return array(
            'size_key'        => $size_key,
            'width'           => $width,
            'height'          => $height,
            'is_intermediate' => $is_intermediate,
        );
    }

    /**
     * Match the closest image size for array-based image requests.
     *
     * @param array $sizes          Registered image sizes from metadata.
     * @param array $requested_size Requested size array.
     * @return string
     */
    protected function match_best_size_key_from_dimensions($sizes, $requested_size) {
        $target_width = !empty($requested_size[0]) ? (int) $requested_size[0] : 0;
        $target_height = !empty($requested_size[1]) ? (int) $requested_size[1] : 0;
        $best_key = '';
        $best_score = PHP_INT_MAX;

        foreach ($sizes as $size_key => $size_data) {
            if (empty($size_data['width']) || empty($size_data['height'])) {
                continue;
            }

            $score = abs((int) $size_data['width'] - $target_width) + abs((int) $size_data['height'] - $target_height);

            if ($score < $best_score) {
                $best_score = $score;
                $best_key = $size_key;
            }
        }

        return $best_key;
    }

    /**
     * Collect every relative file path for the attachment that must be moved.
     *
     * @param int $attachment_id Attachment ID.
     * @return array
     */
    protected function get_attachment_relative_paths($attachment_id) {
        $main_relative_path = $this->get_main_relative_path($attachment_id);

        if (!$main_relative_path) {
            return array();
        }

        $paths = array($main_relative_path);
        $directory = dirname($main_relative_path);
        $metadata = wp_get_attachment_metadata($attachment_id);

        if (!empty($metadata['sizes']) && is_array($metadata['sizes'])) {
            foreach ($metadata['sizes'] as $size_data) {
                if (empty($size_data['file'])) {
                    continue;
                }

                $paths[] = $this->join_relative_path($directory, $size_data['file']);
            }
        }

        if (!empty($metadata['original_image'])) {
            $paths[] = $this->join_relative_path($directory, $metadata['original_image']);
        }

        if (!empty($metadata['backup_sizes']) && is_array($metadata['backup_sizes'])) {
            foreach ($metadata['backup_sizes'] as $backup_size) {
                if (empty($backup_size['file'])) {
                    continue;
                }

                $paths[] = $this->join_relative_path($directory, $backup_size['file']);
            }
        }

        $backup_sizes = get_post_meta($attachment_id, '_wp_attachment_backup_sizes', true);

        if (!empty($backup_sizes) && is_array($backup_sizes)) {
            foreach ($backup_sizes as $backup_size) {
                if (empty($backup_size['file'])) {
                    continue;
                }

                $paths[] = $this->join_relative_path($directory, $backup_size['file']);
            }
        }

        $paths = array_unique(array_filter($paths));
        sort($paths);

        return $paths;
    }

    /**
     * Get the private absolute path for an attachment and size.
     *
     * @param int    $attachment_id Attachment ID.
     * @param string $size_key      Image size key.
     * @return string
     */
    protected function get_private_file_path($attachment_id, $size_key = 'full') {
        $relative_path = $this->get_relative_path_for_size($attachment_id, $size_key);

        if (!$relative_path) {
            return '';
        }

        return $this->build_absolute_path(self::get_storage_base_dir(), $relative_path);
    }

    /**
     * Get the public absolute path for an attachment and size.
     *
     * @param int    $attachment_id Attachment ID.
     * @param string $size_key      Image size key.
     * @return string
     */
    protected function get_public_file_path($attachment_id, $size_key = 'full') {
        $relative_path = $this->get_relative_path_for_size($attachment_id, $size_key);

        if (!$relative_path) {
            return '';
        }

        return $this->build_absolute_path($this->get_public_upload_base_dir(), $relative_path);
    }

    /**
     * Get a relative file path for the requested image size.
     *
     * @param int    $attachment_id Attachment ID.
     * @param string $size_key      Image size key.
     * @return string
     */
    protected function get_relative_path_for_size($attachment_id, $size_key = 'full') {
        $main_relative_path = $this->get_main_relative_path($attachment_id);

        if (!$main_relative_path) {
            return '';
        }

        if (empty($size_key) || 'full' === $size_key) {
            return $main_relative_path;
        }

        $metadata = wp_get_attachment_metadata($attachment_id);

        if (!empty($metadata['sizes'][$size_key]['file'])) {
            return $this->join_relative_path(dirname($main_relative_path), $metadata['sizes'][$size_key]['file']);
        }

        return $main_relative_path;
    }

    /**
     * Get the main attachment path exactly as WordPress stores it.
     *
     * @param int $attachment_id Attachment ID.
     * @return string
     */
    protected function get_main_relative_path($attachment_id) {
        $stored_path = get_post_meta($attachment_id, '_wp_attached_file', true);

        if (empty($stored_path)) {
            return '';
        }

        return $this->normalize_relative_path($stored_path);
    }

    /**
     * Normalize a stored attachment path to a relative uploads path.
     *
     * @param string $path Attachment path.
     * @return string
     */
    protected function normalize_relative_path($path) {
        $path = wp_normalize_path((string) $path);
        $path = ltrim($path, '/');

        $upload_dir = wp_get_upload_dir();
        $base_dir = isset($upload_dir['basedir']) ? wp_normalize_path($upload_dir['basedir']) : '';
        $base_url = isset($upload_dir['baseurl']) ? wp_normalize_path($upload_dir['baseurl']) : '';

        if ($base_dir && 0 === strpos($path, $base_dir . '/')) {
            $path = substr($path, strlen($base_dir) + 1);
        }

        if ($base_url && 0 === strpos($path, $base_url . '/')) {
            $path = substr($path, strlen($base_url) + 1);
        }

        return ltrim($path, '/');
    }

    /**
     * Check whether an attachment can be treated as a local upload.
     *
     * @param int $attachment_id Attachment ID.
     * @return bool
     */
    protected function is_local_attachment($attachment_id) {
        $relative_path = $this->get_main_relative_path($attachment_id);

        if (!$relative_path) {
            return false;
        }

        $absolute_path = $this->build_absolute_path($this->get_public_upload_base_dir(), $relative_path);

        return 0 === strpos(wp_normalize_path($absolute_path), wp_normalize_path($this->get_public_upload_base_dir() . '/'));
    }

    /**
     * Check whether the current user can update an attachment.
     *
     * @param int $attachment_id Attachment ID.
     * @return bool
     */
    protected function current_user_can_manage_attachment($attachment_id) {
        return current_user_can('upload_files') && current_user_can('edit_post', $attachment_id);
    }

    /**
     * Build the admin row action toggle URL.
     *
     * @param int  $attachment_id Attachment ID.
     * @param bool $protect       Protection target state.
     * @return string
     */
    protected function get_toggle_url($attachment_id, $protect) {
        $url = add_query_arg(
            array(
                'action'       => 'at_protected_files_toggle',
                'attachment_id' => (int) $attachment_id,
                'protected'    => $protect ? 1 : 0,
            ),
            admin_url('admin-post.php')
        );

        return wp_nonce_url($url, 'at_protected_file_toggle_' . $attachment_id);
    }

    /**
     * Send shared secure-response headers.
     *
     * @return void
     */
    protected function send_protected_headers() {
        nocache_headers();
        header('X-Robots-Tag: noindex, nofollow, noarchive, nosnippet', true);
        header('Cache-Control: private, no-store, max-age=0', true);
        header('Pragma: no-cache', true);
    }

    /**
     * Send an error response for the secure endpoint and stop execution.
     *
     * @param int    $status_code HTTP status code.
     * @param string $message     Response body.
     * @return void
     */
    protected function send_error_response($status_code, $message) {
        status_header((int) $status_code);
        $this->send_protected_headers();
        header('Content-Type: text/plain; charset=' . get_bloginfo('charset'));

        while (ob_get_level()) {
            ob_end_clean();
        }

        echo esc_html($message);
        exit;
    }

    /**
     * Determine the most appropriate mime type for a file response.
     *
     * @param string $file_path      File path.
     * @param int    $attachment_id  Attachment ID.
     * @return string
     */
    protected function get_mime_type($file_path, $attachment_id) {
        $mime_type = '';

        if (function_exists('mime_content_type')) {
            $mime_type = @mime_content_type($file_path);
        }

        if (!$mime_type) {
            $file_type = wp_check_filetype($file_path);
            if (!empty($file_type['type'])) {
                $mime_type = $file_type['type'];
            }
        }

        if (!$mime_type) {
            $mime_type = get_post_mime_type($attachment_id);
        }

        return $mime_type ? $mime_type : 'application/octet-stream';
    }

    /**
     * Check if the storage directory is writable or creatable.
     *
     * @return bool
     */
    protected function is_storage_dir_writable() {
        $storage_dir = self::get_storage_base_dir();

        if (file_exists($storage_dir)) {
            return is_writable($storage_dir);
        }

        $parent = dirname($storage_dir);

        return $parent && file_exists($parent) && is_writable($parent);
    }

    /**
     * Return the base private storage directory.
     *
     * Default location lives inside wp-content so the hosting user (www-data) can
     * always write to it. Access to the files is prevented by the .htaccess and
     * index.php guards created by ensure_storage_dir(), and files are only
     * served through the plugin's authenticated endpoint.
     *
     * @return string
     */
    public static function get_storage_base_dir() {
        $default_dir = wp_normalize_path(WP_CONTENT_DIR . '/at-private-uploads');

        return untrailingslashit(
            apply_filters('at_protected_files_storage_dir', $default_dir)
        );
    }

    /**
     * Create the private storage directory and drop guard files that block
     * direct web access (Apache .htaccess + empty index.php).
     *
     * @return true|WP_Error
     */
    protected function ensure_storage_dir() {
        $storage_dir = self::get_storage_base_dir();

        if (!file_exists($storage_dir) && !wp_mkdir_p($storage_dir)) {
            error_log(sprintf('[AT Protected Files] Failed to create storage directory: %s', $storage_dir));
            return new WP_Error(
                'storage_dir_failed',
                sprintf(
                    /* translators: %s: absolute storage path. */
                    __('The protected storage directory could not be created at %s. Please check file permissions.', 'at-agency-manager'),
                    $storage_dir
                )
            );
        }

        if (!is_writable($storage_dir)) {
            error_log(sprintf('[AT Protected Files] Storage directory is not writable: %s', $storage_dir));
            return new WP_Error(
                'storage_dir_not_writable',
                sprintf(
                    /* translators: %s: absolute storage path. */
                    __('The protected storage directory is not writable: %s', 'at-agency-manager'),
                    $storage_dir
                )
            );
        }

        $htaccess = $storage_dir . '/.htaccess';
        if (!file_exists($htaccess)) {
            @file_put_contents($htaccess, "Order allow,deny\nDeny from all\n");
        }

        $silent_index = $storage_dir . '/index.php';
        if (!file_exists($silent_index)) {
            @file_put_contents($silent_index, "<?php\n// Silence is golden.\n");
        }

        return true;
    }

    /**
     * Return the public uploads base directory.
     *
     * @return string
     */
    protected function get_public_upload_base_dir() {
        $upload_dir = wp_get_upload_dir();

        return isset($upload_dir['basedir']) ? untrailingslashit(wp_normalize_path($upload_dir['basedir'])) : '';
    }

    /**
     * Build an absolute file path from a base directory and relative path.
     *
     * @param string $base_dir       Base directory.
     * @param string $relative_path  Relative path.
     * @return string
     */
    protected function build_absolute_path($base_dir, $relative_path) {
        return wp_normalize_path(untrailingslashit($base_dir) . '/' . ltrim($relative_path, '/'));
    }

    /**
     * Join a relative directory and filename into a normalized relative path.
     *
     * @param string $directory Directory part.
     * @param string $filename  Filename.
     * @return string
     */
    protected function join_relative_path($directory, $filename) {
        $directory = '.' === $directory ? '' : trim((string) $directory, '/');
        $filename = ltrim((string) $filename, '/');

        if ('' === $directory) {
            return $filename;
        }

        return $directory . '/' . $filename;
    }

    /**
     * Get the first URL from an srcset attribute.
     *
     * @param string $srcset Srcset attribute.
     * @return string
     */
    protected function get_first_srcset_url($srcset) {
        if (empty($srcset)) {
            return '';
        }

        $parts = explode(',', $srcset);
        $first = trim((string) reset($parts));

        if ('' === $first) {
            return '';
        }

        $segments = preg_split('/\s+/', $first);

        return !empty($segments[0]) ? $segments[0] : '';
    }

    /**
     * Extract inner HTML from a DOM node.
     *
     * @param DOMNode $node DOM node.
     * @return string
     */
    protected function get_inner_html($node) {
        $html = '';

        foreach ($node->childNodes as $child_node) {
            $html .= $node->ownerDocument->saveHTML($child_node);
        }

        return $html;
    }

    /**
     * Determine if an attachment is currently protected.
     *
     * @param int $attachment_id Attachment ID.
     * @return bool
     */
    public static function is_attachment_protected($attachment_id) {
        return '1' === (string) get_post_meta($attachment_id, self::META_KEY, true);
    }
}

AT_Protected_Files_Module::register_global_hooks();
