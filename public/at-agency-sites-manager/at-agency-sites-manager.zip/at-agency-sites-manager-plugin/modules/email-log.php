<?php
/**
 * Module: Email Log
 * מעקב אחר שליחת אימיילים מהאתר כולל הצגת תוכן המייל, נמענים, סטטוס שליחה ועוד
 * נטען רק אם המודול הופעל במסך ההגדרות (at_agency_manager_modules[email_log]).
 */

// הגנה מפני גישה ישירה
if (!defined('ABSPATH')) {
    exit;
}

/**
 * מחלקה לניהול מעקב אחר אימיילים
 */
class AT_Email_Log {
    /**
     * @var AT_Agency_Manager_Logger מופע של מחלקת הלוגר
     */
    private $logger;
    
    /**
     * @var string שם הטבלה לשמירת האימיילים
     */
    private $table_name;
    
    /**
     * אתחול המחלקה והגדרת האזנה לאירועים רלוונטיים
     */
    public function __construct() {
        global $wpdb;
        
        // אתחול הלוגר אם קיים
        if (class_exists('AT_Agency_Manager_Logger')) {
            $this->logger = new AT_Agency_Manager_Logger();
        }
        
        // הגדרת שם הטבלה
        $this->table_name = $wpdb->prefix . 'at_email_log';
        
        // הרשמה לאירועים
        add_filter('wp_mail', array($this, 'log_email_before_send'), 10);
        add_action('wp_mail_failed', array($this, 'log_email_failed'));
        
        // הוספת דף ניהול
        add_action('admin_menu', array($this, 'add_email_log_menu'));
        
        // יצירת טבלת האימיילים אם לא קיימת
        add_action('init', array($this, 'maybe_create_table'));
    }
    
    /**
     * יצירת טבלת האימיילים אם לא קיימת
     */
    public function maybe_create_table() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS {$this->table_name} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            time datetime NOT NULL,
            email_to text NOT NULL,
            subject varchar(255) NOT NULL,
            message text NOT NULL,
            headers text,
            attachments text,
            status varchar(20) NOT NULL DEFAULT 'sent',
            error_message text,
            PRIMARY KEY (id),
            KEY time (time),
            KEY status (status)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    /**
     * הוספת תפריט לניהול יומן האימיילים
     * NOTE: Menu is now registered in class-settings.php to avoid duplicate registration
     */
    public function add_email_log_menu() {
        // Menu registration moved to class-settings.php
        // This method kept for backward compatibility but does nothing
    }
    
    /**
     * רישום אימייל לפני שליחתו
     * 
     * @param array $mail מידע על האימייל שנשלח
     * @return array אותו מידע ללא שינוי
     */
    public function log_email_before_send($mail) {
        global $wpdb;
        
        $to = is_array($mail['to']) ? implode(', ', $mail['to']) : $mail['to'];
        $subject = $mail['subject'];
        $message = $mail['message'];
        $headers = is_array($mail['headers']) ? implode("\n", $mail['headers']) : $mail['headers'];
        $attachments = is_array($mail['attachments']) ? implode("\n", $mail['attachments']) : $mail['attachments'];
        
        // רישום האימייל בטבלה
        $wpdb->insert(
            $this->table_name,
            array(
                'time' => current_time('mysql'),
                'email_to' => $to,
                'subject' => $subject,
                'message' => $message,
                'headers' => $headers,
                'attachments' => $attachments,
                'status' => 'sent'
            ),
            array('%s', '%s', '%s', '%s', '%s', '%s', '%s')
        );
        
        // רישום באמצעות הלוגר אם קיים
        if ($this->logger) {
            $this->logger->log_email($to, $subject, 'info');
        }
        
        return $mail;
    }
    
    /**
     * רישום כישלון בשליחת אימייל
     * 
     * @param WP_Error $error השגיאה שהתקבלה
     */
    public function log_email_failed($error) {
        global $wpdb;
        
        $mail_data = $error->get_error_data('wp_mail_failed');
        
        if (!empty($mail_data)) {
            $to = is_array($mail_data['to']) ? implode(', ', $mail_data['to']) : $mail_data['to'];
            $subject = $mail_data['subject'];
            $message = $mail_data['message'];
            $headers = is_array($mail_data['headers']) ? implode("\n", $mail_data['headers']) : $mail_data['headers'];
            $attachments = is_array($mail_data['attachments']) ? implode("\n", $mail_data['attachments']) : $mail_data['attachments'];
            
            // רישום האימייל בטבלה עם סטטוס שגיאה
            $wpdb->insert(
                $this->table_name,
                array(
                    'time' => current_time('mysql'),
                    'email_to' => $to,
                    'subject' => $subject,
                    'message' => $message,
                    'headers' => $headers,
                    'attachments' => $attachments,
                    'status' => 'failed',
                    'error_message' => $error->get_error_message()
                ),
                array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
            );
            
            // רישום באמצעות הלוגר אם קיים
            if ($this->logger) {
                $this->logger->log_email($to, $subject, 'error');
            }
        }
    }
    
    /**
     * הצגת דף ניהול יומן האימיילים
     */
    public function render_email_log_page() {
        // בדיקת הרשאות
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'at-agency-manager'));
        }
        
        global $wpdb;
        
        // מספר אימיילים לעמוד
        $per_page = 20;
        
        // מספר העמוד הנוכחי
        $page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        
        // פילטרים
        $status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
        $search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
        
        // בניית השאילתה
        $query = "SELECT SQL_CALC_FOUND_ROWS * FROM {$this->table_name} WHERE 1=1";
        $query_args = array();
        
        if ($status_filter) {
            $query .= " AND status = %s";
            $query_args[] = $status_filter;
        }
        
        if ($search) {
            $query .= " AND (email_to LIKE %s OR subject LIKE %s)";
            $query_args[] = '%' . $wpdb->esc_like($search) . '%';
            $query_args[] = '%' . $wpdb->esc_like($search) . '%';
        }
        
        // סידור לפי זמן
        $query .= " ORDER BY time DESC";
        
        // הגבלת מספר התוצאות לעמוד
        $query .= " LIMIT %d, %d";
        $query_args[] = ($page - 1) * $per_page;
        $query_args[] = $per_page;
        
        // ביצוע השאילתה
        $emails = $wpdb->get_results($wpdb->prepare($query, $query_args));
        
        // מספר התוצאות הכולל
        $total_items = $wpdb->get_var("SELECT FOUND_ROWS()");
        $total_pages = ceil($total_items / $per_page);
        
        // הסטטוסים האפשריים
        $statuses = array(
            'sent' => __('Sent', 'at-agency-manager'),
            'failed' => __('Failed', 'at-agency-manager')
        );
        
        ?>
        <div class="wrap">
            <h1><?php _e('Email Log', 'at-agency-manager'); ?></h1>
            
            <form method="get">
                <input type="hidden" name="page" value="at-email-log">
                
                <div class="tablenav top">
                    <div class="alignleft actions">
                        <select name="status">
                            <option value=""><?php _e('All Statuses', 'at-agency-manager'); ?></option>
                            <?php foreach ($statuses as $value => $label) : ?>
                                <option value="<?php echo esc_attr($value); ?>" <?php selected($status_filter, $value); ?>><?php echo esc_html($label); ?></option>
                            <?php endforeach; ?>
                        </select>
                        
                        <input type="submit" class="button" value="<?php _e('Filter', 'at-agency-manager'); ?>">
                    </div>
                    
                    <div class="search-box">
                        <input type="search" name="s" value="<?php echo esc_attr($search); ?>" placeholder="<?php _e('Search emails...', 'at-agency-manager'); ?>">
                        <input type="submit" class="button" value="<?php _e('Search', 'at-agency-manager'); ?>">
                    </div>
                    
                    <div class="tablenav-pages">
                        <?php if ($total_pages > 1) : ?>
                            <span class="displaying-num">
                                <?php printf(
                                    _n('%s item', '%s items', $total_items, 'at-agency-manager'),
                                    number_format_i18n($total_items)
                                ); ?>
                            </span>
                            
                            <span class="pagination-links">
                                <?php
                                echo paginate_links(array(
                                    'base'      => add_query_arg('paged', '%#%'),
                                    'format'    => '',
                                    'prev_text' => '&laquo;',
                                    'next_text' => '&raquo;',
                                    'total'     => $total_pages,
                                    'current'   => $page
                                ));
                                ?>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('Time', 'at-agency-manager'); ?></th>
                        <th><?php _e('To', 'at-agency-manager'); ?></th>
                        <th><?php _e('Subject', 'at-agency-manager'); ?></th>
                        <th style="width:100px;"><?php _e('Status', 'at-agency-manager'); ?></th>
                        <th><?php _e('Actions', 'at-agency-manager'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($emails)) : ?>
                        <tr>
                            <td colspan="5"><?php _e('No emails found.', 'at-agency-manager'); ?></td>
                        </tr>
                    <?php else : ?>
                        <?php foreach ($emails as $email) : ?>
                            <tr>
                                <td><?php echo esc_html($email->time); ?></td>
                                <td><?php echo esc_html($email->email_to); ?></td>
                                <td><?php echo esc_html($email->subject); ?></td>
                                <td>
                                    <?php if ($email->status === 'sent') : ?>
                                        <span class="email-status email-status-sent"><?php _e('Sent', 'at-agency-manager'); ?></span>
                                    <?php else : ?>
                                        <span class="email-status email-status-failed" title="<?php echo esc_attr($email->error_message); ?>"><?php _e('Failed', 'at-agency-manager'); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="#" class="button view-email" data-id="<?php echo $email->id; ?>"><?php _e('View', 'at-agency-manager'); ?></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- דיאלוג לתצוגת האימייל -->
        <div id="email-details-dialog" style="display:none;" title="<?php _e('Email Details', 'at-agency-manager'); ?>">
            <div class="email-details-content"></div>
        </div>
        
        <style>
            .email-status {
                display: inline-block;
                padding: 3px 8px;
                border-radius: 3px;
                font-size: 12px;
                font-weight: bold;
            }
            .email-status-sent {
                background-color: #ecf9ec;
                color: #008a20;
            }
            .email-status-failed {
                background-color: #fef1f1;
                color: #d63638;
                cursor: help;
            }
        </style>
        
        <script>
            jQuery(document).ready(function($) {
                // יצירת דיאלוג
                $('#email-details-dialog').dialog({
                    autoOpen: false,
                    modal: true,
                    width: 700,
                    height: 500,
                    resizable: true
                });
                
                // טיפול בלחיצת כפתור תצוגה
                $('.view-email').click(function(e) {
                    e.preventDefault();
                    
                    var emailId = $(this).data('id');
                    
                    $.ajax({
                        url: ajaxurl,
                        data: {
                            action: 'at_get_email_details',
                            id: emailId,
                            _nonce: '<?php echo wp_create_nonce('at_email_log_details'); ?>'
                        },
                        success: function(response) {
                            if (response.success) {
                                $('.email-details-content').html(response.data.html);
                                $('#email-details-dialog').dialog('open');
                            } else {
                                alert('<?php _e('Error loading email details.', 'at-agency-manager'); ?>');
                            }
                        }
                    });
                });
            });
        </script>
        <?php
        
        // רישום טיפול ב-Ajax
        add_action('wp_ajax_at_get_email_details', array($this, 'ajax_get_email_details'));
    }
    
    /**
     * טיפול בבקשת Ajax לקבלת פרטי האימייל
     */
    public function ajax_get_email_details() {
        check_ajax_referer('at_email_log_details', '_nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Unauthorized access.', 'at-agency-manager')));
        }
        
        $email_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
        
        if (!$email_id) {
            wp_send_json_error(array('message' => __('Invalid email ID.', 'at-agency-manager')));
        }
        
        global $wpdb;
        
        $email = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE id = %d",
            $email_id
        ));
        
        if (!$email) {
            wp_send_json_error(array('message' => __('Email not found.', 'at-agency-manager')));
        }
        
        ob_start();
        ?>
        <div class="email-details">
            <table class="widefat">
                <tr>
                    <th style="width:100px;"><?php _e('Time', 'at-agency-manager'); ?></th>
                    <td><?php echo esc_html($email->time); ?></td>
                </tr>
                <tr>
                    <th><?php _e('To', 'at-agency-manager'); ?></th>
                    <td><?php echo esc_html($email->email_to); ?></td>
                </tr>
                <tr>
                    <th><?php _e('Subject', 'at-agency-manager'); ?></th>
                    <td><?php echo esc_html($email->subject); ?></td>
                </tr>
                <tr>
                    <th><?php _e('Headers', 'at-agency-manager'); ?></th>
                    <td><pre><?php echo esc_html($email->headers); ?></pre></td>
                </tr>
                <tr>
                    <th><?php _e('Status', 'at-agency-manager'); ?></th>
                    <td>
                        <?php if ($email->status === 'sent') : ?>
                            <span class="email-status email-status-sent"><?php _e('Sent', 'at-agency-manager'); ?></span>
                        <?php else : ?>
                            <span class="email-status email-status-failed"><?php _e('Failed', 'at-agency-manager'); ?></span>
                            <p class="error-message"><?php echo esc_html($email->error_message); ?></p>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php if (!empty($email->attachments)) : ?>
                <tr>
                    <th><?php _e('Attachments', 'at-agency-manager'); ?></th>
                    <td>
                        <ul>
                            <?php foreach (explode("\n", $email->attachments) as $attachment) : ?>
                                <li><?php echo esc_html($attachment); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </td>
                </tr>
                <?php endif; ?>
            </table>
            
            <h3><?php _e('Message Content', 'at-agency-manager'); ?></h3>
            <div class="email-content">
                <?php if (strpos($email->message, '<!DOCTYPE') !== false || strpos($email->message, '<html') !== false) : ?>
                    <iframe id="email-html-frame" style="width:100%; height:300px; border:1px solid #ddd;"></iframe>
                    <script>
                        jQuery(document).ready(function($) {
                            var iframe = document.getElementById('email-html-frame');
                            var iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                            iframeDoc.open();
                            iframeDoc.write(<?php echo json_encode($email->message); ?>);
                            iframeDoc.close();
                        });
                    </script>
                <?php else : ?>
                    <pre style="white-space: pre-wrap;"><?php echo esc_html($email->message); ?></pre>
                <?php endif; ?>
            </div>
        </div>
        <?php
        $html = ob_get_clean();
        
        wp_send_json_success(array('html' => $html));
    }
}

// אתחול המודול אם מופעל בהגדרות
$modules = get_option('at_agency_manager_modules', []);
if (!empty($modules['email_log'])) {
    global $at_email_log_instance;
    $at_email_log_instance = new AT_Email_Log();
} 