jQuery(document).ready(function($) {
    // Check if atShortLinks is defined
    if (typeof atShortLinks === 'undefined') {
        console.error('atShortLinks is not defined');
        return;
    }
    
    console.log('AT Short Links Admin JS loaded');
    console.log('atShortLinks object:', atShortLinks);

    // טעינת קישורים
    function loadLinks() {
        $.ajax({
            url: atShortLinks.ajaxUrl,
            type: 'POST',
            data: {
                action: 'at_short_links_get_all',
                nonce: atShortLinks.nonce
            },
            success: function(response) {
                if (response.success) {
                    renderLinks(response.data);
                    $('#at-short-links-loading').hide();
                    $('#at-short-links-table').show();
                }
            }
        });
    }
    
    // רינדור קישורים
    function renderLinks(links) {
        var tbody = $('#at-short-links-tbody');
        tbody.empty();
        
        if (links.length === 0) {
            tbody.append('<tr><td colspan="7" style="text-align: center;">No short links found.</td></tr>');
            return;
        }
        
        links.forEach(function(link) {
            var row = $('<tr>');
            row.append('<td><a href="' + link.short_url + '" target="_blank">' + link.short_url + '</a></td>');
            row.append('<td><a href="' + link.original_url + '" target="_blank">' + link.original_url.substring(0, 50) + '...</a></td>');
            row.append('<td>' + (link.post_title || 'Manual link') + '</td>');
            row.append('<td>' + link.clicks + '</td>');
            row.append('<td>' + new Date(link.created_at).toLocaleString() + '</td>');
            row.append('<td><button type="button" class="button button-small at-view-qr-btn" data-link-id="' + link.id + '">View QR</button></td>');
            row.append('<td><button type="button" class="button button-small at-delete-link-btn" data-link-id="' + link.id + '">Delete</button></td>');
            tbody.append(row);
        });
    }
    
    // יצירת קישור חדש - באמצעות כפתור בלבד (לא submit)
    var $createBtn = $('#at-create-link-btn');
    
    if ($createBtn.length === 0) {
        console.error('Create button not found!');
    } else {
        console.log('Create button found, attaching click handler');
        
        $createBtn.on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            console.log('Create button clicked');
            
            var url = $('#at_new_link_url').val();
            var postId = $('#at_new_link_post').val();
            
            console.log('URL:', url, 'Post ID:', postId);
            
            if (!url && !postId) {
                alert('Please enter a URL or select a post/page.');
                return false;
            }
            
            // Disable button to prevent double submission
            var $btn = $(this);
            var originalText = $btn.text();
            $btn.prop('disabled', true).text('Creating...');
            
            console.log('Sending AJAX request...');
            
            $.ajax({
                url: atShortLinks.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'at_short_links_create',
                    nonce: atShortLinks.nonce,
                    url: url,
                    post_id: postId
                },
            success: function(response) {
                console.log('AJAX Success:', response);
                if (response.success) {
                    $('#at_new_link_url').val('');
                    $('#at_new_link_post').val('');
                    loadLinks();
                    alert(atShortLinks.strings.success || 'Short link created successfully!');
                } else {
                    var errorMsg = response.data && response.data.message ? response.data.message : atShortLinks.strings.error;
                    console.error('AJAX returned success:false. Error message:', errorMsg);
                    alert('Error: ' + errorMsg);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', error);
                console.error('Status:', status);
                console.error('Response:', xhr.responseText);
                var errorMsg = 'An error occurred. Please try again.';
                try {
                    var response = JSON.parse(xhr.responseText);
                    if (response.data && response.data.message) {
                        errorMsg = response.data.message;
                    }
                } catch (e) {
                    console.error('Failed to parse error response:', e);
                }
                alert('Error: ' + errorMsg);
            },
                complete: function() {
                    // Re-enable button
                    $btn.prop('disabled', false).text(originalText);
                }
            });
            
            return false;
        });
    }
    
    // גם אפשרות לשלוח עם Enter (אבל רק דרך AJAX)
    $('#at-create-short-link-form').on('submit', function(e) {
        e.preventDefault();
        e.stopPropagation();
        console.log('Form submitted, triggering button click');
        $('#at-create-link-btn').trigger('click');
        return false;
    });
    
    // מחיקת קישור
    $(document).on('click', '.at-delete-link-btn', function() {
        if (!confirm(atShortLinks.strings.confirmDelete)) {
            return;
        }
        
        var linkId = $(this).data('link-id');
        
        $.ajax({
            url: atShortLinks.ajaxUrl,
            type: 'POST',
            data: {
                action: 'at_short_links_delete',
                nonce: atShortLinks.nonce,
                link_id: linkId
            },
            success: function(response) {
                if (response.success) {
                    loadLinks();
                } else {
                    alert(response.data.message || atShortLinks.strings.error);
                }
            }
        });
    });
    
    // צפייה ב-QR
    $(document).on('click', '.at-view-qr-btn', function() {
        var linkId = $(this).data('link-id');
        var $btn = $(this);
        var originalText = $btn.text();
        
        $btn.prop('disabled', true).text('Generating...');
        $('#at-qr-modal').show();
        $('#at-qr-modal-content').html('<div style="text-align: center;"><span class="spinner is-active"></span><p>Generating QR code, please wait...</p></div>');
        
        $.ajax({
            url: atShortLinks.ajaxUrl,
            type: 'POST',
            timeout: 120000, // 2 דקות
            data: {
                action: 'at_short_links_get_qr',
                nonce: atShortLinks.nonce,
                link_id: linkId,
                force_regenerate: false // לא לכפות יצירה מחדש - להשתמש בקובץ קיים אם יש
            },
            success: function(response) {
                $btn.prop('disabled', false).text(originalText);
                if (response.success) {
                    // הוספת timestamp כדי למנוע cache
                    var qrUrl = response.data.qr_url + (response.data.qr_url.indexOf('?') > -1 ? '&' : '?') + 't=' + Date.now();
                    $('#at-qr-modal-content').html('<img src="' + qrUrl + '" style="max-width: 100%;" onerror="this.parentElement.innerHTML=\'<p>Failed to load QR code image. Please try again.</p>\';" />');
                    $('#at-qr-download-btn').data('link-id', linkId);
                } else {
                    $('#at-qr-modal-content').html('<p style="color: red;">' + (response.data.message || atShortLinks.strings.error) + '</p>');
                }
            },
            error: function(xhr, status, error) {
                $btn.prop('disabled', false).text(originalText);
                var errorMsg = 'An error occurred while generating QR code.';
                if (status === 'timeout') {
                    errorMsg = 'Request timed out. The QR code generation is taking too long. Please try again.';
                } else if (xhr.responseText) {
                    try {
                        var response = JSON.parse(xhr.responseText);
                        if (response.data && response.data.message) {
                            errorMsg = response.data.message;
                        }
                    } catch (e) {
                        console.error('Failed to parse error response:', e);
                    }
                }
                $('#at-qr-modal-content').html('<p style="color: red;">' + errorMsg + '</p>');
                console.error('AJAX Error:', error, 'Status:', status);
            }
        });
    });
    
    // סגירת modal
    $('#at-qr-close-btn, #at-qr-modal').on('click', function(e) {
        if (e.target === this) {
            $('#at-qr-modal').hide();
        }
    });
    
    // הורדת QR
    $('#at-qr-download-btn').on('click', function() {
        var linkId = $(this).data('link-id');
        if (linkId) {
            window.location.href = atShortLinks.ajaxUrl + '?action=at_short_links_download_qr&nonce=' + atShortLinks.nonce + '&link_id=' + linkId;
        }
    });
    
    // העלאת לוגו
    var mediaUploader;
    $('.at-upload-logo-btn').on('click', function(e) {
        e.preventDefault();
        
        if (mediaUploader) {
            mediaUploader.open();
            return;
        }
        
        mediaUploader = wp.media({
            title: 'Choose QR Code Logo',
            button: {
                text: 'Use this logo'
            },
            multiple: false
        });
        
        mediaUploader.on('select', function() {
            var attachment = mediaUploader.state().get('selection').first().toJSON();
            // Save attachment ID instead of URL
            $('#at_short_links_qr_logo').val(attachment.id);
            
            var preview = $('.at-qr-logo-preview');
            preview.html('<img src="' + attachment.url + '" alt="QR Logo" style="max-width: 150px; max-height: 150px; border: 1px solid #ddd; padding: 5px;" />');
            $('.at-remove-logo-btn').show();
        });
        
        mediaUploader.open();
    });
    
    // הסרת לוגו
    $('.at-remove-logo-btn').on('click', function() {
        $('#at_short_links_qr_logo').val('');
        $('.at-qr-logo-preview').empty();
        $(this).hide();
    });
    
    // בדיקת הדומיין המקוצר
    $('.at-verify-short-domain').on('click', function() {
        var $btn = $(this);
        var $result = $('.at-verify-short-domain-result');

        $btn.prop('disabled', true);
        $result.text('בודק...').css('color', '');

        $.post(atShortLinks.ajaxUrl, {
            action: 'at_short_links_verify_domain',
            nonce: atShortLinks.nonce
        }).done(function(response) {
            var data = (response && response.data) ? response.data : {};
            var ok = !!(response && response.success);
            $result.text(data.message || (ok ? 'תקין' : atShortLinks.strings.error))
                   .css('color', ok ? '#1e7e34' : '#b32d2e');
        }).fail(function() {
            $result.text(atShortLinks.strings.error).css('color', '#b32d2e');
        }).always(function() {
            $btn.prop('disabled', false);
        });
    });

    // טעינה ראשונית
    if ($('#at-short-links-table').length > 0) {
        loadLinks();
    }
    
    // Debug: בדיקה שהכל נטען
    console.log('All event handlers attached');
    console.log('Create button exists:', $('#at-create-link-btn').length > 0);
    console.log('Form exists:', $('#at-create-short-link-form').length > 0);
});