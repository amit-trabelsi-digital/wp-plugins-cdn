<?php
if (!defined('ABSPATH')) exit;

$shortener = AT_Url_Shortener::get_instance();
$domain = get_option('at_short_links_domain', home_url());
?>

<div class="wrap at-short-links-wrap">
    <h1><?php _e('Short Links Manager', 'at-agency-manager'); ?></h1>
    
    <!-- הגדרות כלליות -->
    <div class="at-short-links-settings" style="background: #fff; padding: 20px; margin: 20px 0; border: 1px solid #ccd0d4; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
        <h2><?php _e('Settings', 'at-agency-manager'); ?></h2>
        <form method="post" action="options.php">
            <?php settings_fields('at_short_links_settings'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="at_short_links_domain"><?php _e('Short Domain', 'at-agency-manager'); ?></label>
                    </th>
                    <td>
                        <input type="url" 
                               id="at_short_links_domain" 
                               name="at_short_links_domain" 
                               value="<?php echo esc_attr($domain); ?>" 
                               class="regular-text" 
                               placeholder="<?php echo esc_attr(home_url()); ?>" />
                        <p class="description">
                            <?php _e('The base domain for short links. Default: site URL', 'at-agency-manager'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="at_short_links_qr_logo"><?php _e('QR Code Logo', 'at-agency-manager'); ?></label>
                    </th>
                    <td>
                        <?php
                        $qr_logo_id = get_option('at_short_links_qr_logo');
                        $logo_url = '';
                        if ($qr_logo_id) {
                            // אם זה מספר, זה attachment ID
                            if (is_numeric($qr_logo_id)) {
                                $logo_url = wp_get_attachment_image_url($qr_logo_id, 'medium');
                            } else {
                                // תאימות לאחור - אם זה URL או path ישן
                                if (filter_var($qr_logo_id, FILTER_VALIDATE_URL)) {
                                    $logo_url = $qr_logo_id;
                                } else {
                                    $upload_dir = wp_upload_dir();
                                    $logo_url = $upload_dir['baseurl'] . '/' . $qr_logo_id;
                                }
                            }
                        }
                        ?>
                        <div class="at-qr-logo-preview" style="margin-bottom: 10px;">
                            <?php if ($logo_url): ?>
                                <img src="<?php echo esc_url($logo_url); ?>" 
                                     alt="QR Logo" 
                                     style="max-width: 150px; max-height: 150px; border: 1px solid #ddd; padding: 5px;" />
                            <?php endif; ?>
                        </div>
                        <input type="hidden" 
                               id="at_short_links_qr_logo" 
                               name="at_short_links_qr_logo" 
                               value="<?php echo esc_attr($qr_logo_id); ?>" />
                        <button type="button" 
                                class="button at-upload-logo-btn">
                            <?php _e('Upload Logo', 'at-agency-manager'); ?>
                        </button>
                        <button type="button" 
                                class="button at-remove-logo-btn" 
                                style="<?php echo $qr_logo_id ? '' : 'display:none;'; ?>">
                            <?php _e('Remove Logo', 'at-agency-manager'); ?>
                        </button>
                        <p class="description">
                            <?php _e('Upload a logo to be displayed in the center of QR codes. If not set, the site logo will be used.', 'at-agency-manager'); ?>
                        </p>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    
    <!-- יצירת קישור חדש -->
    <div class="at-short-links-create" style="background: #fff; padding: 20px; margin: 20px 0; border: 1px solid #ccd0d4; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
        <h2><?php _e('Create New Short Link', 'at-agency-manager'); ?></h2>
        <form id="at-create-short-link-form">
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="at_new_link_url"><?php _e('URL', 'at-agency-manager'); ?></label>
                    </th>
                    <td>
                        <input type="url" 
                               id="at_new_link_url" 
                               name="url" 
                               class="regular-text" 
                               placeholder="https://example.com/page" />
                        <p class="description">
                            <?php _e('Enter the full URL to shorten', 'at-agency-manager'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="at_new_link_post"><?php _e('Or Select Post/Page', 'at-agency-manager'); ?></label>
                    </th>
                    <td>
                        <select id="at_new_link_post" name="post_id" class="regular-text">
                            <option value=""><?php _e('-- Select Post/Page --', 'at-agency-manager'); ?></option>
                            <?php
                            $posts = get_posts(array(
                                'post_type' => array('post', 'page'),
                                'posts_per_page' => -1,
                                'orderby' => 'title',
                                'order' => 'ASC'
                            ));
                            foreach ($posts as $post) {
                                echo '<option value="' . esc_attr($post->ID) . '">' . esc_html($post->post_title) . ' (' . esc_html($post->post_type) . ')</option>';
                            }
                            ?>
                        </select>
                    </td>
                </tr>
            </table>
            <p class="submit">
                <button type="button" id="at-create-link-btn" class="button button-primary">
                    <?php _e('Create Short Link', 'at-agency-manager'); ?>
                </button>
            </p>
        </form>
    </div>
    
    <!-- רשימת קישורים -->
    <div class="at-short-links-list" style="background: #fff; padding: 20px; margin: 20px 0; border: 1px solid #ccd0d4; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
        <h2><?php _e('All Short Links', 'at-agency-manager'); ?></h2>
        <div id="at-short-links-loading" style="text-align: center; padding: 20px;">
            <span class="spinner is-active"></span>
            <?php _e('Loading...', 'at-agency-manager'); ?>
        </div>
        <table class="wp-list-table widefat fixed striped" id="at-short-links-table" style="display: none;">
            <thead>
                <tr>
                    <th><?php _e('Short URL', 'at-agency-manager'); ?></th>
                    <th><?php _e('Original URL', 'at-agency-manager'); ?></th>
                    <th><?php _e('Post/Page', 'at-agency-manager'); ?></th>
                    <th><?php _e('Clicks', 'at-agency-manager'); ?></th>
                    <th><?php _e('Created', 'at-agency-manager'); ?></th>
                    <th><?php _e('QR Code', 'at-agency-manager'); ?></th>
                    <th><?php _e('Actions', 'at-agency-manager'); ?></th>
                </tr>
            </thead>
            <tbody id="at-short-links-tbody">
                <!-- יטען דרך AJAX -->
            </tbody>
        </table>
    </div>
</div>

<!-- Modal ל-QR Code -->
<div id="at-qr-modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); z-index: 100000;">
    <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: #fff; padding: 20px; border-radius: 5px; max-width: 500px; width: 90%;">
        <h2 style="margin-top: 0;"><?php _e('QR Code', 'at-agency-manager'); ?></h2>
        <div id="at-qr-modal-content" style="text-align: center; margin: 20px 0;">
            <span class="spinner is-active"></span>
        </div>
        <p style="text-align: center;">
            <button type="button" class="button" id="at-qr-download-btn">
                <?php _e('Download QR Code', 'at-agency-manager'); ?>
            </button>
            <button type="button" class="button" id="at-qr-close-btn">
                <?php _e('Close', 'at-agency-manager'); ?>
            </button>
        </p>
    </div>
</div>
