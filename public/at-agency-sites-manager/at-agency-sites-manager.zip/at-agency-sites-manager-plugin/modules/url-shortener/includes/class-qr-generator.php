<?php
/**
 * מחלקת יצירת QR codes
 * 
 * יוצרת QR codes מעוצבים עם לוגו האתר
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_QR_Generator {
    private $upload_dir;
    private $upload_url;
    
    public function __construct() {
        $upload_dir = wp_upload_dir();
        $this->upload_dir = $upload_dir['basedir'] . '/at-short-links-qr';
        $this->upload_url = $upload_dir['baseurl'] . '/at-short-links-qr';
        
        // יצירת תיקייה אם לא קיימת
        if (!file_exists($this->upload_dir)) {
            wp_mkdir_p($this->upload_dir);
        }
    }
    
    /**
     * יצירת QR code
     */
    public function generate($url, $link_id, $force_regenerate = false) {
        // הגדלת זמן ביצוע
        @set_time_limit(120);
        
        $qr_file = $this->upload_dir . '/qr-' . $link_id . '.png';
        $qr_url = $this->upload_url . '/qr-' . $link_id . '.png';
        
        // אם הקובץ קיים ולא מבקשים יצירה מחדש, נחזיר אותו
        if (file_exists($qr_file) && !$force_regenerate) {
            error_log('[AT QR Generator] Using existing QR file: ' . $qr_file);
            return $qr_url;
        }
        
        // אם מבקשים יצירה מחדש, נמחק את הקובץ הישן
        if ($force_regenerate && file_exists($qr_file)) {
            @unlink($qr_file);
            error_log('[AT QR Generator] Deleted old QR file');
        }
        
        error_log('[AT QR Generator] Generating QR code for link ID: ' . $link_id . ', URL: ' . $url);
        
        // יצירת QR code בסיסי
        $start_time = microtime(true);
        $qr_code = $this->create_qr_code($url);
        $qr_time = microtime(true) - $start_time;
        error_log('[AT QR Generator] QR code creation took: ' . round($qr_time, 2) . ' seconds');
        
        if (!$qr_code) {
            error_log('[AT QR Generator] Failed to create base QR code');
            return false;
        }
        
        // הוספת לוגו אם קיים
        $logo_path = $this->get_logo_path();
        if ($logo_path) {
            error_log('[AT QR Generator] Logo found, adding logo: ' . $logo_path);
            $logo_start = microtime(true);
            $qr_code = $this->add_logo_to_qr($qr_code, $logo_path);
            $logo_time = microtime(true) - $logo_start;
            error_log('[AT QR Generator] Logo addition took: ' . round($logo_time, 2) . ' seconds');
        } else {
            error_log('[AT QR Generator] No logo found');
        }
        
        // שמירת הקובץ
        $save_start = microtime(true);
        $saved = imagepng($qr_code, $qr_file, 9); // רמת דחיסה 9 (0-9, 9 = דחיסה מקסימלית)
        imagedestroy($qr_code);
        $save_time = microtime(true) - $save_start;
        error_log('[AT QR Generator] File save took: ' . round($save_time, 2) . ' seconds');
        
        if (!$saved) {
            error_log('[AT QR Generator] Failed to save QR code file');
            return false;
        }
        
        $total_time = microtime(true) - $start_time;
        error_log('[AT QR Generator] QR code saved successfully: ' . $qr_file . ' (Total time: ' . round($total_time, 2) . ' seconds)');
        
        return $qr_url;
    }
    
    /**
     * יצירת QR code בסיסי
     */
    private function create_qr_code($url) {
        // נשתמש בספריית PHP QR Code אם קיימת, אחרת נשתמש ב-API חיצוני
        if (class_exists('QRcode')) {
            return $this->generate_with_library($url);
        } else {
            return $this->generate_with_api($url);
        }
    }
    
    /**
     * יצירת QR עם ספרייה מקומית (אם מותקנת)
     */
    private function generate_with_library($url) {
        // אם יש ספריית QR code מותקנת, נשתמש בה
        // כאן נשתמש ב-API חיצוני כרגע
        return $this->generate_with_api($url);
    }
    
    /**
     * יצירת QR עם API חיצוני
     */
    private function generate_with_api($url) {
        // הגדלת זמן ביצוע
        @set_time_limit(120);
        
        // שימוש ב-API של qrcode.tec-it.com
        // נשתמש בגודל קטן יותר כדי לזרז את התהליך
        $api_url = 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=' . urlencode($url);
        
        error_log('[AT QR Generator] Fetching QR from API: ' . $api_url);
        
        $response = wp_remote_get($api_url, array(
            'timeout' => 60,
            'sslverify' => true,
            'redirection' => 5
        ));
        
        if (is_wp_error($response)) {
            error_log('[AT QR Generator] API Error: ' . $response->get_error_message());
            return false;
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            error_log('[AT QR Generator] API returned code: ' . $response_code);
            return false;
        }
        
        $body = wp_remote_retrieve_body($response);
        if (empty($body)) {
            error_log('[AT QR Generator] Empty response body');
            return false;
        }
        
        error_log('[AT QR Generator] Response body size: ' . strlen($body) . ' bytes');
        
        $image_data = @imagecreatefromstring($body);
        
        if (!$image_data) {
            error_log('[AT QR Generator] Failed to create image from string');
            return false;
        }
        
        error_log('[AT QR Generator] QR image created successfully');
        
        return $image_data;
    }
    
    /**
     * הוספת לוגו ל-QR
     */
    private function add_logo_to_qr($qr_image, $logo_path) {
        if (!file_exists($logo_path)) {
            error_log('[AT QR Generator] Logo file not found: ' . $logo_path);
            return $qr_image;
        }
        
        // זיהוי סוג הקובץ
        $image_info = getimagesize($logo_path);
        if (!$image_info) {
            error_log('[AT QR Generator] Failed to get image info for: ' . $logo_path);
            return $qr_image;
        }
        
        $mime_type = $image_info['mime'];
        $logo = false;
        
        // יצירת תמונה לפי סוג הקובץ
        switch ($mime_type) {
            case 'image/png':
                $logo = imagecreatefrompng($logo_path);
                break;
            case 'image/jpeg':
            case 'image/jpg':
                $logo = imagecreatefromjpeg($logo_path);
                break;
            case 'image/gif':
                $logo = imagecreatefromgif($logo_path);
                break;
            default:
                error_log('[AT QR Generator] Unsupported image type: ' . $mime_type);
                return $qr_image;
        }
        
        if (!$logo) {
            error_log('[AT QR Generator] Failed to create image from: ' . $logo_path);
            return $qr_image;
        }
        
        $qr_width = imagesx($qr_image);
        $qr_height = imagesy($qr_image);
        
        $logo_width = imagesx($logo);
        $logo_height = imagesy($logo);
        
        // גודל הלוגו יהיה 20% מגודל ה-QR
        $logo_size = (int)(min($qr_width, $qr_height) * 0.2);
        $logo_x = (int)(($qr_width - $logo_size) / 2);
        $logo_y = (int)(($qr_height - $logo_size) / 2);
        
        // שינוי גודל הלוגו תוך שמירה על יחס הגובה-רוחב
        $aspect_ratio = $logo_width / $logo_height;
        $new_width = $logo_size;
        $new_height = $logo_size;
        
        if ($aspect_ratio > 1) {
            // רוחב גדול יותר
            $new_height = (int)($logo_size / $aspect_ratio);
        } else {
            // גובה גדול יותר
            $new_width = (int)($logo_size * $aspect_ratio);
        }
        
        // יצירת לוגו מוקטן
        $resized_logo = imagecreatetruecolor($new_width, $new_height);
        imagealphablending($resized_logo, false);
        imagesavealpha($resized_logo, true);
        
        // יצירת רקע שקוף
        $transparent = imagecolorallocatealpha($resized_logo, 255, 255, 255, 127);
        imagefill($resized_logo, 0, 0, $transparent);
        
        // העתקת הלוגו עם שקיפות
        imagealphablending($resized_logo, true);
        imagecopyresampled(
            $resized_logo, $logo,
            0, 0, 0, 0,
            $new_width, $new_height,
            $logo_width, $logo_height
        );
        imagealphablending($resized_logo, false);
        imagesavealpha($resized_logo, true);
        
        // יצירת רקע לבן סביב הלוגו
        $white_bg = imagecreatetruecolor($logo_size, $logo_size);
        $white = imagecolorallocate($white_bg, 255, 255, 255);
        imagefill($white_bg, 0, 0, $white);
        
        // חישוב מיקום הלוגו במרכז הרקע הלבן
        $logo_offset_x = (int)(($logo_size - $new_width) / 2);
        $logo_offset_y = (int)(($logo_size - $new_height) / 2);
        
        // העתקת הלוגו על הרקע הלבן
        imagecopy($white_bg, $resized_logo, $logo_offset_x, $logo_offset_y, 0, 0, $new_width, $new_height);
        
        // הוספת הלוגו עם הרקע הלבן ל-QR
        imagecopy($qr_image, $white_bg, $logo_x, $logo_y, 0, 0, $logo_size, $logo_size);
        
        imagedestroy($logo);
        imagedestroy($resized_logo);
        imagedestroy($white_bg);
        
        error_log('[AT QR Generator] Logo added successfully to QR');
        
        return $qr_image;
    }
    
    /**
     * קבלת נתיב לוגו
     */
    private function get_logo_path() {
        // בדיקה אם יש לוגו מותאם אישית
        $custom_logo = get_option('at_short_links_qr_logo');
        if ($custom_logo) {
            // אם זה מספר, זה attachment ID
            if (is_numeric($custom_logo)) {
                $logo_path = get_attached_file($custom_logo);
                if ($logo_path && file_exists($logo_path)) {
                    return $logo_path;
                }
            } else {
                // תאימות לאחור - אם זה URL או path ישן
                if (filter_var($custom_logo, FILTER_VALIDATE_URL)) {
                    // אם זה URL, ננסה להמיר לנתיב
                    $upload_dir = wp_upload_dir();
                    $url_path = str_replace($upload_dir['baseurl'], '', $custom_logo);
                    $logo_path = $upload_dir['basedir'] . $url_path;
                    if (file_exists($logo_path)) {
                        return $logo_path;
                    }
                } else {
                    // אם זה path יחסי
                    $upload_dir = wp_upload_dir();
                    $logo_path = $upload_dir['basedir'] . '/' . $custom_logo;
                    if (file_exists($logo_path)) {
                        return $logo_path;
                    }
                }
            }
        }
        
        // בדיקה אם יש לוגו של האתר
        $site_logo = get_option('clients_logo_file');
        if ($site_logo) {
            $upload_dir = wp_upload_dir();
            $logo_path = $upload_dir['basedir'] . '/' . $site_logo;
            if (file_exists($logo_path)) {
                return $logo_path;
            }
        }
        
        // בדיקה אם יש custom logo ב-WordPress
        $custom_logo_id = get_theme_mod('custom_logo');
        if ($custom_logo_id) {
            $logo_path = get_attached_file($custom_logo_id);
            if ($logo_path && file_exists($logo_path)) {
                return $logo_path;
            }
        }
        
        return false;
    }
    
    /**
     * הורדת QR code
     */
    public function download($url, $link_id) {
        $qr_url = $this->generate($url, $link_id);
        
        if (!$qr_url) {
            wp_die(__('Failed to generate QR code.', 'at-agency-manager'));
        }
        
        $qr_file = $this->upload_dir . '/qr-' . $link_id . '.png';
        
        if (!file_exists($qr_file)) {
            wp_die(__('QR code file not found.', 'at-agency-manager'));
        }
        
        header('Content-Type: image/png');
        header('Content-Disposition: attachment; filename="qr-code-' . $link_id . '.png"');
        header('Content-Length: ' . filesize($qr_file));
        
        readfile($qr_file);
        exit;
    }
}
