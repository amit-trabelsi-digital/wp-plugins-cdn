<?php
/**
 * מחלקת קיצור כתובות
 * 
 * מנהלת יצירת קישורים מקוצרים אוטומטית לכל פוסט/עמוד
 * כולל QR codes מעוצבים
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Url_Shortener {
    private static $instance = null;
    private $table_name;
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'at_short_links';
        
        // וידוא שהטבלה קיימת
        $this->ensure_table_exists();
        
        // הוספת rewrite rules
        add_action('init', array($this, 'add_rewrite_rules'));
        add_filter('query_vars', array($this, 'add_query_vars'));
        
        // Hook אוטומטי ליצירת קישור מקוצר
        add_action('save_post', array($this, 'auto_create_short_link'), 10, 2);
        
        // Handler לניתוב קישורים מקוצרים
        add_action('template_redirect', array($this, 'handle_short_link_redirect'));
        
        // AJAX handlers
        add_action('wp_ajax_at_short_links_get_all', array($this, 'ajax_get_all_links'));
        add_action('wp_ajax_at_short_links_create', array($this, 'ajax_create_link'));
        add_action('wp_ajax_at_short_links_delete', array($this, 'ajax_delete_link'));
        add_action('wp_ajax_at_short_links_get_qr', array($this, 'ajax_get_qr'));
        add_action('wp_ajax_at_short_links_download_qr', array($this, 'ajax_download_qr'));
        
        // Admin page - priority 20 כדי שירוץ אחרי יצירת התפריט הראשי
        add_action('admin_menu', array($this, 'add_admin_menu'), 20);
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        
        // Hook לבדיקת הרשאות לפני user_can_access_admin_page
        add_filter('user_has_cap', array($this, 'check_short_links_access'), 10, 4);
        
        // Metabox בעריכת פוסטים
        add_action('add_meta_boxes', array($this, 'add_short_link_metabox'));
        
        // Hook להחזרת לינק מקוצר במידע על פוסט
        add_filter('get_post_metadata', array($this, 'add_short_link_to_post_meta'), 10, 4);
        add_action('rest_api_init', array($this, 'add_short_link_to_rest_api'));
        
        // Hook כללי להחזרת לינק מקוצר
        add_filter('at_get_post_short_link', array($this, 'get_short_link_for_post'), 10, 2);
        add_filter('at_get_item_short_link', array($this, 'get_short_link_for_item'), 10, 2);
    }
    
    /**
     * Flush rewrite rules (called on activation)
     */
    public static function flush_rewrite_rules_on_activation() {
        $instance = self::get_instance();
        $instance->add_rewrite_rules();
        flush_rewrite_rules();
    }
    
    /**
     * יצירת קישור מקוצר אוטומטית
     */
    public function auto_create_short_link($post_id, $post) {
        // בדיקה אם המודול מופעל
        $modules = get_option('at_agency_manager_modules', []);
        if (empty($modules['url_shortener'])) {
            return;
        }
        
        // בדיקה אם זה פוסט/עמוד/וכו' שצריך קישור
        if (!in_array($post->post_type, array('post', 'page'))) {
            return;
        }
        
        // בדיקה אם כבר יש קישור מקוצר
        $existing = $this->get_link_by_post_id($post_id);
        if ($existing) {
            return;
        }
        
        // יצירת קישור מקוצר
        $url = get_permalink($post_id);
        $this->create_short_link($post_id, $url);
    }
    
    /**
     * וידוא שהטבלה קיימת
     */
    private function ensure_table_exists() {
        global $wpdb;
        
        $table_name = $this->table_name;
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'") === $table_name;
        
        if (!$table_exists) {
            error_log('[AT URL Shortener] Table does not exist, creating it...');
            $this->create_table();
        }
    }
    
    /**
     * יצירת טבלת קישורים מקוצרים
     */
    private function create_table() {
        global $wpdb;
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        $charset_collate = $wpdb->get_charset_collate();
        $table_name = $this->table_name;
        
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            post_id bigint(20) unsigned DEFAULT NULL,
            hash varchar(20) NOT NULL,
            original_url text NOT NULL,
            short_url varchar(255) NOT NULL,
            clicks int(11) NOT NULL DEFAULT 0,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            created_by bigint(20) unsigned DEFAULT NULL,
            is_manual tinyint(1) NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            UNIQUE KEY hash (hash),
            KEY idx_post_id (post_id),
            KEY idx_created_at (created_at),
            KEY idx_created_by (created_by)
        ) $charset_collate;";
        
        dbDelta($sql);
        
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'") === $table_name;
        if ($table_exists) {
            error_log('[AT URL Shortener] Table created successfully');
        } else {
            error_log('[AT URL Shortener] ERROR: Failed to create table. Last error: ' . $wpdb->last_error);
        }
    }
    
    /**
     * יצירת קישור מקוצר
     */
    public function create_short_link($post_id = null, $url = null, $is_manual = false) {
        global $wpdb;
        
        // וידוא שהטבלה קיימת לפני יצירת קישור
        $this->ensure_table_exists();
        
        error_log('[AT URL Shortener] create_short_link called with post_id=' . $post_id . ', url=' . $url . ', is_manual=' . ($is_manual ? 'true' : 'false'));
        
        // בדיקה אם יש כבר קישור עבור post_id זה (אם לא manual)
        if ($post_id && !$is_manual) {
            $existing = $this->get_link_by_post_id($post_id);
            if ($existing) {
                error_log('[AT URL Shortener] Link already exists for post_id ' . $post_id . ', returning existing ID: ' . $existing->id);
                return $existing->id;
            }
        }
        
        // יצירת hash ייחודי
        $hash = $this->generate_unique_hash();
        error_log('[AT URL Shortener] Generated hash: ' . $hash);
        
        // קביעת URL
        $final_url = $url ? $url : ($post_id ? get_permalink($post_id) : '');
        if (empty($final_url)) {
            error_log('[AT URL Shortener] ERROR: No URL provided and cannot get permalink');
            return false;
        }
        
        error_log('[AT URL Shortener] Final URL: ' . $final_url);
        
        // יצירת short URL
        $short_url = $this->get_short_url($hash);
        error_log('[AT URL Shortener] Short URL: ' . $short_url);
        
        // הכנת נתונים להכנסה
        $data = array(
            'post_id' => $post_id,
            'hash' => $hash,
            'original_url' => $final_url,
            'short_url' => $short_url,
            'created_by' => get_current_user_id(),
            'is_manual' => $is_manual ? 1 : 0
        );
        
        error_log('[AT URL Shortener] Data to insert: ' . print_r($data, true));
        error_log('[AT URL Shortener] Table name: ' . $this->table_name);
        
        // שמירת הקישור
        $result = $wpdb->insert(
            $this->table_name,
            $data,
            array('%d', '%s', '%s', '%s', '%d', '%d')
        );
        
        error_log('[AT URL Shortener] Insert result: ' . ($result ? 'success' : 'failed'));
        
        if ($result) {
            $insert_id = $wpdb->insert_id;
            error_log('[AT URL Shortener] Insert ID: ' . $insert_id);
            return $insert_id;
        } else {
            error_log('[AT URL Shortener] Insert failed. Last error: ' . $wpdb->last_error);
            error_log('[AT URL Shortener] Last query: ' . $wpdb->last_query);
            return false;
        }
    }
    
    /**
     * יצירת hash ייחודי
     */
    private function generate_unique_hash($length = 8) {
        global $wpdb;
        
        $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $max_attempts = 100;
        $attempt = 0;
        
        do {
            $hash = '';
            for ($i = 0; $i < $length; $i++) {
                $hash .= $characters[wp_rand(0, strlen($characters) - 1)];
            }
            
            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$this->table_name} WHERE hash = %s",
                $hash
            ));
            
            $attempt++;
        } while ($exists && $attempt < $max_attempts);
        
        if ($attempt >= $max_attempts) {
            // אם לא מצאנו hash ייחודי, ננסה עם hash ארוך יותר
            return $this->generate_unique_hash($length + 1);
        }
        
        return $hash;
    }
    
    /**
     * קבלת URL מקוצר
     */
    public function get_short_url($hash) {
        $domain = get_option('at_short_links_domain', home_url());
        $domain = rtrim($domain, '/');
        return $domain . '/s/' . $hash;
    }
    
    /**
     * קבלת קישור לפי post_id
     */
    public function get_link_by_post_id($post_id) {
        global $wpdb;
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE post_id = %d LIMIT 1",
            $post_id
        ));
    }
    
    /**
     * קבלת קישור לפי hash
     */
    public function get_link_by_hash($hash) {
        global $wpdb;
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE hash = %s LIMIT 1",
            $hash
        ));
    }
    
    /**
     * הוספת rewrite rules
     */
    public function add_rewrite_rules() {
        add_rewrite_rule('^s/([a-zA-Z0-9]+)/?$', 'index.php?at_short_link=$matches[1]', 'top');
    }
    
    /**
     * הוספת query vars
     */
    public function add_query_vars($vars) {
        $vars[] = 'at_short_link';
        return $vars;
    }
    
    /**
     * ניתוב קישורים מקוצרים
     */
    public function handle_short_link_redirect() {
        // בדיקה ישירה מול REQUEST_URI ללא תלות ב-Rewrite Rules
        $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
        $path = parse_url($request_uri, PHP_URL_PATH);
        
        // תמיכה בנתיב /s/xxxx או ישירות /xxxx אם זה דומיין מקוצר ייעודי
        $hash = '';
        
        if (preg_match('#^/s/([a-zA-Z0-9]+)$#', $path, $matches)) {
            $hash = $matches[1];
        } else {
            // בדיקה אם הדומיין הנוכחי הוא הדומיין המקוצר
            $current_host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
            $short_domain_url = get_option('at_short_links_domain');
            
            if ($short_domain_url) {
                $short_host = parse_url($short_domain_url, PHP_URL_HOST);
                if ($short_host && $current_host === $short_host) {
                    // אם זה דומיין מקוצר, כל נתיב יכול להיות hash
                    $hash = trim($path, '/');
                }
            }
        }
        
        // אם לא מצאנו hash בשיטה הישירה, נבדוק ב-query var (גיבוי)
        if (!$hash) {
            $hash = get_query_var('at_short_link');
        }
        
        if (!$hash) {
            return;
        }
        
        $link = $this->get_link_by_hash($hash);
        
        if ($link) {
            // עדכון מספר הקליקים
            global $wpdb;
            $wpdb->query($wpdb->prepare(
                "UPDATE {$this->table_name} SET clicks = clicks + 1 WHERE id = %d",
                $link->id
            ));
            
            // ניתוב ל-URL המקורי
            $redirect_url = $link->original_url;
            
            // אם יש post_id, נשתמש ב-get_permalink כדי לקבל את ה-URL המעודכן
            if ($link->post_id) {
                $permalink = get_permalink($link->post_id);
                if ($permalink) {
                    $redirect_url = $permalink;
                }
            }
            
            wp_redirect($redirect_url, 301);
            exit;
        } else {
            // אם זה דומיין מקוצר ולא מצאנו קישור - נציג 404 או נפנה לדף הבית של האתר הראשי
            $current_host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
            $short_domain_url = get_option('at_short_links_domain');
            
            if ($short_domain_url) {
                $short_host = parse_url($short_domain_url, PHP_URL_HOST);
                if ($short_host && $current_host === $short_host) {
                    // הפניה לדף הבית של האתר הראשי במקום 404
                    wp_redirect(home_url(), 302);
                    exit;
                }
            }
            
            // קישור לא נמצא - 404 רגיל
            status_header(404);
            nocache_headers();
            if (file_exists(get_template_directory() . '/404.php')) {
                include(get_template_directory() . '/404.php');
            } else {
                wp_die(__('Short link not found.', 'at-agency-manager'), __('404 - Not Found', 'at-agency-manager'), array('response' => 404));
            }
            exit;
        }
    }
    
    /**
     * הוספת תפריט אדמין
     */
    public function add_admin_menu() {
        $modules = get_option('at_agency_manager_modules', []);
        
        if (empty($modules['url_shortener'])) {
            return;
        }
        
        add_submenu_page(
            'at-agency-manager',
            __('Short Links', 'at-agency-manager'),
            __('Short Links', 'at-agency-manager'),
            'manage_options',
            'at-short-links',
            array($this, 'render_admin_page')
        );
    }
    
    /**
     * טעינת assets לממשק אדמין
     */
    public function enqueue_admin_assets($hook) {
        // טעינה בדף ניהול קישורים
        // בדיקה גם עם hook חלופי
        if ($hook === 'at-agency-manager_page_at-short-links' || 
            (isset($_GET['page']) && $_GET['page'] === 'at-short-links')) {
            
            // טעינת media uploader
            wp_enqueue_media();
            
            wp_enqueue_style(
                'at-short-links-admin',
                AT_AGENCY_MANAGER_URL . 'modules/url-shortener/assets/css/admin.css',
                array(),
                AT_AGENCY_MANAGER_VERSION
            );
            
            $script_url = AT_AGENCY_MANAGER_URL . 'modules/url-shortener/assets/js/admin.js';
            
            wp_enqueue_script(
                'at-short-links-admin',
                $script_url,
                array('jquery'),
                AT_AGENCY_MANAGER_VERSION,
                true
            );
            
            // Localize script - רק אחרי שה-script נרשם
            wp_localize_script('at-short-links-admin', 'atShortLinks', array(
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('at_short_links_nonce'),
                'strings' => array(
                    'confirmDelete' => __('Are you sure you want to delete this link?', 'at-agency-manager'),
                    'error' => __('An error occurred. Please try again.', 'at-agency-manager'),
                    'success' => __('Operation completed successfully.', 'at-agency-manager')
                )
            ));
        }
        
        // טעינה בדפי עריכת פוסטים
        if (in_array($hook, array('post.php', 'post-new.php', 'edit.php'))) {
            wp_enqueue_style(
                'at-short-links-metabox',
                AT_AGENCY_MANAGER_URL . 'modules/url-shortener/assets/css/metabox.css',
                array(),
                AT_AGENCY_MANAGER_VERSION
            );
        }
    }
    
    /**
     * בדיקת הרשאות גישה לעמוד
     */
    public function check_short_links_access($allcaps, $caps, $args, $user) {
        // רק אם מבקשים גישה לעמוד שלנו
        if (isset($_GET['page']) && $_GET['page'] === 'at-short-links') {
            // אם המשתמש יכול לשנות הגדרות, הוא יכול לגשת לעמוד
            if (isset($allcaps['manage_options']) && $allcaps['manage_options']) {
                return $allcaps;
            }
            
            // בדיקה אם יש capability אחר שמאפשר גישה
            $required_cap = apply_filters('at_short_links_required_cap', 'manage_options');
            if ($required_cap !== 'manage_options' && isset($allcaps[$required_cap]) && $allcaps[$required_cap]) {
                $allcaps['manage_options'] = true; // זמנית כדי לאפשר גישה
                return $allcaps;
            }
        }
        
        return $allcaps;
    }
    
    /**
     * רינדור דף אדמין
     */
    public function render_admin_page() {
        // בדיקת הרשאות - שימוש ב-capability יותר גמיש
        $required_cap = apply_filters('at_short_links_required_cap', 'manage_options');
        
        if (!current_user_can($required_cap)) {
            wp_die(
                __('You do not have sufficient permissions to access this page.', 'at-agency-manager'),
                __('Permission Denied', 'at-agency-manager'),
                array('response' => 403)
            );
        }
        
        // בדיקה אם המודול מופעל
        $modules = get_option('at_agency_manager_modules', []);
        
        if (empty($modules['url_shortener'])) {
            wp_die(
                __('URL Shortener module is not enabled. Please enable it in Settings.', 'at-agency-manager'),
                __('Module Not Enabled', 'at-agency-manager'),
                array('response' => 403)
            );
        }
        
        // בדיקה אם הקובץ קיים
        $template_file = AT_AGENCY_MANAGER_PATH . 'modules/url-shortener/templates/admin-page.php';
        
        if (!file_exists($template_file)) {
            wp_die(
                __('Template file not found.', 'at-agency-manager'),
                __('Error', 'at-agency-manager'),
                array('response' => 500)
            );
        }
        
        include $template_file;
    }
    
    /**
     * AJAX: קבלת כל הקישורים
     */
    public function ajax_get_all_links() {
        check_ajax_referer('at_short_links_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied.', 'at-agency-manager')));
        }
        
        global $wpdb;
        $links = $wpdb->get_results(
            "SELECT * FROM {$this->table_name} ORDER BY created_at DESC"
        );
        
        // הוספת מידע נוסף לכל קישור
        foreach ($links as $link) {
            if ($link->post_id) {
                $post = get_post($link->post_id);
                $link->post_title = $post ? $post->post_title : __('Post not found', 'at-agency-manager');
                $link->post_type = $post ? $post->post_type : '';
            } else {
                $link->post_title = __('Manual link', 'at-agency-manager');
                $link->post_type = '';
            }
        }
        
        wp_send_json_success($links);
    }
    
    /**
     * AJAX: יצירת קישור חדש
     */
    public function ajax_create_link() {
        error_log('[AT URL Shortener] ajax_create_link called');
        error_log('[AT URL Shortener] POST data: ' . print_r($_POST, true));
        
        try {
            check_ajax_referer('at_short_links_nonce', 'nonce');
            error_log('[AT URL Shortener] Nonce check passed');
        } catch (Exception $e) {
            error_log('[AT URL Shortener] Nonce check failed: ' . $e->getMessage());
            wp_send_json_error(array('message' => __('Security check failed.', 'at-agency-manager')));
        }
        
        if (!current_user_can('manage_options')) {
            error_log('[AT URL Shortener] Permission denied for user: ' . get_current_user_id());
            wp_send_json_error(array('message' => __('Permission denied.', 'at-agency-manager')));
        }
        
        $url = isset($_POST['url']) ? esc_url_raw($_POST['url']) : '';
        $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : null;
        
        error_log('[AT URL Shortener] URL: ' . $url);
        error_log('[AT URL Shortener] Post ID: ' . $post_id);
        
        if (empty($url) && !$post_id) {
            error_log('[AT URL Shortener] Both URL and Post ID are empty');
            wp_send_json_error(array('message' => __('URL or Post ID is required.', 'at-agency-manager')));
        }
        
        if ($post_id) {
            $url = get_permalink($post_id);
            error_log('[AT URL Shortener] Got permalink for post ' . $post_id . ': ' . $url);
            
            if (!$url) {
                error_log('[AT URL Shortener] Failed to get permalink for post ' . $post_id);
                wp_send_json_error(array('message' => __('Failed to get permalink for the selected post.', 'at-agency-manager')));
            }
        }
        
        error_log('[AT URL Shortener] Calling create_short_link with post_id=' . $post_id . ', url=' . $url);
        $link_id = $this->create_short_link($post_id, $url, true);
        error_log('[AT URL Shortener] create_short_link returned: ' . ($link_id ? $link_id : 'false'));
        
        if ($link_id) {
            $link = $this->get_link_by_id($link_id);
            error_log('[AT URL Shortener] Link created successfully: ' . print_r($link, true));
            wp_send_json_success($link);
        } else {
            global $wpdb;
            error_log('[AT URL Shortener] Failed to create short link. Last DB error: ' . $wpdb->last_error);
            error_log('[AT URL Shortener] Last DB query: ' . $wpdb->last_query);
            wp_send_json_error(array('message' => __('Failed to create short link. ' . ($wpdb->last_error ? 'DB Error: ' . $wpdb->last_error : ''), 'at-agency-manager')));
        }
    }
    
    /**
     * AJAX: מחיקת קישור
     */
    public function ajax_delete_link() {
        check_ajax_referer('at_short_links_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied.', 'at-agency-manager')));
        }
        
        $link_id = isset($_POST['link_id']) ? intval($_POST['link_id']) : 0;
        
        if (!$link_id) {
            wp_send_json_error(array('message' => __('Invalid link ID.', 'at-agency-manager')));
        }
        
        global $wpdb;
        $result = $wpdb->delete(
            $this->table_name,
            array('id' => $link_id),
            array('%d')
        );
        
        if ($result) {
            wp_send_json_success();
        } else {
            wp_send_json_error(array('message' => __('Failed to delete link.', 'at-agency-manager')));
        }
    }
    
    /**
     * AJAX: קבלת QR code
     */
    public function ajax_get_qr() {
        // הגדלת זמן ביצוע
        @set_time_limit(120);
        
        check_ajax_referer('at_short_links_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied.', 'at-agency-manager')));
        }
        
        $link_id = isset($_POST['link_id']) ? intval($_POST['link_id']) : 0;
        
        if (!$link_id) {
            wp_send_json_error(array('message' => __('Invalid link ID.', 'at-agency-manager')));
        }
        
        $link = $this->get_link_by_id($link_id);
        if (!$link) {
            wp_send_json_error(array('message' => __('Link not found.', 'at-agency-manager')));
        }
        
        error_log('[AT URL Shortener] Generating QR for link ID: ' . $link_id);
        
        // כפיית יצירה מחדש רק אם מבקשים במפורש
        $force_regenerate = isset($_POST['force_regenerate']) ? (bool)$_POST['force_regenerate'] : false;
        
        try {
            $qr_url = $this->generate_qr_code($link->short_url, $link_id, $force_regenerate);
            
            if (!$qr_url) {
                wp_send_json_error(array('message' => __('Failed to generate QR code. Please try again.', 'at-agency-manager')));
            }
            
            wp_send_json_success(array('qr_url' => $qr_url));
        } catch (Exception $e) {
            error_log('[AT URL Shortener] QR generation error: ' . $e->getMessage());
            wp_send_json_error(array('message' => __('Error generating QR code: ', 'at-agency-manager') . $e->getMessage()));
        }
    }
    
    /**
     * AJAX: הורדת QR code
     */
    public function ajax_download_qr() {
        check_ajax_referer('at_short_links_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Permission denied.', 'at-agency-manager'));
        }
        
        $link_id = isset($_GET['link_id']) ? intval($_GET['link_id']) : 0;
        
        if (!$link_id) {
            wp_die(__('Invalid link ID.', 'at-agency-manager'));
        }
        
        $link = $this->get_link_by_id($link_id);
        if (!$link) {
            wp_die(__('Link not found.', 'at-agency-manager'));
        }
        
        $this->download_qr_code($link->short_url, $link_id);
    }
    
    /**
     * קבלת קישור לפי ID
     */
    private function get_link_by_id($id) {
        global $wpdb;
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE id = %d LIMIT 1",
            $id
        ));
    }
    
    /**
     * יצירת QR code
     */
    public function generate_qr_code($url, $link_id, $force_regenerate = false) {
        require_once AT_AGENCY_MANAGER_PATH . 'modules/url-shortener/includes/class-qr-generator.php';
        
        $qr_generator = new AT_QR_Generator();
        return $qr_generator->generate($url, $link_id, $force_regenerate);
    }
    
    /**
     * הורדת QR code
     */
    private function download_qr_code($url, $link_id) {
        require_once AT_AGENCY_MANAGER_PATH . 'modules/url-shortener/includes/class-qr-generator.php';
        
        $qr_generator = new AT_QR_Generator();
        $qr_generator->download($url, $link_id);
    }
    
    /**
     * הוספת metabox בעריכת פוסטים
     */
    public function add_short_link_metabox() {
        // בדיקה אם המודול מופעל
        $modules = get_option('at_agency_manager_modules', []);
        if (empty($modules['url_shortener'])) {
            return;
        }
        
        // הוספת metabox לכל סוגי הפוסטים
        $post_types = get_post_types(array('public' => true), 'names');
        
        foreach ($post_types as $post_type) {
            add_meta_box(
                'at_short_link_metabox',
                __('Short Link', 'at-agency-manager'),
                array($this, 'render_short_link_metabox'),
                $post_type,
                'side',
                'default'
            );
        }
    }
    
    /**
     * רינדור תוכן ה-metabox
     */
    public function render_short_link_metabox($post) {
        // בדיקה אם המודול מופעל
        $modules = get_option('at_agency_manager_modules', []);
        if (empty($modules['url_shortener'])) {
            echo '<p>' . __('URL Shortener module is not enabled.', 'at-agency-manager') . '</p>';
            return;
        }
        
        // קבלת קישור מקוצר
        $link = $this->get_link_by_post_id($post->ID);
        
        // אם אין קישור, נצור אחד
        if (!$link) {
            $url = get_permalink($post->ID);
            if ($url) {
                $link_id = $this->create_short_link($post->ID, $url);
                if ($link_id) {
                    $link = $this->get_link_by_id($link_id);
                }
            }
        }
        
        if (!$link) {
            echo '<p>' . __('Short link will be created automatically when you save this post.', 'at-agency-manager') . '</p>';
            return;
        }
        
        $short_url = $link->short_url;
        $qr_url = $this->generate_qr_code($short_url, $link->id);
        
        wp_nonce_field('at_short_link_metabox', 'at_short_link_metabox_nonce');
        ?>
        <div class="at-short-link-metabox">
            <div style="margin-bottom: 15px;">
                <label for="at_short_link_url" style="display: block; margin-bottom: 5px; font-weight: 600;">
                    <?php _e('Short URL:', 'at-agency-manager'); ?>
                </label>
                <div style="display: flex; gap: 5px;">
                    <input type="text" 
                           id="at_short_link_url" 
                           value="<?php echo esc_attr($short_url); ?>" 
                           readonly 
                           style="flex: 1; font-family: monospace; font-size: 12px;" />
                    <button type="button" 
                            class="button button-small at-copy-short-link" 
                            data-url="<?php echo esc_attr($short_url); ?>"
                            title="<?php esc_attr_e('Copy to clipboard', 'at-agency-manager'); ?>">
                        <span class="dashicons dashicons-clipboard" style="margin-top: 3px;"></span>
                    </button>
                </div>
                <p class="description" style="margin-top: 5px; font-size: 11px;">
                    <?php printf(__('Clicks: %d', 'at-agency-manager'), $link->clicks); ?>
                </p>
            </div>
            
            <?php if ($qr_url): ?>
            <div style="margin-bottom: 15px; text-align: center; padding: 15px; background: #f9f9f9; border: 1px solid #ddd; border-radius: 4px;">
                <label style="display: block; margin-bottom: 10px; font-weight: 600;">
                    <?php _e('QR Code:', 'at-agency-manager'); ?>
                </label>
                <img src="<?php echo esc_url($qr_url); ?>" 
                     alt="QR Code" 
                     style="max-width: 200px; height: auto; border: 1px solid #ddd; padding: 5px; background: #fff;" />
                <div style="margin-top: 10px;">
                    <button type="button" 
                            class="button button-small at-download-qr-metabox" 
                            data-link-id="<?php echo esc_attr($link->id); ?>">
                        <span class="dashicons dashicons-download" style="margin-top: 3px;"></span>
                        <?php _e('Download QR', 'at-agency-manager'); ?>
                    </button>
                </div>
            </div>
            <?php endif; ?>
            
            <div style="font-size: 11px; color: #666; margin-top: 10px; padding-top: 10px; border-top: 1px solid #ddd;">
                <p style="margin: 0;">
                    <?php _e('Created:', 'at-agency-manager'); ?> 
                    <?php echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($link->created_at))); ?>
                </p>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // העתקת לינק
            $('.at-copy-short-link').on('click', function() {
                var url = $(this).data('url');
                var $input = $('#at_short_link_url');
                
                // יצירת input זמני להעתקה
                var $temp = $('<input>');
                $('body').append($temp);
                $temp.val(url).select();
                document.execCommand('copy');
                $temp.remove();
                
                // אנימציה של הצלחה
                var $btn = $(this);
                var originalHtml = $btn.html();
                $btn.html('<span class="dashicons dashicons-yes-alt" style="color: #46b450; margin-top: 3px;"></span>');
                setTimeout(function() {
                    $btn.html(originalHtml);
                }, 2000);
            });
            
            // הורדת QR
            $('.at-download-qr-metabox').on('click', function() {
                var linkId = $(this).data('link-id');
                window.location.href = '<?php echo esc_js(admin_url('admin-ajax.php')); ?>?action=at_short_links_download_qr&nonce=<?php echo esc_js(wp_create_nonce('at_short_links_nonce')); ?>&link_id=' + linkId;
            });
        });
        </script>
        <?php
    }
    
    /**
     * הוספת לינק מקוצר למידע על פוסט (filter)
     */
    public function add_short_link_to_post_meta($value, $object_id, $meta_key, $single) {
        // רק אם מבקשים meta key ספציפי או אם זה REST API
        if ($meta_key !== 'at_short_link' && $meta_key !== 'short_link') {
            return $value;
        }
        
        // בדיקה אם המודול מופעל
        $modules = get_option('at_agency_manager_modules', []);
        if (empty($modules['url_shortener'])) {
            return $value;
        }
        
        $link = $this->get_link_by_post_id($object_id);
        
        if ($link) {
            $short_link_data = array(
                'short_url' => $link->short_url,
                'hash' => $link->hash,
                'clicks' => $link->clicks,
                'created_at' => $link->created_at
            );
            
            if ($single) {
                return $short_link_data;
            }
            
            return array($short_link_data);
        }
        
        return $value;
    }
    
    /**
     * הוספת לינק מקוצר ל-REST API
     */
    public function add_short_link_to_rest_api() {
        // בדיקה אם המודול מופעל
        $modules = get_option('at_agency_manager_modules', []);
        if (empty($modules['url_shortener'])) {
            return;
        }
        
        // הוספת field לכל סוגי הפוסטים
        $post_types = get_post_types(array('public' => true, 'show_in_rest' => true), 'names');
        
        foreach ($post_types as $post_type) {
            register_rest_field(
                $post_type,
                'at_short_link',
                array(
                    'get_callback' => array($this, 'get_short_link_for_rest'),
                    'update_callback' => null,
                    'schema' => array(
                        'description' => __('Short link information', 'at-agency-manager'),
                        'type' => 'object',
                        'context' => array('view', 'edit'),
                        'readonly' => true,
                        'properties' => array(
                            'short_url' => array(
                                'type' => 'string',
                                'description' => __('The short URL', 'at-agency-manager')
                            ),
                            'hash' => array(
                                'type' => 'string',
                                'description' => __('The hash of the short link', 'at-agency-manager')
                            ),
                            'clicks' => array(
                                'type' => 'integer',
                                'description' => __('Number of clicks', 'at-agency-manager')
                            ),
                            'created_at' => array(
                                'type' => 'string',
                                'format' => 'date-time',
                                'description' => __('Creation date', 'at-agency-manager')
                            )
                        )
                    )
                )
            );
        }
    }
    
    /**
     * Callback ל-REST API field
     */
    public function get_short_link_for_rest($object, $field_name, $request) {
        $post_id = $object['id'];
        $link = $this->get_link_by_post_id($post_id);
        
        if ($link) {
            return array(
                'short_url' => $link->short_url,
                'hash' => $link->hash,
                'clicks' => (int) $link->clicks,
                'created_at' => $link->created_at
            );
        }
        
        return null;
    }
    
    /**
     * Hook להחזרת לינק מקוצר לפוסט
     * 
     * שימוש: apply_filters('at_get_post_short_link', null, $post_id);
     * 
     * @param mixed $value הערך הקיים (null בדרך כלל)
     * @param int $post_id מזהה הפוסט
     * @return array|null מידע על הלינק המקוצר או null
     */
    public function get_short_link_for_post($value, $post_id) {
        // בדיקה אם המודול מופעל
        $modules = get_option('at_agency_manager_modules', []);
        if (empty($modules['url_shortener'])) {
            return $value;
        }
        
        $link = $this->get_link_by_post_id($post_id);
        
        if ($link) {
            return array(
                'short_url' => $link->short_url,
                'hash' => $link->hash,
                'clicks' => (int) $link->clicks,
                'created_at' => $link->created_at,
                'qr_url' => $this->generate_qr_code($link->short_url, $link->id)
            );
        }
        
        // אם אין קישור, ננסה ליצור אחד
        $post = get_post($post_id);
        if ($post && in_array($post->post_type, array('post', 'page', 'product'))) {
            $url = get_permalink($post_id);
            if ($url) {
                $link_id = $this->create_short_link($post_id, $url);
                if ($link_id) {
                    $link = $this->get_link_by_id($link_id);
                    if ($link) {
                        return array(
                            'short_url' => $link->short_url,
                            'hash' => $link->hash,
                            'clicks' => (int) $link->clicks,
                            'created_at' => $link->created_at,
                            'qr_url' => $this->generate_qr_code($link->short_url, $link->id)
                        );
                    }
                }
            }
        }
        
        return $value;
    }
    
    /**
     * Hook להחזרת לינק מקוצר לפריט כללי
     * 
     * שימוש: apply_filters('at_get_item_short_link', null, $item_id, $item_type);
     * 
     * @param mixed $value הערך הקיים (null בדרך כלל)
     * @param array $args [item_id, item_type]
     * @return array|null מידע על הלינק המקוצר או null
     */
    public function get_short_link_for_item($value, $args) {
        // בדיקה אם המודול מופעל
        $modules = get_option('at_agency_manager_modules', []);
        if (empty($modules['url_shortener'])) {
            return $value;
        }
        
        if (!is_array($args) || count($args) < 2) {
            return $value;
        }
        
        $item_id = $args[0];
        $item_type = $args[1];
        
        // אם זה פוסט, נשתמש בפונקציה הקיימת
        if (in_array($item_type, array('post', 'page', 'product'))) {
            return $this->get_short_link_for_post(null, $item_id);
        }
        
        // עבור סוגי פריטים אחרים, נחפש לפי original_url
        global $wpdb;
        $link = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE original_url LIKE %s LIMIT 1",
            '%' . $wpdb->esc_like($item_id) . '%'
        ));
        
        if ($link) {
            return array(
                'short_url' => $link->short_url,
                'hash' => $link->hash,
                'clicks' => (int) $link->clicks,
                'created_at' => $link->created_at,
                'qr_url' => $this->generate_qr_code($link->short_url, $link->id)
            );
        }
        
        return $value;
    }
}
