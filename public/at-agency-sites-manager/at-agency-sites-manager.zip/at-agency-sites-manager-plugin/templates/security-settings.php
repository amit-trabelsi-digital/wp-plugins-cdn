<?php
if (!defined('ABSPATH')) exit;
?>
<div class="wrap" style="direction: rtl; text-align: right;">
    <h1 style="text-align: right;">הגדרות אבטחה</h1>
    <form method="post" action="options.php">
        <?php
        settings_fields('at_security_settings');
        do_settings_sections('at_security_settings');
        ?>
        <table class="form-table" style="width:100%;">
            <tr>
                <th scope="row"><label for="at_security_debug_mode">מצב דיבאג</label></th>
                <td>
                    <input type="checkbox" id="at_security_debug_mode" name="at_security_debug_mode" value="1" <?php checked(get_option('at_security_debug_mode'), 1); ?> />
                    <span class="description">הפעלת מצב דיבאג תאפשר הצגת מידע נוסף לאיתור תקלות.</span>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="at_security_log_level">רמת לוג</label></th>
                <td>
                    <select id="at_security_log_level" name="at_security_log_level">
                        <option value="error" <?php selected(get_option('at_security_log_level'), 'error'); ?>>שגיאות בלבד</option>
                        <option value="warning" <?php selected(get_option('at_security_log_level'), 'warning'); ?>>אזהרות</option>
                        <option value="info" <?php selected(get_option('at_security_log_level'), 'info'); ?>>מידע</option>
                        <option value="debug" <?php selected(get_option('at_security_log_level'), 'debug'); ?>>דיבאג</option>
                    </select>
                    <span class="description">בחר את רמת הלוגים שיישמרו במערכת.</span>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="at_security_log_retention">משך שמירת לוגים (ימים)</label></th>
                <td>
                    <input type="number" id="at_security_log_retention" name="at_security_log_retention" value="<?php echo esc_attr(get_option('at_security_log_retention', 30)); ?>" min="1" max="365" style="width: 80px;" />
                    <span class="description">הגדר לכמה ימים לשמור לוגים (ברירת מחדל: 30 ימים).</span>
                </td>
            </tr>
        </table>
        <?php submit_button('שמור הגדרות אבטחה'); ?>
    </form>
    <hr>
    <h2 style="text-align: right;">מידע דיבאג</h2>
    <div id="at-security-debug-info">
        <!-- כאן ניתן להציג מידע דינאמי מה-API בעתיד -->
        <em>מידע דיבאג יוצג כאן בעתיד.</em>
    </div>
    <h2 style="text-align: right;">לוגים אחרונים</h2>
    <div id="at-security-logs">
        <!-- כאן ניתן להציג לוגים מה-API בעתיד -->
        <em>לוגים אחרונים יוצגו כאן בעתיד.</em>
    </div>
</div> 