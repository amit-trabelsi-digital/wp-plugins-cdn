<div class="wrap at-agency-manager-wrap">
    <h1><?php _e('AT Custom Branding Settings', 'at-agency-manager'); ?></h1>
    <p><?php _e('Here you can adjust the branding and customization for your WordPress dashboard.', 'at-agency-manager'); ?></p>
    
    <form method="post" action="options.php">
        <?php settings_fields('at-branding'); ?>
        
        <div class="card">
            <h2><?php _e('Brand Colors', 'at-agency-manager'); ?></h2>
            <p><?php _e('Set your brand colors. These will be used for various UI elements throughout the dashboard and login screen.', 'at-agency-manager'); ?></p>
            
            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><?php _e('Primary Color (Dashboard)', 'at-agency-manager'); ?></th>
                    <td>
                        <input type="text" name="clients_main_color" size="40" value="<?php echo esc_attr(get_option('clients_main_color')); ?>" placeholder="#4ec5e0" />
                        <p class="description"><?php _e('Enter a HEX color code (e.g. #4ec5e0). Used for buttons and accents in the dashboard.', 'at-agency-manager'); ?></p>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php _e('Login Page Background Color', 'at-agency-manager'); ?></th>
                    <td>
                        <input type="text" name="at_login_bg_color" size="40" value="<?php echo esc_attr(get_option('at_login_bg_color', '#d0edeb')); ?>" placeholder="#d0edeb" />
                        <p class="description"><?php _e('Enter a HEX color code for the login page background (e.g. #d0edeb).', 'at-agency-manager'); ?></p>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php _e('Button Color (Dashboard)', 'at-agency-manager'); ?></th>
                    <td>
                        <input type="text" name="at_button_color" size="40" value="<?php echo esc_attr(get_option('at_button_color', '#4ec5e0')); ?>" placeholder="#4ec5e0" />
                        <p class="description"><?php _e('Enter a HEX color code for buttons in the dashboard (e.g. #4ec5e0).', 'at-agency-manager'); ?></p>
                    </td>
                </tr>
            </table>
        </div>
        
        <div class="card">
            <h2><?php _e('Brand Logo', 'at-agency-manager'); ?></h2>
            <p><?php _e('Upload your company logo to use in the login page and dashboard.', 'at-agency-manager'); ?></p>
            
            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><?php _e('Login Logo', 'at-agency-manager'); ?></th>
                    <td>
                        <input type="text" name="clients_logo_file" id="clients_logo_file" size="40" value="<?php echo esc_attr(get_option('clients_logo_file')); ?>" />
                        <input type="button" id="upload_logo_button" class="button" value="<?php _e('Upload Logo', 'at-agency-manager'); ?>" />
                        <?php if (get_option('clients_logo_file')) : ?>
                            <p>
                                <img src="<?php echo esc_attr(get_option('clients_logo_file')); ?>" alt="<?php _e('Current logo', 'at-agency-manager'); ?>" style="max-width: 200px; height: auto; margin-top: 10px; border: 1px solid #ddd; padding: 5px;">
                            </p>
                        <?php endif; ?>
                        <p class="description"><?php _e('Recommended size: 320px × 80px. Max width: 320px', 'at-agency-manager'); ?></p>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php _e('Admin Favicon', 'at-agency-manager'); ?></th>
                    <td>
                        <input type="text" name="admin_favicon_file" id="admin_favicon_file" size="40" value="<?php echo esc_attr(get_option('admin_favicon_file')); ?>" />
                        <input type="button" id="upload_favicon_button" class="button" value="<?php _e('Upload Favicon', 'at-agency-manager'); ?>" />
                        <?php if (get_option('admin_favicon_file')) : ?>
                            <p>
                                <img src="<?php echo esc_attr(get_option('admin_favicon_file')); ?>" alt="<?php _e('Current favicon', 'at-agency-manager'); ?>" style="max-width: 32px; height: auto; margin-top: 10px; border: 1px solid #ddd; padding: 5px;">
                            </p>
                        <?php endif; ?>
                        <p class="description"><?php _e('Recommended formats: .ico, .png or .svg. Recommended size: 32px × 32px.', 'at-agency-manager'); ?></p>
                    </td>
                </tr>
            </table>
        </div>
        
        <div class="card">
            <h2><?php _e('Typography', 'at-agency-manager'); ?></h2>
            <p><?php _e('Customize fonts used in the WordPress dashboard and admin panel.', 'at-agency-manager'); ?></p>
            
            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><?php _e('Dashboard Font (Google Fonts)', 'at-agency-manager'); ?></th>
                    <td>
                        <select name="at_admin_font" id="at_admin_font">
                            <option value="">-- <?php _e('System Default', 'at-agency-manager'); ?> --</option>
                            <option value="Roboto" <?php selected(get_option('at_admin_font'), 'Roboto'); ?>>Roboto</option>
                            <option value="Open Sans" <?php selected(get_option('at_admin_font'), 'Open Sans'); ?>>Open Sans</option>
                            <option value="Lato" <?php selected(get_option('at_admin_font'), 'Lato'); ?>>Lato</option>
                            <option value="Ubuntu" <?php selected(get_option('at_admin_font'), 'Ubuntu'); ?>>Ubuntu</option>
                            <option value="Inter" <?php selected(get_option('at_admin_font'), 'Inter'); ?>>Inter</option>
                            <option value="IBM Plex Sans" <?php selected(get_option('at_admin_font'), 'IBM Plex Sans'); ?>>IBM Plex Sans</option>
                            <option value="Plus Jakarta Sans" <?php selected(get_option('at_admin_font'), 'Plus Jakarta Sans'); ?>>Plus Jakarta Sans</option>
                        </select>
                        <p class="description"><?php _e('Select a Google Font to use throughout the WordPress dashboard.', 'at-agency-manager'); ?></p>
                    </td>
                </tr>
            </table>
        </div>
        
        <?php submit_button(); ?>
    </form>
</div>

<script type="text/javascript">
    jQuery(document).ready(function($) {
        $('#upload_logo_button').click(function() {
            tb_show('Upload a logo', 'media-upload.php?type=image&TB_iframe=true&post_id=0', false);
            window.send_to_editor = function(html) {
                var imgurl = $('img', html).attr('src');
                $('#clients_logo_file').val(imgurl);
                tb_remove();
            };
            return false;
        });
        
        $('#upload_favicon_button').click(function() {
            tb_show('Upload a favicon', 'media-upload.php?type=image&TB_iframe=true&post_id=0', false);
            window.send_to_editor = function(html) {
                var imgurl = $('img', html).attr('src');
                $('#admin_favicon_file').val(imgurl);
                tb_remove();
            };
            return false;
        });
    });
</script> 