<style>
    body.login {
        background-color: #f1f1f1;
    }
    
    body.login div#login h1 a {
        background-image: url('<?php echo $clientLogo; ?>');
        background-size: contain;
        width: 100%;
        height: 100px;
        margin: 0 auto 20px;
        padding: 0;
    }
    
    .login form {
        border-radius: 5px;
        box-shadow: 0 1px 3px rgba(0,0,0,.1);
    }
    
    .wp-core-ui .button-primary {
        background: <?php echo $clientColor; ?>;
        border-color: <?php echo $clientColor; ?>;
        text-shadow: none;
        box-shadow: none;
    }
    
    .wp-core-ui .button-primary:hover,
    .wp-core-ui .button-primary:focus,
    .wp-core-ui .button-primary:active {
        background: <?php echo $clientColor; ?>;
        border-color: <?php echo $clientColor; ?>;
        opacity: 0.9;
    }
    
    .login #backtoblog a, 
    .login #nav a {
        color: #666;
    }
    
    .login #backtoblog a:hover, 
    .login #nav a:hover,
    .login h1 a:hover {
        color: <?php echo $clientColor; ?>;
    }
    
    input[type=text]:focus, 
    input[type=password]:focus, 
    input[type=checkbox]:focus {
        border-color: <?php echo $clientColor; ?>;
        box-shadow: 0 0 0 1px <?php echo $clientColor; ?>;
    }
    
    #at-footer {
        margin-top: 20px;
        opacity: 0.7;
        transition: opacity 0.3s ease;
    }
    
    #at-footer:hover {
        opacity: 1;
    }
    
    #at-footer img {
        vertical-align: middle;
    }
</style> 