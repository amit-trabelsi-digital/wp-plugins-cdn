<!DOCTYPE html>
<html dir="rtl">
    <head>
        <title><?php echo get_bloginfo('name'); ?></title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <style>
            body {
                text-align: right;
                font-family: Arial, Helvetica, sans-serif;
                margin: 0;
                padding: 30px;
                background-color: #f7f7f7;
                color: #454545;
                line-height: 1.5em;
            }
            
            #email_container {
                background: #fff;
                direction: rtl;
            }
            
            #email_content {
                width: 600px;
                max-width: 90%;
                padding: 30px;
                background: #fff;
                margin: 30px auto;
                border: 1px #ccc solid;
                border-radius: 5px;
            }
            
            .logo {
                width: 160px;
                margin: 10px auto;
                text-align: center;
            }
            
            h1 {
                padding: 10px 0 3px 0;
                font-weight: 500;
                font-size: 24px;
                color: #000;
                border-bottom: 1px solid #bbb;
            }
            
            p {
                direction: rtl;
                unicode-bidi: plaintext;
            }
            
            #email_footer {
                text-align: center;
                border-top: 1px solid #eee;
                padding: 5px 0 0 0;
                font-size: 11px;
                color: #999;
                line-height: 14px;
            }
            
            .contact_footer {
                text-align: center;
                padding: 5px 0 0 0;
                font-size: 9px;
                color: #999;
                line-height: 12px;
                direction: ltr;
            }
            
            a {
                color: <?php echo get_option('clients_main_color', '#4ec5e0'); ?>;
                text-decoration: none;
            }
            
            a:hover {
                text-decoration: underline;
            }
            
            img {
                max-width: 100%;
                height: auto;
            }
        </style>
    </head>
    <body>
        <div id="email_container">
            <div id="email_content">
                <div class="logo">
                    <?php if(get_option('clients_logo_file') != '') : ?>
                    <img src="<?php echo get_option('clients_logo_file'); ?>" alt="<?php echo get_bloginfo('name'); ?>" width="160" height="auto">
                    <?php else: ?>
                    <h2><?php echo get_bloginfo('name'); ?></h2>
                    <?php endif; ?>
                </div>
                
                <?php if (!empty($atts['subject'])) : ?>
                <h1><?php echo $atts['subject']; ?></h1>
                <?php endif; ?>

                <?php echo $base; ?>

                <div id="email_footer">
                    <?php echo sprintf(__('You received this email from %s - %s', 'at-agency-manager'), get_bloginfo('name'), get_bloginfo('url')); ?>
                </div>
            </div>
        </div>
        <div class="contact_footer">
            <?php _e('Development & Maintenance by:', 'at-agency-manager'); ?> 
            <a href="https://atd.digital"><?php _e('Amit Trabelsi Digital', 'at-agency-manager'); ?></a>
        </div>
    </body>
</html> 