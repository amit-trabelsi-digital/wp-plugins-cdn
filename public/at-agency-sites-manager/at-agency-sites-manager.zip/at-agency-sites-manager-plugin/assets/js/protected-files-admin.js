(function($) {
    'use strict';

    // Copy-to-clipboard for the Secure URL field (works on both grid and list views).
    $(document).on('click', '.at-protected-file-card__copy-btn', function(event) {
        event.preventDefault();

        var $btn = $(this);
        var $input = $btn.closest('.at-protected-file-card__copy').find('.at-protected-file-card__input');
        var value = $input.val();

        if (!value) {
            return;
        }

        var copied = false;

        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(value).then(function() {
                flashCopied($btn);
            }).catch(function() {
                if (legacyCopy($input)) {
                    flashCopied($btn);
                }
            });
            return;
        }

        copied = legacyCopy($input);
        if (copied) {
            flashCopied($btn);
        }
    });

    function legacyCopy($input) {
        $input[0].focus();
        $input[0].select();
        try {
            return document.execCommand('copy');
        } catch (e) {
            return false;
        }
    }

    function flashCopied($btn) {
        var copiedLabel = $btn.data('copied-label') || 'Copied!';
        var defaultLabel = $btn.data('copy-label') || 'Copy';
        var $text = $btn.find('.at-protected-file-card__copy-text');

        $btn.addClass('is-copied');
        $text.text(copiedLabel);

        clearTimeout($btn.data('copy-timer'));
        var timer = setTimeout(function() {
            $btn.removeClass('is-copied');
            $text.text(defaultLabel);
        }, 1600);
        $btn.data('copy-timer', timer);
    }

    if (
        typeof wp === 'undefined' ||
        typeof wp.media === 'undefined' ||
        typeof wp.media.view === 'undefined' ||
        typeof wp.media.view.Attachment === 'undefined' ||
        typeof wp.media.view.Attachment.Library === 'undefined'
    ) {
        return;
    }

    var libraryView = wp.media.view.Attachment.Library;
    var originalClassName = libraryView.prototype.className;
    var originalRender = libraryView.prototype.render;

    function getBadgeMarkup() {
        var label = (window.atProtectedFilesAdmin && window.atProtectedFilesAdmin.badgeLabel) || 'Protected';
        var description = (window.atProtectedFilesAdmin && window.atProtectedFilesAdmin.badgeDescription) || '';

        return '<span class="at-protected-files-grid-badge" aria-label="' + _.escape(description) + '">' +
            '<span class="dashicons dashicons-shield" aria-hidden="true"></span>' +
            '<span>' + _.escape(label) + '</span>' +
        '</span>';
    }

    wp.media.view.Attachment.Library = libraryView.extend({
        className: function() {
            var className = _.isFunction(originalClassName)
                ? originalClassName.apply(this, arguments)
                : (originalClassName || 'attachment');

            if (this.model && this.model.get('atProtectedFile')) {
                className += ' at-protected-file';
            }

            return className;
        },

        render: function() {
            originalRender.apply(this, arguments);

            this.$el.find('.at-protected-files-grid-badge').remove();

            if (this.model && this.model.get('atProtectedFile')) {
                this.$el.find('.attachment-preview').append(getBadgeMarkup());
            }

            return this;
        }
    });
})(jQuery);
