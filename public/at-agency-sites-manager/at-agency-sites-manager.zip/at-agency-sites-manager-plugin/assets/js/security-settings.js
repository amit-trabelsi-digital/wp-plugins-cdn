jQuery(document).ready(function($) {
    'use strict';

    const securitySettings = {
        init: function() {
            this.bindEvents();
            this.loadLogs();
        },

        bindEvents: function() {
            $('.at-security-settings-page .refresh-logs').on('click', this.loadLogs.bind(this));
            $('.at-security-settings-page .clear-logs').on('click', this.clearLogs.bind(this));
        },

        loadLogs: function() {
            const $logsTable = $('.at-security-settings-page .logs-table tbody');
            
            $.ajax({
                url: atSecuritySettings.restUrl + 'security/logs',
                method: 'GET',
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-WP-Nonce', atSecuritySettings.nonce);
                },
                success: function(response) {
                    $logsTable.empty();
                    
                    if (!response.length) {
                        $logsTable.append(`
                            <tr>
                                <td colspan="3" class="no-logs">
                                    ${atSecuritySettings.i18n.noLogs}
                                </td>
                            </tr>
                        `);
                        return;
                    }

                    response.forEach(function(log) {
                        $logsTable.append(`
                            <tr class="log-entry log-${log.level}">
                                <td class="log-timestamp">${log.timestamp}</td>
                                <td class="log-level">${log.level}</td>
                                <td class="log-message">${log.message}</td>
                            </tr>
                        `);
                    });
                },
                error: function() {
                    alert(atSecuritySettings.i18n.errorLoading);
                }
            });
        },

        clearLogs: function() {
            if (!confirm('האם אתה בטוח שברצונך למחוק את כל הלוגים?')) {
                return;
            }

            $.ajax({
                url: atSecuritySettings.restUrl + 'security/logs',
                method: 'DELETE',
                beforeSend: function(xhr) {
                    xhr.setRequestHeader('X-WP-Nonce', atSecuritySettings.nonce);
                },
                success: function() {
                    securitySettings.loadLogs();
                },
                error: function() {
                    alert('שגיאה במחיקת הלוגים');
                }
            });
        }
    };

    securitySettings.init();
}); 