/**
 * AT Agency Manager - Admin Scripts
 */
jQuery(document).ready(function($) {
    // Media uploader for logo
    $('#upload_logo_button').click(function(e) {
        e.preventDefault();
        
        var custom_uploader = wp.media({
            title: 'Choose Logo',
            button: {
                text: 'Choose Logo'
            },
            multiple: false
        }).on('select', function() {
            var attachment = custom_uploader.state().get('selection').first().toJSON();
            $('#clients_logo_file').val(attachment.url);
        }).open();
    });
    
    // Media uploader for favicon
    $('#upload_favicon_button').click(function(e) {
        e.preventDefault();
        
        var custom_uploader = wp.media({
            title: 'Choose Favicon',
            button: {
                text: 'Choose Favicon'
            },
            multiple: false
        }).on('select', function() {
            var attachment = custom_uploader.state().get('selection').first().toJSON();
            $('#admin_favicon_file').val(attachment.url);
        }).open();
    });
    
    // Tab navigation
    $('.nav-tab').click(function(e) {
        e.preventDefault();
        
        // Remove active class from all tabs and tab contents
        $('.nav-tab').removeClass('nav-tab-active');
        $('.at-tab-content').removeClass('active');
        
        // Add active class to current tab and show corresponding content
        $(this).addClass('nav-tab-active');
        var tabId = $(this).attr('href');
        $(tabId).addClass('active');
    });
    
    // Show the first tab by default
    if ($('.nav-tab').length > 0) {
        $('.nav-tab:first').addClass('nav-tab-active');
        $('.at-tab-content:first').addClass('active');
    }
    
    // Toggle switch functionality
    $('.at-toggle-switch input').change(function() {
        var target = $(this).data('target');
        if ($(this).is(':checked')) {
            $('#' + target).show();
        } else {
            $('#' + target).hide();
        }
    });
    
    // Initialize toggle switches
    $('.at-toggle-switch input').each(function() {
        var target = $(this).data('target');
        if ($(this).is(':checked')) {
            $('#' + target).show();
        } else {
            $('#' + target).hide();
        }
    });
    
    // Test email functionality
    $('#at-test-email').click(function() {
        var button = $(this);
        var result = $('#at-test-email-result');
        
        button.prop('disabled', true);
        result.html('Sending...');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'at_test_email',
                security: $('#at_security').val()
            },
            success: function(response) {
                if (response.success) {
                    result.html('<span style="color:green">Email sent successfully!</span>');
                } else {
                    result.html('<span style="color:red">Failed: ' + response.data + '</span>');
                }
                button.prop('disabled', false);
            },
            error: function() {
                result.html('<span style="color:red">Error: could not send test email</span>');
                button.prop('disabled', false);
            }
        });
    });
}); 