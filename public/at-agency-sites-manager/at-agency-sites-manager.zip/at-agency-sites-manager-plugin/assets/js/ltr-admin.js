/* Admin Body Direction Switcher */
jQuery(document).ready(function($) {
    // Check if cookie exists for direction preference
    var savedDir = readCookie('at_admin_dir');
    var defaultDir = $('body').hasClass('rtl') ? 'rtl' : 'ltr';
    var currentDir = savedDir || defaultDir;
    
    // Apply saved direction on page load
    if (savedDir && savedDir !== defaultDir) {
        applyDirection(savedDir);
    }
    
    // Handle clicks on RTL/LTR buttons
    $('#dir-rtl, #dir-ltr').on('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        
        var targetDir = $(this).attr('id') === 'dir-rtl' ? 'rtl' : 'ltr';
        applyDirection(targetDir);
    });
    
    // Apply direction to admin content
    function applyDirection(dir) {
        var $body = $('body');
        var $adminBar = $('.admin-body-ltr-adminbar');
        var $content = $('#wpcontent, #wpbody-content, .wrap, .at-agency-manager-wrap');
        
        if (dir === 'ltr') {
            $body.addClass('admin-body-ltr-active');
            $content.css('direction', 'ltr');
            $adminBar.addClass('active');
            $('#dir-ltr').addClass('active');
            $('#dir-rtl').removeClass('active');
            createCookie('at_admin_dir', 'ltr', 30);
        } else {
            $body.removeClass('admin-body-ltr-active');
            $content.css('direction', 'rtl');
            $adminBar.removeClass('active');
            $('#dir-rtl').addClass('active');
            $('#dir-ltr').removeClass('active');
            createCookie('at_admin_dir', 'rtl', 30);
        }
    }
    
    // Cookie functions
    function createCookie(name, value, days) {
        var expires = "";
        if (days) {
            var date = new Date();
            date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
            expires = "; expires=" + date.toUTCString();
        }
        document.cookie = name + "=" + value + expires + "; path=/";
    }
    
    function readCookie(name) {
        var nameEQ = name + "=";
        var ca = document.cookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') c = c.substring(1, c.length);
            if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
        }
        return null;
    }
    
    function eraseCookie(name) {
        createCookie(name, "", -1);
    }
}); 