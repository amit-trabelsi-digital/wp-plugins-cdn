#!/bin/bash

# Define the source of truth file
PLUGIN_FILE="at-bookings-api-fixes.php"

# 1. Extract Version from Plugin Header (Source of Truth)
# Looks for line starting with " * Version: X.X.X"
NEW_VERSION=$(grep -m 1 "* Version:" "$PLUGIN_FILE" | awk '{print $3}')

if [ -z "$NEW_VERSION" ]; then
    echo "❌ Error: Could not detect version in $PLUGIN_FILE"
    exit 1
fi

CURRENT_DATE=$(date +"%B %d, %Y")

echo "🔄 Syncing project to version: $NEW_VERSION"

# 2. Update PHP Constant (in the same file)
# Looks for "define('AT_BOOKINGS_API_FIXES_VERSION', 'X.X.X');"
sed -i '' "s/define('AT_BOOKINGS_API_FIXES_VERSION', '[0-9.]*');/define('AT_BOOKINGS_API_FIXES_VERSION', '$NEW_VERSION');/" "$PLUGIN_FILE"
echo "✅ Updated PHP Constant"

# 3. Update README.md (Badge and Title)
sed -i '' "s/version-[0-9.]*-blue/version-$NEW_VERSION-blue/" README.md
sed -i '' "s/# AT Bookings API Fixes v[0-9.]*/# AT Bookings API Fixes v$NEW_VERSION/" README.md
echo "✅ Updated README.md"

# 4. Update CLAUDE.md (Header)
sed -i '' "s/# CLAUDE.md - AT Bookings API Fixes v[0-9.]*/# CLAUDE.md - AT Bookings API Fixes v$NEW_VERSION/" CLAUDE.md
sed -i '' "s/\*\*Version\*\*: [0-9.]*/\*\*Version\*\*: $NEW_VERSION/" CLAUDE.md
# Update date only if version changed (optional logic, simplified here to always update date on run)
sed -i '' "s/\*\*Updated\*\*: .*/\*\*Updated\*\*: $CURRENT_DATE/" CLAUDE.md
echo "✅ Updated CLAUDE.md"

# 5. Check CHANGELOG.md
if ! grep -q "\[$NEW_VERSION\]" CHANGELOG.md; then
    echo "⚠️  WARNING: Version $NEW_VERSION not found in CHANGELOG.md!"
else
    echo "✅ CHANGELOG.md contains version $NEW_VERSION"
fi

echo "✨ Sync complete! All files match version $NEW_VERSION."
