<?php
/**
 * Unified Zoho Core Module
 * 
 * Combines zoho-crm.php, zoho-api.php, and zoho-modules.php into single consolidated class
 * Acts as Facade to maintain backward compatibility with existing code
 * 
 * @package AT_Bookings_API_Fixes
 * @version 2.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Zoho_Core {
    
    private static $instance = null;
    private $crm_class;
    private $api_class;
    private $modules_class;
    
    // Constants from original classes
    const ZOHO_ACCOUNTS_URL = 'https://accounts.zoho.com';
    
    /**
     * Get Zoho CRM API URL (delegates to AT_Zoho_API)
     * ✅ FIXED: Single source of truth
     */
    public static function get_api_url() {
        if (class_exists('AT_Zoho_API')) {
            return AT_Zoho_API::get_api_base_url();
        }
        // Fallback for backward compatibility
        return 'https://www.zohoapis.com/crm/v2';
    }
    
    // Legacy constant for backward compatibility
    const ZOHO_CRM_API_URL = 'https://www.zohoapis.com/crm/v2';

    // Module names constants
    const MODULE_CONTACTS = 'Contacts';
    const MODULE_LEADS = 'Leads';
    const MODULE_ACCOUNTS = 'Accounts';
    const MODULE_DEALS = 'Deals';
    const MODULE_PRODUCTS = 'Products';
    const MODULE_SALES_ORDERS = 'Sales_Orders';
    const MODULE_TOURS = 'Tours';
    const MODULE_TOUR_SCHEDULES = 'Tour_Schedules';
    const MODULE_COUPONS = 'Coupons';
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->load_dependencies();
        $this->init_hooks();
    }
    
    /**
     * Load original module classes for delegation
     */
    private function load_dependencies() {
        // Load original classes from backup location temporarily
        $zoho_dir = dirname(__FILE__);
        $original_dir = dirname(dirname(dirname(__FILE__))) . '/includes/zoho';
        
        // Load API class
        if (file_exists($original_dir . '/zoho-api.php')) {
            require_once $original_dir . '/zoho-api.php';
        }
        
        // Load Modules class
        if (file_exists($original_dir . '/zoho-modules.php')) {
            require_once $original_dir . '/zoho-modules.php';
        }
        
        // Initialize instances
        if (class_exists('AT_Zoho_API')) {
            $this->api_class = AT_Zoho_API::get_instance();
        }
        
        if (class_exists('AT_Zoho_Modules')) {
            $this->modules_class = AT_Zoho_Modules::get_instance();
        }
    }
    
    /**
     * Initialize hooks for Zoho CRM
     */
    private function init_hooks() {
        // Note: register_settings hook removed to prevent duplicate registration
        // Only AJAX handlers and scheduled tasks are registered here
        add_action('wp_ajax_at_zoho_test_connection', array($this, 'ajax_test_connection'));
        add_action('wp_ajax_at_zoho_search_records', array($this, 'ajax_search_records'));
        add_action('wp_ajax_at_zoho_get_modules', array($this, 'ajax_get_modules'));
        add_action('wp_ajax_at_zoho_save_refresh_token', array($this, 'ajax_save_refresh_token'));
        add_action('wp_ajax_at_zoho_save_basic_settings', array($this, 'ajax_save_basic_settings'));
        
        // Schedule automatic token refresh
        add_action('at_zoho_refresh_token', array($this, 'scheduled_token_refresh'));
        
        // Check if we need to schedule the refresh
        if (!wp_next_scheduled('at_zoho_refresh_token')) {
            wp_schedule_event(time(), 'hourly', 'at_zoho_refresh_token');
        }
    }
    
    /**
     * Create a record in Zoho CRM
     */
    public function create_record($module, $data) {
        if ($this->api_class) {
            return $this->api_class->create_record($module, $data);
        }
        return array('success' => false, 'message' => 'API not initialized');
    }
    
    /**
     * Update a record in Zoho CRM
     */
    public function update_record($module, $record_id, $data) {
        if ($this->api_class) {
            return $this->api_class->update_record($module, $record_id, $data);
        }
        return array('success' => false, 'message' => 'API not initialized');
    }
    
    /**
     * Search records in Zoho CRM
     */
    public function search_records($search_term, $module = '') {
        if ($this->modules_class) {
            return $this->modules_class->search_in_module($module, 'name', $search_term);
        }
        return false;
    }
    
    /**
     * Get API domain
     */
    public function get_api_domain() {
        if ($this->api_class) {
            return $this->api_class->get_api_domain();
        }
        return '';
    }
    
    /**
     * Check if Zoho is configured
     */
    public static function is_configured() {
        return !empty(get_option('at_zoho_client_id')) && 
               !empty(get_option('at_zoho_refresh_token'));
    }
    
    /**
     * Test Zoho connection
     */
    public function test_connection() {
        if ($this->api_class && method_exists($this->api_class, 'test_connection')) {
            return $this->api_class->test_connection();
        }
        return array('success' => false, 'message' => 'API not available');
    }
    
    /**
     * Refresh access token
     */
    public function refresh_token() {
        if ($this->api_class && method_exists($this->api_class, 'refresh_access_token')) {
            return $this->api_class->refresh_access_token();
        }
        return array('success' => false, 'message' => 'API not available');
    }
    
    /**
     * Scheduled token refresh
     */
    public function scheduled_token_refresh() {
        AT_Bookings_Logger::info('Running scheduled Zoho token refresh');
        $this->refresh_token();
    }
    
    /**
     * Register settings
     * 
     * @deprecated 3.3.0 Settings registration is handled by the main plugin.
     * Kept for backward compatibility but no longer used.
     */
    public function register_settings() {
        // Settings are registered by AT_Bookings_API_Fixes::register_zoho_settings().
        // This method is kept for backward compatibility only
    }
    
    /**
     * AJAX: Test connection
     */
    public function ajax_test_connection() {
        if (!AT_Security_Manager::verify_ajax_admin()) {
            return;
        }
        
        $result = $this->test_connection();
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
    
    /**
     * AJAX: Search records
     */
    public function ajax_search_records() {
        if (!AT_Security_Manager::verify_ajax_admin()) {
            return;
        }
        
        $search_term = sanitize_text_field($_POST['search_term'] ?? '');
        $module = sanitize_text_field($_POST['module'] ?? '');
        
        $results = $this->search_records($search_term, $module);
        wp_send_json_success($results);
    }
    
    /**
     * AJAX: Get modules
     */
    public function ajax_get_modules() {
        if (!AT_Security_Manager::verify_ajax_admin()) {
            return;
        }
        
        $modules = array(
            self::MODULE_CONTACTS,
            self::MODULE_LEADS,
            self::MODULE_ACCOUNTS,
            self::MODULE_DEALS,
            self::MODULE_PRODUCTS,
            self::MODULE_SALES_ORDERS,
            self::MODULE_TOURS,
            self::MODULE_TOUR_SCHEDULES
        );
        
        wp_send_json_success($modules);
    }
    
    /**
     * AJAX: Save refresh token
     */
    public function ajax_save_refresh_token() {
        if (!AT_Security_Manager::verify_ajax_admin()) {
            return;
        }
        
        $token = sanitize_text_field($_POST['refresh_token'] ?? '');
        $domain = sanitize_text_field($_POST['domain'] ?? 'com');
        
        update_option('at_zoho_refresh_token', $token);
        update_option('at_zoho_domain', $domain);
        
        AT_Bookings_Logger::info('Zoho refresh token updated');
        wp_send_json_success(array('message' => 'Token saved successfully'));
    }
    
    /**
     * AJAX: Save basic settings
     */
    public function ajax_save_basic_settings() {
        if (!AT_Security_Manager::verify_ajax_admin()) {
            return;
        }
        
        $client_id = sanitize_text_field($_POST['client_id'] ?? '');
        $client_secret = sanitize_text_field($_POST['client_secret'] ?? '');
        
        update_option('at_zoho_client_id', $client_id);
        update_option('at_zoho_client_secret', $client_secret);
        
        AT_Bookings_Logger::info('Zoho basic settings updated');
        wp_send_json_success(array('message' => 'Settings saved successfully'));
    }
}

// Initialize Zoho Core
AT_Zoho_Core::get_instance();
