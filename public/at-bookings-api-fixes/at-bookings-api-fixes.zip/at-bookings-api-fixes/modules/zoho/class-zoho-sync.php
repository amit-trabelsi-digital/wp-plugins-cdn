<?php
/**
 * Unified Zoho Sync Module
 * 
 * Combines zoho-sync-service.php and zoho-sync-logs.php into single consolidated class
 * Uses Facade pattern for backward compatibility
 * 
 * @package AT_Bookings_API_Fixes
 * @version 2.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Zoho_Sync {
    
    private static $instance = null;
    private $sync_service;
    private $sync_logs;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->load_dependencies();
    }
    
    /**
     * Load original sync classes for delegation
     */
    private function load_dependencies() {
        $original_dir = dirname(dirname(dirname(__FILE__))) . '/includes/zoho';
        
        // Load Sync Service
        if (file_exists($original_dir . '/zoho-sync-service.php')) {
            require_once $original_dir . '/zoho-sync-service.php';
        }
        
        // Load Sync Logs
        if (file_exists($original_dir . '/zoho-sync-logs.php')) {
            require_once $original_dir . '/zoho-sync-logs.php';
        }
        
        // Initialize instances
        if (class_exists('AT_Zoho_Sync_Service')) {
            $this->sync_service = new AT_Zoho_Sync_Service();
        }
        
        if (class_exists('AT_Zoho_Sync_Logs')) {
            $this->sync_logs = AT_Zoho_Sync_Logs::get_instance();
        }
    }
    
    /**
     * Sync complete order to Zoho
     */
    public function sync_order($order_id, $trigger = 'manual') {
        if ($this->sync_service && method_exists($this->sync_service, 'sync_order')) {
            return $this->sync_service->sync_order($order_id, $trigger);
        }
        return array('success' => false, 'message' => 'Sync service not available');
    }
    
    /**
     * Sync single entity
     */
    public function sync_entity($order_id, $entity, $trigger = 'manual') {
        if ($this->sync_service && method_exists($this->sync_service, 'sync_entity')) {
            return $this->sync_service->sync_entity($order_id, $entity, $trigger);
        }
        return array('success' => false, 'message' => 'Sync service not available');
    }
    
    /**
     * Stop sync
     */
    public function set_stop_flag() {
        if ($this->sync_service && method_exists($this->sync_service, 'set_stop_flag')) {
            return $this->sync_service->set_stop_flag();
        }
    }
    
    /**
     * Log sync operation
     */
    public static function log($data) {
        if (class_exists('AT_Zoho_Sync_Logs')) {
            $logs = AT_Zoho_Sync_Logs::get_instance();
            if (method_exists($logs, 'log')) {
                return $logs->log($data);
            }
        }
        return false;
    }
    
    /**
     * Create logs table
     */
    public static function create_table() {
        if (class_exists('AT_Zoho_Sync_Logs')) {
            return AT_Zoho_Sync_Logs::create_table();
        }
    }
    
    /**
     * Get recent logs
     */
    public static function get_recent_logs($limit = 50, $filters = array()) {
        if (class_exists('AT_Zoho_Sync_Logs')) {
            $logs = AT_Zoho_Sync_Logs::get_instance();
            if (method_exists($logs, 'get_recent_logs')) {
                return $logs->get_recent_logs($limit, $filters);
            }
        }
        return array();
    }
    
    /**
     * Clear logs
     */
    public static function clear_logs() {
        if (class_exists('AT_Zoho_Sync_Logs')) {
            $logs = AT_Zoho_Sync_Logs::get_instance();
            if (method_exists($logs, 'clear_logs')) {
                return $logs->clear_logs();
            }
        }
        return false;
    }
    
    /**
     * Get log count
     */
    public static function get_log_count() {
        if (class_exists('AT_Zoho_Sync_Logs')) {
            $logs = AT_Zoho_Sync_Logs::get_instance();
            if (method_exists($logs, 'get_log_count')) {
                return $logs->get_log_count();
            }
        }
        return 0;
    }
}

// Initialize Zoho Sync module
AT_Zoho_Sync::get_instance();
