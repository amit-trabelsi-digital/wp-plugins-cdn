<?php
/**
 * Unified Zoho Admin Module
 * 
 * Combines zoho-settings.php and zoho-logs-page.php
 * 
 * @package AT_Bookings_API_Fixes
 * @version 2.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Zoho_Admin {
    
    private static $instance = null;
    private $settings_loaded = false;
    private $logs_page_loaded = false;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        if (is_admin()) {
            $this->load_dependencies();
        }
    }
    
    /**
     * Load admin dependencies
     */
    private function load_dependencies() {
        $original_dir = dirname(dirname(dirname(__FILE__))) . '/includes/zoho';
        
        // Load Settings page
        if (file_exists($original_dir . '/zoho-settings.php')) {
            require_once $original_dir . '/zoho-settings.php';
            $this->settings_loaded = true;
        }
        
        // Load Logs page
        if (file_exists($original_dir . '/zoho-logs-page.php')) {
            require_once $original_dir . '/zoho-logs-page.php';
            $this->logs_page_loaded = true;
        }
    }
    
    /**
     * Check if admin pages loaded successfully
     */
    public function is_loaded() {
        return $this->settings_loaded || $this->logs_page_loaded;
    }
}

// Initialize Zoho Admin
AT_Zoho_Admin::get_instance();
