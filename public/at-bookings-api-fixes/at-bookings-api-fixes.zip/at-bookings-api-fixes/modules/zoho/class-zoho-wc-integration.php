<?php
/**
 * Unified Zoho WooCommerce Integration Module
 * 
 * Combines zoho-woocommerce.php and zoho-field-checker.php
 * 
 * @package AT_Bookings_API_Fixes
 * @version 2.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Zoho_WC_Integration {
    
    private static $instance = null;
    private $woocommerce_loaded = false;
    private $field_checker_loaded = false;
    private $wc_class;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        if (class_exists('WooCommerce') && is_admin()) {
            $this->load_dependencies();
        }
    }
    
    /**
     * Load WooCommerce integration dependencies
     */
    private function load_dependencies() {
        $original_dir = dirname(dirname(dirname(__FILE__))) . '/includes/zoho';
        
        // Load WooCommerce integration
        if (file_exists($original_dir . '/zoho-woocommerce.php')) {
            require_once $original_dir . '/zoho-woocommerce.php';
            $this->woocommerce_loaded = true;
            
            if (class_exists('AT_Zoho_WooCommerce')) {
                $this->wc_class = AT_Zoho_WooCommerce::get_instance();
            }
        }
        
        // Load Field checker
        if (file_exists($original_dir . '/zoho-field-checker.php')) {
            require_once $original_dir . '/zoho-field-checker.php';
            $this->field_checker_loaded = true;
        }
    }
    
    /**
     * Check if integration loaded successfully
     */
    public function is_loaded() {
        return $this->woocommerce_loaded && $this->field_checker_loaded;
    }
    
    /**
     * Get WooCommerce integration instance
     */
    public function get_wc_instance() {
        return $this->wc_class;
    }
}

// Initialize WC Integration
AT_Zoho_WC_Integration::get_instance();
