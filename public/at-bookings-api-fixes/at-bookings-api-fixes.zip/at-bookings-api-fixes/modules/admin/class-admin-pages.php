<?php
/**
 * Unified Admin Pages Module
 * 
 * Combines slots-management.php and zoho-order-sync.php
 * 
 * @package AT_Bookings_API_Fixes
 * @version 2.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Admin_Pages {
    
    private static $instance = null;
    private $slots_loaded = false;
    private $order_sync_loaded = false;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        if (is_admin()) {
            $this->load_dependencies();
        }
    }
    
    /**
     * Load admin pages dependencies
     */
    private function load_dependencies() {
        $original_dir = dirname(dirname(dirname(__FILE__))) . '/includes/admin';
        
        // Load Slots Management
        if (file_exists($original_dir . '/slots-management.php')) {
            require_once $original_dir . '/slots-management.php';
            $this->slots_loaded = true;
        }
        
        // Load Order Sync page
        if (file_exists($original_dir . '/zoho-order-sync.php')) {
            require_once $original_dir . '/zoho-order-sync.php';
            $this->order_sync_loaded = true;
        }
    }
    
    /**
     * Check if pages loaded successfully
     */
    public function is_loaded() {
        return $this->slots_loaded || $this->order_sync_loaded;
    }
}

// Initialize Admin Pages
AT_Admin_Pages::get_instance();
