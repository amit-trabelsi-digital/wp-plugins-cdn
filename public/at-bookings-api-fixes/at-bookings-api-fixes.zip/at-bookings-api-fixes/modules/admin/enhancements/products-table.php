<?php
/**
 * Products Table Enhancement
 * 
 * @package AT_Bookings_API_Fixes
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Load original products table enhancement
$original_dir = dirname(dirname(dirname(__FILE__))) . '/includes/admin';

if (file_exists($original_dir . '/products-table-enhancement.php')) {
    require_once $original_dir . '/products-table-enhancement.php';
}
