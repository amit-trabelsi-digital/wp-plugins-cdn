<?php
/**
 * Unified Admin Core Module
 * 
 * Combines dashboard.php, menu-manager.php, and system-checks.php
 * Uses Facade pattern for backward compatibility
 * 
 * @package AT_Bookings_API_Fixes
 * @version 2.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Admin_Core {
    
    private static $instance = null;
    private $dashboard_loaded = false;
    private $menu_loaded = false;
    private $checks_loaded = false;
    private $menu_manager;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        if (is_admin()) {
            $this->load_dependencies();
        }
    }
    
    /**
     * Load admin core dependencies
     */
    private function load_dependencies() {
        $original_dir = dirname(dirname(dirname(__FILE__))) . '/includes/admin';
        
        // Load System checks
        if (file_exists($original_dir . '/system-checks.php')) {
            require_once $original_dir . '/system-checks.php';
            $this->checks_loaded = true;
        }
        
        // Load Menu manager
        if (file_exists($original_dir . '/menu-manager.php')) {
            require_once $original_dir . '/menu-manager.php';
            $this->menu_loaded = true;
            
            if (class_exists('AT_Bookings_Menu_Manager')) {
                $this->menu_manager = AT_Bookings_Menu_Manager::get_instance();
            }
        }
        
        // Load Dashboard
        if (file_exists($original_dir . '/dashboard.php')) {
            require_once $original_dir . '/dashboard.php';
            $this->dashboard_loaded = true;
        }
    }
    
    /**
     * Check if all core components loaded
     */
    public function is_loaded() {
        return $this->menu_loaded && $this->dashboard_loaded;
    }
    
    /**
     * Get menu manager instance
     */
    public function get_menu_manager() {
        return $this->menu_manager;
    }
}

// Initialize Admin Core
AT_Admin_Core::get_instance();
