<?php
/**
 * Performance Fixes for AT Bookings API
 * 
 * @package AT_Bookings_API_Fixes
 * @version 1.3.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class AT_Performance_Fixes {
    
    public function __construct() {
        add_action('init', array($this, 'init_critical_fixes'), 1);
        add_action('wp_loaded', array($this, 'init_performance_fixes'), 5);
    }
    
    /**
     * Initialize critical fixes for current fatal errors
     */
    public function init_critical_fixes() {
        // Fix WooCommerce SEO breadcrumb errors - HIGHEST PRIORITY
        add_filter('wpseo_woocommerce_breadcrumb_link', array($this, 'fix_woocommerce_seo_breadcrumb'), 1, 1);
        add_filter('wpseo_breadcrumb_links', array($this, 'fix_breadcrumb_links_array'), 1, 1);
        
        // Memory management for Query Monitor
        $this->optimize_query_monitor();
        
        // Redis error handling
        $this->handle_redis_connection_errors();
    }
    
    /**
     * Fix WooCommerce SEO breadcrumb link errors
     */
    public function fix_woocommerce_seo_breadcrumb($link) {
        if (is_array($link)) {
            // Ensure all required keys exist
            $default_keys = array(
                'class' => '',
                'id' => '',
                'url' => '',
                'text' => '',
                'allow_html' => false
            );
            
            foreach ($default_keys as $key => $default_value) {
                if (!isset($link[$key])) {
                    $link[$key] = $default_value;
                }
            }
        }
        return $link;
    }
    
    /**
     * Fix breadcrumb links array
     */
    public function fix_breadcrumb_links_array($links) {
        if (is_array($links)) {
            foreach ($links as $index => $link) {
                $links[$index] = $this->fix_woocommerce_seo_breadcrumb($link);
            }
        }
        return $links;
    }
    
    /**
     * Optimize Query Monitor to prevent memory exhaustion
     */
    private function optimize_query_monitor() {
        // Disable Query Monitor on frontend completely
        if (!is_admin()) {
            add_filter('qm/process', '__return_false', 1);
        }
        
        // In admin, limit heavy collectors
        if (is_admin()) {
            add_filter('qm/collectors', function($collectors) {
                // Remove memory-intensive collectors
                $heavy_collectors = array(
                    'db_dupes',
                    'db_callers', 
                    'assets',
                    'conditionals',
                    'environment',
                    'http',
                    'languages',
                    'logger',
                    'overview',
                    'php_errors',
                    'request',
                    'theme',
                    'timing'
                );
                
                foreach ($heavy_collectors as $collector) {
                    if (isset($collectors[$collector])) {
                        unset($collectors[$collector]);
                    }
                }
                
                return $collectors;
            }, 1);
            
            // Limit Query Monitor memory usage
            add_filter('qm/collect/db_queries', function($queries) {
                // Limit to last 100 queries only
                if (count($queries) > 100) {
                    return array_slice($queries, -100, 100, true);
                }
                return $queries;
            });
        }
    }
    
    /**
     * Handle Redis connection errors
     */
    private function handle_redis_connection_errors() {
        // Monitor for Redis errors and handle gracefully
        add_action('shutdown', function() {
            $error = error_get_last();
            if ($error && strpos($error['message'], 'RedisException') !== false) {
                // Log the error
                error_log('AT Performance Fixes: Redis connection error detected - ' . $error['message']);
                
                // Temporarily disable object cache if possible
                if (function_exists('wp_cache_flush')) {
                    wp_cache_flush();
                }
                
                // Set a flag to avoid Redis for the next few minutes
                set_transient('at_redis_error_detected', true, 300); // 5 minutes
            }
        });
        
        // Check if Redis errors were detected and avoid Redis operations
        if (get_transient('at_redis_error_detected')) {
            // Override object cache functions to use database
            add_filter('pre_wp_cache_get', function($value, $key, $group) {
                return false; // Force database lookup
            }, 10, 3);
        }
    }
    
    /**
     * Initialize additional performance fixes
     */
    public function init_performance_fixes() {
        // Memory management
        $this->manage_memory_usage();
        
        // Cache optimization
        $this->optimize_cache_operations();
        
        // Database optimization
        $this->optimize_database_queries();
    }
    
    /**
     * Manage memory usage
     */
    private function manage_memory_usage() {
        if (is_admin()) {
            // Increase memory limit for admin
            if (function_exists('ini_set')) {
                $current_limit = ini_get('memory_limit');
                $current_bytes = $this->convert_to_bytes($current_limit);
                $required_bytes = 2 * 1024 * 1024 * 1024; // 2GB
                
                if ($current_bytes < $required_bytes) {
                    ini_set('memory_limit', '2048M');
                }
            }
            
            // Monitor memory usage
            add_action('admin_footer', array($this, 'monitor_memory_usage'));
        }
    }
    
    /**
     * Monitor memory usage and perform emergency cleanup
     */
    public function monitor_memory_usage() {
        $memory_usage = memory_get_usage(true);
        $memory_limit = $this->convert_to_bytes(ini_get('memory_limit'));
        $memory_percent = ($memory_usage / $memory_limit) * 100;
        
        if ($memory_percent > 85) {
            // Emergency cleanup
            $this->emergency_memory_cleanup();
            
            error_log("AT Performance Fixes: Emergency memory cleanup performed - usage was {$memory_percent}%");
        }
    }
    
    /**
     * Emergency memory cleanup
     */
    private function emergency_memory_cleanup() {
        // Clear WordPress caches
        if (function_exists('wp_cache_flush')) {
            wp_cache_flush();
        }
        
        // Clear object cache groups
        if (function_exists('wp_cache_delete_group')) {
            $cache_groups = array('posts', 'post_meta', 'terms', 'term_meta', 'users', 'user_meta');
            foreach ($cache_groups as $group) {
                wp_cache_delete_group($group);
            }
        }
        
        // Force garbage collection
        if (function_exists('gc_collect_cycles')) {
            gc_collect_cycles();
        }
    }
    
    /**
     * Optimize cache operations
     */
    private function optimize_cache_operations() {
        // Reduce cache expiration times for non-critical data
        add_filter('wp_cache_expiration', function($expiration, $key, $group) {
            $short_cache_groups = array('posts', 'post_meta', 'terms', 'term_meta');
            if (in_array($group, $short_cache_groups)) {
                return min($expiration, 300); // Max 5 minutes
            }
            return $expiration;
        }, 10, 3);
    }
    
    /**
     * Optimize database queries
     */
    private function optimize_database_queries() {
        // Limit post revisions
        if (!defined('WP_POST_REVISIONS')) {
            define('WP_POST_REVISIONS', 3);
        }
        
        // Optimize autosave interval
        if (!defined('AUTOSAVE_INTERVAL')) {
            define('AUTOSAVE_INTERVAL', 300); // 5 minutes
        }
    }
    
    /**
     * Convert memory limit string to bytes
     */
    private function convert_to_bytes($size) {
        $size = trim($size);
        $last = strtolower($size[strlen($size)-1]);
        $size = (int) $size;
        switch($last) {
            case 'g':
                $size *= 1024;
            case 'm':
                $size *= 1024;
            case 'k':
                $size *= 1024;
        }
        return $size;
    }
}

// Initialize the performance fixes
new AT_Performance_Fixes(); 
