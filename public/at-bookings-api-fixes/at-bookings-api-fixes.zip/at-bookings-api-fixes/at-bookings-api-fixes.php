<?php
/**
 * Plugin Name: AT Bookings API Fixes
 * Plugin URI: https://amit-trabelsi.co.il
 * Description: תיקונים וייעולים לאתר הבוקינג - כולל תיקוני ביצועים, שגיאות וחיבור ל-API
 * Version: 4.2.5
 * Author: Amit Trabelsi
 * Author URI: https://amit-trabelsi.co.il
 * Text Domain: at-bookings-api-fixes
 * Domain Path: /languages
 * Requires at least: 5.0
 * Tested up to: 6.6
 * Requires PHP: 7.4
 * Network: false
 * Update URI: https://updates.amiteam.io/at-bookings-api-fixes/plugin-info.json
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('AT_BOOKINGS_API_FIXES_VERSION', '4.2.5');
define('AT_BOOKINGS_API_FIXES_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('AT_BOOKINGS_API_FIXES_PLUGIN_URL', plugin_dir_url(__FILE__));
define('AT_BOOKINGS_API_FIXES_PLUGIN_BASENAME', plugin_basename(__FILE__));
define('AT_BOOKINGS_API_FIXES_TEMPLATES_DIR', AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'templates/');
define('AT_BOOKINGS_API_FIXES_FILE', __FILE__);
define('AT_BOOKINGS_MENU_POSITION', 58); // Above WooCommerce (55.5)

/**
 * Main plugin class
 */
class AT_Bookings_API_Fixes {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->init_hooks();
        $this->load_dependencies();
    }
    
    /**
     * Initialize hooks
     */
    private function init_hooks() {
        add_action('plugins_loaded', array($this, 'load_textdomain'));
        add_action('init', array($this, 'init_plugin'));
        add_action('admin_init', array($this, 'register_zoho_settings'));
        add_action('admin_notices', array($this, 'admin_notices'));
        
        // AJAX handlers for dashboard
        add_action('wp_ajax_at_test_zoho_connection', array($this, 'ajax_test_connection'));
        add_action('wp_ajax_at_refresh_zoho_token', array($this, 'ajax_refresh_token'));
        add_action('wp_ajax_at_clear_cache', array($this, 'ajax_clear_cache'));
        
        // AJAX handlers for order sync
        add_action('wp_ajax_at_zoho_sync_load_order', array($this, 'ajax_load_order'));
        add_action('wp_ajax_at_zoho_sync_get_search_config', array('AT_Zoho_Order_Sync_Page', 'handle_get_search_config'));
        add_action('wp_ajax_at_zoho_sync_search', array('AT_Zoho_Order_Sync_Page', 'handle_search_entity'));
        add_action('wp_ajax_at_zoho_sync_entity', array($this, 'ajax_sync_entity'));
        add_action('wp_ajax_at_zoho_sync_run_all', array($this, 'ajax_sync_run_all'));
        add_action('wp_ajax_at_zoho_sync_stop', array($this, 'ajax_sync_stop'));
        add_action('wp_ajax_at_zoho_get_order_object', array($this, 'ajax_get_order_object'));
        
        // AJAX handlers for searching Zoho records
        add_action('wp_ajax_at_search_zoho_records', array($this, 'ajax_search_zoho_records'));
        
        // AJAX handler for initial slots population
        add_action('wp_ajax_at_populate_initial_slots', array($this, 'ajax_populate_initial_slots'));
        
        // Activation/Deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }

    /**
     * Register Zoho settings independently of the retired GitHub updater.
     */
    public function register_zoho_settings() {
        register_setting('at_zoho_crm_options', 'at_zoho_client_id', array('sanitize_callback' => 'sanitize_text_field'));
        register_setting('at_zoho_crm_options', 'at_zoho_client_secret', array('sanitize_callback' => 'sanitize_text_field'));
        register_setting('at_zoho_crm_options', 'at_zoho_domain', array('sanitize_callback' => 'sanitize_text_field'));
        register_setting('at_zoho_crm_options', 'at_zoho_refresh_token', array('sanitize_callback' => 'sanitize_text_field'));
    }
    
    /**
     * Load plugin dependencies
     */
    private function load_dependencies() {
        require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/class-private-cdn-updater.php';
        require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/class-control-telemetry.php';

        new AT_Bookings_Private_CDN_Updater(array(
            'slug' => 'at-bookings-api-fixes',
            'plugin_file' => AT_BOOKINGS_API_FIXES_PLUGIN_BASENAME,
            'current_version' => AT_BOOKINGS_API_FIXES_VERSION,
            'manifest_url' => 'https://updates.amiteam.io/at-bookings-api-fixes/plugin-info.json',
        ));

        // Load core components
        if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/core/class-logger.php')) {
            require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/core/class-logger.php';
        }
        
        // Load database tables management
        if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/database/slots-table.php')) {
            require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/database/slots-table.php';
            AT_Bookings_Slots_Table::init();
        }
        // Load slots manager
        if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/slots/slots-manager.php')) {
            require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/slots/slots-manager.php';
        }
        // Load slots sync
        if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/slots/slots-sync.php')) {
            require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/slots/slots-sync.php';
        }
        // Load slots hooks
        if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/slots/slots-hooks.php')) {
            require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/slots/slots-hooks.php';
        }
        // Load performance fixes
        if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'performance-fixes.php')) {
            require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'performance-fixes.php';
        }
        // Load occupancy/REST utilities
        if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/occupancy.php')) {
            require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/occupancy.php';
        }
        // Cycle management (open cycles list, close-for-sale, daily auto-close
        // cron + manual run). Loaded unconditionally so the cron handler is
        // registered during WP-Cron requests (which are NOT is_admin()).
        if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/admin/cycle-management.php')) {
            require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/admin/cycle-management.php';
        }
        // Load admin components
        if (is_admin()) {
            // System checks utility
            if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/admin/system-checks.php')) {
                require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/admin/system-checks.php';
            }
            // Admin menu manager
            if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/admin/menu-manager.php')) {
                require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/admin/menu-manager.php';
            }
            // Dashboard page
            if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/admin/dashboard.php')) {
                require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/admin/dashboard.php';
            }
            // Notifications helper
            if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/admin/notifications-helper.php')) {
                require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/admin/notifications-helper.php';
            }
            // Order sync page
            if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/admin/zoho-order-sync.php')) {
                require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/admin/zoho-order-sync.php';
            }
            // ACF field groups
            if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/acf/acf-field-groups.php')) {
                require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/acf/acf-field-groups.php';
            }
            // Slots management page
            if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/admin/slots-management.php')) {
                require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/admin/slots-management.php';
            }
            // Products table enhancement
            if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/admin/products-table-enhancement.php')) {
                require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/admin/products-table-enhancement.php';
            }
            // Initial Sync helper (v3.5.0+)
            if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/zoho/zoho-sync-service-initial.php')) {
                require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/zoho/zoho-sync-service-initial.php';
            }
            // Initial Sync admin page
            if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/admin/initial-sync.php')) {
                require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/admin/initial-sync.php';
            }
        }
        // Load Gravity Forms ↔ Zoho Sync Settings (loaded unconditionally so the
        // `at_zoho_gform_config` filter is registered on every request, including
        // frontend form submissions — not just in wp-admin).
        if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/admin/gform-sync-settings.php')) {
            require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/admin/gform-sync-settings.php';
        }
        // Load ZOHO CRM integration
        if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/zoho/zoho-crm.php')) {
            require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/zoho/zoho-crm.php';
        }
        // Load Zoho fields and mapper
        if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/zoho/zoho-fields.php')) {
            require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/zoho/zoho-fields.php';
        }
        if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/zoho/zoho-mapper.php')) {
            require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/zoho/zoho-mapper.php';
        }
        // Load Zoho sync service
        if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/zoho/zoho-sync-service.php')) {
            require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/zoho/zoho-sync-service.php';
        }        // Slots-management page performance wrapper. Narrows the default
        // 60-day range to 30 days (halves the heavy postmeta JOIN) and
        // invalidates the at_get_future_tours_data() transient cache when
        // bookings are saved. Fixes the 504 timeout on /wp-admin/admin.php
        // ?page=at-slots-management.
        if (is_admin() && file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/integrations/slots-management-performance.php')) {
            require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/integrations/slots-management-performance.php';
        }

        // Abandoned-cart Lead enricher: runs on woocommerce_order_status_changed
        // at priority 20 (after the primary sync at 10) and pushes a follow-up
        // update_record() that adds cart contents + a distinctive Lead_Source
        // so sales can act on "נטישות דברו איתנו" Leads in Zoho.
        if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/integrations/abandoned-cart-lead-enricher.php')) {
            require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/integrations/abandoned-cart-lead-enricher.php';
        }
        // Counterpart to the enricher: runs at priority 25 on the SAME hook
        // when the order finishes paying. Updates the previously-created
        // abandoned-cart Lead's status to "Contact in Future" and appends a
        // link to the resulting Sales_Order, so sales doesn't chase a
        // customer who already completed the purchase.
        if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/integrations/abandoned-cart-lead-closer.php')) {
            require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/integrations/abandoned-cart-lead-closer.php';
        }
        // Abandoned-cart test page (admin-only). Lets the user simulate a full
        // unpaid-order → Lead → enrichment flow from wp-admin without going
        // through the storefront as a guest.
        if (is_admin() && file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/integrations/abandoned-cart-test-page.php')) {
            require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/integrations/abandoned-cart-test-page.php';
        }

        // Load Zoho field checker
        if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/zoho/zoho-field-checker.php')) {
            require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/zoho/zoho-field-checker.php';
        }
        // Load API Endpoints
        if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/api/slots-endpoint.php')) {
            require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/api/slots-endpoint.php';
        }

        // Load Zoho Webhook Handler
        if (file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/api/zoho-webhook-handler.php')) {
            require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/api/zoho-webhook-handler.php';
        }

        // Load Zoho Webhook Settings
        if (is_admin() && file_exists(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/admin/zoho-webhook-settings.php')) {
            require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/admin/zoho-webhook-settings.php';
        }

        // Load Gravity Forms to Zoho Sync (unified integration).
        //
        // Deferred to plugins_loaded (priority 15): this plugin loads before
        // Gravity Forms in active_plugins order, so class_exists('GFAPI')
        // is false here at load_dependencies() time and the integration was
        // silently skipped (Form -> Zoho sync never registered). Loading on
        // plugins_loaded guarantees GFAPI exists. The file is purely
        // declarative (only function defs + add_action/add_filter), and all
        // its hooks fire well after plugins_loaded, so nothing is missed.
        // This only affects the GF integration; the order/booking/product
        // Zoho syncs load unconditionally above and are not touched.
        add_action('plugins_loaded', array($this, 'load_gravity_forms_zoho_sync'), 15);
    }

    /**
     * Load the Gravity Forms -> Zoho integration once Gravity Forms is
     * available (it loads after this plugin in active_plugins order).
     */
    public function load_gravity_forms_zoho_sync() {
        if (! class_exists('GFAPI')) {
            return;
        }
        $file = AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/integrations/gravity-forms-sync.php';
        if (file_exists($file)) {
            require_once $file;
        }
    }
    
    /**
     * Load plugin textdomain
     */
    public function load_textdomain() {
        load_plugin_textdomain(
            'at-bookings-api-fixes',
            false,
            dirname(AT_BOOKINGS_API_FIXES_PLUGIN_BASENAME) . '/languages'
        );
    }
    
    /**
     * Initialize plugin
     */
    public function init_plugin() {
        // Check if WooCommerce is active
        if (!class_exists('WooCommerce')) {
            add_action('admin_notices', array($this, 'woocommerce_missing_notice'));
            return;
        }
        
        // Initialize error fixes immediately
        $this->init_critical_fixes();
    }
    
    /**
     * Initialize critical fixes for current errors
     */
    private function init_critical_fixes() {
        // Fix WooCommerce SEO "Undefined array key 'class'" errors
        add_filter('wpseo_woocommerce_breadcrumb_link', array($this, 'fix_breadcrumb_link'), 1, 1);
        
        // Handle Redis connection errors
        add_action('wp_cache_init', array($this, 'handle_redis_errors'));
        
        // Optimize Query Monitor to prevent memory exhaustion
        add_action('plugins_loaded', array($this, 'optimize_query_monitor'), 1);
        
        // Memory management
        add_action('init', array($this, 'manage_memory_limits'));
    }
    
    /**
     * Fix WooCommerce SEO breadcrumb link errors
     */
    public function fix_breadcrumb_link($link) {
        if (is_array($link)) {
            $required_keys = array('class', 'id', 'url', 'text');
            foreach ($required_keys as $key) {
                if (!isset($link[$key])) {
                    $link[$key] = '';
                }
            }
        }
        return $link;
    }
    
    /**
     * Handle Redis connection errors
     */
    public function handle_redis_errors() {
        if (class_exists('Redis')) {
            add_action('shutdown', function() {
                $error = error_get_last();
                if ($error && strpos($error['message'], 'RedisException') !== false) {
                    // Temporarily disable object cache
                    if (!defined('WP_CACHE_KEY_SALT')) {
                        define('WP_CACHE_KEY_SALT', 'temp_disabled_' . time());
                    }
                    
                    // Schedule re-enable after 5 minutes
                    if (!wp_next_scheduled('at_reenable_object_cache')) {
                        wp_schedule_single_event(time() + 300, 'at_reenable_object_cache');
                    }
                    
                    error_log('AT Bookings API Fixes: Redis connection error detected, temporarily disabled object cache');
                }
            });
        }
    }
    
    /**
     * Optimize Query Monitor to prevent memory issues
     */
    public function optimize_query_monitor() {
        // Disable Query Monitor on frontend for non-admin users
        if (!is_admin() && !current_user_can('manage_options')) {
            add_filter('qm/process', '__return_false');
        }
        
        // Limit Query Monitor collectors in admin
        if (is_admin()) {
            add_filter('qm/collectors', function($collectors) {
                // Remove heavy collectors
                unset($collectors['db_dupes']);
                unset($collectors['db_callers']);
                unset($collectors['assets']);
                return $collectors;
            });
        }
    }
    
    /**
     * Manage memory limits
     */
    public function manage_memory_limits() {
        if (is_admin()) {
            // Increase memory limit for admin area
            if (function_exists('ini_set')) {
                ini_set('memory_limit', '2048M');
            }
            
            // Monitor memory usage
            add_action('admin_footer', function() {
                $memory_usage = memory_get_usage(true);
                $memory_limit = wp_convert_hr_to_bytes(ini_get('memory_limit'));
                $memory_percent = ($memory_usage / $memory_limit) * 100;
                
                if ($memory_percent > 80) {
                    // Emergency cleanup
                    if (function_exists('wp_cache_flush')) {
                        wp_cache_flush();
                    }
                    
                    // Clear object cache
                    if (function_exists('wp_cache_delete_group')) {
                        wp_cache_delete_group('posts');
                        wp_cache_delete_group('post_meta');
                    }
                    
                    error_log("AT Bookings API Fixes: High memory usage detected ({$memory_percent}%), emergency cleanup performed");
                }
            });
        }
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Create database tables
        if (class_exists('AT_Bookings_Slots_Table')) {
            AT_Bookings_Slots_Table::create_tables();
        }
        
        // Set default options
        add_option('at_bookings_fixes_version', AT_BOOKINGS_API_FIXES_VERSION);
        add_option('at_bookings_fixes_activated', current_time('mysql'));
        
        // Clear any existing caches
        if (function_exists('wp_cache_flush')) {
            wp_cache_flush();
        }
        
        // Create ZOHO sync logs table
        if (class_exists('AT_Zoho_Sync_Logs')) {
            AT_Zoho_Sync_Logs::create_table();
        }
        
        // Schedule the daily cycle auto-close cron
        if (class_exists('AT_Cycle_Management')) {
            AT_Cycle_Management::schedule_cron();
        }

        // Log activation
        error_log('AT Bookings API Fixes plugin activated - version ' . AT_BOOKINGS_API_FIXES_VERSION);
        
        // Add immediate notice about activation
        set_transient('at_bookings_fixes_activated_notice', true, 30);
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Clean up scheduled events
        wp_clear_scheduled_hook('at_reenable_object_cache');

        // Clean up the daily cycle auto-close cron
        if (class_exists('AT_Cycle_Management')) {
            AT_Cycle_Management::unschedule_cron();
        } else {
            wp_clear_scheduled_hook('at_daily_close_empty_cycles');
        }
        
        // Drop database tables
        if (class_exists('AT_Bookings_Slots_Table')) {
            AT_Bookings_Slots_Table::drop_tables();
        }
        
        // Log deactivation
        error_log('AT Bookings API Fixes plugin deactivated');
    }
    
    /**
     * Admin notices
     */
    public function admin_notices() {
        // Show activation notice
        if (get_transient('at_bookings_fixes_activated_notice')) {
            echo '<div class="notice notice-success is-dismissible">';
            echo '<p><strong>AT Bookings API Fixes v' . esc_html(AT_BOOKINGS_API_FIXES_VERSION) . ':</strong> התוסף הופעל בהצלחה! תיקוני השגיאות וZOHO CRM Integration פעילים כעת.</p>';
            echo '</div>';
            delete_transient('at_bookings_fixes_activated_notice');
        }
        
        // Show integration status
        if (defined('IMPREZA_CHILD_VERSION') && current_user_can('manage_options')) {
            $dismissed = get_user_meta(get_current_user_id(), 'at_integration_notice_dismissed', true);
            if (!$dismissed) {
                echo '<div class="notice notice-info is-dismissible">';
                echo '<p><strong>AT Bookings API Fixes:</strong> זוהתה אינטגרציה עם Impreza Child Theme v' . IMPREZA_CHILD_VERSION . '</p>';
                echo '</div>';
            }
        }
    }
    
    /**
     * WooCommerce missing notice
     */
    public function woocommerce_missing_notice() {
        echo '<div class="notice notice-error">';
        echo '<p><strong>AT Bookings API Fixes:</strong> התוסף דורש את WooCommerce להיות מותקן ופעיל.</p>';
        echo '</div>';
    }
    
    /**
     * AJAX handler: Test Zoho connection
     */
    public function ajax_test_connection() {
        check_ajax_referer('at_bookings_dashboard', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
        }
        
        if (class_exists('AT_Bookings_System_Checks')) {
            $result = AT_Bookings_System_Checks::test_zoho_connection();
            if ($result['success']) {
                wp_send_json_success($result['message']);
            } else {
                wp_send_json_error($result['message']);
            }
        } else {
            wp_send_json_error(__('System checks not available', 'at-bookings-api-fixes'));
        }
    }
    
    /**
     * AJAX handler: Refresh Zoho token
     */
    public function ajax_refresh_token() {
        check_ajax_referer('at_bookings_dashboard', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
        }
        
        if (class_exists('AT_Zoho_CRM')) {
            try {
                $zoho = AT_Zoho_CRM::get_instance();
                $zoho->scheduled_token_refresh();
                wp_send_json_success(__('Token refreshed successfully', 'at-bookings-api-fixes'));
            } catch (Exception $e) {
                wp_send_json_error($e->getMessage());
            }
        } else {
            wp_send_json_error(__('Zoho CRM not available', 'at-bookings-api-fixes'));
        }
    }
    
    /**
     * AJAX handler: Clear cache
     */
    public function ajax_clear_cache() {
        check_ajax_referer('at_bookings_dashboard', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
        }
        
        // Clear transients
        delete_transient('at_modules_comparison');
        
        // Clear all Zoho count transients
        global $wpdb;
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_at_zoho_count_%'");
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_at_zoho_count_%'");
        
        // Clear WordPress object cache
        if (function_exists('wp_cache_flush')) {
            wp_cache_flush();
        }
        
        wp_send_json_success(__('Cache cleared successfully', 'at-bookings-api-fixes'));
    }
    
    /**
     * AJAX handler: Load order data for sync
     */
    public function ajax_load_order() {
        try {
            check_ajax_referer('at_zoho_sync', 'nonce');
            
            if (!current_user_can('manage_woocommerce')) {
                wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
            }
            
            $order_id = (int) ($_POST['order_id'] ?? 0);
            if (!$order_id) {
                wp_send_json_error(__('Invalid order ID', 'at-bookings-api-fixes'));
            }
            
            $order = wc_get_order($order_id);
            
            if (!$order) {
                wp_send_json_error(__('Order not found', 'at-bookings-api-fixes'));
            }
            
            // Use AT_Zoho_Order_Sync_Page to get full entity data with previews
            if (class_exists('AT_Zoho_Order_Sync_Page')) {
                $entities = [];
                
                // Get data for each entity (Contact, Product, Cycle, Order)
                foreach (['contact', 'product', 'cycle', 'order'] as $entity) {
                    try {
                        $entities[$entity] = AT_Zoho_Order_Sync_Page::get_entity_current_data($entity, $order);
                    } catch (Exception $e) {
                        // Log error but continue with other entities
                        write_detailed_log('Error loading entity data for ' . $entity . ' in Order #' . $order_id . ': ' . $e->getMessage(), 'ERROR');
                        write_detailed_log('Stack trace: ' . $e->getTraceAsString(), 'ERROR');
                        
                        // Return safe fallback data
                        $entities[$entity] = [
                            'zoho_id' => null,
                            'zoho_url' => '',
                            'preview' => [],
                            'diff' => '',
                            'issues' => [sprintf(__('Error loading data: %s', 'at-bookings-api-fixes'), $e->getMessage())]
                        ];
                    } catch (Error $e) {
                        // Catch PHP 7+ fatal errors (TypeError, etc.)
                        write_detailed_log('Fatal error loading entity data for ' . $entity . ' in Order #' . $order_id . ': ' . $e->getMessage(), 'ERROR');
                        write_detailed_log('Stack trace: ' . $e->getTraceAsString(), 'ERROR');
                        
                        $entities[$entity] = [
                            'zoho_id' => null,
                            'zoho_url' => '',
                            'preview' => [],
                            'diff' => '',
                            'issues' => [sprintf(__('Fatal error: %s', 'at-bookings-api-fixes'), $e->getMessage())]
                        ];
                    }
                }
                
                wp_send_json_success([
                    'order_id' => $order_id,
                    'customer' => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                    'status' => $order->get_status(),
                    'total' => $order->get_total(),
                    'date' => $order->get_date_created()->format('d/m/Y H:i'),
                    'entities' => $entities  // Full entity data with previews
                ]);
            } else {
                // Fallback to basic data
                wp_send_json_success([
                    'order_id' => $order_id,
                    'customer' => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                    'status' => $order->get_status(),
                    'total' => $order->get_total(),
                    'date' => $order->get_date_created()->format('d/m/Y H:i')
                ]);
            }
        } catch (Exception $e) {
            // Log full error details
            write_detailed_log('Fatal error in ajax_load_order for Order #' . ($order_id ?? 'unknown') . ': ' . $e->getMessage(), 'ERROR');
            write_detailed_log('Stack trace: ' . $e->getTraceAsString(), 'ERROR');
            
            // Send error response
            wp_send_json_error([
                'message' => __('Error loading order data', 'at-bookings-api-fixes'),
                'error' => $e->getMessage(),
                'order_id' => $order_id ?? 0
            ]);
        } catch (Error $e) {
            // Catch PHP 7+ fatal errors
            write_detailed_log('Fatal PHP error in ajax_load_order for Order #' . ($order_id ?? 'unknown') . ': ' . $e->getMessage(), 'ERROR');
            write_detailed_log('Stack trace: ' . $e->getTraceAsString(), 'ERROR');
            
            wp_send_json_error([
                'message' => __('Fatal error loading order data', 'at-bookings-api-fixes'),
                'error' => $e->getMessage(),
                'order_id' => $order_id ?? 0
            ]);
        }
    }
    
    /**
     * AJAX handler: Sync individual entity
     */
    public function ajax_sync_entity() {
        // Direct file logging for debugging
        $log_file = WP_CONTENT_DIR . '/debug-sync.log';
        file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] ajax_sync_entity called\n", FILE_APPEND);
        
        try {
            check_ajax_referer('at_zoho_sync', 'nonce');
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Nonce verified\n", FILE_APPEND);
            
            if (!current_user_can('manage_woocommerce')) {
                file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Permission denied\n", FILE_APPEND);
                wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
            }
            
            $order_id = (int) ($_POST['order_id'] ?? 0);
            $entity = sanitize_text_field($_POST['entity'] ?? '');
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Order ID: $order_id, Entity: $entity\n", FILE_APPEND);
            
            if (!$order_id || !$entity) {
                error_log('[AT Zoho Sync] Missing parameters');
                wp_send_json_error(__('Missing required parameters', 'at-bookings-api-fixes'));
            }
            
            $order = wc_get_order($order_id);
            if (!$order) {
                error_log('[AT Zoho Sync] Order not found');
                wp_send_json_error(__('Order not found', 'at-bookings-api-fixes'));
            }
            error_log('[AT Zoho Sync] Order found: #' . $order->get_id());
            
            if (!class_exists('AT_Zoho_Sync_Service')) {
                file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] ERROR: AT_Zoho_Sync_Service class not found\n", FILE_APPEND);
                wp_send_json_error(__('Sync service not available', 'at-bookings-api-fixes'));
            }
            
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Creating sync service instance\n", FILE_APPEND);
            $sync_service = new AT_Zoho_Sync_Service();
            
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Calling sync_entity for: $entity\n", FILE_APPEND);
            $result = $sync_service->sync_entity($order_id, $entity, 'manual');
            
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] sync_entity result: " . print_r($result, true) . "\n", FILE_APPEND);
            
            if ($result['success']) {
                // If syncing order entity, save the Zoho ID to the order
                if ($entity === 'order' && isset($result['zoho_id'])) {
                    $zoho_module = $order->is_paid() ? 'Sales_Orders' : 'Leads';
                    $meta_key = $zoho_module === 'Sales_Orders' ? '_zoho_sales_order_id' : '_zoho_lead_id';
                    update_post_meta($order_id, $meta_key, $result['zoho_id']);
                    error_log('[AT Zoho Sync] Saved Zoho ID to order meta: ' . $result['zoho_id']);
                }
                
                wp_send_json_success($result);
            } else {
                error_log('[AT Zoho Sync] Sync failed: ' . ($result['message'] ?? 'Unknown error'));
                wp_send_json_error($result['message'] ?? 'Unknown error');
            }
            
        } catch (Exception $e) {
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] EXCEPTION: " . $e->getMessage() . "\n", FILE_APPEND);
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Stack trace: " . $e->getTraceAsString() . "\n", FILE_APPEND);
            wp_send_json_error('Exception: ' . $e->getMessage());
        }
    }
    
    /**
     * AJAX handler: Run full sync
     */
    public function ajax_sync_run_all() {
        check_ajax_referer('at_zoho_sync', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
        }
        
        $order_id = (int) ($_POST['order_id'] ?? 0);
        
        if (!$order_id) {
            wp_send_json_error(__('Missing order ID', 'at-bookings-api-fixes'));
        }
        
        if (class_exists('AT_Zoho_Sync_Service')) {
            $sync_service = new AT_Zoho_Sync_Service();
            $result = $sync_service->sync_order($order_id, 'manual');
            
            if ($result['success']) {
                wp_send_json_success($result);
            } else {
                wp_send_json_error($result);
            }
        } else {
            wp_send_json_error(__('Sync service not available', 'at-bookings-api-fixes'));
        }
    }
    
    /**
     * AJAX handler: Stop sync
     */
    public function ajax_sync_stop() {
        check_ajax_referer('at_zoho_sync', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
        }
        
        if (class_exists('AT_Zoho_Sync_Service')) {
            $sync_service = new AT_Zoho_Sync_Service();
            $sync_service->set_stop_flag();
            
            wp_send_json_success(__('Sync stop signal sent', 'at-bookings-api-fixes'));
        } else {
            wp_send_json_error(__('Sync service not available', 'at-bookings-api-fixes'));
        }
    }
    
    /**
     * AJAX handler: Get full order object for debugging
     * Returns the exact object that would be sent to Zoho
     */
    public function ajax_get_order_object() {
        check_ajax_referer('at_zoho_sync', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
        }
        
        $order_id = (int) ($_POST['order_id'] ?? 0);
        $order = wc_get_order($order_id);
        
        if (!$order) {
            wp_send_json_error(__('Order not found', 'at-bookings-api-fixes'));
        }
        
        // Build the exact object using our centralized mapper
        if (class_exists('AT_Zoho_Mapper') && class_exists('AT_Zoho_Sync_Service')) {
            $sync_service = new AT_Zoho_Sync_Service();
            
            // Get booking/slot data using Order Sync page method (more reliable)
            // This method uses WC_Booking_Data_Store and gets data directly from WooCommerce Bookings
            $slot_data = null;
            if (class_exists('AT_Zoho_Order_Sync_Page') && method_exists('AT_Zoho_Order_Sync_Page', 'get_booking_data_from_order')) {
                $slot_data = AT_Zoho_Order_Sync_Page::get_booking_data_from_order($order);
                
                // Debug logging
                if ($slot_data) {
                    write_detailed_log('Booking data retrieved for Order #' . $order_id . ': BID=' . ($slot_data['id'] ?? 'N/A') . ', Tour ID=' . ($slot_data['tour_id'] ?? 'N/A'), 'DEBUG');
                } else {
                    write_detailed_log('No booking data found for Order #' . $order_id, 'WARNING');
                }
            }
            
            // Get actual IDs from meta
            $contact_id = get_post_meta($order_id, '_zoho_contact_id', true);
            $cycle_ids = get_post_meta($order_id, '_zoho_cycle_ids', true);
            $cycle_id = is_array($cycle_ids) && !empty($cycle_ids) ? $cycle_ids[0] : null;
            
            // CRITICAL: Get cycle ID from multiple sources (priority order)
            if (!$cycle_id && $slot_data) {
                // 1. Check if slot_data has zoho_cycle_id from booking meta
                $cycle_id = $slot_data['zoho_cycle_id'] ?? null;
                
                // 2. If still no ID, try to find cycle in Zoho
                if (!$cycle_id) {
                    // Get product for cycle search
                    $items = $order->get_items();
                    if (!empty($items)) {
                        $first_item = reset($items);
                        $product = $first_item->get_product();
                        
                        if ($product && method_exists($sync_service, 'find_or_create_cycle')) {
                            write_detailed_log('Searching for Cycle in Zoho for Order #' . $order_id . ', Tour ID: ' . ($slot_data['tour_id'] ?? 'N/A'), 'DEBUG');
                            $find_result = $sync_service->find_or_create_cycle($slot_data, $product);
                            
                            if ($find_result['success'] && !empty($find_result['id'])) {
                                $cycle_id = $find_result['id'];
                                write_detailed_log('✓ Found Cycle in Zoho: ' . $cycle_id, 'INFO');
                            } else {
                                write_detailed_log('✗ Cycle not found in Zoho: ' . ($find_result['message'] ?? 'Unknown'), 'WARNING');
                            }
                        }
                    }
                }
            }
            
            // CRITICAL: Add Zoho IDs to slot_data BEFORE building order object
            // This ensures Ordered_Items[].Cycle_rel gets the correct cycle ID
            if (!$slot_data) {
                $slot_data = [];
            }
            if ($cycle_id) {
                $slot_data['zoho_cycle_id'] = $cycle_id;
            }
            
            // Build order object using single source (now with correct cycle_id!)
            $order_data = AT_Zoho_Mapper::map_to_sales_order($order, $slot_data);
            
            // Override Contact_Name as lookup object (not Customer_No)
            if ($contact_id) {
                $order_data['Contact_Name'] = ['id' => $contact_id];
            }
            
            // IMPORTANT: Do NOT override Cycle_type!
            // Per CHANGELOG v3.6.1: Cycle_type = 'קבוצתי' (text, not ID)
            // The cycle link is in Ordered_Items[].Cycle_rel for each line item
            
            // Return the complete object
            wp_send_json_success([
                'object' => $order_data,
                'meta_info' => [
                    'contact_id' => $contact_id ?: 'NOT_SYNCED',
                    'cycle_id' => $cycle_id ?: 'NOT_SYNCED',
                    'has_contact' => !empty($contact_id),
                    'has_cycle' => !empty($cycle_id),
                    'ready_to_sync' => !empty($contact_id) && !empty($cycle_id),
                    'total_fields' => count($order_data),
                    'ordered_items_count' => count($order_data['Ordered_Items'] ?? []),
                    'is_paid' => $order->is_paid(),
                    'module' => $order->is_paid() ? 'Sales_Orders' : 'Leads'
                ]
            ]);
        } else {
            wp_send_json_error(__('Required classes not available', 'at-bookings-api-fixes'));
        }
    }

    /**
     * AJAX handler: Search Zoho records
     */
    public function ajax_search_zoho_records() {
        check_ajax_referer('at_zoho_sync', 'nonce');

        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
        }

        $search_term = sanitize_text_field($_POST['search_term'] ?? '');
        $module = sanitize_text_field($_POST['module'] ?? '');

        if (!$search_term || !$module) {
            wp_send_json_error(__('Missing required parameters', 'at-bookings-api-fixes'));
        }

        if (class_exists('AT_Zoho_CRM')) {
            try {
                $zoho = AT_Zoho_CRM::get_instance();
                $results = $zoho->search_records($search_term, $module);
                wp_send_json_success($results);
            } catch (Exception $e) {
                wp_send_json_error($e->getMessage());
            }
         } else {
             wp_send_json_error(__('Zoho CRM not available', 'at-bookings-api-fixes'));
         }
     }
     
     /**
      * AJAX handler: Populate initial slots
      */
     public function ajax_populate_initial_slots() {
         check_ajax_referer('at_bookings_dashboard', 'nonce');
         
         if (!current_user_can('manage_options')) {
             wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
         }
         
         if (class_exists('AT_Bookings_Slots_Table')) {
             $count = AT_Bookings_Slots_Table::populate_initial_slots();
             
             if ($count !== false) {
                 wp_send_json_success([
                     'message' => sprintf(__('Generated %d initial slots successfully', 'at-bookings-api-fixes'), $count),
                     'count' => $count
                 ]);
             } else {
                 wp_send_json_error(__('Failed to generate initial slots', 'at-bookings-api-fixes'));
             }
         } else {
             wp_send_json_error(__('Slots table class not available', 'at-bookings-api-fixes'));
         }
     }
 }

// Initialize the plugin
AT_Bookings_API_Fixes::get_instance();

/**
 * Re-enable object cache action
 */
add_action('at_reenable_object_cache', function() {
    // Clear any temporary cache settings
    if (function_exists('wp_cache_flush')) {
        wp_cache_flush();
    }
    error_log('AT Bookings API Fixes: Object cache re-enabled after Redis error recovery');
});

/**
 * Emergency fallback for critical functions
 */
if (!function_exists('write_detailed_log')) {
    function write_detailed_log($message, $type = 'INFO') {
        error_log("[$type] $message");
    }
}

/**
 * Helper function to convert human readable memory limit to bytes
 */
if (!function_exists('wp_convert_hr_to_bytes')) {
    function wp_convert_hr_to_bytes($size) {
        $size = trim($size);
        $last = strtolower($size[strlen($size)-1]);
        $size = (int) $size;
        switch($last) {
            case 'g':
                $size *= 1024;
            case 'm':
                $size *= 1024;
            case 'k':
                $size *= 1024;
        }
        return $size;
    }
}
