<?php
/**
 * Database Tables Management
 * 
 * Handles creation, management, and maintenance of plugin database tables
 * 
 * @package AT_Bookings_API_Fixes
 * @subpackage Database
 * @since 3.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Bookings_Slots_Table {
    const TABLE_SLOTS = 'at_booking_slots';
    const TABLE_SLOT_BOOKINGS = 'at_slot_bookings';

    /**
     * Initialize database tables
     */
    public static function init() {
        add_action('admin_init', array(__CLASS__, 'create_tables'));
        add_action('init', array(__CLASS__, 'check_and_create_tables'));
    }
    
    /**
     * Check and create tables if they don't exist
     */
    public static function check_and_create_tables() {
        if (!self::tables_exist()) {
            self::create_tables();
        }
    }

    /**
     * Create database tables on plugin activation
     */
    public static function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        // Slots table
        $slots_table = $wpdb->prefix . self::TABLE_SLOTS;
        $slots_sql = "CREATE TABLE IF NOT EXISTS $slots_table (
            id BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            product_id BIGINT(20) UNSIGNED NOT NULL,
            slot_start DATETIME NOT NULL,
            slot_end DATETIME NOT NULL,
            tour_id VARCHAR(100) NOT NULL,
            zoho_cycle_id VARCHAR(50),
            status ENUM('active', 'full', 'closed', 'cancelled') DEFAULT 'active',
            max_capacity INT DEFAULT 0,
            current_bookings INT DEFAULT 0,
            last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            
            UNIQUE KEY unique_slot (product_id, slot_start),
            UNIQUE KEY unique_tour_id (tour_id),
            KEY idx_product_date (product_id, slot_start),
            KEY idx_zoho_cycle (zoho_cycle_id),
            KEY idx_status_date (status, slot_start),
            KEY idx_status (status)
        ) $charset_collate;";

        // Slot bookings table
        $slot_bookings_table = $wpdb->prefix . self::TABLE_SLOT_BOOKINGS;
        $bookings_sql = "CREATE TABLE IF NOT EXISTS $slot_bookings_table (
            id BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            slot_id BIGINT(20) UNSIGNED NOT NULL,
            order_id BIGINT(20) UNSIGNED NOT NULL,
            booking_id BIGINT(20) UNSIGNED,
            participants INT DEFAULT 1,
            ticket_types LONGTEXT,
            status ENUM('pending', 'confirmed', 'paid', 'completed', 'cancelled') DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            
            KEY idx_slot (slot_id),
            KEY idx_order (order_id),
            KEY idx_booking (booking_id),
            KEY idx_status (status),
            UNIQUE KEY unique_order_booking (order_id, booking_id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($slots_sql);
        dbDelta($bookings_sql);

        // Log table creation
        update_option('at_booking_tables_created', current_time('mysql'));
    }

    /**
     * Drop tables on plugin deactivation
     */
    public static function drop_tables() {
        global $wpdb;
        
        $slots_table = $wpdb->prefix . self::TABLE_SLOTS;
        $bookings_table = $wpdb->prefix . self::TABLE_SLOT_BOOKINGS;

        $wpdb->query("DROP TABLE IF EXISTS $bookings_table");
        $wpdb->query("DROP TABLE IF EXISTS $slots_table");

        delete_option('at_booking_tables_created');
    }

    /**
     * Get slots table name
     */
    public static function get_slots_table() {
        global $wpdb;
        return $wpdb->prefix . self::TABLE_SLOTS;
    }

    /**
     * Get slot bookings table name
     */
    public static function get_slot_bookings_table() {
        global $wpdb;
        return $wpdb->prefix . self::TABLE_SLOT_BOOKINGS;
    }

    /**
     * Check if tables exist
     */
    public static function tables_exist() {
        global $wpdb;
        
        $slots_table = self::get_slots_table();
        $bookings_table = self::get_slot_bookings_table();

        return ($wpdb->get_var("SHOW TABLES LIKE '$slots_table'") === $slots_table &&
                $wpdb->get_var("SHOW TABLES LIKE '$bookings_table'") === $bookings_table);
    }

    /**
     * Truncate tables (for reset)
     */
    public static function truncate_tables() {
        global $wpdb;
        
        $slots_table = self::get_slots_table();
        $bookings_table = self::get_slot_bookings_table();

        $wpdb->query("TRUNCATE TABLE $bookings_table");
        $wpdb->query("TRUNCATE TABLE $slots_table");
    }
    
    /**
     * Populate initial slots from existing bookings
     */
    public static function populate_initial_slots() {
        global $wpdb;
        
        if (!self::tables_exist()) {
            return false;
        }
        
        // Get all booking products
        $booking_products = $wpdb->get_col(
            "SELECT p.ID FROM {$wpdb->posts} p
            JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
            WHERE p.post_type = 'product'
            AND p.post_status = 'publish'
            AND pm.meta_key = '_virtual'
            AND pm.meta_value = 'yes'"
        );
        
        $generated_count = 0;
        
        foreach ($booking_products as $product_id) {
            if (class_exists('AT_Bookings_Slots_Manager')) {
                $result = AT_Bookings_Slots_Manager::generate_slots_for_product($product_id, 90); // 3 months
                if ($result['success']) {
                    $generated_count += $result['generated'];
                }
            }
        }
        
        // Log the population
        update_option('at_slots_initial_population', current_time('mysql'));
        update_option('at_slots_initial_count', $generated_count);
        
        return $generated_count;
    }
}
