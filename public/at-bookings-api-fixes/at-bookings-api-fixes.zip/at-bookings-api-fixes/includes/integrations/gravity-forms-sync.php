<?php
/**
 * Gravity Forms to Zoho CRM Sync Integration
 * 
 * Syncs Gravity Forms submissions (Form ID 4 - Membership Signup) to Zoho CRM
 * Uses the existing AT_Zoho_Sync_Service infrastructure
 * 
 * @package AT_Bookings_API_Fixes
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Hook into Gravity Forms entry submission
 * Uses config filter at_zoho_gform_config to determine which forms to sync
 */
add_action('gform_entry_created', 'at_gform_sync_to_zoho', 10, 2);

/**
 * Tagged logger for the Gravity Forms → Zoho path.
 *
 * Lines for Form ID 3 (סיור פרטי) get the [GF_PRIVATE_TOUR] tag so the user
 * can isolate that flow in custom.log; everything else gets the generic
 * [GF_SYNC] tag.
 *
 * @param int|string $form_id
 * @param string     $message
 * @param string     $level
 * @param array      $context
 */
function at_gf_sync_log($form_id, $message, $level = 'INFO', $context = array()) {
    if (!function_exists('write_detailed_log')) {
        return;
    }
    $tag  = ((int) $form_id === 3) ? '[GF_PRIVATE_TOUR]' : '[GF_SYNC]';
    $line = $tag . ' ' . $message;
    if (!empty($context)) {
        $line .= ' | ' . wp_json_encode($context, JSON_UNESCAPED_UNICODE);
    }
    write_detailed_log($line, $level);
}

/**
 * Sanitize a Zoho payload against the module's live schema BEFORE we ship it.
 *
 * Why: GForm Sync Settings lets an admin map any Gravity Forms field to any
 * Zoho field. Nothing in that UI prevents mapping a free-text field (e.g.
 * "הרכב משתתפים" → "מבוגרים") onto a Zoho field declared as integer/double
 * (e.g. No_of_Employees). When that happens Zoho rejects the whole payload
 * with INVALID_DATA and the Lead/Contact never gets created. Real example:
 *
 *   {"code":"INVALID_DATA","details":{"expected_data_type":"integer",
 *    "api_name":"No_of_Employees"},"message":"invalid data"}
 *
 * This sanitizer looks up each api_name in the module schema (cached 15 min
 * via AT_Zoho_Fields) and, for fields whose type is numeric/date/etc., either
 * coerces the value or removes it from the payload entirely. The removed
 * value is rescued into a single "rescued" buffer that the caller can append
 * to Description so we never lose the customer's actual answer.
 *
 * @param array  $payload  api_name => value
 * @param string $module   "Leads" | "Contacts" | ...
 * @param int    $form_id  for the tagged logger
 * @return array{payload: array, rescued: array<string,string>}  cleaned payload + map of removed fields
 */
function at_gf_zoho_sanitize_payload($payload, $module, $form_id) {
    if (!class_exists('AT_Zoho_Fields')) {
        return array('payload' => $payload, 'rescued' => array());
    }

    $schema = AT_Zoho_Fields::get_module_fields($module);
    if (empty($schema) || !is_array($schema)) {
        // No schema available — can't sanitize. Better to ship as-is than block.
        return array('payload' => $payload, 'rescued' => array());
    }

    // Build api_name → field-type lookup once. Zoho's metadata API uses
    // several different keys for the same concept depending on the field —
    // `field_type` was the legacy v2 name and is missing from many v6 fields;
    // `data_type` / `json_type` are the canonical v6 keys. We prefer the
    // most specific available, with `data_type` as the primary source.
    $type_by_name = array();
    $label_by_name = array();
    foreach ($schema as $f) {
        if (!isset($f['api_name'])) {
            continue;
        }
        $type = '';
        if (!empty($f['data_type']))  { $type = $f['data_type']; }
        elseif (!empty($f['field_type'])) { $type = $f['field_type']; }
        elseif (!empty($f['json_type']))  { $type = $f['json_type']; }
        $type_by_name[$f['api_name']]  = $type;
        $label_by_name[$f['api_name']] = isset($f['field_label']) ? $f['field_label'] : $f['api_name'];
    }

    // Zoho field types that expect a numeric value. Covers both legacy
    // (field_type=number/currency) and v6 (data_type=integer/double/...) names.
    $numeric_types = array('number', 'bigint', 'integer', 'autonumber', 'currency', 'double', 'decimal', 'percent');

    $rescued = array();
    $clean   = array();

    foreach ($payload as $api_name => $value) {
        // Skip null/empty — Zoho ignores them anyway and we want to preserve
        // the upstream behaviour of letting empty strings through.
        if ($value === null || $value === '') {
            $clean[$api_name] = $value;
            continue;
        }

        // Field not in schema? Pass through — Zoho will tell us if it's wrong,
        // and we don't want to drop legitimate custom fields the cache missed.
        if (!isset($type_by_name[$api_name])) {
            $clean[$api_name] = $value;
            continue;
        }

        $type = strtolower($type_by_name[$api_name]);

        // Numeric fields: keep if value is numeric (cast to int/float), else rescue.
        if (in_array($type, $numeric_types, true)) {
            if (is_numeric($value)) {
                // Coerce: integer types → int, double/decimal → float.
                $clean[$api_name] = in_array($type, array('double', 'decimal', 'currency', 'percent'), true)
                    ? (float) $value
                    : (int) $value;
            } else {
                $label = $label_by_name[$api_name];
                $rescued[$api_name] = $label . ': ' . (is_scalar($value) ? (string) $value : wp_json_encode($value, JSON_UNESCAPED_UNICODE));
                at_gf_sync_log($form_id, 'Removed non-numeric value from numeric Zoho field', 'WARNING', array(
                    'api_name' => $api_name,
                    'field_label' => $label,
                    'zoho_type' => $type,
                    'value'    => $value,
                    'rescued_to' => 'Description',
                ));
            }
            continue;
        }

        // Default: keep as-is. Strings, picklists, emails, phones etc. are
        // validated upstream by AT_Zoho_Fields::validate_field_value(), and
        // we don't want this sanitizer to second-guess them.
        $clean[$api_name] = $value;
    }

    // If we rescued anything, append it to Description so the data isn't lost.
    if (!empty($rescued)) {
        $append = "\n\n--- שדות שלא התאימו לסכמת Zoho ועברו לתיאור ---\n" . implode("\n", $rescued);
        $existing = isset($clean['Description']) ? $clean['Description'] : '';
        $clean['Description'] = trim($existing . $append);
    }

    return array('payload' => $clean, 'rescued' => $rescued);
}

/**
 * Get configuration for enabled forms
 * 
 * @return array Map of Form ID => Settings
 */
function at_get_zoho_gform_config()
{
	$defaults = array(
		4 => array(
			'module' => 'Contacts',
			'title' => 'הצטרפות למועדון',
			'opt_in_field_id' => 12,
			'full_name_field_id' => array( 1,14 )
		),
		2 => array(
			'module' => 'Leads',
			'title' => 'דברו איתנו',
			'opt_in_field_id' => 12,
			'full_name_field_id' => 1
		),
		3 => array(
			'module' => 'Leads',
			'title' => 'סיור פרטי',
			'full_name_field_id' => 3,
			'opt_in_field_id' => 17,
		),
		1 => array(
			'module' => 'Leads',
			'title' => 'הצטרפות לצוות ארטרנטיב'
		)
	);

	// Dynamically add all active Gravity Forms
	if (class_exists('GFAPI')) {
		$forms = GFAPI::get_forms(true, false); // Active forms only
		if (is_array($forms)) {
			foreach ($forms as $form) {
				$form_id = (int) $form['id'];
				// Don't overwrite existing configs (like form 4)
				if (!isset($defaults[$form_id])) {
					$defaults[$form_id] = array(
						'module' => 'Contacts', // Default to Contacts
						'title' => $form['title'],
						'source' => $form['title']
					);
				}
			}
		}
	}

	// Apply filter to allow external modifications (e.g. from functions.php)
	return apply_filters('at_zoho_gform_config', $defaults);
}

/**
 * Core sync logic - used by both automatic and manual sync
 * 
 * @param array $entry The entry object
 * @param array $form The form object
 * @param bool $return_result Whether to return result (for AJAX) or just log
 * @return array|null Result array if $return_result=true, null otherwise
 */
function at_gform_sync_contact_to_zoho($entry, $form, $return_result = false)
{
	$form_id = (int) $form['id'];
	$config = at_get_zoho_gform_config();

	at_gf_sync_log($form_id, 'Sync started', 'INFO', array(
		'form_id'    => $form_id,
		'form_title' => isset($form['title']) ? $form['title'] : '',
		'entry_id'   => isset($entry['id']) ? $entry['id'] : null,
	));

	// Check if form is configured for sync
	if (!array_key_exists($form_id, $config)) {
		at_gf_sync_log($form_id, 'Skip: form is not configured for sync', 'INFO', array(
			'form_id'           => $form_id,
			'configured_forms'  => array_keys($config),
		));
		return $return_result ? array('success' => false, 'message' => 'טופס זה אינו מוגדר לסנכרון') : null;
	}

	$form_config = $config[$form_id];
	$target_module = isset($form_config['module']) ? $form_config['module'] : 'Contacts';

	at_gf_sync_log($form_id, 'Target module resolved', 'INFO', array(
		'target_module' => $target_module,
		'form_config'   => $form_config,
	));

	// Check if Zoho is configured and sync service is available
	if (!class_exists('AT_Zoho_Modules') || !class_exists('AT_Zoho_CRM')) {
		$error = 'Zoho sync service not available';
		at_gf_sync_log($form_id, 'Skip: Zoho classes not loaded', 'ERROR');
		return $return_result ? array('success' => false, 'message' => $error) : null;
	}

	// Check if Zoho is configured
	if (!AT_Zoho_CRM::is_configured()) {
		$error = 'Zoho CRM לא מוגדר';
		at_gf_sync_log($form_id, 'Skip: Zoho CRM not configured', 'WARNING');
		return $return_result ? array('success' => false, 'message' => $error) : null;
	}

	try {
		// Extract form data
		$contact_data = at_extract_gform_contact_data($entry, $form, $form_config);

		// Allow config to override source/Reffe if not mapped
		if (isset($form_config['source'])) {
			$contact_data['source'] = $form_config['source'];
		}

		if (empty($contact_data['email'])) {
			$error = 'כתובת אימייל חסרה ברשומה';
			if (function_exists('write_detailed_log')) {
				write_detailed_log('Gravity Forms Entry #' . $entry['id'] . ' has no email address', 'WARNING');
			}
			return $return_result ? array('success' => false, 'message' => $error) : null;
		}

		// Get Zoho Modules instance
		$zoho_modules = AT_Zoho_Modules::get_instance();

		// Get form name for Reffe field
		$form_name = !empty($form['title']) ? $form['title'] : 'טופס אתר';

		// Override form name if set in config
		if (isset($form_config['title'])) {
			$form_name = $form_config['title'];
		}

		// ==============================================================================
		// 1. SYNC CONTACT (Always create/update Contact first to ensure existence & link)
		// ==============================================================================
		
		// Use the mapper to prepare contact data
		if (class_exists('AT_Zoho_Mapper')) {
			$zoho_contact_data = AT_Zoho_Mapper::map_to_contact(
				$contact_data,
				array(
					'form_name' => $form_name,
					'email_opt_in' => $contact_data['email_opt_in'] // Pass opt-in value
				)
			);
		} else {
			// Fallback - manual mapping
			$zoho_contact_data = array(
				'Email' => $contact_data['email'],
				'First_Name' => $contact_data['firstname'],
				'Last_Name' => !empty($contact_data['lastname']) ? $contact_data['lastname'] : (!empty($contact_data['firstname']) ? $contact_data['firstname'] : 'לקוח חדש'),
				'Phone' => $contact_data['phone'],
				'Description' => $contact_data['notes'],
				'Reffe' => $form_name,
				'Email_Opt_In' => $contact_data['email_opt_in'] ? 'כן' : 'לא',
			);
		}

		// Add Full Entry Dump to Description/Notes
		if (!empty($contact_data['full_entry_dump'])) {
			$existing_notes = isset($zoho_contact_data['Description']) ? $zoho_contact_data['Description'] : '';
			$zoho_contact_data['Description'] = trim($existing_notes . "\n\n" . $contact_data['full_entry_dump']);
		}

		// Apply admin-selected "aggregated description" — fields the admin marked as
		// "כלול בתיאור" are joined as "label: value" lines and written to the
		// configured aggregate_target field (defaults to Description).
		if (!empty($contact_data['aggregated_description'])) {
			$agg_target = !empty($contact_data['aggregate_target']) ? $contact_data['aggregate_target'] : 'Description';
			$existing = isset($zoho_contact_data[$agg_target]) ? $zoho_contact_data[$agg_target] : '';
			$zoho_contact_data[$agg_target] = trim($existing . ($existing !== '' ? "\n\n" : '') . $contact_data['aggregated_description']);
		}

		// Apply explicit per-field mapping from the admin UI on top of everything else.
		// These values override any semantic/auto-detected mapping for the same Zoho api_name.
		if (!empty($contact_data['direct_zoho_fields']) && is_array($contact_data['direct_zoho_fields'])) {
			foreach ($contact_data['direct_zoho_fields'] as $zoho_api_name => $value) {
				if ($zoho_api_name === '' || $value === null || $value === '') {
					continue;
				}
				$zoho_contact_data[$zoho_api_name] = $value;
			}
		}

		// Sanitize against the Contacts module schema (strips e.g. free text
		// that got mapped onto a numeric field — see at_gf_zoho_sanitize_payload
		// docblock). Rescued values are rolled into Description.
		$sanitized = at_gf_zoho_sanitize_payload($zoho_contact_data, 'Contacts', $form_id);
		$zoho_contact_data = $sanitized['payload'];

		// Sync Contact
		$contact_id = null;
		$contact_action = '';
		$existing_contact = $zoho_modules->search_contact($contact_data['email']);

		if (!empty($existing_contact) && isset($existing_contact['id'])) {
			$contact_id = $existing_contact['id'];
			$zoho_modules->update_record('Contacts', $contact_id, $zoho_contact_data);
			$contact_action = 'UPDATE';
			at_log_gform_sync($entry['id'], 'UPDATE', $contact_id, $zoho_contact_data, 'Contacts');
			at_add_gform_note($entry['id'], $contact_id, 'UPDATE', 'Contacts');
		} else {
			$new_contact = $zoho_modules->create_contact($zoho_contact_data);
			if ($new_contact && isset($new_contact['id'])) {
				$contact_id = $new_contact['id'];
				$contact_action = 'CREATE';
				at_log_gform_sync($entry['id'], 'CREATE', $contact_id, $zoho_contact_data, 'Contacts');
				at_add_gform_note($entry['id'], $contact_id, 'CREATE', 'Contacts');
			} else {
				// search_contact() sometimes misses existing records due to Zoho's
				// search index lag (Created_Time can take minutes to be searchable).
				// In that case create_contact() comes back with DUPLICATE_DATA and
				// helpfully includes the existing record's id — extract it and UPDATE
				// rather than leaving $contact_id empty (which would break Lead linking
				// downstream and produce orphan records).
				$dupe_id = at_extract_zoho_duplicate_id($new_contact);
				if ($dupe_id !== '') {
					$contact_id = $dupe_id;
					$zoho_modules->update_record('Contacts', $contact_id, $zoho_contact_data);
					$contact_action = 'UPDATE';
					at_log_gform_sync($entry['id'], 'UPDATE', $contact_id, $zoho_contact_data, 'Contacts');
					at_add_gform_note($entry['id'], $contact_id, 'UPDATE', 'Contacts');
					if (function_exists('write_detailed_log')) {
						write_detailed_log("Gravity Forms Entry #{$entry['id']}: contact recovered via DUPLICATE_DATA fallback (ID: {$contact_id})", 'INFO');
					}
				} else if (function_exists('write_detailed_log')) {
					$err = is_array($new_contact) && isset($new_contact['message']) ? substr($new_contact['message'], 0, 300) : 'no ID returned';
					write_detailed_log("Gravity Forms Entry #{$entry['id']}: contact create FAILED and DUPLICATE_DATA fallback did not yield an ID — {$err}", 'ERROR');
				}
			}
		}

		if (function_exists('write_detailed_log')) {
			write_detailed_log("Gravity Forms Entry #{$entry['id']} synced to Contacts (ID: {$contact_id})", 'INFO');
		}

		// ==============================================================================
		// 2. SYNC LEAD (If configured as Lead, create Lead and link to Contact)
		// ==============================================================================
		
		if ($target_module === 'Leads') {
			// Prepare Lead Data (based on contact data + lead specifics)
			$zoho_lead_data = $zoho_contact_data;
			
			// Lead specific fields
			$zoho_lead_data['Lead_Source'] = $form_name;
			if (empty($zoho_lead_data['Company'])) {
				$zoho_lead_data['Company'] = 'פרטי';
			}
			
			// Linking Lead↔Contact: in Zoho's Leads module there is no standard
			// "Contact_Name" lookup field — Leads and Contacts are deliberately
			// separate entities (Leads are converted into Contacts). The previous
			// 'Contact_Name_ID' assignment caused Zoho to reject the whole payload
			// with INVALID_DATA, which is why Form 3 (סיור פרטי) Leads never
			// arrived in the "דברו איתנו" view. The Contact and the Lead are
			// already linked by Email — which is how the Zoho view groups them.

			// Sanitize the Lead payload against the Leads module schema —
			// same protection as the Contacts path. This is what actually
			// fixed Form 3 (סיור פרטי) sync after the Contact_Name_ID fix:
			// real-world Form 3 submissions were getting INVALID_DATA on
			// No_of_Employees (mapped to a free-text answer like "מבוגרים").
			$sanitized_lead = at_gf_zoho_sanitize_payload($zoho_lead_data, 'Leads', $form_id);
			$zoho_lead_data = $sanitized_lead['payload'];

			at_gf_sync_log($form_id, 'About to sync Lead', 'INFO', array(
				'email'   => $contact_data['email'],
				'payload' => $zoho_lead_data,
				'rescued_fields' => array_keys($sanitized_lead['rescued']),
			));

			// Sync Lead
			$lead_id = null;

			// Check if lead exists? Usually for forms we create new leads or update existing
			// But for "Contact Us" we might want a new Lead every time?
			// Standard practice: Search by email to update or create.
			if (method_exists($zoho_modules, 'search_lead')) {
				$existing_lead = $zoho_modules->search_lead('Email', $contact_data['email']);
			}

			if (!empty($existing_lead) && isset($existing_lead['id'])) {
				$lead_id = $existing_lead['id'];
				$update_response = $zoho_modules->update_record('Leads', $lead_id, $zoho_lead_data);
				at_log_gform_sync($entry['id'], 'UPDATE', $lead_id, $zoho_lead_data, 'Leads');
				at_add_gform_note($entry['id'], $lead_id, 'UPDATE', 'Leads');
				at_gf_sync_log($form_id, 'Lead UPDATED in Zoho', 'INFO', array(
					'lead_id'  => $lead_id,
					'response' => $update_response,
				));
			} else {
				if (method_exists($zoho_modules, 'create_lead')) {
					$new_lead = $zoho_modules->create_lead($zoho_lead_data);
					at_gf_sync_log($form_id, 'create_lead() returned', 'INFO', array(
						'response' => $new_lead,
					));
					if ($new_lead && isset($new_lead['id'])) {
						$lead_id = $new_lead['id'];
						at_log_gform_sync($entry['id'], 'CREATE', $lead_id, $zoho_lead_data, 'Leads');
						at_add_gform_note($entry['id'], $lead_id, 'CREATE', 'Leads');
						at_gf_sync_log($form_id, 'SUCCESS: Lead created in Zoho', 'INFO', array(
							'lead_id' => $lead_id,
						));
					} else {
						// Same Zoho search-index lag handling as Contacts above:
						// recover the existing Lead ID from the DUPLICATE_DATA response.
						$dupe_id = at_extract_zoho_duplicate_id($new_lead);
						if ($dupe_id !== '') {
							$lead_id = $dupe_id;
							$zoho_modules->update_record('Leads', $lead_id, $zoho_lead_data);
							at_log_gform_sync($entry['id'], 'UPDATE', $lead_id, $zoho_lead_data, 'Leads');
							at_add_gform_note($entry['id'], $lead_id, 'UPDATE', 'Leads');
							at_gf_sync_log($form_id, 'Lead recovered via DUPLICATE_DATA fallback', 'INFO', array(
								'lead_id' => $lead_id,
							));
						} else {
							$err = is_array($new_lead) && isset($new_lead['message']) ? substr($new_lead['message'], 0, 300) : 'no ID returned';
							at_gf_sync_log($form_id, 'FAILED: lead create rejected by Zoho and no duplicate ID to recover', 'ERROR', array(
								'zoho_error' => $err,
								'response'   => $new_lead,
							));
						}
					}
				}
			}

			at_gf_sync_log($form_id, 'Lead sync finished', 'INFO', array(
				'lead_id' => $lead_id,
			));
			
			// Return Lead result as primary
			if ($return_result) {
				return array(
					'success' => true,
					'action' => $lead_id ? 'CREATE/UPDATE' : 'FAILED',
					'contact_id' => $lead_id, // For backward compatibility with UI expecting 'contact_id'
					'lead_id' => $lead_id,
					'related_contact_id' => $contact_id,
					'zoho_url' => at_get_zoho_contact_url($lead_id, 'Leads'),
					'message' => 'סונכרן בהצלחה ל-Leads ו-Contacts!'
				);
			}
		}

		// ==============================================================================
		// 3. SYNC TO ARBITRARY MODULE (e.g. Deals, Cases, custom modules from settings)
		// ==============================================================================
		if ($target_module !== 'Contacts' && $target_module !== 'Leads') {
			$custom_data = $zoho_contact_data;
			$custom_data['Lead_Source'] = $form_name;

			// Link to Contact if module supports a Contact_Name lookup
			if ($contact_id) {
				$custom_data['Contact_Name'] = $contact_id;
			}

			$custom_record_id = null;
			try {
				$new_record = $zoho_modules->create_record($target_module, $custom_data);
				if ($new_record && isset($new_record['id'])) {
					$custom_record_id = $new_record['id'];
					at_log_gform_sync($entry['id'], 'CREATE', $custom_record_id, $custom_data, $target_module);
					at_add_gform_note($entry['id'], $custom_record_id, 'CREATE', $target_module);
				}
			} catch (Exception $e) {
				if (function_exists('write_detailed_log')) {
					write_detailed_log("Gravity Forms Entry #{$entry['id']} sync to {$target_module} failed: " . $e->getMessage(), 'ERROR');
				}
				if ($return_result) {
					return array('success' => false, 'message' => sprintf(__('שגיאה ביצירת רשומה ב-%s: %s', 'at-bookings-api-fixes'), $target_module, $e->getMessage()));
				}
			}

			if (function_exists('write_detailed_log')) {
				write_detailed_log("Gravity Forms Entry #{$entry['id']} synced to {$target_module} (ID: {$custom_record_id})", 'INFO');
			}

			if ($return_result) {
				return array(
					'success' => (bool) $custom_record_id,
					'action' => $custom_record_id ? 'CREATE' : 'FAILED',
					'contact_id' => $custom_record_id, // UI expects this key
					'record_id' => $custom_record_id,
					'module' => $target_module,
					'related_contact_id' => $contact_id,
					'zoho_url' => $custom_record_id ? at_get_zoho_contact_url($custom_record_id, $target_module) : '',
					'message' => sprintf(__('סונכרן בהצלחה ל-%s ול-Contacts!', 'at-bookings-api-fixes'), $target_module),
				);
			}
		}

		// Return Contact result (if not Leads)
		if ($return_result) {
			return array(
				'success' => true,
				'action' => $contact_action,
				'contact_id' => $contact_id,
				'zoho_url' => at_get_zoho_contact_url($contact_id, 'Contacts'),
				'message' => 'סונכרן בהצלחה ל-Contacts!'
			);
		}

	} catch (Exception $e) {
		if (function_exists('write_detailed_log')) {
			write_detailed_log(
				'Gravity Forms Zoho Sync Error (Entry #' . $entry['id'] . '): ' . $e->getMessage(),
				'ERROR'
			);
		}

		if ($return_result) {
			return array('success' => false, 'message' => 'שגיאה: ' . $e->getMessage());
		}
	}

	return null;
}

/**
 * Wrapper for automatic sync (called by gform_entry_created hook)
 * 
 * @param array $entry The entry that was created
 * @param array $form The form that was submitted
 */
function at_gform_sync_to_zoho($entry, $form)
{
	at_gform_sync_contact_to_zoho($entry, $form, false);
}

/**
 * Extract and map Gravity Forms fields to Zoho lead properties
 * 
 * @param array $entry The form entry
 * @param array $form The form object
 * @return array Mapped contact data for Zoho
 */
function at_extract_gform_contact_data($entry, $form, $config = array())
{
	$data = array(
		'email' => '',
		'firstname' => '',
		'lastname' => '',
		'phone' => '',
		'company' => '',
		'source' => !empty($form['title']) ? $form['title'] : 'טופס אתר',
		'email_opt_in' => false,
		'notes' => '',
		'full_entry_dump' => '',
		// New: explicit GForm-field → Zoho-field values from the admin's mapping UI.
		// Keyed by Zoho api_name (e.g. ['First_Name' => 'Yossi', 'Custom_Field_X' => '...'])
		// Consumed in at_gform_sync_contact_to_zoho() and merged into the payload sent to Zoho.
		'direct_zoho_fields' => array(),
		// New: aggregated description blob (label: value lines) for fields the admin
		// marked as "כלול בתיאור". The target Zoho api_name is in 'aggregate_target'.
		'aggregated_description' => '',
		'aggregate_target'       => 'Description',
	);

	// 🔍 DEBUG: Log entry start
	if (function_exists('write_detailed_log')) {
		write_detailed_log("🟢 GRAVITY FORMS ENTRY PROCESSING START", 'DEBUG');
		write_detailed_log("   Form ID: " . $form['id'], 'DEBUG');
		write_detailed_log("   Form Title: " . $form['title'], 'DEBUG');
		write_detailed_log("   Total fields in entry: " . count($entry), 'DEBUG');
	}

	// 0. Manual Configuration Mapping (Priority)
	if (!empty($config['full_name_field_id'])) {
		if (is_array($config['full_name_field_id'])) {
			// Handle composite name (First Name + Last Name fields)
			$first_id = isset($config['full_name_field_id']['first']) ? $config['full_name_field_id']['first'] : (isset($config['full_name_field_id'][0]) ? $config['full_name_field_id'][0] : null);
			$last_id  = isset($config['full_name_field_id']['last'])  ? $config['full_name_field_id']['last']  : (isset($config['full_name_field_id'][1]) ? $config['full_name_field_id'][1] : null);
			
			if ($first_id) $data['firstname'] = rgar($entry, $first_id);
			if ($last_id)  $data['lastname']  = rgar($entry, $last_id);
			
			if (function_exists('write_detailed_log')) {
				write_detailed_log("   Mapped Composite Name: First(#{$first_id})='{$data['firstname']}', Last(#{$last_id})='{$data['lastname']}'", 'DEBUG');
			}
		} else {
			// Handle single Full Name field
			$full_name = rgar($entry, $config['full_name_field_id']);
			if (!empty($full_name)) {
				$parts = explode(' ', trim($full_name), 2);
				$data['firstname'] = isset($parts[0]) ? $parts[0] : '';
				$data['lastname'] = isset($parts[1]) ? $parts[1] : '';
				if (function_exists('write_detailed_log')) {
					write_detailed_log("   Mapped Full Name (Field {$config['full_name_field_id']}): {$data['firstname']} {$data['lastname']}", 'DEBUG');
				}
			}
		}
	}

	if (!empty($config['opt_in_field_id'])) {
		$opt_in_field_id = $config['opt_in_field_id'];
		$opt_in_val = rgar($entry, $opt_in_field_id);
		
		// Fix: Check sub-field .1 if main field is empty (common for single checkbox)
		if (empty($opt_in_val)) {
			$opt_in_val = rgar($entry, $opt_in_field_id . '.1');
		}

		// Check if checked (1, true, 'on', or field label)
		// Gravity Forms checkboxes usually store value as the field ID key if checked, but rgar gets the value.
		// If checkbox has choices, value is the choice value.
		$is_checked = (!empty($opt_in_val));
		
		$data['email_opt_in'] = $is_checked;
		if (function_exists('write_detailed_log')) {
			write_detailed_log("   Mapped Opt-in (Field {$config['opt_in_field_id']}): " . ($is_checked ? 'TRUE' : 'FALSE') . " (Val: " . json_encode($opt_in_val) . ")", 'DEBUG');
		}
	}

	// 0b. Direct field mappings from admin settings (priority over auto-detection)
	if (!empty($config['email_field_id'])) {
		$val = rgar($entry, $config['email_field_id']);
		if (!empty($val)) {
			$data['email'] = sanitize_email($val);
		}
	}
	if (!empty($config['phone_field_id'])) {
		$val = rgar($entry, $config['phone_field_id']);
		if (!empty($val)) {
			$data['phone'] = sanitize_text_field($val);
		}
	}
	if (!empty($config['notes_field_id'])) {
		$val = rgar($entry, $config['notes_field_id']);
		if (!empty($val)) {
			$data['notes'] = sanitize_textarea_field(is_array($val) ? implode(', ', $val) : $val);
		}
	}

	// 1. Map specific fields by ID (Legacy logic + smart mapping)
	foreach ($entry as $field_id => $value) {
		if (!is_numeric($field_id) || empty($value))
			continue;

		// Skip if already mapped via config
		if (!empty($config['full_name_field_id'])) {
			if (is_array($config['full_name_field_id'])) {
				// Check if current field ID is in the mapping array values
				$mapped_ids = array_map('intval', $config['full_name_field_id']);
				if (in_array((int)$field_id, $mapped_ids)) continue;
			} elseif ((int)$field_id == (int)$config['full_name_field_id']) {
				continue;
			}
		}
		if (!empty($config['opt_in_field_id']) && (int)$field_id == (int)$config['opt_in_field_id']) continue;

		// Skip fields already mapped via admin settings
		$admin_mapped_keys = array('email_field_id', 'phone_field_id', 'notes_field_id');
		$skip_field = false;
		foreach ($admin_mapped_keys as $mapped_key) {
			if (!empty($config[$mapped_key]) && (int)$field_id == (int)$config[$mapped_key]) {
				$skip_field = true;
				break;
			}
		}
		if ($skip_field) continue;

		// Find the field definition
		$field = null;
		foreach ($form['fields'] as $f) {
			if ((int) $f->id === (int) $field_id) {
				$field = $f;
				break;
			}
		}
		if (!$field)
			continue;

		// Map fields based on type and label
		$field_label = strtolower($field->label ?? '');

		switch ($field->type) {
			case 'email':
				$data['email'] = sanitize_email($value);
				break;

			case 'text':
				if (stripos($field_label, 'שם פרטי') !== false || stripos($field_label, 'first') !== false) {
					$data['firstname'] = sanitize_text_field($value);
				} elseif (stripos($field_label, 'שם משפחה') !== false || stripos($field_label, 'last') !== false) {
					$data['lastname'] = sanitize_text_field($value);
				} elseif (stripos($field_label, 'חברה') !== false || stripos($field_label, 'company') !== false) {
					$data['company'] = sanitize_text_field($value);
				}
				break;

			case 'phone':
				$data['phone'] = sanitize_text_field($value);
				break;

			case 'checkbox':
				$opt_in_keywords = array('תנאים', 'terms', 'תקנון', 'דיוור', 'mailing', 'newsletter', 'רישום למועדון', 'הצטרפות למועדון', 'מועדון');
				foreach ($opt_in_keywords as $keyword) {
					if (stripos($field_label, $keyword) !== false) {
						$is_checked = ($value === $field->label || $value === 'on' || $value === '1' || $value === true);
						$data['email_opt_in'] = $is_checked;
						break;
					}
				}
				break;

			case 'textarea':
				if (stripos($field_label, 'הערות') !== false || stripos($field_label, 'comments') !== false) {
					$data['notes'] = sanitize_textarea_field($value);
				}
				break;
		}
	}

	// 2. Generate Full Entry Dump (All fields)
	$dump_lines = array();
	$dump_lines[] = "=== סיכום טופס: " . $form['title'] . " ===";
	$dump_lines[] = "תאריך: " . current_time('Y-m-d H:i:s');
	$dump_lines[] = "---";

	foreach ($form['fields'] as $field) {
		// Skip layout fields
		if (in_array($field->type, array('html', 'section', 'page', 'captcha'))) {
			continue;
		}

		// Get value
		$val = rgar($entry, $field->id);
		if ($val === '')
			continue;

		// Get display value (human readable)
		if (class_exists('GFCommon')) {
			$display_value = GFCommon::get_lead_field_display($field, $val, $entry['currency']);
			$display_value = strip_tags($display_value);
		} else {
			$display_value = is_array($val) ? json_encode($val, JSON_UNESCAPED_UNICODE) : $val;
		}

		if (!empty($display_value)) {
			$dump_lines[] = $field->label . ": " . $display_value;
		}
	}
	$data['full_entry_dump'] = implode("\n", $dump_lines);

	// 3. Build explicit GForm-field → Zoho-field map AND aggregated description blob
	// from the admin settings. These are independent: a single GF field can be
	// both routed to a specific Zoho field (via field_mapping) AND included in
	// the aggregated description (via aggregated_fields). The aggregated blob is
	// written into the Zoho field named in config['aggregate_target']
	// (default "Description"). Legacy "__aggregate__" sentinel is still honored
	// for backward compatibility with previously-saved options.
	$data['aggregate_target'] = !empty($config['aggregate_target']) ? $config['aggregate_target'] : 'Description';

	$aggregated_fields_set = array();
	if (!empty($config['aggregated_fields']) && is_array($config['aggregated_fields'])) {
		foreach ($config['aggregated_fields'] as $gf_id) {
			$aggregated_fields_set[(string) $gf_id] = true;
		}
	}

	// Helper: resolve a GF field's submitted value into display text + field definition.
	$resolve_gf_value = function ($gf_field_id) use ($entry, $form) {
		$raw_value = rgar($entry, $gf_field_id);
		if ($raw_value === '' || $raw_value === null) {
			return array(null, null);
		}
		$field_def = null;
		foreach ($form['fields'] as $f) {
			if ((string) $f->id === (string) $gf_field_id) {
				$field_def = $f;
				break;
			}
		}
		$display_value = $raw_value;
		if ($field_def && class_exists('GFCommon')) {
			$rendered = GFCommon::get_lead_field_display($field_def, $raw_value, isset($entry['currency']) ? $entry['currency'] : '');
			$rendered = is_string($rendered) ? strip_tags($rendered) : $rendered;
			if (!empty($rendered)) {
				$display_value = $rendered;
			}
		} elseif (is_array($display_value)) {
			$display_value = implode(', ', array_filter($display_value));
		}
		return array($display_value, $field_def);
	};

	// 3a. Direct field mappings → keyed by Zoho api_name
	if (!empty($config['field_mapping']) && is_array($config['field_mapping'])) {
		foreach ($config['field_mapping'] as $gf_field_id => $zoho_api_name) {
			if ($gf_field_id === '' || $zoho_api_name === '') {
				continue;
			}
			// Legacy sentinel — treat as "aggregated only, no direct target"
			if ($zoho_api_name === '__aggregate__') {
				$aggregated_fields_set[(string) $gf_field_id] = true;
				continue;
			}
			list($display_value, $field_def) = $resolve_gf_value($gf_field_id);
			if ($display_value === null) {
				continue;
			}
			$data['direct_zoho_fields'][$zoho_api_name] = $display_value;
		}
	}

	// 3b. Aggregated description (independent — same field may already be mapped above)
	if (!empty($aggregated_fields_set)) {
		$aggregated_lines = array();
		foreach (array_keys($aggregated_fields_set) as $gf_field_id) {
			list($display_value, $field_def) = $resolve_gf_value($gf_field_id);
			if ($display_value === null) {
				continue;
			}
			$label = ($field_def && !empty($field_def->label)) ? $field_def->label : ('Field #' . $gf_field_id);
			$aggregated_lines[] = $label . ': ' . $display_value;
		}
		if (!empty($aggregated_lines)) {
			$data['aggregated_description'] = implode("\n", $aggregated_lines);
		}
	}

	if (function_exists('write_detailed_log')) {
		if (!empty($data['direct_zoho_fields'])) {
			write_detailed_log('   Direct Zoho field mapping: ' . wp_json_encode($data['direct_zoho_fields'], JSON_UNESCAPED_UNICODE), 'DEBUG');
		}
		if (!empty($data['aggregated_description'])) {
			write_detailed_log('   Aggregated description (' . count($aggregated_fields_set) . ' fields) → ' . $data['aggregate_target'], 'DEBUG');
		}
	}

	// 🔍 DEBUG: Log final extracted data
	if (function_exists('write_detailed_log')) {
		write_detailed_log("🟠 GRAVITY FORMS EXTRACTION COMPLETE", 'DEBUG');
		write_detailed_log("   Email: " . ($data['email'] ?: '(empty)'), 'DEBUG');
		write_detailed_log("   Full Dump Length: " . strlen($data['full_entry_dump']) . " chars", 'DEBUG');
	}

	return $data;
}

/**
 * Log Gravity Forms sync to Zoho logs table
 * 
 * Uses the existing wp_at_zoho_sync_log table with source = 'gravity_forms'
 * 
 * @param int $entry_id Gravity Forms entry ID
 * @param string $action Action (CREATE or UPDATE)
 * @param string $lead_id Zoho Lead ID
 * @param array $data Data that was synced
 */
function at_log_gform_sync($entry_id, $action, $contact_id, $data, $module = 'Contacts')
{
	global $wpdb;

	// Use the existing Zoho sync log table
	$table_name = $wpdb->prefix . 'at_zoho_sync_log';

	$wpdb->insert(
		$table_name,
		array(
			'sync_time' => current_time('mysql'),
			'source' => 'gravity_forms',
			'source_id' => $entry_id,
			'target_module' => $module, // Contacts or Leads
			'target_id' => $contact_id,
			'action' => $action,
			'status' => 'success',
			'data_sent' => wp_json_encode($data),
			'sync_type' => 'membership_signup',
		),
		array(
			'%s',
			'%s',
			'%d',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
		)
	);
}

/**
 * Add Zoho CRM Sync metabox to Gravity Forms entry detail screen
 */
add_action('gform_entry_detail_sidebar_middle', 'at_gform_add_zoho_sync_metabox', 10, 2);

/**
 * Display Zoho CRM Sync metabox on entry detail page
 * 
 * @param array $form The form object
 * @param array $entry The entry object
 */
function at_gform_add_zoho_sync_metabox($form, $entry)
{
	// Check if form is configured for sync
	$config = at_get_zoho_gform_config();
	if (!array_key_exists((int) $form['id'], $config)) {
		return;
	}

	// Gather every per-module sync record we know about for this entry.
	// Sources, in priority order (later sources fill in missing modules from earlier ones):
	//   1. GF entry meta (at_zoho_<Module>_id, written by at_save_gform_zoho_meta())
	//   2. Parsed Zoho-sync notes left by at_add_gform_note() (covers entries synced
	//      before the meta-saving code existed, AND covers earlier modules from
	//      multi-step syncs that only wrote meta for the last module)
	$known_modules = array();

	if (function_exists('gform_get_meta')) {
		foreach (array('Contacts', 'Leads') as $mod) {
			$mid = gform_get_meta($entry['id'], 'at_zoho_' . $mod . '_id');
			if (!empty($mid)) {
				$known_modules[$mod] = array(
					'id'        => (string) $mid,
					'synced_at' => (string) gform_get_meta($entry['id'], 'at_zoho_' . $mod . '_synced_at'),
				);
			}
		}
		// Include "last_module" (handles custom modules not in the Contacts/Leads pair above)
		$last_mod = gform_get_meta($entry['id'], 'at_zoho_last_module');
		$last_id  = gform_get_meta($entry['id'], 'at_zoho_last_id');
		if (!empty($last_mod) && !empty($last_id) && !isset($known_modules[$last_mod])) {
			$known_modules[$last_mod] = array(
				'id'        => (string) $last_id,
				'synced_at' => (string) gform_get_meta($entry['id'], 'at_zoho_last_synced_at'),
			);
		}
	}

	// Layer in anything we can recover from existing GF notes, and self-heal by
	// writing it to meta so we don't have to parse again next time.
	$notes_parsed = at_parse_all_zoho_from_gform_notes($entry['id']);
	foreach ($notes_parsed as $module => $info) {
		if (isset($known_modules[$module])) {
			continue;
		}
		$known_modules[$module] = array(
			'id'        => $info['id'],
			'synced_at' => $info['sync_time'],
		);
		// Backfill the entry meta so future loads are instant
		at_save_gform_zoho_meta($entry['id'], $info['id'], $module);
	}

	?>
	<div id="zoho-crm-sync" class="postbox">
		<h3 class="hndle" style="cursor: auto;">
			<span>Zoho CRM Sync</span>
		</h3>
		<div class="inside">
			<?php if (!empty($known_modules)): ?>
				<div class="at-sync-status" style="margin-bottom: 15px;">
					<p style="margin: 5px 0;">
						<strong>✅ סונכרן ל-Zoho:</strong>
					</p>
					<?php foreach ($known_modules as $module => $info):
						$module_label = ($module === 'Leads') ? 'Lead' : (($module === 'Contacts') ? 'Contact' : $module);
						$record_url   = at_get_zoho_contact_url($info['id'], $module);
					?>
						<p style="margin: 5px 0; padding: 10px; background: #f0f9ff; border-right: 3px solid #0ea5e9; direction: rtl;">
							<strong><?php echo esc_html($module_label); ?> ID:</strong>
							<code dir="ltr"><?php echo esc_html($info['id']); ?></code><br>
							<?php if (!empty($info['synced_at'])): ?>
								<strong>זמן סנכרון:</strong> <?php echo esc_html($info['synced_at']); ?><br>
							<?php endif; ?>
							<a href="<?php echo esc_url($record_url); ?>" target="_blank"
								style="color: #0ea5e9; text-decoration: none; font-weight: bold;">
								🔗 פתח ב-Zoho CRM →
							</a>
						</p>
					<?php endforeach; ?>
				</div>

				<button type="button" id="at-gf-sync-button" class="button"
					data-entry-id="<?php echo esc_attr($entry['id']); ?>" style="width: 100%;">
					🔄 סנכרן מחדש לזוהו
				</button>
			<?php else: ?>
				<p style="margin: 10px 0; color: #dc2626; font-weight: bold; direction: rtl;">
					⚠️ רשומה זו לא סונכרנה לזוהו
				</p>
				<button type="button" id="at-gf-sync-button" class="button button-primary"
					data-entry-id="<?php echo esc_attr($entry['id']); ?>" style="width: 100%;">
					✨ סנכרן לזוהו עכשיו
				</button>
			<?php endif; ?>

			<div id="at-gf-sync-message" style="margin-top: 10px;"></div>
		</div>
	</div>

	<script type="text/javascript">
		jQuery(document).ready(function ($) {
			$('#at-gf-sync-button').on('click', function () {
				var $button = $(this);
				var $message = $('#at-gf-sync-message');
				var entryId = $button.data('entry-id');

				$button.prop('disabled', true).text('⏳ מסנכרן...');
				$message.html('<p style="color: #666;">מסנכרן עם Zoho CRM...</p>');

				$.ajax({
					url: ajaxurl,
					type: 'POST',
					data: {
						action: 'at_gf_sync_to_zoho',
						entry_id: entryId,
						nonce: '<?php echo wp_create_nonce('at_gf_sync_' . $entry['id']); ?>'
					},
					success: function (response) {
						if (response.success) {
							$message.html(
								'<div style="padding: 10px; background: #d1fae5; border-right: 3px solid #10b981; margin: 10px 0; direction: rtl;">' +
								'<strong>✅ ' + response.data.message + '</strong><br>' +
								(response.data.lead_id ? 'Lead ID: ' + response.data.lead_id + '<br>' : '') +
								(response.data.zoho_url ? '<a href="' + response.data.zoho_url + '" target="_blank" style="color: #059669;">🔗 פתח ב-Zoho CRM →</a>' : '') +
								'</div>'
							);
							$button.prop('disabled', false).text('🔄 סנכרן מחדש');

							// Reload page after 2 seconds to show updated sync status
							setTimeout(function () {
								location.reload();
							}, 2000);
						} else {
							$message.html(
								'<div style="padding: 10px; background: #fee2e2; border-right: 3px solid #ef4444; margin: 10px 0; direction: rtl;">' +
								'<strong>❌ שגיאה:</strong> ' + response.data.message +
								'</div>'
							);
							$button.prop('disabled', false).text('🔄 נסה שוב');
						}
					},
					error: function (xhr, status, error) {
						$message.html(
							'<div style="padding: 10px; background: #fee2e2; border-right: 3px solid #ef4444; margin: 10px 0; direction: rtl;">' +
							'<strong>❌ שגיאת שרת:</strong> ' + error +
							'</div>'
						);
						$button.prop('disabled', false).text('🔄 נסה שוב');
					}
				});
			});
		});
	</script>
	<?php
}

/**
 * Get Zoho CRM Lead URL
 * 
 * @param string $lead_id Zoho Lead ID
 * @return string Zoho CRM URL
 */
function at_get_zoho_contact_url($record_id, $module = 'Contacts')
{
	// Zoho CRM URL format (production):
	//   https://crm.zoho.<domain>/crm/org<zgid>/tab/<Module>/<recordId>
	// e.g. https://crm.zoho.com/crm/org872898220/tab/Leads/6552120000015273001
	$zoho_domain = get_option('at_zoho_domain', 'com'); // com, eu, in, etc.
	$zoho_org_id = at_get_zoho_org_id();

	if (empty($zoho_org_id)) {
		// Unknown org — return record search URL instead of a broken deep link
		return "https://crm.zoho.{$zoho_domain}/crm/EntityInfo.do?module={$module}&id={$record_id}";
	}

	// Zoho's URL expects the "org" prefix followed by the numeric zgid
	// (org_id from settings is stored without the prefix).
	$org_segment = (strpos($zoho_org_id, 'org') === 0) ? $zoho_org_id : 'org' . $zoho_org_id;

	return "https://crm.zoho.{$zoho_domain}/crm/{$org_segment}/tab/{$module}/{$record_id}";
}

/**
 * Resolve the connected Zoho account's organization ID (zgid).
 *
 * Resolution order:
 *   1. Manual override stored as the `at_zoho_org_id` option.
 *   2. Auto-discovered value cached as `at_zoho_org_id_cache` transient (24h).
 *   3. Live fetch from Zoho's `/org` endpoint (cached on success).
 *
 * @return string Zoho zgid (numeric) without the "org" prefix, or '' if unknown.
 */
function at_get_zoho_org_id()
{
	$manual = get_option('at_zoho_org_id', '');
	if (!empty($manual)) {
		return ltrim(trim($manual), 'org');
	}

	$cached = get_transient('at_zoho_org_id_cache');
	if (!empty($cached)) {
		return $cached;
	}

	if (!class_exists('AT_Zoho_API') || !class_exists('AT_Zoho_CRM') || !AT_Zoho_CRM::is_configured()) {
		return '';
	}

	try {
		$org = AT_Zoho_API::get_instance()->get_organization();
	} catch (Exception $e) {
		return '';
	}

	if (!empty($org['zgid'])) {
		$zgid = (string) $org['zgid'];
		set_transient('at_zoho_org_id_cache', $zgid, DAY_IN_SECONDS);
		return $zgid;
	}
	return '';
}

// Backward compatibility alias
function at_get_zoho_lead_url($lead_id)
{
	return at_get_zoho_contact_url($lead_id, 'Leads');
}

/**
 * Extract the existing record ID from a Zoho DUPLICATE_DATA error response.
 *
 * Zoho's search-records endpoint has noticeable index lag (a record can take
 * minutes to be discoverable via /search after creation), so AT_Zoho_Modules
 * ::search_contact() and ::search_lead() routinely fail to find records that
 * actually exist. When we then attempt create_contact / create_lead, Zoho
 * rejects the call with HTTP 400 + code=DUPLICATE_DATA and includes the
 * existing record's id in the response body — we extract it here so the caller
 * can fall back to UPDATE instead of creating an orphan.
 *
 * @param mixed $response Whatever the create_* call returned (usually an array
 *                        shaped like ['success' => false, 'message' => '... Response: { JSON }']).
 * @return string Zoho record ID, or '' if not extractable.
 */
function at_extract_zoho_duplicate_id($response)
{
	if (!is_array($response) || empty($response['message'])) {
		return '';
	}
	$msg = (string) $response['message'];
	if (strpos($msg, 'DUPLICATE_DATA') === false) {
		return '';
	}

	// Preferred path: pull the JSON blob out of "Response: { ... }" and decode it.
	// Walks any nested Owner object correctly, unlike a flat regex.
	if (preg_match('/Response:\s*(\{.*\})\s*$/s', $msg, $m)) {
		$decoded = json_decode($m[1], true);
		if (is_array($decoded) && !empty($decoded['data'][0]['details'])) {
			$d = $decoded['data'][0]['details'];
			if (!empty($d['duplicate_record']['id'])) {
				return (string) $d['duplicate_record']['id'];
			}
			if (!empty($d['id'])) {
				return (string) $d['id'];
			}
		}
	}

	// Last-resort regex: the id sitting right before "more_records" in the
	// outer details object is the duplicate's id.
	if (preg_match('/"id":\s*"(\d+)"\s*,\s*"more_records"/', $msg, $m)) {
		return $m[1];
	}

	return '';
}

/**
 * AJAX handler for manual Gravity Forms to Zoho sync
 */
add_action('wp_ajax_at_gf_sync_to_zoho', 'at_gf_manual_sync_to_zoho');

/**
 * Handle manual sync from Gravity Forms entry detail page
 */
function at_gf_manual_sync_to_zoho()
{
	// Verify nonce
	$entry_id = isset($_POST['entry_id']) ? intval($_POST['entry_id']) : 0;

	if (!$entry_id || !wp_verify_nonce($_POST['nonce'], 'at_gf_sync_' . $entry_id)) {
		wp_send_json_error(array(
			'message' => 'אימות נכשל. אנא רענן את הדף ונסה שוב.'
		));
	}

	// Check user permissions
	if (!current_user_can('gravityforms_edit_entries')) {
		wp_send_json_error(array(
			'message' => 'אין לך הרשאות לבצע פעולה זו.'
		));
	}

	// Load Gravity Forms entry
	if (!class_exists('GFAPI')) {
		wp_send_json_error(array(
			'message' => 'Gravity Forms לא זמין.'
		));
	}

	$entry = GFAPI::get_entry($entry_id);
	if (is_wp_error($entry)) {
		wp_send_json_error(array(
			'message' => 'רשומה לא נמצאה (Entry ID: ' . $entry_id . ')'
		));
	}

	$form = GFAPI::get_form($entry['form_id']);
	if (is_wp_error($form)) {
		wp_send_json_error(array(
			'message' => 'טופס לא נמצא (Form ID: ' . $entry['form_id'] . ')'
		));
	}

	// Check if Zoho is configured
	if (!class_exists('AT_Zoho_CRM') || !AT_Zoho_CRM::is_configured()) {
		wp_send_json_error(array(
			'message' => 'Zoho CRM לא מוגדר. אנא הגדר את ההתחברות לזוהו.'
		));
	}

	// Log sync attempt
	if (function_exists('write_detailed_log')) {
		write_detailed_log(
			'[GF Sync] Manual sync requested for Entry #' . $entry_id . ' by user ' . get_current_user_id(),
			'INFO'
		);
	}

	// Use the centralized sync function
	$result = at_gform_sync_contact_to_zoho($entry, $form, true);

	if ($result && $result['success']) {
		wp_send_json_success($result);
	} else {
		wp_send_json_error($result ? $result : array('message' => 'סנכרון נכשל'));
	}
}

/**
 * Add note to Gravity Forms entry after successful Zoho sync
 * 
 * @param int $entry_id Gravity Forms entry ID
 * @param string $lead_id Zoho Lead ID
 * @param string $action Action performed (CREATE or UPDATE)
 */
function at_add_gform_note($entry_id, $record_id, $action, $module = 'Contacts')
{
	if (!class_exists('GFAPI')) {
		return;
	}

	$zoho_url = at_get_zoho_contact_url($record_id, $module);
	$action_text = ($action === 'CREATE') ? 'נוצר' : 'עודכן';
	$module_name = ($module === 'Contacts') ? 'Contact' : 'Lead';

	$note_text = sprintf(
		'<strong>🔗 Zoho CRM Sync</strong><br>' .
		'פעולה: %s<br>' .
		'מודול: %s<br>' .
		'Record ID: %s<br>' .
		'קישור: <a href="%s" target="_blank">פתח ב-Zoho CRM →</a><br>' .
		'זמן: %s',
		$action_text,
		$module_name,
		esc_html($record_id),
		esc_url($zoho_url),
		current_time('Y-m-d H:i:s')
	);

	GFAPI::add_note(
		$entry_id,
		0, // user_id (0 = system)
		get_bloginfo('name'), // user_name
		$note_text,
		'success'
	);

	// Persist the Zoho record ID on the GF entry itself so the entries-list
	// "Zoho" column can resolve it cheaply without depending on the sync log
	// table (which may not exist on this install).
	// Keys: at_zoho_<Module>_id, at_zoho_<Module>_synced_at, at_zoho_last_module
	at_save_gform_zoho_meta($entry_id, $record_id, $module);
}

/**
 * Save Zoho sync metadata on a Gravity Forms entry.
 *
 * @param int    $entry_id
 * @param string $record_id  Zoho record ID
 * @param string $module     Zoho module api_name (e.g. Contacts, Leads, Deals)
 */
function at_save_gform_zoho_meta($entry_id, $record_id, $module)
{
	if (!class_exists('GFAPI') || empty($entry_id) || empty($record_id) || empty($module)) {
		return;
	}
	$entry_id = (int) $entry_id;

	// Sanitize module to a safe meta-key suffix
	$module_key = preg_replace('/[^A-Za-z0-9_]/', '', $module);
	if ($module_key === '') {
		return;
	}

	$keys = array(
		'at_zoho_' . $module_key . '_id'         => (string) $record_id,
		'at_zoho_' . $module_key . '_synced_at'  => current_time('mysql'),
		'at_zoho_last_module'                    => $module,
		'at_zoho_last_id'                        => (string) $record_id,
		'at_zoho_last_synced_at'                 => current_time('mysql'),
	);

	foreach ($keys as $key => $value) {
		// gform_update_meta is the canonical GF API for entry meta
		if (function_exists('gform_update_meta')) {
			gform_update_meta($entry_id, $key, $value);
		}
	}
}

/**
 * ========================================
 * BULK ACTIONS - סנכרון מרובה
 * ========================================
 */

/**
 * Add "Sync to Zoho" to bulk actions dropdown.
 *
 * Gravity Forms 2.2.3.12+ uses gf_apply_filters( ['gform_entry_list_bulk_actions', $form_id], … )
 * to build the bulk-actions menu. We register on the unprefixed filter so it
 * applies to every form, and the handler verifies the form is configured.
 *
 * Note: this is NOT 'gform_entries_bulk_actions' — that filter doesn't exist
 * in modern Gravity Forms, which is why the menu item appeared (via the JS
 * fallback) but the server-side action never fired.
 */
add_filter('gform_entry_list_bulk_actions', 'at_gform_add_bulk_sync_action', 10, 2);
add_filter('gform_entries_bulk_actions', 'at_gform_add_bulk_sync_action', 10, 2); // legacy alias, harmless

function at_gform_add_bulk_sync_action($actions, $form_id = 0)
{
	// Get form ID from parameter or URL
	if (empty($form_id)) {
		$form_id = isset($_GET['id']) ? absint($_GET['id']) : 0;
	}

	// Debug logging
	if (function_exists('write_detailed_log')) {
		write_detailed_log(
			'[GF Bulk] Filter called for form ID: ' . $form_id . ' | Actions before: ' . implode(', ', array_keys($actions)),
			'INFO'
		);
	}

	// Check if form is configured for sync
	$config = at_get_zoho_gform_config();
	if (!array_key_exists((int) $form_id, $config)) {
		if (function_exists('write_detailed_log')) {
			write_detailed_log('[GF Bulk] Skipping - not a configured sync form', 'INFO');
		}
		return $actions;
	}

	// Add the sync action
	$actions['sync_to_zoho'] = 'סנכרן ל-Zoho CRM';

	if (function_exists('write_detailed_log')) {
		write_detailed_log(
			'[GF Bulk] Added sync action! Actions after: ' . implode(', ', array_keys($actions)),
			'INFO'
		);
	}

	return $actions;
}

/**
 * Handle bulk sync action.
 *
 * Hooked to gf_do_action( ['gform_entry_list_action', $action, $form_id], $action, $entries, $form_id )
 * which is fired by Gravity Forms 2.2+ after both single-entry actions and
 * bulk actions on the entries list. We filter to our action name and to the
 * forms configured in at_get_zoho_gform_config().
 *
 * Also kept the legacy gform_entries_bulk_action-sync_to_zoho hook for safety
 * in case a custom workflow still triggers it.
 */
add_action('gform_entry_list_action', 'at_gform_handle_entry_list_action', 10, 3);
add_action('gform_entries_bulk_action-sync_to_zoho', 'at_gform_handle_bulk_sync', 10, 3);

/**
 * @param string $action    e.g. 'sync_to_zoho'
 * @param array  $entry_ids
 * @param int    $form_id
 */
function at_gform_handle_entry_list_action($action, $entry_ids, $form_id)
{
	if ($action !== 'sync_to_zoho') {
		return;
	}
	if (!class_exists('GFAPI')) {
		return;
	}
	$form = GFAPI::get_form((int) $form_id);
	if (!$form || is_wp_error($form)) {
		return;
	}
	at_gform_handle_bulk_sync($form, $entry_ids, $action);
}

function at_gform_handle_bulk_sync($form, $entry_ids, $action)
{
	if ($action !== 'sync_to_zoho') {
		return;
	}

	// In modern GF the entries come via the hook param; in some flows we still
	// have to pull them out of POST ourselves. Cover both.
	if (empty($entry_ids)) {
		$posted = isset($_POST['entry']) ? wp_unslash($_POST['entry']) : array();
		if (is_array($posted) && !empty($posted)) {
			$entry_ids = array_map('intval', $posted);
		}
	}

	if (empty($entry_ids)) {
		if (class_exists('GFCommon')) {
			GFCommon::add_message(__('לא נבחרו רשומות לסנכרון', 'at-bookings-api-fixes'), true);
		}
		return;
	}

	// Check permissions
	if (!current_user_can('gravityforms_edit_entries')) {
		if (class_exists('GFCommon')) {
			GFCommon::add_error_message(__('אין לך הרשאות לבצע פעולה זו', 'at-bookings-api-fixes'));
		}
		return;
	}

	// Check Zoho configuration
	if (!class_exists('AT_Zoho_CRM') || !AT_Zoho_CRM::is_configured()) {
		if (class_exists('GFCommon')) {
			GFCommon::add_error_message(__('Zoho CRM לא מוגדר. אנא הגדר את ההתחברות לזוהו.', 'at-bookings-api-fixes'));
		}
		return;
	}

	// Each Zoho API call can take a couple of seconds; a bulk of 100 entries
	// blows past the default 30s execution limit. Bump as far as the host allows.
	if (function_exists('set_time_limit')) {
		@set_time_limit(600);
	}
	@ini_set('memory_limit', '512M');

	$synced = 0;
	$failed = 0;
	$skipped = 0;
	$errors = array();

	if (function_exists('write_detailed_log')) {
		write_detailed_log(
			sprintf('[GF Bulk Sync] Start: %d entries for form #%d', count($entry_ids), (int) $form['id']),
			'INFO'
		);
	}

	foreach ($entry_ids as $entry_id) {
		$entry = GFAPI::get_entry($entry_id);

		if (is_wp_error($entry)) {
			$failed++;
			$errors[] = sprintf('Entry #%d: לא נמצא', $entry_id);
			continue;
		}

		// Use the centralized sync function
		$result = at_gform_sync_contact_to_zoho($entry, $form, true);

		if ($result && $result['success']) {
			$synced++;
		} elseif ($result && isset($result['message']) && strpos($result['message'], 'אינו מוגדר') !== false) {
			$skipped++;
		} else {
			$failed++;
			$error_msg = $result && isset($result['message']) ? $result['message'] : 'שגיאה לא ידועה';
			$errors[] = sprintf('Entry #%d: %s', $entry_id, $error_msg);
		}
	}

	// Build result message
	$messages = array();

	if ($synced > 0) {
		$messages[] = sprintf(
			_n('%d רשומה סונכרנה בהצלחה', '%d רשומות סונכרנו בהצלחה', $synced, 'at-bookings-api-fixes'),
			$synced
		);
	}

	if ($skipped > 0) {
		$messages[] = sprintf(
			_n('%d רשומה דולגה', '%d רשומות דולגו', $skipped, 'at-bookings-api-fixes'),
			$skipped
		);
	}

	if ($failed > 0) {
		$messages[] = sprintf(
			_n('%d רשומה נכשלה', '%d רשומות נכשלו', $failed, 'at-bookings-api-fixes'),
			$failed
		);
	}

	// Display results
	if ($synced > 0 || $skipped > 0) {
		GFCommon::add_message(implode(' | ', $messages));
	}

	if (!empty($errors)) {
		foreach (array_slice($errors, 0, 5) as $error) {
			GFCommon::add_error_message($error);
		}

		if (count($errors) > 5) {
			GFCommon::add_error_message(sprintf(
				__('...ועוד %d שגיאות', 'at-bookings-api-fixes'),
				count($errors) - 5
			));
		}
	}

	// Log bulk action summary
	if (function_exists('write_detailed_log')) {
		write_detailed_log(
			sprintf(
				'[GF Bulk Sync] Processed %d entries: %d synced, %d failed, %d skipped',
				count($entry_ids),
				$synced,
				$failed,
				$skipped
			),
			'INFO'
		);
	}
}

/**
 * Enqueue fallback JavaScript to add bulk action if missing
 * 
 * This fallback ensures the "סנכרן ל-Zoho CRM" option appears in bulk actions
 * even if the PHP filter doesn't register it properly
 */
add_action('admin_enqueue_scripts', 'at_enqueue_gform_bulk_action_fallback');
function at_enqueue_gform_bulk_action_fallback()
{
	// Only load on Gravity Forms admin pages
	if (!isset($_GET['page']) || $_GET['page'] !== 'gf_entries') {
		return;
	}

	// Enqueue the fallback script
	wp_enqueue_script(
		'at-gform-bulk-action-fallback',
		plugin_dir_url(__FILE__) . '../../assets/js/bulk-action-fallback.js',
		array('jquery'),
		'1.0.0',
		true
	);
}

/**
 * ========================================
 * ZOHO COLUMN ON GRAVITY FORMS ENTRIES LIST
 * ========================================
 *
 * Adds a "Zoho" column to the entries list showing either a deep link to the
 * synced Zoho record or "לא סונכרן" with an inline sync button. Driven by the
 * last successful row in the wp_at_zoho_sync_log table where
 * source='gravity_forms' AND source_id=<entry_id>.
 */

/**
 * Look up the most recent successful Zoho sync for a Gravity Forms entry.
 * Prefers Leads over Contacts so that Leads-targeted forms link to the Lead.
 *
 * @param int $entry_id
 * @return array|null
 */
function at_get_gform_entry_zoho_sync($entry_id)
{
	static $cache = array();
	$entry_id = (int) $entry_id;
	if ($entry_id <= 0) {
		return null;
	}
	if (array_key_exists($entry_id, $cache)) {
		return $cache[$entry_id];
	}

	// Source 1 (preferred): Gravity Forms entry meta written by at_save_gform_zoho_meta()
	// during sync. Prefer Leads over Contacts so multi-module syncs link to the Lead.
	if (function_exists('gform_get_meta')) {
		$lead_id    = gform_get_meta($entry_id, 'at_zoho_Leads_id');
		$contact_id = gform_get_meta($entry_id, 'at_zoho_Contacts_id');
		$last_id    = gform_get_meta($entry_id, 'at_zoho_last_id');
		$last_mod   = gform_get_meta($entry_id, 'at_zoho_last_module');

		if (!empty($lead_id)) {
			return $cache[$entry_id] = array(
				'module'    => 'Leads',
				'id'        => (string) $lead_id,
				'sync_time' => (string) gform_get_meta($entry_id, 'at_zoho_Leads_synced_at'),
			);
		}
		if (!empty($contact_id)) {
			return $cache[$entry_id] = array(
				'module'    => 'Contacts',
				'id'        => (string) $contact_id,
				'sync_time' => (string) gform_get_meta($entry_id, 'at_zoho_Contacts_synced_at'),
			);
		}
		if (!empty($last_id) && !empty($last_mod)) {
			return $cache[$entry_id] = array(
				'module'    => (string) $last_mod,
				'id'        => (string) $last_id,
				'sync_time' => (string) gform_get_meta($entry_id, 'at_zoho_last_synced_at'),
			);
		}
	}

	// Source 2 (fallback for entries synced before meta was added): parse existing
	// Gravity Forms notes left by at_add_gform_note(). Their format is stable:
	//   <strong>🔗 Zoho CRM Sync</strong> ... מודול: <Module> ... Record ID: <id> ...
	// We look at the most recent note and prefer Leads if multiple notes exist.
	$parsed = at_parse_zoho_from_gform_notes($entry_id);
	if ($parsed) {
		// Backfill meta so future page loads skip the parse step
		at_save_gform_zoho_meta($entry_id, $parsed['id'], $parsed['module']);
		return $cache[$entry_id] = $parsed;
	}

	// Source 3 (fallback): legacy custom sync log table. Skipped silently if
	// the table doesn't exist on this install (which is the most likely cause
	// of the "always not synced" symptom).
	global $wpdb;
	$table = $wpdb->prefix . 'at_zoho_sync_log';

	$exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table));
	if (!$exists) {
		return $cache[$entry_id] = null;
	}

	$row = $wpdb->get_row($wpdb->prepare(
		"SELECT target_module, target_id, sync_time
		 FROM {$table}
		 WHERE source = 'gravity_forms'
		   AND source_id = %d
		   AND status = 'success'
		   AND target_id IS NOT NULL
		   AND target_id <> ''
		 ORDER BY FIELD(target_module, 'Leads', 'Contacts') ASC, sync_time DESC
		 LIMIT 1",
		$entry_id
	), ARRAY_A);

	if (!$row || empty($row['target_id'])) {
		return $cache[$entry_id] = null;
	}

	return $cache[$entry_id] = array(
		'module'    => !empty($row['target_module']) ? $row['target_module'] : 'Contacts',
		'id'        => $row['target_id'],
		'sync_time' => isset($row['sync_time']) ? $row['sync_time'] : '',
	);
}

/**
 * Parse the most recent successful Zoho-sync note left by at_add_gform_note()
 * on a Gravity Forms entry. Returns Leads if both a Lead and Contact note exist.
 *
 * @param int $entry_id
 * @return array|null  ['module' => 'Leads'|'Contacts', 'id' => '...', 'sync_time' => 'Y-m-d H:i:s'] or null
 */
function at_parse_zoho_from_gform_notes($entry_id)
{
	$all = at_parse_all_zoho_from_gform_notes($entry_id);
	if (empty($all)) {
		return null;
	}
	// Prefer Leads, otherwise return the most recent record we saw.
	if (isset($all['Leads'])) {
		return $all['Leads'];
	}
	// Find most recent by sync_time
	$best = null;
	foreach ($all as $info) {
		if ($best === null || strcmp($info['sync_time'], $best['sync_time']) > 0) {
			$best = $info;
		}
	}
	return $best;
}

/**
 * Parse ALL Zoho-sync notes left on a Gravity Forms entry and return a
 * map of module => ['id', 'sync_time']. Used by the metabox + the entries-list
 * column so we can display every module the entry was synced to (Contact + Lead
 * + any custom modules), not just one "primary" record.
 *
 * For duplicates (multiple syncs to the same module), we keep the most recent.
 *
 * @param int $entry_id
 * @return array<string, array{module:string,id:string,sync_time:string}>
 */
function at_parse_all_zoho_from_gform_notes($entry_id)
{
	if (!class_exists('RGFormsModel') && !class_exists('GFFormsModel')) {
		return array();
	}

	$notes = array();
	if (method_exists('GFFormsModel', 'get_lead_notes')) {
		$notes = GFFormsModel::get_lead_notes($entry_id);
	} elseif (method_exists('RGFormsModel', 'get_lead_notes')) {
		$notes = RGFormsModel::get_lead_notes($entry_id);
	}
	if (empty($notes)) {
		return array();
	}

	$results = array();
	foreach ($notes as $note) {
		$value = isset($note->value) ? $note->value : '';
		if (strpos($value, 'Zoho CRM Sync') === false) {
			continue;
		}
		$module = '';
		$record = '';
		if (preg_match('/מודול:\s*([A-Za-z]+)/u', $value, $m)) {
			$module = trim($m[1]);
			// Note text uses "Contact"/"Lead" singular — normalize to api_name plural
			if ($module === 'Contact') $module = 'Contacts';
			elseif ($module === 'Lead') $module = 'Leads';
		}
		if (preg_match('/Record ID:\s*([A-Za-z0-9_\-]+)/u', $value, $m)) {
			$record = trim($m[1]);
		}
		if (empty($module) || empty($record)) {
			continue;
		}

		$candidate = array(
			'module'    => $module,
			'id'        => $record,
			'sync_time' => isset($note->date_created) ? $note->date_created : '',
		);

		// Keep the most recent per module
		if (!isset($results[$module]) || strcmp($candidate['sync_time'], $results[$module]['sync_time']) > 0) {
			$results[$module] = $candidate;
		}
	}

	return $results;
}

/**
 * Add a "Zoho" column header to the GF entries table.
 *
 * @param array $table_columns Map of column_id => label
 * @return array
 */
add_filter('gform_entry_list_columns', 'at_gform_add_zoho_column', 10, 1);
function at_gform_add_zoho_column($table_columns)
{
	$table_columns['at_zoho_status'] = 'Zoho';
	return $table_columns;
}

/**
 * Render the "Zoho" column cell — link to record if synced, or
 * "לא סונכרן" with a one-click sync button otherwise.
 *
 * @param string $value
 * @param int    $form_id
 * @param string $field_id  Column ID (e.g. 'at_zoho_status')
 * @param array  $entry
 * @return string
 */
add_filter('gform_entries_field_value', 'at_gform_render_zoho_column', 10, 4);
function at_gform_render_zoho_column($value, $form_id, $field_id, $entry)
{
	if ($field_id !== 'at_zoho_status') {
		return $value;
	}

	$entry_id = isset($entry['id']) ? (int) $entry['id'] : 0;
	if (!$entry_id) {
		return $value;
	}

	// Collect every known module/id for this entry (Contact + Lead + custom modules)
	$modules = at_get_gform_entry_all_zoho_syncs($entry_id);

	if (!empty($modules)) {
		$links = array();
		// Order: Leads, Contacts, then anything else
		uksort($modules, function ($a, $b) {
			$order = array('Leads' => 1, 'Contacts' => 2);
			$ra = isset($order[$a]) ? $order[$a] : 99;
			$rb = isset($order[$b]) ? $order[$b] : 99;
			return $ra - $rb;
		});
		foreach ($modules as $module => $info) {
			$short = ($module === 'Leads') ? 'Lead' : (($module === 'Contacts') ? 'Contact' : $module);
			$url   = at_get_zoho_contact_url($info['id'], $module);
			$links[] = sprintf(
				'<a href="%s" target="_blank" rel="noopener" title="%s" style="text-decoration:none; white-space:nowrap;">' .
					'<span class="dashicons dashicons-external" style="font-size:14px; vertical-align:middle;"></span> %s</a>',
				esc_url($url),
				esc_attr(sprintf('סונכרן: %s · %s', $info['synced_at'], $info['id'])),
				esc_html($short)
			);
		}
		return implode(' &nbsp; ', $links);
	}

	// Not synced — render an inline sync button (uses existing AJAX endpoint)
	$nonce = wp_create_nonce('at_gf_sync_' . $entry_id);
	return sprintf(
		'<span style="color:#b32d2e;">לא סונכרן</span> ' .
			'<button type="button" class="button button-small at-gf-list-sync-btn" ' .
			'data-entry-id="%d" data-nonce="%s" style="margin-right:6px;">' .
			'<span class="dashicons dashicons-update" style="font-size:14px; vertical-align:middle;"></span> סנכרן</button>',
		$entry_id,
		esc_attr($nonce)
	);
}

/**
 * Return every Zoho module + record_id known for a Gravity Forms entry,
 * combining entry meta and any backfill from existing GF notes. Self-heals by
 * persisting note-derived records to entry meta so the next call is instant.
 *
 * @param int $entry_id
 * @return array<string, array{id:string, synced_at:string}>
 */
function at_get_gform_entry_all_zoho_syncs($entry_id)
{
	static $cache = array();
	$entry_id = (int) $entry_id;
	if ($entry_id <= 0) {
		return array();
	}
	if (array_key_exists($entry_id, $cache)) {
		return $cache[$entry_id];
	}

	$modules = array();

	if (function_exists('gform_get_meta')) {
		foreach (array('Contacts', 'Leads') as $mod) {
			$mid = gform_get_meta($entry_id, 'at_zoho_' . $mod . '_id');
			if (!empty($mid)) {
				$modules[$mod] = array(
					'id'        => (string) $mid,
					'synced_at' => (string) gform_get_meta($entry_id, 'at_zoho_' . $mod . '_synced_at'),
				);
			}
		}
		$last_mod = gform_get_meta($entry_id, 'at_zoho_last_module');
		$last_id  = gform_get_meta($entry_id, 'at_zoho_last_id');
		if (!empty($last_mod) && !empty($last_id) && !isset($modules[$last_mod])) {
			$modules[$last_mod] = array(
				'id'        => (string) $last_id,
				'synced_at' => (string) gform_get_meta($entry_id, 'at_zoho_last_synced_at'),
			);
		}
	}

	// Recover anything that's only in notes and backfill meta for next time
	$notes_parsed = at_parse_all_zoho_from_gform_notes($entry_id);
	foreach ($notes_parsed as $module => $info) {
		if (isset($modules[$module])) {
			continue;
		}
		$modules[$module] = array(
			'id'        => $info['id'],
			'synced_at' => $info['sync_time'],
		);
		at_save_gform_zoho_meta($entry_id, $info['id'], $module);
	}

	return $cache[$entry_id] = $modules;
}

/**
 * Some Gravity Forms versions also pass the value through gform_entries_column_filter
 * for final escaping. Make sure our HTML survives that pass.
 */
add_filter('gform_entries_column_filter', 'at_gform_passthrough_zoho_column', 10, 5);
function at_gform_passthrough_zoho_column($value, $form_id, $field_id, $entry, $query_string)
{
	if ($field_id === 'at_zoho_status') {
		// Re-render so we always have fresh HTML (e.g. after a sync)
		return at_gform_render_zoho_column('', $form_id, $field_id, $entry);
	}
	return $value;
}

/**
 * Enqueue inline JS that powers the per-row sync button in the Zoho column.
 */
add_action('admin_print_footer_scripts', 'at_gform_zoho_column_inline_js', 99);
function at_gform_zoho_column_inline_js()
{
	if (!isset($_GET['page']) || $_GET['page'] !== 'gf_entries') {
		return;
	}
	?>
	<script>
	(function($) {
		if (typeof $ === 'undefined') return;
		$(document).on('click', '.at-gf-list-sync-btn', function(e) {
			e.preventDefault();
			var $btn  = $(this);
			var entryId = $btn.data('entry-id');
			var nonce   = $btn.data('nonce');
			var $cell   = $btn.closest('td');

			$btn.prop('disabled', true).text('מסנכרן…');

			$.post(ajaxurl, {
				action: 'at_gf_sync_to_zoho',
				entry_id: entryId,
				nonce: nonce
			}).done(function(resp) {
				if (resp && resp.success && resp.data && (resp.data.zoho_url || resp.data.contact_id)) {
					var url = resp.data.zoho_url || '#';
					$cell.html('<a href="' + url + '" target="_blank" rel="noopener" style="text-decoration:none;">'
						+ '<span class="dashicons dashicons-external" style="font-size:14px;vertical-align:middle;"></span> סונכרן ✓</a>');
				} else {
					var msg = (resp && resp.data && resp.data.message) ? resp.data.message : 'שגיאה';
					$btn.prop('disabled', false).text('סנכרן');
					$cell.find('.at-sync-err').remove();
					$cell.append(' <span class="at-sync-err" style="color:#b32d2e;font-size:11px;">' + msg + '</span>');
				}
			}).fail(function() {
				$btn.prop('disabled', false).text('סנכרן');
			});
		});
	})(window.jQuery);
	</script>
	<?php
}

