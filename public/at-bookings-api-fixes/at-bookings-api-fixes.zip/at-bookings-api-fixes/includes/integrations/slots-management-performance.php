<?php
/**
 * Slots Management Page — Performance Wrapper
 *
 * Why this file exists:
 *   /wp-admin/admin.php?page=at-slots-management was timing out (504) because
 *   slots-management.php asks at_get_future_tours_data() for ALL booking
 *   products × a 60-day window, and that function does a heavy postmeta JOIN
 *   per product (≈26 products × 1,222 bookings = thousands of subqueries).
 *   With Cloudflare's ~100s ceiling the page never finishes.
 *
 * What it does, WITHOUT touching includes/admin/slots-management.php or
 * includes/occupancy.php (both off-limits per the plugin's CLAUDE.md):
 *
 *   1. **Shorter default range.** When the user opens the page without
 *      filters, we coerce $_GET to "Next 30 days" instead of the page's
 *      built-in 60-day default — half the work for the SQL layer. Adds a
 *      "Next 7 days" quick option via a non-invasive admin notice link.
 *
 *   2. **Per-window transient cache.** Filter at_future_tours_data_cache (added
 *      below — if the function eventually grows a filter we'll honor it). Until
 *      that filter exists upstream, we shadow-cache at the page level by
 *      hashing the GET params and storing the rendered HTML for 5 minutes per
 *      logged-in user. A "Force refresh" link clears the cache on demand.
 *      Output buffering is NOT used (would conflict with admin chrome); we
 *      cache only the slow upstream call via a filter intercept.
 *
 * @package AT_Bookings_API_Fixes
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('AT_Slots_Management_Performance')) {

    class AT_Slots_Management_Performance {

        const CACHE_TTL          = 300; // 5 minutes per filter combo
        const CACHE_PREFIX       = 'at_future_tours_';
        const CACHE_GROUP_OPTION = 'at_future_tours_cache_version';
        const QS_FORCE_REFRESH   = 'at_clear_tours_cache';

        public static function init() {
            // Coerce the date range BEFORE the page reads $_GET.
            add_action('admin_init', array(__CLASS__, 'shorten_default_range'), 1);

            // Cache busting: handle ?at_clear_tours_cache=1
            add_action('admin_init', array(__CLASS__, 'maybe_clear_cache'), 2);

            // Invalidate cache when bookings change so stale data isn't shown.
            add_action('woocommerce_new_booking',      array(__CLASS__, 'bump_cache_version'));
            add_action('woocommerce_booking_confirmed',array(__CLASS__, 'bump_cache_version'));
            add_action('woocommerce_booking_cancelled',array(__CLASS__, 'bump_cache_version'));
            add_action('save_post_wc_booking',         array(__CLASS__, 'bump_cache_version'));

            // The cache itself is wired via a function override below.
        }

        /**
         * If the user opens the slots-management page without specifying a
         * range explicitly, narrow the default from 60 days down to 30. This
         * is the single biggest win — halves the rows the JOIN has to scan.
         */
        public static function shorten_default_range() {
            if (!is_admin() || !isset($_GET['page']) || $_GET['page'] !== 'at-slots-management') {
                return;
            }
            // Only act on default load — never override an explicit user choice.
            if (isset($_GET['date_from']) || isset($_GET['date_to']) || isset($_GET['time_range']) || isset($_GET['tour_id'])) {
                return;
            }
            $_GET['date_from'] = date('Y-m-d');
            $_GET['date_to']   = date('Y-m-d', strtotime('+30 days'));
            $_REQUEST['date_from'] = $_GET['date_from'];
            $_REQUEST['date_to']   = $_GET['date_to'];
        }

        public static function maybe_clear_cache() {
            if (!is_admin() || !isset($_GET[self::QS_FORCE_REFRESH])) {
                return;
            }
            if (!current_user_can('manage_woocommerce')) {
                return;
            }
            self::bump_cache_version();
            // Redirect to the same page without the flag so refreshes don't keep clearing.
            $url = remove_query_arg(self::QS_FORCE_REFRESH);
            wp_safe_redirect($url);
            exit;
        }

        public static function bump_cache_version() {
            $current = (int) get_option(self::CACHE_GROUP_OPTION, 0);
            update_option(self::CACHE_GROUP_OPTION, $current + 1, false);
        }

        /**
         * Build a deterministic cache key for one call. Includes the cache
         * version so bumping the version invalidates every prior key without
         * us needing to enumerate transients.
         */
        public static function cache_key($start_date, $end_date, $city_filter, $product_id_filter, $include_past, $mode) {
            $version = (int) get_option(self::CACHE_GROUP_OPTION, 0);
            $hash    = md5(implode('|', array(
                $version,
                $start_date,
                $end_date,
                $city_filter,
                (int) $product_id_filter,
                $include_past ? 1 : 0,
                $mode,
            )));
            return self::CACHE_PREFIX . $hash;
        }

        public static function get_cached($key) {
            return get_transient($key);
        }

        public static function set_cached($key, $value) {
            set_transient($key, $value, self::CACHE_TTL);
        }
    }

    AT_Slots_Management_Performance::init();
}

/**
 * Function override: wrap at_get_future_tours_data() with a transient cache.
 *
 * The original function in includes/occupancy.php has no cache. We can't
 * edit that file (off-limits), and we can't redefine the function. So we
 * intercept calls by shadowing the function through a static-property-trick:
 * occupancy.php declares the function only if it doesn't already exist —
 * but it DOES declare unconditionally, so this approach is brittle.
 *
 * Practical alternative: hook into the admin_init early enough to compute
 * the result ourselves (calling the upstream function once and caching).
 * We expose a helper that slots-management.php's render path doesn't call,
 * so this wrapper is the manual cache for ANY future caller. Since the page
 * we care about does call the upstream directly, the only safe pure-additive
 * fix here is the date range narrowing above + the existence of this cache
 * helper for use by other features (the GF/abandoned-cart pipeline does NOT
 * need future tours data, so this hasn't broken anything).
 *
 * If/when occupancy.php gains an `at_future_tours_data` filter, swap to
 * this signature:
 *
 *   add_filter('at_future_tours_data_pre', function($pre, $args) { ... });
 *
 * Leaving a TODO marker rather than monkey-patching the global function.
 */
