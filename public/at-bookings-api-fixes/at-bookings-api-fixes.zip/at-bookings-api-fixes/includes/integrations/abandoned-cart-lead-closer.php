<?php
/**
 * Abandoned-cart Lead Closer
 *
 * Counterpart to abandoned-cart-lead-enricher.php. When an order finishes
 * paying (transitions to processing/completed), the primary Zoho sync creates
 * a Sales_Order and stores its IDs on the order. But the Lead that was created
 * earlier (when the order was still pending) stays in Zoho forever as an
 * "abandoned cart" — sales would call the customer who already paid.
 *
 * This closer:
 *   1. Fires on woocommerce_order_status_changed at priority 25 (AFTER the
 *      primary sync at 10 and the enricher at 20).
 *   2. Detects when the order has just transitioned to a paid status.
 *   3. Looks up the matching Lead in Zoho by OID (the WC order ID we stamped
 *      onto the Lead in the enricher), falling back to the post_meta cache
 *      (_zoho_lead_id) if the OID search misses.
 *   4. Updates Lead_Status to 'Contact in Future' (display: "הזמין עצמאית
 *      קבוצתי באתר") so the "נטישות" view stops showing it, and appends a
 *      pointer to the Sales_Order(s) in the Description.
 *
 * Failure modes are non-fatal: if no Lead is found, we log and exit; if Zoho
 * rejects the update, we log and exit. The Sales_Order has already been
 * created — the closer is best-effort cleanup.
 *
 * @package AT_Bookings_API_Fixes
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * The Lead_Status value to set on Leads whose customer eventually paid.
 * "Contact in Future" is the actual_value; the display in Hebrew is
 * "הזמין עצמאית קבוצתי באתר" (verified against the live Zoho picklist).
 */
if (!defined('AT_ABANDONED_CART_COMPLETED_STATUS')) {
    define('AT_ABANDONED_CART_COMPLETED_STATUS', 'Contact in Future');
}

add_action('woocommerce_order_status_changed', 'at_close_abandoned_lead_on_purchase', 25, 4);

/**
 * @param int      $order_id
 * @param string   $old_status
 * @param string   $new_status
 * @param WC_Order $order
 */
function at_close_abandoned_lead_on_purchase($order_id, $old_status, $new_status, $order) {
    // Same paid-status definition the primary sync uses (zoho-sync-service.php:1070).
    $paid_statuses = array('completed', 'processing');
    if (!in_array($new_status, $paid_statuses, true)) {
        return;
    }

    if (!class_exists('AT_Zoho_API') || !class_exists('AT_Zoho_CRM') || !AT_Zoho_CRM::is_configured()) {
        return;
    }

    if (!$order instanceof WC_Order) {
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }
    }

    // Avoid acting twice if WC bounces the order between paid statuses
    // (e.g. processing → completed → processing). Once we've closed the
    // Lead, we don't want to keep firing.
    $closed_for = (string) get_post_meta($order_id, '_zoho_lead_closed_for', true);

    at_abandoned_cart_log('Closer fired on paid transition', 'INFO', array(
        'order_id'   => $order_id,
        'old_status' => $old_status,
        'new_status' => $new_status,
        'already_closed_for' => $closed_for ?: '(none)',
    ));

    // 1. Locate the Lead. Prefer the post_meta we already stored when the
    //    enricher ran — it's authoritative and doesn't cost an API call.
    //    Fall back to a search by OID for Leads created outside this
    //    plugin's flow (manual entries, imports, etc.).
    $lead_id = (string) get_post_meta($order_id, '_zoho_lead_id', true);

    if (!$lead_id) {
        $found = at_find_lead_by_oid($order_id);
        if ($found) {
            $lead_id = $found;
            at_abandoned_cart_log('Lead located via OID search', 'INFO', array(
                'order_id' => $order_id,
                'lead_id'  => $lead_id,
            ));
        }
    }

    if (!$lead_id) {
        at_abandoned_cart_log('Skip closer: no Lead found for this order', 'INFO', array(
            'order_id' => $order_id,
        ));
        return;
    }

    if ($closed_for === $lead_id) {
        at_abandoned_cart_log('Skip closer: Lead already closed for this order', 'INFO', array(
            'order_id' => $order_id,
            'lead_id'  => $lead_id,
        ));
        return;
    }

    // 2. Collect Sales_Order IDs created by the primary sync. The
    //    sync service stores them in post_meta as a list — we link to
    //    whichever one(s) exist so sales can jump straight to the SO.
    $sales_order_ids = get_post_meta($order_id, '_zoho_sales_order_ids', true);
    if (!is_array($sales_order_ids)) {
        $single = (string) get_post_meta($order_id, '_zoho_sales_order_id', true);
        $sales_order_ids = $single ? array($single) : array();
    }

    // 3. Build the description appendix.
    $appendix_lines = array(
        '',
        '--- עודכן ב-' . current_time('Y-m-d H:i') . ' ---',
        'הלקוח חזר והשלים את הרכישה (סטטוס: ' . $new_status . ').',
        'הזמנה: #' . $order_id . ' — ' . $order->get_view_order_url(),
    );
    if (!empty($sales_order_ids)) {
        $appendix_lines[] = 'Zoho Sales Orders:';
        foreach ($sales_order_ids as $so_id) {
            $appendix_lines[] = '  • ' . at_build_zoho_sales_order_url($so_id) . ' (ID: ' . $so_id . ')';
        }
    }
    $appendix = implode("\n", $appendix_lines);

    // 4. Read existing Description so we APPEND rather than overwrite.
    $api = AT_Zoho_API::get_instance();
    $existing = null;
    try {
        $existing = $api->get_record('Leads', $lead_id);
    } catch (Exception $e) {
        // Lead might have been deleted — surface the error and bail.
        at_abandoned_cart_log('Closer: could not fetch existing Lead', 'WARNING', array(
            'lead_id' => $lead_id,
            'error'   => $e->getMessage(),
        ));
        return;
    }

    $existing_desc = is_array($existing) && !empty($existing['Description']) ? (string) $existing['Description'] : '';

    $payload = array(
        'Lead_Status' => AT_ABANDONED_CART_COMPLETED_STATUS,
        'Description' => trim($existing_desc . "\n" . $appendix),
    );

    // Use the same safety filter the enricher uses, so unknown fields are
    // dropped silently rather than killing the update.
    if (function_exists('at_abandoned_cart_safe_payload')) {
        $payload = at_abandoned_cart_safe_payload($payload, 'Leads', $order_id);
    }

    at_abandoned_cart_log('Sending close-update to Zoho', 'INFO', array(
        'order_id'        => $order_id,
        'lead_id'         => $lead_id,
        'new_lead_status' => isset($payload['Lead_Status']) ? $payload['Lead_Status'] : '(stripped)',
        'sales_order_ids' => $sales_order_ids,
    ));

    try {
        $result = $api->update_record('Leads', $lead_id, $payload);
        $ok = is_array($result) && (!empty($result['id']) || !empty($result['success']));

        if ($ok) {
            update_post_meta($order_id, '_zoho_lead_closed_for', $lead_id);
            at_abandoned_cart_log('SUCCESS: Lead closed (status + SO link added)', 'INFO', array(
                'order_id' => $order_id,
                'lead_id'  => $lead_id,
            ));
        } else {
            at_abandoned_cart_log('FAILED: Zoho rejected Lead close-update', 'ERROR', array(
                'order_id'      => $order_id,
                'lead_id'       => $lead_id,
                'zoho_response' => $result,
            ));
        }
    } catch (Exception $e) {
        at_abandoned_cart_log('EXCEPTION during Lead close-update', 'ERROR', array(
            'order_id' => $order_id,
            'lead_id'  => $lead_id,
            'error'    => $e->getMessage(),
        ));
    }
}

/**
 * Search Zoho Leads for one whose OID custom field matches the given order ID.
 * Returns the Lead ID or '' if none found.
 *
 * Used as a fallback when _zoho_lead_id post_meta is missing (e.g. the Lead
 * was created by a different flow than our enricher).
 */
function at_find_lead_by_oid($order_id) {
    $api = AT_Zoho_API::get_instance();
    try {
        $results = $api->search_records('Leads', 'OID', (string) $order_id);
    } catch (Exception $e) {
        at_abandoned_cart_log('OID search threw exception', 'WARNING', array(
            'order_id' => $order_id,
            'error'    => $e->getMessage(),
        ));
        return '';
    }
    if (empty($results) || !is_array($results)) {
        return '';
    }
    // search_records() returns either a single record or an array of records.
    if (isset($results['id'])) {
        return (string) $results['id'];
    }
    if (isset($results[0]['id'])) {
        return (string) $results[0]['id'];
    }
    return '';
}

/**
 * Build a clickable Zoho URL for a Sales_Order. Mirrors at_get_zoho_contact_url()
 * (defined in gravity-forms-sync.php) but for the Sales_Orders module so the
 * URL points at the right tab.
 */
function at_build_zoho_sales_order_url($sales_order_id) {
    if (function_exists('at_get_zoho_contact_url')) {
        return at_get_zoho_contact_url($sales_order_id, 'Sales_Orders');
    }
    return 'https://crm.zoho.com/crm/tab/Sales_Orders/' . rawurlencode($sales_order_id);
}
