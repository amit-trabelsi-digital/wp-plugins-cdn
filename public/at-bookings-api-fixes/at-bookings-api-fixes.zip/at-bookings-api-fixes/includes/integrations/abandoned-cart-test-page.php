<?php
/**
 * Abandoned Cart → Zoho Lead — Test Page
 *
 * Adds a "Test Abandoned Cart" submenu under AT Bookings that lets the user
 * simulate the full abandoned-cart flow without opening a browser as a guest:
 *  1. Create a real WooCommerce order from a chosen bookable product with a
 *     test email/name/phone.
 *  2. Transition the order to "pending" → fires the same
 *     woocommerce_order_status_changed pipeline that a real abandoned cart
 *     would fire.
 *  3. That pipeline runs (a) the primary AT_Zoho_WooCommerce::auto_sync_on_status_change
 *     which creates the Lead in Zoho and stores _zoho_lead_id, then (b) the
 *     new abandoned-cart enricher at priority 20 which adds the cart description
 *     and Lead_Source = "נטישת סל".
 *  4. Render the resulting Lead ID + a direct link to Zoho + a tail of the
 *     [ABANDONED_CART] log lines so the user can verify the flow on one screen.
 *
 * Why this lives in includes/integrations/ rather than includes/admin/: the
 * plugin's CLAUDE.md forbids editing files under includes/admin/. This test
 * page is part of the additive abandoned-cart feature, so it ships alongside
 * the enricher.
 *
 * @package AT_Bookings_API_Fixes
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('AT_Abandoned_Cart_Test_Page')) {

    class AT_Abandoned_Cart_Test_Page {

        const PAGE_SLUG  = 'at-test-abandoned-cart';
        const NONCE_NAME = 'at_test_abandoned_cart_nonce';

        public static function init() {
            add_action('admin_menu', array(__CLASS__, 'register_menu'), 50);
            add_action('wp_ajax_at_test_abandoned_get_product_meta', array(__CLASS__, 'ajax_get_product_meta'));
        }

        /**
         * AJAX: return upcoming slots + person types for a given bookable
         * product, so the form can populate the tour-date and ticket-count
         * fields dynamically. Authenticated admin only.
         */
        public static function ajax_get_product_meta() {
            if (!current_user_can('manage_woocommerce')) {
                wp_send_json_error(array('message' => 'forbidden'), 403);
            }
            check_ajax_referer(self::NONCE_NAME, 'nonce');

            $product_id = isset($_GET['product_id']) ? (int) $_GET['product_id'] : 0;
            $product    = $product_id ? wc_get_product($product_id) : null;
            if (!$product || !is_wc_booking_product($product)) {
                wp_send_json_error(array('message' => 'not a bookable product'), 400);
            }

            wp_send_json_success(array(
                'slots'        => self::get_upcoming_slots($product_id, 60),
                'person_types' => self::get_person_types_for_product($product_id),
            ));
        }

        /**
         * Pull upcoming slots from the AT slots table (the canonical source
         * for ARTERNATIVE tour cycles). Each slot is rendered for the
         * date picker as "YYYY-MM-DD HH:mm — N spots".
         *
         * @return array<array{value:string,label:string}>
         */
        private static function get_upcoming_slots($product_id, $limit = 60) {
            global $wpdb;

            $table = $wpdb->prefix . 'at_booking_slots';
            if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) !== $table) {
                return array();
            }

            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT slot_start, slot_end, max_bookings, current_bookings, status
                 FROM {$table}
                 WHERE product_id = %d
                   AND slot_start >= NOW()
                 ORDER BY slot_start ASC
                 LIMIT %d",
                $product_id,
                $limit
            ));

            $out = array();
            foreach ($rows as $row) {
                $remaining = max(0, (int) $row->max_bookings - (int) $row->current_bookings);
                $start_ts  = strtotime($row->slot_start);
                $end_ts    = strtotime($row->slot_end);
                $out[] = array(
                    'value' => $row->slot_start . '|' . $row->slot_end,
                    'label' => sprintf(
                        '%s (נותרו %d מקומות, סטטוס: %s)',
                        date_i18n('Y-m-d H:i', $start_ts),
                        $remaining,
                        $row->status
                    ),
                );
            }
            return $out;
        }

        /**
         * Return WooCommerce Booking person types attached to a product (e.g.
         * "מבוגר", "ילד"). Falls back to a default Adult-only list for products
         * that don't have person types enabled.
         *
         * @return array<array{id:int,name:string,base_cost:float}>
         */
        private static function get_person_types_for_product($product_id) {
            $out = array();

            if (!class_exists('WC_Product_Booking')) {
                return array(array('id' => 0, 'name' => 'מבוגר', 'base_cost' => 0));
            }

            $product = wc_get_product($product_id);
            if (!$product || !$product->has_persons()) {
                return array(array('id' => 0, 'name' => 'מבוגר', 'base_cost' => 0));
            }

            // WC Bookings stores person types as child posts (CPT: bookable_person)
            // OR (older installs) as simple counters. We support both.
            $persons = $product->get_person_types();
            if (empty($persons)) {
                return array(array('id' => 0, 'name' => 'מבוגר', 'base_cost' => 0));
            }

            foreach ($persons as $person) {
                $out[] = array(
                    'id'        => (int) $person->get_id(),
                    'name'      => $person->get_name(),
                    'base_cost' => (float) $person->get_cost(),
                );
            }
            return $out;
        }

        public static function register_menu() {
            add_submenu_page(
                'at-bookings',
                __('Test Abandoned Cart', 'at-bookings-api-fixes'),
                __('Test Abandoned Cart', 'at-bookings-api-fixes'),
                'manage_woocommerce',
                self::PAGE_SLUG,
                array(__CLASS__, 'render_page')
            );
        }

        public static function render_page() {
            if (!current_user_can('manage_woocommerce')) {
                wp_die(__('Insufficient permissions.', 'at-bookings-api-fixes'));
            }

            $result = null;
            if (isset($_POST['at_test_abandoned_cart_run'])) {
                check_admin_referer(self::NONCE_NAME);

                // Person counts come from the dynamic UI as person_count[<id>] = N.
                $persons = array();
                if (isset($_POST['person_count']) && is_array($_POST['person_count'])) {
                    foreach ((array) $_POST['person_count'] as $person_id => $count) {
                        $count = (int) $count;
                        if ($count > 0) {
                            $persons[(int) $person_id] = $count;
                        }
                    }
                }

                // Slot resolution: prefer the dropdown selection (existing slot
                // row from at_booking_slots); if empty, fall back to the manual
                // datetime-local pair. Both shapes are "Y-m-d H:i|Y-m-d H:i" or
                // ISO local "Y-m-d\TH:i|Y-m-d\TH:i" — run_simulation() normalises
                // via strtotime() so either works.
                $slot_value = isset($_POST['slot']) ? sanitize_text_field(wp_unslash($_POST['slot'])) : '';
                if ($slot_value === '' && !empty($_POST['slot_manual'])) {
                    $slot_value = sanitize_text_field(wp_unslash($_POST['slot_manual']));
                }

                $result = self::run_simulation(array(
                    'product_id'  => isset($_POST['product_id']) ? (int) $_POST['product_id'] : 0,
                    'email'       => isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '',
                    'first_name'  => isset($_POST['first_name']) ? sanitize_text_field(wp_unslash($_POST['first_name'])) : '',
                    'last_name'   => isset($_POST['last_name']) ? sanitize_text_field(wp_unslash($_POST['last_name'])) : '',
                    'phone'       => isset($_POST['phone']) ? sanitize_text_field(wp_unslash($_POST['phone'])) : '',
                    'slot'        => $slot_value,
                    'persons'     => $persons,
                ));
            }

            $current_user = wp_get_current_user();
            $default_email = $current_user ? $current_user->user_email : '';

            ?>
            <div class="wrap" dir="rtl">
                <h1>🧪 בדיקת נטישת סל → Zoho Lead</h1>
                <p>
                    יוצר הזמנת WooCommerce, מעביר אותה לסטטוס <code>pending</code>,
                    ומפעיל את כל ה-pipeline (סנכרון ראשי + ה-enricher).
                    בסוף תראה את <code>Lead ID</code> ב-Zoho, את ה-payload, ואת הלוגים הרלוונטיים.
                </p>

                <?php if ($result) : ?>
                    <?php self::render_result($result); ?>
                <?php endif; ?>

                <h2>פרמטרים</h2>
                <form method="post" id="at-test-abandoned-form">
                    <?php wp_nonce_field(self::NONCE_NAME); ?>
                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row"><label for="product_id">מוצר Booking</label></th>
                            <td>
                                <select name="product_id" id="product_id" required>
                                    <option value="">— בחר מוצר —</option>
                                    <?php foreach (self::get_bookable_products() as $p) : ?>
                                        <option value="<?php echo esc_attr($p['id']); ?>">
                                            <?php echo esc_html('#' . $p['id'] . ' — ' . $p['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="description">בחר את הסיור שהלקוח התעניין בו — ירכיב את ה-Description.</p>
                            </td>
                        </tr>
                        <tr id="at-row-slot" style="display:none;">
                            <th scope="row"><label for="slot_picker">תאריך הסיור</label></th>
                            <td>
                                <select name="slot" id="slot_picker">
                                    <option value="">— ללא תאריך (נטישה מוקדמת) —</option>
                                </select>
                                <span id="at-slot-loading" style="display:none;color:#777;">טוען סלוטים...</span>
                                <br>
                                <div id="at-slot-manual-wrap" style="margin-top:8px;">
                                    <label style="color:#555;">— או הזן תאריך/שעה ידנית: —</label><br>
                                    <input type="datetime-local" id="slot_manual_start" style="margin-top:4px;">
                                    <span style="color:#777;">עד</span>
                                    <input type="datetime-local" id="slot_manual_end">
                                    <input type="hidden" name="slot_manual" id="slot_manual">
                                </div>
                                <p class="description">
                                    אם למוצר אין סלוטים בטבלה <code>at_booking_slots</code>, הזן תאריך ידנית.
                                    הקוד ייצור <code>WC_Booking</code> אמיתי לתאריך שתבחר.
                                </p>
                            </td>
                        </tr>
                        <tr id="at-row-persons" style="display:none;">
                            <th scope="row">סוגי כרטיסים</th>
                            <td id="at-persons-container">
                                <em>בחר מוצר כדי לטעון סוגי כרטיסים...</em>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="email">אימייל</label></th>
                            <td>
                                <input type="email" name="email" id="email"
                                       value="<?php echo esc_attr($default_email); ?>"
                                       class="regular-text" required>
                                <p class="description">ה-Lead ב-Zoho ייווצר עם האימייל הזה.</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="first_name">שם פרטי</label></th>
                            <td>
                                <input type="text" name="first_name" id="first_name"
                                       value="Test" class="regular-text" required>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="last_name">שם משפחה</label></th>
                            <td>
                                <input type="text" name="last_name" id="last_name"
                                       value="Abandoner" class="regular-text" required>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="phone">טלפון</label></th>
                            <td>
                                <input type="text" name="phone" id="phone"
                                       value="050-0000000" class="regular-text">
                            </td>
                        </tr>
                    </table>

                    <p class="submit">
                        <button type="submit" name="at_test_abandoned_cart_run" class="button button-primary">
                            הפעל סימולציה
                        </button>
                    </p>
                </form>

                <script>
                (function($){
                    var ajaxNonce = <?php echo wp_json_encode(wp_create_nonce(self::NONCE_NAME)); ?>;
                    var ajaxUrl   = <?php echo wp_json_encode(admin_url('admin-ajax.php')); ?>;

                    // Default manual datetime: 14 days from now at 10:00, ending +2h.
                    var futureStart = new Date(Date.now() + 14 * 24 * 3600 * 1000);
                    futureStart.setHours(10, 0, 0, 0);
                    var futureEnd = new Date(futureStart.getTime() + 2 * 3600 * 1000);
                    function fmtLocal(d){
                        var pad = function(n){ return (n<10?'0':'')+n; };
                        return d.getFullYear() + '-' + pad(d.getMonth()+1) + '-' + pad(d.getDate())
                            + 'T' + pad(d.getHours()) + ':' + pad(d.getMinutes());
                    }
                    $('#slot_manual_start').val(fmtLocal(futureStart));
                    $('#slot_manual_end').val(fmtLocal(futureEnd));

                    // Build the hidden slot_manual value (pipe-separated start|end) whenever
                    // either input changes, so the form submits with current values.
                    function syncManualSlot() {
                        var s = $('#slot_manual_start').val();
                        var e = $('#slot_manual_end').val();
                        $('#slot_manual').val(s && e ? (s + '|' + e) : '');
                    }
                    $('#slot_manual_start, #slot_manual_end').on('change input', syncManualSlot);
                    syncManualSlot();

                    $('#product_id').on('change', function(){
                        var productId = $(this).val();
                        if (!productId) {
                            $('#at-row-slot, #at-row-persons').hide();
                            return;
                        }
                        $('#at-slot-loading').show();
                        $('#at-row-slot, #at-row-persons').show();
                        $('#slot_picker').html('<option value="">— טוען —</option>');
                        $('#at-persons-container').html('<em>טוען...</em>');

                        $.get(ajaxUrl, {
                            action:     'at_test_abandoned_get_product_meta',
                            product_id: productId,
                            nonce:      ajaxNonce
                        }).done(function(resp){
                            $('#at-slot-loading').hide();
                            if (!resp || !resp.success) {
                                $('#slot_picker').html('<option value="">— שגיאה —</option>');
                                $('#at-persons-container').html('<em style="color:#dc3232;">לא ניתן לטעון פרטי מוצר</em>');
                                return;
                            }
                            // Slots
                            var $slot = $('#slot_picker').empty().append('<option value="">— ללא תאריך (נטישה מוקדמת) —</option>');
                            (resp.data.slots || []).forEach(function(s){
                                $slot.append($('<option>').val(s.value).text(s.label));
                            });
                            if ((resp.data.slots || []).length === 0) {
                                $slot.append('<option value="" disabled>אין סלוטים בטבלה — השתמש בהזנה ידנית למטה</option>');
                            }
                            // Person types
                            var $cont = $('#at-persons-container').empty();
                            (resp.data.person_types || []).forEach(function(pt, i){
                                var defaultVal = i === 0 ? 2 : 0;
                                $cont.append(
                                    $('<div style="margin-bottom:6px;">').append(
                                        $('<label>').css({'display':'inline-block','width':'200px'}).text(pt.name + ':'),
                                        $('<input type="number" min="0" max="20" class="small-text">')
                                            .attr('name', 'person_count[' + pt.id + ']')
                                            .val(defaultVal),
                                        $('<span style="color:#777;margin-right:8px;">').text(' (מחיר בסיס: ' + pt.base_cost + ')')
                                    )
                                );
                            });
                        }).fail(function(){
                            $('#at-slot-loading').hide();
                            $('#at-persons-container').html('<em style="color:#dc3232;">שגיאת רשת</em>');
                        });
                    });
                })(jQuery);
                </script>

                <hr>

                <h2>סטטוס מערכת</h2>
                <?php self::render_system_check(); ?>
            </div>
            <?php
        }

        private static function render_result(array $r) {
            $ok_color = $r['success'] ? '#46b450' : '#dc3232';
            ?>
            <div class="notice" style="border-right: 4px solid <?php echo esc_attr($ok_color); ?>; padding: 12px 16px;">
                <h2 style="margin-top:0;">
                    <?php echo $r['success'] ? '✅ הסימולציה הצליחה' : '❌ הסימולציה נכשלה'; ?>
                </h2>

                <table class="widefat" style="margin-bottom:12px;">
                    <tbody>
                        <tr>
                            <th>Order ID (WordPress)</th>
                            <td>
                                <?php if (!empty($r['order_id'])) : ?>
                                    <a href="<?php echo esc_url(admin_url('post.php?post=' . $r['order_id'] . '&action=edit')); ?>" target="_blank">
                                        #<?php echo esc_html($r['order_id']); ?>
                                    </a>
                                <?php else : ?>
                                    —
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Lead ID (Zoho)</th>
                            <td>
                                <?php if (!empty($r['lead_id']) && !empty($r['lead_url'])) : ?>
                                    <a href="<?php echo esc_url($r['lead_url']); ?>" target="_blank">
                                        <?php echo esc_html($r['lead_id']); ?>
                                    </a>
                                <?php elseif (!empty($r['lead_id'])) : ?>
                                    <?php echo esc_html($r['lead_id']); ?>
                                <?php else : ?>
                                    <em style="color:#dc3232;">לא נוצר Lead — בדוק את הלוגים למטה</em>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Enrichment בוצע?</th>
                            <td>
                                <?php echo !empty($r['enriched']) ? '✅ כן' : '❌ לא'; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>הודעה</th>
                            <td><?php echo esc_html($r['message']); ?></td>
                        </tr>
                    </tbody>
                </table>

                <?php if (!empty($r['cart_description'])) : ?>
                    <h3>תיאור הסל שנשלח ל-Description</h3>
                    <pre style="background:#f6f7f7;padding:10px;white-space:pre-wrap;direction:rtl;text-align:right;"><?php echo esc_html($r['cart_description']); ?></pre>
                <?php endif; ?>

                <?php if (!empty($r['log_lines'])) : ?>
                    <h3>לוגים אחרונים מהזרם (<code>[ABANDONED_CART]</code>)</h3>
                    <pre style="background:#1d2327;color:#f0f6fc;padding:10px;max-height:400px;overflow:auto;direction:ltr;text-align:left;font-size:12px;"><?php echo esc_html(implode("\n", $r['log_lines'])); ?></pre>
                <?php endif; ?>
            </div>
            <?php
        }

        private static function render_system_check() {
            $rows = array(
                'WooCommerce'                => class_exists('WooCommerce'),
                'AT_Zoho_API class'          => class_exists('AT_Zoho_API'),
                'AT_Zoho_CRM class'          => class_exists('AT_Zoho_CRM'),
                'Zoho CRM configured'        => class_exists('AT_Zoho_CRM') && AT_Zoho_CRM::is_configured(),
                'Auto-sync enabled (option)' => (bool) get_option('at_zoho_auto_sync_enabled', false),
                'Enricher loaded (function)' => function_exists('at_enrich_abandoned_cart_lead'),
                'Logger available'           => function_exists('write_detailed_log'),
                'Custom log file exists'     => file_exists(WP_CONTENT_DIR . '/logs/custom.log'),
            );
            echo '<table class="widefat striped"><tbody>';
            foreach ($rows as $label => $ok) {
                $icon = $ok ? '✅' : '❌';
                echo '<tr><td style="width:300px;">' . esc_html($label) . '</td><td>' . $icon . '</td></tr>';
            }
            echo '</tbody></table>';

            if (!get_option('at_zoho_auto_sync_enabled', false)) {
                echo '<p style="color:#dc3232;"><strong>שים לב:</strong> Auto-sync כבוי. הסימולציה לא תיצור Lead ב-Zoho עד שתפעיל אותו ב-<em>Zoho Settings</em>.</p>';
            }
        }

        /**
         * Run the actual simulation: create order → set to pending → collect results.
         */
        private static function run_simulation(array $args) {
            $r = array(
                'success'          => false,
                'order_id'         => 0,
                'lead_id'          => '',
                'lead_url'         => '',
                'enriched'         => false,
                'message'          => '',
                'cart_description' => '',
                'log_lines'        => array(),
            );

            try {
                if (empty($args['product_id']) || empty($args['email'])) {
                    throw new Exception('חסר מוצר או אימייל');
                }
                $product = wc_get_product($args['product_id']);
                if (!$product) {
                    throw new Exception('המוצר לא נמצא');
                }

                // Resolve the chosen slot (format "Y-m-d H:i:s|Y-m-d H:i:s") if any.
                $slot_start_ts = 0;
                $slot_end_ts   = 0;
                if (!empty($args['slot'])) {
                    list($slot_start_raw, $slot_end_raw) = array_pad(explode('|', $args['slot'], 2), 2, '');
                    $slot_start_ts = strtotime($slot_start_raw);
                    $slot_end_ts   = strtotime($slot_end_raw);
                }

                // Person counts come from the UI keyed by person_type ID
                // (0 = "default Adult" fallback for products without person types).
                $persons = !empty($args['persons']) ? array_filter($args['persons']) : array();
                $total_qty = (int) array_sum($persons);
                if ($total_qty < 1) {
                    $total_qty = 1; // safety floor — a cart with zero participants is meaningless
                }

                // 1. Build a real order. Start in 'checkout-draft' (WC's own
                //    draft state for incomplete carts — exactly what an
                //    abandoned cart looks like in real life) so we can later
                //    flip to 'pending' and see a genuine status transition
                //    that fires woocommerce_order_status_changed with
                //    old='checkout-draft', new='pending'.
                $order = wc_create_order(array('status' => 'checkout-draft'));
                if (is_wp_error($order)) {
                    throw new Exception('wc_create_order failed: ' . $order->get_error_message());
                }

                // Per-line price: use the chosen person types' base costs
                // when available, else fall back to the product's regular
                // price. Otherwise the line total stays at 0 and the cart
                // description shows "$0".
                $line_subtotal = self::calculate_line_subtotal($args['product_id'], $persons, $product, $total_qty);

                $item_id = $order->add_product($product, $total_qty, array(
                    'subtotal' => $line_subtotal,
                    'total'    => $line_subtotal,
                ));
                $order->set_billing_email($args['email']);
                $order->set_billing_first_name($args['first_name']);
                $order->set_billing_last_name($args['last_name']);
                $order->set_billing_phone($args['phone']);
                $order->set_customer_note('TEST: simulated abandoned cart from admin test page');

                // 2. Persist the persons breakdown on the order item meta so the
                //    enricher's parse_ticket_types() can find it (it looks for
                //    keys like persons_<type> or labels matching adult/child/…).
                //    We store both shapes: the WC Bookings "persons_<id>" array
                //    style AND a human-readable "<name>: <count>" line so the
                //    fallback parser also works.
                if ($item_id && !empty($persons)) {
                    $persons_meta = array();
                    foreach ($persons as $person_id => $count) {
                        wc_add_order_item_meta($item_id, 'persons_' . $person_id, (int) $count);
                        // Human-readable label for display in Description.
                        $person_name = self::resolve_person_label($args['product_id'], (int) $person_id);
                        wc_add_order_item_meta($item_id, $person_name, (int) $count);
                        $persons_meta[$person_id] = (int) $count;
                    }
                }

                // 3. If a slot was chosen and WC Bookings is active, create an
                //    actual WC_Booking attached to this order item. This lets the
                //    enricher pull the tour date via _booking_id → get_wc_booking().
                $booking_id = 0;
                if ($slot_start_ts && $slot_end_ts && function_exists('create_wc_booking')) {
                    $booking_data = array(
                        'product_id' => (int) $args['product_id'],
                        'order_item_id' => $item_id,
                        'start_date' => $slot_start_ts,
                        'end_date'   => $slot_end_ts,
                        'persons'    => $persons,
                        'cost'       => (float) $product->get_price() * $total_qty,
                    );
                    $booking = create_wc_booking($args['product_id'], $booking_data, 'in-cart', true);
                    if ($booking && !is_wp_error($booking)) {
                        $booking_id = $booking->get_id();
                        // Attach booking to the order so WC_Booking_Data_Store finds it.
                        $booking->set_order_id($order->get_id());
                        $booking->save();
                        if ($item_id) {
                            wc_add_order_item_meta($item_id, '_booking_id', $booking_id);
                        }
                    }
                }

                // Calculate totals WITHOUT triggering a status change yet.
                // calculate_totals() can flip status under some configurations,
                // so we lock the status to checkout-draft afterwards just in case.
                $order->calculate_totals();
                $order->set_status('checkout-draft');
                $order->save();
                $r['order_id'] = $order->get_id();

                at_abandoned_cart_log('Test simulation: order created', 'INFO', array(
                    'order_id'      => $r['order_id'],
                    'email'         => $args['email'],
                    'product'       => $product->get_name(),
                    'persons'       => $persons,
                    'total_qty'     => $total_qty,
                    'line_subtotal' => $line_subtotal,
                    'order_total'   => (float) $order->get_total(),
                    'order_status'  => $order->get_status(),
                    'booking_id'    => $booking_id,
                    'slot_start'    => $slot_start_ts ? date('Y-m-d H:i', $slot_start_ts) : null,
                ));

                // 2. Mark log offset BEFORE the status change so we can grep just this run.
                $log_file       = WP_CONTENT_DIR . '/logs/custom.log';
                $offset_before  = file_exists($log_file) ? filesize($log_file) : 0;

                // 3. Force the status transition explicitly. We re-load the
                //    order from DB first so the status-change hooks fire with
                //    a clean object (some setups cache CRUD state and confuse
                //    the transition detection).
                $order_fresh = wc_get_order($r['order_id']);
                $current_status = $order_fresh->get_status();
                at_abandoned_cart_log('About to transition status', 'INFO', array(
                    'order_id'    => $r['order_id'],
                    'from_status' => $current_status,
                    'to_status'   => 'pending',
                ));
                if ($current_status === 'pending') {
                    // No-op transitions don't fire the hook. Bump through a
                    // different status first so the transition becomes real.
                    $order_fresh->update_status('on-hold', 'TEST: bump to force status change');
                    $order_fresh = wc_get_order($r['order_id']);
                }
                $order_fresh->update_status('pending', 'TEST: trigger abandoned-cart pipeline');

                // 4. Collect outcomes from post_meta.
                $r['lead_id']  = (string) get_post_meta($r['order_id'], '_zoho_lead_id', true);
                $enriched_for  = (string) get_post_meta($r['order_id'], '_zoho_lead_enriched_for', true);
                $r['enriched'] = $r['lead_id'] && $enriched_for === $r['lead_id'];

                // 5. Build the cart description the same way the enricher does, so the
                //    user sees exactly what landed in Zoho's Description field.
                if (function_exists('at_build_cart_description_for_lead')) {
                    $r['cart_description'] = at_build_cart_description_for_lead($order);
                }

                // 6. Pull every relevant log line written during this run so
                //    the user can see both the primary sync (AUTO-SYNC TRIGGERED)
                //    and the enricher ([ABANDONED_CART]) in one place.
                $r['log_lines'] = self::tail_log_lines_since(
                    $log_file,
                    $offset_before,
                    array('[ABANDONED_CART]', 'AUTO-SYNC', 'Order #' . $r['order_id'])
                );

                // 7. Link to Zoho if we have a Lead ID.
                if ($r['lead_id']) {
                    $r['lead_url'] = self::build_zoho_lead_url($r['lead_id']);
                }

                $r['success'] = (bool) $r['lead_id'];
                $r['message'] = $r['success']
                    ? sprintf('Lead נוצר ב-Zoho (Lead #%s). Enrichment: %s',
                        $r['lead_id'],
                        $r['enriched'] ? 'בוצע' : 'לא בוצע (בדוק לוגים)')
                    : 'Lead לא נוצר. בדוק את הלוגים ואת הגדרות ה-Auto-Sync.';
            } catch (Exception $e) {
                $r['message'] = 'שגיאה: ' . $e->getMessage();
            }

            return $r;
        }

        /**
         * @return array<array{id:int,name:string}>
         */
        private static function get_bookable_products() {
            $out  = array();
            $args = array(
                'post_type'      => 'product',
                'post_status'    => 'publish',
                'posts_per_page' => 100,
                'tax_query'      => array(
                    array(
                        'taxonomy' => 'product_type',
                        'field'    => 'slug',
                        'terms'    => 'booking',
                    ),
                ),
                'orderby'        => 'title',
                'order'          => 'ASC',
            );
            $q = new WP_Query($args);
            foreach ($q->posts as $post) {
                $out[] = array(
                    'id'   => (int) $post->ID,
                    'name' => get_the_title($post),
                );
            }
            return $out;
        }

        /**
         * Read everything written to $file after $offset_before and return the
         * lines matching any of $tags (string or array of strings). Used to
         * show the user only the log entries produced by *this* run.
         */
        private static function tail_log_lines_since($file, $offset_before, $tags) {
            if (!file_exists($file)) {
                return array();
            }
            $size = filesize($file);
            if ($size <= $offset_before) {
                return array();
            }
            $fh = fopen($file, 'rb');
            if (!$fh) {
                return array();
            }
            fseek($fh, $offset_before);
            $chunk = fread($fh, $size - $offset_before);
            fclose($fh);

            $tag_list = is_array($tags) ? $tags : array($tags);
            $lines    = preg_split('/\r\n|\r|\n/', $chunk);
            $hits     = array();
            foreach ($lines as $line) {
                if ($line === '') {
                    continue;
                }
                foreach ($tag_list as $tag) {
                    if (strpos($line, $tag) !== false) {
                        $hits[] = $line;
                        break;
                    }
                }
            }
            return $hits;
        }

        /**
         * Compute the line subtotal for the synthetic order:
         *  - If the product has person types and the user filled in counts,
         *    multiply each person count by that person type's base_cost.
         *  - Otherwise fall back to (product price × total qty).
         * Returns float >= 0 — never negative.
         */
        private static function calculate_line_subtotal($product_id, array $persons, $product, $total_qty) {
            $total = 0.0;

            if (!empty($persons) && class_exists('WC_Product_Booking')) {
                $booking_product = wc_get_product($product_id);
                if ($booking_product && method_exists($booking_product, 'get_person_types')) {
                    foreach ($booking_product->get_person_types() as $pt) {
                        $pid = (int) $pt->get_id();
                        if (!empty($persons[$pid])) {
                            $total += ((float) $pt->get_cost()) * (int) $persons[$pid];
                        }
                    }
                }
            }

            if ($total <= 0) {
                $total = ((float) $product->get_price()) * max(1, (int) $total_qty);
            }

            return $total;
        }

        /**
         * Map a WC Bookings person_type ID back to its Hebrew label, with a
         * sensible "מבוגר" default for the synthetic 0-id used by products
         * without person types.
         */
        private static function resolve_person_label($product_id, $person_id) {
            if ($person_id === 0) {
                return 'מבוגר';
            }
            $person_post = get_post($person_id);
            if ($person_post && $person_post->post_title) {
                return $person_post->post_title;
            }
            return 'מבוגר';
        }

        private static function build_zoho_lead_url($lead_id) {
            if (function_exists('at_get_zoho_contact_url')) {
                return at_get_zoho_contact_url($lead_id, 'Leads');
            }
            // Fallback: try the most common Zoho CRM URL shape; the user can correct.
            return 'https://crm.zoho.com/crm/tab/Leads/' . rawurlencode($lead_id);
        }
    }

    AT_Abandoned_Cart_Test_Page::init();
}
