<?php
/**
 * Abandoned Cart → Zoho Lead Enricher
 *
 * Problem: unpaid WooCommerce orders are synced to Zoho as Leads (by
 * AT_Zoho_Sync_Service::sync_lead()), but the Lead arrives with only a name +
 * email + phone — no information about WHICH tour the customer wanted, on what
 * date, for how many people, or for how much money. That makes the "נטישות
 * דברו איתנו" view in Zoho unactionable: sales sees a name and can't follow up.
 *
 * Fix: listen on woocommerce_order_status_changed at a LATER priority than
 * AT_Zoho_WooCommerce::auto_sync_on_status_change (priority 10), wait until the
 * Lead has been created and its ID stored in _zoho_lead_id post_meta, then push
 * a follow-up update_record() call to Zoho that fills:
 *   - Lead_Source        → "נטישת סל" (so the Zoho view filter can group these)
 *   - Description        → human-readable cart breakdown
 *
 * Why this approach rather than editing zoho-mapper.php / zoho-sync-service.php
 * directly: the plugin's CLAUDE.md explicitly forbids modifying files under
 * includes/zoho/. This file lives in includes/integrations/ which is the
 * sanctioned location for additive cross-cutting features (same dir as the
 * Gravity Forms → Zoho sync), and uses only public APIs (post_meta + the Zoho
 * API facade), so the core sync code stays untouched.
 *
 * @package AT_Bookings_API_Fixes
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Lead_Source value used to route unpaid-order Leads into the
 * "נטישות דברו איתנו" view in Zoho. Changing this string requires re-aligning
 * the Zoho view filter.
 */
if (!defined('AT_ABANDONED_CART_LEAD_SOURCE')) {
    define('AT_ABANDONED_CART_LEAD_SOURCE', 'נטישת סל');
}

/**
 * Tagged logger. Every log line is prefixed with [ABANDONED_CART] so the user
 * can `tail -f wp-content/logs/custom.log | grep ABANDONED_CART` and see the
 * full lifecycle of one test order without noise from other syncs.
 *
 * @param string $message
 * @param string $level   INFO|WARNING|ERROR
 * @param array  $context Optional structured context, JSON-encoded
 */
function at_abandoned_cart_log($message, $level = 'INFO', $context = array()) {
    if (!function_exists('write_detailed_log')) {
        return;
    }
    $line = '[ABANDONED_CART] ' . $message;
    if (!empty($context)) {
        $line .= ' | ' . wp_json_encode($context, JSON_UNESCAPED_UNICODE);
    }
    write_detailed_log($line, $level);
}

// Priority 20 = AFTER AT_Zoho_WooCommerce::auto_sync_on_status_change (10).
// By the time we run, sync_lead() has already created the Lead in Zoho and
// stored its ID on the order. We then enrich it with a follow-up update.
add_action('woocommerce_order_status_changed', 'at_enrich_abandoned_cart_lead', 20, 4);

/**
 * Fallback hook for orders that never trigger woocommerce_order_status_changed.
 *
 * Real-world finding (Order #9813 in production): when WC creates an order
 * from the checkout form, it calls set_status('pending') during construction
 * rather than update_status() afterwards. set_status() doesn't fire
 * woocommerce_order_status_changed — the order is BORN in pending, no
 * transition happens. Result: AT_Zoho_WooCommerce::auto_sync_on_status_change()
 * (and our enricher) never run, no Lead gets created, no enrichment happens,
 * and an abandoned cart silently dies.
 *
 * woocommerce_checkout_order_processed fires unconditionally after every
 * checkout submission, regardless of whether the gateway redirects the user
 * away (Yaad Sarig does) or processes inline. We use it to kick off the
 * same pipeline by synthesising a transition from 'pending' → 'pending'.
 *
 * Guard against double-firing: if _zoho_lead_id is already set, the primary
 * sync ran (via status_changed) and we don't need to do anything here.
 */
add_action('woocommerce_checkout_order_processed', 'at_kickoff_abandoned_cart_pipeline', 5, 2);

/**
 * @param int   $order_id
 * @param array $posted_data
 */
function at_kickoff_abandoned_cart_pipeline($order_id, $posted_data = array()) {
    $order = wc_get_order($order_id);
    if (!$order) {
        return;
    }

    // If the primary sync already ran (via the normal status-changed hook),
    // _zoho_lead_id will be set and we have nothing to do. Idempotency.
    $existing_lead = get_post_meta($order_id, '_zoho_lead_id', true);
    if (!empty($existing_lead)) {
        return;
    }

    $status = $order->get_status();
    at_abandoned_cart_log('Checkout fallback fired (no status_changed transition)', 'INFO', array(
        'order_id' => $order_id,
        'status'   => $status,
        'has_zoho_lead_id' => false,
    ));

    // Only act on the same unpaid statuses the enricher handles. If WC
    // somehow created the order paid (unlikely from checkout), we skip and
    // let the normal flow handle the eventual paid sync.
    $unpaid_statuses = array('pending', 'on-hold', 'failed');
    if (!in_array($status, $unpaid_statuses, true)) {
        at_abandoned_cart_log('Fallback skip: status is not unpaid', 'INFO', array(
            'order_id' => $order_id,
            'status'   => $status,
        ));
        return;
    }

    // Reuse the existing status-changed handlers by synthesising a transition.
    // Priority 10 = AT_Zoho_WooCommerce::auto_sync_on_status_change (creates
    // the Lead). Priority 20 = at_enrich_abandoned_cart_lead (adds the cart
    // contents). The primary sync rejects self-transitions ($old === $new),
    // so we report the previous logical state as 'checkout-draft' — that is
    // the state WC actually came from before set_status('pending'), and it's
    // not in the primary sync's skip list (only trash + auto-draft are).
    at_abandoned_cart_log('Fallback: dispatching synthetic transition to run primary sync + enricher', 'INFO', array(
        'order_id'   => $order_id,
        'from'       => 'checkout-draft',
        'to'         => $status,
    ));
    do_action('woocommerce_order_status_changed', $order_id, 'checkout-draft', $status, $order);
}

/**
 * Enrich the Zoho Lead created from an unpaid order with cart contents.
 *
 * @param int      $order_id
 * @param string   $old_status
 * @param string   $new_status
 * @param WC_Order $order
 */
function at_enrich_abandoned_cart_lead($order_id, $old_status, $new_status, $order) {
    at_abandoned_cart_log('Hook fired', 'INFO', array(
        'order_id'   => $order_id,
        'old_status' => $old_status,
        'new_status' => $new_status,
    ));

    // Only act on statuses the sync service treats as "unpaid → Lead".
    // Paid statuses (completed, processing) become Sales_Orders, not Leads,
    // and the abandoned-cart concept doesn't apply to them.
    $unpaid_statuses = array('pending', 'on-hold', 'failed');
    if (!in_array($new_status, $unpaid_statuses, true)) {
        at_abandoned_cart_log('Skip: status is not unpaid (Lead pipeline does not apply)', 'INFO', array(
            'order_id'         => $order_id,
            'new_status'       => $new_status,
            'unpaid_statuses'  => $unpaid_statuses,
        ));
        return;
    }

    // Respect the same kill-switch that gates the primary sync. If auto-sync
    // is off, no Lead was created, so there's nothing to enrich.
    if (!get_option('at_zoho_auto_sync_enabled', false)) {
        at_abandoned_cart_log('Skip: auto-sync is disabled (at_zoho_auto_sync_enabled = false)', 'WARNING', array(
            'order_id' => $order_id,
        ));
        return;
    }

    // Zoho API must be available and configured. Bail quietly if not.
    if (!class_exists('AT_Zoho_API') || !class_exists('AT_Zoho_CRM')) {
        at_abandoned_cart_log('Skip: Zoho classes not loaded', 'ERROR', array(
            'order_id' => $order_id,
        ));
        return;
    }
    if (!AT_Zoho_CRM::is_configured()) {
        at_abandoned_cart_log('Skip: Zoho CRM not configured', 'WARNING', array(
            'order_id' => $order_id,
        ));
        return;
    }

    // Ensure $order is usable (some callers pass a stale ID after a CRUD edit).
    if (!$order instanceof WC_Order) {
        $order = wc_get_order($order_id);
        if (!$order) {
            at_abandoned_cart_log('Skip: order not found', 'ERROR', array(
                'order_id' => $order_id,
            ));
            return;
        }
    }

    // The primary sync stores the Lead ID on the order. If it isn't there yet,
    // the primary sync either hasn't run, is running in the background, or
    // failed — either way, there's nothing to enrich.
    $lead_id = get_post_meta($order_id, '_zoho_lead_id', true);
    if (!$lead_id) {
        at_abandoned_cart_log('Skip: no Lead ID on order yet (primary sync has not stored _zoho_lead_id)', 'WARNING', array(
            'order_id' => $order_id,
            'hint'     => 'Verify auto-sync ran first at priority 10 on woocommerce_order_status_changed',
        ));
        return;
    }

    // Prevent re-enriching the same Lead on every status flip between unpaid
    // statuses (e.g. pending → on-hold → pending). One enrichment per Lead is
    // enough; if sales wants a fresh snapshot they can re-sync from admin.
    $already_enriched = get_post_meta($order_id, '_zoho_lead_enriched_for', true);
    if ($already_enriched === $lead_id) {
        at_abandoned_cart_log('Skip: Lead already enriched for this Lead ID', 'INFO', array(
            'order_id' => $order_id,
            'lead_id'  => $lead_id,
        ));
        return;
    }

    $description = at_build_cart_description_for_lead($order);
    if ($description === '') {
        at_abandoned_cart_log('Skip: empty cart description (no items?)', 'WARNING', array(
            'order_id' => $order_id,
            'lead_id'  => $lead_id,
        ));
        return;
    }

    // Build the candidate payload. OID + BID are convenience fields that link
    // the Lead back to the WC order/booking — sales can copy them into the
    // wp-admin Orders search. They exist in this account as text fields, but
    // we run the whole payload through at_abandoned_cart_safe_payload() so
    // even if the org renames/removes them, the sync still succeeds (offending
    // fields are dropped, never crash the update).
    $booking_id = 0;
    if (class_exists('AT_Zoho_Mapper') && method_exists('AT_Zoho_Mapper', 'get_booking_id_from_order')) {
        $booking_id = (int) AT_Zoho_Mapper::get_booking_id_from_order($order);
    }

    $payload = array(
        'Lead_Source' => AT_ABANDONED_CART_LEAD_SOURCE,
        'Description' => $description,
        'OID'         => (string) $order_id,
    );
    if ($booking_id > 0) {
        $payload['BID'] = (string) $booking_id;
    }

    // Drop any field Zoho's schema doesn't have or refuses — keeps the update
    // resilient if Common_Status / OID / BID get renamed in the future.
    $payload = at_abandoned_cart_safe_payload($payload, 'Leads', $order_id);

    at_abandoned_cart_log('Sending enrichment to Zoho', 'INFO', array(
        'order_id'    => $order_id,
        'lead_id'     => $lead_id,
        'lead_source' => isset($payload['Lead_Source']) ? $payload['Lead_Source'] : '(stripped)',
        'oid'         => isset($payload['OID']) ? $payload['OID'] : '(stripped)',
        'bid'         => isset($payload['BID']) ? $payload['BID'] : '(stripped or unavailable)',
        'description' => isset($payload['Description']) ? $payload['Description'] : '(stripped)',
    ));

    try {
        $api    = AT_Zoho_API::get_instance();
        $result = $api->update_record('Leads', $lead_id, $payload);

        // AT_Zoho_API::update_record() returns an array on success and false
        // (or an array with no 'id') on failure. Be defensive.
        $ok = is_array($result) && (!empty($result['id']) || !empty($result['success']));

        if ($ok) {
            update_post_meta($order_id, '_zoho_lead_enriched_for', $lead_id);
            at_abandoned_cart_log('SUCCESS: Lead enriched in Zoho', 'INFO', array(
                'order_id'      => $order_id,
                'lead_id'       => $lead_id,
                'zoho_response' => $result,
            ));
        } else {
            at_abandoned_cart_log('FAILED: Zoho rejected enrichment update', 'ERROR', array(
                'order_id'      => $order_id,
                'lead_id'       => $lead_id,
                'zoho_response' => $result,
            ));
        }
    } catch (Exception $e) {
        at_abandoned_cart_log('EXCEPTION during enrichment', 'ERROR', array(
            'order_id' => $order_id,
            'lead_id'  => $lead_id,
            'error'    => $e->getMessage(),
        ));
    }
}

/**
 * Build the human-readable Hebrew cart breakdown that goes into the Lead's
 * Description field. Format intentionally optimized for sales reading it on
 * a phone in Zoho's mobile view — short header, one block per item.
 *
 * Example output:
 *
 *   נטישת עגלה — הזמנה #1234
 *   תאריך: 2026-06-16 14:32
 *
 *   • סיור בכרמל הגבוה
 *     כמות: 2 כרטיסים (מבוגר: 2)
 *     מחיר: ₪450
 *
 *   סה״כ עגלה: ₪450
 *   הערת לקוח: רוצה להגיע ברכב פרטי
 *
 * @param WC_Order $order
 * @return string
 */
function at_build_cart_description_for_lead($order) {
    $lines = array();

    $lines[] = sprintf('נטישת עגלה — הזמנה #%d', $order->get_id());
    $created = $order->get_date_created();
    if ($created) {
        $lines[] = 'תאריך: ' . $created->format('Y-m-d H:i');
    }
    $lines[] = '';

    foreach ($order->get_items() as $item) {
        $lines[] = '• ' . $item->get_name();

        // Booking date (per-item) — pulled from the linked WC_Booking if any.
        // Carts can have items without a booking yet (early add-to-cart), so
        // we degrade gracefully.
        $booking_date = at_get_booking_date_for_item($item);
        if ($booking_date) {
            $lines[] = '  תאריך סיור: ' . $booking_date;
        }

        $qty_line = '  כמות: ' . $item->get_quantity() . ' כרטיסים';
        $ticket_breakdown = at_format_ticket_breakdown_for_item($item);
        if ($ticket_breakdown !== '') {
            $qty_line .= ' (' . $ticket_breakdown . ')';
        }
        $lines[] = $qty_line;

        $lines[] = '  מחיר: ' . html_entity_decode(wp_strip_all_tags(wc_price($item->get_total(), array('currency' => $order->get_currency()))));
        $lines[] = '';
    }

    $lines[] = 'סה״כ עגלה: ' . html_entity_decode(wp_strip_all_tags(wc_price($order->get_total(), array('currency' => $order->get_currency()))));

    if ($note = $order->get_customer_note()) {
        $lines[] = '';
        $lines[] = 'הערת לקוח: ' . $note;
    }

    return trim(implode("\n", $lines));
}

/**
 * Format the ticket-type breakdown for a single order item as a compact
 * Hebrew label, e.g. "מבוגר: 2, ילד: 1". Returns '' when no breakdown is
 * available (the caller will then just show the bare quantity).
 *
 * @param WC_Order_Item $item
 * @return string
 */
function at_format_ticket_breakdown_for_item($item) {
    $labels = array(
        'adult'   => 'מבוגר',
        'adults'  => 'מבוגר',
        'child'   => 'ילד',
        'children'=> 'ילד',
        'kid'     => 'ילד',
        'kids'    => 'ילד',
        'senior'  => 'גמלאי',
        'infant'  => 'תינוק',
        'baby'    => 'תינוק',
    );

    // Person-type meta keys we already collapsed via persons_<id>, so they
    // shouldn't be double-counted when the same item also has a human-readable
    // "מבוגר: 2" line.
    $consumed_counts = array();
    $counts = array();

    // WooCommerce Bookings stores persons under meta keys like "persons_adult"
    // or "persons_<post_id>" (when person types are configured as a CPT). The
    // test page also writes the Hebrew label directly as a meta key (e.g.
    // "מבוגר" => 2) so non-English checkouts produce a useful breakdown.
    foreach ($item->get_meta_data() as $meta) {
        $data  = $meta->get_data();
        $key   = isset($data['key'])   ? (string) $data['key']   : '';
        $value = isset($data['value']) ? $data['value'] : '';

        if (!is_numeric($value) || (int) $value <= 0) {
            continue;
        }

        $label = null;

        // 1. persons_<id> where <id> is a post ID for a WC Bookings person type
        if (preg_match('/^persons?_(\d+)$/i', $key, $m)) {
            $post = get_post((int) $m[1]);
            if ($post && $post->post_title) {
                $label = $post->post_title;
                $consumed_counts[$post->post_title] = (int) $value; // mark to skip duplicate Hebrew-key line
            }
        }

        // 2. persons_<english_type>
        if ($label === null && preg_match('/^persons?_([a-z]+)$/i', $key, $m)) {
            $type  = strtolower($m[1]);
            $label = isset($labels[$type]) ? $labels[$type] : $type;
        }

        // 3. Direct English word match in the key (legacy)
        if ($label === null && preg_match('/(adult|child|kid|senior|infant|baby)/i', $key, $m)) {
            $type  = strtolower($m[1]);
            $label = isset($labels[$type]) ? $labels[$type] : $type;
        }

        // 4. Direct Hebrew label as the meta key (the test page writes these,
        //    and some checkout customizations do too).
        if ($label === null) {
            $hebrew_labels = array('מבוגר', 'ילד', 'גמלאי', 'תינוק', 'נער', 'נערה', 'פעוט');
            foreach ($hebrew_labels as $hl) {
                if ($key === $hl) {
                    // Skip if we already counted this label via persons_<id>
                    if (isset($consumed_counts[$hl])) {
                        $label = null;
                        continue 2; // skip this meta entry entirely
                    }
                    $label = $hl;
                    break;
                }
            }
        }

        if ($label === null) {
            continue;
        }

        if (!isset($counts[$label])) {
            $counts[$label] = 0;
        }
        $counts[$label] += (int) $value;
    }

    if (empty($counts)) {
        return '';
    }

    $parts = array();
    foreach ($counts as $label => $count) {
        $parts[] = $label . ': ' . $count;
    }
    return implode(', ', $parts);
}

/**
 * Pull the tour date out of the WC_Booking linked to an order item, if any.
 *
 * @param WC_Order_Item $item
 * @return string Y-m-d H:i or empty string when no booking is attached.
 */
function at_get_booking_date_for_item($item) {
    $booking_id = $item->get_meta('_booking_id');
    if (is_array($booking_id)) {
        $booking_id = reset($booking_id);
    }
    if (!$booking_id || !function_exists('get_wc_booking')) {
        return '';
    }

    $booking = get_wc_booking((int) $booking_id);
    if (!$booking) {
        return '';
    }

    $start = $booking->get_start();
    if (!$start) {
        return '';
    }
    return gmdate('Y-m-d H:i', (int) $start);
}

/**
 * Schema-aware payload filter: drops any field that doesn't exist in the
 * Zoho module's live schema. Designed to be "safe by omission" — if the
 * schema cache is empty or AT_Zoho_Fields is unavailable, returns the
 * payload unchanged rather than blocking the sync.
 *
 * This is what lets the enricher experiment with new fields (OID, BID, and
 * later custom fields) without worrying about whether they exist in the
 * target org. If a field is missing, it's logged and dropped — never raised
 * to Zoho where it would reject the entire update with INVALID_DATA.
 *
 * Note: this is intentionally lighter than gravity-forms-sync.php's
 * at_gf_zoho_sanitize_payload() (which also coerces numeric types and
 * rescues stripped values into Description). The enricher controls its own
 * payload, so type mismatches shouldn't happen — only existence checks.
 *
 * @param array  $payload  api_name => value
 * @param string $module   "Leads" | "Contacts" | ...
 * @param int    $order_id for the tagged logger
 * @return array filtered payload
 */
function at_abandoned_cart_safe_payload($payload, $module, $order_id) {
    if (!class_exists('AT_Zoho_Fields')) {
        return $payload;
    }
    $schema = AT_Zoho_Fields::get_module_fields($module);
    if (empty($schema) || !is_array($schema)) {
        return $payload;
    }

    $known = array();
    foreach ($schema as $f) {
        if (!empty($f['api_name'])) {
            $known[$f['api_name']] = true;
        }
    }

    $clean   = array();
    $dropped = array();
    foreach ($payload as $api_name => $value) {
        if (isset($known[$api_name])) {
            $clean[$api_name] = $value;
        } else {
            $dropped[$api_name] = $value;
        }
    }

    if (!empty($dropped)) {
        at_abandoned_cart_log('Dropped fields not present in Zoho schema', 'WARNING', array(
            'order_id' => $order_id,
            'module'   => $module,
            'dropped'  => array_keys($dropped),
        ));
    }

    return $clean;
}
