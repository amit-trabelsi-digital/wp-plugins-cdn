<?php

defined('ABSPATH') || exit;

final class AT_Bookings_Control_Telemetry
{
    public static function register($registry)
    {
        if (!is_object($registry) || !method_exists($registry, 'register')) {
            return;
        }
        $registry->register('at-bookings-api-fixes', array(__CLASS__, 'snapshot'));
    }

    public static function snapshot()
    {
        $woocommerce = class_exists('WooCommerce');
        $bookings = class_exists('WC_Bookings') || class_exists('WC_Product_Booking');
        $zoho = class_exists('AT_Zoho_CRM') && AT_Zoho_CRM::is_configured();
        $gravity_forms = class_exists('GFAPI');

        return array(
            'name' => 'AT Bookings API Fixes',
            'version' => AT_BOOKINGS_API_FIXES_VERSION,
            'status' => $woocommerce && $bookings ? ($zoho ? 'ready' : 'degraded') : 'error',
            'status_reason' => !$woocommerce
                ? 'woocommerce_missing'
                : (!$bookings ? 'woocommerce_bookings_missing' : ($zoho ? null : 'zoho_not_configured')),
            'capabilities' => array(
                'bookings.monitor',
                'bookings.slots',
                'bookings.cycles',
                'zoho.sync',
                'zoho.webhook',
                'gravityforms.zoho_sync',
            ),
            'metrics' => array(
                'woocommerce_active' => $woocommerce,
                'bookings_active' => $bookings,
                'zoho_configured' => $zoho,
                'zoho_auto_sync' => (bool) get_option('at_zoho_auto_sync_enabled', false),
                'zoho_last_sync_at' => (int) get_option('at_zoho_last_sync_time', 0),
                'gravity_forms_active' => $gravity_forms,
                'redis_available' => class_exists('Redis') && function_exists('wp_cache_get'),
            ),
            'links' => array(
                'dashboard' => admin_url('admin.php?page=at-bookings'),
                'system_status' => admin_url('admin.php?page=at-bookings-system-status'),
            ),
        );
    }
}

add_action('at_control_register_integrations', array('AT_Bookings_Control_Telemetry', 'register'));
