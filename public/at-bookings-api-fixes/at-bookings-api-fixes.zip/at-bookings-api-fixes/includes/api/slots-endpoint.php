<?php
/**
 * REST API Endpoint for Managing Slots
 *
 * @package AT_Bookings_API_Fixes
 * @subpackage API
 * @since 3.1.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Slots_Endpoint {

    /**
     * Initialize the endpoint
     */
    public static function init() {
        add_action('rest_api_init', array(__CLASS__, 'register_routes'));
    }

    /**
     * Register the REST API routes for slots
     */
    public static function register_routes() {
        register_rest_route('at/v1', '/slots', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array(__CLASS__, 'create_slots'),
            'permission_callback' => array(__CLASS__, 'check_permission'),
            'args' => array(
                'product_id' => array(
                    'required' => true,
                    'validate_callback' => 'is_numeric',
                    'description' => 'The ID of the booking product.',
                ),
                'type' => array(
                    'required' => true,
                    'enum' => array('single', 'recurring'),
                    'description' => 'The type of slot creation: "single" or "recurring".',
                ),
                'start_datetime' => array(
                    'description' => 'Start datetime in ISO 8601 format (e.g., 2025-12-31T10:00:00). Required for "single" type.',
                    'validate_callback' => 'rest_is_valid_date',
                ),
                'end_datetime' => array(
                    'description' => 'End datetime in ISO 8601 format. Optional for "single" type.',
                    'validate_callback' => 'rest_is_valid_date',
                ),
                'start_date' => array(
                    'description' => 'Start date for recurrence (Y-m-d). Required for "recurring" type.',
                    'validate_callback' => 'rest_is_valid_date',
                ),
                'end_date' => array(
                    'description' => 'End date for recurrence (Y-m-d). Required for "recurring" type.',
                    'validate_callback' => 'rest_is_valid_date',
                ),
                'days' => array(
                    'description' => 'Array of weekdays (0=Sun, 1=Mon...). Required for "recurring" type.',
                    'type' => 'array',
                ),
                'start_time' => array(
                    'description' => 'Start time (H:i). Required for "recurring" type.',
                ),
                'end_time' => array(
                    'description' => 'End time (H:i). Required for "recurring" type.',
                ),
            ),
        ));

        register_rest_route('at/v1', '/slots/change', array(
            'methods' => WP_REST_Server::EDITABLE,
            'callback' => array(__CLASS__, 'change_booking_slot'),
            'permission_callback' => array(__CLASS__, 'check_permission'),
            'args' => array(
                'booking_id' => array(
                    'required' => true,
                    'validate_callback' => 'is_numeric',
                ),
                'new_product_id' => array(
                    'required' => true,
                    'validate_callback' => 'is_numeric',
                ),
                'new_start_datetime' => array(
                    'required' => true,
                    'validate_callback' => 'rest_is_valid_date',
                ),
            ),
        ));

        register_rest_route('at/v1', '/slots/bulk-upsert', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array(__CLASS__, 'bulk_upsert_slots'),
            'permission_callback' => array(__CLASS__, 'check_permission'),
            'args' => array(
                'product_id' => array(
                    'required' => true,
                    'validate_callback' => 'is_numeric',
                    'description' => 'The ID of the booking product.',
                ),
                'slots' => array(
                    'required' => true,
                    'type' => 'array',
                    'description' => 'Array of slots with start_datetime and optional end_datetime.',
                ),
            ),
        ));

        register_rest_route('at/v1', '/slots/check', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array(__CLASS__, 'check_slot_exists'),
            'permission_callback' => array(__CLASS__, 'check_permission'),
            'args' => array(
                'product_id' => array(
                    'required' => true,
                    'validate_callback' => 'is_numeric',
                ),
                'start_datetime' => array(
                    'required' => true,
                ),
            ),
        ));
    }

    /**
     * Permission check for the endpoint
     */
    public static function check_permission(WP_REST_Request $request) {
        if (current_user_can('manage_woocommerce')) {
            return true;
        }

        if (class_exists('AT_Security_Manager')) {
            return AT_Security_Manager::verify_api_request($request);
        }

        return new WP_Error(
            'security_manager_unavailable',
            __('API authentication is unavailable', 'at-bookings-api-fixes'),
            array('status' => 503)
        );
    }

    /**
     * Check if a slot exists
     */
    public static function check_slot_exists(WP_REST_Request $request) {
        $product_id = (int)$request['product_id'];
        $start_datetime = $request['start_datetime'];
        
        try {
            $start = new DateTime($start_datetime, wp_timezone());
            $start_utc = clone $start;
            $start_utc->setTimezone(new DateTimeZone('UTC'));
            
            $tour_id = $product_id . '_' . $start_utc->getTimestamp();
            
            $check = self::check_slot_exists_with_bookings($tour_id);
            
            return new WP_REST_Response(array(
                'exists' => $check['exists'],
                'tour_id' => $tour_id,
                'bookings_count' => $check['bookings_count'] ?? 0,
            ), 200);
            
        } catch (Exception $e) {
            return new WP_Error('datetime_error', $e->getMessage(), array('status' => 400));
        }
    }

    /**
     * Callback to create slots
     */
    public static function create_slots(WP_REST_Request $request) {
        $params = $request->get_params();
        $type = $params['type'];

        if ($type === 'single') {
            return self::create_single_slot($params);
        } elseif ($type === 'recurring') {
            return self::create_recurring_slots($params);
        }

        return new WP_Error('invalid_type', 'Invalid slot creation type.', array('status' => 400));
    }

    /**
     * Create a single slot
     */
    private static function create_single_slot($params) {
        global $wpdb;
        $product_id = (int)$params['product_id'];
        $product = wc_get_product($product_id);

        if (!$product || $product->get_type() !== 'booking') {
            return new WP_Error('invalid_product', 'Product is not a valid booking product.', array('status' => 400));
        }
        if (empty($params['start_datetime'])) {
            return new WP_Error('missing_param', 'start_datetime is required for a single slot.', array('status' => 400));
        }

        try {
            $start = new DateTime($params['start_datetime'], wp_timezone());
            if (!empty($params['end_datetime'])) {
                $end = new DateTime($params['end_datetime'], wp_timezone());
            } else {
                $end = clone $start;
                $duration = $product->get_duration();
                $duration_unit = $product->get_duration_unit();
                $end->modify("+$duration $duration_unit");
            }

            $slot_data = self::prepare_slot_data($product, $start, $end);
            $slots_table = AT_Bookings_Slots_Table::get_slots_table();

            $result = $wpdb->insert($slots_table, $slot_data);

            if ($result) {
                // Log creation
                if (class_exists('AT_Zoho_Sync_Logs')) {
                    AT_Zoho_Sync_Logs::get_instance()->log_sync(
                        'create',
                        'Tour_Schedules',
                        $wpdb->insert_id,
                        $slot_data['tour_id'], // Using tour_id as Zoho ID reference
                        'success',
                        $params,
                        $slot_data,
                        'Single slot created via API',
                        'slots',
                        'POST'
                    );
                }

                return new WP_REST_Response(array(
                    'success' => true,
                    'message' => '1 slot created successfully.',
                    'created_slots' => array($slot_data),
                ), 201);
            } else {
                return new WP_Error('db_error', 'Failed to insert slot. It might already exist.', array('status' => 409));
            }
        } catch (Exception $e) {
            return new WP_Error('datetime_error', $e->getMessage(), array('status' => 400));
        }
    }

    /**
     * Create recurring slots
     */
    private static function create_recurring_slots($params) {
        global $wpdb;
        $product_id = (int)$params['product_id'];
        $product = wc_get_product($product_id);

        // Validation
        $required = array('start_date', 'end_date', 'days', 'start_time', 'end_time');
        foreach ($required as $key) {
            if (empty($params[$key])) {
                return new WP_Error('missing_param', "$key is required for recurring slots.", array('status' => 400));
            }
        }
        if (!$product || $product->get_type() !== 'booking') {
            return new WP_Error('invalid_product', 'Product is not a valid booking product.', array('status' => 400));
        }

        try {
            $start_date = new DateTime($params['start_date']);
            $end_date = new DateTime($params['end_date']);
            $end_date->setTime(23, 59, 59);
            $interval = new DateInterval('P1D');
            $period = new DatePeriod($start_date, $interval, $end_date);
            $weekdays = (array)$params['days'];

            $created_slots = array();
            $slots_table = AT_Bookings_Slots_Table::get_slots_table();

            foreach ($period as $date) {
                if (in_array($date->format('w'), $weekdays)) {
                    $start = clone $date;
                    list($hour, $minute) = explode(':', $params['start_time']);
                    $start->setTime($hour, $minute);

                    $end = clone $date;
                    list($hour, $minute) = explode(':', $params['end_time']);
                    $end->setTime($hour, $minute);
                    
                    $slot_data = self::prepare_slot_data($product, $start, $end);

                    $result = $wpdb->insert($slots_table, $slot_data);
                    if ($result) {
                        $created_slots[] = $slot_data;
                    }
                }
            }

            // Log recurring creation
            if (class_exists('AT_Zoho_Sync_Logs') && !empty($created_slots)) {
                AT_Zoho_Sync_Logs::get_instance()->log_sync(
                    'create',
                    'Tour_Schedules',
                    0, // No single ID
                    'Multiple (' . count($created_slots) . ')',
                    'success',
                    $params,
                    ['count' => count($created_slots)],
                    'Recurring slots created via API',
                    'slots',
                    'POST'
                );
            }

            return new WP_REST_Response(array(
                'success' => true,
                'message' => count($created_slots) . ' slots created successfully.',
                'created_slots' => $created_slots,
            ), 201);

        } catch (Exception $e) {
            return new WP_Error('datetime_error', $e->getMessage(), array('status' => 400));
        }
    }

    /**
     * Change the slot for an existing booking
     */
    public static function change_booking_slot(WP_REST_Request $request) {
        $params = $request->get_params();
        $booking_id = (int)$params['booking_id'];
        $new_product_id = (int)$params['new_product_id'];
        $new_start_datetime = $params['new_start_datetime'];

        $booking = get_wc_booking($booking_id);
        if (!$booking) {
            return new WP_Error('invalid_booking', 'Booking not found.', array('status' => 404));
        }

        $new_product = wc_get_product($new_product_id);
        if (!$new_product || $new_product->get_type() !== 'booking') {
            return new WP_Error('invalid_product', 'New product is not a valid booking product.', array('status' => 400));
        }

        try {
            $new_start = new DateTime($new_start_datetime, wp_timezone());
            $new_end = clone $new_start;
            $duration = $new_product->get_duration();
            $duration_unit = $new_product->get_duration_unit();
            $new_end->modify("+$duration $duration_unit");

            // Check availability for the new slot
            $available_slots = $new_product->get_available_bookings($new_start->getTimestamp(), $new_end->getTimestamp());
            if (is_wp_error($available_slots)) {
                return $available_slots;
            }
            if (empty($available_slots)) {
                 return new WP_Error('slot_unavailable', 'The new slot is not available.', array('status' => 400));
            }

            // Update booking details
            $booking->set_product_id($new_product_id);
            $booking->set_start($new_start->getTimestamp());
            $booking->set_end($new_end->getTimestamp());
            $booking->save();

            // Update the corresponding order item
            $order = $booking->get_order();
            if ($order) {
                foreach ($order->get_items() as $item) {
                    if ($item->get_meta('_booking_id') == $booking_id) {
                        $item->set_product_id($new_product_id);
                        $item->save();
                        break;
                    }
                }
                $order->calculate_totals();
                $order->save();
            }

            // Update our custom slots table
            AT_Bookings_Slots_Sync::sync_order_to_slots($order);

            return new WP_REST_Response(array('success' => true, 'message' => 'Booking slot changed successfully.'), 200);

        } catch (Exception $e) {
            return new WP_Error('datetime_error', $e->getMessage(), array('status' => 400));
        }
    }

    /**
     * Bulk upsert slots from external system
     * Creates slots only if they don't exist and have no bookings
     */
    public static function bulk_upsert_slots(WP_REST_Request $request) {
        $params = $request->get_params();
        $product_id = (int)$params['product_id'];
        $slots = $params['slots'] ?? [];

        $product = wc_get_product($product_id);
        if (!$product || $product->get_type() !== 'booking') {
            return new WP_Error('invalid_product', 'Product is not a valid booking product.', array('status' => 400));
        }

        if (empty($slots)) {
            return new WP_Error('empty_slots', 'No slots provided.', array('status' => 400));
        }

        global $wpdb;
        $created = 0;
        $skipped = 0;
        $errors = 0;
        $details = array();

        foreach ($slots as $index => $slot_data) {
            try {
                if (empty($slot_data['start_datetime'])) {
                    $details[] = array(
                        'index' => $index,
                        'action' => 'error',
                        'reason' => 'missing_start_datetime',
                    );
                    $errors++;
                    continue;
                }

                $start = new DateTime($slot_data['start_datetime'], wp_timezone());
                
                if (!empty($slot_data['end_datetime'])) {
                    $end = new DateTime($slot_data['end_datetime'], wp_timezone());
                } else {
                    $end = clone $start;
                    $duration = $product->get_duration();
                    $duration_unit = $product->get_duration_unit();
                    $end->modify("+$duration $duration_unit");
                }

                // Convert to UTC for storage and tour_id generation
                $start_utc = clone $start;
                $start_utc->setTimezone(new DateTimeZone('UTC'));
                $end_utc = clone $end;
                $end_utc->setTimezone(new DateTimeZone('UTC'));

                // Generate tour_id: product_id_utc_timestamp
                $tour_id = $product_id . '_' . $start_utc->getTimestamp();

                // Check if slot exists with bookings
                $check_result = self::check_slot_exists_with_bookings($tour_id);

                if ($check_result['exists']) {
                    $details[] = array(
                        'slot' => $start->format('Y-m-d H:i'),
                        'action' => 'skipped',
                        'reason' => $check_result['bookings_count'] > 0 ? 'has_bookings' : 'already_exists',
                        'bookings_count' => $check_result['bookings_count'],
                        'tour_id' => $tour_id,
                    );
                    $skipped++;
                    continue;
                }

                // Create new slot
                $slot_data_prepared = self::prepare_slot_data($product, $start_utc, $end_utc);
                $slots_table = AT_Bookings_Slots_Table::get_slots_table();

                $result = $wpdb->insert($slots_table, $slot_data_prepared);

                if ($result) {
                    $details[] = array(
                        'slot' => $start->format('Y-m-d H:i'),
                        'action' => 'created',
                        'tour_id' => $tour_id,
                    );
                    $created++;
                } else {
                    $details[] = array(
                        'slot' => $start->format('Y-m-d H:i'),
                        'action' => 'error',
                        'reason' => 'db_error',
                        'tour_id' => $tour_id,
                    );
                    $errors++;
                }

            } catch (Exception $e) {
                $details[] = array(
                    'index' => $index,
                    'action' => 'error',
                    'reason' => 'datetime_error',
                    'message' => $e->getMessage(),
                );
                $errors++;
            }
        }

        $response_data = array(
            'success' => true,
            'summary' => array(
                'total' => count($slots),
                'created' => $created,
                'skipped' => $skipped,
                'errors' => $errors,
            ),
            'details' => $details,
        );

        // Log bulk upsert
        if (class_exists('AT_Zoho_Sync_Logs')) {
            AT_Zoho_Sync_Logs::get_instance()->log_sync(
                'import',
                'Tour_Schedules',
                0,
                'Bulk (' . count($slots) . ')',
                'success',
                ['product_id' => $product_id, 'count' => count($slots)],
                $response_data['summary'],
                'Bulk upsert via API',
                'slots/bulk-upsert',
                'POST'
            );
        }

        return new WP_REST_Response($response_data, 200);
    }

    /**
     * Check if a slot exists and how many bookings it has
     */
    private static function check_slot_exists_with_bookings($tour_id) {
        global $wpdb;
        $slots_table = AT_Bookings_Slots_Table::get_slots_table();

        $slot = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id, current_bookings, status FROM {$slots_table} WHERE tour_id = %s",
                $tour_id
            )
        );

        if (!$slot) {
            return array('exists' => false);
        }

        return array(
            'exists' => true,
            'slot_id' => (int)$slot->id,
            'bookings_count' => (int)$slot->current_bookings,
            'status' => $slot->status,
        );
    }

    /**
     * Prepare data for a single slot insertion
     */
    private static function prepare_slot_data($product, $start_datetime, $end_datetime) {
        $product_id = $product->get_id();
        $max_capacity = (int) $product->get_max_persons() ?: 1;

        // Ensure start and end are in UTC for DB storage
        $start_utc = clone $start_datetime;
        $start_utc->setTimezone(new DateTimeZone('UTC'));
        $end_utc = clone $end_datetime;
        $end_utc->setTimezone(new DateTimeZone('UTC'));

        return array(
            'product_id' => $product_id,
            'slot_start' => $start_utc->format('Y-m-d H:i:s'),
            'slot_end' => $end_utc->format('Y-m-d H:i:s'),
            'tour_id' => $product_id . '_' . $start_utc->getTimestamp(),
            'max_capacity' => $max_capacity,
            'status' => 'active',
        );
    }
}

AT_Slots_Endpoint::init();
