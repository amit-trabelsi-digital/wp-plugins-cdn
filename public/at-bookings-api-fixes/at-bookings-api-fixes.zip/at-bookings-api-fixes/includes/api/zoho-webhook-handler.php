<?php
/**
 * Zoho Webhook Handler
 * מטפל בעדכונים מ-Zoho CRM (הזמנות, מחזורים)
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Zoho_Webhook_Handler {
    
    public static function init() {
        add_action('rest_api_init', array(__CLASS__, 'register_routes'));
    }
    
    public static function register_routes() {
        // Webhook לעדכון הזמנות
        register_rest_route('at/v1', '/zoho-webhook/order-update', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array(__CLASS__, 'handle_order_update'),
            'permission_callback' => array(__CLASS__, 'verify_zoho_webhook'),
        ));
        
        // Webhook לעדכון מחזורים
        register_rest_route('at/v1', '/zoho-webhook/cycle-update', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array(__CLASS__, 'handle_cycle_update'),
            'permission_callback' => array(__CLASS__, 'verify_zoho_webhook'),
        ));
    }
    
    /**
     * אימות webhook מ-Zoho
     */
    public static function verify_zoho_webhook($request) {
        $secret = get_option('at_zoho_webhook_secret', '');
        $signature = $request->get_header('X-Zoho-Signature');
        
        if (empty($secret) || empty($signature)) {
            return new WP_Error('auth_failed', 'Missing authentication', array('status' => 401));
        }
        
        $body = $request->get_body();
        $expected = hash_hmac('sha256', $body, $secret);
        
        if (!hash_equals($expected, $signature)) {
            return new WP_Error('auth_failed', 'Invalid signature', array('status' => 403));
        }
        
        return true;
    }
    
    /**
     * טיפול בעדכון הזמנה מ-Zoho
     */
    public static function handle_order_update(WP_REST_Request $request) {
        $data = $request->get_json_params();
        
        // דוגמה למבנה:
        // {
        //   "zoho_order_id": "123456789",
        //   "status": "Paid",
        //   "wp_order_id": "456" (אופציונלי)
        // }
        
        $zoho_order_id = $data['zoho_order_id'] ?? '';
        $new_status = $data['status'] ?? '';
        
        if (empty($zoho_order_id) || empty($new_status)) {
            return new WP_Error('missing_data', 'Missing required fields', array('status' => 400));
        }
        
        // מצא את ההזמנה ב-WordPress לפי Zoho ID
        $wp_order_id = self::find_order_by_zoho_id($zoho_order_id);
        
        if (!$wp_order_id) {
            return new WP_Error('order_not_found', 'Order not found in WordPress', array('status' => 404));
        }
        
        $order = wc_get_order($wp_order_id);
        
        // המר סטטוס Zoho ל-WooCommerce
        $wc_status = self::map_zoho_status_to_wc($new_status);
        
        // תיעוד השינוי בהערות ההזמנה עם זמן מלא
        $note = sprintf(
            __('Status updated from Zoho CRM: %s -> %s via Webhook. Timestamp: %s', 'at-bookings-api-fixes'),
            $order->get_status(),
            $wc_status,
            current_time('Y-m-d H:i:s')
        );
        $order->add_order_note($note);
        
        // עדכן סטטוס
        $order->update_status($wc_status, __('Status updated from Zoho CRM', 'at-bookings-api-fixes'));
        
        // רשום לוגים ב-Logs Screen
        if (class_exists('AT_Zoho_Sync_Logs')) {
            AT_Zoho_Sync_Logs::get_instance()->log_sync(
                'update',
                'Sales_Orders',
                $wp_order_id,
                $zoho_order_id,
                'success',
                $data,
                ['new_status' => $wc_status],
                null,
                'webhook/order-update',
                'POST'
            );
        }
        
        // רשום לוגים
        write_detailed_log("Order #{$wp_order_id} updated from Zoho: {$new_status} → {$wc_status}", 'INFO');
        
        return new WP_REST_Response(array(
            'success' => true,
            'wp_order_id' => $wp_order_id,
            'new_status' => $wc_status
        ), 200);
    }
    
    /**
     * טיפול בעדכון מחזור מ-Zoho
     */
    public static function handle_cycle_update(WP_REST_Request $request) {
        $data = $request->get_json_params();
        
        // דוגמה למבנה:
        // {
        //   "tour_sku": "123_1234567890",
        //   "new_start_datetime": "2025-02-15T10:00:00",
        //   "booking_ids": ["789", "790"] (אופציונלי - bookings לעדכון)
        // }
        
        $tour_sku = $data['tour_sku'] ?? '';
        $new_datetime = $data['new_start_datetime'] ?? '';
        
        if (empty($tour_sku) || empty($new_datetime)) {
            return new WP_Error('missing_data', 'Missing required fields', array('status' => 400));
        }
        
        // מצא את המחזור לפי tour_sku
        global $wpdb;
        $slots_table = AT_Bookings_Slots_Table::get_slots_table();
        
        $slot = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$slots_table} WHERE tour_id = %s",
            $tour_sku
        ), ARRAY_A);
        
        if (!$slot) {
            // Log missing cycle error
            if (class_exists('AT_Zoho_Sync_Logs')) {
                AT_Zoho_Sync_Logs::get_instance()->log_sync(
                    'update',
                    'Tour_Schedules',
                    0,
                    $tour_sku,
                    'error',
                    $data,
                    null,
                    'Cycle not found',
                    'webhook/cycle-update',
                    'POST'
                );
            }
            return new WP_REST_Response(array(
                'success' => false, 
                'message' => 'Cycle not found'
            ), 404); // Changed to valid response to allow logging
        }
        
        // בדוק אם יש הזמנות למחזור
        $has_bookings = (int)$slot['current_bookings'] > 0;
        $response = null;
        
        if ($has_bookings) {
            // אסטרטגיה: צור booking חדש ומחק את הישן
            $response = self::recreate_bookings_for_new_cycle($slot, $new_datetime, $data['booking_ids'] ?? []);
        } else {
            // אין הזמנות - עדכן את המחזור ישירות
            $new_timestamp = strtotime($new_datetime);
            
            $wpdb->update(
                $slots_table,
                array(
                    'slot_start' => date('Y-m-d H:i:s', $new_timestamp),
                    'slot_end' => date('Y-m-d H:i:s', $new_timestamp + 3600) // +1 hour (adjust per product)
                ),
                array('tour_id' => $tour_sku)
            );
            
            $response = new WP_REST_Response(array(
                'success' => true,
                'action' => 'updated',
                'tour_sku' => $tour_sku
            ), 200);
        }

        // Log success
        if (class_exists('AT_Zoho_Sync_Logs')) {
            AT_Zoho_Sync_Logs::get_instance()->log_sync(
                'update',
                'Tour_Schedules',
                $slot['id'], // slot DB ID
                $tour_sku,
                'success',
                $data,
                $response->get_data(),
                null,
                'webhook/cycle-update',
                'POST'
            );
        }

        return $response;
    }
    
    /**
     * יצירת bookings חדשים במחזור חדש (כאשר משנים תאריך)
     */
    private static function recreate_bookings_for_new_cycle($old_slot, $new_datetime, $booking_ids) {
        $product = wc_get_product($old_slot['product_id']);
        
        if (!$product) {
            return new WP_Error('product_not_found', 'Product not found', array('status' => 404));
        }
        
        // צור מחזור חדש
        $new_start = new DateTime($new_datetime, wp_timezone());
        $new_end = clone $new_start;
        $new_end->modify('+' . $product->get_duration() . ' ' . $product->get_duration_unit());
        
        // הכנס slot חדש
        global $wpdb;
        $slots_table = AT_Bookings_Slots_Table::get_slots_table();
        
        $new_slot_data = array(
            'product_id' => $product->get_id(),
            'slot_start' => $new_start->format('Y-m-d H:i:s'),
            'slot_end' => $new_end->format('Y-m-d H:i:s'),
            'tour_id' => $product->get_id() . '_' . $new_start->getTimestamp(),
            'max_capacity' => $old_slot['max_capacity'],
            'status' => 'active'
        );
        
        $wpdb->insert($slots_table, $new_slot_data);
        
        // עבור על כל ה-bookings והעבר אותם למחזור החדש
        $moved_bookings = [];
        
        foreach ($booking_ids as $booking_id) {
            $booking = get_wc_booking($booking_id);
            
            if (!$booking) {
                continue;
            }
            
            // הוסף הערה לbooking הישן לפני השינוי
            $old_start = date('Y-m-d H:i', $booking->get_start());
            
            // עדכן את ה-booking
            $booking->set_start($new_start->getTimestamp());
            $booking->set_end($new_end->getTimestamp());
            $booking->save();
            
            // הוסף הערה על העדכון מזוהו (כקומנט ל-post)
            $note = sprintf(
                __('Cycle date updated from Zoho CRM via Webhook. Old: %s, New: %s. Timestamp: %s', 'at-bookings-api-fixes'),
                $old_start,
                $new_start->format('Y-m-d H:i'),
                current_time('Y-m-d H:i:s')
            );
            
            // Add note to Booking (WC Bookings uses comments)
            wp_insert_comment(array(
                'comment_post_ID' => $booking_id,
                'comment_author' => 'Zoho Webhook',
                'comment_content' => $note,
                'comment_type' => 'order_note', // Standard WC order note type
                'comment_meta' => array(
                    'is_customer_note' => 0
                )
            ));
            
            $moved_bookings[] = $booking_id;
        }
        
        // מחק את המחזור הישן (רק אם הועברו כל ההזמנות)
        if (count($moved_bookings) > 0) {
            $wpdb->delete($slots_table, array('tour_id' => $old_slot['tour_id']));
        }
        
        return new WP_REST_Response(array(
            'success' => true,
            'action' => 'recreated',
            'old_tour_id' => $old_slot['tour_id'],
            'new_tour_id' => $new_slot_data['tour_id'],
            'moved_bookings' => $moved_bookings
        ), 200);
    }
    
    /**
     * מצא הזמנה לפי Zoho ID
     */
    private static function find_order_by_zoho_id($zoho_id) {
        global $wpdb;
        
        $result = $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} 
             WHERE meta_key = '_zoho_order_id' AND meta_value = %s",
            $zoho_id
        ));
        
        return $result ? (int)$result : false;
    }
    
    /**
     * המרת סטטוס Zoho ל-WooCommerce
     */
    private static function map_zoho_status_to_wc($zoho_status) {
        $status_map = array(
            'Paid' => 'completed',
            'Pending' => 'on-hold',
            'חדש' => 'processing',
            'Cancelled' => 'cancelled',
            'Refunded' => 'refunded'
        );
        
        return $status_map[$zoho_status] ?? 'processing';
    }
}

AT_Zoho_Webhook_Handler::init();

