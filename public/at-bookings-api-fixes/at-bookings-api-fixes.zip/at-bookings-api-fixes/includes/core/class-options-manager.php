<?php
/**
 * Central Options Manager for AT Bookings API Fixes
 * 
 * Handles all WordPress options management in one centralized location
 * 
 * @package AT_Bookings_API_Fixes
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Options_Manager {
    
    // Option keys
    const OPTION_API_KEY = 'at_bookings_api_key';
    const OPTION_VERSION = 'at_bookings_fixes_version';
    const OPTION_ACTIVATED = 'at_bookings_fixes_activated';
    const OPTION_REDIS_ERROR = 'at_redis_error_detected';
    
    // Zoho options
    const OPTION_ZOHO_CLIENT_ID = 'at_zoho_client_id';
    const OPTION_ZOHO_CLIENT_SECRET = 'at_zoho_client_secret';
    const OPTION_ZOHO_DOMAIN = 'at_zoho_domain';
    const OPTION_ZOHO_REFRESH_TOKEN = 'at_zoho_refresh_token';
    const OPTION_ZOHO_ACCESS_TOKEN = 'at_zoho_access_token';
    const OPTION_ZOHO_TOKEN_EXPIRES = 'at_zoho_token_expires';
    
    /**
     * Ensure API key exists, create if missing
     * 
     * @return string API key
     */
    public static function ensure_api_key() {
        $api_key = get_option(self::OPTION_API_KEY);
        
        if (empty($api_key)) {
            $api_key = wp_generate_password(32, false);
            add_option(self::OPTION_API_KEY, $api_key, '', 'no');
        }
        
        return $api_key;
    }
    
    /**
     * Ensure version option exists
     * 
     * @param string $current_version Current plugin version
     * @return bool True if version was updated
     */
    public static function ensure_version_option($current_version) {
        $stored_version = get_option(self::OPTION_VERSION);
        
        if ($stored_version !== $current_version) {
            update_option(self::OPTION_VERSION, $current_version);
            return true;
        }
        
        return false;
    }
    
    /**
     * Record plugin activation timestamp
     * 
     * @return void
     */
    public static function record_activation() {
        add_option(self::OPTION_ACTIVATED, current_time('mysql'), '', 'no');
    }
    
    /**
     * Get all Zoho settings
     * 
     * @return array Zoho configuration
     */
    public static function get_zoho_settings() {
        return array(
            'client_id' => get_option(self::OPTION_ZOHO_CLIENT_ID),
            'client_secret' => get_option(self::OPTION_ZOHO_CLIENT_SECRET),
            'domain' => get_option(self::OPTION_ZOHO_DOMAIN),
            'refresh_token' => get_option(self::OPTION_ZOHO_REFRESH_TOKEN),
            'access_token' => get_option(self::OPTION_ZOHO_ACCESS_TOKEN),
            'token_expires' => get_option(self::OPTION_ZOHO_TOKEN_EXPIRES)
        );
    }
    
    /**
     * Update Zoho settings
     * 
     * @param array $settings Zoho settings to update
     * @return bool Success status
     */
    public static function update_zoho_settings($settings) {
        $success = true;
        
        $mapping = array(
            'client_id' => self::OPTION_ZOHO_CLIENT_ID,
            'client_secret' => self::OPTION_ZOHO_CLIENT_SECRET,
            'domain' => self::OPTION_ZOHO_DOMAIN,
            'refresh_token' => self::OPTION_ZOHO_REFRESH_TOKEN,
            'access_token' => self::OPTION_ZOHO_ACCESS_TOKEN,
            'token_expires' => self::OPTION_ZOHO_TOKEN_EXPIRES
        );
        
        foreach ($mapping as $key => $option_name) {
            if (isset($settings[$key])) {
                if (!update_option($option_name, $settings[$key])) {
                    $success = false;
                }
            }
        }
        
        return $success;
    }
    
    /**
     * Check if Redis error was detected
     * 
     * @return bool
     */
    public static function has_redis_error() {
        return (bool) get_transient(self::OPTION_REDIS_ERROR);
    }
    
    /**
     * Set Redis error flag
     * 
     * @param int $duration Duration in seconds (default: 5 minutes)
     * @return void
     */
    public static function set_redis_error($duration = 300) {
        set_transient(self::OPTION_REDIS_ERROR, true, $duration);
    }
    
    /**
     * Clear Redis error flag
     * 
     * @return void
     */
    public static function clear_redis_error() {
        delete_transient(self::OPTION_REDIS_ERROR);
    }
    
    /**
     * Clean up old options on deactivation
     * 
     * @return void
     */
    public static function cleanup_options() {
        // Note: Keep important data, only remove temporary flags
        delete_transient(self::OPTION_REDIS_ERROR);
    }
}
