<?php
/**
 * Central Logger for AT Bookings API Fixes
 * 
 * Unified logging system with automatic cleanup and rotation
 * 
 * @package AT_Bookings_API_Fixes
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Bookings_Logger {
    
    // Log levels
    const LEVEL_DEBUG = 'DEBUG';
    const LEVEL_INFO = 'INFO';
    const LEVEL_WARNING = 'WARNING';
    const LEVEL_ERROR = 'ERROR';
    const LEVEL_CRITICAL = 'CRITICAL';
    
    // Log file location
    private static $log_file;
    
    // Maximum log file size (5MB)
    private static $max_file_size = 5242880;
    
    // Maximum log retention days
    private static $retention_days = 7;
    
    /**
     * Initialize logger - call this on plugin load
     * 
     * @return void
     */
    public static function init() {
        self::$log_file = WP_CONTENT_DIR . '/logs/at-bookings-debug.log';
        
        // Ensure logs directory exists
        if (!is_dir(dirname(self::$log_file))) {
            wp_mkdir_p(dirname(self::$log_file));
        }
        
        // Run cleanup periodically
        add_action('wp_scheduled_delete', array(__CLASS__, 'cleanup_old_logs'));
    }
    
    /**
     * Log a message
     * 
     * @param string $message Message to log
     * @param string $level Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
     * @param array $context Additional context data
     * @return bool Success status
     */
    public static function log($message, $level = self::LEVEL_INFO, $context = array()) {
        // Check log file size and rotate if needed
        self::check_rotation();
        
        // Format timestamp
        $timestamp = current_time('Y-m-d H:i:s');
        
        // Format context
        $context_str = '';
        if (!empty($context)) {
            $context_str = ' | ' . json_encode($context);
        }
        
        // Format log line
        $log_line = "[{$timestamp}] [{$level}] {$message}{$context_str}\n";
        
        // Write to file
        $result = @file_put_contents(
            self::$log_file,
            $log_line,
            FILE_APPEND | LOCK_EX
        );
        
        // Also send to WordPress error log for critical errors
        if ($level === self::LEVEL_CRITICAL || $level === self::LEVEL_ERROR) {
            error_log("[AT Bookings] [{$level}] {$message}");
        }
        
        return ($result !== false);
    }
    
    /**
     * Log debug message
     * 
     * @param string $message Message to log
     * @param array $context Context data
     * @return bool Success status
     */
    public static function debug($message, $context = array()) {
        return self::log($message, self::LEVEL_DEBUG, $context);
    }
    
    /**
     * Log info message
     * 
     * @param string $message Message to log
     * @param array $context Context data
     * @return bool Success status
     */
    public static function info($message, $context = array()) {
        return self::log($message, self::LEVEL_INFO, $context);
    }
    
    /**
     * Log warning message
     * 
     * @param string $message Message to log
     * @param array $context Context data
     * @return bool Success status
     */
    public static function warning($message, $context = array()) {
        return self::log($message, self::LEVEL_WARNING, $context);
    }
    
    /**
     * Log error message
     * 
     * @param string $message Message to log
     * @param array $context Context data
     * @return bool Success status
     */
    public static function error($message, $context = array()) {
        return self::log($message, self::LEVEL_ERROR, $context);
    }
    
    /**
     * Log critical message
     * 
     * @param string $message Message to log
     * @param array $context Context data
     * @return bool Success status
     */
    public static function critical($message, $context = array()) {
        return self::log($message, self::LEVEL_CRITICAL, $context);
    }
    
    /**
     * Get recent log entries
     * 
     * @param int $lines Number of lines to retrieve (default: 100)
     * @param string $level Filter by level (empty for all)
     * @return array Log entries
     */
    public static function get_recent_logs($lines = 100, $level = '') {
        if (!file_exists(self::$log_file)) {
            return array();
        }
        
        $entries = array();
        $file_lines = file(self::$log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        
        if (empty($file_lines)) {
            return $entries;
        }
        
        // Get last N lines
        $file_lines = array_slice($file_lines, -$lines);
        
        foreach ($file_lines as $line) {
            // Filter by level if specified
            if (!empty($level) && strpos($line, "[{$level}]") === false) {
                continue;
            }
            
            $entries[] = $line;
        }
        
        return array_reverse($entries);
    }
    
    /**
     * Clear all logs
     * 
     * @return bool Success status
     */
    public static function clear_logs() {
        if (file_exists(self::$log_file)) {
            return @unlink(self::$log_file);
        }
        
        return true;
    }
    
    /**
     * Check if log file needs rotation and rotate if needed
     * 
     * @return void
     */
    private static function check_rotation() {
        if (!file_exists(self::$log_file)) {
            return;
        }
        
        $file_size = filesize(self::$log_file);
        
        if ($file_size > self::$max_file_size) {
            self::rotate_log();
        }
    }
    
    /**
     * Rotate log file
     * 
     * @return void
     */
    private static function rotate_log() {
        $timestamp = current_time('Y-m-d-H-i-s');
        $backup_file = dirname(self::$log_file) . '/at-bookings-debug-' . $timestamp . '.log';
        
        @rename(self::$log_file, $backup_file);
    }
    
    /**
     * Clean up old log files
     * 
     * @return int Number of files deleted
     */
    public static function cleanup_old_logs() {
        $log_dir = dirname(self::$log_file);
        
        if (!is_dir($log_dir)) {
            return 0;
        }
        
        $deleted = 0;
        $cutoff_time = strtotime('-' . self::$retention_days . ' days');
        
        $files = glob($log_dir . '/at-bookings-*.log');
        
        if (empty($files)) {
            return 0;
        }
        
        foreach ($files as $file) {
            if (filemtime($file) < $cutoff_time) {
                if (@unlink($file)) {
                    $deleted++;
                }
            }
        }
        
        return $deleted;
    }
    
    /**
     * Get log file size in readable format
     * 
     * @return string Human-readable file size
     */
    public static function get_log_file_size() {
        if (!file_exists(self::$log_file)) {
            return '0 B';
        }
        
        $size = filesize(self::$log_file);
        
        $units = array('B', 'KB', 'MB', 'GB');
        $size = max($size, 0);
        $pow = floor(($size ? log($size) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        $size /= (1 << (10 * $pow));
        
        return round($size, 2) . ' ' . $units[$pow];
    }
}

// Initialize logger on plugin load
AT_Bookings_Logger::init();
