<?php
/**
 * Smart Plugin Loader for AT Bookings API Fixes
 * 
 * Implements dynamic and conditional module loading
 * Reduces load time and memory usage significantly
 * 
 * @package AT_Bookings_API_Fixes
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Smart_Loader {
    
    private static $instance = null;
    private $loaded_modules = array();
    private $plugin_dir;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->plugin_dir = dirname(dirname(dirname(__FILE__)));
    }
    
    /**
     * Load module with conditions check
     * 
     * @param string $module_name Module name (without extension)
     * @param array $conditions Conditions to check before loading
     * @param string $module_type Type: 'admin', 'zoho', 'core', etc.
     * @return bool Whether module was loaded
     */
    public function load_module($module_name, $conditions = array(), $module_type = 'core') {
        // Prevent duplicate loading
        if (isset($this->loaded_modules[$module_name])) {
            return $this->loaded_modules[$module_name];
        }
        
        // Check conditions before loading
        if (!$this->check_conditions($conditions)) {
            $this->loaded_modules[$module_name] = false;
            return false;
        }
        
        // Determine file path based on module type
        $file_path = $this->get_module_path($module_name, $module_type);
        
        if (file_exists($file_path)) {
            require_once $file_path;
            $this->loaded_modules[$module_name] = true;
            AT_Bookings_Logger::debug("Module loaded: {$module_name}", array('type' => $module_type));
            return true;
        }
        
        $this->loaded_modules[$module_name] = false;
        AT_Bookings_Logger::warning("Module file not found: {$file_path}");
        return false;
    }
    
    /**
     * Load all core modules
     */
    public function load_core_modules() {
        $this->load_module('class-options-manager', array(), 'core');
        $this->load_module('class-security-manager', array(), 'core');
        $this->load_module('class-logger', array(), 'core');
    }
    
    /**
     * Load Zoho modules (only in admin)
     */
    public function load_zoho_modules() {
        if (!is_admin()) {
            return;
        }
        
        $this->load_module('class-zoho-core', array(), 'zoho');
        $this->load_module('class-zoho-sync', array(), 'zoho');
        $this->load_module('class-zoho-admin', array('is_admin' => true), 'zoho');
        $this->load_module('class-zoho-wc-integration', array('plugin_active' => 'woocommerce/woocommerce.php'), 'zoho');
    }
    
    /**
     * Load Admin modules (only in admin)
     */
    public function load_admin_modules() {
        if (!is_admin()) {
            return;
        }
        
        $this->load_module('class-admin-core', array('is_admin' => true), 'admin');
        $this->load_module('class-admin-pages', array('is_admin' => true), 'admin');
    }
    
    /**
     * Get module file path
     */
    private function get_module_path($module_name, $module_type) {
        switch ($module_type) {
            case 'core':
                return $this->plugin_dir . '/includes/core/' . $module_name . '.php';
            case 'zoho':
                return $this->plugin_dir . '/modules/zoho/' . $module_name . '.php';
            case 'admin':
                return $this->plugin_dir . '/modules/admin/' . $module_name . '.php';
            default:
                return $this->plugin_dir . '/includes/' . $module_type . '/' . $module_name . '.php';
        }
    }
    
    /**
     * Check if conditions are met for loading
     * 
     * @param array $conditions Conditions array
     * @return bool True if all conditions are met
     */
    private function check_conditions($conditions) {
        if (empty($conditions)) {
            return true;
        }
        
        foreach ($conditions as $condition => $value) {
            switch ($condition) {
                case 'is_admin':
                    if ($value && !is_admin()) {
                        return false;
                    }
                    break;
                    
                case 'is_frontend':
                    if ($value && is_admin()) {
                        return false;
                    }
                    break;
                    
                case 'plugin_active':
                    if (!is_plugin_active($value)) {
                        return false;
                    }
                    break;
                    
                case 'class_exists':
                    if (!class_exists($value)) {
                        return false;
                    }
                    break;
                    
                case 'function_exists':
                    if (!function_exists($value)) {
                        return false;
                    }
                    break;
                    
                case 'constant_defined':
                    if (!defined($value)) {
                        return false;
                    }
                    break;
            }
        }
        
        return true;
    }
    
    /**
     * Get loaded modules list
     */
    public function get_loaded_modules() {
        return array_keys(array_filter($this->loaded_modules));
    }
    
    /**
     * Get failed modules list
     */
    public function get_failed_modules() {
        return array_keys(array_filter($this->loaded_modules, function($loaded) {
            return !$loaded;
        }));
    }
}

// Initialize Smart Loader
AT_Smart_Loader::get_instance();
