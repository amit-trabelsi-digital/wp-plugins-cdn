<?php
/**
 * Central Security Manager for AT Bookings API Fixes
 * 
 * Handles all nonce verification and permission checks in one centralized location
 * 
 * @package AT_Bookings_API_Fixes
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Security_Manager {
    
    // AJAX nonce actions
    const NONCE_DASHBOARD = 'at_bookings_dashboard';
    const NONCE_ZOHO_SYNC = 'at_zoho_sync';
    const NONCE_API = 'at_bookings_api';

    /**
     * Read an API credential from headers.
     *
     * Query-string credentials are intentionally disabled by default because
     * URLs are routinely stored in access logs, browser history and analytics.
     * A short migration window can be enabled explicitly with
     * AT_BOOKINGS_ALLOW_QUERY_API_KEY.
     *
     * @param WP_REST_Request $request REST request.
     * @return string
     */
    public static function get_request_api_key($request) {
        $authorization = trim((string) $request->get_header('authorization'));

        if (preg_match('/^Bearer\s+(.+)$/i', $authorization, $matches)) {
            return trim($matches[1]);
        }

        $header_key = trim((string) $request->get_header('x-at-api-key'));
        if ($header_key !== '') {
            return $header_key;
        }

        if (defined('AT_BOOKINGS_ALLOW_QUERY_API_KEY') && AT_BOOKINGS_ALLOW_QUERY_API_KEY) {
            return trim((string) $request->get_param('api_key'));
        }

        return '';
    }
    
    /**
     * Verify admin AJAX request with nonce and capability check
     * 
     * @param string $nonce_action Nonce action name (default: dashboard)
     * @param string $nonce_param Parameter name for nonce (default: 'nonce')
     * @return bool Returns true if verification passed, false otherwise
     */
    public static function verify_ajax_admin($nonce_action = self::NONCE_DASHBOARD, $nonce_param = 'nonce') {
        // Check nonce
        if (!isset($_REQUEST[$nonce_param])) {
            wp_send_json_error(__('Security check failed - missing nonce', 'at-bookings-api-fixes'));
            return false;
        }
        
        if (!check_ajax_referer($nonce_action, $nonce_param, false)) {
            wp_send_json_error(__('Security check failed - invalid nonce', 'at-bookings-api-fixes'));
            return false;
        }
        
        // Check capability
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
            return false;
        }
        
        return true;
    }
    
    /**
     * Verify WooCommerce manager AJAX request
     * 
     * @param string $nonce_action Nonce action name (default: zoho_sync)
     * @param string $nonce_param Parameter name for nonce (default: 'nonce')
     * @return bool Returns true if verification passed
     */
    public static function verify_ajax_woo($nonce_action = self::NONCE_ZOHO_SYNC, $nonce_param = 'nonce') {
        // Check nonce
        if (!isset($_REQUEST[$nonce_param])) {
            wp_send_json_error(__('Security check failed - missing nonce', 'at-bookings-api-fixes'));
            return false;
        }
        
        if (!check_ajax_referer($nonce_action, $nonce_param, false)) {
            wp_send_json_error(__('Security check failed - invalid nonce', 'at-bookings-api-fixes'));
            return false;
        }
        
        // Check capability
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
            return false;
        }
        
        return true;
    }
    
    /**
     * Verify API request with API key or debug mode
     * 
     * @param object $request WP_REST_Request object
     * @return bool|WP_Error True if authorized, WP_Error otherwise
     */
    public static function verify_api_request($request) {
        // Credentials must travel in a header, never in a URL.
        $api_key = self::get_request_api_key($request);
        
        // Check if user is admin (REST API)
        if (current_user_can('manage_options')) {
            return true;
        }
        
        // Verify API key
        if (empty($api_key)) {
            return new WP_Error(
                'missing_api_key',
                __('API key is required', 'at-bookings-api-fixes'),
                array('status' => 401)
            );
        }
        
        $stored_key = get_option('at_bookings_api_key');
        
        if (empty($stored_key) || !hash_equals((string) $stored_key, (string) $api_key)) {
            return new WP_Error(
                'invalid_api_key',
                __('Invalid API key', 'at-bookings-api-fixes'),
                array('status' => 403)
            );
        }
        
        return true;
    }
    
    /**
     * Sanitize and validate text input
     * 
     * @param string $input Input to sanitize
     * @param string $type Type of sanitization (text, email, url, int, etc.)
     * @return mixed Sanitized input
     */
    public static function sanitize_input($input, $type = 'text') {
        switch ($type) {
            case 'email':
                return sanitize_email($input);
            case 'url':
                return esc_url($input);
            case 'int':
                return intval($input);
            case 'float':
                return floatval($input);
            case 'boolean':
                return filter_var($input, FILTER_VALIDATE_BOOLEAN);
            case 'html':
                return wp_kses_post($input);
            case 'text':
            default:
                return sanitize_text_field($input);
        }
    }
    
    /**
     * Escape output for safe display
     * 
     * @param string $output Output to escape
     * @param string $type Type of escaping (html, attr, url, js, etc.)
     * @return string Escaped output
     */
    public static function escape_output($output, $type = 'html') {
        switch ($type) {
            case 'attr':
                return esc_attr($output);
            case 'url':
                return esc_url($output);
            case 'js':
                return esc_js($output);
            case 'html':
            default:
                return esc_html($output);
        }
    }
    
    /**
     * Get nonce field HTML
     * 
     * @param string $action Nonce action
     * @param string $name Nonce field name
     * @return string Nonce field HTML
     */
    public static function get_nonce_field($action = self::NONCE_DASHBOARD, $name = 'nonce') {
        return wp_nonce_field($action, $name, false, false);
    }
    
    /**
     * Create nonce for use in AJAX calls
     * 
     * @param string $action Nonce action
     * @return string Nonce value
     */
    public static function create_nonce($action = self::NONCE_DASHBOARD) {
        return wp_create_nonce($action);
    }
}
