<?php

defined('ABSPATH') || exit;

final class AT_Bookings_Private_CDN_Updater
{
    private $slug;
    private $plugin_file;
    private $current_version;
    private $manifest_url;
    private $cache_key;

    public function __construct($args)
    {
        $this->slug = $args['slug'];
        $this->plugin_file = $args['plugin_file'];
        $this->current_version = $args['current_version'];
        $this->manifest_url = $args['manifest_url'];
        $this->cache_key = 'at_cdn_manifest_' . md5($this->manifest_url);

        $hostname = wp_parse_url($this->manifest_url, PHP_URL_HOST);
        if ($hostname) {
            add_filter('update_plugins_' . $hostname, array($this, 'filter_update'), 10, 4);
        }
        add_filter('plugins_api', array($this, 'plugin_information'), 10, 3);
        add_action('upgrader_process_complete', array($this, 'clear_cache_after_upgrade'), 10, 2);
        add_action('load-plugins.php', array($this, 'refresh_update_check'));
    }

    public function filter_update($update, $plugin_data, $plugin_file, $locales)
    {
        if ($plugin_file !== $this->plugin_file || !empty($update)) {
            return $update;
        }
        $manifest = $this->get_manifest();
        if (!$manifest || !version_compare($this->current_version, $manifest['version'], '<')) {
            return $update;
        }
        return (object) array(
            'id' => $plugin_data['UpdateURI'] ?? $this->manifest_url,
            'slug' => $this->slug,
            'plugin' => $this->plugin_file,
            'new_version' => $manifest['version'],
            'version' => $manifest['version'],
            'url' => $manifest['homepage'] ?? $this->manifest_url,
            'package' => $manifest['package'],
            'tested' => $manifest['tested'] ?? '',
            'requires' => $manifest['requires'] ?? '',
            'requires_php' => $manifest['requires_php'] ?? '',
        );
    }

    public function plugin_information($result, $action, $args)
    {
        if ('plugin_information' !== $action || empty($args->slug) || $this->slug !== $args->slug) {
            return $result;
        }
        $manifest = $this->get_manifest();
        if (!$manifest) {
            return $result;
        }
        return (object) array(
            'name' => $manifest['name'] ?? $this->slug,
            'slug' => $this->slug,
            'version' => $manifest['version'],
            'author' => $manifest['author'] ?? '',
            'homepage' => $manifest['homepage'] ?? $this->manifest_url,
            'requires' => $manifest['requires'] ?? '',
            'tested' => $manifest['tested'] ?? '',
            'requires_php' => $manifest['requires_php'] ?? '',
            'last_updated' => $manifest['last_updated'] ?? '',
            'sections' => is_array($manifest['sections'] ?? null) ? $manifest['sections'] : array(),
            'download_link' => $manifest['package'],
        );
    }

    public function clear_cache_after_upgrade($upgrader, $options)
    {
        if ('plugin' === ($options['type'] ?? '') && in_array($this->plugin_file, (array) ($options['plugins'] ?? array()), true)) {
            delete_site_transient($this->cache_key);
        }
    }

    public function refresh_update_check()
    {
        if (!current_user_can('update_plugins')) {
            return;
        }
        $refresh_key = 'at_cdn_update_check_' . md5($this->plugin_file);
        if (get_site_transient($refresh_key)) {
            return;
        }
        delete_site_transient($this->cache_key);
        set_site_transient($refresh_key, time(), 15 * MINUTE_IN_SECONDS);
        wp_update_plugins(array('at_cdn_plugin' => $this->slug));
    }

    private function get_manifest()
    {
        $cached = get_site_transient($this->cache_key);
        if (is_array($cached)) {
            return $cached;
        }
        $response = wp_remote_get($this->manifest_url, array(
            'timeout' => 10,
            'redirection' => 2,
            'headers' => array('Accept' => 'application/json'),
        ));
        if (is_wp_error($response) || 200 !== wp_remote_retrieve_response_code($response)) {
            return false;
        }
        $manifest = json_decode(wp_remote_retrieve_body($response), true);
        if (!is_array($manifest) || empty($manifest['version']) || empty($manifest['package'])) {
            return false;
        }
        set_site_transient($this->cache_key, $manifest, 15 * MINUTE_IN_SECONDS);
        return $manifest;
    }
}
