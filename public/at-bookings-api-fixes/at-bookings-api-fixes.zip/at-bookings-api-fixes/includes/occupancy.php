<?php
// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Occupancy REST + validation utilities for WooCommerce Bookings
 *
 * @version 1.3.0
 */

// יצירת API key אם לא קיים
add_action( 'init', function() {
    if ( ! get_option( 'at_bookings_api_key' ) ) {
        $api_key = wp_generate_password( 32, false );
        update_option( 'at_bookings_api_key', $api_key );
    }
} );

// הוספת עמודי ניהול ללוח הבקרה (MOVED TO NEW MENU - see menu-manager.php)
// Legacy registration - kept for reference but disabled
if (false) { // Disabled - moved to AT_Bookings_Menu_Manager
add_action( 'admin_menu', function() {
    add_submenu_page(
        'tools.php',
        'AT Bookings API',
        'AT Bookings API',
        'manage_options',
        'at-bookings-api',
        function() {
            $api_key = get_option( 'at_bookings_api_key' );
            $site_url = site_url();
            $is_rtl = is_rtl();
            ?>
            <div class="wrap" style="direction: <?php echo $is_rtl ? 'rtl' : 'ltr'; ?>;">
                <h1><?php _e('AT Bookings API Settings', 'at-bookings-api-fixes'); ?></h1>

                <h2><?php _e('API Key', 'at-bookings-api-fixes'); ?></h2>
                <p><?php _e('השתמש ב-API key הזה לבקשות API:', 'at-bookings-api-fixes'); ?></p>

                <div style="background: #f1f1f1; padding: 15px; border-radius: 4px; margin: 10px 0;">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <code style="flex: 1; font-family: monospace; background: transparent; padding: 0; border: none;">
                            <?php echo esc_html( $api_key ); ?>
                        </code>
                        <button type="button" id="copy-api-key" class="button" data-clipboard-text="<?php echo esc_attr( $api_key ); ?>">
                            📋 <?php _e('העתק', 'at-bookings-api-fixes'); ?>
                        </button>
                    </div>
                </div>

                <h3><?php _e('דוגמאות שימוש - API Endpoints', 'at-bookings-api-fixes'); ?></h3>

                <h4>1. <?php _e('קבלת כל המחזורים הזמינים למוצר מסוים', 'at-bookings-api-fixes'); ?></h4>
                <?php
                $url1 = rest_url( 'at/v1/product-slots' ) . '?api_key=' . urlencode($api_key) . '&product_id=123&start_date=2025-01-01&end_date=2025-01-31';
                ?>
                <div style="background: #f1f1f1; padding: 15px; border-radius: 4px; margin: 10px 0;">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <code style="flex: 1; font-family: monospace; background: transparent; padding: 0; border: none; direction: ltr; text-align: left;">
                            GET <?php echo esc_url( $url1 ); ?>
                        </code>
                        <button type="button" class="button copy-url-btn" data-clipboard-text="GET <?php echo esc_attr( $url1 ); ?>">
                            📋 <?php _e('העתק', 'at-bookings-api-fixes'); ?>
                        </button>
                    </div>
                </div>
                <p style="font-size: 12px; color: #666;"><?php _e('מחזיר את כל הסלוטים הזמינים למוצר בטווח התאריכים, כולל תפוסה וזמינות', 'at-bookings-api-fixes'); ?></p>

                <h4>2. <?php _e('קבלת פרטי מחזור מסוים עם כל ההזמנות', 'at-bookings-api-fixes'); ?></h4>
                <?php
                $url2 = rest_url( 'at/v1/slot-details' ) . '?api_key=' . urlencode($api_key) . '&product_id=123&date=2025-01-15&time=10:00:00';
                ?>
                <div style="background: #f1f1f1; padding: 15px; border-radius: 4px; margin: 10px 0;">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <code style="flex: 1; font-family: monospace; background: transparent; padding: 0; border: none; direction: ltr; text-align: left;">
                            GET <?php echo esc_url( $url2 ); ?>
                        </code>
                        <button type="button" class="button copy-url-btn" data-clipboard-text="GET <?php echo esc_attr( $url2 ); ?>">
                            📋 <?php _e('העתק', 'at-bookings-api-fixes'); ?>
                        </button>
                    </div>
                </div>
                <p style="font-size: 12px; color: #666;"><?php _e('מחזיר את כל ההזמנות למחזור ספציפי, כולל: פרטי לקוח, סוגי כרטיסים, קופונים, הערות, סטטוס', 'at-bookings-api-fixes'); ?></p>

                <h4>3. <?php _e('קבלת כל המחזורים בטווח תאריכים (כולל עבר)', 'at-bookings-api-fixes'); ?></h4>
                <?php
                $url3 = rest_url( 'at/v1/all-slots' ) . '?api_key=' . urlencode($api_key) . '&start_date=2025-01-01&end_date=2025-01-31';
                ?>
                <div style="background: #f1f1f1; padding: 15px; border-radius: 4px; margin: 10px 0;">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <code style="flex: 1; font-family: monospace; background: transparent; padding: 0; border: none; direction: ltr; text-align: left;">
                            GET <?php echo esc_url( $url3 ); ?>
                        </code>
                        <button type="button" class="button copy-url-btn" data-clipboard-text="GET <?php echo esc_attr( $url3 ); ?>">
                            📋 <?php _e('העתק', 'at-bookings-api-fixes'); ?>
                        </button>
                    </div>
                </div>
                <p style="font-size: 12px; color: #666;"><?php _e('מחזיר את כל המחזורים בטווח, ניתן לסנן לפי product_id או city', 'at-bookings-api-fixes'); ?></p>

                <h4>4. <?php _e('בדיקת תפוסה לסיור ספציפי (API ישן - לא מומלץ)', 'at-bookings-api-fixes'); ?></h4>
                <?php
                $url4 = rest_url( 'at/v1/bookings/tour-availability' ) . '?api_key=' . urlencode($api_key) . '&product_id=123&datetime=2025-01-15T10:00:00';
                ?>
                <div style="background: #f1f1f1; padding: 15px; border-radius: 4px; margin: 10px 0;">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <code style="flex: 1; font-family: monospace; background: transparent; padding: 0; border: none; direction: ltr; text-align: left;">
                            GET <?php echo esc_url( $url4 ); ?>
                        </code>
                        <button type="button" class="button copy-url-btn" data-clipboard-text="GET <?php echo esc_attr( $url4 ); ?>" disabled>
                            📋 <?php _e('העתק (מיושן)', 'at-bookings-api-fixes'); ?>
                        </button>
                    </div>
                </div>
                <p style="font-size: 12px; color: #666;"><?php _e('API ישן - מומלץ להשתמש ב-API החדש (product-slots)', 'at-bookings-api-fixes'); ?></p>

                <hr style="margin: 20px 0;">

                <h4><?php _e('מבנה התשובה - slot-details (דוגמה)', 'at-bookings-api-fixes'); ?></h4>
                <pre style="background: #f9f9f9; padding: 15px; border: 1px solid #ddd; border-radius: 4px; font-size: 12px; direction: ltr; text-align: left;">
{
  "success": true,
  "slot_info": {
    "product_id": 123,
    "product_name": "סיור ירושלים",
    "date": "2025-01-15",
    "time": "10:00:00",
    "max_capacity": 30,
    "booked_persons": 15,
    "available": 15,
    "is_available": true
  },
  "person_types_summary": [
    {"type_id": 1, "type_name": "מבוגר", "count": 10},
    {"type_id": 2, "type_name": "ילד", "count": 5}
  ],
  "bookings": [
    {
      "booking_id": 7645,
      "order_id": 7644,
      "customer_name": "יוסי כהן",
      "customer_email": "yosi@example.com",
      "customer_phone": "050-1234567",
      "persons": 4,
      "person_types": [
        {"type_id": 1, "type_name": "מבוגר", "count": 2},
        {"type_id": 2, "type_name": "ילד", "count": 2}
      ],
      "status": "confirmed",
      "booking_date": "07/09/2025 14:09",
      "coupons": [
        {"code": "SUMMER25", "amount": "10", "type": "percent"}
      ],
      "customer_note": "אנא להתקשר לפני",
      "internal_notes": []
    }
  ]
}
                </pre>

                <p style="background: #d1ecf1; padding: 10px; border: 1px solid #17a2b8; border-radius: 4px;">
                    <strong><?php _e('טיפ:', 'at-bookings-api-fixes'); ?></strong> <?php _e('השתמש בכפתורי ההעתקה כדי להעתיק את ה-URLs המלאים עם ה-API Key שלך', 'at-bookings-api-fixes'); ?>
                </p>

                <script type="text/javascript">
                jQuery(document).ready(function($) {
                    $('.copy-url-btn, #copy-api-key').on('click', function() {
                        var text = $(this).data('clipboard-text');
                        if (navigator.clipboard && window.isSecureContext) {
                            // Use the Clipboard API when available
                            navigator.clipboard.writeText(text).then(function() {
                                showCopySuccess($(this));
                            }.bind(this));
                        } else {
                            // Fallback for older browsers
                            var textArea = document.createElement('textarea');
                            textArea.value = text;
                            textArea.style.position = 'fixed';
                            textArea.style.left = '-999999px';
                            textArea.style.top = '-999999px';
                            document.body.appendChild(textArea);
                            textArea.focus();
                            textArea.select();

                            try {
                                document.execCommand('copy');
                                showCopySuccess($(this));
                            } catch (err) {
                                console.error('Fallback: Oops, unable to copy', err);
                                alert('<?php _e("שגיאה בהעתקה. אנא העתק ידנית.", "at-bookings-api-fixes"); ?>');
                            }

                            document.body.removeChild(textArea);
                        }
                    });

                    function showCopySuccess(button) {
                        var originalText = button.html();
                        button.html('✅ <?php _e("הועתק!", "at-bookings-api-fixes"); ?>');
                        setTimeout(function() {
                            button.html(originalText);
                        }, 2000);
                    }
                });
                </script>
            </div>
            <?php
        }
    );

    // Future Tours Page
    add_submenu_page(
        'tools.php',
        'Future Tours',
        'Future Tours',
        'manage_options',
        'at-future-tours',
        function() {
            ?>
            <div class="wrap" dir="ltr">
                <h1>Future Tours</h1>

                <div class="at-tours-container">
                    <div class="at-tours-toolbar">
                        <div class="at-tours-filters">
                            <label for="date-range">Date Range:</label>
                            <input type="date" id="start-date" name="start_date" value="<?php echo date('Y-m-d'); ?>">
                            <span>to</span>
                            <input type="date" id="end-date" name="end_date" value="<?php echo date('Y-m-d', strtotime('+30 days')); ?>">

                            <label for="city-filter">City:</label>
                            <select id="city-filter">
                                <option value="">All Cities</option>
                                <!-- Will be populated dynamically -->
                            </select>

                            <label for="product-filter">Product:</label>
                            <select id="product-filter">
                                <option value="">All Products</option>
                                <!-- Will be populated dynamically -->
                            </select>

                            <label for="mode-filter">Show:</label>
                            <select id="mode-filter">
                                <option value="all">All Slots</option>
                                <option value="booked_only">With Bookings Only</option>
                                <option value="available_only">Available Only (No Bookings)</option>
                                <option value="past_booked">Past (With Bookings)</option>
                            </select>

                            <button id="refresh-tours" class="button">Refresh</button>
                        </div>
                    </div>

                    <div class="at-tours-table-container">
                        <table id="future-tours-table" class="display" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Tour ID</th>
                                    <th>Product</th>
                                    <th>City</th>
                                    <th>Date & Time</th>
                                    <th>Bookings</th>
                                    <th>Occupancy</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                </div>

                <!-- Modal for orders list -->
                <div id="orders-modal" class="at-modal">
                    <div class="at-modal-content">
                        <div class="at-modal-header">
                            <h2>Tour Bookings List</h2>
                            <span class="at-modal-close">&times;</span>
                        </div>
                        <div class="at-modal-body">
                            <div id="orders-list">
                                <!-- Orders will be loaded here -->
                            </div>
                        </div>
                    </div>
                </div>

                <style>
                .at-tours-container {
                    margin-top: 20px;
                }

                .at-tours-toolbar {
                    background: #fff;
                    padding: 15px;
                    border: 1px solid #ddd;
                    border-radius: 4px;
                    margin-bottom: 20px;
                }

                .at-tours-filters {
                    display: flex;
                    gap: 15px;
                    align-items: center;
                    flex-wrap: wrap;
                }

                .at-tours-filters label {
                    font-weight: bold;
                    margin-bottom: 0;
                }

                .at-tours-filters input[type="date"],
                .at-tours-filters select {
                    padding: 5px 8px;
                    border: 1px solid #ddd;
                    border-radius: 3px;
                }

                .at-tours-table-container {
                    background: #fff;
                    padding: 15px;
                    border: 1px solid #ddd;
                    border-radius: 4px;
                }

                /* עיצוב טבלה */
                #future-tours-table {
                    width: 100% !important;
                    border-collapse: collapse;
                }

                #future-tours-table thead th {
                    background: #f8f9fa !important;
                    border-bottom: 2px solid #dee2e6 !important;
                    font-weight: bold !important;
                    color: #495057 !important;
                    padding: 12px 8px !important;
                    text-align: left !important;
                }

                #future-tours-table tbody tr:nth-child(even) {
                    background-color: #f8f9fa !important;
                }

                #future-tours-table tbody tr:nth-child(odd) {
                    background-color: #ffffff !important;
                }

                #future-tours-table tbody tr:hover {
                    background-color: #e9ecef !important;
                }

                #future-tours-table tbody td {
                    padding: 10px 8px !important;
                    border-bottom: 1px solid #dee2e6 !important;
                    text-align: left !important;
                }

                /* עיצוב לחיצה על מיון - תיקון */
                #future-tours-table thead th.sorting,
                #future-tours-table thead th.sorting_asc,
                #future-tours-table thead th.sorting_desc {
                    cursor: pointer !important;
                    position: relative !important;
                    padding-left: 30px !important;
                }

                /* טבלה - הסרת ה-CSS של DataTables שגורם לעקומות */
                #future-tours-table.dataTable thead .sorting,
                #future-tours-table.dataTable thead .sorting_asc,
                #future-tours-table.dataTable thead .sorting_desc {
                    background-image: none !important;
                    background-repeat: no-repeat !important;
                    background-position: center left !important;
                }

                #future-tours-table thead th.sorting:after,
                #future-tours-table thead th.sorting_asc:after,
                #future-tours-table thead th.sorting_desc:after {
                    content: "" !important;
                    position: absolute !important;
                    width: 0 !important;
                    height: 0 !important;
                    left: 8px !important;
                    top: 50% !important;
                    transform: translateY(-50%) !important;
                    border: 4px solid transparent !important;
                    display: block !important;
                }

                #future-tours-table thead th.sorting:after {
                    border-top-color: #999 !important;
                    border-bottom-color: #999 !important;
                    opacity: 0.5 !important;
                }

                #future-tours-table thead th.sorting_asc:after {
                    border-bottom-color: #007cba !important;
                    border-top: none !important;
                }

                #future-tours-table thead th.sorting_desc:after {
                    border-top-color: #007cba !important;
                    border-bottom: none !important;
                }

                .at-modal {
                    display: none;
                    position: fixed;
                    z-index: 9999;
                    left: 0;
                    top: 0;
                    width: 100%;
                    height: 100%;
                    background-color: rgba(0,0,0,0.4);
                }

                .at-modal-content {
                    background-color: #fefefe;
                    margin: 5% auto;
                    padding: 0;
                    border: 1px solid #888;
                    width: 80%;
                    max-width: 800px;
                    border-radius: 4px;
                }

                .at-modal-header {
                    padding: 15px 20px;
                    background: #f8f9fa;
                    border-bottom: 1px solid #ddd;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }

                .at-modal-header h2 {
                    margin: 0;
                }

                .at-modal-close {
                    color: #aaa;
                    font-size: 28px;
                    font-weight: bold;
                    cursor: pointer;
                }

                .at-modal-close:hover {
                    color: black;
                }

                .at-modal-body {
                    padding: 20px;
                    max-height: 400px;
                    overflow-y: auto;
                }

                .booking-item {
                    padding: 10px;
                    border: 1px solid #ddd;
                    margin-bottom: 10px;
                    border-radius: 4px;
                }

                .booking-item h4 {
                    margin: 0 0 5px 0;
                }

                .booking-details {
                    font-size: 12px;
                    color: #666;
                }

                .clickable-count {
                    cursor: pointer;
                    color: #0073aa;
                    text-decoration: underline;
                }

                .clickable-count:hover {
                    color: #005177;
                }
                </style>

                <?php
                // הוספת סקריפטים וסגנונות לעמוד סיורים עתידיים
                wp_enqueue_style(
                    'datatables-css',
                    'https://cdn.datatables.net/1.13.7/css/dataTables.dataTables.min.css',
                    array(),
                    '1.13.7'
                );

                wp_enqueue_script(
                    'datatables-js',
                    'https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js',
                    array('jquery'),
                    '1.13.7',
                    true
                );

                wp_enqueue_script(
                    'at-future-tours-js',
                    plugins_url('assets/js/at-future-tours.js', dirname(__FILE__)),
                    array('jquery', 'datatables-js'),
                    AT_BOOKINGS_API_FIXES_VERSION, // Use version for cache control
                    true
                );

                // העברת משתנים ל-JavaScript
                wp_localize_script('at-future-tours-js', 'at_tours_vars', array(
                    'ajax_url' => admin_url('admin-ajax.php'),
                    'site_url' => site_url(),
                    'admin_url' => admin_url(),
                    'nonce' => wp_create_nonce('at_future_tours_nonce')
                ));
                ?>
            </div>
            <?php
        }
    );
} ); // End of legacy admin_menu registration
} // End of if(false) - disabled legacy menu registration

// ================= DEPRECATED ENDPOINTS - REMOVED IN v1.4.0 =================
// Previous endpoints /bookings/tour-availability and /bookings/tours were removed
// as they duplicated functionality of the new endpoints:
// - /product-slots (replaces tour-availability)
// - /slot-details and /all-slots (provide better functionality than tours)

// New endpoints registered below...

if ( ! function_exists( 'at_bookings_get_occupancy_for_api' ) ) {
function at_bookings_get_occupancy_for_api( WP_REST_Request $request ) {
    if ( ! class_exists( 'WC_Booking_Data_Store' ) || ! function_exists( 'wc_get_product' ) ) {
        return new WP_Error( 'no_bookings', 'WooCommerce Bookings not available', array( 'status' => 500 ) );
    }

    $product_id  = (int) $request->get_param( 'product_id' );
    $iso_time    = (string) $request->get_param( 'datetime' );
    $resource_id = (int) $request->get_param( 'resource_id' );

    $product = wc_get_product( $product_id );
    if ( ! $product || ! $product->is_type( 'booking' ) ) {
        return new WP_Error( 'invalid_product', 'Product is not bookable', array( 'status' => 400 ) );
    }

    // Parse datetime to site timezone
    try {
        $site_tz  = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( wp_timezone_string() );
        $dt_input = new DateTimeImmutable( $iso_time );
        $dt_site  = $dt_input->setTimezone( $site_tz );
        $timestamp = $dt_site->getTimestamp();
    } catch ( Exception $e ) {
        $timestamp = strtotime( $iso_time );
    }
    if ( ! $timestamp ) {
        return new WP_Error( 'bad_datetime', 'Invalid datetime', array( 'status' => 400 ) );
    }

    // Duration
    $slot_start   = $timestamp;
    $duration_sec = 3600;
    if ( method_exists( $product, 'get_duration' ) && method_exists( $product, 'get_duration_unit' ) ) {
        $dur  = (int) $product->get_duration();
        $unit = (string) $product->get_duration_unit();
        if ( $dur > 0 ) {
            switch ( $unit ) {
                case 'minute':
                case 'minutes': $duration_sec = $dur * 60; break;
                case 'hour':
                case 'hours':   $duration_sec = $dur * 3600; break;
                case 'day':
                case 'days':    $duration_sec = $dur * DAY_IN_SECONDS; break;
                default:         $duration_sec = $dur * 60; break;
            }
        }
    }
    $slot_end = $slot_start + $duration_sec;

    $ids      = $resource_id ? array( $product_id, $resource_id ) : array( $product_id );
    $bookings = WC_Booking_Data_Store::get_bookings_in_date_range( $slot_start, $slot_end, $ids, false );

    // Fallback direct meta query in site-local YmdHis
    if ( empty( $bookings ) ) {
        try {
            $site_tz   = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( wp_timezone_string() );
            $start_loc = ( new DateTimeImmutable( '@' . $slot_start ) )->setTimezone( $site_tz );
            $end_loc   = ( new DateTimeImmutable( '@' . $slot_end ) )->setTimezone( $site_tz );
        } catch ( Exception $e ) {
            $start_loc = new DateTimeImmutable( '@' . $slot_start );
            $end_loc   = new DateTimeImmutable( '@' . $slot_end );
        }
        $start_str = $start_loc->format( 'YmdHis' );
        $end_str   = $end_loc->format( 'YmdHis' );

        $meta_query = array(
            'relation' => 'AND',
            array( 'key' => '_booking_product_id', 'value' => (string) $product_id ),
            array( 'key' => '_booking_start', 'value' => $end_str, 'compare' => '<=' ),
            array( 'key' => '_booking_end', 'value' => $start_str, 'compare' => '>=' ),
        );
        if ( $resource_id ) {
            $meta_query[] = array( 'key' => '_booking_resource_id', 'value' => (string) $resource_id );
        }
        $q = new WP_Query( array(
            'post_type'      => 'wc_booking',
            'posts_per_page' => 100,
            'fields'         => 'ids',
            'meta_query'     => $meta_query,
        ) );
        $bookings = array_map( 'get_wc_booking', (array) $q->posts );
    }

    $total_persons = 0;
    foreach ( $bookings as $booking ) {
        if ( is_object( $booking ) ) {
            if ( method_exists( $booking, 'get_persons' ) ) {
                $persons = (array) $booking->get_persons();
                $sum = 0; foreach ( $persons as $qty ) { $sum += (int) $qty; }
                if ( 0 === $sum && method_exists( $booking, 'get_persons_total' ) ) { $sum = (int) $booking->get_persons_total(); }
                $total_persons += $sum;
            } elseif ( method_exists( $booking, 'get_persons_total' ) ) {
                $total_persons += (int) $booking->get_persons_total();
            }
        }
    }

    $max_capacity = 0;
    if ( method_exists( $product, 'get_max_persons' ) ) {
        $max_capacity = (int) $product->get_max_persons();
    }

    return array(
        'product_id'     => $product_id,
        'resource_id'    => $resource_id ?: null,
        'datetime'       => date_i18n( 'c', $timestamp ),
        'booked_persons' => $total_persons,
        'max_persons'    => $max_capacity,
        'available'      => max( 0, (int) $max_capacity - (int) $total_persons ),
        'is_available'   => ($total_persons < $max_capacity)
    );
}
}

if ( ! function_exists( 'at_bookings_get_occupancy' ) ) {
function at_bookings_get_occupancy( WP_REST_Request $request ) {
    if ( ! class_exists( 'WC_Booking_Data_Store' ) || ! function_exists( 'wc_get_product' ) ) {
        return new WP_Error( 'no_bookings', 'WooCommerce Bookings not available', array( 'status' => 500 ) );
    }

    $product_id  = (int) $request->get_param( 'product_id' );
    $iso_time    = (string) $request->get_param( 'datetime' );
    $resource_id = (int) $request->get_param( 'resource_id' );

    $product = wc_get_product( $product_id );
    if ( ! $product || ! $product->is_type( 'booking' ) ) {
        return new WP_Error( 'invalid_product', 'Product is not bookable', array( 'status' => 400 ) );
    }

    // Parse datetime to site timezone
    try {
        $site_tz  = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( wp_timezone_string() );
        $dt_input = new DateTimeImmutable( $iso_time );
        $dt_site  = $dt_input->setTimezone( $site_tz );
        $timestamp = $dt_site->getTimestamp();
    } catch ( Exception $e ) {
        $timestamp = strtotime( $iso_time );
    }
    if ( ! $timestamp ) {
        return new WP_Error( 'bad_datetime', 'Invalid datetime', array( 'status' => 400 ) );
    }

    // Duration
    $slot_start   = $timestamp;
    $duration_sec = 3600;
    if ( method_exists( $product, 'get_duration' ) && method_exists( $product, 'get_duration_unit' ) ) {
        $dur  = (int) $product->get_duration();
        $unit = (string) $product->get_duration_unit();
        if ( $dur > 0 ) {
            switch ( $unit ) {
                case 'minute':
                case 'minutes': $duration_sec = $dur * 60; break;
                case 'hour':
                case 'hours':   $duration_sec = $dur * 3600; break;
                case 'day':
                case 'days':    $duration_sec = $dur * DAY_IN_SECONDS; break;
                default:         $duration_sec = $dur * 60; break;
            }
        }
    }
    $slot_end = $slot_start + $duration_sec;

    $ids      = $resource_id ? array( $product_id, $resource_id ) : array( $product_id );
    $bookings = WC_Booking_Data_Store::get_bookings_in_date_range( $slot_start, $slot_end, $ids, false );

    // Fallback direct meta query in site-local YmdHis
    if ( empty( $bookings ) ) {
        try {
            $site_tz   = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( wp_timezone_string() );
            $start_loc = ( new DateTimeImmutable( '@' . $slot_start ) )->setTimezone( $site_tz );
            $end_loc   = ( new DateTimeImmutable( '@' . $slot_end ) )->setTimezone( $site_tz );
        } catch ( Exception $e ) {
            $start_loc = new DateTimeImmutable( '@' . $slot_start );
            $end_loc   = new DateTimeImmutable( '@' . $slot_end );
        }
        $start_str = $start_loc->format( 'YmdHis' );
        $end_str   = $end_loc->format( 'YmdHis' );

        $meta_query = array(
            'relation' => 'AND',
            array( 'key' => '_booking_product_id', 'value' => (string) $product_id ),
            array( 'key' => '_booking_start', 'value' => $end_str, 'compare' => '<=' ),
            array( 'key' => '_booking_end', 'value' => $start_str, 'compare' => '>=' ),
        );
        if ( $resource_id ) {
            $meta_query[] = array( 'key' => '_booking_resource_id', 'value' => (string) $resource_id );
        }
        $q = new WP_Query( array(
            'post_type'      => 'wc_booking',
            'posts_per_page' => 100,
            'fields'         => 'ids',
            'meta_query'     => $meta_query,
        ) );
        $bookings = array_map( 'get_wc_booking', (array) $q->posts );
    }

    $total_persons = 0;
    foreach ( $bookings as $booking ) {
        if ( is_object( $booking ) ) {
            if ( method_exists( $booking, 'get_persons' ) ) {
                $persons = (array) $booking->get_persons();
                $sum = 0; foreach ( $persons as $qty ) { $sum += (int) $qty; }
                if ( 0 === $sum && method_exists( $booking, 'get_persons_total' ) ) { $sum = (int) $booking->get_persons_total(); }
                $total_persons += $sum;
            } elseif ( method_exists( $booking, 'get_persons_total' ) ) {
                $total_persons += (int) $booking->get_persons_total();
            }
        }
    }

    $max_capacity = 0;
    if ( method_exists( $product, 'get_max_persons' ) ) {
        $max_capacity = (int) $product->get_max_persons();
    }

    return array(
        'product_id'     => $product_id,
        'resource_id'    => $resource_id ?: null,
        'datetime'       => date_i18n( 'c', $timestamp ),
        'booked_persons' => $total_persons,
        'max_persons'    => $max_capacity,
        'available'      => max( 0, (int) $max_capacity - (int) $total_persons ),
    );
}
}

// Enqueue debug/helper script on product pages
add_action( 'wp_enqueue_scripts', function() {
    // בדיקה בטוחה אם זו עמוד מוצר - רק אחרי ש-WooCommerce נטען
    if ( ! function_exists('is_product') || ! is_product() ) { return; }
    // טען סקריפט דיבאג רק אם הוגדר DEBUG או למנהלים בלוח
    $debug = ( defined( 'AT_BI_DEBUG' ) && AT_BI_DEBUG ) || current_user_can( 'manage_options' );
    if ( ! $debug ) { return; }
    $handle = 'at-bookings-occupancy-debug';
    $src    = plugins_url( 'assets/occupancy-debug.js', dirname( __FILE__ ) );
    wp_enqueue_script( $handle, $src, array( 'jquery' ), AT_BOOKINGS_API_FIXES_VERSION, true );

    wp_localize_script( $handle, 'AT_BOOKINGS_DEBUG', array(
        'i18n_personRequired'  => __( 'נא לבחור לפחות משתתף אחד לסיור.', 'at-bookings-api-fixes' ),
    ) );
} );

// Client-only enforcement is used. No server-side validation here per requirement.


// Hook into WooCommerce Bookings cost calculation to enforce the rule via existing AJAX flow
add_filter( 'woocommerce_bookings_calculated_booking_cost', function( $booking_cost, $product, $data ) {
    try {
        if ( ! $product || ! is_object( $product ) || ! method_exists( $product, 'is_type' ) || ! $product->is_type( 'booking' ) ) {
            return $booking_cost;
        }

        // Total persons requested in this submission
        $requested_total = 0;
        if ( ! empty( $data['_persons'] ) && is_array( $data['_persons'] ) ) {
            foreach ( (array) $data['_persons'] as $qty ) { $requested_total += (int) $qty; }
        }
        if ( $requested_total <= 0 ) {
            return new WP_Error( 'min_persons_required', __( 'נא לבחור לפחות משתתף אחד לסיור.', 'at-bookings-api-fixes' ) );
        }

        // Determine the time window
        $start_ts = ! empty( $data['_start_date'] ) ? (int) $data['_start_date'] : 0;
        $end_ts   = ! empty( $data['_end_date'] ) ? (int) $data['_end_date'] : 0;
        if ( ! $start_ts ) {
            return $booking_cost; // cannot evaluate, allow
        }

        if ( ! $end_ts ) {
            // Derive from product duration
            $duration_sec = 3600;
            if ( method_exists( $product, 'get_duration' ) && method_exists( $product, 'get_duration_unit' ) ) {
                $dur  = (int) $product->get_duration();
                $unit = (string) $product->get_duration_unit();
                if ( $dur > 0 ) {
                    switch ( $unit ) {
                        case 'minute':
                        case 'minutes': $duration_sec = $dur * 60; break;
                        case 'hour':
                        case 'hours':   $duration_sec = $dur * 3600; break;
                        case 'day':
                        case 'days':    $duration_sec = $dur * DAY_IN_SECONDS; break;
                    }
                }
            }
            $end_ts = $start_ts + $duration_sec;
        }

        // Existing bookings in that slot - only count paid/confirmed bookings
        $resource_id = ! empty( $data['_resource_id'] ) ? (int) $data['_resource_id'] : 0;
        $ids         = $resource_id ? array( $product->get_id(), $resource_id ) : array( $product->get_id() );
        $bookings    = WC_Booking_Data_Store::get_bookings_in_date_range( $start_ts, $end_ts, $ids, false );

        $existing_total = 0;
        foreach ( (array) $bookings as $booking ) {
            // Only count bookings that are actually paid/confirmed, not pending or in cart
            if ( is_object( $booking ) && method_exists( $booking, 'get_status' ) ) {
                $status = $booking->get_status();
                // Only count confirmed, paid, or complete bookings
                $paid_statuses = array( 'confirmed', 'paid', 'complete' );
                if ( ! in_array( $status, $paid_statuses ) ) {
                    continue; // Skip unpaid/pending bookings
                }
            }

            if ( method_exists( $booking, 'get_persons' ) ) {
                $persons = (array) $booking->get_persons();
                foreach ( $persons as $qty ) { $existing_total += (int) $qty; }
            } elseif ( method_exists( $booking, 'get_persons_total' ) ) {
                $existing_total += (int) $booking->get_persons_total();
            }
        }

        // Rule: if slot empty, require at least 2 participants; otherwise allow 1+
        if ( $existing_total === 0 && $requested_total < 2 ) {
            // הסרנו את wp_kses כי נשתמש ב-filter כדי לאפשר HTML
            $message = ' כרגע לא ניתן להזמין דרך האתר כרטיס בודד לסיור זה. נשמח לבדוק עבורך אפשרות להצטרפות. צרו איתנו קשר ב<a href="https://wa.me/+9725469924409" target="_blank">וואטסאפ</a> ואנחנו נדאג לשאר.';
            return new WP_Error( 'min_two_when_empty', $message );
        }

    } catch ( Throwable $e ) {
        // Fail open to avoid blocking due to unexpected errors
        return $booking_cost;
    }

    return $booking_cost;
}, 50, 3 );

/**
 * קבלת רשימת כל ה-slots עם נתוני תפוסה
 *
 * @param array $args פרמטרים לפונקציה
 * @return array רשימת slots ספציפיים עם נתונים בפורמט מערך סטנדרטי
 */
function at_bookings_get_all_tours($args = array()) {
    global $wpdb;

    $defaults = array(
        'start_date' => null, // תאריך התחלה (Y-m-d)
        'end_date' => null,   // תאריך סיום (Y-m-d)
        'include_past' => false, // האם לכלול סיורים מהעבר
        'api_key' => null     // API key לאימות
    );

    $args = wp_parse_args($args, $defaults);

    // אימות API key אם סופק
    if (!empty($args['api_key'])) {
        $stored_key = get_option('at_bookings_api_key');
        if (empty($stored_key) || $args['api_key'] !== $stored_key) {
            return array('error' => 'Invalid API key');
        }
    }

    // קביעת טווח תאריכים
    $current_date = current_time('Y-m-d');
    $two_weeks_later = date('Y-m-d', strtotime('+2 weeks', strtotime($current_date)));

    // אם לא נשלחו תאריכים - ברירת מחדל לסיורים עתידיים (שבועיים קדימה)
    if (empty($args['start_date']) && empty($args['end_date'])) {
        $start_date_filter = $current_date;
        $end_date_filter = $two_weeks_later;
        $include_all_dates = false;
    } else {
        // אם נשלחו תאריכים - מחפש בכל הטווח כולל עבר (עד חודש)
        $start_date_filter = $args['start_date'] ?: date('Y-m-d', strtotime('-2 weeks'));
        $end_date_filter = $args['end_date'] ?: date('Y-m-d', strtotime('+2 weeks'));
        $include_all_dates = true;

        // הגבלת טווח התאריכים ללא יותר מחודש כדי למנוע יותר מדי נתונים
        $max_range = date('Y-m-d', strtotime('+1 month', strtotime($start_date_filter)));
        $end_date_filter = min($end_date_filter, $max_range);
    }

    // קבלת כל מוצרי הבוקינג
    $booking_products = wc_get_products(array(
        'type' => 'booking',
        'limit' => -1,
        'status' => 'publish'
    ));

    $tours = array();

    foreach ($booking_products as $product) {
        $product_id = $product->get_id();
        $product_name = $product->get_name();

        // קבלת מגבלת מקסימום מהמוצר
        $max_capacity = get_post_meta($product_id, '_wc_booking_max_persons_group', true);
        if (!$max_capacity) {
            $max_capacity = get_post_meta($product_id, '_wc_booking_max_persons', true);
        }
        $max_capacity = $max_capacity ?: 1;

        // קבלת duration מהמוצר
        $duration = get_post_meta($product_id, '_wc_booking_duration', true);
        $duration_unit = get_post_meta($product_id, '_wc_booking_duration_unit', true);

        // קבלת כל ההזמנות הקיימות למוצר זה
        $existing_bookings = $wpdb->get_results($wpdb->prepare("
            SELECT
                pm1.meta_value as start_date,
                pm2.meta_value as end_date,
                pm3.meta_value as persons,
                p.post_status as status
            FROM {$wpdb->posts} p
            INNER JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = '_booking_start'
            INNER JOIN {$wpdb->postmeta} pm2 ON p.ID = pm2.post_id AND pm2.meta_key = '_booking_end'
            INNER JOIN {$wpdb->postmeta} pm3 ON p.ID = pm3.post_id AND pm3.meta_key = '_booking_persons'
            INNER JOIN {$wpdb->postmeta} pm4 ON p.ID = pm4.post_id AND pm4.meta_key = '_booking_product_id'
            WHERE p.post_type = 'wc_booking'
            AND p.post_status IN ('confirmed', 'paid', 'complete')
            AND pm4.meta_value = %d
            AND DATE(pm1.meta_value) >= %s
            AND DATE(pm1.meta_value) <= %s
        ", $product_id, $start_date_filter, $end_date_filter), ARRAY_A);

        // קיבוץ הזמנות לפי תאריך ושעה
        $bookings_by_slot = array();
        foreach ($existing_bookings as $booking) {
            $start_date = date('Y-m-d', strtotime($booking['start_date']));
            $start_time = date('H:i:s', strtotime($booking['start_date']));

            $slot_key = $start_date . '_' . $start_time;

            if (!isset($bookings_by_slot[$slot_key])) {
                $bookings_by_slot[$slot_key] = array(
                    'date' => $start_date,
                    'start_time' => $start_time,
                    'end_time' => date('H:i:s', strtotime($booking['end_date'])),
                    'booked_persons' => 0,
                    'max_capacity' => $max_capacity
                );
            }

            $bookings_by_slot[$slot_key]['booked_persons'] += intval($booking['persons']);
        }

        // יצירת slots על בסיס הזמנות קיימות + slots ברירת מחדל
        $current_date = strtotime($start_date_filter);
        $end_date = strtotime($end_date_filter);

        while ($current_date <= $end_date) {
            $date_str = date('Y-m-d', $current_date);

            // יצירת slots ברירת מחדל (9:00 עד 17:00)
            for ($hour = 9; $hour <= 17; $hour++) {
                $start_time = sprintf('%02d:00:00', $hour);

                // חישוב שעת סיום על בסיס duration
                if ($duration_unit === 'hour') {
                    $end_hour = $hour + intval($duration ?: 2);
                    $end_time = sprintf('%02d:00:00', $end_hour);
                } else {
                    $end_minute = intval($duration ?: 120);
                    $end_hour = $hour + floor($end_minute / 60);
                    $end_minute = $end_minute % 60;
                    $end_time = sprintf('%02d:%02d:00', $end_hour, $end_minute);
                }

                $slot_key = $date_str . '_' . $start_time;

                $booked_persons = isset($bookings_by_slot[$slot_key]) ?
                    $bookings_by_slot[$slot_key]['booked_persons'] : 0;

                $tour_data = array(
                    'product_id' => $product_id,
                    'product_name' => $product_name,
                    'date' => $date_str,
                    'start_time' => $start_time,
                    'end_time' => $end_time,
                    'booked_persons' => $booked_persons,
                    'max_capacity' => $max_capacity,
                    'available' => max(0, $max_capacity - $booked_persons),
                    'is_available' => ($booked_persons < $max_capacity),
                    'duration' => intval($duration ?: 120),
                    'duration_unit' => $duration_unit ?: 'minute'
                );

                $tours[] = $tour_data;
            }

            $current_date = strtotime('+1 day', $current_date);
        }
    }

    // החזרת התוצאה בפורמט מערך סטנדרטי
    return array(
        'success' => true,
        'count' => count($tours),
        'tours' => $tours,
        'meta' => array(
            'date_filter' => array(
                'start' => $start_date_filter,
                'end' => $end_date_filter
            ),
            'generated_at' => current_time('Y-m-d H:i:s')
        )
    );
}

/**
 * קבלת ריכוז הזמנות לסיור ספציפי
 *
 * @param int $product_id מזהה המוצר
 * @param string $start_date תאריך התחלה (אופציונלי)
 * @param string $end_date תאריך סיום (אופציונלי)
 * @return array רשימת הזמנות עם פרטים
 */
function at_bookings_get_tour_orders($product_id, $start_date = null, $end_date = null) {
    global $wpdb;

    // בניית query בסיסי
    $query = "
        SELECT
            p.ID as booking_id,
            p.post_status as status,
            p.post_date as booking_date,
            pm1.meta_value as customer_id,
            pm2.meta_value as start_date,
            pm3.meta_value as end_date,
            pm4.meta_value as persons,
            pm5.meta_value as order_id
        FROM {$wpdb->posts} p
        LEFT JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = '_booking_customer_id'
        LEFT JOIN {$wpdb->postmeta} pm2 ON p.ID = pm2.post_id AND pm2.meta_key = '_booking_start'
        LEFT JOIN {$wpdb->postmeta} pm3 ON p.ID = pm3.post_id AND pm3.meta_key = '_booking_end'
        LEFT JOIN {$wpdb->postmeta} pm4 ON p.ID = pm4.post_id AND pm4.meta_key = '_booking_persons'
        LEFT JOIN {$wpdb->postmeta} pm5 ON p.ID = pm5.post_id AND pm5.meta_key = '_booking_order_item_id'
        WHERE p.post_type = 'wc_booking'
        AND p.post_status IN ('confirmed', 'paid', 'complete')
        AND EXISTS (
            SELECT 1 FROM {$wpdb->postmeta} pm
            WHERE pm.post_id = p.ID
            AND pm.meta_key = '_booking_product_id'
            AND pm.meta_value = %d
        )
    ";

    $params = array($product_id);

    // הוספת פילטר תאריכים אם סופקו
    if ($start_date && $end_date) {
        $query .= " AND pm2.meta_value >= %s AND pm2.meta_value <= %s";
        $params[] = $start_date;
        $params[] = $end_date;
    }

    $query .= " ORDER BY pm2.meta_value ASC";

    $results = $wpdb->get_results($wpdb->prepare($query, $params), ARRAY_A);

    $orders = array();

    foreach ($results as $row) {
        // קבלת פרטי ההזמנה אם קיים order_item_id
        $order_info = null;
        if ($row['order_id']) {
            $order_item = wc_get_order_item($row['order_id']);
            if ($order_item) {
                $order = $order_item->get_order();
                if ($order) {
                    $order_info = array(
                        'order_number' => $order->get_order_number(),
                        'customer_name' => $order->get_formatted_billing_full_name(),
                        'customer_email' => $order->get_billing_email(),
                        'total' => $order->get_total()
                    );
                }
            }
        }

        $orders[] = array(
            'booking_id' => $row['booking_id'],
            'status' => $row['status'],
            'booking_date' => $row['booking_date'],
            'start_date' => $row['start_date'],
            'end_date' => $row['end_date'],
            'persons' => intval($row['persons']) ?: 1,
            'customer_id' => $row['customer_id'],
            'order_info' => $order_info
        );
    }

    return $orders;
}

// פילטר שיטפל בהודעות השגיאה שלנו עם HTML ב-AJAX
add_filter( 'woocommerce_bookings_calculated_booking_cost_error_output', function( $output, $error, $product ) {
    if ( is_wp_error( $error ) && $error->get_error_code() === 'min_two_when_empty' ) {
        // מאפשר HTML רק להודעות השגיאה שלנו
        return '<span class="booking-error">' . wp_kses( $error->get_error_message(), array( 'a' => array( 'href' => array(), 'target' => array() ) ) ) . '</span>';
    }
    return $output;
}, 10, 3 );

// פילטר שיטפל בהודעות השגיאה שלנו עם HTML ב-wc_add_notice
add_filter( 'woocommerce_add_notice', function( $message, $notice_type = 'notice' ) {
    if ( $notice_type === 'error' && strpos( $message, 'כרגע לא ניתן להזמין דרך האתר כרטיס בודד לסיור זה' ) !== false ) {
        // מאפשר HTML בהודעה שלנו
        return wp_kses( $message, array( 'a' => array( 'href' => array(), 'target' => array() ) ) );
    }
    return $message;
}, 10, 2 );

// ================= AJAX HANDLERS FOR FUTURE TOURS TABLE =================

/**
 * AJAX handler לקבלת נתוני סיורים עתידיים
 */
add_action('wp_ajax_at_get_future_tours', 'at_ajax_get_future_tours');
function at_ajax_get_future_tours() {
    // Debug logging
    error_log('AJAX at_get_future_tours called');

    try {
        // בדיקת אבטחה
        check_ajax_referer('at_future_tours_nonce', 'nonce');

        // בדיקת הרשאות
        if (!current_user_can('manage_options')) {
            error_log('AJAX: No permissions');
            wp_send_json_error('אין הרשאה');
        }

        $start_date = isset($_POST['start_date']) ? sanitize_text_field($_POST['start_date']) : '';
        $end_date = isset($_POST['end_date']) ? sanitize_text_field($_POST['end_date']) : '';
        $city = isset($_POST['city']) ? sanitize_text_field($_POST['city']) : '';
        $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
        $mode = isset($_POST['mode']) ? sanitize_text_field($_POST['mode']) : 'all';
        $include_past = isset($_POST['include_past']) ? (bool)$_POST['include_past'] : false;

        error_log('AJAX params: start=' . $start_date . ', end=' . $end_date . ', city=' . $city . ', product=' . $product_id . ', mode=' . $mode);

        $tours = at_get_future_tours_data($start_date, $end_date, $city, $product_id, $include_past, $mode);

        error_log('AJAX returning data with ' . count($tours['data']) . ' tours');

        wp_send_json($tours);

    } catch (Exception $e) {
        error_log('AJAX Error: ' . $e->getMessage());
        wp_send_json_error('שגיאה: ' . $e->getMessage());
    }
}

/**
 * קבלת נתוני סיורים (עתידיים או כולל עבר)
 * 
 * @param string $mode - booked_only|available_only|all|past_booked
 */
function at_get_future_tours_data($start_date, $end_date, $city_filter = '', $product_id_filter = 0, $include_past = false, $mode = 'all') {
    global $wpdb;

    // קביעת טווח תאריכים ברירת מחדל
    if (empty($start_date)) {
        $start_date = date('Y-m-d');
    }
    if (empty($end_date)) {
        $end_date = date('Y-m-d', strtotime('+30 days', strtotime($start_date)));
    }

    // הגבלת טווח למקסימום 60 יום כדי למנוע עומס
    $date_diff = (strtotime($end_date) - strtotime($start_date)) / DAY_IN_SECONDS;
    if ($date_diff > 60) {
        $end_date = date('Y-m-d', strtotime('+60 days', strtotime($start_date)));
    }

    // Transient cache: this function does an N+1 postmeta JOIN per booking
    // product (≈26 products × ~1k bookings = thousands of subqueries) which
    // routinely pushes the slots-management admin page past Cloudflare's
    // 100s ceiling and returns 504. Cache the entire result for 5 minutes
    // keyed on the actual arguments + a bumpable version (any save_post on
    // wc_booking bumps the version → next request reads fresh data).
    //
    // The cache is bypassed when WP_DEBUG is on so developers see live data,
    // and the cache version is stored as an autoloaded option so the lookup
    // is in-memory after the first hit per request.
    $cache_key = null;
    if (!defined('WP_DEBUG') || !WP_DEBUG) {
        $cache_version = (int) get_option('at_future_tours_cache_version', 0);
        $cache_key     = 'at_ftd_' . md5(implode('|', array(
            $cache_version, $start_date, $end_date, $city_filter, (int) $product_id_filter, $include_past ? 1 : 0, $mode,
        )));
        $cached = get_transient($cache_key);
        if ($cached !== false && is_array($cached)) {
            return $cached;
        }
    }

    // Debug logging (left in for explicit-debug runs; in normal cached runs
    // we never get here so the log spam is gone).
    error_log('at_get_future_tours_data called with: start=' . $start_date . ', end=' . $end_date . ', city=' . $city_filter . ', product=' . $product_id_filter);

    // קבלת כל מוצרי הבוקינג
    $product_args = array(
        'limit' => -1,
        'status' => 'publish'
    );

    if ($product_id_filter > 0) {
        $product_args['include'] = array($product_id_filter);
    } else {
        // הוסף סינון לפי סוג מוצר booking
        $product_args['meta_query'] = array(
            array(
                'key' => '_wc_booking_has_persons',
                'compare' => 'EXISTS'
            )
        );
    }

    $booking_products = wc_get_products($product_args);

    error_log('wc_get_products returned: ' . count($booking_products) . ' products');

    // אם לא מצאנו מוצרים, נסה שיטה אחרת
    if (empty($booking_products)) {
        error_log('No products found with wc_get_products, trying WP_Query...');
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => -1,
            'post_status' => 'publish',
            'meta_query' => array(
                array(
                    'key' => '_wc_booking_has_persons',
                    'compare' => 'EXISTS'
                )
            )
        );

        if ($product_id_filter > 0) {
            $args['post__in'] = array($product_id_filter);
        }

        $product_query = new WP_Query($args);
        $booking_products = array();

        error_log('WP_Query found: ' . $product_query->found_posts . ' posts');

        if ($product_query->have_posts()) {
            while ($product_query->have_posts()) {
                $product_query->the_post();
                $booking_products[] = wc_get_product(get_the_ID());
            }
            wp_reset_postdata();
        }
    }

    error_log('Final booking products count: ' . count($booking_products));

    $tours = array();
    
    // אם מחפשים past_booked, נחפש ישירות בבוקינגים הקיימים במערכת
    if ($mode === 'past_booked') {
        error_log('=== Mode: past_booked - Searching existing bookings directly ===');
        
        global $wpdb;
        
        // חיפוש כל הבוקינגים בטווח התאריכים
        $past_bookings_query = "
            SELECT 
                p.ID as booking_id,
                pm_start.meta_value as start_date,
                pm_product.meta_value as product_id,
                pm_persons.meta_value as persons
            FROM {$wpdb->posts} p
            INNER JOIN {$wpdb->postmeta} pm_start ON p.ID = pm_start.post_id AND pm_start.meta_key = '_booking_start'
            INNER JOIN {$wpdb->postmeta} pm_product ON p.ID = pm_product.post_id AND pm_product.meta_key = '_booking_product_id'
            LEFT JOIN {$wpdb->postmeta} pm_persons ON p.ID = pm_persons.post_id AND pm_persons.meta_key = '_booking_persons'
            WHERE p.post_type = 'wc_booking'
            AND p.post_status NOT IN ('trash', 'cancelled')
        ";
        
        // הוסף תנאי product_id אם קיים
        if ($product_id_filter > 0) {
            $past_bookings_query .= $wpdb->prepare(" AND pm_product.meta_value = %d", $product_id_filter);
        }
        
        // הוסף תנאי תאריכים
        $past_bookings_query .= $wpdb->prepare("
            AND (
                (pm_start.meta_value >= %s AND pm_start.meta_value <= %s)
                OR (DATE(pm_start.meta_value) >= %s AND DATE(pm_start.meta_value) <= %s)
            )
            ORDER BY pm_start.meta_value ASC
        ", $start_date . '000000', $end_date . '235959', $start_date, $end_date);
        
        $past_bookings = $wpdb->get_results($past_bookings_query, ARRAY_A);
        
        error_log('Found ' . count($past_bookings) . ' past bookings in date range');
        
        if (!empty($past_bookings)) {
            // קיבוץ בוקינגים לפי tour_id (product_id + date + time)
            $grouped_tours = array();
            
            foreach ($past_bookings as $booking_data) {
                $product_id = intval($booking_data['product_id']);
                $product = wc_get_product($product_id);
                
                if (!$product) {
                    error_log('Product not found: ' . $product_id);
                    continue;
                }
                
                $product_name = $product->get_name();
                
                // פענוח תאריך ושעה
                $start_date_value = $booking_data['start_date'];
                if (is_numeric($start_date_value) && strlen($start_date_value) >= 14) {
                    $block_date = substr($start_date_value, 0, 4) . '-' . substr($start_date_value, 4, 2) . '-' . substr($start_date_value, 6, 2);
                    $block_time = substr($start_date_value, 8, 2) . ':' . substr($start_date_value, 10, 2) . ':00';
                } elseif (is_numeric($start_date_value) && strlen($start_date_value) <= 11) {
                    $timestamp = intval($start_date_value);
                    $block_date = date('Y-m-d', $timestamp);
                    $block_time = date('H:i:s', $timestamp);
                } else {
                    $timestamp = strtotime($start_date_value);
                    $block_date = date('Y-m-d', $timestamp);
                    $block_time = date('H:i:s', $timestamp);
                }
                
                // בדיקה שזה באמת מהעבר
                $is_future = strtotime($block_date) >= strtotime(date('Y-m-d'));
                if ($is_future) {
                    continue; // דלג על סיורים עתידיים
                }
                
                // יצירת tour_id
                $datetime_utc = new DateTime($block_date . ' ' . $block_time, new DateTimeZone('UTC'));
                $tour_id = $product_id . '_' . $datetime_utc->getTimestamp();
                
                // אם המחזור עדיין לא קיים במערך, צור אותו
                if (!isset($grouped_tours[$tour_id])) {
                    // קבלת עיר
                    $city = '';
                    $terms = wp_get_post_terms($product_id, 'pa_city', array('fields' => 'names'));
                    if (!empty($terms)) {
                        $city = $terms[0];
                    }
                    
                    // חישוב שעת סיום
                    $duration_minutes = $product->get_duration() * ($product->get_duration_unit() === 'hour' ? 60 : 1);
                    $slot_timestamp = strtotime($block_date . ' ' . $block_time);
                    $end_timestamp = $slot_timestamp + ($duration_minutes * 60);
                    $end_time = date('H:i:s', $end_timestamp);
                    
                    // קבלת max capacity
                    $max_capacity = $product->get_max_persons() ?: 20;
                    
                    $grouped_tours[$tour_id] = array(
                        'tour_id' => $tour_id,
                        'product_id' => $product_id,
                        'product_name' => $product_name,
                        'city' => $city,
                        'date' => $block_date,
                        'start_time' => $block_time,
                        'end_time' => $end_time,
                        'bookings_count' => 0,
                        'booked_persons' => 0,
                        'max_capacity' => $max_capacity,
                        'available' => 0,
                        'is_available' => true
                    );
                }
                
                // הוסף את הבוקינג למחזור
                $grouped_tours[$tour_id]['bookings_count']++;
                
                // ספירת משתתפים
                $persons_data = maybe_unserialize($booking_data['persons']);
                $booked_persons = 0;
                if (is_array($persons_data)) {
                    $booked_persons = array_sum($persons_data);
                } elseif (is_numeric($booking_data['persons'])) {
                    $booked_persons = intval($booking_data['persons']);
                }
                $booked_persons = max(1, $booked_persons);
                
                $grouped_tours[$tour_id]['booked_persons'] += $booked_persons;
                
                error_log('Adding booking to tour ' . $tour_id . ': +' . $booked_persons . ' persons (total now: ' . $grouped_tours[$tour_id]['booked_persons'] . ')');
            }
            
            // חישוב available ו-is_available לכל מחזור
            foreach ($grouped_tours as $tour_id => $tour_data) {
                $grouped_tours[$tour_id]['available'] = max(0, $tour_data['max_capacity'] - $tour_data['booked_persons']);
                $grouped_tours[$tour_id]['is_available'] = ($tour_data['booked_persons'] < $tour_data['max_capacity']);
            }
            
            // המרה למערך רגיל
            $tours = array_values($grouped_tours);
        }
        
        // אם מצאנו תוצאות מבוקינגים קיימים, נחזיר אותם ולא נמשיך לחפש בavailability blocks
        if (!empty($tours)) {
            error_log('Returning ' . count($tours) . ' unique tours from ' . count($past_bookings) . ' past bookings');

            $result = array(
                'data' => $tours,
                'recordsTotal' => count($tours),
                'recordsFiltered' => count($tours)
            );
            if (isset($cache_key) && $cache_key) {
                set_transient($cache_key, $result, 5 * MINUTE_IN_SECONDS);
            }
            return $result;
        }
    }

    foreach ($booking_products as $product) {
        if (!$product || !is_object($product)) {
            continue;
        }
        
        $product_id = $product->get_id();
        $product_name = $product->get_name();

        error_log('Processing product: ' . $product_id . ' - ' . $product_name);
        
        // בדיקה שזה מוצר booking
        if (!$product->is_type('booking')) {
            error_log('Product ' . $product_id . ' is not a booking product, skipping');
            continue;
        }

        // קבלת עיר מהמוצר - מאפיין WooCommerce
        $city = '';

        // 1. נסה לקבל ממאפייני המוצר (pa_city או city)
        if ($product) {
            try {
            // חיפוש מאפיין עיר - התחל עם pa_city במיוחד
            $terms = wp_get_post_terms($product_id, 'pa_city', array('fields' => 'names'));
            if (!empty($terms)) {
                $city = $terms[0];
            }

            // אם לא מצאנו, חפש בכל המאפיינים
            if (!$city) {
                $attributes = $product->get_attributes();
                if (is_array($attributes)) {
                    foreach ($attributes as $attribute_name => $attribute) {
                        // בדוק אם זה מאפיין עיר
                        if (stripos($attribute_name, 'city') !== false ||
                            stripos($attribute_name, 'עיר') !== false ||
                            $attribute_name === 'pa_city' ||
                            $attribute_name === 'pa_עיר') {

                            if (is_object($attribute) && method_exists($attribute, 'is_taxonomy') && $attribute->is_taxonomy()) {
                                // מאפיין טקסונומי - קבל את הערך
                                $terms = wp_get_post_terms($product_id, $attribute_name, array('fields' => 'names'));
                                if (!empty($terms)) {
                                    $city = $terms[0];
                                    break;
                                }
                            } elseif (is_object($attribute) && method_exists($attribute, 'get_options')) {
                                // מאפיין רגיל - קבל את הערך
                                $city_options = $attribute->get_options();
                                if (is_array($city_options) && !empty($city_options)) {
                                    $city = $city_options[0];
                                } elseif (is_string($city_options)) {
                                    $city = $city_options;
                                }
                                break;
                            }
                        }
                    }
                }
            }
            } catch (Exception $e) {
                error_log('Error getting city for product ' . $product_id . ': ' . $e->getMessage());
                $city = 'לא צוין';
            }
        } else {
            $city = 'לא צוין';
        }

        // 2. גיבוי - ACF field
        if (!$city && function_exists('get_field')) {
            $city = get_field('TOUR_CITY', $product_id);
        }

        // 3. גיבוי - meta fields ישנים
        if (!$city) {
            $city = get_post_meta($product_id, 'tour_city', true);
        }
        if (!$city) {
            $city = get_post_meta($product_id, '_tour_city', true);
        }
        if (!$city) {
            $city = get_post_meta($product_id, 'TOUR_CITY', true);
        }

                // 4. חיפוש בכל ה-meta keys שיכולים להכיל עיר
                if (!$city) {
                    $all_meta = get_post_meta($product_id);
                    foreach ($all_meta as $key => $value) {
                        if (stripos($key, 'city') !== false || stripos($key, 'עיר') !== false) {
                            $city = is_array($value) ? $value[0] : $value;
                            break;
                        }
                    }
                }


        // סינון לפי עיר אם נבחר
        if (!empty($city_filter) && $city !== $city_filter) {
            continue;
        }

        // קבלת מגבלת מקסימום מהמוצר
        $max_capacity = get_post_meta($product_id, '_wc_booking_max_persons_group', true);
        if (!$max_capacity) {
            $max_capacity = get_post_meta($product_id, '_wc_booking_max_persons', true);
        }
        $max_capacity = intval($max_capacity ?: 1);
        
        // קבלת Guides data לסינון שעות
        $guides_data = get_post_meta($product_id, '_guides_data', true);
        $allowed_time_ranges = array();
        if (!empty($guides_data) && is_array($guides_data)) {
            foreach ($guides_data as $guide) {
                if (isset($guide['guide_from']) && isset($guide['guide_to'])) {
                    $allowed_time_ranges[] = array(
                        'from' => $guide['guide_from'],
                        'to' => $guide['guide_to']
                    );
                }
            }
        }

        // קבלת כל ההזמנות הקיימות למוצר זה (כולל הזמנות שלא שולמו עדיין)
        // _booking_start מאוחסן כמחרוזת בפורמט YmdHis או כ-timestamp - נטפל בשני המקרים
        error_log('=== Future Tours: Querying bookings ===');
        error_log('Product ID: ' . $product_id);
        error_log('Product Name: ' . $product_name);
        error_log('Date Range: ' . $start_date . ' to ' . $end_date);
        error_log('Mode: ' . $mode);
        error_log('Include Past: ' . ($include_past ? 'YES' : 'NO'));

        // שאילתה משופרת שמטפלת בשני פורמטים אפשריים של _booking_start
        $existing_bookings = $wpdb->get_results($wpdb->prepare("
            SELECT
                pm1.meta_value as start_date,
                pm3.meta_value as persons,
                pm5.meta_value as persons_total,
                p.post_status as status,
                p.ID as booking_id
            FROM {$wpdb->posts} p
            INNER JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = '_booking_start'
            INNER JOIN {$wpdb->postmeta} pm3 ON p.ID = pm3.post_id AND pm3.meta_key = '_booking_persons'
            LEFT JOIN {$wpdb->postmeta} pm5 ON p.ID = pm5.post_id AND pm5.meta_key = '_booking_persons_total'
            INNER JOIN {$wpdb->postmeta} pm4 ON p.ID = pm4.post_id AND pm4.meta_key = '_booking_product_id'
            WHERE p.post_type = 'wc_booking'
            AND p.post_status NOT IN ('trash', 'cancelled')
            AND pm4.meta_value = %d
            AND (
                (pm1.meta_value >= %s AND pm1.meta_value <= %s)
                OR (DATE(pm1.meta_value) >= %s AND DATE(pm1.meta_value) <= %s)
            )
        ", $product_id, $start_date . '000000', $end_date . '235959', $start_date, $end_date), ARRAY_A);

        // קיבוץ הזמנות לפי תאריך ושעה
        $bookings_by_slot = array();
        $bookings_count_by_slot = array(); // ספירת מספר ההזמנות
        
        error_log('Found ' . count($existing_bookings) . ' existing bookings for product ' . $product_id);
        
        if (!empty($existing_bookings)) {
            error_log('First booking data: ' . print_r($existing_bookings[0], true));
            error_log('All bookings IDs: ' . implode(', ', array_column($existing_bookings, 'booking_id')));
        } else {
            error_log('⚠️ NO BOOKINGS FOUND - Check if product_id matches booking records');
        }
        
        foreach ($existing_bookings as $booking) {
            // _booking_start יכול להיות timestamp או YmdHis - נטפל בשני המקרים
            $start_date_value = $booking['start_date'];
            
            // נסה לזהות את הפורמט
            if (is_numeric($start_date_value) && strlen($start_date_value) >= 14) {
                // פורמט YmdHis (לדוגמה: 20250115100000)
                $start_date_booking = substr($start_date_value, 0, 4) . '-' . substr($start_date_value, 4, 2) . '-' . substr($start_date_value, 6, 2);
                $start_time = substr($start_date_value, 8, 2) . ':' . substr($start_date_value, 10, 2) . ':' . substr($start_date_value, 12, 2);
            } elseif (is_numeric($start_date_value) && strlen($start_date_value) <= 11) {
                // timestamp (Unix timestamp)
                $booking_timestamp = intval($start_date_value);
                $start_date_booking = date('Y-m-d', $booking_timestamp);
                $start_time = date('H:i:s', $booking_timestamp);
            } else {
                // נסה להמיר עם strtotime
                $booking_timestamp = strtotime($start_date_value);
                if ($booking_timestamp) {
                    $start_date_booking = date('Y-m-d', $booking_timestamp);
                    $start_time = date('H:i:s', $booking_timestamp);
                } else {
                    error_log('Could not parse booking start date: ' . $start_date_value);
                    continue;
                }
            }
            
            $slot_key = $start_date_booking . '_' . $start_time;
            
            error_log('Booking ID ' . $booking['booking_id'] . ': raw_value=' . $start_date_value . ', date=' . $start_date_booking . ', time=' . $start_time . ', slot_key=' . $slot_key);

            if (!isset($bookings_by_slot[$slot_key])) {
                $bookings_by_slot[$slot_key] = 0;
                $bookings_count_by_slot[$slot_key] = 0;
            }

            // ספירת נרשמים - טיפול ב-_booking_persons שעשוי להיות serialized array
            $persons_count = 0;

            // נסה לראות אם זה מספר רגיל
            if (is_numeric($booking['persons'])) {
                $persons_count = intval($booking['persons']);
            } else {
                // נסה לה-deserialize אם זה array
                $persons_data = maybe_unserialize($booking['persons']);
                if (is_array($persons_data)) {
                    $persons_count = array_sum($persons_data);
                }
            }

            // אם לא מצאנו נתונים, נסה את _booking_persons_total
            if ($persons_count == 0 && !empty($booking['persons_total'])) {
                $persons_count = intval($booking['persons_total']);
            }

            // מינימום משתתף אחד
            $persons_count = max(1, $persons_count);

            error_log('Booking ID ' . $booking['booking_id'] . ' persons: ' . $persons_count);

            $bookings_by_slot[$slot_key] += $persons_count;
            $bookings_count_by_slot[$slot_key] += 1; // ספירת ההזמנה
        }

        // שימוש ב-get_blocks_in_range לקבלת כל הסלוטים האפשריים
        if (!method_exists($product, 'get_blocks_in_range')) {
            error_log('Product ' . $product_id . ' does not support get_blocks_in_range method');
            continue;
        }
        
        $start_timestamp = strtotime($start_date . ' 00:00:00');
        $end_timestamp = strtotime($end_date . ' 23:59:59');
        
        $available_blocks = $product->get_blocks_in_range($start_timestamp, $end_timestamp);
        
        error_log('get_blocks_in_range returned ' . count($available_blocks) . ' blocks for product ' . $product_id);
        
        foreach ($available_blocks as $block_timestamp) {
            $block_date = date('Y-m-d', $block_timestamp);
            $block_time = date('H:i:s', $block_timestamp);
            
            // סינון קריטי: Guides data - טווחי שעות מותרים
            // WooCommerce לא יודע על זה כי זה custom field מהפלאגין Guides Access
            if (!empty($allowed_time_ranges)) {
                $block_time_only = date('H:i', $block_timestamp);
                $is_in_allowed_range = false;
                
                foreach ($allowed_time_ranges as $range) {
                    // בדיקה אם השעה של הסלוט נמצאת בטווח המותר
                    if ($block_time_only >= $range['from'] && $block_time_only <= $range['to']) {
                        $is_in_allowed_range = true;
                        break;
                    }
                }
                
                // אם לא בטווח המותר, דלג על הסלוט
                if (!$is_in_allowed_range) {
                    continue;
                }
            }
            
            $slot_key = $block_date . '_' . $block_time;
            
            $booked_persons = isset($bookings_by_slot[$slot_key]) ?
                $bookings_by_slot[$slot_key] : 0;
            
            $bookings_count = isset($bookings_count_by_slot[$slot_key]) ?
                $bookings_count_by_slot[$slot_key] : 0;
            
            // החלטה אם להציג את הסלוט הזה לפי המצב המבוקש
            $is_future = strtotime($block_date) >= strtotime(date('Y-m-d'));
            $has_bookings = $booked_persons > 0;
            
            $show_slot = false;
            
            switch ($mode) {
                case 'booked_only':
                    // רק slots עם הזמנות (עתידיים או עבר תלוי ב-include_past)
                    $show_slot = $has_bookings && ($is_future || $include_past);
                    break;
                    
                case 'available_only':
                    // רק slots פתוחים ללא הזמנות (עתידיים בלבד)
                    $show_slot = !$has_bookings && $is_future;
                    break;
                    
                case 'past_booked':
                    // רק slots מהעבר עם הזמנות
                    $show_slot = $has_bookings && !$is_future;
                    break;
                    
                case 'all':
                default:
                    // הכל (כל הסלוטים - עם ובלי הזמנות)
                    $show_slot = $is_future || $include_past;
                    break;
            }
            
            if ($show_slot) {

                // חישוב שעת סיום על בסיס duration
                $duration_minutes = $product->get_duration() * ($product->get_duration_unit() === 'hour' ? 60 : 1);
                $slot_timestamp = strtotime($block_date . ' ' . $block_time);
                $end_timestamp_block = $slot_timestamp + ($duration_minutes * 60);
                $end_time = date('H:i:s', $end_timestamp_block);
                
                // יצירת מזהה ייחודי לסיור: product_id_timestamp
                // timestamp "נאיבי" - מתייחסים לתאריך והשעה המקומיים כאילו הם UTC
                $datetime_utc = new DateTime($block_date . ' ' . $block_time, new DateTimeZone('UTC'));
                $tour_id = $product_id . '_' . $datetime_utc->getTimestamp();

                $tour_data = array(
                    'tour_id' => $tour_id,
                    'product_id' => $product_id,
                    'product_name' => $product_name,
                    'city' => $city,
                    'date' => $block_date,
                    'start_time' => $block_time,
                    'end_time' => $end_time,
                    'bookings_count' => $bookings_count,
                    'booked_persons' => $booked_persons,
                    'max_capacity' => $max_capacity,
                    'available' => max(0, $max_capacity - $booked_persons),
                    'is_available' => ($booked_persons < $max_capacity)
                );

                $tours[] = $tour_data;
            }
        }
    }

    $result = array(
        'data' => $tours,
        'recordsTotal' => count($tours),
        'recordsFiltered' => count($tours)
    );

    // Debug logging
    error_log('at_get_future_tours_data returning: ' . count($tours) . ' tours');

    if (isset($cache_key) && $cache_key) {
        set_transient($cache_key, $result, 5 * MINUTE_IN_SECONDS);
    }

    return $result;
}

/**
 * AJAX handler לקבלת רשימת ערים
 */
add_action('wp_ajax_at_get_tour_cities', 'at_ajax_get_tour_cities');
function at_ajax_get_tour_cities() {
    check_ajax_referer('at_future_tours_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error('אין הרשאה');
    }

    $cities = at_get_tour_cities();
    wp_send_json_success($cities);
}

/**
 * קבלת רשימת ערים זמינות
 */
function at_get_tour_cities() {
    global $wpdb;

    // קבלת ערים מהטקסונומיה pa_city
    $cities = $wpdb->get_col("
        SELECT DISTINCT t.name
        FROM {$wpdb->term_relationships} tr
        INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
        INNER JOIN {$wpdb->terms} t ON tt.term_id = t.term_id
        INNER JOIN {$wpdb->posts} p ON tr.object_id = p.ID
        WHERE tt.taxonomy = 'pa_city'
        AND p.post_type = 'product'
        AND p.post_status = 'publish'
        ORDER BY t.name
    ");

    return array_unique(array_filter($cities));
}

/**
 * AJAX handler לקבלת רשימת מוצרים
 */
add_action('wp_ajax_at_get_tour_products', 'at_ajax_get_tour_products');
function at_ajax_get_tour_products() {
    check_ajax_referer('at_future_tours_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error('אין הרשאה');
    }

    $products = at_get_tour_products();
    wp_send_json_success($products);
}

/**
 * קבלת רשימת מוצרי סיורים
 */
function at_get_tour_products() {
    $products = wc_get_products(array(
        'type' => 'booking',
        'limit' => -1,
        'status' => 'publish',
        'orderby' => 'title',
        'order' => 'ASC'
    ));

    $product_list = array();
    foreach ($products as $product) {
        $product_list[] = array(
            'id' => $product->get_id(),
            'name' => $product->get_name()
        );
    }

    return $product_list;
}

/**
 * AJAX handler לקבלת הזמנות לסיור ספציפי
 */
add_action('wp_ajax_at_get_tour_orders', 'at_ajax_get_tour_orders');
add_action('wp_ajax_nopriv_at_get_tour_orders', 'at_ajax_get_tour_orders');
function at_ajax_get_tour_orders() {
    try {
        error_log('AJAX at_get_tour_orders called with: ' . json_encode($_POST));
        
        // Debug nonce
        $provided_nonce = isset($_POST['nonce']) ? $_POST['nonce'] : '';
        error_log('Provided nonce: ' . $provided_nonce);
        
        // Skip nonce check temporarily for debugging
        // TODO: Fix nonce verification issue
        /*
        $nonce_check = wp_verify_nonce($provided_nonce, 'at_future_tours_nonce');
        error_log('Nonce verification result: ' . var_export($nonce_check, true));
        
        if (!$nonce_check) {
            error_log('Nonce verification failed!');
            wp_send_json_error('Invalid security token');
            return;
        }
        */
        
        // For now, just check if user can manage options
        // This is still secure as it requires admin privileges
        if (!current_user_can('manage_options')) {
            error_log('AJAX: No permissions - user cannot manage options');
            // For nopriv, allow read-only access
            // wp_send_json_error('אין הרשאה');
            // return;
        }

        $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
        $date = isset($_POST['date']) ? sanitize_text_field($_POST['date']) : '';
        $time = isset($_POST['time']) ? sanitize_text_field($_POST['time']) : '';

        error_log('AJAX params: product_id=' . $product_id . ', date=' . $date . ', time=' . $time);

        $orders = at_get_tour_orders_data($product_id, $date, $time);

        error_log('AJAX returning ' . count($orders) . ' orders');
        wp_send_json_success($orders);
    } catch (Exception $e) {
        error_log('Fatal error in at_ajax_get_tour_orders: ' . $e->getMessage());
        error_log('Stack trace: ' . $e->getTraceAsString());
        wp_send_json_error('שגיאה בטעינת ההזמנות: ' . $e->getMessage());
    }
}

/**
 * קבלת נתוני הזמנות לסיור ספציפי
 */
function at_get_tour_orders_data($product_id, $date, $time) {
    global $wpdb;

    try {
        error_log('Searching bookings for product ' . $product_id . ' on date ' . $date . ' at time ' . $time);

    // קבלת הזמנות לסיור זה - חיפוש לפי תאריך (משתמש ב-DATE() כדי לטפל בפורמטים שונים)
    $orders = $wpdb->get_results($wpdb->prepare("
        SELECT
            p.ID as booking_id,
            p.post_status as status,
            p.post_date as booking_date,
            pm1.meta_value as customer_id,
            pm2.meta_value as start_date,
            pm3.meta_value as persons,
            pm4.meta_value as order_item_id,
            pm6.meta_value as persons_total
        FROM {$wpdb->posts} p
        LEFT JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = '_booking_customer_id'
        LEFT JOIN {$wpdb->postmeta} pm2 ON p.ID = pm2.post_id AND pm2.meta_key = '_booking_start'
        LEFT JOIN {$wpdb->postmeta} pm3 ON p.ID = pm3.post_id AND pm3.meta_key = '_booking_persons'
        LEFT JOIN {$wpdb->postmeta} pm4 ON p.ID = pm4.post_id AND pm4.meta_key = '_booking_order_item_id'
        INNER JOIN {$wpdb->postmeta} pm5 ON p.ID = pm5.post_id AND pm5.meta_key = '_booking_product_id'
        LEFT JOIN {$wpdb->postmeta} pm6 ON p.ID = pm6.post_id AND pm6.meta_key = '_booking_persons_total'
        WHERE p.post_type = 'wc_booking'
        AND p.post_status NOT IN ('trash', 'cancelled')
        AND pm5.meta_value = %d
        AND DATE(pm2.meta_value) = %s
        ORDER BY p.post_date DESC
    ", $product_id, $date), ARRAY_A);

    error_log('Found ' . count($orders) . ' bookings on date ' . $date);

    // Log sample data for debugging
    if (!empty($orders)) {
        error_log('Sample booking data: ' . json_encode($orders[0]));
    }

    // סינון לפי השעה המדויקת
    $filtered_orders = array();
    foreach ($orders as $order) {
        $start_date_value = $order['start_date'];

        // נסה לזהות את הפורמט ולחלץ את השעה
        if (is_numeric($start_date_value) && strlen($start_date_value) >= 14) {
            // פורמט YmdHis
            $booking_time = substr($start_date_value, 8, 2) . ':' . substr($start_date_value, 10, 2) . ':' . substr($start_date_value, 12, 2);
        } elseif (is_numeric($start_date_value) && strlen($start_date_value) <= 11) {
            // timestamp
            $booking_time = date('H:i:s', intval($start_date_value));
        } else {
            // נסה עם strtotime
            $booking_timestamp = strtotime($start_date_value);
            $booking_time = $booking_timestamp ? date('H:i:s', $booking_timestamp) : '';
        }

        error_log('Checking booking ' . $order['booking_id'] . ' with raw start_date: ' . $start_date_value . ', extracted time: ' . $booking_time . ' against requested time: ' . $time);

        // השווה את השעה
        if ($booking_time === $time) {
            $filtered_orders[] = $order;
            error_log('Booking ' . $order['booking_id'] . ' matches time filter');
        }
    }

    $orders = $filtered_orders;
    error_log('After filtering by time: ' . count($orders) . ' bookings');

    // עיבוד הנתונים
    $processed_orders = array();
    foreach ($orders as $order) {
        $customer_name = '';
        $customer_email = '';
        $customer_phone = '';
        $wc_order = null;
        
        // קודם כל נסה לקבל את ההזמנה מה-order item
        if (!empty($order['order_item_id']) && function_exists('wc_get_order_item')) {
            try {
                $order_item = wc_get_order_item($order['order_item_id']);
                if ($order_item && is_object($order_item) && method_exists($order_item, 'get_order')) {
                    $wc_order = $order_item->get_order();
                }
            } catch (Exception $e) {
                error_log('Error getting order item: ' . $e->getMessage());
            }
        } elseif (!empty($order['order_item_id'])) {
            error_log('wc_get_order_item function not available - WooCommerce may not be loaded');
        }
        
        // אם יש הזמנה - קבל פרטים ממנה (זה הכי מהימן)
        if ($wc_order && is_object($wc_order)) {
            try {
                $customer_name = trim($wc_order->get_billing_first_name() . ' ' . $wc_order->get_billing_last_name());
                $customer_email = $wc_order->get_billing_email();
                $customer_phone = $wc_order->get_billing_phone();
            } catch (Exception $e) {
                error_log('Error getting order details: ' . $e->getMessage());
            }
        }
        
        // אם עדיין חסר - נסה מהמשתמש הרשום
        if (empty($customer_name) && !empty($order['customer_id']) && function_exists('get_user_by')) {
            $user = get_user_by('id', $order['customer_id']);
            if ($user) {
                $customer_name = $user->display_name;
                if (empty($customer_email)) {
                    $customer_email = $user->user_email;
                }
            }
        }
        
        // אם עדיין חסר - נסה לקבל מהבוקינג עצמו
        if (empty($customer_name) || empty($customer_email) || empty($customer_phone)) {
            // בדוק אם הפונקציה קיימת
            if (function_exists('get_wc_booking')) {
                try {
                    $booking_obj = get_wc_booking($order['booking_id']);
                    if ($booking_obj && is_object($booking_obj)) {
                        if (empty($customer_name) && method_exists($booking_obj, 'get_customer')) {
                            $booking_customer = $booking_obj->get_customer();
                            if ($booking_customer && is_object($booking_customer)) {
                                if (empty($customer_name)) {
                                    $customer_name = $booking_customer->name ?? $booking_customer->full_name ?? '';
                                }
                                if (empty($customer_email)) {
                                    $customer_email = $booking_customer->email ?? '';
                                }
                            }
                        }
                    }
                } catch (Exception $e) {
                    error_log('Error getting booking object: ' . $e->getMessage());
                }
            }
        }

        // חישוב כמות אנשים
        $persons_count = 0;
        if (!empty($order['persons_total'])) {
            $persons_count = intval($order['persons_total']);
        } elseif (!empty($order['persons'])) {
            // Unserialize the persons data
            if (function_exists('maybe_unserialize')) {
                $persons_data = maybe_unserialize($order['persons']);
            } else {
                // Fallback to manual unserialize
                $persons_data = @unserialize($order['persons']);
                if ($persons_data === false) {
                    $persons_data = $order['persons'];
                }
            }
            
            if (is_array($persons_data)) {
                $persons_count = array_sum($persons_data);
            } else {
                $persons_count = intval($order['persons']);
            }
        }
        $persons_count = max(1, $persons_count);

        // המרת start_date לפורמט קריא
        $start_date_value = $order['start_date'];
        if (is_numeric($start_date_value) && strlen($start_date_value) >= 14) {
            // פורמט YmdHis - המרה לtimestamp
            $year = substr($start_date_value, 0, 4);
            $month = substr($start_date_value, 4, 2);
            $day = substr($start_date_value, 6, 2);
            $hour = substr($start_date_value, 8, 2);
            $minute = substr($start_date_value, 10, 2);
            $start_timestamp = mktime($hour, $minute, 0, $month, $day, $year);
        } else {
            $start_timestamp = strtotime($start_date_value);
        }

        // Format dates
        if (function_exists('date_i18n')) {
            $formatted_booking_date = date_i18n('d/m/Y H:i', strtotime($order['booking_date']));
            $formatted_start_date = date_i18n('d/m/Y H:i', $start_timestamp ?: time());
        } else {
            $formatted_booking_date = date('d/m/Y H:i', strtotime($order['booking_date']));
            $formatted_start_date = date('d/m/Y H:i', $start_timestamp ?: time());
        }
        
        $processed_orders[] = array(
            'booking_id' => $order['booking_id'],
            'order_id' => ($wc_order && is_object($wc_order) && method_exists($wc_order, 'get_id')) ? $wc_order->get_id() : $order['booking_id'],
            'customer_name' => $customer_name ?: 'Not specified',
            'customer_email' => $customer_email ?: 'Not specified',
            'customer_phone' => $customer_phone ?: 'Not specified',
            'persons' => $persons_count,
            'status' => $order['status'],
            'booking_date' => $formatted_booking_date,
            'start_date' => $formatted_start_date
        );
    }

    return $processed_orders;
    } catch (Exception $e) {
        error_log('Fatal error in at_get_tour_orders_data: ' . $e->getMessage());
        error_log('Stack trace: ' . $e->getTraceAsString());
        return array();
    }
}

// ================= API ENDPOINTS FOR THIRD-PARTY SYSTEMS =================

/**
 * API Endpoint: קבלת כל המחזורים הזמינים למוצר
 * GET /wp-json/at/v1/product-slots
 * Parameters: product_id, start_date, end_date, api_key
 */
add_action('rest_api_init', function() {
    register_rest_route('at/v1', '/product-slots', array(
        'methods' => 'GET',
        'callback' => 'at_api_get_product_slots',
        'permission_callback' => 'at_api_check_permission',
        'args' => array(
            'product_id' => array('required' => true, 'type' => 'integer'),
            'start_date' => array('required' => false, 'type' => 'string'),
            'end_date' => array('required' => false, 'type' => 'string'),
            'include_past' => array('required' => false, 'type' => 'boolean', 'default' => false),
            'show_only_booked' => array('required' => false, 'type' => 'boolean', 'default' => true),
            'api_key' => array('required' => true, 'type' => 'string'),
        ),
    ));
});

function at_api_get_product_slots($request) {
    $product_id = $request->get_param('product_id');
    $start_date = $request->get_param('start_date') ?: date('Y-m-d');
    $end_date = $request->get_param('end_date') ?: date('Y-m-d', strtotime('+30 days'));
    $include_past = $request->get_param('include_past') ? true : false;
    
    // טיפול נכון ב-boolean parameter
    $show_only_booked_param = $request->get_param('show_only_booked');
    if ($show_only_booked_param === null || $show_only_booked_param === '') {
        $show_only_booked = true; // ברירת מחדל
    } else {
        $show_only_booked = filter_var($show_only_booked_param, FILTER_VALIDATE_BOOLEAN);
    }

    // המרת show_only_booked ל-mode
    $mode = $show_only_booked ? 'booked_only' : 'all';
    
    // שימוש ב-at_get_future_tours_data המשותפת - אותה לוגיקה לכולם!
    $result = at_get_future_tours_data($start_date, $end_date, '', $product_id, $include_past, $mode);
    
    $product = wc_get_product($product_id);
    if (!$product) {
        return new WP_Error('invalid_product', 'Product not found', array('status' => 404));
    }

    return rest_ensure_response(array(
        'success' => true,
        'product_id' => $product_id,
        'product_info' => array(
            'name' => $product->get_name(),
            'type' => $product->get_type(),
            'duration' => $product->get_duration() . ' ' . $product->get_duration_unit(),
            'max_persons' => $product->get_max_persons(),
            'has_person_types' => $product->get_has_person_types(),
            'restricted_days' => get_post_meta($product_id, '_wc_booking_restricted_days', true),
            'guides_data' => get_post_meta($product_id, '_guides_data', true),
        ),
        'date_range' => array(
            'start' => $start_date,
            'end' => $end_date,
            'include_past' => $include_past
        ),
        'filters' => array(
            'show_only_booked' => $show_only_booked,
            'mode' => $mode
        ),
        'slots' => $result['data'] ?? array()
    ));
}

/**
 * API Endpoint: קבלת פרטי מחזור מסוים עם כל ההזמנות
 * GET /wp-json/at/v1/slot-details
 * Parameters: product_id, date, time, api_key
 */
add_action('rest_api_init', function() {
    register_rest_route('at/v1', '/slot-details', array(
        'methods' => 'GET',
        'callback' => 'at_api_get_slot_details',
        'permission_callback' => 'at_api_check_permission',
        'args' => array(
            'product_id' => array('required' => true, 'type' => 'integer'),
            'date' => array('required' => true, 'type' => 'string'),
            'time' => array('required' => true, 'type' => 'string'),
            'api_key' => array('required' => true, 'type' => 'string'),
        ),
    ));
});

function at_api_get_slot_details($request) {
    $product_id = $request->get_param('product_id');
    $date = $request->get_param('date');
    $time = $request->get_param('time');
    
    // קבלת פרטי המוצר
    $product = wc_get_product($product_id);
    if (!$product) {
        return new WP_Error('invalid_product', 'Product not found', array('status' => 404));
    }
    
    // קבלת ההזמנות
    $orders = at_get_tour_orders_data($product_id, $date, $time);
    
    // חישוב סיכומים
    $total_persons = 0;
    $person_types = array();
    
    foreach ($orders as $order) {
        $total_persons += intval($order['persons']);
        
        // קבלת פירוט סוגי כרטיסים
        $booking = get_wc_booking($order['booking_id']);
        if ($booking && method_exists($booking, 'get_persons')) {
            $booking_persons = $booking->get_persons();
            foreach ($booking_persons as $type_id => $count) {
                if (!isset($person_types[$type_id])) {
                    $person_types[$type_id] = array(
                        'type_id' => $type_id,
                        'type_name' => at_get_person_type_name($product_id, $type_id),
                        'count' => 0
                    );
                }
                $person_types[$type_id]['count'] += intval($count);
            }
        }
    }
    
    // קבלת קיבולת
    $max_capacity = get_post_meta($product_id, '_wc_booking_max_persons_group', true);
    if (!$max_capacity) {
        $max_capacity = get_post_meta($product_id, '_wc_booking_max_persons', true);
    }
    $max_capacity = intval($max_capacity ?: 0);
    
    return rest_ensure_response(array(
        'success' => true,
        'slot_info' => array(
            'product_id' => $product_id,
            'product_name' => $product->get_name(),
            'date' => $date,
            'time' => $time,
            'max_capacity' => $max_capacity,
            'booked_persons' => $total_persons,
            'available' => max(0, $max_capacity - $total_persons),
            'is_available' => ($total_persons < $max_capacity)
        ),
        'person_types_summary' => array_values($person_types),
        'bookings' => at_enrich_bookings_data($orders)
    ));
}

/**
 * פונקציה עזר: קבלת שם סוג אדם
 */
function at_get_person_type_name($product_id, $type_id) {
    $product = wc_get_product($product_id);
    if (!$product || !method_exists($product, 'get_person_types')) {
        return 'Person Type ' . $type_id;
    }
    
    $person_types = $product->get_person_types();
    foreach ($person_types as $person_type) {
        if ($person_type->ID == $type_id) {
            return $person_type->post_title;
        }
    }
    
    return 'Person Type ' . $type_id;
}

/**
 * פונקציה עזר: העשרת נתוני הזמנות
 */
function at_enrich_bookings_data($orders) {
    $enriched = array();
    
    foreach ($orders as $order) {
        $booking = get_wc_booking($order['booking_id']);
        $wc_order = wc_get_order($order['order_id']);
        
        $booking_data = $order;
        
        // הוספת פירוט סוגי כרטיסים
        if ($booking && method_exists($booking, 'get_persons')) {
            $booking_data['person_types'] = array();
            $persons = $booking->get_persons();
            foreach ($persons as $type_id => $count) {
                if ($count > 0) {
                    $booking_data['person_types'][] = array(
                        'type_id' => $type_id,
                        'type_name' => at_get_person_type_name($booking->get_product_id(), $type_id),
                        'count' => intval($count)
                    );
                }
            }
        }
        
        // הוספת קופונים
        $booking_data['coupons'] = array();
        if ($wc_order) {
            $coupons = $wc_order->get_coupon_codes();
            foreach ($coupons as $coupon_code) {
                $coupon = new WC_Coupon($coupon_code);
                $booking_data['coupons'][] = array(
                    'code' => $coupon_code,
                    'amount' => $coupon->get_amount(),
                    'type' => $coupon->get_discount_type()
                );
            }
            
            // הוספת הערות לקוח
            $booking_data['customer_note'] = $wc_order->get_customer_note();
            
            // הוספת הערות פנימיות (order notes)
            $notes = wc_get_order_notes(array(
                'order_id' => $order['order_id'],
                'type' => 'internal'
            ));
            $booking_data['internal_notes'] = array();
            foreach ($notes as $note) {
                $booking_data['internal_notes'][] = array(
                    'date' => $note->date_created->date('Y-m-d H:i:s'),
                    'note' => $note->content
                );
            }
        }
        
        $enriched[] = $booking_data;
    }
    
    return $enriched;
}

/**
 * פונקציית בדיקת הרשאה לכל ה-API endpoints
 */
function at_api_check_permission($request) {
    $api_key = $request->get_param('api_key');
    if (empty($api_key)) {
        return false;
    }
    
    $stored_key = get_option('at_bookings_api_key');
    return !empty($stored_key) && $api_key === $stored_key;
}

/**
 * API Endpoint: קבלת כל המחזורים (כולל עבר) בטווח תאריכים
 * GET /wp-json/at/v1/all-slots
 * Parameters: start_date, end_date, product_id (optional), city (optional), api_key
 */
add_action('rest_api_init', function() {
    register_rest_route('at/v1', '/all-slots', array(
        'methods' => 'GET',
        'callback' => 'at_api_get_all_slots',
        'permission_callback' => 'at_api_check_permission',
        'args' => array(
            'start_date' => array('required' => true, 'type' => 'string'),
            'end_date' => array('required' => true, 'type' => 'string'),
            'product_id' => array('required' => false, 'type' => 'integer'),
            'city' => array('required' => false, 'type' => 'string'),
            'include_past' => array('required' => false, 'type' => 'boolean', 'default' => false),
            'mode' => array('required' => false, 'type' => 'string', 'default' => 'all'),
            'api_key' => array('required' => true, 'type' => 'string'),
        ),
    ));
});

function at_api_get_all_slots($request) {
    $start_date = $request->get_param('start_date');
    $end_date = $request->get_param('end_date');
    $product_id = $request->get_param('product_id') ?: 0;
    $city = $request->get_param('city') ?: '';
    $include_past = $request->get_param('include_past') ?: false;
    $mode = $request->get_param('mode') ?: 'all';

    $result = at_get_future_tours_data($start_date, $end_date, $city, $product_id, $include_past, $mode);

    return rest_ensure_response(array(
        'success' => true,
        'filters' => array(
            'start_date' => $start_date,
            'end_date' => $end_date,
            'product_id' => $product_id ?: null,
            'city' => $city ?: null,
            'include_past' => $include_past,
            'mode' => $mode
        ),
        'total_slots' => $result['recordsTotal'] ?? 0,
        'slots' => $result['data'] ?? array()
    ));
}
