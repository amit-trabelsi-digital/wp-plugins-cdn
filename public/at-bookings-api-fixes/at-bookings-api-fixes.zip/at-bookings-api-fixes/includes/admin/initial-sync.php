<?php
/**
 * Initial Sync Admin Page
 *
 * Orchestrates bulk product/cycle/order sync to Zoho with insert-only mode,
 * batching, resume/stop controls, and real-time logging.
 *
 * @package AT_Bookings_API_Fixes
 * @subpackage Admin
 * @since 3.5.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Bookings_Initial_Sync {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('wp_ajax_at_initial_sync_get_products', array($this, 'ajax_get_products'));
        add_action('wp_ajax_at_initial_sync_sync_products', array($this, 'ajax_sync_products'));
        add_action('wp_ajax_at_initial_sync_get_cycles', array($this, 'ajax_get_cycles'));
        add_action('wp_ajax_at_initial_sync_sync_cycles', array($this, 'ajax_sync_cycles'));
        add_action('wp_ajax_at_initial_sync_get_orders', array($this, 'ajax_get_orders'));
        add_action('wp_ajax_at_initial_sync_sync_orders', array($this, 'ajax_sync_orders'));
        add_action('wp_ajax_at_initial_sync_stop', array($this, 'ajax_stop_sync'));
        add_action('wp_ajax_at_initial_sync_reset_metadata', array($this, 'ajax_reset_metadata'));
    }
    
    /**
     * Render the Initial Sync page
     */
    public static function render() {
        if (!current_user_can('manage_options')) {
            wp_die(__('Insufficient permissions', 'at-bookings-api-fixes'));
        }
        
        $is_rtl = is_rtl();
        ?>
        <div class="wrap at-initial-sync" dir="<?php echo $is_rtl ? 'rtl' : 'ltr'; ?>">
            <h1><?php _e('Initial Sync to Zoho', 'at-bookings-api-fixes'); ?></h1>
            <p class="description"><?php _e('Synchronize products, cycles (bookings), and orders to Zoho CRM for the first time. Insert-only mode prevents duplicates.', 'at-bookings-api-fixes'); ?></p>
            <div style="background: #e7f3ff; border: 1px solid #0073aa; border-radius: 4px; padding: 12px; margin: 15px 0;">
                <strong><?php _e('💡 Debug Information:', 'at-bookings-api-fixes'); ?></strong><br>
                <?php _e('Detailed debug logs with full API payloads and responses are saved to:', 'at-bookings-api-fixes'); ?><br>
                <code style="display: block; margin-top: 8px; background: #fff; padding: 8px; border-radius: 3px; font-size: 11px;">
                    wp-content/uploads/at-logs/errors-<?php echo date('Y-m-d'); ?>.log
                </code>
                <?php _e('Log entries contain: SKU, WC PID, Zoho search queries, API payloads, and Zoho responses.', 'at-bookings-api-fixes'); ?>
            </div>
            
            <!-- Tabs -->
            <div class="nav-tab-wrapper">
                <a href="#" class="nav-tab nav-tab-active at-tab-trigger" data-tab="products">
                    <span class="dashicons dashicons-product"></span>
                    <?php _e('Products', 'at-bookings-api-fixes'); ?>
                </a>
                <a href="#" class="nav-tab at-tab-trigger" data-tab="cycles">
                    <span class="dashicons dashicons-calendar"></span>
                    <?php _e('Cycles', 'at-bookings-api-fixes'); ?>
                </a>
                <a href="#" class="nav-tab at-tab-trigger" data-tab="orders">
                    <span class="dashicons dashicons-cart"></span>
                    <?php _e('Orders', 'at-bookings-api-fixes'); ?>
                </a>
            </div>
            
            <!-- Products Tab -->
            <div class="at-tab-content at-tab-products active">
                <div class="at-sync-panel">
                    <h2><?php _e('Product Synchronization', 'at-bookings-api-fixes'); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php _e('Batch Size', 'at-bookings-api-fixes'); ?></th>
                            <td>
                                <input type="number" id="products-batch-size" value="10" min="1" max="50">
                                <label>
                                    <input type="checkbox" id="products-sync-all" value="1">
                                    <?php _e('Sync all (ignore batch size)', 'at-bookings-api-fixes'); ?>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Force Create', 'at-bookings-api-fixes'); ?></th>
                            <td>
                                <label style="display: flex; align-items: center; gap: 8px; padding: 10px; background: #fffbea; border: 1px solid #ffc107; border-radius: 4px;">
                                    <input type="checkbox" id="products-force-create" value="1">
                                    <span><?php _e('✨ Create new products in Zoho even if they were never synced before (יצור מוצרים חדשים בזוהו)', 'at-bookings-api-fixes'); ?></span>
                                </label>
                                <p style="margin: 8px 0 0 0; color: #666; font-size: 12px;">
                                    <?php _e('Check this if you cleared the Zoho records or are doing a fresh sync. Without this, only products with an existing Zoho ID will be synced.', 'at-bookings-api-fixes'); ?>
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Status', 'at-bookings-api-fixes'); ?></th>
                            <td id="products-status"><?php _e('Ready', 'at-bookings-api-fixes'); ?></td>
                        </tr>
                    </table>
                    
                    <div class="at-sync-actions">
                        <button type="button" class="button button-secondary at-reset-metadata-btn" data-sync-type="products" style="margin-left: 10px;">
                            <span class="dashicons dashicons-trash"></span>
                            <?php _e('Reset Sync Metadata', 'at-bookings-api-fixes'); ?>
                        </button>
                        <button type="button" class="button button-primary at-sync-start-btn" data-sync-type="products">
                            <span class="dashicons dashicons-update"></span>
                            <?php _e('Start Sync', 'at-bookings-api-fixes'); ?>
                        </button>
                        <button type="button" class="button at-sync-stop-btn" data-sync-type="products" disabled>
                            <span class="dashicons dashicons-no-alt"></span>
                            <?php _e('Stop', 'at-bookings-api-fixes'); ?>
                        </button>
                    </div>
                    
                    <div class="at-sync-progress">
                        <div class="at-progress-bar">
                            <div class="at-progress-fill" id="products-progress" style="width: 0%;"></div>
                        </div>
                        <div class="at-progress-text">
                            <span id="products-progress-text">0%</span>
                        </div>
                    </div>
                    
                    <div class="at-sync-log">
                        <h3><?php _e('Sync Log', 'at-bookings-api-fixes'); ?></h3>
                        <div class="at-log-console" id="products-log"></div>
                    </div>
                </div>
            </div>
            
            <!-- Cycles Tab -->
            <div class="at-tab-content at-tab-cycles">
                <div class="at-sync-panel">
                    <h2><?php _e('Cycle (Booking) Synchronization', 'at-bookings-api-fixes'); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php _e('Start Date', 'at-bookings-api-fixes'); ?></th>
                            <td>
                                <input type="date" id="cycles-start-date" value="<?php echo date('Y-m-d'); ?>">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('End Date', 'at-bookings-api-fixes'); ?></th>
                            <td>
                                <input type="date" id="cycles-end-date" value="<?php echo date('Y-m-d', strtotime('+90 days')); ?>">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Batch Size', 'at-bookings-api-fixes'); ?></th>
                            <td>
                                <input type="number" id="cycles-batch-size" value="20" min="1" max="100">
                                <label>
                                    <input type="checkbox" id="cycles-sync-all" value="1">
                                    <?php _e('Sync all (ignore batch size)', 'at-bookings-api-fixes'); ?>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Filter', 'at-bookings-api-fixes'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" id="cycles-with-bookings-only" value="1">
                                    <?php _e('רק מחזורים עם הזמנות קיימות', 'at-bookings-api-fixes'); ?>
                                </label>
                                <p class="description"><?php _e('אם מסומן, יסנכרן רק מחזורים שיש להם לפחות הזמנה אחת', 'at-bookings-api-fixes'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Status', 'at-bookings-api-fixes'); ?></th>
                            <td id="cycles-status"><?php _e('Ready', 'at-bookings-api-fixes'); ?></td>
                        </tr>
                    </table>
                    
                    <div class="at-sync-actions">
                        <button type="button" class="button button-primary at-sync-start-btn" data-sync-type="cycles">
                            <span class="dashicons dashicons-update"></span>
                            <?php _e('Start Sync', 'at-bookings-api-fixes'); ?>
                        </button>
                        <button type="button" class="button at-sync-stop-btn" data-sync-type="cycles" disabled>
                            <span class="dashicons dashicons-no-alt"></span>
                            <?php _e('Stop', 'at-bookings-api-fixes'); ?>
                        </button>
                        <button type="button" class="button" id="clear-cycles-cache-btn">
                            <span class="dashicons dashicons-trash"></span>
                            <?php _e('Clear Cache', 'at-bookings-api-fixes'); ?>
                        </button>
                    </div>
                    
                    <div class="at-sync-progress">
                        <div class="at-progress-bar">
                            <div class="at-progress-fill" id="cycles-progress" style="width: 0%;"></div>
                        </div>
                        <div class="at-progress-text">
                            <span id="cycles-progress-text">0%</span>
                        </div>
                    </div>
                    
                    <div class="at-sync-log">
                        <h3><?php _e('Sync Log', 'at-bookings-api-fixes'); ?></h3>
                        <div class="at-log-console" id="cycles-log"></div>
                    </div>
                </div>
            </div>
            
            <!-- Orders Tab -->
            <div class="at-tab-content at-tab-orders">
                <div class="at-sync-panel">
                    <h2><?php _e('Order Synchronization', 'at-bookings-api-fixes'); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php _e('Start Date', 'at-bookings-api-fixes'); ?></th>
                            <td>
                                <input type="date" id="orders-start-date" value="<?php echo date('Y-m-d', strtotime('-30 days')); ?>">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Order Status', 'at-bookings-api-fixes'); ?></th>
                            <td>
                                <select id="orders-status">
                                    <option value=""><?php _e('All Statuses', 'at-bookings-api-fixes'); ?></option>
                                    <option value="wc-pending"><?php _e('Pending', 'at-bookings-api-fixes'); ?></option>
                                    <option value="wc-processing"><?php _e('Processing', 'at-bookings-api-fixes'); ?></option>
                                    <option value="wc-on-hold"><?php _e('On Hold', 'at-bookings-api-fixes'); ?></option>
                                    <option value="wc-completed"><?php _e('Completed', 'at-bookings-api-fixes'); ?></option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Batch Size', 'at-bookings-api-fixes'); ?></th>
                            <td>
                                <input type="number" id="orders-batch-size" value="15" min="1" max="50">
                                <label>
                                    <input type="checkbox" id="orders-sync-all" value="1">
                                    <?php _e('Sync all (ignore batch size)', 'at-bookings-api-fixes'); ?>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Status', 'at-bookings-api-fixes'); ?></th>
                            <td id="orders-status-display"><?php _e('Ready', 'at-bookings-api-fixes'); ?></td>
                        </tr>
                    </table>
                    
                    <div class="at-sync-actions">
                        <button type="button" class="button button-primary at-sync-start-btn" data-sync-type="orders">
                            <span class="dashicons dashicons-update"></span>
                            <?php _e('Start Sync', 'at-bookings-api-fixes'); ?>
                        </button>
                        <button type="button" class="button at-sync-stop-btn" data-sync-type="orders" disabled>
                            <span class="dashicons dashicons-no-alt"></span>
                            <?php _e('Stop', 'at-bookings-api-fixes'); ?>
                        </button>
                    </div>
                    
                    <div class="at-sync-progress">
                        <div class="at-progress-bar">
                            <div class="at-progress-fill" id="orders-progress" style="width: 0%;"></div>
                        </div>
                        <div class="at-progress-text">
                            <span id="orders-progress-text">0%</span>
                        </div>
                    </div>
                    
                    <div class="at-sync-log">
                        <h3><?php _e('Sync Log', 'at-bookings-api-fixes'); ?></h3>
                        <div class="at-log-console" id="orders-log"></div>
                    </div>
                </div>
            </div>
            
            <style>
                .at-initial-sync {
                    max-width: 1200px;
                    margin: 20px auto;
                }
                
                .at-initial-sync .nav-tab-wrapper {
                    margin: 20px 0;
                    border-bottom: 2px solid #ddd;
                }
                
                .at-initial-sync .nav-tab {
                    padding: 10px 15px;
                    border: none;
                    border-bottom: 3px solid transparent;
                    cursor: pointer;
                    color: #666;
                }
                
                .at-initial-sync .nav-tab:hover,
                .at-initial-sync .nav-tab.nav-tab-active {
                    color: #0073aa;
                    border-bottom-color: #0073aa;
                }
                
                .at-initial-sync .nav-tab .dashicons {
                    margin-right: 5px;
                    vertical-align: middle;
                }
                
                .at-tab-content {
                    display: none;
                    padding: 20px 0;
                }
                
                .at-tab-content.active {
                    display: block;
                }
                
                .at-sync-panel {
                    background: #fff;
                    padding: 20px;
                    border: 1px solid #ddd;
                    border-radius: 4px;
                }
                
                .at-sync-panel h2 {
                    margin-top: 0;
                }
                
                .at-sync-actions {
                    margin: 20px 0;
                }
                
                .at-sync-actions button {
                    margin-right: 10px;
                }
                
                .at-sync-progress {
                    margin: 20px 0;
                    display: none;
                }
                
                .at-sync-progress.active {
                    display: block;
                }
                
                .at-progress-bar {
                    width: 100%;
                    height: 30px;
                    background: #f0f0f0;
                    border: 1px solid #ddd;
                    border-radius: 4px;
                    overflow: hidden;
                    position: relative;
                }
                
                .at-progress-fill {
                    height: 100%;
                    background: linear-gradient(90deg, #0073aa, #0073aa);
                    transition: width 0.3s ease;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    color: white;
                    font-weight: bold;
                }
                
                .at-progress-text {
                    text-align: center;
                    margin-top: 10px;
                    font-weight: bold;
                }
                
                .at-sync-log {
                    margin: 20px 0;
                }
                
                .at-log-console {
                    background: #f5f5f5;
                    border: 1px solid #ddd;
                    border-radius: 4px;
                    padding: 15px;
                    height: 400px;
                    overflow-y: auto;
                    font-family: monospace;
                    font-size: 12px;
                    line-height: 1.5;
                }
                
                .at-log-entry {
                    padding: 5px 0;
                    border-bottom: 1px solid #eee;
                }
                
                .at-log-entry.success {
                    color: #28a745;
                }
                
                .at-log-entry.error {
                    color: #dc3545;
                }
                
                .at-log-entry.info {
                    color: #17a2b8;
                }
                
                .at-log-entry.warning {
                    color: #ffc107;
                }
                
                .at-log-entry:last-child {
                    border-bottom: none;
                }
                
                .at-initial-sync .form-table {
                    margin: 20px 0;
                    width: 100%;
                }
                
                .at-initial-sync .form-table input[type="number"],
                .at-initial-sync .form-table input[type="date"],
                .at-initial-sync .form-table select {
                    width: 200px;
                    padding: 5px;
                }
                
                .at-initial-sync .form-table td > label {
                    display: block;
                    margin-top: 10px;
                }
                
                .description {
                    font-style: italic;
                    color: #666;
                    margin: 10px 0;
                }
            </style>
        </div>
        <?php
    }
    
    /**
     * AJAX: Get products to sync
     */
    public function ajax_get_products() {
        check_ajax_referer('at_bookings_dashboard', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
        }
        
        $batch_size = (int) ($_POST['batch_size'] ?? 10);
        $sync_all = isset($_POST['sync_all']) && $_POST['sync_all'];
        
        if (!class_exists('AT_Zoho_Sync_Service_Initial')) {
            require_once dirname(__FILE__) . '/../zoho/zoho-sync-service-initial.php';
        }
        
        $sync_helper = new AT_Zoho_Sync_Service_Initial();
        $products = $sync_helper->get_products_to_sync($sync_all ? 10000 : $batch_size);
        
        wp_send_json_success([
            'count' => count($products),
            'total' => $sync_all ? count($products) : '?',
            'batch_size' => $batch_size,
        ]);
    }
    
    /**
     * AJAX: Sync products batch
     */
    public function ajax_sync_products() {
        check_ajax_referer('at_bookings_dashboard', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
        }
        
        $batch_size = (int) ($_POST['batch_size'] ?? 10);
        $offset = (int) ($_POST['offset'] ?? 0);
        $sync_all = isset($_POST['sync_all']) && $_POST['sync_all'];
        $force_create = isset($_POST['force_create']) && $_POST['force_create']; // New: Force create flag
        
        if (!class_exists('AT_Zoho_Sync_Service_Initial')) {
            require_once dirname(__FILE__) . '/../zoho/zoho-sync-service-initial.php';
        }
        
        $sync_helper = new AT_Zoho_Sync_Service_Initial();
        
        // If force_create is enabled, sync ALL products (not just those already synced)
        // Otherwise use the default insert-only mode (only products not yet synced)
        $insert_only_mode = !$force_create; // Invert: if force_create=true, insert_only=false
        
        // Get more products than batch size to handle skipped ones, but limit actual sync
        // Pass insert_only_mode to get_products_to_sync so it respects the force_create flag
        $products_to_check = $sync_helper->get_products_to_sync($sync_all ? 10000 : ($batch_size * 2), $offset, $insert_only_mode);
        
        if (empty($products_to_check)) {
            wp_send_json_success([
                'done' => true,
                'message' => __('No more products to sync', 'at-bookings-api-fixes'),
            ]);
        }
        
        // Sync with insert_only_mode based on force_create checkbox
        // true = only sync new products (default safe mode)
        // false = sync all products including those previously synced (force create mode)
        $result = $sync_helper->sync_products_batch($products_to_check, $insert_only_mode, $batch_size);
        
        wp_send_json_success([
            'done' => count($products_to_check) < $batch_size,
            'result' => $result,
            'offset' => $offset + count($result['records']), // Increment by actual synced count
            'force_create_mode' => $force_create,
        ]);
    }
    
    /**
     * AJAX: Get cycles to sync
     */
    public function ajax_get_cycles() {
        check_ajax_referer('at_bookings_dashboard', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
        }
        
        $start_date = sanitize_text_field($_POST['start_date'] ?? '');
        $end_date = sanitize_text_field($_POST['end_date'] ?? '');
        $batch_size = (int) ($_POST['batch_size'] ?? 20);
        $sync_all = isset($_POST['sync_all']) && $_POST['sync_all'];
        $with_bookings_only = isset($_POST['with_bookings_only']) && $_POST['with_bookings_only'];
        
        if (!class_exists('AT_Zoho_Sync_Service_Initial')) {
            require_once dirname(__FILE__) . '/../zoho/zoho-sync-service-initial.php';
        }
        
        $sync_helper = new AT_Zoho_Sync_Service_Initial();
        $cycles = $sync_helper->get_cycles_to_sync($start_date, $end_date, $sync_all ? 10000 : $batch_size);
        
        // Filter: only cycles with bookings
        if ($with_bookings_only) {
            $cycles = array_filter($cycles, function($cycle) {
                return isset($cycle['bookings_count']) && $cycle['bookings_count'] > 0;
            });
            $cycles = array_values($cycles); // Re-index
        }
        
        // Build preview list (first 20 items)
        $preview_list = array();
        $preview_count = min(count($cycles), 20);
        for ($i = 0; $i < $preview_count; $i++) {
            $cycle = $cycles[$i];
            $preview_list[] = array(
                'tour_id' => $cycle['tour_id'] ?? 'unknown',
                'product_name' => $cycle['product_name'] ?? 'Unknown',
                'date' => $cycle['date'] ?? '',
                'time' => $cycle['start_time'] ?? '',
                'city' => $cycle['city'] ?? ''
            );
        }
        
        wp_send_json_success([
            'count' => count($cycles),
            'total' => $sync_all ? count($cycles) : '?',
            'batch_size' => $batch_size,
            'preview' => $preview_list,
            'has_more' => count($cycles) > 20
        ]);
    }
    
    /**
     * AJAX: Sync cycles batch
     */
    public function ajax_sync_cycles() {
        check_ajax_referer('at_bookings_dashboard', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
        }
        
        $start_date = sanitize_text_field($_POST['start_date'] ?? '');
        $end_date = sanitize_text_field($_POST['end_date'] ?? '');
        $batch_size = (int) ($_POST['batch_size'] ?? 20);
        $offset = (int) ($_POST['offset'] ?? 0);
        $sync_all = isset($_POST['sync_all']) && $_POST['sync_all'];
        $with_bookings_only = isset($_POST['with_bookings_only']) && $_POST['with_bookings_only'];
        
        // Auto-clear cache before first batch
        if ($offset === 0) {
            // Load AT_Zoho_Sync_Service if needed
            if (!class_exists('AT_Zoho_Sync_Service')) {
                require_once dirname(__FILE__) . '/../zoho/zoho-sync-service.php';
            }
            
            if (class_exists('AT_Zoho_Sync_Service')) {
                $sync_service = new AT_Zoho_Sync_Service();
                $cleared = $sync_service->clear_all_cycles_cache();
                write_detailed_log("Auto-cleared $cleared cycle cache entries before bulk sync", 'INFO');
            }
        }
        
        if (!class_exists('AT_Zoho_Sync_Service_Initial')) {
            require_once dirname(__FILE__) . '/../zoho/zoho-sync-service-initial.php';
        }
        
        $sync_helper = new AT_Zoho_Sync_Service_Initial();
        // Fix: Pass offset+batch_size to limit to ensure we get enough records for slicing
        $fetch_limit = $sync_all ? 10000 : ($offset + $batch_size);
        $cycles = $sync_helper->get_cycles_to_sync($start_date, $end_date, $fetch_limit);
        
        // Filter: only cycles with bookings
        if ($with_bookings_only) {
            $cycles = array_filter($cycles, function($cycle) {
                return isset($cycle['bookings_count']) && $cycle['bookings_count'] > 0;
            });
            $cycles = array_values($cycles); // Re-index
        }
        
        // Apply offset
        $cycles = array_slice($cycles, $offset, $batch_size);
        
        if (empty($cycles)) {
            wp_send_json_success([
                'done' => true,
                'message' => __('No more cycles to sync', 'at-bookings-api-fixes'),
            ]);
        }
        
        $result = $sync_helper->sync_cycles_batch($cycles);
        
        wp_send_json_success([
            'done' => count($cycles) < $batch_size,
            'result' => $result,
            'offset' => $offset + $batch_size,
        ]);
    }
    
    /**
     * AJAX: Get orders to sync
     */
    public function ajax_get_orders() {
        check_ajax_referer('at_bookings_dashboard', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
        }
        
        $start_date = sanitize_text_field($_POST['start_date'] ?? '');
        $order_status = sanitize_text_field($_POST['order_status'] ?? '');
        $batch_size = (int) ($_POST['batch_size'] ?? 15);
        $sync_all = isset($_POST['sync_all']) && $_POST['sync_all'];
        
        if (!class_exists('AT_Zoho_Sync_Service_Initial')) {
            require_once dirname(__FILE__) . '/../zoho/zoho-sync-service-initial.php';
        }
        
        $sync_helper = new AT_Zoho_Sync_Service_Initial();
        $orders = $sync_helper->get_orders_to_sync($start_date, $order_status ?: null, $sync_all ? 10000 : $batch_size);
        
        wp_send_json_success([
            'count' => count($orders),
            'total' => $sync_all ? count($orders) : '?',
            'batch_size' => $batch_size,
        ]);
    }
    
    /**
     * AJAX: Sync orders batch
     */
    public function ajax_sync_orders() {
        check_ajax_referer('at_bookings_dashboard', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
        }
        
        $start_date = sanitize_text_field($_POST['start_date'] ?? '');
        $order_status = sanitize_text_field($_POST['order_status'] ?? '');
        $batch_size = (int) ($_POST['batch_size'] ?? 15);
        $offset = (int) ($_POST['offset'] ?? 0);
        $sync_all = isset($_POST['sync_all']) && $_POST['sync_all'];
        
        if (!class_exists('AT_Zoho_Sync_Service_Initial')) {
            require_once dirname(__FILE__) . '/../zoho/zoho-sync-service-initial.php';
        }
        
        $sync_helper = new AT_Zoho_Sync_Service_Initial();
        $orders = $sync_helper->get_orders_to_sync($start_date, $order_status ?: null, $sync_all ? 10000 : $batch_size);
        
        // Apply offset
        $orders = array_slice($orders, $offset, $batch_size);
        
        if (empty($orders)) {
            wp_send_json_success([
                'done' => true,
                'message' => __('No more orders to sync', 'at-bookings-api-fixes'),
            ]);
        }
        
        $result = $sync_helper->sync_orders_batch($orders);
        
        wp_send_json_success([
            'done' => count($orders) < $batch_size,
            'result' => $result,
            'offset' => $offset + $batch_size,
        ]);
    }
    
    /**
     * AJAX: Stop sync
     */
    public function ajax_stop_sync() {
        check_ajax_referer('at_bookings_dashboard', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
        }
        
        if (!class_exists('AT_Zoho_Sync_Service_Initial')) {
            require_once dirname(__FILE__) . '/../zoho/zoho-sync-service-initial.php';
        }
        
        $sync_helper = new AT_Zoho_Sync_Service_Initial();
        $sync_helper->set_stop_flag();
        
        wp_send_json_success(__('Sync stop signal sent', 'at-bookings-api-fixes'));
    }
    
    /**
     * AJAX: Reset sync metadata from all products
     * Clears _zoho_product_id, _at_zoho_sync_state, and optionally SKU
     */
    public function ajax_reset_metadata() {
        check_ajax_referer('at_bookings_dashboard', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
        }
        
        $sync_type = sanitize_text_field($_POST['sync_type'] ?? 'products');
        $reset_sku = isset($_POST['reset_sku']) && $_POST['reset_sku'];
        
        if ($sync_type === 'products') {
            $args = [
                'post_type' => 'product',
                'post_status' => 'any',
                'numberposts' => -1,
                'fields' => 'ids',
            ];
            
            $product_ids = get_posts($args);
            $count = 0;
            
            foreach ($product_ids as $product_id) {
                // Delete Zoho-related meta
                delete_post_meta($product_id, '_zoho_product_id');
                delete_post_meta($product_id, '_at_zoho_sync_state');
                delete_post_meta($product_id, '_zoho_last_sync');
                
                // Optionally reset SKU if it looks like a Zoho ID
                if ($reset_sku) {
                    $sku = get_post_meta($product_id, '_sku', true);
                    // Check if SKU is a Zoho ID format (long numeric string)
                    if ($sku && is_numeric($sku) && strlen($sku) > 15) {
                        // Delete SKU using direct meta update (avoid WC_Product->save() issues)
                        update_post_meta($product_id, '_sku', '');
                        AT_Bookings_Logger::info("Reset SKU for product #{$product_id} (was Zoho ID: {$sku})");
                    }
                }
                
                $count++;
            }
            
            AT_Bookings_Logger::info("Reset sync metadata for {$count} products" . ($reset_sku ? ' (including SKUs)' : ''));
            
            wp_send_json_success([
                'message' => sprintf(__('Reset sync metadata for %d products', 'at-bookings-api-fixes'), $count),
                'count' => $count,
            ]);
        } else {
            wp_send_json_error(__('Invalid sync type', 'at-bookings-api-fixes'));
        }
    }
}

// Initialize
AT_Bookings_Initial_Sync::get_instance();

