<?php
/**
 * Slots Management Admin Page
 * 
 * Provides interface for viewing and managing booking slots
 * 
 * @package AT_Bookings_API_Fixes
 * @subpackage Admin
 * @since 3.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Bookings_Slots_Management {
    
    /**
     * Render slots management page
     */
    public static function render() {
        global $wpdb;
        
        $slots_table = $wpdb->prefix . 'at_booking_slots';
        $is_rtl = is_rtl();
        
        // Get filter values
        $product_filter = isset($_GET['product_id']) ? (int) $_GET['product_id'] : 0;
        $city_filter = isset($_GET['city']) ? sanitize_text_field($_GET['city']) : '';
        $status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
        $tour_id_filter = isset($_GET['tour_id']) ? sanitize_text_field($_GET['tour_id']) : '';
        $time_range = isset($_GET['time_range']) ? sanitize_text_field($_GET['time_range']) : 'future';
        
        // חישוב טווח תאריכים לפי time_range
        if (isset($_GET['date_from']) && isset($_GET['date_to'])) {
            // אם המשתמש בחר תאריכים ידנית
            $date_from = sanitize_text_field($_GET['date_from']);
            $date_to = sanitize_text_field($_GET['date_to']);
        } elseif ($tour_id_filter) {
            // אם מחפשים לפי tour_id, חפש בטווח רחב (6 חודשים אחורה + 6 חודשים קדימה)
            $date_from = date('Y-m-d', strtotime('-180 days'));
            $date_to = date('Y-m-d', strtotime('+180 days'));
        } else {
            // ברירת מחדל לפי time_range
            switch ($time_range) {
                case 'past':
                    $date_from = date('Y-m-d', strtotime('-30 days'));
                    $date_to = date('Y-m-d');
                    break;
                case 'all':
                    $date_from = date('Y-m-d', strtotime('-30 days'));
                    $date_to = date('Y-m-d', strtotime('+60 days'));
                    break;
                case 'future':
                default:
                    $date_from = date('Y-m-d');
                    $date_to = date('Y-m-d', strtotime('+60 days'));
                    break;
            }
        }
        
        ?>
        <div class="wrap at-slots-management" dir="<?php echo $is_rtl ? 'rtl' : 'ltr'; ?>">
            <h1><?php _e('Tours & Cycles Management', 'at-bookings-api-fixes'); ?></h1>
            
            <div class="notice notice-info">
                <p>
                    <?php _e('View and manage all tour cycles (past and future) from WooCommerce Bookings.', 'at-bookings-api-fixes'); ?>
                    <br>
                    <strong><?php _e('Note:', 'at-bookings-api-fixes'); ?></strong> 
                    <?php _e('This page uses live data from WooCommerce Bookings and groups bookings by tour cycle (product + date/time).', 'at-bookings-api-fixes'); ?>
                </p>
            </div>
            
            <!-- Filters -->
            <div class="at-slots-filters">
                <form method="get" action="">
                    <input type="hidden" name="page" value="at-slots-management">
                    
                    <!-- Search by Tour ID -->
                    <div class="at-filter-row at-tour-id-search" style="margin-bottom: 15px; padding: 15px; background: #f0f6fc; border: 1px solid #c3e0f7; border-radius: 4px;">
                        <label for="tour-id-filter" style="display: flex; align-items: center; gap: 5px;">
                            <span class="dashicons dashicons-search" style="color: #2271b1;"></span>
                            <strong><?php _e('Quick Search by Tour ID:', 'at-bookings-api-fixes'); ?></strong>
                        </label>
                        <input type="text" 
                               name="tour_id" 
                               id="tour-id-filter" 
                               value="<?php echo esc_attr($tour_id_filter); ?>" 
                               placeholder="<?php esc_attr_e('e.g., 518_1761818400 or just 518', 'at-bookings-api-fixes'); ?>"
                               style="min-width: 300px; padding: 8px; font-family: monospace;">
                        <button type="submit" class="button button-primary">
                            <span class="dashicons dashicons-search"></span>
                            <?php _e('Search', 'at-bookings-api-fixes'); ?>
                        </button>
                        <?php if ($tour_id_filter): ?>
                            <a href="<?php echo admin_url('admin.php?page=at-slots-management'); ?>" class="button">
                                <span class="dashicons dashicons-no-alt"></span>
                                <?php _e('Clear', 'at-bookings-api-fixes'); ?>
                            </a>
                            <br>
                            <span style="color: #2271b1; margin-top: 5px; display: inline-block;">
                                <span class="dashicons dashicons-info"></span>
                                <?php printf(__('Searching for: %s', 'at-bookings-api-fixes'), '<strong>' . esc_html($tour_id_filter) . '</strong>'); ?>
                                <em style="color: #666; margin-inline-start: 10px;">
                                    (<?php _e('Searching across all dates: past + future', 'at-bookings-api-fixes'); ?>)
                                </em>
                            </span>
                        <?php else: ?>
                            <small style="color: #666; margin-inline-start: 10px;">
                                <?php _e('Supports partial search (e.g., product ID only). Searches in all dates.', 'at-bookings-api-fixes'); ?>
                            </small>
                        <?php endif; ?>
                    </div>
                    
                    <div class="at-filter-row">
                        <label for="time-range-filter">
                            <span class="dashicons dashicons-calendar-alt"></span>
                            <?php _e('Time Range:', 'at-bookings-api-fixes'); ?>
                        </label>
                        <select name="time_range" id="time-range-filter" style="min-width: 150px; font-weight: bold;">
                            <option value="future" <?php selected($time_range, 'future'); ?>><?php _e('Future (Next 60 days)', 'at-bookings-api-fixes'); ?></option>
                            <option value="past" <?php selected($time_range, 'past'); ?>><?php _e('Past (Last 30 days)', 'at-bookings-api-fixes'); ?></option>
                            <option value="all" <?php selected($time_range, 'all'); ?>><?php _e('All (Past + Future)', 'at-bookings-api-fixes'); ?></option>
                        </select>
                        
                        <label for="product-filter"><?php _e('Product:', 'at-bookings-api-fixes'); ?></label>
                        <select name="product_id" id="product-filter" style="min-width: 200px;">
                            <option value=""><?php _e('All Products', 'at-bookings-api-fixes'); ?></option>
                            <?php
                            // קבלת מוצרי booking בלבד
                            $products = wc_get_products(array(
                                'type' => 'booking',
                                'limit' => -1,
                                'status' => 'publish',
                                'orderby' => 'title',
                                'order' => 'ASC'
                            ));
                            
                            foreach ($products as $product) {
                                $selected = $product->get_id() == $product_filter ? 'selected' : '';
                                echo '<option value="' . $product->get_id() . '" ' . $selected . '>' . esc_html($product->get_name()) . '</option>';
                            }
                            ?>
                        </select>
                        
                        <label for="city-filter"><?php _e('City:', 'at-bookings-api-fixes'); ?></label>
                        <select name="city" id="city-filter" style="min-width: 150px;">
                            <option value=""><?php _e('All Cities', 'at-bookings-api-fixes'); ?></option>
                            <?php
                            // קבלת ערים מטקסונומיה
                            if (function_exists('at_get_tour_cities')) {
                                $cities = at_get_tour_cities();
                                foreach ($cities as $city) {
                                    $selected = $city == $city_filter ? 'selected' : '';
                                    echo '<option value="' . esc_attr($city) . '" ' . $selected . '>' . esc_html($city) . '</option>';
                                }
                            }
                            ?>
                        </select>
                        
                        <label for="status-filter"><?php _e('Status:', 'at-bookings-api-fixes'); ?></label>
                        <select name="status" id="status-filter">
                            <option value=""><?php _e('All Statuses', 'at-bookings-api-fixes'); ?></option>
                            <option value="active" <?php selected($status_filter, 'active'); ?>><?php _e('Active', 'at-bookings-api-fixes'); ?></option>
                            <option value="full" <?php selected($status_filter, 'full'); ?>><?php _e('Full', 'at-bookings-api-fixes'); ?></option>
                        </select>
                        
                        <label for="date-from"><?php _e('Date Range:', 'at-bookings-api-fixes'); ?></label>
                        <input type="date" name="date_from" id="date-from" value="<?php echo esc_attr($date_from); ?>">
                        <span>-</span>
                        <input type="date" name="date_to" id="date-to" value="<?php echo esc_attr($date_to); ?>">
                        
                        <button type="submit" class="button"><?php _e('Filter', 'at-bookings-api-fixes'); ?></button>
                        <a href="<?php echo admin_url('admin.php?page=at-slots-management'); ?>" class="button"><?php _e('Reset', 'at-bookings-api-fixes'); ?></a>
                    </div>
                </form>
            </div>
            
            <!-- Actions -->
            <div class="at-slots-actions">
                <p class="description">
                    <?php _e('Data is loaded directly from WooCommerce Bookings. Use filters above to find specific tours.', 'at-bookings-api-fixes'); ?>
                </p>
                
                <!-- Debug Helper: Show Zoho Cycles Fields -->
                <div style="margin-top: 15px; padding: 10px; background: #fff3cd; border: 1px solid #ffc107; border-radius: 4px;">
                    <strong>🔍 Debug Helper:</strong>
                    <button type="button" id="show-cycles-fields" class="button button-secondary">
                        <?php _e('Show Zoho Cycles Module Fields', 'at-bookings-api-fixes'); ?>
                    </button>
                    <small style="color: #856404; margin-inline-start: 10px;">
                        <?php _e('Use this to verify which fields exist in your Zoho Cycles module', 'at-bookings-api-fixes'); ?>
                    </small>
                </div>
            </div>
            
            <!-- Slots Table -->
            <div class="at-slots-table-container">
                <?php self::render_slots_table($product_filter, $city_filter, $status_filter, $tour_id_filter, $date_from, $date_to); ?>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            // 🔍 Debug Helper: Show Cycles Fields Button
            $('#show-cycles-fields').on('click', function() {
                const $btn = $(this);
                const originalHtml = $btn.html();
                
                $btn.prop('disabled', true).html('<span class="dashicons dashicons-update at-spin"></span> <?php _e('Loading...', 'at-bookings-api-fixes'); ?>');
                
                jQuery.post(ajaxurl, {
                    action: 'at_get_cycles_fields',
                    nonce: '<?php echo wp_create_nonce('at_slots_management_nonce'); ?>'
                }, function(response) {
                    $btn.prop('disabled', false).html(originalHtml);
                    
                    if (response.success) {
                        const fields = response.data.fields;
                        const total = response.data.total_fields;
                        
                        console.log('=== ZOHO CYCLES MODULE FIELDS ===');
                        console.log('Total fields:', total);
                        console.log('Fields:', fields);
                        
                        // Build readable list
                        let fieldsList = '═══ ZOHO CYCLES FIELDS (' + total + ') ═══\n\n';
                        
                        // Lookup fields
                        const lookupFields = fields.filter(f => f.lookup !== null);
                        if (lookupFields.length > 0) {
                            fieldsList += '🔗 LOOKUP FIELDS:\n';
                            lookupFields.forEach(f => {
                                fieldsList += '  • ' + f.api_name + ' → ' + f.lookup + '\n';
                                fieldsList += '    Label: ' + f.field_label + '\n';
                            });
                            fieldsList += '\n';
                        }
                        
                        // Regular fields
                        const regularFields = fields.filter(f => f.lookup === null && !f.read_only);
                        fieldsList += '📝 WRITABLE FIELDS:\n';
                        regularFields.forEach(f => {
                            fieldsList += '  • ' + f.api_name + ' (' + f.data_type + ')\n';
                        });
                        
                        alert(fieldsList + '\n\n(Check console for full details)');
                    } else {
                        alert('❌ Error: ' + (response.data || 'Unknown error'));
                    }
                }).fail(function(xhr) {
                    $btn.prop('disabled', false).html(originalHtml);
                    alert('❌ AJAX Error: ' + (xhr.responseJSON?.data || xhr.statusText));
                });
            });
            
            // בדיקה מקדימה אם המחזור קיים ב-Zoho בעת הטעינה
            $('.sync-cycle.has-tooltip').each(function() {
                const $btn = $(this);
                const cid_website = $btn.data('tour-id');
                const previewId = $btn.data('preview-id');
                
                if (!cid_website || !previewId) return;
                
                // קבלת preview data
                let previewData = {};
                try {
                    previewData = JSON.parse($('#' + previewId).text());
                } catch (e) {
                    return;
                }
                
                // חיפוש ב-Zoho
                jQuery.post(ajaxurl, {
                    action: 'at_check_zoho_cycle',
                    nonce: '<?php echo wp_create_nonce('at_slots_management_nonce'); ?>',
                    cid_website: cid_website,
                    tour_id: cid_website
                }, function(response) {
                    if (response.success && response.data.found) {
                        // המחזור קיים ב-Zoho
                        const zohoId = response.data.zoho_id;
                        const zohoUrl = response.data.zoho_url;
                        
                        // החלף את הכפתור בהודעה
                        $btn.replaceWith(
                            '<div class="at-cycle-synced" style="padding: 5px 10px; background: #d4edda; border: 1px solid #28a745; border-radius: 3px; display: inline-block;">' +
                            '<span class="dashicons dashicons-yes-alt" style="color: #28a745; margin-right: 5px;"></span>' +
                            '<strong style="color: #28a745;"><?php _e('Synced to Zoho', 'at-bookings-api-fixes'); ?></strong><br>' +
                            '<small style="color: #155724;"><?php _e('ID:', 'at-bookings-api-fixes'); ?> <a href="' + zohoUrl + '" target="_blank">' + zohoId + '</a></small>' +
                            '</div>'
                        );
                    }
                });
            });
            
            // Tooltip for cycle preview
            let tooltipTimeout;
            
            $(document).on('mouseenter', '.sync-cycle.has-tooltip', function(e) {
                const $btn = $(this);
                const previewId = $btn.data('preview-id');
                
                if (!previewId) return;
                
                // קבלת JSON מ-script tag (לא מattribute)
                const $scriptTag = $('#' + previewId);
                if (!$scriptTag.length) return;
                
                let previewData;
                try {
                    previewData = JSON.parse($scriptTag.text());
                } catch (e) {
                    console.error('Failed to parse preview data:', e);
                    return;
                }
                
                // יצירת tooltip עם הנתונים המלאים
                const $tooltip = $('<div class="at-cycle-tooltip"></div>');
                const jsonString = JSON.stringify(previewData, null, 2);
                
                $tooltip.html(
                    '<div style="background: white; border: 2px solid #2271b1; border-radius: 5px; padding: 15px; box-shadow: 0 2px 10px rgba(0,0,0,0.2); max-width: 600px;">' +
                    '<h4 style="margin: 0 0 10px 0; color: #2271b1;"><?php _e('Zoho Cycle Object Preview', 'at-bookings-api-fixes'); ?></h4>' +
                    '<pre style="margin: 0; background: #f5f5f5; padding: 10px; border-radius: 3px; max-height: 500px; overflow-y: auto; font-size: 11px; direction: ltr; text-align: left; white-space: pre-wrap; word-wrap: break-word;">' + 
                    jsonString + 
                    '</pre>' +
                    '<small style="display: block; margin-top: 10px; color: #666;"><?php _e('This data will be sent to Zoho CRM', 'at-bookings-api-fixes'); ?></small>' +
                    '</div>'
                );
                
                $tooltip.css({
                    position: 'absolute',
                    zIndex: 10000,
                    left: e.pageX + 20,
                    top: e.pageY - 50
                });
                
                $('body').append($tooltip);
                
                $btn.data('tooltip-element', $tooltip);
            }).on('mouseleave', '.sync-cycle.has-tooltip', function() {
                const $btn = $(this);
                const $tooltip = $btn.data('tooltip-element');
                
                if ($tooltip) {
                    $tooltip.fadeOut(200, function() {
                        $(this).remove();
                    });
                }
            });
            
            // Sync cycle to Zoho
            $('.sync-cycle').on('click', function() {
                const $btn = $(this);
                const tourId = $btn.data('tour-id');
                const productId = $btn.data('product-id');
                const previewId = $btn.data('preview-id');
                
                // קבלת JSON מ-script tag
                let previewData = {};
                try {
                    const $scriptTag = $('#' + previewId);
                    if ($scriptTag.length) {
                        previewData = JSON.parse($scriptTag.text());
                    }
                } catch (e) {
                    console.error('Failed to parse preview data:', e);
                    return;
                }
                
                // בדיקה אם ניתן לסנכרן (אם יש Product ID ב-Zoho)
                if (previewData._can_sync === false) {
                    const warning = previewData._sync_warning || '<?php _e('Product not synced to Zoho. Please sync the product first.', 'at-bookings-api-fixes'); ?>';
                    alert('⚠️ ' + warning);
                    return;
                }
                
                if (!confirm('<?php _e('Sync this cycle to Zoho CRM?', 'at-bookings-api-fixes'); ?>\n\n' + 
                            '<?php _e('Tour ID:', 'at-bookings-api-fixes'); ?> ' + tourId + '\n\n' +
                            '<?php _e('Check browser console for full object details.', 'at-bookings-api-fixes'); ?>')) {
                    return;
                }
                
                console.log('=== Zoho Cycle Sync Preview ===');
                console.log('Tour ID:', tourId);
                console.log('Product ID:', productId);
                console.log('Cycle Object:', previewData);
                console.log('JSON:');
                console.log(JSON.stringify(previewData, null, 2));
                
                const originalHtml = $btn.html();
                $btn.prop('disabled', true).html('<span class="dashicons dashicons-update at-spin"></span> <?php _e('Syncing...', 'at-bookings-api-fixes'); ?>');
                
                // AJAX call לסנכרון cycle ספציפי לZoho
                jQuery.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        action: 'at_sync_single_cycle',
                        nonce: '<?php echo wp_create_nonce('at_slots_management_nonce'); ?>',
                        tour_id: tourId,
                        product_id: productId,
                        cycle_data: JSON.stringify(previewData)
                    },
                    timeout: 60000,  // 60 שניות - תן זמן לZoho API להגיב
                    success: function(response) {
                        console.log('=== Zoho Response ===');
                        console.log('Full response:', response);
                        
                        if (response.success) {
                            // ✅ הצלחה!
                            const zohoId = response.data.zoho_id;
                            const action = response.data.action || 'create';
                            const zohoMsg = response.data.zoho_message || 'record added';
                            
                            console.log('✅ Cycle synced successfully!');
                            console.log('Zoho ID:', zohoId);
                            console.log('Zoho message:', zohoMsg);
                            
                            // הצג הודעת הצלחה
                            const successHtml = '<div class="at-cycle-synced" style="padding: 5px 10px; background: #d4edda; border: 1px solid #28a745; border-radius: 3px; display: inline-block;">' +
                                '<span class="dashicons dashicons-yes-alt" style="color: #28a745; margin-right: 5px;"></span>' +
                                '<strong style="color: #28a745;"><?php _e('Synced to Zoho', 'at-bookings-api-fixes'); ?></strong><br>' +
                                '<small style="color: #155724;"><?php _e('ID:', 'at-bookings-api-fixes'); ?> ' + zohoId + '</small>' +
                                '</div>';
                            
                            $btn.replaceWith(successHtml);
                            
                            // 📤 הצג alert פשוט
                            alert('✅ ' + zohoMsg + '\n\nZoho ID: ' + zohoId);
                            
                            // עדכן את השורה
                            $btn.closest('tr').addClass('at-cycle-synced-row');
                        } else {
                            // ❌ שגיאה
                            console.error('Sync error:', response);
                            
                            // 🔍 הודעה מזוהו
                            let errorMsg = '<?php _e('Sync failed', 'at-bookings-api-fixes'); ?>';
                            let zohoMsg = '';
                            
                            if (response.data) {
                                if (typeof response.data === 'string') {
                                    errorMsg = response.data;
                                } else if (typeof response.data === 'object') {
                                    errorMsg = response.data.message || '<?php _e('Unknown error', 'at-bookings-api-fixes'); ?>';
                                    zohoMsg = response.data.zoho_message || '';
                                }
                            }
                            
                            console.log('❌ Sync failed:', errorMsg);
                            if (zohoMsg) console.log('Zoho message:', zohoMsg);
                            
                            // 📤 הצג alert פשוט
                            alert('❌ ' + errorMsg + (zohoMsg ? '\n\nZoho: ' + zohoMsg : ''));
                            
                            $btn.prop('disabled', false).html(originalHtml);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX error:', status, error);
                        
                        let errorMsg = status === 'timeout' 
                            ? '<?php _e('Request timeout - check server logs', 'at-bookings-api-fixes'); ?>'
                            : '<?php _e('Network error', 'at-bookings-api-fixes'); ?>';
                        
                        if (xhr.responseJSON && xhr.responseJSON.data) {
                            errorMsg = typeof xhr.responseJSON.data === 'string' 
                                ? xhr.responseJSON.data 
                                : xhr.responseJSON.data.message || errorMsg;
                        }
                        
                        alert('❌ ' + errorMsg);
                        $btn.prop('disabled', false).html(originalHtml);
                    }
                });
            });
            
            // Checkbox functionality for bulk sync
            let checkboxes = {};
            
            // Check/uncheck all
            $('#check-all-cycles').on('change', function() {
                const isChecked = $(this).prop('checked');
                $('.cycle-checkbox').prop('checked', isChecked).trigger('change');
            });
            
            // Individual checkboxes
            $(document).on('change', '.cycle-checkbox', function() {
                const tourId = $(this).data('tour-id');
                const isChecked = $(this).prop('checked');
                
                if (isChecked) {
                    checkboxes[tourId] = $(this).data('product-id');
                } else {
                    delete checkboxes[tourId];
                }
                
                updateBulkSyncUI();
            });
            
            function updateBulkSyncUI() {
                const count = Object.keys(checkboxes).length;
                $('#selected-count').text(count);
                
                if (count > 0) {
                    $('#bulk-sync-btn').prop('disabled', false);
                } else {
                    $('#bulk-sync-btn').prop('disabled', true);
                }
            }
            
            // Sync Selected button
            $('#bulk-sync-btn').on('click', function() {
                const selected = Object.keys(checkboxes);
                if (selected.length === 0) {
                    alert('<?php _e('Please select at least one cycle to sync.', 'at-bookings-api-fixes'); ?>');
                    return;
                }
                
                syncCycles(selected, 'selected');
            });
            
            // Sync All button
            $('#sync-all-btn').on('click', function() {
                const allTours = $('.cycle-checkbox').map(function() {
                    return $(this).data('tour-id');
                }).get();
                
                if (allTours.length === 0) {
                    alert('<?php _e('No cycles to sync.', 'at-bookings-api-fixes'); ?>');
                    return;
                }
                
                if (!confirm('<?php _e('Sync all', 'at-bookings-api-fixes'); ?> ' + allTours.length + ' <?php _e('cycles to Zoho?', 'at-bookings-api-fixes'); ?>')) {
                    return;
                }
                
                syncCycles(allTours, 'all');
            });
            
            function syncCycles(tourIds, mode) {
                const $btn = mode === 'selected' ? $('#bulk-sync-btn') : $('#sync-all-btn');
                const originalHtml = $btn.html();
                
                // בדיקה אילו cycles ניתן לסנכרן
                const syncableTours = [];
                const nonSyncableTours = [];
                
                tourIds.forEach(function(tourId) {
                    const $row = $('.cycle-checkbox[data-tour-id="' + tourId + '"]').closest('tr');
                    const $previewScript = $row.find('script[type="application/json"]');
                    
                    if ($previewScript.length) {
                        try {
                            const previewData = JSON.parse($previewScript.text());
                            if (previewData._can_sync === false) {
                                nonSyncableTours.push({
                                    tourId: tourId,
                                    warning: previewData._sync_warning || '<?php _e('Product not synced to Zoho', 'at-bookings-api-fixes'); ?>'
                                });
                            } else {
                                syncableTours.push(tourId);
                            }
                        } catch (e) {
                            console.error('Failed to parse preview for tour ' + tourId, e);
                            nonSyncableTours.push({
                                tourId: tourId,
                                warning: '<?php _e('Unable to verify sync status', 'at-bookings-api-fixes'); ?>'
                            });
                        }
                    } else {
                        nonSyncableTours.push({
                            tourId: tourId,
                            warning: '<?php _e('Preview data not found', 'at-bookings-api-fixes'); ?>'
                        });
                    }
                });
                
                // אם יש cycles שלא ניתן לסנכרן, הצג אזהרה
                if (nonSyncableTours.length > 0) {
                    let warningMsg = '<?php _e('The following cycles cannot be synced:', 'at-bookings-api-fixes'); ?>\n\n';
                    nonSyncableTours.forEach(function(item) {
                        warningMsg += '• ' + item.tourId + ': ' + item.warning + '\n';
                    });
                    
                    if (syncableTours.length > 0) {
                        warningMsg += '\n<?php _e('Continue syncing', 'at-bookings-api-fixes'); ?> ' + syncableTours.length + ' <?php _e('syncable cycles?', 'at-bookings-api-fixes'); ?>';
                        if (!confirm(warningMsg)) {
                            return;
                        }
                        // המשך רק עם ה-syncable ones
                        tourIds = syncableTours;
                    } else {
                        alert(warningMsg);
                        return;
                    }
                }
                
                if (tourIds.length === 0) {
                    alert('<?php _e('No cycles can be synced.', 'at-bookings-api-fixes'); ?>');
                    return;
                }
                
                $btn.prop('disabled', true).html('<span class="dashicons dashicons-update at-spin"></span> <?php _e('Syncing...', 'at-bookings-api-fixes'); ?>');
                
                // TODO: הוסף AJAX call לסנכרון מרובה cycles
                console.log('Syncing ' + mode + ':', tourIds);
                
                // כרגע - simulation
                setTimeout(function() {
                    alert('<?php _e('Sync functionality will be implemented.', 'at-bookings-api-fixes'); ?>\n\n<?php _e('Selected:', 'at-bookings-api-fixes'); ?> ' + tourIds.length + ' cycles');
                    $btn.prop('disabled', false).html(originalHtml);
                    
                    // Update UI - mark as synced
                    tourIds.forEach(function(tourId) {
                        $('.cycle-checkbox[data-tour-id="' + tourId + '"]').closest('tr').addClass('at-cycle-synced-row');
                    });
                }, 500);
            }
            
            // Table sorting functionality
            let currentSort = {
                column: null,
                direction: 'asc' // 'asc' or 'desc'
            };
            
            $('.sortable').on('click', function() {
                const $header = $(this);
                const sortType = $header.data('sort');
                const $tbody = $('tbody');
                // רק rows עם נתונים (יש להם data-datetime), לא ה-empty message
                const $rows = $tbody.find('tr[data-datetime]');
                
                if ($rows.length === 0) return;
                
                // קבע כיוון מיון
                if (currentSort.column === sortType) {
                    // אם כבר ממוין לפי העמודה הזו - הפוך כיוון
                    currentSort.direction = currentSort.direction === 'asc' ? 'desc' : 'asc';
                } else {
                    // עמודה חדשה - התחל מ-asc
                    currentSort.column = sortType;
                    currentSort.direction = 'asc';
                }
                
                // הסר כל ה-sort indicators
                $('.sort-indicator').removeClass('sort-asc sort-desc').html('');
                
                // הוסף indicator לעמודה הנוכחית
                const indicator = currentSort.direction === 'asc' ? '↑' : '↓';
                $header.find('.sort-indicator').addClass('sort-' + currentSort.direction).html(' ' + indicator);
                
                // מיין את ה-rows
                $rows.sort(function(a, b) {
                    const $a = $(a);
                    const $b = $(b);
                    let valA, valB;
                    
                    switch(sortType) {
                        case 'datetime':
                            // מיון לפי timestamp (מספר)
                            valA = parseInt($a.data('datetime')) || 0;
                            valB = parseInt($b.data('datetime')) || 0;
                            break;
                        case 'bookings':
                            // מיון לפי מספר בוקינגס
                            valA = parseInt($a.data('bookings')) || 0;
                            valB = parseInt($b.data('bookings')) || 0;
                            break;
                        case 'occupancy':
                            // מיון לפי מספר משתתפים
                            valA = parseInt($a.data('occupancy')) || 0;
                            valB = parseInt($b.data('occupancy')) || 0;
                            break;
                        default:
                            return 0;
                    }
                    
                    // השוואה
                    if (valA < valB) {
                        return currentSort.direction === 'asc' ? -1 : 1;
                    }
                    if (valA > valB) {
                        return currentSort.direction === 'asc' ? 1 : -1;
                    }
                    return 0;
                });
                
                // שמור את ה-empty message אם קיים
                const $emptyMessage = $tbody.find('tr:not([data-datetime])');
                
                // הוסף את ה-rows הממוינים חזרה לtbody
                $tbody.empty();
                if ($rows.length > 0) {
                    $tbody.append($rows);
                } else if ($emptyMessage.length > 0) {
                    $tbody.append($emptyMessage);
                }
            });
        });
        </script>
        
        <style>
        .at-slots-filters {
            background: white;
            padding: 20px;
            margin: 20px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .at-filter-row {
            display: flex;
            gap: 15px;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .at-filter-row label {
            font-weight: bold;
            margin: 0;
        }
        
        .at-filter-row input,
        .at-filter-row select {
            padding: 5px 8px;
            border: 1px solid #ddd;
            border-radius: 3px;
        }
        
        .at-slots-actions {
            margin: 20px 0;
        }
        
        .at-slots-actions .button {
            margin-right: 10px;
        }
        
        .at-slots-table-container {
            background: white;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .at-spin {
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        </style>
        
        <?php
        
        // Render footer
        if (class_exists('AT_Bookings_Dashboard')) {
            AT_Bookings_Dashboard::render_footer();
        }
    }
    
    /**
     * Render slots table
     */
    private static function render_slots_table($product_filter, $city_filter, $status_filter, $tour_id_filter, $date_from, $date_to) {
        // אם יש חיפוש לפי tour_id, השתמש בפונקציה ייעודית
        if ($tour_id_filter) {
            $slots = self::search_by_tour_id($tour_id_filter);
        } else {
            // אחרת, השתמש בפונקציה המרכזית at_get_future_tours_data
            if (!function_exists('at_get_future_tours_data')) {
                echo '<p>' . __('Future Tours function not available. Please ensure occupancy.php is loaded.', 'at-bookings-api-fixes') . '</p>';
                return;
            }
            
            // קבלת נתוני סיורים - כולל סיורים פתוחים ללא הזמנות
            $result = at_get_future_tours_data(
                $date_from,
                $date_to,
                $city_filter ?: null,
                $product_filter ?: null,
                true,  // include_past
                'all'  // mode - מציג כל הסיורים (עם ובלי הזמנות)
            );
            
            $slots = $result['data'] ?? [];
            
            // סינון לפי סטטוס אם נדרש
            if ($status_filter) {
                $slots = array_filter($slots, function($slot) use ($status_filter) {
                    $is_past = strtotime($slot['date']) < strtotime(date('Y-m-d'));
                    
                    if ($status_filter === 'active') {
                        return !$is_past && $slot['is_available'];
                    } elseif ($status_filter === 'full') {
                        return !$slot['is_available'] || $slot['bookings_count'] >= $slot['max_capacity'];
                    }
                    return true;
                });
            }
        }
        
        ?>
        <form id="slots-bulk-sync-form" method="post">
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th style="width: 40px;">
                        <input type="checkbox" id="check-all-cycles" title="<?php _e('Select all', 'at-bookings-api-fixes'); ?>">
                    </th>
                    <th><?php _e('Tour ID', 'at-bookings-api-fixes'); ?></th>
                    <th><?php _e('Product', 'at-bookings-api-fixes'); ?></th>
                    <th><?php _e('City', 'at-bookings-api-fixes'); ?></th>
                    <th class="sortable" data-sort="datetime" style="cursor: pointer;">
                        <?php _e('Date & Time', 'at-bookings-api-fixes'); ?>
                        <span class="sort-indicator"></span>
                    </th>
                    <th class="sortable" data-sort="bookings" style="cursor: pointer;">
                        <?php _e('Bookings', 'at-bookings-api-fixes'); ?>
                        <span class="sort-indicator"></span>
                    </th>
                    <th class="sortable" data-sort="occupancy" style="cursor: pointer;">
                        <?php _e('Occupancy', 'at-bookings-api-fixes'); ?>
                        <span class="sort-indicator"></span>
                    </th>
                    <th><?php _e('Status', 'at-bookings-api-fixes'); ?></th>
                    <th><?php _e('Actions', 'at-bookings-api-fixes'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($slots)): ?>
                <tr>
                    <td colspan="9" style="text-align: center; padding: 20px;">
                        <?php _e('No tours found with current filters.', 'at-bookings-api-fixes'); ?>
                        <br><small><?php _e('Try adjusting date range or removing filters.', 'at-bookings-api-fixes'); ?></small>
                        <?php if ($tour_id_filter): ?>
                        <br><br>
                        <strong><?php _e('Searched for Tour ID:', 'at-bookings-api-fixes'); ?> <code><?php echo esc_html($tour_id_filter); ?></code></strong>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php else: ?>
                <?php 
                $is_tour_id_search = !empty($tour_id_filter);
                foreach ($slots as $slot): 
                    $highlight = $is_tour_id_search ? 'background-color: #fff3cd;' : '';
                    
                    // חישוב timestamp למיון לפי תאריך ושעה
                    $datetime_str = $slot['date'] . ' ' . $slot['start_time'];
                    $datetime_timestamp = strtotime($datetime_str);
                    
                    // נתונים למיון
                    $bookings_count = (int)($slot['bookings_count'] ?? 0);
                    $booked_persons = (int)($slot['booked_persons'] ?? 0);
                ?>
                <tr style="<?php echo $highlight; ?>" 
                    data-datetime="<?php echo esc_attr($datetime_timestamp); ?>"
                    data-bookings="<?php echo esc_attr($bookings_count); ?>"
                    data-occupancy="<?php echo esc_attr($booked_persons); ?>">
                    <td style="text-align: center;">
                        <input type="checkbox" class="cycle-checkbox" data-tour-id="<?php echo esc_attr($slot['tour_id']); ?>" data-product-id="<?php echo esc_attr($slot['product_id']); ?>">
                    </td>
                    <td>
                        <code style="font-weight: <?php echo $is_tour_id_search ? 'bold' : 'normal'; ?>;">
                            <?php echo esc_html($slot['tour_id']); ?>
                        </code>
                    </td>
                    <td>
                        <strong><?php echo esc_html($slot['product_name'] ?: 'Unknown Product'); ?></strong>
                        <br><small>ID: <?php echo (int)$slot['product_id']; ?></small>
                    </td>
                    <td>
                        <?php if (!empty($slot['city'])): ?>
                            <span class="dashicons dashicons-location-alt"></span>
                            <?php echo esc_html($slot['city']); ?>
                        <?php else: ?>
                            <span style="color: #999;">—</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <strong><?php echo esc_html($slot['date']); ?></strong>
                        <br>
                        <small>
                            <?php echo esc_html($slot['start_time']); ?> - <?php echo esc_html($slot['end_time']); ?>
                        </small>
                    </td>
                    <td style="text-align: center;">
                        <?php if ($slot['bookings_count'] > 0): ?>
                            <strong style="color: #2271b1;"><?php echo (int)$slot['bookings_count']; ?></strong>
                        <?php else: ?>
                            <span style="color: #999;">0</span>
                        <?php endif; ?>
                    </td>
                    <td style="text-align: center;">
                        <strong><?php echo (int)$slot['booked_persons']; ?></strong>
                        /
                        <?php echo (int)$slot['max_capacity']; ?>
                        <br>
                        <small style="color: <?php echo $slot['is_available'] ? '#46b450' : '#dc3232'; ?>;">
                            <?php echo $slot['is_available'] ? __('Available', 'at-bookings-api-fixes') : __('Full', 'at-bookings-api-fixes'); ?>
                        </small>
                    </td>
                    <td>
                        <?php
                        // קביעת סטטוס על בסיס תפוסה ותאריך
                        $is_past = strtotime($slot['date']) < strtotime(date('Y-m-d'));
                        $is_full = !$slot['is_available'];
                        
                        if ($is_past) {
                            $status_text = __('Completed', 'at-bookings-api-fixes');
                            $status_class = 'completed';
                        } elseif ($is_full) {
                            $status_text = __('Full', 'at-bookings-api-fixes');
                            $status_class = 'full';
                        } else {
                            $status_text = __('Active', 'at-bookings-api-fixes');
                            $status_class = 'active';
                        }
                        ?>
                        <span class="at-status at-status-<?php echo esc_attr($status_class); ?>">
                            <?php echo esc_html($status_text); ?>
                        </span>
                    </td>
                    <td>
                        <?php
                        // בניית preview של האובייקט שיישלח ל-Zoho
                        $cycle_preview = self::build_cycle_preview($slot);
                        $preview_json = $cycle_preview ? json_encode($cycle_preview, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) : '{}';
                        $tour_id = $slot['tour_id'];
                        $unique_id = 'cycle-preview-' . md5($tour_id . microtime());
                        
                        // בדיקה אם ניתן לסנכרן (אם יש Product ID ב-Zoho)
                        $can_sync = isset($cycle_preview['_can_sync']) ? $cycle_preview['_can_sync'] : false;
                        $sync_warning = isset($cycle_preview['_sync_warning']) ? $cycle_preview['_sync_warning'] : '';
                        
                        // Get Zoho ID from cache/options (stored after successful sync)
                        // Format: at_zoho_cycle_ID_{tour_id_hash}
                        $cache_key = 'at_zoho_cycle_id_' . md5($tour_id);
                        $zoho_id = get_option($cache_key, '');
                        
                        // If not in cache, try to find in Zoho by Tour_SKU
                        if (empty($zoho_id) && class_exists('AT_Zoho_API')) {
                            $api = AT_Zoho_API::get_instance();
                            $search = $api->search_records('Cycles', 'Tour_SKU', $tour_id);
                            if (!empty($search['data']) && isset($search['data'][0]['id'])) {
                                $zoho_id = $search['data'][0]['id'];
                                // Cache it for next time
                                update_option($cache_key, $zoho_id, 'no');
                                write_detailed_log("Found Zoho ID in search for {$tour_id}: {$zoho_id}", 'DEBUG');
                            }
                        }
                        
                        // DEBUG: Log lookup
                        if (defined('WP_DEBUG') && WP_DEBUG && !empty($zoho_id)) {
                            write_detailed_log("Found Zoho ID for {$tour_id}: {$zoho_id}", 'DEBUG');
                        }
                        ?>
                        
                        <?php if ($zoho_id): ?>
                            <!-- Synced - Show Zoho ID with link -->
                            <div style="padding: 5px 10px; background: #d4edda; border: 1px solid #28a745; border-radius: 3px; display: inline-block;">
                                <span class="dashicons dashicons-yes-alt" style="color: #28a745; margin-right: 5px; vertical-align: middle;"></span>
                                <span style="color: #155724; font-weight: bold; font-size: 12px;">
                                    <?php _e('Synced', 'at-bookings-api-fixes'); ?>
                                </span>
                                <br>
                                <small style="color: #155724; word-break: break-all;">
                                    <code><?php echo esc_html(substr($zoho_id, 0, 16)); ?>...</code>
                                </small>
                            </div>
                        <?php elseif ($can_sync): ?>
                            <button type="button" class="button button-small sync-cycle has-tooltip" 
                                    data-tour-id="<?php echo esc_attr($tour_id); ?>"
                                    data-product-id="<?php echo esc_attr($slot['product_id']); ?>"
                                    data-preview-id="<?php echo esc_attr($unique_id); ?>"
                                    title="<?php _e('Click to sync. Hover to see data preview.', 'at-bookings-api-fixes'); ?>">
                                <span class="dashicons dashicons-cloud"></span>
                                <?php _e('Sync', 'at-bookings-api-fixes'); ?>
                            </button>
                        <?php else: ?>
                            <div class="at-sync-warning" style="padding: 5px 10px; background: #fff3cd; border: 1px solid #ffc107; border-radius: 3px; display: inline-block; max-width: 250px;">
                                <span class="dashicons dashicons-warning" style="color: #856404; margin-right: 5px; vertical-align: middle;"></span>
                                <small style="color: #856404; font-weight: bold;">
                                    <?php echo esc_html($sync_warning ?: __('Product not synced', 'at-bookings-api-fixes')); ?>
                                </small>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Store JSON data in script tag (not in attribute) -->
                        <script type="application/json" id="<?php echo esc_attr($unique_id); ?>">
<?php echo $preview_json; ?>
                        </script>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
        
        <!-- Bulk Actions -->
        <?php if (!empty($slots)): ?>
        <div id="bulk-sync-actions" style="margin-top: 20px; padding: 15px; background: #f5f5f5; border: 1px solid #ddd; border-radius: 4px;">
            <label>
                <strong><?php _e('Selected Cycles:', 'at-bookings-api-fixes'); ?></strong>
                <span id="selected-count" style="color: #2271b1; font-weight: bold;">0</span> / <?php echo count($slots); ?>
            </label>
            <br><br>
            <button type="button" id="bulk-sync-btn" class="button button-primary" disabled>
                <span class="dashicons dashicons-cloud-upload" style="margin-right: 5px;"></span>
                <?php _e('Sync Selected to Zoho', 'at-bookings-api-fixes'); ?>
            </button>
            <button type="button" id="sync-all-btn" class="button" style="background: #f0f0f0;">
                <span class="dashicons dashicons-update" style="margin-right: 5px;"></span>
                <?php _e('Sync All', 'at-bookings-api-fixes'); ?>
            </button>
        </div>
        <?php endif; ?>
        </form>
        
        <!-- Summary -->
        <div class="at-slots-summary">
            <h3><?php _e('Summary', 'at-bookings-api-fixes'); ?></h3>
            <?php
            $summary = self::get_slots_summary($product_filter, $city_filter, $status_filter, $date_from, $date_to);
            ?>
            <div class="at-summary-grid">
                <div class="at-summary-item">
                    <span class="at-summary-number"><?php echo $summary['total']; ?></span>
                    <span class="at-summary-label"><?php _e('Total Slots', 'at-bookings-api-fixes'); ?></span>
                </div>
                <div class="at-summary-item">
                    <span class="at-summary-number"><?php echo $summary['active']; ?></span>
                    <span class="at-summary-label"><?php _e('Active', 'at-bookings-api-fixes'); ?></span>
                </div>
                <div class="at-summary-item">
                    <span class="at-summary-number"><?php echo $summary['with_bookings']; ?></span>
                    <span class="at-summary-label"><?php _e('With Bookings', 'at-bookings-api-fixes'); ?></span>
                </div>
                <div class="at-summary-item">
                    <span class="at-summary-number"><?php echo $summary['synced']; ?></span>
                    <span class="at-summary-label"><?php _e('Synced to Zoho', 'at-bookings-api-fixes'); ?></span>
                </div>
            </div>
        </div>
        
        <style>
        .at-status {
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 12px;
            font-weight: bold;
        }
        
        .at-status-active {
            background: #d4edda;
            color: #155724;
        }
        
        .at-status-full {
            background: #fff3cd;
            color: #856404;
        }
        
        .at-status-closed {
            background: #f8d7da;
            color: #721c24;
        }
        
        .at-status-cancelled {
            background: #e2e3e5;
            color: #383d41;
        }
        
        .at-status-completed {
            background: #e2e3e5;
            color: #383d41;
        }
        
        .at-not-synced {
            color: #6c757d;
            font-style: italic;
        }
        
        /* Sortable table headers */
        .sortable {
            user-select: none;
            position: relative;
        }
        
        .sortable:hover {
            background-color: #f0f0f0;
        }
        
        .sort-indicator {
            display: inline-block;
            margin-left: 5px;
            color: #2271b1;
            font-weight: bold;
        }
        
        .sort-asc {
            color: #2271b1;
        }
        
        .sort-desc {
            color: #2271b1;
        }
        
        .at-cycle-tooltip {
            pointer-events: none;
            animation: fadeIn 0.2s ease-in;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .sync-cycle.has-tooltip {
            position: relative;
        }
        
        .sync-cycle.has-tooltip:hover {
            background-color: #2271b1;
            color: white;
            border-color: #2271b1;
        }
        
        .sync-cycle.has-tooltip .dashicons {
            transition: transform 0.3s ease;
        }
        
        .sync-cycle.has-tooltip:hover .dashicons {
            transform: scale(1.1);
        }
        
        /* Bulk sync styling */
        .at-cycle-synced-row {
            background-color: #d4edda !important;
            opacity: 0.7;
        }
        
        #bulk-sync-actions {
            display: flex;
            gap: 10px;
            align-items: center;
            flex-wrap: wrap;
        }
        
        #bulk-sync-btn:disabled,
        #bulk-sync-btn:disabled:hover {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        .at-spin {
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .at-summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        
        .at-summary-item {
            text-align: center;
            padding: 20px;
            background: white;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .at-summary-number {
            display: block;
            font-size: 24px;
            font-weight: bold;
            color: #0073aa;
        }
        
        .at-summary-label {
            display: block;
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }
        </style>
        
        <?php
    }
    
    /**
     * Search for tour by tour_id directly
     * Parses tour_id (product_id_timestamp) and finds the specific booking
     * 
     * @param string $tour_id_search Tour ID to search (full or partial)
     * @return array Array of tour data
     */
    private static function search_by_tour_id($tour_id_search) {
        global $wpdb;
        
        $results = [];
        
        // פענוח tour_id - פורמט: product_id_timestamp
        // תמיכה בחיפוש חלקי (רק product_id) או מלא
        $parts = explode('_', $tour_id_search);
        $product_id = isset($parts[0]) ? intval($parts[0]) : 0;
        $timestamp = isset($parts[1]) ? intval($parts[1]) : null;
        
        if (!$product_id) {
            return $results; // tour_id לא תקין
        }
        
        // חיפוש בוקינגים
        $query = "
            SELECT 
                p.ID as booking_id,
                pm_start.meta_value as start_date,
                pm_product.meta_value as product_id,
                pm_persons.meta_value as persons
            FROM {$wpdb->posts} p
            INNER JOIN {$wpdb->postmeta} pm_start ON p.ID = pm_start.post_id AND pm_start.meta_key = '_booking_start'
            INNER JOIN {$wpdb->postmeta} pm_product ON p.ID = pm_product.post_id AND pm_product.meta_key = '_booking_product_id'
            LEFT JOIN {$wpdb->postmeta} pm_persons ON p.ID = pm_persons.post_id AND pm_persons.meta_key = '_booking_persons'
            WHERE p.post_type = 'wc_booking'
            AND p.post_status NOT IN ('trash', 'cancelled')
            AND pm_product.meta_value = %d
        ";
        
        $query_params = [$product_id];
        
        // אם יש timestamp ספציפי, חפש רק אותו
        if ($timestamp) {
            // המרת timestamp לתאריכים אפשריים (תמיכה בפורמטים שונים)
            $date_str = date('Y-m-d H:i:s', $timestamp);
            $date_ymd_his = date('YmdHis', $timestamp);
            
            $query .= " AND (
                pm_start.meta_value = %s
                OR pm_start.meta_value = %s
                OR pm_start.meta_value = %d
            )";
            $query_params[] = $date_str;
            $query_params[] = $date_ymd_his;
            $query_params[] = $timestamp;
        }
        
        $query .= " ORDER BY pm_start.meta_value ASC";
        
        $bookings = $wpdb->get_results($wpdb->prepare($query, ...$query_params), ARRAY_A);
        
        if (empty($bookings)) {
            return $results;
        }
        
        // קיבוץ בוקינגים לפי tour_id
        $grouped_tours = [];
        
        foreach ($bookings as $booking_data) {
            $product = wc_get_product($product_id);
            
            if (!$product) {
                continue;
            }
            
            $product_name = $product->get_name();
            
            // פענוח תאריך ושעה
            $start_date_value = $booking_data['start_date'];
            if (is_numeric($start_date_value) && strlen($start_date_value) >= 14) {
                $block_date = substr($start_date_value, 0, 4) . '-' . substr($start_date_value, 4, 2) . '-' . substr($start_date_value, 6, 2);
                $block_time = substr($start_date_value, 8, 2) . ':' . substr($start_date_value, 10, 2) . ':00';
            } elseif (is_numeric($start_date_value) && strlen($start_date_value) <= 11) {
                $ts = intval($start_date_value);
                $block_date = date('Y-m-d', $ts);
                $block_time = date('H:i:s', $ts);
            } else {
                $ts = strtotime($start_date_value);
                $block_date = date('Y-m-d', $ts);
                $block_time = date('H:i:s', $ts);
            }
            
            // יצירת tour_id
            $datetime_utc = new DateTime($block_date . ' ' . $block_time, new DateTimeZone('UTC'));
            $calculated_tour_id = $product_id . '_' . $datetime_utc->getTimestamp();
            
            // בדיקת התאמה (אם חיפוש חלקי או מלא)
            if (stripos($calculated_tour_id, $tour_id_search) === false) {
                continue; // לא תואם לחיפוש
            }
            
            // אם המחזור עדיין לא קיים במערך, צור אותו
            if (!isset($grouped_tours[$calculated_tour_id])) {
                // קבלת עיר
                $city = '';
                $terms = wp_get_post_terms($product_id, 'pa_city', array('fields' => 'names'));
                if (!empty($terms)) {
                    $city = $terms[0];
                }
                
                // חישוב שעת סיום
                $duration_minutes = $product->get_duration() * ($product->get_duration_unit() === 'hour' ? 60 : 1);
                $slot_timestamp = strtotime($block_date . ' ' . $block_time);
                $end_timestamp = $slot_timestamp + ($duration_minutes * 60);
                $end_time = date('H:i:s', $end_timestamp);
                
                // קבלת max capacity
                $max_capacity = $product->get_max_persons() ?: 20;
                
                $grouped_tours[$calculated_tour_id] = [
                    'tour_id' => $calculated_tour_id,
                    'product_id' => $product_id,
                    'product_name' => $product_name,
                    'city' => $city,
                    'date' => $block_date,
                    'start_time' => $block_time,
                    'end_time' => $end_time,
                    'bookings_count' => 0,
                    'booked_persons' => 0,
                    'max_capacity' => $max_capacity,
                    'available' => 0,
                    'is_available' => true
                ];
            }
            
            // הוסף את הבוקינג למחזור
            $grouped_tours[$calculated_tour_id]['bookings_count']++;
            
            // ספירת משתתפים
            $persons_data = maybe_unserialize($booking_data['persons']);
            $booked_persons = 0;
            if (is_array($persons_data)) {
                $booked_persons = array_sum($persons_data);
            } elseif (is_numeric($booking_data['persons'])) {
                $booked_persons = intval($booking_data['persons']);
            }
            $booked_persons = max(1, $booked_persons);
            
            $grouped_tours[$calculated_tour_id]['booked_persons'] += $booked_persons;
        }
        
        // חישוב available ו-is_available
        foreach ($grouped_tours as $tour_id => $tour_data) {
            $grouped_tours[$tour_id]['available'] = max(0, $tour_data['max_capacity'] - $tour_data['booked_persons']);
            $grouped_tours[$tour_id]['is_available'] = ($tour_data['booked_persons'] < $tour_data['max_capacity']);
        }
        
        return array_values($grouped_tours);
    }
    
    /**
     * Build Zoho cycle object preview from tour data
     * Uses same mapper as Zoho Order Sync page
     * 
     * @param array $tour Tour data from at_get_future_tours_data
     * @return array Zoho cycle object ready for sync
     */
    private static function build_cycle_preview($tour) {
        if (!class_exists('AT_Zoho_Mapper')) {
            return null;
        }
        
        // קבלת המוצר
        $product = wc_get_product($tour['product_id']);
        if (!$product) {
            return null;
        }
        
        // בדיקה קריטית: האם המוצר מסונכרן ל-Zoho?
        // 1. בדוק את meta field ראשון
        $zoho_product_id = get_post_meta($product->get_id(), '_zoho_product_id', true);
        
        // 2. אם אין meta field, בדוק אם SKU (שהוא Zoho objectID) קיים בZoho
        $can_sync = !empty($zoho_product_id);
        if (!$can_sync) {
            $product_sku = $product->get_sku();
            if (!empty($product_sku)) {
                // המקט בוורדפרס הוא objectID של המוצר בZoho
                // אנחנו משתמשים בו כדי לוודא שהמוצר קיים בZoho
                // אנחנו לא חוזרים לחיפוש, פשוט משתמשים בו ישירות
                $zoho_product_id = $product_sku;
                $can_sync = true;
                
                // שמור את המטא-דאטה לעתיד
                update_post_meta($product->get_id(), '_zoho_product_id', $zoho_product_id);
            }
        }
        
        // המרת tour data לפורמט slot שמתאים ל-mapper
        // כל השדות שנדרשים לפי map_to_cycle()
        $slot_data = [
            'id' => null, // אין לנו booking_id ספציפי במצב זה
            'product_id' => $tour['product_id'],
            'slot_start' => $tour['date'] . ' ' . $tour['start_time'],
            'slot_end' => $tour['date'] . ' ' . $tour['end_time'],
            'status' => 'paid', // סטטוס ברירת מחדל לבוקינגים ששולמו
            'current_bookings' => $tour['bookings_count'],
            'booked_persons' => $tour['booked_persons'],
            'max_capacity' => $tour['max_capacity'],
            'tour_id' => $tour['tour_id'],
            'city' => $tour['city'],
        ];
        
        // שימוש ב-mapper המרכזי (בונה את האובייקט בדיוק כפי שיישלח ל-Zoho)
        // הוא משתמש בכל הנתונים שלעיל, כולל city ו-booked_persons/max_capacity לסטטוס
        $cycle_data = AT_Zoho_Mapper::map_to_cycle($slot_data, $product);
        
        // החזר רק את הנתונים שנשלחים ל-Zoho (בלי שדות עם _ שהם למידע בלבד בקצה הלקוח)
        // סינון כל השדות שמתחילים ב-underscore
        $filtered_data = array();
        foreach ($cycle_data as $key => $value) {
            if (strpos($key, '_') !== 0) {
                $filtered_data[$key] = $value;
            }
        }
        
        // הוסף מידע פנימי (לשימוש ב-JavaScript, לא נשלח ל-Zoho)
        $filtered_data['_can_sync'] = $can_sync;
        $filtered_data['_product_sku'] = $product->get_sku();
        if (!$can_sync) {
            $filtered_data['_sync_warning'] = sprintf(
                __('Product "%s" (SKU: %s) has not been synced to Zoho yet. Please sync the product first.', 'at-bookings-api-fixes'),
                $product->get_name(),
                $product->get_sku()
            );
        }
        
        return $filtered_data;
    }
    
    /**
     * Get slots summary statistics
     */
    private static function get_slots_summary($product_filter, $city_filter, $status_filter, $date_from, $date_to) {
        // שימוש באותו API כמו העמוד עצמו
        if (!function_exists('at_get_future_tours_data')) {
            return [
                'total' => 0,
                'active' => 0,
                'with_bookings' => 0,
                'synced' => 0
            ];
        }
        
        // קבלת כל הנתונים
        $result = at_get_future_tours_data(
            $date_from,
            $date_to,
            $city_filter ?: null,
            $product_filter ?: null,
            'all',
            true
        );
        
        $slots = $result['data'] ?? [];
        
        // חישוב סטטיסטיקות
        $total = count($slots);
        $active = 0;
        $with_bookings = 0;
        $synced = 0;
        
        foreach ($slots as $slot) {
            // ספירת active (עתידיים וזמינים)
            $is_past = strtotime($slot['date']) < strtotime(date('Y-m-d'));
            if (!$is_past && $slot['is_available']) {
                $active++;
            }
            
            // ספירת מחזורים עם הזמנות
            if ($slot['bookings_count'] > 0) {
                $with_bookings++;
            }
            
            // ספירת מחזורים שכבר סונכרנו לZoho
            $tour_id = $slot['tour_id'];
            $cache_key = 'at_zoho_cycle_id_' . md5($tour_id);
            $zoho_id = get_option($cache_key, '');
            if (!empty($zoho_id)) {
                $synced++;
            }
        }
        
        return [
            'total' => $total,
            'active' => $active,
            'with_bookings' => $with_bookings,
            'synced' => $synced
        ];
    }
    
    /**
     * AJAX handler to check if cycle exists in Zoho by CID_Website
     */
    public static function ajax_check_zoho_cycle() {
        // בדיקת security
        check_ajax_referer('at_slots_management_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $cid_website = isset($_POST['cid_website']) ? sanitize_text_field($_POST['cid_website']) : '';
        $tour_id = isset($_POST['tour_id']) ? sanitize_text_field($_POST['tour_id']) : '';
        
        if (!$cid_website || !$tour_id) {
            wp_send_json_error('Missing required parameters');
        }
        
        try {
            // חיפוש ב-Zoho לפי CID_Website (המזהה הייחודי)
            if (!class_exists('AT_Zoho_Core')) {
                wp_send_json_error('Zoho not configured');
            }
            
            $zoho = AT_Zoho_Core::instance();
            $search_result = $zoho->search_records('Cycles', 'CID_Website', $cid_website);
            
            if (!empty($search_result['data']) && isset($search_result['data'][0]['id'])) {
                // מצא את המחזור ב-Zoho
                $zoho_cycle_id = $search_result['data'][0]['id'];
                $zoho_cycle_url = 'https://' . get_option('at_zoho_domain', 'crm.zoho.com') . '/crm/org' . get_option('at_zoho_org_id', '') . '/tab/Cycles/' . $zoho_cycle_id;
                
                // שמור את ה-ID ב-meta (בדומה לבוקינגים)
                // כאן אנו לא יכולים לשמור ישירות בbooking, אז נשמור בoption זמני
                update_option('at_cycle_zoho_id_' . md5($cid_website), $zoho_cycle_id);
                
                wp_send_json_success([
                    'found' => true,
                    'zoho_id' => $zoho_cycle_id,
                    'zoho_url' => $zoho_cycle_url,
                    'message' => 'Cycle already exists in Zoho'
                ]);
            } else {
                wp_send_json_success([
                    'found' => false,
                    'message' => 'Cycle not found in Zoho'
                ]);
            }
        } catch (Exception $e) {
            wp_send_json_error('Error checking Zoho: ' . $e->getMessage());
        }
    }
}

// רישום ה-AJAX handler
add_action('wp_ajax_at_check_zoho_cycle', array('AT_Bookings_Slots_Management', 'ajax_check_zoho_cycle'));
