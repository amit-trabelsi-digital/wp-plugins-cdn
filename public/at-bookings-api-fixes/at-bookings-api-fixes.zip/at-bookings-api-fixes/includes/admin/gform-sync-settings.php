<?php
/**
 * Gravity Forms ↔ Zoho Sync Settings Page
 *
 * Admin UI to configure which Gravity Forms get synced to Zoho CRM and how
 * each form's fields map to Zoho fields. Settings are stored in a single
 * WordPress option ('at_gform_zoho_sync_settings') and merged into the
 * configuration via the existing `at_zoho_gform_config` filter declared in
 * includes/integrations/gravity-forms-sync.php.
 *
 * Default behavior: every active Gravity Form is synced (module: Contacts)
 * even if it has no per-form override. Admins can disable individual forms
 * or override module / field mappings here.
 *
 * @package AT_Bookings_API_Fixes
 * @since   4.2.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_GForm_Sync_Settings {

    const OPTION_KEY = 'at_gform_zoho_sync_settings';
    const NONCE_ACTION = 'at_gform_sync_settings_save';
    const PAGE_SLUG = 'at-gform-sync-settings';
    const MODULES_CACHE_KEY = 'at_zoho_modules_cache';
    const MODULES_CACHE_TTL = 12 * HOUR_IN_SECONDS;

    public static function init() {
        add_action('admin_post_at_gform_sync_save', array(__CLASS__, 'handle_save'));
        add_action('admin_post_at_gform_sync_save_org', array(__CLASS__, 'handle_save_org'));
        add_action('admin_post_at_gform_sync_refresh_modules', array(__CLASS__, 'handle_refresh_modules'));
        add_action('wp_ajax_at_gform_sync_get_fields', array(__CLASS__, 'ajax_get_module_fields'));
        add_filter('at_zoho_gform_config', array(__CLASS__, 'merge_settings_into_config'), 20, 1);
    }

    /**
     * Save the manually-entered Zoho Org ID. Empty value clears the override
     * and falls back to auto-discovery via /org.
     */
    public static function handle_save_org() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('אין לך הרשאות לבצע פעולה זו.', 'at-bookings-api-fixes'));
        }
        check_admin_referer('at_gform_sync_save_org', 'at_gform_sync_org_nonce');

        $raw = isset($_POST['at_zoho_org_id']) ? sanitize_text_field(wp_unslash($_POST['at_zoho_org_id'])) : '';
        // Strip optional "org" prefix and any non-digit characters
        $clean = preg_replace('/[^0-9]/', '', $raw);

        if ($clean === '') {
            delete_option('at_zoho_org_id');
        } else {
            update_option('at_zoho_org_id', $clean);
        }
        // Clear cache so the next lookup re-resolves
        delete_transient('at_zoho_org_id_cache');

        wp_safe_redirect(add_query_arg(
            array('page' => self::PAGE_SLUG, 'org_saved' => '1'),
            admin_url('admin.php')
        ));
        exit;
    }

    /**
     * Fetch the list of Zoho CRM modules available for sync (api_supported).
     *
     * Cached for 12 hours in a transient. Falls back to a minimal hard-coded
     * list (Contacts, Leads) if the Zoho API is unreachable or unconfigured.
     *
     * @param bool $force_refresh Bypass cache.
     * @return array<string, string> Map of api_name => plural_label
     */
    public static function get_zoho_modules($force_refresh = false) {
        if (!$force_refresh) {
            $cached = get_transient(self::MODULES_CACHE_KEY);
            if (is_array($cached) && !empty($cached)) {
                return $cached;
            }
        }

        $modules = array();
        if (class_exists('AT_Zoho_API') && class_exists('AT_Zoho_CRM') && AT_Zoho_CRM::is_configured()) {
            try {
                $api = AT_Zoho_API::get_instance();
                $raw = $api->get_modules();
                if (is_array($raw)) {
                    foreach ($raw as $module) {
                        if (empty($module['api_name'])) {
                            continue;
                        }
                        // Skip non-record modules (e.g. Activities is a wrapper)
                        if (!empty($module['generated_type']) && $module['generated_type'] === 'subform') {
                            continue;
                        }
                        $label = !empty($module['plural_label']) ? $module['plural_label'] : $module['api_name'];
                        $modules[$module['api_name']] = $label;
                    }
                }
            } catch (Exception $e) {
                if (function_exists('write_detailed_log')) {
                    write_detailed_log('[GForm Sync Settings] get_zoho_modules failed: ' . $e->getMessage(), 'WARNING');
                }
            }
        }

        // Fallback: always offer at least Contacts + Leads so the UI is useful
        // even before Zoho is connected.
        if (empty($modules)) {
            $modules = array(
                'Contacts' => __('Contacts (אנשי קשר)', 'at-bookings-api-fixes'),
                'Leads'    => __('Leads (לידים)', 'at-bookings-api-fixes'),
            );
        }

        // Sort by label for nicer UX
        asort($modules, SORT_NATURAL | SORT_FLAG_CASE);

        set_transient(self::MODULES_CACHE_KEY, $modules, self::MODULES_CACHE_TTL);
        return $modules;
    }

    /**
     * Clear the cached Zoho modules list.
     */
    public static function clear_modules_cache() {
        delete_transient(self::MODULES_CACHE_KEY);
    }

    /**
     * Get the writeable Zoho fields for a given module, as api_name => display label.
     *
     * Uses the existing AT_Zoho_Fields cache (15 min). Filters out fields that
     * can't be set via the API (read_only, audit timestamps, system fields).
     *
     * @param string $module Module api_name (e.g. "Contacts", "Leads")
     * @return array<string, string> api_name => "Label (api_name) [type]"
     */
    public static function get_zoho_fields_for_module($module) {
        $module = trim((string) $module);
        if ($module === '' || !class_exists('AT_Zoho_Fields')) {
            return array();
        }

        $raw = AT_Zoho_Fields::get_module_fields($module);
        if (empty($raw) || !is_array($raw)) {
            return array();
        }

        $writeable = array();
        foreach ($raw as $field) {
            if (empty($field['api_name'])) {
                continue;
            }
            // Skip non-writeable / system fields
            if (!empty($field['read_only'])) {
                continue;
            }
            if (isset($field['view_type']) && is_array($field['view_type']) && empty($field['view_type']['edit']) && empty($field['view_type']['create'])) {
                continue;
            }
            // Skip subform/multi-module helpers that don't accept simple values
            $type = isset($field['data_type']) ? $field['data_type'] : (isset($field['field_type']) ? $field['field_type'] : '');
            if (in_array($type, array('subform', 'multiuserlookup', 'multiselectlookup'), true)) {
                continue;
            }

            $label = !empty($field['field_label']) ? $field['field_label'] : (!empty($field['display_label']) ? $field['display_label'] : $field['api_name']);
            $mandatory = !empty($field['mandatory']);
            $api_name = $field['api_name'];

            $display = $label;
            if ($mandatory) {
                $display .= ' *';
            }
            $display .= ' — ' . $api_name;
            if ($type !== '') {
                $display .= ' [' . $type . ']';
            }
            $writeable[$api_name] = $display;
        }

        asort($writeable, SORT_NATURAL | SORT_FLAG_CASE);
        return $writeable;
    }

    /**
     * AJAX: return the fields list for a given module.
     * Used by the admin UI when the admin changes the module dropdown.
     */
    public static function ajax_get_module_fields() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Insufficient permissions', 'at-bookings-api-fixes')));
        }
        check_ajax_referer('at_gform_sync_fields', 'nonce');

        $module = isset($_POST['module']) ? sanitize_text_field(wp_unslash($_POST['module'])) : '';
        if ($module === '') {
            wp_send_json_error(array('message' => __('Module is required', 'at-bookings-api-fixes')));
        }

        $fields = self::get_zoho_fields_for_module($module);
        wp_send_json_success(array(
            'module' => $module,
            'fields' => $fields,
        ));
    }

    /**
     * Handle the "Refresh modules from Zoho" action.
     */
    public static function handle_refresh_modules() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('אין לך הרשאות לבצע פעולה זו.', 'at-bookings-api-fixes'));
        }
        check_admin_referer('at_gform_sync_refresh_modules', 'at_gform_sync_refresh_nonce');

        self::clear_modules_cache();
        self::get_zoho_modules(true);

        wp_safe_redirect(add_query_arg(
            array('page' => self::PAGE_SLUG, 'modules_refreshed' => '1'),
            admin_url('admin.php')
        ));
        exit;
    }

    /**
     * Hard-coded factory defaults — these mirror the original configuration
     * that was previously hard-coded inside at_get_zoho_gform_config() and
     * are used as the starting point on a fresh install (before any save).
     *
     * After the first save the user's saved option supersedes these values.
     *
     * @return array<int, array<string, mixed>>
     */
    public static function get_factory_defaults() {
        return array(
            // הצטרפות למועדון
            4 => array(
                'enabled'             => 1,
                'module'              => 'Contacts',
                'title'               => 'הצטרפות למועדון',
                'email_field_id'      => '',
                'first_name_field_id' => 1,
                'last_name_field_id'  => 14,
                'phone_field_id'      => '',
                'opt_in_field_id'     => 12,
                'notes_field_id'      => '',
            ),
            // דברו איתנו
            2 => array(
                'enabled'             => 1,
                'module'              => 'Leads',
                'title'               => 'דברו איתנו',
                'email_field_id'      => '',
                'first_name_field_id' => 1,
                'last_name_field_id'  => '',
                'phone_field_id'      => '',
                'opt_in_field_id'     => 12,
                'notes_field_id'      => '',
            ),
            // סיור פרטי
            3 => array(
                'enabled'             => 1,
                'module'              => 'Leads',
                'title'               => 'סיור פרטי',
                'email_field_id'      => '',
                'first_name_field_id' => 3,
                'last_name_field_id'  => '',
                'phone_field_id'      => '',
                'opt_in_field_id'     => 17,
                'notes_field_id'      => '',
            ),
            // הצטרפות לצוות ארטרנטיב
            1 => array(
                'enabled'             => 1,
                'module'              => 'Leads',
                'title'               => 'הצטרפות לצוות ארטרנטיב',
                'email_field_id'      => '',
                'first_name_field_id' => '',
                'last_name_field_id'  => '',
                'phone_field_id'      => '',
                'opt_in_field_id'     => '',
                'notes_field_id'      => '',
            ),
        );
    }

    /**
     * Get saved settings array.
     *
     * Structure:
     * [
     *   'forms' => [
     *      <form_id> => [
     *         'enabled'             => bool,
     *         'module'              => 'Contacts'|'Leads',
     *         'title'               => string,
     *         'email_field_id'      => int|string,
     *         'first_name_field_id' => int|string,
     *         'last_name_field_id'  => int|string,
     *         'phone_field_id'      => int|string,
     *         'opt_in_field_id'     => int|string,
     *         'notes_field_id'      => int|string,
     *      ],
     *   ],
     * ]
     *
     * @return array
     */
    public static function get_settings() {
        $settings = get_option(self::OPTION_KEY, false);

        // No option saved yet → seed from factory defaults so the existing
        // hard-coded form mappings (4, 2, 3, 1) appear pre-configured in the UI
        // and continue to behave exactly as before.
        if ($settings === false) {
            return array('forms' => self::get_factory_defaults());
        }

        if (!is_array($settings)) {
            $settings = array();
        }
        if (!isset($settings['forms']) || !is_array($settings['forms'])) {
            $settings['forms'] = array();
        }
        return $settings;
    }

    /**
     * Merge admin-configured settings into the runtime config used by
     * gravity-forms-sync.php. Disabled forms are removed; enabled forms
     * with overrides have their values applied on top of defaults.
     *
     * @param array $config Default config from at_get_zoho_gform_config()
     * @return array
     */
    public static function merge_settings_into_config($config) {
        $settings = self::get_settings();
        if (empty($settings['forms'])) {
            return $config;
        }

        foreach ($settings['forms'] as $form_id => $form_settings) {
            $form_id = (int) $form_id;
            if ($form_id <= 0) {
                continue;
            }

            $is_enabled = !empty($form_settings['enabled']);

            if (!$is_enabled) {
                // Disable sync for this form
                unset($config[$form_id]);
                continue;
            }

            // Make sure the form exists in the config (add it if missing)
            if (!isset($config[$form_id])) {
                $config[$form_id] = array();
            }

            // Module override — accept any non-empty api_name (validated on save).
            if (!empty($form_settings['module'])) {
                $config[$form_id]['module'] = $form_settings['module'];
            }

            // Title / source override
            if (!empty($form_settings['title'])) {
                $config[$form_id]['title'] = $form_settings['title'];
            }

            // Field mappings — only set if admin provided a value
            $field_map = array(
                'email_field_id'      => 'email_field_id',
                'phone_field_id'      => 'phone_field_id',
                'opt_in_field_id'     => 'opt_in_field_id',
                'notes_field_id'      => 'notes_field_id',
            );
            foreach ($field_map as $setting_key => $config_key) {
                if (isset($form_settings[$setting_key]) && $form_settings[$setting_key] !== '') {
                    $config[$form_id][$config_key] = $form_settings[$setting_key];
                }
            }

            // First / last name → composite full_name_field_id array
            $first_id = isset($form_settings['first_name_field_id']) ? $form_settings['first_name_field_id'] : '';
            $last_id  = isset($form_settings['last_name_field_id'])  ? $form_settings['last_name_field_id']  : '';
            if ($first_id !== '' || $last_id !== '') {
                $config[$form_id]['full_name_field_id'] = array(
                    'first' => $first_id !== '' ? $first_id : null,
                    'last'  => $last_id  !== '' ? $last_id  : null,
                );
            }

            // Explicit per-field mapping (GF field_id → Zoho api_name).
            // Consumed by at_extract_gform_contact_data() in gravity-forms-sync.php.
            if (!empty($form_settings['field_mapping']) && is_array($form_settings['field_mapping'])) {
                $config[$form_id]['field_mapping'] = $form_settings['field_mapping'];
            }
            // Independent list of GF field IDs included in the aggregated description.
            if (!empty($form_settings['aggregated_fields']) && is_array($form_settings['aggregated_fields'])) {
                $config[$form_id]['aggregated_fields'] = $form_settings['aggregated_fields'];
            }
            // Aggregation target field (default Description)
            if (!empty($form_settings['aggregate_target'])) {
                $config[$form_id]['aggregate_target'] = $form_settings['aggregate_target'];
            }
        }

        return $config;
    }

    /**
     * Render the admin page.
     */
    public static function render() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('אין לך הרשאות לגשת לעמוד זה.', 'at-bookings-api-fixes'));
        }

        if (!class_exists('GFAPI')) {
            echo '<div class="wrap"><h1>' . esc_html__('הגדרות סנכרון Gravity Forms ↔ Zoho', 'at-bookings-api-fixes') . '</h1>';
            echo '<div class="notice notice-error"><p>' . esc_html__('Gravity Forms לא מותקן או לא פעיל.', 'at-bookings-api-fixes') . '</p></div></div>';
            return;
        }

        $forms = GFAPI::get_forms(true, false); // active only
        $settings = self::get_settings();
        $forms_settings = isset($settings['forms']) ? $settings['forms'] : array();

        // Load full Zoho modules list (cached). Falls back to Contacts/Leads if Zoho not connected.
        $zoho_modules = self::get_zoho_modules();

        // Notices
        if (isset($_GET['updated']) && $_GET['updated'] === '1') {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('ההגדרות נשמרו בהצלחה.', 'at-bookings-api-fixes') . '</p></div>';
        }
        if (isset($_GET['modules_refreshed']) && $_GET['modules_refreshed'] === '1') {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('רשימת המודולים רועננה מ-Zoho.', 'at-bookings-api-fixes') . ' (' . count($zoho_modules) . ')</p></div>';
        }
        if (isset($_GET['org_saved']) && $_GET['org_saved'] === '1') {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Zoho Org ID נשמר.', 'at-bookings-api-fixes') . '</p></div>';
        }

        ?>
        <div class="wrap at-bookings-page" dir="rtl">
            <h1><?php esc_html_e('הגדרות סנכרון Gravity Forms ↔ Zoho CRM', 'at-bookings-api-fixes'); ?></h1>

            <div class="notice notice-info inline" style="margin: 15px 0;">
                <p>
                    <strong><?php esc_html_e('ברירת מחדל:', 'at-bookings-api-fixes'); ?></strong>
                    <?php esc_html_e('כל מילוי של כל טופס פעיל מסונכרן אוטומטית ל-Zoho. ניתן לכבות סנכרון לטופס ספציפי או לבחור מיפוי שדות מותאם למטה.', 'at-bookings-api-fixes'); ?>
                </p>
                <p>
                    <?php esc_html_e('אם לא נבחר שדה ספציפי — הקוד יזהה אוטומטית לפי תווית/סוג השדה (אימייל, שם פרטי, שם משפחה, טלפון, opt-in וכו׳).', 'at-bookings-api-fixes'); ?>
                </p>
            </div>

            <div style="margin: 10px 0 20px; display:flex; align-items:center; gap:12px; flex-wrap:wrap;">
                <span style="color:#50575e;">
                    <?php
                    printf(
                        /* translators: %d: number of Zoho modules */
                        esc_html__('נטענו %d מודולים מ-Zoho (cache 12 שעות).', 'at-bookings-api-fixes'),
                        count($zoho_modules)
                    );
                    ?>
                </span>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline;">
                    <input type="hidden" name="action" value="at_gform_sync_refresh_modules">
                    <?php wp_nonce_field('at_gform_sync_refresh_modules', 'at_gform_sync_refresh_nonce'); ?>
                    <button type="submit" class="button button-secondary">
                        <span class="dashicons dashicons-update" style="vertical-align:middle;"></span>
                        <?php esc_html_e('רענן רשימת מודולים מ-Zoho', 'at-bookings-api-fixes'); ?>
                    </button>
                </form>
            </div>

            <?php
            // Zoho Org ID config — used to build deep links to Zoho records
            $manual_org_id = get_option('at_zoho_org_id', '');
            $auto_org_id   = function_exists('at_get_zoho_org_id') ? at_get_zoho_org_id() : '';
            $zoho_domain   = get_option('at_zoho_domain', 'com');
            ?>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"
                  style="margin: 0 0 20px; padding:14px 18px; background:#fff; border:1px solid #c3c4c7; border-radius:4px; display:flex; align-items:center; gap:14px; flex-wrap:wrap;">
                <input type="hidden" name="action" value="at_gform_sync_save_org">
                <?php wp_nonce_field('at_gform_sync_save_org', 'at_gform_sync_org_nonce'); ?>

                <label style="display:flex; align-items:center; gap:8px;">
                    <strong><?php esc_html_e('Zoho Org ID:', 'at-bookings-api-fixes'); ?></strong>
                    <input type="text"
                           name="at_zoho_org_id"
                           value="<?php echo esc_attr($manual_org_id); ?>"
                           placeholder="<?php echo esc_attr($auto_org_id !== '' ? sprintf(__('זוהה אוטומטית: %s', 'at-bookings-api-fixes'), $auto_org_id) : __('למשל: 872898220', 'at-bookings-api-fixes')); ?>"
                           dir="ltr"
                           style="min-width:220px; font-family:monospace;">
                </label>

                <button type="submit" class="button button-secondary">
                    <?php esc_html_e('שמור Org ID', 'at-bookings-api-fixes'); ?>
                </button>

                <span class="description" style="color:#50575e;">
                    <?php
                    if ($auto_org_id !== '') {
                        printf(
                            /* translators: %s: org id */
                            esc_html__('זוהה אוטומטית מ-Zoho: %s — אפשר להשאיר ריק או לדרוס ידנית.', 'at-bookings-api-fixes'),
                            '<code dir="ltr">' . esc_html($auto_org_id) . '</code>'
                        );
                    } else {
                        esc_html_e('לא ניתן היה לזהות אוטומטית. הזן ידנית את ה-Org ID מ-Zoho (Setup → Company Settings → Company Details), כדי שהלינקים לרשומות יעבדו.', 'at-bookings-api-fixes');
                    }
                    ?>
                </span>
            </form>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="at_gform_sync_save">
                <?php wp_nonce_field(self::NONCE_ACTION, 'at_gform_sync_nonce'); ?>

                <?php if (empty($forms)) : ?>
                    <p><?php esc_html_e('אין טפסים פעילים ב-Gravity Forms.', 'at-bookings-api-fixes'); ?></p>
                <?php else : ?>
                    <?php foreach ($forms as $form) :
                        $form_id = (int) $form['id'];
                        $current = isset($forms_settings[$form_id]) ? $forms_settings[$form_id] : array();
                        // Default: enabled unless admin explicitly disabled it
                        $is_enabled = array_key_exists('enabled', $current) ? !empty($current['enabled']) : true;
                        $module     = !empty($current['module']) ? $current['module'] : 'Contacts';
                        $title      = isset($current['title']) ? $current['title'] : $form['title'];

                        $eligible_fields = self::get_eligible_fields($form);
                    ?>
                        <div class="at-gform-card" style="background:#fff; border:1px solid #c3c4c7; border-radius:4px; padding:18px 22px; margin:14px 0; box-shadow:0 1px 1px rgba(0,0,0,0.04);">
                            <h2 style="margin-top:0; display:flex; align-items:center; gap:10px;">
                                <label style="display:flex; align-items:center; gap:8px; cursor:pointer;">
                                    <input
                                        type="checkbox"
                                        name="forms[<?php echo esc_attr($form_id); ?>][enabled]"
                                        value="1"
                                        <?php checked($is_enabled); ?>
                                    >
                                    <span>
                                        <?php echo esc_html($form['title']); ?>
                                        <span style="color:#666; font-weight:normal;">(Form ID: <?php echo esc_html($form_id); ?>)</span>
                                    </span>
                                </label>
                            </h2>

                            <table class="form-table" role="presentation">
                                <tbody>
                                    <tr>
                                        <th scope="row"><label for="module_<?php echo esc_attr($form_id); ?>"><?php esc_html_e('מודול ב-Zoho', 'at-bookings-api-fixes'); ?></label></th>
                                        <td>
                                            <select id="module_<?php echo esc_attr($form_id); ?>" name="forms[<?php echo esc_attr($form_id); ?>][module]">
                                                <?php
                                                // Make sure the currently-saved module is always present in the
                                                // list, even if Zoho's API didn't return it (e.g. permissions issue).
                                                $modules_for_select = $zoho_modules;
                                                if (!empty($module) && !isset($modules_for_select[$module])) {
                                                    $modules_for_select[$module] = $module . ' ' . __('(לא זמין כרגע ב-API)', 'at-bookings-api-fixes');
                                                }
                                                foreach ($modules_for_select as $api_name => $label) :
                                                    $display = $label;
                                                    if ($api_name === 'Leads') {
                                                        $display .= ' — ' . __('יוצר גם Contact וגם Lead', 'at-bookings-api-fixes');
                                                    }
                                                ?>
                                                    <option value="<?php echo esc_attr($api_name); ?>" <?php selected($module, $api_name); ?>>
                                                        <?php echo esc_html($display); ?>
                                                        <?php if ($label !== $api_name) : ?>
                                                            <?php echo ' (' . esc_html($api_name) . ')'; ?>
                                                        <?php endif; ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                            <p class="description">
                                                <?php esc_html_e('בחר את המודול ב-Zoho אליו תועבר הרשומה. "Leads" יוצר גם Contact וגם Lead; שאר המודולים יוצרים רשומה במודול הנבחר.', 'at-bookings-api-fixes'); ?>
                                            </p>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th scope="row"><label for="title_<?php echo esc_attr($form_id); ?>"><?php esc_html_e('שם מקור (Source/Reffe)', 'at-bookings-api-fixes'); ?></label></th>
                                        <td>
                                            <input type="text" id="title_<?php echo esc_attr($form_id); ?>" name="forms[<?php echo esc_attr($form_id); ?>][title]" value="<?php echo esc_attr($title); ?>" class="regular-text" placeholder="<?php echo esc_attr($form['title']); ?>">
                                            <p class="description"><?php esc_html_e('הטקסט שיופיע ב-Zoho כשדה Lead Source / Reffe. אם נשאיר ריק — ייקח את שם הטופס.', 'at-bookings-api-fixes'); ?></p>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th scope="row" colspan="2" style="padding-bottom:6px;">
                                            <h3 style="margin:6px 0;"><?php esc_html_e('מיפוי שדות לזוהו', 'at-bookings-api-fixes'); ?></h3>
                                            <p class="description" style="font-weight:normal;">
                                                <?php esc_html_e('בחר לאיזה שדה ספציפי בזוהו מסונכרן כל שדה של הטופס. השאר ריק ("— לא מסונכרן —") כדי שהשדה לא יישלח לזוהו, או בחר ערך כדי לדחוף אותו לשדה הספציפי במודול הנבחר.', 'at-bookings-api-fixes'); ?>
                                            </p>
                                        </th>
                                    </tr>
                                </tbody>
                            </table>

                            <?php
                            // Per-form field mapping (GForm field → Zoho api_name)
                            $field_mapping = isset($current['field_mapping']) && is_array($current['field_mapping']) ? $current['field_mapping'] : array();
                            // Per-form aggregation target (default: Description)
                            $aggregate_target = !empty($current['aggregate_target']) ? $current['aggregate_target'] : 'Description';
                            // Per-form list of GF field IDs that join the aggregated description blob.
                            // Independent from $field_mapping — a field can be both mapped AND aggregated.
                            $aggregated_fields = isset($current['aggregated_fields']) && is_array($current['aggregated_fields']) ? array_map('strval', $current['aggregated_fields']) : array();
                            // Back-compat: legacy "__aggregate__" sentinel still works — treat it as both
                            // unmapped to target AND aggregated.
                            foreach ($field_mapping as $gf_id => $val) {
                                if ($val === '__aggregate__' && !in_array((string) $gf_id, $aggregated_fields, true)) {
                                    $aggregated_fields[] = (string) $gf_id;
                                }
                            }
                            // Zoho fields for the currently-selected module — used to populate the dropdowns
                            $zoho_fields_for_form = self::get_zoho_fields_for_module($module);
                            $zoho_fields_count = count($zoho_fields_for_form);
                            ?>

                            <p style="margin: 12px 0 4px;">
                                <label>
                                    <strong><?php esc_html_e('שדה יעד לאגרגציה:', 'at-bookings-api-fixes'); ?></strong>
                                    <select name="forms[<?php echo esc_attr($form_id); ?>][aggregate_target]"
                                            class="at-aggregate-target"
                                            data-saved="<?php echo esc_attr($aggregate_target); ?>"
                                            style="min-width:240px;">
                                        <?php
                                        $agg_options = $zoho_fields_for_form;
                                        if ($aggregate_target !== '' && !isset($agg_options[$aggregate_target])) {
                                            $agg_options[$aggregate_target] = $aggregate_target . ' ' . __('(לא נמצא ב-API)', 'at-bookings-api-fixes');
                                        }
                                        foreach ($agg_options as $api_name => $field_label) :
                                        ?>
                                            <option value="<?php echo esc_attr($api_name); ?>" <?php selected($aggregate_target, $api_name); ?>>
                                                <?php echo esc_html($field_label); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </label>
                                <span class="description"><?php esc_html_e('שדה ה-Zoho שיקבל את הטקסט המאוגד מכל השדות שסומנו "כלול בתיאור".', 'at-bookings-api-fixes'); ?></span>
                            </p>

                            <table class="widefat striped at-gform-fieldmap" data-form-id="<?php echo esc_attr($form_id); ?>" data-current-module="<?php echo esc_attr($module); ?>" style="margin-top:8px;">
                                <thead>
                                    <tr>
                                        <th style="width:45%;"><?php esc_html_e('שדה ב-Gravity Forms', 'at-bookings-api-fixes'); ?></th>
                                        <th style="width:40%;"><?php esc_html_e('שדה יעד ב-Zoho', 'at-bookings-api-fixes'); ?> <span class="at-fieldmap-status" style="font-weight:normal; color:#666;">(<?php echo esc_html($module); ?> — <?php echo (int) $zoho_fields_count; ?> <?php esc_html_e('שדות', 'at-bookings-api-fixes'); ?>)</span></th>
                                        <th style="width:15%;"><?php esc_html_e('כלול בתיאור', 'at-bookings-api-fixes'); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($eligible_fields)) : ?>
                                        <tr><td colspan="3"><?php esc_html_e('אין שדות הניתנים למיפוי בטופס.', 'at-bookings-api-fixes'); ?></td></tr>
                                    <?php else : ?>
                                        <?php foreach ($eligible_fields as $gf_field_id => $gf_field_label) :
                                            $saved_zoho_field = isset($field_mapping[$gf_field_id]) ? $field_mapping[$gf_field_id] : '';
                                            // Legacy "__aggregate__" sentinel meant aggregated-only; render as empty target
                                            if ($saved_zoho_field === '__aggregate__') {
                                                $saved_zoho_field = '';
                                            }
                                            $is_aggregated = in_array((string) $gf_field_id, $aggregated_fields, true);
                                            $select_value = $saved_zoho_field;
                                        ?>
                                            <tr>
                                                <td><?php echo esc_html($gf_field_label); ?></td>
                                                <td>
                                                    <select
                                                        name="forms[<?php echo esc_attr($form_id); ?>][field_mapping][<?php echo esc_attr($gf_field_id); ?>]"
                                                        class="at-fieldmap-zoho-select"
                                                        data-saved="<?php echo esc_attr($select_value); ?>"
                                                        style="width:100%; max-width:420px;"
                                                    >
                                                        <option value=""><?php esc_html_e('— לא מסונכרן —', 'at-bookings-api-fixes'); ?></option>
                                                        <?php
                                                        // If a saved value is no longer in the live list (renamed/removed
                                                        // in Zoho), still render it as an option so we don't silently lose it.
                                                        $options_to_render = $zoho_fields_for_form;
                                                        if ($select_value !== '' && !isset($options_to_render[$select_value])) {
                                                            $options_to_render[$select_value] = $select_value . ' ' . __('(לא נמצא ב-API)', 'at-bookings-api-fixes');
                                                        }
                                                        foreach ($options_to_render as $api_name => $field_label) :
                                                        ?>
                                                            <option value="<?php echo esc_attr($api_name); ?>" <?php selected($select_value, $api_name); ?>>
                                                                <?php echo esc_html($field_label); ?>
                                                            </option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </td>
                                                <td style="text-align:center;">
                                                    <label title="<?php esc_attr_e('כשמסומן: השדה כלול בטקסט המאוגד שנכנס לשדה היעד לאגרגציה (ברירת מחדל: Description). אם נבחר גם שדה יעד למעלה — הערך יישלח לשני המקומות.', 'at-bookings-api-fixes'); ?>">
                                                        <input
                                                            type="checkbox"
                                                            class="at-fieldmap-aggregate"
                                                            name="forms[<?php echo esc_attr($form_id); ?>][field_aggregate][<?php echo esc_attr($gf_field_id); ?>]"
                                                            value="1"
                                                            <?php checked($is_aggregated); ?>
                                                        >
                                                    </label>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                            <p class="description" style="margin-top:6px;">
                                <?php esc_html_e('סמן "כלול בתיאור" עבור שדות שאתה רוצה לרכז יחד לתוך שדה אחד ב-Zoho (כמו תיאור פנייה מורכבת). הפורמט יהיה "תווית: ערך" בשורה לכל שדה. שדה יכול להיות גם ממופה לשדה יעד ספציפי וגם כלול בתיאור — במקרה הזה הערך יישלח לשני המקומות.', 'at-bookings-api-fixes'); ?>
                            </p>
                        </div>
                    <?php endforeach; ?>

                    <p class="submit">
                        <button type="submit" class="button button-primary button-large">
                            <?php esc_html_e('שמור הגדרות', 'at-bookings-api-fixes'); ?>
                        </button>
                    </p>
                <?php endif; ?>
            </form>

            <div class="at-gform-help" style="margin-top:30px; padding:16px 20px; background:#f6f7f7; border-right:4px solid #2271b1; border-radius:3px;">
                <h3 style="margin-top:0;"><?php esc_html_e('💡 מידע שימושי', 'at-bookings-api-fixes'); ?></h3>
                <ul style="list-style:disc; padding-right:20px;">
                    <li><?php esc_html_e('כל הגשה של טופס שמוגדר כ-Enabled תסונכרן אוטומטית מיד.', 'at-bookings-api-fixes'); ?></li>
                    <li><?php esc_html_e('לסנכרון רטרואקטיבי של רשומות שלא סונכרנו — היכנס לרשימת ה-Entries של הטופס ב-Gravity Forms ובחר Bulk Action "סנכרן ל-Zoho CRM".', 'at-bookings-api-fixes'); ?></li>
                    <li><?php esc_html_e('כל ניסיון סנכרון (הצלחה/כשל) מתועד בלוגים תחת:', 'at-bookings-api-fixes'); ?>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=at-bookings-zoho-logs')); ?>"><?php esc_html_e('Zoho Sync Logs', 'at-bookings-api-fixes'); ?></a>.
                    </li>
                </ul>
            </div>
        </div>

        <script>
        (function() {
            var ajaxUrl  = <?php echo wp_json_encode(admin_url('admin-ajax.php')); ?>;
            var ajaxNonce = <?php echo wp_json_encode(wp_create_nonce('at_gform_sync_fields')); ?>;
            var i18n = {
                loading: <?php echo wp_json_encode(__('טוען שדות מ-Zoho…', 'at-bookings-api-fixes')); ?>,
                noFields: <?php echo wp_json_encode(__('לא נמצאו שדות זמינים במודול זה.', 'at-bookings-api-fixes')); ?>,
                error: <?php echo wp_json_encode(__('שגיאה בטעינת שדות.', 'at-bookings-api-fixes')); ?>,
                notMapped: <?php echo wp_json_encode(__('— לא מסונכרן —', 'at-bookings-api-fixes')); ?>,
                notFound: <?php echo wp_json_encode(__('(לא נמצא ב-API)', 'at-bookings-api-fixes')); ?>,
                fields: <?php echo wp_json_encode(__('שדות', 'at-bookings-api-fixes')); ?>
            };

            function findCard(moduleSelect) {
                return moduleSelect.closest('.at-gform-card');
            }

            function rebuildFieldMapDropdowns(card, module, zohoFields) {
                var table = card.querySelector('.at-gform-fieldmap');
                if (!table) return;

                var status = card.querySelector('.at-fieldmap-status');
                if (status) {
                    var count = Object.keys(zohoFields).length;
                    status.textContent = '(' + module + ' — ' + count + ' ' + i18n.fields + ')';
                }

                var selects = table.querySelectorAll('select.at-fieldmap-zoho-select');
                selects.forEach(function(select) {
                    var saved = select.getAttribute('data-saved') || select.value || '';
                    select.innerHTML = '';

                    var optEmpty = document.createElement('option');
                    optEmpty.value = '';
                    optEmpty.textContent = i18n.notMapped;
                    select.appendChild(optEmpty);

                    var hasSaved = false;
                    Object.keys(zohoFields).forEach(function(apiName) {
                        var opt = document.createElement('option');
                        opt.value = apiName;
                        opt.textContent = zohoFields[apiName];
                        if (apiName === saved) {
                            opt.selected = true;
                            hasSaved = true;
                        }
                        select.appendChild(opt);
                    });

                    // Preserve saved value if missing from new module's fields
                    if (saved && !hasSaved) {
                        var opt = document.createElement('option');
                        opt.value = saved;
                        opt.textContent = saved + ' ' + i18n.notFound;
                        opt.selected = true;
                        select.appendChild(opt);
                    }
                });
            }

            function showLoading(card) {
                var status = card.querySelector('.at-fieldmap-status');
                if (status) status.textContent = '(' + i18n.loading + ')';
            }

            function showError(card) {
                var status = card.querySelector('.at-fieldmap-status');
                if (status) status.textContent = '(' + i18n.error + ')';
            }

            function onModuleChange(e) {
                var select = e.target;
                if (!select || select.tagName !== 'SELECT') return;
                if (!select.id || select.id.indexOf('module_') !== 0) return;

                var card = findCard(select);
                if (!card) return;

                var newModule = select.value;
                if (!newModule) return;

                showLoading(card);

                var data = new FormData();
                data.append('action', 'at_gform_sync_get_fields');
                data.append('nonce', ajaxNonce);
                data.append('module', newModule);

                fetch(ajaxUrl, { method: 'POST', credentials: 'same-origin', body: data })
                    .then(function(r) { return r.json(); })
                    .then(function(json) {
                        if (json && json.success && json.data && json.data.fields) {
                            rebuildFieldMapDropdowns(card, newModule, json.data.fields);
                            card.querySelector('.at-gform-fieldmap').setAttribute('data-current-module', newModule);
                        } else {
                            showError(card);
                        }
                    })
                    .catch(function() { showError(card); });
            }

            document.addEventListener('change', onModuleChange);

            // "כלול בתיאור" is independent from the per-row Zoho-field target —
            // a field can be both mapped to a Zoho field AND included in the aggregated
            // description blob. No mutual exclusion.
        })();
        </script>
        <?php

        if (class_exists('AT_Bookings_Dashboard')) {
            AT_Bookings_Dashboard::render_footer();
        }
    }

    /**
     * Build a Field ID => Label list of the form's fields that make sense
     * to map to Zoho (skips layout-only fields).
     *
     * @param array $form Gravity Forms form object
     * @return array
     */
    private static function get_eligible_fields($form) {
        $eligible = array();
        if (empty($form['fields']) || !is_array($form['fields'])) {
            return $eligible;
        }

        $skip_types = array('html', 'section', 'page', 'captcha', 'fileupload');
        foreach ($form['fields'] as $field) {
            $type  = isset($field->type) ? $field->type : '';
            if (in_array($type, $skip_types, true)) {
                continue;
            }
            $id    = isset($field->id) ? $field->id : '';
            $label = isset($field->label) ? $field->label : '';
            if ($id === '' || $id === null) {
                continue;
            }
            $display = sprintf('#%s — %s [%s]', $id, $label !== '' ? $label : __('ללא שם', 'at-bookings-api-fixes'), $type);
            $eligible[$id] = $display;
        }
        return $eligible;
    }

    /**
     * Handle form submission (admin-post.php).
     */
    public static function handle_save() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('אין לך הרשאות לבצע פעולה זו.', 'at-bookings-api-fixes'));
        }

        check_admin_referer(self::NONCE_ACTION, 'at_gform_sync_nonce');

        $raw_forms = isset($_POST['forms']) && is_array($_POST['forms']) ? wp_unslash($_POST['forms']) : array();
        $clean_forms = array();

        foreach ($raw_forms as $form_id => $fields) {
            $form_id = (int) $form_id;
            if ($form_id <= 0) {
                continue;
            }

            // Module: accept any non-empty alphanumeric api_name (Zoho api_names
            // are alphanumeric + underscore). Fallback to Contacts on invalid input.
            $raw_module = isset($fields['module']) ? sanitize_text_field($fields['module']) : '';
            $module = preg_match('/^[A-Za-z0-9_]+$/', $raw_module) ? $raw_module : 'Contacts';

            // Build a clean GForm field_id → Zoho api_name mapping AND
            // a separate list of fields to include in the aggregated description.
            // These two are INDEPENDENT — a field can be in both, in either, or in neither.
            $field_mapping = array();
            if (isset($fields['field_mapping']) && is_array($fields['field_mapping'])) {
                foreach ($fields['field_mapping'] as $gf_field_id => $zoho_api_name) {
                    $gf_field_id   = sanitize_text_field((string) $gf_field_id);
                    $zoho_api_name = sanitize_text_field((string) $zoho_api_name);
                    if ($gf_field_id === '' || $zoho_api_name === '') {
                        continue;
                    }
                    // Zoho api_names: alphanumeric + underscore only
                    if (!preg_match('/^[A-Za-z0-9_]+$/', $zoho_api_name)) {
                        continue;
                    }
                    $field_mapping[$gf_field_id] = $zoho_api_name;
                }
            }

            $aggregated_fields = array();
            if (isset($fields['field_aggregate']) && is_array($fields['field_aggregate'])) {
                foreach ($fields['field_aggregate'] as $gf_field_id => $flag) {
                    if (!empty($flag)) {
                        $gf_field_id = sanitize_text_field((string) $gf_field_id);
                        if ($gf_field_id !== '') {
                            $aggregated_fields[] = $gf_field_id;
                        }
                    }
                }
                $aggregated_fields = array_values(array_unique($aggregated_fields));
            }

            // Target Zoho field that receives the aggregated description blob
            $aggregate_target_raw = isset($fields['aggregate_target']) ? sanitize_text_field($fields['aggregate_target']) : 'Description';
            $aggregate_target = preg_match('/^[A-Za-z0-9_]+$/', $aggregate_target_raw) ? $aggregate_target_raw : 'Description';

            $clean = array(
                'enabled'             => !empty($fields['enabled']) ? 1 : 0,
                'module'              => $module,
                'title'               => isset($fields['title']) ? sanitize_text_field($fields['title']) : '',
                // Legacy semantic mappings — kept for backward-compat with auto-detection,
                // but the new per-field mapping below takes precedence at sync time.
                'email_field_id'      => isset($fields['email_field_id']) ? sanitize_text_field($fields['email_field_id']) : '',
                'first_name_field_id' => isset($fields['first_name_field_id']) ? sanitize_text_field($fields['first_name_field_id']) : '',
                'last_name_field_id'  => isset($fields['last_name_field_id']) ? sanitize_text_field($fields['last_name_field_id']) : '',
                'phone_field_id'      => isset($fields['phone_field_id']) ? sanitize_text_field($fields['phone_field_id']) : '',
                'opt_in_field_id'     => isset($fields['opt_in_field_id']) ? sanitize_text_field($fields['opt_in_field_id']) : '',
                'notes_field_id'      => isset($fields['notes_field_id']) ? sanitize_text_field($fields['notes_field_id']) : '',
                // Explicit per-field mapping: GF field_id → Zoho api_name
                'field_mapping'       => $field_mapping,
                // List of GF field IDs to also include in the aggregated description blob.
                // Independent from field_mapping — both can apply to the same field.
                'aggregated_fields'   => $aggregated_fields,
                // Target Zoho field that receives the aggregated description blob
                'aggregate_target'    => $aggregate_target,
            );

            $clean_forms[$form_id] = $clean;
        }

        update_option(self::OPTION_KEY, array('forms' => $clean_forms));

        wp_safe_redirect(add_query_arg(
            array('page' => self::PAGE_SLUG, 'updated' => '1'),
            admin_url('admin.php')
        ));
        exit;
    }
}

AT_GForm_Sync_Settings::init();
