<?php
/**
 * Admin Menu Manager
 * 
 * Handles registration of admin menu and submenus
 *
 * @package AT_Bookings_API_Fixes
 * @version 2.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Menu Manager Class
 */
class AT_Bookings_Menu_Manager {
    
    private static $instance = null;
    private $menu_slug = 'at-bookings';
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('admin_menu', array($this, 'register_menus'), 9);
        add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));
    }
    
    /**
     * Register admin menus
     */
    public function register_menus() {
        // Main top-level menu
        add_menu_page(
            __('AT Bookings & CRM', 'at-bookings-api-fixes'),           // Page title
            __('AT Bookings', 'at-bookings-api-fixes'),                 // Menu title
            'manage_options',                                            // Capability
            $this->menu_slug,                                           // Menu slug
            array($this, 'render_dashboard'),                           // Callback
            $this->get_menu_icon(),                                     // Icon
            AT_BOOKINGS_MENU_POSITION                                   // Position (58 = above WooCommerce)
        );
        
        // Dashboard submenu (same as main menu)
        add_submenu_page(
            $this->menu_slug,
            __('Dashboard', 'at-bookings-api-fixes'),
            __('Dashboard', 'at-bookings-api-fixes'),
            'manage_options',
            $this->menu_slug,
            array($this, 'render_dashboard')
        );
        
        // Zoho Settings
        add_submenu_page(
            $this->menu_slug,
            __('Zoho CRM Settings', 'at-bookings-api-fixes'),
            __('Zoho Settings', 'at-bookings-api-fixes'),
            'manage_options',
            'at-bookings-zoho-settings',
            array($this, 'render_zoho_settings')
        );
        
        // Zoho Sync Logs
        add_submenu_page(
            $this->menu_slug,
            __('Zoho Sync Logs', 'at-bookings-api-fixes'),
            __('Sync Logs', 'at-bookings-api-fixes'),
            'manage_options',
            'at-bookings-zoho-logs',
            array($this, 'render_zoho_logs')
        );

        // Gravity Forms ↔ Zoho Sync Settings
        add_submenu_page(
            $this->menu_slug,
            __('Gravity Forms Sync', 'at-bookings-api-fixes'),
            __('GForm Sync Settings', 'at-bookings-api-fixes'),
            'manage_options',
            AT_GForm_Sync_Settings::PAGE_SLUG,
            array($this, 'render_gform_sync_settings')
        );
        
        // API Documentation & Settings (unified from API Docs + AT Bookings API)
        add_submenu_page(
            $this->menu_slug,
            __('API Documentation & Settings', 'at-bookings-api-fixes'),
            __('API Documentation', 'at-bookings-api-fixes'),
            'manage_options',
            'at-bookings-api-docs',
            array($this, 'render_api_docs_unified')
        );
        
        // Order/Booking Sync Tester (admin only)
        add_submenu_page(
            $this->menu_slug,
            __('Order/Booking Sync', 'at-bookings-api-fixes'),
            __('Order Sync', 'at-bookings-api-fixes'),
            'manage_woocommerce',
            'at-zoho-order-sync',
            array($this, 'render_order_sync')
        );
        
        // Initial Sync (new in v3.5.0)
        add_submenu_page(
            $this->menu_slug,
            __('Initial Sync', 'at-bookings-api-fixes'),
            __('Initial Sync', 'at-bookings-api-fixes'),
            'manage_options',
            'at-initial-sync',
            array($this, 'render_initial_sync')
        );
        
        // Cycle Management (open cycles + close for sale + daily auto-close)
        if (class_exists('AT_Cycle_Management')) {
            add_submenu_page(
                $this->menu_slug,
                __('Cycle Management', 'at-bookings-api-fixes'),
                __('ניהול מחזורים', 'at-bookings-api-fixes'),
                'manage_woocommerce',
                'at-cycle-management',
                array($this, 'render_cycle_management')
            );
        }

        // Slots Management
        add_submenu_page(
            $this->menu_slug,
            __('Slots Management', 'at-bookings-api-fixes'),
            __('Slots Management', 'at-bookings-api-fixes'),
            'manage_woocommerce',
            'at-slots-management',
            array($this, 'render_slots_management')
        );
        
        // Future Tours (moved from Tools menu)
        add_submenu_page(
            $this->menu_slug,
            __('Future Tours', 'at-bookings-api-fixes'),
            __('Future Tours', 'at-bookings-api-fixes'),
            'manage_options',
            'at-future-tours',
            array($this, 'render_future_tours')
        );
        
        // System Status
        add_submenu_page(
            $this->menu_slug,
            __('System Status', 'at-bookings-api-fixes'),
            __('System Status', 'at-bookings-api-fixes'),
            'manage_options',
            'at-bookings-system-status',
            array($this, 'render_system_status')
        );
    }
    
    /**
     * Get menu icon
     * 
     * @return string Icon URL or dashicon class
     */
    private function get_menu_icon() {
        // Using dashicons-update-alt for sync icon
        return 'dashicons-update-alt';
    }
    
    /**
     * Enqueue admin assets
     * 
     * @param string $hook Current admin page hook
     */
    public function enqueue_assets($hook) {
        // Load menu styles on ALL admin pages for consistent branding
        wp_enqueue_style(
            'at-bookings-admin-menu',
            AT_BOOKINGS_API_FIXES_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            AT_BOOKINGS_API_FIXES_VERSION
        );
        
        // RTL menu styles on ALL admin pages
        if (is_rtl()) {
            wp_enqueue_style(
                'at-bookings-admin-menu-rtl',
                AT_BOOKINGS_API_FIXES_PLUGIN_URL . 'assets/css/admin-rtl.css',
                array('at-bookings-admin-menu'),
                AT_BOOKINGS_API_FIXES_VERSION
            );
        }
        
        // Only load page-specific assets on our plugin pages
        if (strpos($hook, 'at-bookings') === false) {
            return;
        }
        
        // Admin dashboard script
        wp_enqueue_script(
            'at-bookings-admin',
            AT_BOOKINGS_API_FIXES_PLUGIN_URL . 'assets/js/admin-dashboard.js',
            array('jquery'),
            AT_BOOKINGS_API_FIXES_VERSION,
            true
        );
        
        // Initial Sync script (only on initial sync page)
        if (strpos($hook, 'at-initial-sync') !== false) {
            wp_enqueue_script(
                'at-initial-sync',
                AT_BOOKINGS_API_FIXES_PLUGIN_URL . 'assets/js/admin-initial-sync.js',
                array('jquery'),
                AT_BOOKINGS_API_FIXES_VERSION,
                true
            );
            
            wp_localize_script('at-initial-sync', 'atInitialSync', array(
                'ajaxurl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('at_bookings_dashboard'),
                'i18n' => array(
                    'startSync' => __('Start Sync', 'at-bookings-api-fixes'),
                    'stop' => __('Stop', 'at-bookings-api-fixes'),
                    'syncing' => __('Syncing...', 'at-bookings-api-fixes'),
                    'syncComplete' => __('Sync Complete', 'at-bookings-api-fixes'),
                    'syncStopped' => __('Sync Stopped', 'at-bookings-api-fixes'),
                    'success' => __('Success', 'at-bookings-api-fixes'),
                    'error' => __('Error', 'at-bookings-api-fixes'),
                    'processing' => __('Processing', 'at-bookings-api-fixes'),
                    'noMoreItems' => __('No more items to sync', 'at-bookings-api-fixes'),
                )
            ));
            
            wp_enqueue_style(
                'at-initial-sync',
                AT_BOOKINGS_API_FIXES_PLUGIN_URL . 'assets/css/admin-initial-sync.css',
                array(),
                AT_BOOKINGS_API_FIXES_VERSION
            );
        }
        
        // Order sync script (only on sync page)
        if (strpos($hook, 'at-zoho-order-sync') !== false) {
            wp_enqueue_script(
                'at-zoho-sync',
                AT_BOOKINGS_API_FIXES_PLUGIN_URL . 'assets/js/admin-zoho-sync.js',
                array('jquery'),
                AT_BOOKINGS_API_FIXES_VERSION,
                true
            );
            
            // Localize sync script
            wp_localize_script('at-zoho-sync', 'atZohoSync', array(
                'ajaxurl' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('at_zoho_sync'),
                'i18n' => array(
                    'loading' => __('Loading...', 'at-bookings-api-fixes'),
                    'syncing' => __('Syncing...', 'at-bookings-api-fixes'),
                    'enterOrderId' => __('Please enter an Order ID', 'at-bookings-api-fixes'),
                    'selectOrder' => __('Please select an order first', 'at-bookings-api-fixes'),
                    'missingParameters' => __('Missing required parameters', 'at-bookings-api-fixes'),
                    'syncStarted' => __('Sync started', 'at-bookings-api-fixes'),
                    'fullSyncStarted' => __('Full synchronization started', 'at-bookings-api-fixes'),
                    'fullSyncCompleted' => __('Full synchronization completed successfully', 'at-bookings-api-fixes'),
                    'syncStopped' => __('Synchronization stopped by user', 'at-bookings-api-fixes'),
                    'syncFailed' => __('Synchronization failed', 'at-bookings-api-fixes'),
                    'timelineEmpty' => __('No sync activity yet. Click "Run Full Sync" or individual entity buttons to start.', 'at-bookings-api-fixes'),
                    'allFieldsPresent' => __('All required fields present', 'at-bookings-api-fixes'),
                    'contact' => __('Contact', 'at-bookings-api-fixes'),
                    'product' => __('Product', 'at-bookings-api-fixes'),
                    'cycle' => __('Cycle', 'at-bookings-api-fixes'),
                    'order' => __('Order', 'at-bookings-api-fixes'),
                    'fullSync' => __('Full Sync', 'at-bookings-api-fixes'),
                    'step' => __('Step', 'at-bookings-api-fixes'),
                    'update' => __('Update', 'at-bookings-api-fixes'),
                    'error' => __('An error occurred', 'at-bookings-api-fixes'),
                    'searching' => __('Searching...', 'at-bookings-api-fixes')
                )
            ));
        }
        
        // Localize script with i18n and AJAX data
        wp_localize_script('at-bookings-admin', 'atBookings', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('at_bookings_dashboard'),
            'i18n' => array(
                'testing' => __('Testing connection...', 'at-bookings-api-fixes'),
                'testingConnection' => __('Testing Zoho connection...', 'at-bookings-api-fixes'),
                'connectionSuccess' => __('Connection successful!', 'at-bookings-api-fixes'),
                'connectionFailed' => __('Connection failed', 'at-bookings-api-fixes'),
                'refreshingToken' => __('Refreshing access token...', 'at-bookings-api-fixes'),
                'tokenRefreshed' => __('Token refreshed successfully', 'at-bookings-api-fixes'),
                'tokenRefreshFailed' => __('Token refresh failed', 'at-bookings-api-fixes'),
                'clearingCache' => __('Clearing cache...', 'at-bookings-api-fixes'),
                'cacheCleared' => __('Cache cleared successfully', 'at-bookings-api-fixes'),
                'error' => __('An error occurred', 'at-bookings-api-fixes'),
                'confirmTest' => __('Test Zoho connection now?', 'at-bookings-api-fixes'),
                'confirmRefresh' => __('Refresh access token now?', 'at-bookings-api-fixes'),
                'confirmClear' => __('Clear all cached data?', 'at-bookings-api-fixes'),
                'copied' => __('Copied!', 'at-bookings-api-fixes'),
                'productionWarning' => __('You are in a PRODUCTION environment. Testing this endpoint will affect live data. Continue?', 'at-bookings-api-fixes'),
                'endpointSuccess' => __('Success! Check console for response.', 'at-bookings-api-fixes'),
                'endpointError' => __('Error:', 'at-bookings-api-fixes'),
            )
        ));
    }
    
    /**
     * Render dashboard page
     */
    public function render_dashboard() {
        if (class_exists('AT_Bookings_Dashboard')) {
            AT_Bookings_Dashboard::render();
        } else {
            echo '<div class="wrap">';
            echo '<h1>' . esc_html__('Dashboard', 'at-bookings-api-fixes') . '</h1>';
            echo '<p>' . esc_html__('Dashboard is loading...', 'at-bookings-api-fixes') . '</p>';
            echo '</div>';
        }
    }
    
    /**
     * Render Zoho Settings page
     */
    public function render_zoho_settings() {
        if (class_exists('AT_Zoho_CRM')) {
            // Load the Zoho settings page - use NEW stepped interface
            $zoho_settings_file = AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/zoho/zoho-settings-new.php';
            if (file_exists($zoho_settings_file)) {
                include $zoho_settings_file;
                // Add footer after the settings page
                if (class_exists('AT_Bookings_Dashboard')) {
                    AT_Bookings_Dashboard::render_footer();
                }
            } else {
                // Fallback to old version if new one doesn't exist
                $old_settings_file = AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/zoho/zoho-settings.php';
                if (file_exists($old_settings_file)) {
                    include $old_settings_file;
                    // Add footer after the settings page
                    if (class_exists('AT_Bookings_Dashboard')) {
                        AT_Bookings_Dashboard::render_footer();
                    }
                }
            }
        } else {
            echo '<div class="wrap">';
            echo '<h1>' . esc_html__('Zoho CRM Settings', 'at-bookings-api-fixes') . '</h1>';
            echo '<div class="notice notice-error"><p>' . esc_html__('Zoho CRM module is not loaded.', 'at-bookings-api-fixes') . '</p></div>';
            echo '</div>';
        }
    }
    
    /**
     * Render Zoho Logs page
     */
    public function render_zoho_logs() {
        if (class_exists('AT_Zoho_Sync_Logs')) {
            // Call the logs_page method which prepares data and includes template
            $sync_logs = AT_Zoho_Sync_Logs::get_instance();
            $sync_logs->logs_page();
            
            // Add footer after the logs page
            if (class_exists('AT_Bookings_Dashboard')) {
                AT_Bookings_Dashboard::render_footer();
            }
        } else {
            echo '<div class="wrap">';
            echo '<h1>' . esc_html__('Zoho Sync Logs', 'at-bookings-api-fixes') . '</h1>';
            echo '<div class="notice notice-error"><p>' . esc_html__('Zoho Sync Logs module is not loaded.', 'at-bookings-api-fixes') . '</p></div>';
            echo '</div>';
        }
    }
    
    /**
     * Render Gravity Forms ↔ Zoho Sync Settings page
     */
    public function render_gform_sync_settings() {
        if (class_exists('AT_GForm_Sync_Settings')) {
            AT_GForm_Sync_Settings::render();
        } else {
            echo '<div class="wrap">';
            echo '<h1>' . esc_html__('Gravity Forms ↔ Zoho Sync', 'at-bookings-api-fixes') . '</h1>';
            echo '<div class="notice notice-error"><p>' . esc_html__('GForm Sync Settings module is not loaded.', 'at-bookings-api-fixes') . '</p></div>';
            echo '</div>';
        }
    }

    /**
     * Render API Documentation page
     */
    public function render_api_docs() {
        $environment = AT_Bookings_System_Checks::get_environment();
        $is_production = $environment['type'] === 'production';
        $zoho_status = AT_Bookings_System_Checks::get_zoho_status();
        $is_zoho_production = $zoho_status['environment'] === 'production';
        $api_key = get_option('at_bookings_api_key', '');
        
        echo '<div class="wrap at-bookings-page">';
        echo '<h1>' . esc_html__('API Documentation', 'at-bookings-api-fixes') . '</h1>';
        
        // Warning for production
        if ($is_production || $is_zoho_production) {
            echo '<div class="notice notice-warning at-production-warning">';
            echo '<p><strong>' . esc_html__('Production Environment Detected!', 'at-bookings-api-fixes') . '</strong></p>';
            echo '<p>' . esc_html__('You are in a production environment. Please be careful when testing API endpoints as they affect live data.', 'at-bookings-api-fixes') . '</p>';
            echo '</div>';
        }
        
        // API Overview
        echo '<div class="at-api-section">';
        echo '<h2>' . esc_html__('API Overview', 'at-bookings-api-fixes') . '</h2>';
        echo '<p>' . esc_html__('AT Bookings provides a comprehensive REST API for managing bookings, tours, and Zoho CRM integration.', 'at-bookings-api-fixes') . '</p>';
        
        echo '<div class="at-api-info-box">';
        echo '<h3>' . esc_html__('Quick Info', 'at-bookings-api-fixes') . '</h3>';
        echo '<table class="widefat">';
        echo '<tr><td><strong>' . esc_html__('Base URL:', 'at-bookings-api-fixes') . '</strong></td><td><code dir="ltr">' . esc_html(rest_url('at/v1')) . '</code></td></tr>';
        echo '<tr><td><strong>' . esc_html__('Authentication:', 'at-bookings-api-fixes') . '</strong></td><td>' . esc_html__('API Key (in URL parameters)', 'at-bookings-api-fixes') . '</td></tr>';
        echo '<tr><td><strong>' . esc_html__('Format:', 'at-bookings-api-fixes') . '</strong></td><td>JSON</td></tr>';
        echo '<tr><td><strong>' . esc_html__('Your API Key:', 'at-bookings-api-fixes') . '</strong></td>';
        echo '<td>';
        if ($api_key) {
            echo '<code class="at-api-key" dir="ltr">' . esc_html($api_key) . '</code> ';
            echo '<button type="button" class="button button-small at-copy-key" data-key="' . esc_attr($api_key) . '">' . esc_html__('Copy', 'at-bookings-api-fixes') . '</button>';
        } else {
            echo '<em>' . esc_html__('No API key configured', 'at-bookings-api-fixes') . '</em>';
        }
        echo '</td></tr>';
        echo '</table>';
        echo '</div>';
        echo '</div>';
        
        // Available Endpoints
        echo '<div class="at-api-section">';
        echo '<h2>' . esc_html__('Available Endpoints', 'at-bookings-api-fixes') . '</h2>';
        
        $endpoints = array(
            array(
                'method' => 'GET',
                'endpoint' => '/bookings/tours',
                'title' => __('Get All Tours', 'at-bookings-api-fixes'),
                'description' => __('Retrieve all tour slots with occupancy data', 'at-bookings-api-fixes'),
                'params' => array(
                    'api_key' => __('Required. Your API key', 'at-bookings-api-fixes'),
                    'start_date' => __('Optional. Start date (Y-m-d)', 'at-bookings-api-fixes'),
                    'end_date' => __('Optional. End date (Y-m-d)', 'at-bookings-api-fixes'),
                )
            ),
            array(
                'method' => 'GET',
                'endpoint' => '/product-slots',
                'title' => __('Get Product Slots', 'at-bookings-api-fixes'),
                'description' => __('Get available slots for a specific product', 'at-bookings-api-fixes'),
                'params' => array(
                    'api_key' => __('Required. Your API key', 'at-bookings-api-fixes'),
                    'product_id' => __('Required. Product ID', 'at-bookings-api-fixes'),
                    'start_date' => __('Optional. Start date', 'at-bookings-api-fixes'),
                    'end_date' => __('Optional. End date', 'at-bookings-api-fixes'),
                    'include_past' => __('Optional. Include past dates (true/false)', 'at-bookings-api-fixes'),
                )
            ),
            array(
                'method' => 'GET',
                'endpoint' => '/slot-details',
                'title' => __('Get Slot Details', 'at-bookings-api-fixes'),
                'description' => __('Get detailed information about a specific slot including all bookings', 'at-bookings-api-fixes'),
                'params' => array(
                    'api_key' => __('Required. Your API key', 'at-bookings-api-fixes'),
                    'product_id' => __('Required. Product ID', 'at-bookings-api-fixes'),
                    'date' => __('Required. Date (Y-m-d)', 'at-bookings-api-fixes'),
                    'time' => __('Required. Time (H:i:s)', 'at-bookings-api-fixes'),
                )
            ),
            array(
                'method' => 'GET',
                'endpoint' => '/all-slots',
                'title' => __('Get All Slots in Range', 'at-bookings-api-fixes'),
                'description' => __('Get all available slots within a date range', 'at-bookings-api-fixes'),
                'params' => array(
                    'api_key' => __('Required. Your API key', 'at-bookings-api-fixes'),
                    'start_date' => __('Required. Start date (Y-m-d)', 'at-bookings-api-fixes'),
                    'end_date' => __('Required. End date (Y-m-d)', 'at-bookings-api-fixes'),
                    'product_id' => __('Optional. Filter by product', 'at-bookings-api-fixes'),
                )
            ),
            [
                'method' => 'POST',
                'endpoint' => '/slots',
                'title' => __('Create Booking Slots', 'at-bookings-api-fixes'),
                'description' => __('Create a new single or recurring slot for a product.', 'at-bookings-api-fixes'),
                'params' => [
                    'product_id' => 'integer',
                    'type' => 'string ("single" or "recurring")',
                    'start_datetime' => 'ISO 8601 (for single, e.g., 2025-12-31T10:00:00)',
                    'start_date' => 'Y-m-d (for recurring)',
                    'end_date' => 'Y-m-d (for recurring)',
                    'days' => 'array of integers (0-6 for Sun-Sat, for recurring)',
                    'start_time' => 'H:i (for recurring)',
                    'end_time' => 'H:i (for recurring)',
                ]
            ],
            [
                'method' => 'PUT',
                'endpoint' => '/slots/change',
                'title' => __('Change Booking Slot', 'at-bookings-api-fixes'),
                'description' => __('Change the slot (date/time and product) for an existing booking.', 'at-bookings-api-fixes'),
                'params' => [
                    'booking_id' => __('Required. The booking ID to change', 'at-bookings-api-fixes'),
                    'new_product_id' => __('Required. The new product ID for the booking', 'at-bookings-api-fixes'),
                    'new_start_datetime' => __('Required. New start date and time (ISO 8601)', 'at-bookings-api-fixes'),
                ]
            ]
        );
        
        foreach ($endpoints as $endpoint) {
            echo '<div class="at-api-endpoint">';
            echo '<h3>';
            echo '<span class="at-method at-method-' . strtolower($endpoint['method']) . '">' . esc_html($endpoint['method']) . '</span> ';
            echo '<code dir="ltr">' . esc_html($endpoint['endpoint']) . '</code>';
            echo '</h3>';
            echo '<p class="at-endpoint-title"><strong>' . esc_html($endpoint['title']) . '</strong></p>';
            echo '<p>' . esc_html($endpoint['description']) . '</p>';
            
            if (!empty($endpoint['params'])) {
                echo '<h4>' . esc_html__('Parameters:', 'at-bookings-api-fixes') . '</h4>';
                echo '<ul class="at-params-list">';
                foreach ($endpoint['params'] as $param => $desc) {
                    echo '<li><code>' . esc_html($param) . '</code> - ' . esc_html($desc) . '</li>';
                }
                echo '</ul>';
            }
            
            // Try it button
            $example_url = rest_url('at/v1' . $endpoint['endpoint']) . '?api_key=' . urlencode($api_key);
            echo '<div class="at-try-it">';
            echo '<button type="button" class="button button-primary at-test-endpoint" ';
            echo 'data-endpoint="' . esc_attr($endpoint['endpoint']) . '" ';
            echo 'data-url="' . esc_url($example_url) . '" ';
            echo 'data-is-production="' . ($is_production || $is_zoho_production ? '1' : '0') . '">';
            echo '<span class="dashicons dashicons-controls-play"></span> ';
            echo esc_html__('Try This Endpoint', 'at-bookings-api-fixes');
            echo '</button>';
            echo '<span class="at-endpoint-result"></span>';
            echo '</div>';
            
            echo '</div>';
        }
        
        echo '</div>';
        
        // Full Documentation Link
        $api_doc_file = AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'API-DOCUMENTATION.md';
        if (file_exists($api_doc_file)) {
            echo '<div class="at-api-section at-full-docs">';
            echo '<h2>' . esc_html__('Complete Documentation', 'at-bookings-api-fixes') . '</h2>';
            echo '<p>' . esc_html__('For complete API documentation with examples, response formats, and error handling, see:', 'at-bookings-api-fixes') . '</p>';
            echo '<p><code>' . esc_html($api_doc_file) . '</code></p>';
            echo '</div>';
        }
        
        // Add footer
        if (class_exists('AT_Bookings_Dashboard')) {
            AT_Bookings_Dashboard::render_footer();
        }
        
        echo '</div>';
    }
    
    /**
     * Render System Status page
     */
    public function render_system_status() {
        echo '<div class="wrap at-bookings-page">';
        echo '<h1>' . esc_html__('System Status', 'at-bookings-api-fixes') . '</h1>';
        
        if (class_exists('AT_Bookings_System_Checks')) {
            $checks = AT_Bookings_System_Checks::check_requirements();
            $environment = AT_Bookings_System_Checks::get_environment();
            
            echo '<div class="at-system-status">';
            
            // Requirements table
            echo '<h2>' . esc_html__('System Requirements', 'at-bookings-api-fixes') . '</h2>';
            echo '<table class="widefat striped">';
            echo '<thead><tr>';
            echo '<th>' . esc_html__('Component', 'at-bookings-api-fixes') . '</th>';
            echo '<th>' . esc_html__('Required', 'at-bookings-api-fixes') . '</th>';
            echo '<th>' . esc_html__('Current', 'at-bookings-api-fixes') . '</th>';
            echo '<th>' . esc_html__('Status', 'at-bookings-api-fixes') . '</th>';
            echo '</tr></thead><tbody>';
            
            foreach ($checks as $check) {
                $status_icon = $check['status'] ? '✓' : '✗';
                $status_class = $check['status'] ? 'at-status-pass' : 'at-status-fail';
                echo '<tr>';
                echo '<td><strong>' . esc_html($check['label']) . '</strong></td>';
                echo '<td>' . esc_html($check['required']) . '</td>';
                echo '<td><code>' . esc_html($check['current']) . '</code></td>';
                echo '<td class="' . esc_attr($status_class) . '">' . esc_html($status_icon . ' ' . $check['message']) . '</td>';
                echo '</tr>';
            }
            
            echo '</tbody></table>';
            
            // Environment info
            echo '<h2>' . esc_html__('Environment Information', 'at-bookings-api-fixes') . '</h2>';
            echo '<table class="widefat striped">';
            echo '<tbody>';
            echo '<tr><td><strong>' . esc_html__('Environment Type', 'at-bookings-api-fixes') . '</strong></td><td>' . esc_html($environment['type_label']) . '</td></tr>';
            echo '<tr><td><strong>' . esc_html__('Site URL', 'at-bookings-api-fixes') . '</strong></td><td><code dir="ltr">' . esc_html($environment['url']) . '</code></td></tr>';
            echo '<tr><td><strong>' . esc_html__('Database Name', 'at-bookings-api-fixes') . '</strong></td><td><code>' . esc_html($environment['database']) . '</code></td></tr>';
            echo '<tr><td><strong>' . esc_html__('Debug Mode', 'at-bookings-api-fixes') . '</strong></td><td>' . ($environment['debug_mode'] ? esc_html__('Enabled', 'at-bookings-api-fixes') : esc_html__('Disabled', 'at-bookings-api-fixes')) . '</td></tr>';
            echo '<tr><td><strong>' . esc_html__('Multisite', 'at-bookings-api-fixes') . '</strong></td><td>' . ($environment['is_multisite'] ? esc_html__('Yes', 'at-bookings-api-fixes') : esc_html__('No', 'at-bookings-api-fixes')) . '</td></tr>';
            echo '</tbody></table>';
            
            echo '</div>';
        }
        
        // Add footer
        if (class_exists('AT_Bookings_Dashboard')) {
            AT_Bookings_Dashboard::render_footer();
        }
        
        echo '</div>';
    }
    
    /**
     * Render unified API Documentation & Settings page
     */
    public function render_api_docs_unified() {
        // Combine API settings and documentation in one page
        $api_key = get_option('at_bookings_api_key');
        if (empty($api_key)) {
            $api_key = wp_generate_password(32, false);
            update_option('at_bookings_api_key', $api_key);
        }
        
        $is_rtl = is_rtl();
        ?>
        <div class="wrap at-api-unified" style="direction: <?php echo $is_rtl ? 'rtl' : 'ltr'; ?>;">
            <h1><?php _e('API Documentation & Settings', 'at-bookings-api-fixes'); ?></h1>
            
            <!-- API Key Section -->
            <div class="at-api-section at-api-key-section">
                <h2><?php _e('API Key', 'at-bookings-api-fixes'); ?></h2>
                <p><?php _e('השתמש ב-API key הזה לבקשות API:', 'at-bookings-api-fixes'); ?></p>

                <div class="at-api-key-display">
                    <code id="at-api-key-value"><?php echo esc_html($api_key); ?></code>
                    <button type="button" id="copy-api-key" class="button" data-clipboard-text="<?php echo esc_attr($api_key); ?>">
                        <span class="dashicons dashicons-admin-page"></span>
                        <?php _e('העתק', 'at-bookings-api-fixes'); ?>
                    </button>
                </div>
            </div>
            
            <!-- Now include the original API documentation content -->
            <?php
            // Include the original render_api_docs content
            $this->render_api_docs();
            ?>
        </div>
        <?php
    }

    /**
     * Legacy API Settings (kept for compatibility)
     */
    public function render_api_settings() {
        // Include the original API settings content from occupancy.php
        $api_key = get_option('at_bookings_api_key');
        if (empty($api_key)) {
            $api_key = wp_generate_password(32, false);
            update_option('at_bookings_api_key', $api_key);
        }
        
        $site_url = site_url();
        $is_rtl = is_rtl();
        ?>
        <div class="wrap" style="direction: <?php echo $is_rtl ? 'rtl' : 'ltr'; ?>;">
            <h1><?php _e('AT Bookings API Settings', 'at-bookings-api-fixes'); ?></h1>

            <h2><?php _e('API Key', 'at-bookings-api-fixes'); ?></h2>
            <p><?php _e('השתמש ב-API key הזה לבקשות API:', 'at-bookings-api-fixes'); ?></p>

            <div style="background: #f1f1f1; padding: 15px; border-radius: 4px; margin: 10px 0;">
                <div style="display: flex; align-items: center; gap: 10px;">
                    <code style="flex: 1; font-family: monospace; background: transparent; padding: 0; border: none;">
                        <?php echo esc_html($api_key); ?>
                    </code>
                    <button type="button" id="copy-api-key" class="button" data-clipboard-text="<?php echo esc_attr($api_key); ?>">
                        📋 <?php _e('העתק', 'at-bookings-api-fixes'); ?>
                    </button>
                </div>
            </div>

            <h3><?php _e('דוגמאות שימוש - API Endpoints', 'at-bookings-api-fixes'); ?></h3>
            
            <div class="notice notice-info">
                <p><?php _e('For complete API documentation and testing, visit:', 'at-bookings-api-fixes'); ?> 
                <a href="<?php echo admin_url('admin.php?page=at-bookings-api-docs'); ?>"><?php _e('API Documentation', 'at-bookings-api-fixes'); ?></a></p>
            </div>

            <script>
            document.addEventListener('DOMContentLoaded', function() {
                const copyBtn = document.getElementById('copy-api-key');
                if (copyBtn) {
                    copyBtn.addEventListener('click', function() {
                        const text = this.getAttribute('data-clipboard-text');
                        navigator.clipboard.writeText(text).then(() => {
                            this.textContent = '✅ <?php _e('הועתק!', 'at-bookings-api-fixes'); ?>';
                            setTimeout(() => {
                                this.textContent = '📋 <?php _e('העתק', 'at-bookings-api-fixes'); ?>';
                            }, 2000);
                        });
                    });
                }
            });
            </script>
        </div>
        <?php
        
        // Render footer
        if (class_exists('AT_Bookings_Dashboard')) {
            AT_Bookings_Dashboard::render_footer();
        }
    }
    
    /**
     * Render Future Tours page (moved from Tools)
     */
    public function render_future_tours() {
        // Include the complete original Future Tours functionality
        ?>
        <div class="wrap" dir="ltr">
            <h1>Future Tours</h1>

            <div class="at-tours-container">
                <div class="at-tours-toolbar">
                    <div class="at-tours-filters">
                        <label for="date-range">Date Range:</label>
                        <input type="date" id="start-date" name="start_date" value="<?php echo date('Y-m-d'); ?>">
                        <span>to</span>
                        <input type="date" id="end-date" name="end_date" value="<?php echo date('Y-m-d', strtotime('+30 days')); ?>">

                        <label for="city-filter">City:</label>
                        <select id="city-filter">
                            <option value="">All Cities</option>
                            <!-- Will be populated dynamically -->
                        </select>

                        <label for="product-filter">Product:</label>
                        <select id="product-filter">
                            <option value="">All Products</option>
                            <!-- Will be populated dynamically -->
                        </select>

                        <label for="mode-filter">Show:</label>
                        <select id="mode-filter">
                            <option value="all">All Slots</option>
                            <option value="booked_only">With Bookings Only</option>
                            <option value="available_only">Available Only (No Bookings)</option>
                            <option value="past_booked">Past (With Bookings)</option>
                        </select>

                        <button id="refresh-tours" class="button">Refresh</button>
                    </div>
                </div>

                <div class="at-tours-table-container">
                    <table id="future-tours-table" class="display" style="width:100%">
                        <thead>
                            <tr>
                                <th>Tour ID</th>
                                <th>Product</th>
                                <th>City</th>
                                <th>Date & Time</th>
                                <th>Bookings</th>
                                <th>Occupancy</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </div>

            <!-- Modal for orders list -->
            <div id="orders-modal" class="at-modal">
                <div class="at-modal-content">
                    <div class="at-modal-header">
                        <h2>Tour Bookings List</h2>
                        <span class="at-modal-close">&times;</span>
                    </div>
                    <div class="at-modal-body">
                        <div id="orders-list">
                            <!-- Orders will be loaded here -->
                        </div>
                    </div>
                </div>
            </div>

            <style>
            .at-tours-container {
                margin-top: 20px;
            }

            .at-tours-toolbar {
                background: #fff;
                padding: 15px;
                border: 1px solid #ddd;
                border-radius: 4px;
                margin-bottom: 20px;
            }

            .at-tours-filters {
                display: flex;
                gap: 15px;
                align-items: center;
                flex-wrap: wrap;
            }

            .at-tours-filters label {
                font-weight: bold;
                margin-bottom: 0;
            }

            .at-tours-filters input[type="date"],
            .at-tours-filters select {
                padding: 5px 8px;
                border: 1px solid #ddd;
                border-radius: 3px;
            }

            .at-tours-table-container {
                background: #fff;
                padding: 15px;
                border: 1px solid #ddd;
                border-radius: 4px;
            }

            /* עיצוב טבלה */
            #future-tours-table {
                width: 100% !important;
                border-collapse: collapse;
            }

            #future-tours-table thead th {
                background: #f8f9fa !important;
                border-bottom: 2px solid #dee2e6 !important;
                font-weight: bold !important;
                color: #495057 !important;
                padding: 12px 8px !important;
                text-align: left !important;
            }

            #future-tours-table tbody tr:nth-child(even) {
                background-color: #f8f9fa !important;
            }

            #future-tours-table tbody tr:nth-child(odd) {
                background-color: #ffffff !important;
            }

            #future-tours-table tbody tr:hover {
                background-color: #e9ecef !important;
            }

            #future-tours-table tbody td {
                padding: 10px 8px !important;
                border-bottom: 1px solid #dee2e6 !important;
                text-align: left !important;
            }

            /* עיצוב לחיצה על מיון - תיקון */
            #future-tours-table thead th.sorting,
            #future-tours-table thead th.sorting_asc,
            #future-tours-table thead th.sorting_desc {
                cursor: pointer !important;
                position: relative !important;
                padding-left: 30px !important;
            }

            /* טבלה - הסרת ה-CSS של DataTables שגורם לעקומות */
            #future-tours-table.dataTable thead .sorting,
            #future-tours-table.dataTable thead .sorting_asc,
            #future-tours-table.dataTable thead .sorting_desc {
                background-image: none !important;
                background-repeat: no-repeat !important;
                background-position: center left !important;
            }

            #future-tours-table thead th.sorting:after,
            #future-tours-table thead th.sorting_asc:after,
            #future-tours-table thead th.sorting_desc:after {
                content: "" !important;
                position: absolute !important;
                width: 0 !important;
                height: 0 !important;
                left: 8px !important;
                top: 50% !important;
                transform: translateY(-50%) !important;
                border: 4px solid transparent !important;
                display: block !important;
            }

            #future-tours-table thead th.sorting:after {
                border-top-color: #999 !important;
                border-bottom-color: #999 !important;
                opacity: 0.5 !important;
            }

            #future-tours-table thead th.sorting_asc:after {
                border-bottom-color: #007cba !important;
                border-top: none !important;
            }

            #future-tours-table thead th.sorting_desc:after {
                border-top-color: #007cba !important;
                border-bottom: none !important;
            }

            .at-modal {
                display: none;
                position: fixed;
                z-index: 9999;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0,0,0,0.4);
            }

            .at-modal-content {
                background-color: #fefefe;
                margin: 5% auto;
                padding: 0;
                border: 1px solid #888;
                width: 80%;
                max-width: 800px;
                border-radius: 4px;
            }

            .at-modal-header {
                padding: 15px 20px;
                background: #f8f9fa;
                border-bottom: 1px solid #ddd;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }

            .at-modal-header h2 {
                margin: 0;
            }

            .at-modal-close {
                color: #aaa;
                font-size: 28px;
                font-weight: bold;
                cursor: pointer;
            }

            .at-modal-close:hover {
                color: black;
            }

            .at-modal-body {
                padding: 20px;
                max-height: 400px;
                overflow-y: auto;
            }

            .booking-item {
                padding: 10px;
                border: 1px solid #ddd;
                margin-bottom: 10px;
                border-radius: 4px;
            }

            .booking-item h4 {
                margin: 0 0 5px 0;
            }

            .booking-details {
                font-size: 12px;
                color: #666;
            }

            .clickable-count {
                cursor: pointer;
                color: #0073aa;
                text-decoration: underline;
            }

            .clickable-count:hover {
                color: #005177;
            }
            </style>

            <?php
            // הוספת סקריפטים וסגנונות לעמוד סיורים עתידיים
            wp_enqueue_style(
                'datatables-css',
                'https://cdn.datatables.net/1.13.7/css/dataTables.dataTables.min.css',
                array(),
                '1.13.7'
            );

            wp_enqueue_script(
                'datatables-js',
                'https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js',
                array('jquery'),
                '1.13.7',
                true
            );

            wp_enqueue_script(
                'at-future-tours-js',
                AT_BOOKINGS_API_FIXES_PLUGIN_URL . 'assets/js/at-future-tours.js',
                array('jquery', 'datatables-js'),
                AT_BOOKINGS_API_FIXES_VERSION,
                true
            );

            // העברת משתנים ל-JavaScript
            wp_localize_script('at-future-tours-js', 'at_tours_vars', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'site_url' => site_url(),
                'admin_url' => admin_url(),
                'nonce' => wp_create_nonce('at_future_tours_nonce')
            ));
            ?>
        </div>
        <?php
        
        // Render footer
        if (class_exists('AT_Bookings_Dashboard')) {
            AT_Bookings_Dashboard::render_footer();
        }
    }
    
    /**
     * Render Order/Booking Sync page
     */
    public function render_order_sync() {
        if (class_exists('AT_Zoho_Order_Sync_Page')) {
            AT_Zoho_Order_Sync_Page::render();
            // Footer is already rendered inside AT_Zoho_Order_Sync_Page::render()
        } else {
            echo '<div class="wrap">';
            echo '<h1>' . esc_html__('Order/Booking Sync', 'at-bookings-api-fixes') . '</h1>';
            echo '<div class="notice notice-error"><p>' . esc_html__('Order sync module is not loaded.', 'at-bookings-api-fixes') . '</p></div>';
            echo '</div>';
        }
    }
    
    /**
     * Render Initial Sync page
     */
    public function render_initial_sync() {
        if (class_exists('AT_Bookings_Initial_Sync')) {
            AT_Bookings_Initial_Sync::render();
            // Footer is already rendered inside AT_Bookings_Initial_Sync::render()
            if (class_exists('AT_Bookings_Dashboard')) {
                AT_Bookings_Dashboard::render_footer();
            }
        } else {
            echo '<div class="wrap">';
            echo '<h1>' . esc_html__('Initial Sync', 'at-bookings-api-fixes') . '</h1>';
            echo '<div class="notice notice-error"><p>' . esc_html__('Initial sync module is not loaded.', 'at-bookings-api-fixes') . '</p></div>';
            echo '</div>';
        }
    }
    
    /**
     * Render Cycle Management page
     */
    public function render_cycle_management() {
        if (class_exists('AT_Cycle_Management')) {
            AT_Cycle_Management::render();
            // Footer is rendered inside AT_Cycle_Management::render()
        } else {
            echo '<div class="wrap">';
            echo '<h1>' . esc_html__('Cycle Management', 'at-bookings-api-fixes') . '</h1>';
            echo '<div class="notice notice-error"><p>' . esc_html__('Cycle management module is not loaded.', 'at-bookings-api-fixes') . '</p></div>';
            echo '</div>';
        }
    }

    /**
     * Render Slots Management page
     */
    public function render_slots_management() {
        if (class_exists('AT_Bookings_Slots_Management')) {
            AT_Bookings_Slots_Management::render();
            // Footer is already rendered inside AT_Bookings_Slots_Management::render()
        } else {
            echo '<div class="wrap">';
            echo '<h1>' . esc_html__('Slots Management', 'at-bookings-api-fixes') . '</h1>';
            echo '<div class="notice notice-error"><p>' . esc_html__('Slots management module is not loaded.', 'at-bookings-api-fixes') . '</p></div>';
            echo '</div>';
        }
    }
}

// Initialize menu manager
AT_Bookings_Menu_Manager::get_instance();

