<?php
/**
 * Zoho Order Sync Admin Page
 * 
 * Admin interface for testing and managing order synchronization to Zoho CRM
 * 
 * @package AT_Bookings_API_Fixes
 * @subpackage Admin
 * @since 3.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Zoho_Order_Sync_Page {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // This class is loaded only when needed
    }
    
    /**
     * Render the main sync page
     */
    public static function render() {
        $is_rtl = is_rtl();
        $current_order_id = isset($_GET['order_id']) ? (int) $_GET['order_id'] : 0;
        
        ?>
        <div class="wrap at-sync-page" dir="<?php echo $is_rtl ? 'rtl' : 'ltr'; ?>">
            <h1><?php _e('Order/Booking Sync Tester', 'at-bookings-api-fixes'); ?></h1>
            
            <div class="notice notice-info">
                <p><?php _e('This page allows you to test Zoho synchronization for individual orders/bookings. Use it to verify sync logic before enabling automatic synchronization.', 'at-bookings-api-fixes'); ?></p>
            </div>
            
            <!-- Notices container for AJAX responses -->
            <div id="at-sync-notices" class="at-notices-container"></div>
            
            <!-- Collapsible field validation -->
            <div class="at-sync-section at-field-validation at-collapsible" id="at-field-validation">
                <div class="at-collapsible-header">
                    <h2 style="margin: 0; display: flex; align-items: center; gap: 8px;">
                        <span class="dashicons dashicons-arrow-down at-collapse-icon"></span>
                        <?php _e('Zoho Fields Validation', 'at-bookings-api-fixes'); ?>
                    </h2>
                </div>
                <div class="at-collapsible-content">
                    <p><?php _e('Checking required custom fields in Zoho modules:', 'at-bookings-api-fixes'); ?></p>
                    <div class="at-field-checks" id="at-field-checks">
                        <div class="at-loading"><?php _e('Loading field validation...', 'at-bookings-api-fixes'); ?></div>
                    </div>
                </div>
            </div>
            
            <?php self::render_order_selector($current_order_id); ?>
            
            <?php if ($current_order_id): ?>
                <div id="at-sync-content" class="at-sync-content">
                    <?php self::render_order_details($current_order_id); ?>
                    <?php self::render_sync_interface($current_order_id); ?>
                </div>
            <?php endif; ?>
        </div>
        
        <?php
        // Render footer
        if (class_exists('AT_Bookings_Dashboard')) {
            AT_Bookings_Dashboard::render_footer();
        }
    }
    
    /**
     * Render order selector
     */
    private static function render_order_selector($current_order_id) {
        ?>
        <div class="at-sync-section at-order-selector">
            <h2><?php _e('Select Order/Booking', 'at-bookings-api-fixes'); ?></h2>
            
            <div class="at-selector-controls">
                <label for="at-order-search">
                    <?php _e('Search by Order ID or Customer Name:', 'at-bookings-api-fixes'); ?>
                </label>
                <div class="at-search-container">
                    <input type="text" 
                           id="at-order-search" 
                           placeholder="<?php esc_attr_e('Enter Order ID or customer name...', 'at-bookings-api-fixes'); ?>"
                           value="<?php echo $current_order_id ? $current_order_id : ''; ?>">
                    <button type="button" id="at-load-order" class="button button-primary">
                        <?php _e('Load Order', 'at-bookings-api-fixes'); ?>
                    </button>
                </div>
            </div>
            
            <?php if ($current_order_id): ?>
            <div class="at-current-order">
                <?php
                $order = wc_get_order($current_order_id);
                if ($order):
                ?>
                <h3><?php printf(__('Current Order: #%d', 'at-bookings-api-fixes'), $current_order_id); ?></h3>
                <div class="at-order-details">
                    <span class="at-order-customer"><?php echo esc_html($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()); ?></span>
                    <span class="at-order-status at-status-<?php echo esc_attr($order->get_status()); ?>">
                        <?php echo esc_html(wc_get_order_status_name($order->get_status())); ?>
                    </span>
                    <span class="at-order-total"><?php echo wc_price($order->get_total()); ?></span>
                    <span class="at-order-date"><?php echo esc_html($order->get_date_created()->format('d/m/Y H:i')); ?></span>
                </div>
                <?php else: ?>
                <div class="notice notice-error">
                    <p><?php printf(__('Order #%d not found.', 'at-bookings-api-fixes'), $current_order_id); ?></p>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php
    }
    
    /**
     * Render detailed order information
     */
    private static function render_order_details($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }
        
        $booking_id = AT_Zoho_Mapper::get_booking_id_from_order($order);
        
        ?>
        <div class="at-sync-section at-order-information">
            <h2><?php _e('Order Information', 'at-bookings-api-fixes'); ?></h2>
            
            <div class="at-info-grid">
                <div class="at-info-item">
                    <strong><?php _e('Order ID:', 'at-bookings-api-fixes'); ?></strong>
                    <span><?php echo esc_html('#' . $order->get_id()); ?></span>
                </div>
                
                <div class="at-info-item">
                    <strong><?php _e('Booking ID (BID):', 'at-bookings-api-fixes'); ?></strong>
                    <span><?php echo esc_html($booking_id ?: __('Not found', 'at-bookings-api-fixes')); ?></span>
                </div>
                
                <div class="at-info-item">
                    <strong><?php _e('Order Date:', 'at-bookings-api-fixes'); ?></strong>
                    <span><?php echo esc_html($order->get_date_created()->format(get_option('date_format') . ' ' . get_option('time_format'))); ?></span>
                </div>
                
                <div class="at-info-item">
                    <strong><?php _e('Current Status:', 'at-bookings-api-fixes'); ?></strong>
                    <span class="at-status-badge at-status-<?php echo esc_attr($order->get_status()); ?>">
                        <?php echo esc_html(wc_get_order_status_name($order->get_status())); ?>
                    </span>
                </div>
                
                <div class="at-info-item">
                    <strong><?php _e('Payment Status:', 'at-bookings-api-fixes'); ?></strong>
                    <span class="at-status-badge <?php echo $order->is_paid() ? 'at-status-paid' : 'at-status-pending'; ?>">
                        <?php echo $order->is_paid() ? __('Paid', 'at-bookings-api-fixes') : __('Pending', 'at-bookings-api-fixes'); ?>
                    </span>
                </div>
                
                <div class="at-info-item">
                    <strong><?php _e('Payment Date:', 'at-bookings-api-fixes'); ?></strong>
                    <span>
                        <?php 
                        if ($order->is_paid() && $order->get_date_paid()) {
                            echo esc_html($order->get_date_paid()->format(get_option('date_format') . ' ' . get_option('time_format')));
                        } else {
                            _e('Not paid', 'at-bookings-api-fixes');
                        }
                        ?>
                    </span>
                </div>
                
                <div class="at-info-item">
                    <strong><?php _e('Transaction ID:', 'at-bookings-api-fixes'); ?></strong>
                    <span><?php 
                        $transaction_id = $order->get_transaction_id();
                        if (!$transaction_id) {
                            $yaad_payment = get_post_meta($order->get_id(), 'yaad_credit_card_payment', true);
                            if ($yaad_payment && preg_match('/Id=(\d+)/', $yaad_payment, $matches)) {
                                $transaction_id = $matches[1];
                            }
                        }
                        echo esc_html($transaction_id ?: __('N/A', 'at-bookings-api-fixes'));
                    ?></span>
                </div>
                
                <div class="at-info-item">
                    <strong><?php _e('Customer:', 'at-bookings-api-fixes'); ?></strong>
                    <span><?php echo esc_html($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()); ?></span>
                </div>
                
                <div class="at-info-item">
                    <strong><?php _e('Email:', 'at-bookings-api-fixes'); ?></strong>
                    <span><?php echo esc_html($order->get_billing_email()); ?></span>
                </div>
                
                <div class="at-info-item">
                    <strong><?php _e('Phone:', 'at-bookings-api-fixes'); ?></strong>
                    <span><?php echo esc_html($order->get_billing_phone() ?: __('N/A', 'at-bookings-api-fixes')); ?></span>
                </div>
            </div>
            
            <!-- Order Items -->
            <div class="at-order-items">
                <h3><?php _e('Order Items', 'at-bookings-api-fixes'); ?></h3>
                <table class="widefat striped">
                    <thead>
                        <tr>
                            <th><?php _e('Product', 'at-bookings-api-fixes'); ?></th>
                            <th><?php _e('Type', 'at-bookings-api-fixes'); ?></th>
                            <th style="text-align: center;"><?php _e('Qty', 'at-bookings-api-fixes'); ?></th>
                            <th style="text-align: right;"><?php _e('Price', 'at-bookings-api-fixes'); ?></th>
                            <th style="text-align: right;"><?php _e('Total', 'at-bookings-api-fixes'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($order->get_items() as $item) {
                            $product = $item->get_product();
                            $person_type = $item->get_meta('_person_type');
                            ?>
                            <tr>
                                <td>
                                    <strong><?php echo esc_html($item->get_name()); ?></strong>
                                </td>
                                <td>
                                    <?php
                                    // Get ticket types directly from booking
                                    $ticket_types = __('Standard', 'at-bookings-api-fixes');
                                    $booking_id = $item->get_meta('_booking_id');
                                    if ($booking_id && is_array($booking_id)) {
                                        $booking_id = reset($booking_id);
                                    }
                                    
                                    if ($booking_id) {
                                        // Get person types directly from post meta
                                        $booking_persons = get_post_meta($booking_id, '_booking_persons', true);
                                        
                                        // Get person type IDs to names mapping
                                        if (is_array($booking_persons) && !empty($booking_persons)) {
                                            $types_arr = [];
                                            foreach ($booking_persons as $person_type_id => $count) {
                                                if ((int)$count > 0) {
                                                    // Get person type name
                                                    $person_type = get_post($person_type_id);
                                                    if ($person_type) {
                                                        $types_arr[] = esc_html($person_type->post_title) . ' (' . $count . ')';
                                                    }
                                                }
                                            }
                                            if (!empty($types_arr)) {
                                                $ticket_types = implode(', ', $types_arr);
                                            }
                                        }
                                    }
                                    
                                    echo $ticket_types;
                                    ?>
                                </td>
                                <td style="text-align: center;">
                                    <?php
                                    // Calculate total ticket count from booking tickets
                                    $total_tickets = 0;
                                    $booking_id = $item->get_meta('_booking_id');
                                    if ($booking_id && is_array($booking_id)) {
                                        $booking_id = reset($booking_id);
                                    }
                                    
                                    if ($booking_id) {
                                        // Try to get tickets from booking meta
                                        $booking = get_post($booking_id);
                                        if ($booking) {
                                            $booking_persons = get_post_meta($booking_id, '_booking_persons', true);
                                            if (is_array($booking_persons)) {
                                                foreach ($booking_persons as $count) {
                                                    $total_tickets += (int) $count;
                                                }
                                            }
                                        }
                                    }
                                    
                                    echo ($total_tickets > 0) ? $total_tickets : (int) $item->get_quantity();
                                    ?>
                                </td>
                                <td style="text-align: right;">
                                    <?php
                                    // Get weighted average unit price from booking cost and persons
                                    $unit_price = $item->get_subtotal() / $item->get_quantity();
                                    $booking_id = $item->get_meta('_booking_id');
                                    if ($booking_id && is_array($booking_id)) {
                                        $booking_id = reset($booking_id);
                                    }
                                    
                                    if ($booking_id) {
                                        $booking_cost = (float)get_post_meta($booking_id, '_booking_cost', true);
                                        $booking_persons = get_post_meta($booking_id, '_booking_persons', true);
                                        
                                        if ($booking_cost > 0 && is_array($booking_persons)) {
                                            $total_persons = array_sum($booking_persons);
                                            if ($total_persons > 0) {
                                                $unit_price = $booking_cost / $total_persons;
                                            }
                                        }
                                    }
                                    
                                    echo wc_price($unit_price);
                                    ?>
                                </td>
                                <td style="text-align: right;">
                                    <?php echo wc_price($item->get_subtotal()); ?>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Order Totals -->
            <div class="at-order-totals">
                <table class="at-totals-table">
                    <tr>
                        <td><strong><?php _e('Subtotal:', 'at-bookings-api-fixes'); ?></strong></td>
                        <td style="text-align: right;"><?php echo wc_price($order->get_subtotal()); ?></td>
                    </tr>
                    <tr>
                        <td><strong><?php _e('Tax:', 'at-bookings-api-fixes'); ?></strong></td>
                        <td style="text-align: right;"><?php echo wc_price($order->get_total_tax()); ?></td>
                    </tr>
                    <tr>
                        <td><strong><?php _e('Discount:', 'at-bookings-api-fixes'); ?></strong></td>
                        <td style="text-align: right;"><?php echo wc_price($order->get_discount_total()); ?></td>
                    </tr>
                    <tr style="background: #f5f5f5; font-size: 1.1em;">
                        <td><strong><?php _e('Total:', 'at-bookings-api-fixes'); ?></strong></td>
                        <td style="text-align: right;"><strong><?php echo wc_price($order->get_total()); ?></strong></td>
                    </tr>
                </table>
            </div>
            
            <!-- Order Notes -->
            <?php
            $notes = $order->get_customer_order_notes();
            if (!empty($notes)) {
                ?>
                <div class="at-order-notes">
                    <h3><?php _e('Order Notes', 'at-bookings-api-fixes'); ?></h3>
                    <ul>
                        <?php foreach ($notes as $note): ?>
                        <li><strong><?php echo esc_html($note->get_author()); ?>:</strong> <?php echo esc_html($note->get_content()); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php
            }
            ?>
        </div>
        <?php
    }
    
    /**
     * Render sync interface
     */
    private static function render_sync_interface($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }
        
        ?>
        <div class="at-sync-interface">
            <div class="at-sync-main">
                <div class="at-entity-cards">
                    <?php self::render_entity_card('contact', $order); ?>
                    <?php self::render_entity_card('product', $order); ?>
                    <?php self::render_entity_card('cycle', $order); ?>
                    <?php self::render_entity_card('order', $order); ?>
                </div>
                
                <div class="at-sync-controls">
                    <button type="button" id="at-run-full-sync" class="button button-primary button-large">
                        <span class="dashicons dashicons-update"></span>
                        <?php _e('Run Full Sync', 'at-bookings-api-fixes'); ?>
                    </button>
                    
                    <button type="button" id="at-stop-sync" class="button button-secondary" style="display: none;">
                        <span class="dashicons dashicons-no"></span>
                        <?php _e('Stop Sync', 'at-bookings-api-fixes'); ?>
                    </button>
                </div>
            </div>
            
            <div class="at-sync-timeline">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                    <h3 style="margin: 0;"><?php _e('Sync Timeline', 'at-bookings-api-fixes'); ?></h3>
                    <button type="button" id="at-clear-timeline" class="button" style="padding: 4px 12px;">
                        <span class="dashicons dashicons-trash" style="margin-top: 4px;"></span>
                        <?php _e('Clear History', 'at-bookings-api-fixes'); ?>
                    </button>
                </div>
                <div id="at-timeline-content" class="at-timeline-content">
                    <div class="at-timeline-empty">
                        <?php _e('No sync activity yet. Click "Run Full Sync" or individual entity buttons to start.', 'at-bookings-api-fixes'); ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render entity card
     */
    private static function render_entity_card($entity, $order) {
        $entity_config = self::get_entity_config($entity);
        $entity_data = self::get_entity_current_data($entity, $order);
        
        ?>
        <div class="at-entity-card" data-entity="<?php echo esc_attr($entity); ?>">
            <div class="at-card-header">
                <h3>
                    <span class="dashicons <?php echo esc_attr($entity_config['icon']); ?>"></span>
                    <?php echo esc_html($entity_config['title']); ?>
                </h3>
                <div class="at-card-status">
                    <?php if ($entity_data['zoho_id']): ?>
                        <span class="at-status-connected">
                            <a href="<?php echo esc_url($entity_data['zoho_url']); ?>" target="_blank">
                                <?php echo esc_html($entity_data['zoho_id']); ?>
                            </a>
                        </span>
                    <?php else: ?>
                        <span class="at-status-not-found"><?php _e('Not Found', 'at-bookings-api-fixes'); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="at-card-content">
                <!-- Origin information -->
                <div class="at-entity-origin">
                    <small>
                        <strong><?php _e('Origin:', 'at-bookings-api-fixes'); ?></strong> 
                        <?php 
                        if ($entity === 'order') {
                            echo esc_html($entity_data['preview']['_origin_module'] ?? 'Unknown') . ' - ' . 
                                 esc_html($entity_data['preview']['_origin_id'] ?? 'N/A');
                        } else {
                            echo 'WooCommerce';
                        }
                        ?>
                    </small>
                </div>
                
                <?php if (!empty($entity_data['preview'])): ?>
                <div class="at-data-preview">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                        <strong><?php _e('Data to sync:', 'at-bookings-api-fixes'); ?></strong>
                        <button type="button" class="button button-small at-view-full-object" 
                                data-entity="<?php echo esc_attr($entity); ?>"
                                data-order-id="<?php echo esc_attr($order->get_id()); ?>"
                                style="font-size: 11px; padding: 2px 8px; height: auto;">
                            📋 <?php _e('View Full Object', 'at-bookings-api-fixes'); ?>
                        </button>
                    </div>
                    <ul>
                        <?php foreach (array_slice($entity_data['preview'], 0, 10) as $key => $value): ?>
                        <?php if (strpos($key, '_meta_info') === false && strpos($key, '_') !== 0): ?>
                        <li><code><?php echo esc_html($key); ?>:</code> 
                            <?php 
                            if (is_array($value)) {
                                echo '<em>[' . count($value) . ' items]</em>';
                            } elseif (is_bool($value)) {
                                echo $value ? 'true' : 'false';
                            } else {
                                echo esc_html(substr((string)$value, 0, 50));
                                if (strlen((string)$value) > 50) echo '...';
                            }
                            ?>
                        </li>
                        <?php endif; ?>
                        <?php endforeach; ?>
                        <?php if (count($entity_data['preview']) > 10): ?>
                        <li><em><?php printf(__('... and %d more fields', 'at-bookings-api-fixes'), count($entity_data['preview']) - 10); ?></em></li>
                        <?php endif; ?>
                    </ul>
                    
                    <?php if (!empty($entity_data['preview']['_meta_info'])): ?>
                    <div style="background: #f0f0f1; padding: 8px; margin-top: 8px; border-radius: 3px; font-size: 11px;">
                        <strong>ℹ️ Info:</strong>
                        <?php foreach ($entity_data['preview']['_meta_info'] as $key => $value): ?>
                            <div><?php echo esc_html(ucwords(str_replace('_', ' ', $key))); ?>: 
                                <code><?php echo esc_html($value === true ? 'Yes' : ($value === false ? 'No' : $value)); ?></code>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
                
                <?php if (!empty($entity_data['diff'])): ?>
                <div class="at-data-diff">
                    <strong><?php _e('Changes to apply:', 'at-bookings-api-fixes'); ?></strong>
                    <div class="at-diff-content">
                        <?php echo wp_kses_post($entity_data['diff']); ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if (!empty($entity_data['issues'])): ?>
                <div class="at-data-issues">
                    <strong style="color: #d63638;"><?php _e('⚠ Issues detected:', 'at-bookings-api-fixes'); ?></strong>
                    <ul style="color: #d63638;">
                        <?php foreach ($entity_data['issues'] as $issue): ?>
                        <li><?php echo esc_html($issue); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="at-card-actions">
                <?php if (!$entity_data['zoho_id']): ?>
                <button type="button" 
                        class="button button-secondary at-search-entity" 
                        data-entity="<?php echo esc_attr($entity); ?>"
                        data-order-id="<?php echo esc_attr($order->get_id()); ?>">
                    <span class="dashicons dashicons-search"></span>
                    <?php _e('Search', 'at-bookings-api-fixes'); ?>
                </button>
                <?php endif; ?>
                <button type="button" 
                        class="button at-sync-entity" 
                        data-entity="<?php echo esc_attr($entity); ?>"
                        data-order-id="<?php echo esc_attr($order->get_id()); ?>">
                    <span class="dashicons dashicons-update"></span>
                    <?php echo esc_html($entity_data['zoho_id'] ? __('Update', 'at-bookings-api-fixes') : __('Create', 'at-bookings-api-fixes')); ?>
                </button>
                
                <div class="at-card-meta">
                    <small>
                        <?php printf(__('Method: %s', 'at-bookings-api-fixes'), '<code>' . esc_html($entity_config['method']) . '</code>'); ?>
                        <br>
                        <?php printf(__('Endpoint: %s', 'at-bookings-api-fixes'), '<code>' . esc_html($entity_config['endpoint']) . '</code>'); ?>
                    </small>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Get entity configuration
     */
    private static function get_entity_config($entity) {
        $configs = [
            'contact' => [
                'title' => __('Contact', 'at-bookings-api-fixes'),
                'icon' => 'dashicons-admin-users',
                'method' => 'sync_contact()',
                'endpoint' => '/contacts'
            ],
            'product' => [
                'title' => __('Product/Tour', 'at-bookings-api-fixes'),
                'icon' => 'dashicons-products',
                'method' => 'sync_product()',
                'endpoint' => '/products'
            ],
            'cycle' => [
                'title' => __('Cycle/Slot', 'at-bookings-api-fixes'),
                'icon' => 'dashicons-calendar-alt',
                'method' => 'sync_cycle()',
                'endpoint' => '/cycles'
            ],
            'order' => [
                'title' => __('Order/Lead', 'at-bookings-api-fixes'),
                'icon' => 'dashicons-clipboard',
                'method' => 'sync_order_record()',
                'endpoint' => '/sales_orders or /leads'
            ]
        ];
        
        return $configs[$entity] ?? [];
    }
    
    /**
     * Get current entity data and preview
     */
    public static function get_entity_current_data($entity, $order) {
        $data = [
            'zoho_id' => null,
            'zoho_url' => '',
            'preview' => [],
            'diff' => '',
            'issues' => []
        ];
        
        switch ($entity) {
            case 'contact':
                $data['zoho_id'] = get_post_meta($order->get_id(), '_zoho_contact_id', true);
                $contact_data = AT_Zoho_Mapper::map_to_contact($order);
                $data['preview'] = $contact_data;
                
                // If no stored Zoho ID, search in Zoho by Email
                if (empty($data['zoho_id']) && !empty($contact_data['Email'])) {
                    try {
                        $zoho_api = AT_Zoho_API::get_instance();
                        $search_result = $zoho_api->search_records('Contacts', 'Email', $contact_data['Email']);
                        
                        if (!empty($search_result['data']) && isset($search_result['data'][0]['id'])) {
                            $data['zoho_id'] = $search_result['data'][0]['id'];
                            write_detailed_log('Contact found in Zoho by Email: ' . $contact_data['Email'], 'INFO');
                        } else {
                            write_detailed_log('Contact not found in Zoho by Email: ' . $contact_data['Email'], 'DEBUG');
                        }
                    } catch (Exception $e) {
                        write_detailed_log('Error searching Contact in Zoho: ' . $e->getMessage(), 'ERROR');
                    }
                }
                
                // Check for phone
                if (empty($order->get_billing_phone())) {
                    $data['issues'][] = __('Phone number is empty', 'at-bookings-api-fixes');
                }
                break;
                
            case 'product':
                // Get first product from order
                $items = $order->get_items();
                if (!empty($items)) {
                    $first_item = reset($items);
                    $product = $first_item->get_product();
                    if ($product) {
                        $product_data = AT_Zoho_Mapper::map_to_product($product);
                        $data['preview'] = $product_data;
                        
                        $zoho_api = AT_Zoho_API::get_instance();
                        $product_sku = $product->get_sku();
                        $zoho_object_id = null;
                        
                        // Step 1: Check if product has SKU (should be Zoho ObjectID)
                        if (!empty($product_sku)) {
                            write_detailed_log("Product has SKU: $product_sku - Verifying it exists in Zoho...", 'DEBUG');
                            
                            // Verify the SKU (ObjectID) exists in Zoho
                            try {
                                $zoho_product = $zoho_api->get_record('Products', $product_sku);
                                
                                if ($zoho_product && isset($zoho_product['id'])) {
                                    // SKU is valid - it exists in Zoho
                                    $zoho_object_id = $zoho_product['id'];
                                    $data['zoho_id'] = $zoho_object_id;
                                    write_detailed_log("✓ SKU verified in Zoho. ObjectID: $zoho_object_id", 'INFO');
                                } else {
                                    // SKU doesn't exist in Zoho - need to search by PID
                                    write_detailed_log("✗ SKU not found in Zoho. Will search by PID instead.", 'DEBUG');
                                }
                            } catch (Exception $e) {
                                // Error verifying SKU - will search by PID (this is normal if SKU is invalid)
                                write_detailed_log("SKU not found in Zoho (will search by PID): " . $e->getMessage(), 'DEBUG');
                            }
                        }
                        
                        // Step 2: If no valid ObjectID yet, search by PID (WordPress product ID)
                        if (!$zoho_object_id && isset($product_data['PID'])) {
                            write_detailed_log("Searching in Zoho by PID: " . $product_data['PID'], 'DEBUG');
                            
                            try {
                                $search_result = $zoho_api->search_records('Products', 'PID', $product_data['PID']);
                                
                                // Check if we found the product in Zoho
                                if (!empty($search_result['data']) && is_array($search_result['data'])) {
                                    $zoho_product = $search_result['data'][0];
                                    $zoho_object_id = $zoho_product['id'] ?? null;
                                    
                                    if ($zoho_object_id) {
                                        $data['zoho_id'] = $zoho_object_id;
                                        
                                        // Save the Zoho ObjectID to SKU field for future use
                                        $product->set_sku($zoho_object_id);
                                        $product->save();
                                        
                                        write_detailed_log("✓ Found product in Zoho by PID. ObjectID $zoho_object_id saved to SKU.", 'INFO');
                                        
                                        $data['issues'][] = sprintf(
                                            __('✅ Product found in Zoho by PID. ObjectID %s saved to SKU field.', 'at-bookings-api-fixes'),
                                            $zoho_object_id
                                        );
                                    }
                                }
                            } catch (Exception $e) {
                                // Error searching by PID
                                write_detailed_log("Error searching product by PID in Zoho: " . $e->getMessage(), 'ERROR');
                            }
                        }
                        
                        // Step 3: If still not found - show error
                        if (!$zoho_object_id) {
                            $data['issues'][] = sprintf(
                                __('❌ Product not found in Zoho. Searched by PID: %s. Sync needed.', 'at-bookings-api-fixes'),
                                $product_data['PID']
                            );
                        }
                    }
                }
                break;
                
            case 'cycle':
                $slot_data = self::get_booking_data_from_order($order);
                if ($slot_data) {
                    $product = wc_get_product($slot_data['product_id']);
                    $cycle_data = AT_Zoho_Mapper::map_to_cycle($slot_data, $product);
                    $data['preview'] = $cycle_data;
                    
                    // Add detailed slot information
                    $slot_start = strtotime($slot_data['slot_start']);
                    $slot_end = isset($slot_data['slot_end']) ? strtotime($slot_data['slot_end']) : null;
                    
                    // Calculate unique tour_id (product_id_timestamp) - same as Future Tours page
                    $tour_id = $slot_data['product_id'] . '_' . (int)$slot_start;
                    
                    $data['preview']['_tour_id'] = $tour_id;
                    $data['preview']['_formatted_date'] = date_i18n(get_option('date_format'), $slot_start);
                    $data['preview']['_formatted_time'] = date_i18n(get_option('time_format'), $slot_start);
                    $data['preview']['_slot_start_time'] = date_i18n('Y-m-d H:i:s', $slot_start);
                    if ($slot_end) {
                        $data['preview']['_slot_end_time'] = date_i18n('Y-m-d H:i:s', $slot_end);
                    }
                    $data['preview']['_current_bookings'] = $slot_data['current_bookings'] ?? 0;
                    $data['preview']['_slot_status'] = $slot_data['status'] ?? 'unknown';
                    
                    // CRITICAL: Search for cycle in Zoho using our centralized logic
                    $zoho_cycle_id = $slot_data['zoho_cycle_id'] ?? null;
                    
                    // If no stored ID, try to find it using find_or_create_cycle logic
                    if (!$zoho_cycle_id && class_exists('AT_Zoho_Sync_Service')) {
                        $sync_service = new AT_Zoho_Sync_Service();
                        $find_result = $sync_service->find_or_create_cycle($slot_data, $product);
                        
                        if ($find_result['success'] && !empty($find_result['id'])) {
                            $zoho_cycle_id = $find_result['id'];
                            $data['preview']['_find_message'] = $find_result['message'];
                        }
                    }
                    
                    $data['zoho_id'] = $zoho_cycle_id;
                    
                } else {
                    $data['issues'][] = __('⚠ No booking found for this order. Please verify booking exists in WooCommerce Bookings.', 'at-bookings-api-fixes');
                }
                break;
                
            case 'order':
                $is_paid = $order->is_paid();
                $module = $is_paid ? 'Sales_Orders' : 'Leads';
                $data['zoho_id'] = get_post_meta($order->get_id(), '_zoho_' . $module . '_id', true);
                
                // If no stored Zoho ID, search in Zoho by OID/BID
                if (empty($data['zoho_id'])) {
                    $order_id = $order->get_id();
                    $booking_id = AT_Zoho_Mapper::get_booking_id_from_order($order);
                    
                    try {
                        $zoho_api = AT_Zoho_API::get_instance();
                        
                        if ($is_paid) {
                            // Search in Sales_Orders by OID
                            $search_result = $zoho_api->search_records('Sales_Orders', 'OID', $order_id);
                            
                            if (!empty($search_result['data'])) {
                                // If booking_id exists, filter by BID as well
                                if ($booking_id) {
                                    foreach ($search_result['data'] as $record) {
                                        if (isset($record['BID']) && (int)$record['BID'] === $booking_id) {
                                            $data['zoho_id'] = $record['id'];
                                            write_detailed_log('Sales Order found in Zoho by OID+BID: Order #' . $order_id . ', BID: ' . $booking_id, 'INFO');
                                            break;
                                        }
                                    }
                                } else {
                                    // No BID, just use first match by OID
                                    $data['zoho_id'] = $search_result['data'][0]['id'];
                                    write_detailed_log('Sales Order found in Zoho by OID: ' . $order_id, 'INFO');
                                }
                            } else {
                                write_detailed_log('Sales Order not found in Zoho by OID: ' . $order_id, 'DEBUG');
                            }
                        } else {
                            // Search in Leads by WP_OID
                            $search_result = $zoho_api->search_records('Leads', 'WP_OID', $order_id);
                            
                            if (!empty($search_result['data'])) {
                                // If booking_id exists, filter by WP_BID as well
                                if ($booking_id) {
                                    foreach ($search_result['data'] as $record) {
                                        if (isset($record['WP_BID']) && (int)$record['WP_BID'] === $booking_id) {
                                            $data['zoho_id'] = $record['id'];
                                            write_detailed_log('Lead found in Zoho by WP_OID+WP_BID: Order #' . $order_id . ', BID: ' . $booking_id, 'INFO');
                                            break;
                                        }
                                    }
                                } else {
                                    // No BID, just use first match by WP_OID
                                    $data['zoho_id'] = $search_result['data'][0]['id'];
                                    write_detailed_log('Lead found in Zoho by WP_OID: ' . $order_id, 'INFO');
                                }
                            } else {
                                write_detailed_log('Lead not found in Zoho by WP_OID: ' . $order_id, 'DEBUG');
                            }
                        }
                    } catch (Exception $e) {
                        write_detailed_log('Error searching Order/Lead in Zoho: ' . $e->getMessage(), 'ERROR');
                    }
                }
                
                // Use the same reliable method as ajax_get_order_object
                $slot_data = self::get_booking_data_from_order($order);
                
                // Get actual IDs from meta
                $contact_id = get_post_meta($order->get_id(), '_zoho_contact_id', true);
                $cycle_ids = get_post_meta($order->get_id(), '_zoho_cycle_ids', true);
                $cycle_id = is_array($cycle_ids) && !empty($cycle_ids) ? $cycle_ids[0] : null;
                
                // Get cycle ID from booking meta if not in order meta
                if (!$cycle_id && $slot_data) {
                    $cycle_id = $slot_data['zoho_cycle_id'] ?? null;
                }
                
                // If still no cycle ID but we have slot_data, try to find it in Zoho
                if (!$cycle_id && $slot_data) {
                    // Get product for cycle search
                    $items = $order->get_items();
                    if (!empty($items)) {
                        $first_item = reset($items);
                        $product = $first_item->get_product();
                        
                        if ($product && class_exists('AT_Zoho_Sync_Service')) {
                            $sync_service = new AT_Zoho_Sync_Service();
                            if (method_exists($sync_service, 'find_or_create_cycle')) {
                                $find_result = $sync_service->find_or_create_cycle($slot_data, $product);
                                
                                if ($find_result['success'] && !empty($find_result['id'])) {
                                    $cycle_id = $find_result['id'];
                                    write_detailed_log('Found Cycle in Zoho for Order #' . $order->get_id() . ': ' . $cycle_id, 'INFO');
                                }
                            }
                        }
                    }
                }
                
                // Add cycle ID to slot_data for Ordered_Items linking
                if (!$slot_data) {
                    $slot_data = [];
                }
                if ($cycle_id) {
                    $slot_data['zoho_cycle_id'] = $cycle_id;
                }
                
                // Build order data with correct structure (per CHANGELOG v3.6.1)
                $order_data = AT_Zoho_Mapper::map_to_sales_order($order, $slot_data);
                
                // Override Contact_Name as lookup object (not Customer_No)
                if ($contact_id) {
                    $order_data['Contact_Name'] = ['id' => $contact_id];
                }
                
                // IMPORTANT: Do NOT override Cycle_type!
                // Per CHANGELOG v3.6.1: Cycle_type = 'קבוצתי' (text, not ID)
                // The cycle link is in Ordered_Items[].Cycle_rel
                
                // Determine cycle ID source for display
                $cycle_source = 'not_synced';
                if (!empty($cycle_ids)) {
                    $cycle_source = 'order_meta';
                } elseif (!empty($slot_data['zoho_cycle_id'])) {
                    $cycle_source = 'booking_meta';
                } elseif (!empty($cycle_id)) {
                    $cycle_source = 'zoho_search';
                }
                
                // Add metadata about what will be sent to Zoho
                $data['preview'] = $order_data;
                $data['preview']['_meta_info'] = [
                    'contact_id_source' => $contact_id ? 'order_meta' : 'not_synced',
                    'cycle_id_source' => $cycle_source,
                    'total_items' => count($order_data['Ordered_Items'] ?? []),
                    'has_subforms' => !empty($order_data['Ordered_Items']),
                    'ready_to_sync' => !empty($contact_id) && !empty($cycle_id)
                ];
                
                // Add detailed ticket breakdown by type
                $items = $order->get_items();
                $total_participants = 0;
                if (!empty($items)) {
                    $ticket_types = [];
                    foreach ($items as $item) {
                        $person_type = $item->get_meta('_person_type') ?: __('Standard', 'at-bookings-api-fixes');
                        $qty = $item->get_quantity();
                        $total_participants += $qty;
                        
                        if (!isset($ticket_types[$person_type])) {
                            $ticket_types[$person_type] = [
                                'type' => $person_type,
                                'quantity' => 0,
                                'unit_price' => 0,
                                'subtotal' => 0
                            ];
                        }
                        $ticket_types[$person_type]['quantity'] += $qty;
                        $unit_price = $qty > 0 ? $item->get_subtotal() / $qty : 0;
                        $ticket_types[$person_type]['unit_price'] = $unit_price;
                        $ticket_types[$person_type]['subtotal'] += $item->get_subtotal();
                    }
                    
                    // Add ticket breakdown to preview
                    $data['preview']['_ticket_breakdown'] = json_encode(array_values($ticket_types), JSON_UNESCAPED_UNICODE);
                    $data['preview']['_total_participants'] = $total_participants;
                }
                
                // Add discount and coupon information
                $data['preview']['_discount_total'] = wc_price($order->get_discount_total());
                $data['preview']['_tax_total'] = wc_price($order->get_total_tax());
                $data['preview']['_shipping_total'] = wc_price($order->get_shipping_total());
                $data['preview']['_grand_total'] = wc_price($order->get_total());
                
                // Add coupon information if available
                $coupons = $order->get_coupon_codes();
                if (!empty($coupons)) {
                    $data['preview']['_coupons'] = implode(', ', $coupons);
                }
                
                // Add customer notes
                $notes = $order->get_customer_order_notes();
                if (!empty($notes)) {
                    $note_texts = [];
                    foreach ($notes as $note) {
                        $note_texts[] = $note->get_content();
                    }
                    $data['preview']['_customer_notes'] = implode(' | ', $note_texts);
                }
                
                // Add transaction ID - extract from Yaadpay meta field
                $transaction_id = $order->get_transaction_id();
                if (!$transaction_id) {
                    // Try Yaadpay credit card payment meta - parse Id from string
                    $yaad_payment = get_post_meta($order->get_id(), 'yaad_credit_card_payment', true);
                    if ($yaad_payment && preg_match('/Id=(\d+)/', $yaad_payment, $matches)) {
                        $transaction_id = $matches[1];
                    }
                }
                $data['preview']['_transaction_id'] = esc_html($transaction_id ?: __('N/A', 'at-bookings-api-fixes'));
                $data['preview']['_origin_transaction_id'] = esc_html($transaction_id ?: __('N/A', 'at-bookings-api-fixes'));
                
                // Add origin metadata
                $data['preview']['_origin_module'] = 'WooCommerce';
                $data['preview']['_origin_entity'] = 'Order';
                $data['preview']['_origin_id'] = $order->get_id();
                $data['preview']['_origin_date'] = esc_html($order->get_date_created()->format('Y-m-d H:i:s'));
                $data['preview']['_origin_status'] = esc_html(wc_get_order_status_name($order->get_status()));
                $data['preview']['_origin_payment_status'] = esc_html($order->is_paid() ? __('Paid', 'at-bookings-api-fixes') : __('Pending', 'at-bookings-api-fixes'));
                $data['preview']['_origin_payment_date'] = esc_html($order->is_paid() && $order->get_date_paid() ? $order->get_date_paid()->format('Y-m-d H:i:s') : __('Not paid', 'at-bookings-api-fixes'));
                
                // Generate Zoho URL
                $data['zoho_url'] = "https://crm.zoho.com/crm/org123456789/{$module}/detail/{$data['zoho_id']}";
                break;
        }
        
        return $data;
    }
    
    /**
     * Get order slot data
     */
    private static function get_order_slot_data($order) {
        global $wpdb;
        
        // First, try to get from custom booking slots tables
        $slots_table = $wpdb->prefix . 'at_booking_slots';
        $slot_bookings_table = $wpdb->prefix . 'at_slot_bookings';
        
        $slot = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT s.* FROM {$slots_table} s
                JOIN {$slot_bookings_table} sb ON s.id = sb.slot_id
                WHERE sb.order_id = %d
                LIMIT 1",
                $order->get_id()
            ),
            ARRAY_A
        );
        
        // If found in custom tables, return it
        if ($slot) {
            return $slot;
        }
        
        // If not found, try to get from WooCommerce Bookings
        if (function_exists('get_wc_booking') && class_exists('AT_Zoho_Mapper')) {
            // Get booking ID using the mapper helper
            $booking_id = AT_Zoho_Mapper::get_booking_id_from_order($order);
            
            if ($booking_id) {
                try {
                    $booking = get_wc_booking($booking_id);
                    
                    if ($booking && is_a($booking, 'WC_Booking')) {
                        // Convert WC_Booking to our slot data format
                        $product = $booking->get_product();
                        $product_id = $product ? $product->get_id() : 0;
                        
                        write_detailed_log(sprintf(
                            "Found WC Booking #%d for Order #%d: Start=%s, End=%s, Status=%s",
                            $booking->get_id(),
                            $order->get_id(),
                            $booking->get_start_date('Y-m-d H:i:s'),
                            $booking->get_end_date('Y-m-d H:i:s'),
                            $booking->get_status()
                        ), 'INFO');
                        
                        $start_timestamp = $booking->get_start();
                        
                        // Generate tour_id (PID_timestamp) - used in Tour_SKU field
                        $tour_id = $product_id . '_' . (int)$start_timestamp;
                        
                        return [
                            'id' => $booking->get_id(),
                            'product_id' => $product_id,
                            'slot_start' => $booking->get_start_date('Y-m-d H:i:s'),
                            'slot_end' => $booking->get_end_date('Y-m-d H:i:s'),
                            'status' => $booking->get_status(),
                            'current_bookings' => 1, // Single booking
                            'tour_id' => $tour_id,  // CRITICAL: Add tour_id for Tour_SKU searches
                            'zoho_cycle_id' => get_post_meta($booking->get_id(), '_zoho_cycle_id', true),
                        ];
                    }
                } catch (Exception $e) {
                    write_detailed_log("Error getting WC Booking: " . $e->getMessage(), 'ERROR');
                }
            } else {
                write_detailed_log("No booking ID found for Order #" . $order->get_id(), 'DEBUG');
            }
        }
        
        return null;
    }
    
    /**
     * Get booking data from order using WC_Booking_Data_Store
     * Same logic as REST API endpoint in child theme
     * 
     * PUBLIC: Used by ajax_get_order_object for reliable booking data retrieval
     * 
     * @param WC_Order $order Order object
     * @return array|null Booking data or null if not found
     */
    public static function get_booking_data_from_order($order) {
        if (!class_exists('WC_Booking_Data_Store')) {
            write_detailed_log('WC_Booking_Data_Store not available', 'DEBUG');
            return null;
        }
        
        $order_id = $order->get_id();
        $booking_ids = WC_Booking_Data_Store::get_booking_ids_from_order_id($order_id);
        
        if (empty($booking_ids)) {
            write_detailed_log('No booking IDs found for Order #' . $order_id, 'DEBUG');
            return null;
        }
        
        $booking_id = $booking_ids[0]; // First booking
        $booking = get_wc_booking($booking_id);
        
        if (!$booking || !$booking->get_id()) {
            write_detailed_log('Booking object not found for ID: ' . $booking_id, 'DEBUG');
            return null;
        }
        
        $product = $booking->get_product();
        if (!$product) {
            write_detailed_log('Product not found for Booking #' . $booking_id, 'DEBUG');
            return null;
        }
        
        $product_id = $product->get_id();
        $start_timestamp = $booking->get_start();
        $tour_id = $product_id . '_' . (int)$start_timestamp;
        
        // Get tour city from product ACF field
        $tour_city = get_field('TOUR_CITY', $product_id) ?: '';
        
        $booking_data = [
            'id' => $booking->get_id(),
            'product_id' => $product_id,
            'slot_start' => gmdate('Y-m-d H:i:s', $start_timestamp),
            'slot_end' => gmdate('Y-m-d H:i:s', $booking->get_end()),
            'status' => $booking->get_status(),
            'current_bookings' => 1,
            'zoho_cycle_id' => get_post_meta($booking->get_id(), '_zoho_cycle_id', true),
            'tour_id' => $tour_id,
            'tour_city' => $tour_city,  // For Subject building
        ];
        
        write_detailed_log('Booking data retrieved for Order #' . $order_id . ': Start=' . $booking_data['slot_start'] . ', Tour ID=' . $tour_id . ', City=' . $tour_city, 'DEBUG');
        
        return $booking_data;
    }
    
    /**
     * AJAX handler for searching records in Zoho (generic)
     */
    public static function handle_search_entity() {
        check_ajax_referer('at_zoho_sync', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
        }
        
        $module = sanitize_text_field($_POST['module'] ?? '');
        $search_field = sanitize_text_field($_POST['search_field'] ?? '');
        $search_value = sanitize_text_field($_POST['search_value'] ?? '');
        $order_id = isset($_POST['order_id']) ? (int) $_POST['order_id'] : null;
        
        if (!$module || !$search_field || !$search_value) {
            wp_send_json_error(__('Missing search parameters', 'at-bookings-api-fixes'));
        }
        
        // Verify Zoho API is available
        if (!class_exists('AT_Zoho_API')) {
            wp_send_json_error(__('Zoho API not available', 'at-bookings-api-fixes'));
        }
        
        try {
            $zoho_api = AT_Zoho_API::get_instance();
            
            // Perform search with correct parameters: module, criteria (field name), value
            $response = $zoho_api->search_records($module, $search_field, $search_value);
            
            // Log the search operation to database
            if (class_exists('AT_Zoho_Sync_Logs')) {
                $logs = AT_Zoho_Sync_Logs::get_instance();
                
                $request_data = [
                    'search_field' => $search_field,
                    'search_value' => $search_value
                ];
                
                $is_success = isset($response['success']) && $response['success'];
                $zoho_id = (!empty($response['data']) && isset($response['data'][0]['id'])) ? $response['data'][0]['id'] : null;
                
                $logs->log_sync(
                    'search',
                    $module,
                    $order_id,
                    $zoho_id,
                    $is_success ? 'success' : 'error',
                    $request_data,
                    $response,
                    $is_success ? null : ($response['message'] ?? 'Search failed')
                );
            }
            
            if (isset($response['success']) && $response['success']) {
                // If searching for Cycles and found, cache the Zoho ID for frontend display
                if ($module === 'Cycles' && !empty($response['data'])) {
                    $zoho_id = $response['data'][0]['id'];
                    $search_val_tour_sku = $response['data'][0]['Tour_SKU'] ?? $search_value;
                    $cache_key = 'at_zoho_cycle_id_' . md5($search_val_tour_sku);
                    update_option($cache_key, $zoho_id, 'no');
                    write_detailed_log("Cached Zoho Cycle ID: {$search_val_tour_sku} → {$zoho_id}", 'DEBUG');
                }
                
                wp_send_json_success([
                    'module' => $module,
                    'search_field' => $search_field,
                    'search_value' => $search_value,
                    'results' => $response['data'],
                    'count' => count($response['data'])
                ]);
            } else {
                wp_send_json_error($response['message'] ?? __('No results found', 'at-bookings-api-fixes'));
            }
        } catch (Exception $e) {
            // Log exception
            if (class_exists('AT_Zoho_Sync_Logs')) {
                $logs = AT_Zoho_Sync_Logs::get_instance();
                $logs->log_sync(
                    'search',
                    $module,
                    $order_id,
                    null,
                    'error',
                    ['search_field' => $search_field, 'search_value' => $search_value],
                    null,
                    $e->getMessage()
                );
            }
            wp_send_json_error($e->getMessage());
        }
    }
    
    /**
     * AJAX handler for getting search configuration
     */
    public static function handle_get_search_config() {
        check_ajax_referer('at_zoho_sync', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
        }
        
        $entity = sanitize_text_field($_POST['entity'] ?? '');
        $order_id = (int) ($_POST['order_id'] ?? 0);
        
        if (!$entity || !$order_id) {
            wp_send_json_error(__('Missing entity or order ID', 'at-bookings-api-fixes'));
        }
        
        $order = wc_get_order($order_id);
        if (!$order) {
            wp_send_json_error(__('Order not found', 'at-bookings-api-fixes'));
        }
        
        $config = self::get_search_config($entity, $order);
        
        if ($config) {
            wp_send_json_success($config);
        } else {
            wp_send_json_error(__('No search configuration found for this entity', 'at-bookings-api-fixes'));
        }
    }
    
    /**
     * Get search configuration for each entity
     */
    public static function get_search_config($entity, $order) {
        switch ($entity) {
            case 'contact':
                return [
                    'module' => 'Contacts', // לקוחות
                    'field_options' => [
                        'Email' => $order->get_billing_email(),
                        'Phone' => $order->get_billing_phone(),
                    ],
                    'default_field' => 'Email'
                ];
            
            case 'product':
                $items = $order->get_items();
                if (empty($items)) return null;
                $first_item = reset($items);
                $product = $first_item->get_product();
                if (!$product) return null;
                
                return [
                    'module' => 'Products', // סיורים
                    'field_options' => [
                        'Product_Code' => $product->get_sku(),
                        'PID' => $product->get_id(),
                    ],
                    'default_field' => 'PID'
                ];
            
            case 'cycle':
                global $wpdb;
                
                // Get booking ID using WC_Bookings
                $booking_id = AT_Zoho_Mapper::get_booking_id_from_order($order);
                if (!$booking_id) {
                    return null;
                }
                
                // Get booking from WC_Bookings
                if (!class_exists('WC_Booking')) {
                    return null;
                }
                
                $booking = get_wc_booking($booking_id);
                if (!$booking || !$booking->get_id()) {
                    return null;
                }
                
                $product = $booking->get_product();
                if (!$product) {
                    return null;
                }
                
                $product_id = $product->get_id();
                $start_timestamp = $booking->get_start();
                
                // Check if we have stored zoho_cycle_id from previous sync
                $zoho_cycle_id = get_post_meta($booking->get_id(), '_zoho_cycle_id', true);
                
                // Generate tour_id (PID_timestamp) - this is what goes in Tour_SKU field
                $tour_id = $product_id . '_' . (int)$start_timestamp;
                
                $field_options = [];
                
                // PRIMARY: If we have stored zoho_cycle_id, search by exact ID
                if (!empty($zoho_cycle_id)) {
                    $field_options['id'] = $zoho_cycle_id;
                }
                
                // SECONDARY: Search by Tour_SKU (the unique identifier we use)
                $field_options['Tour_SKU'] = $tour_id;
                
                return [
                    'module' => 'Cycles',
                    'field_options' => $field_options,
                    'default_field' => !empty($zoho_cycle_id) ? 'id' : 'Tour_SKU'
                ];
            
            case 'order':
                return [
                    'module' => $order->is_paid() ? 'Sales_Orders' : 'Leads', // הזדמנויות מכירה או לידים
                    'field_options' => [
                        'OID' => $order->get_id(),
                        'Subject' => 'Order #' . $order->get_id(),
                    ],
                    'default_field' => 'OID'
                ];
            
            default:
                return null;
        }
    }
    
    /**
     * Get full order data from REST API
     */
    private static function get_full_order_data_from_rest($order_id) {
        $rest_url = get_rest_url(null, 'wc/v3/orders/' . $order_id);
        
        $response = wp_remote_get($rest_url, [
            'headers' => ['Content-Type' => 'application/json']
        ]);
        
        if (is_wp_error($response)) {
            return null;
        }
        
        $data = json_decode(wp_remote_retrieve_body($response), true);
        return $data;
    }
    
    /**
     * Get search data for entity
     */
    private static function get_search_data_for_entity($entity, $order, $rest_data = null) {
        switch ($entity) {
            case 'contact':
                return [
                    'criteria_field' => 'Email',
                    'criteria_value' => $order->get_billing_email(),
                    'module' => 'Contacts'
                ];
            
            case 'product':
                $items = $order->get_items();
                if (empty($items)) return null;
                $first_item = reset($items);
                $product = $first_item->get_product();
                if (!$product) return null;
                
                return [
                    'criteria_field' => 'Product_Code',
                    'criteria_value' => $product->get_sku(),
                    'module' => 'Products'
                ];
            
            case 'cycle':
                $booking_id = AT_Zoho_Mapper::get_booking_id_from_order($order);
                if (!$booking_id) return null;
                
                return [
                    'criteria_field' => 'BookingID',
                    'criteria_value' => $booking_id,
                    'module' => 'Events'
                ];
            
            case 'order':
                $booking_id = AT_Zoho_Mapper::get_booking_id_from_order($order);
                return [
                    'criteria_field' => 'Subject',
                    'criteria_value' => 'Order #' . $order->get_id(),
                    'module' => $order->is_paid() ? 'Sales_Orders' : 'Leads'
                ];
            
            default:
                return null;
        }
    }

}

// Initialize the page class
AT_Zoho_Order_Sync_Page::get_instance();
