<?php
/**
 * System Checks Utility
 * 
 * Provides health checks and status information for the plugin
 *
 * @package AT_Bookings_API_Fixes
 * @version 2.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * System Checks Class
 */
class AT_Bookings_System_Checks {
    
    /**
     * Check system requirements
     * 
     * @return array Array of requirement checks
     */
    public static function check_requirements() {
        $checks = array();
        
        // WordPress version
        global $wp_version;
        $checks['wordpress'] = array(
            'label' => __('WordPress Version', 'at-bookings-api-fixes'),
            'required' => '5.0',
            'current' => $wp_version,
            'status' => version_compare($wp_version, '5.0', '>='),
            'message' => sprintf(__('Required: %s or higher', 'at-bookings-api-fixes'), '5.0')
        );
        
        // PHP version
        $php_version = phpversion();
        $checks['php'] = array(
            'label' => __('PHP Version', 'at-bookings-api-fixes'),
            'required' => '7.4',
            'current' => $php_version,
            'status' => version_compare($php_version, '7.4', '>='),
            'message' => sprintf(__('Required: %s or higher', 'at-bookings-api-fixes'), '7.4')
        );
        
        // WooCommerce
        $wc_active = class_exists('WooCommerce');
        $wc_version = $wc_active ? WC()->version : '';
        $checks['woocommerce'] = array(
            'label' => __('WooCommerce', 'at-bookings-api-fixes'),
            'required' => __('Active', 'at-bookings-api-fixes'),
            'current' => $wc_active ? $wc_version : __('Not Active', 'at-bookings-api-fixes'),
            'status' => $wc_active,
            'message' => $wc_active ? __('Active', 'at-bookings-api-fixes') : __('Required plugin not active', 'at-bookings-api-fixes')
        );
        
        // WooCommerce Bookings
        $bookings_active = class_exists('WC_Bookings');
        $checks['wc_bookings'] = array(
            'label' => __('WooCommerce Bookings', 'at-bookings-api-fixes'),
            'required' => __('Recommended', 'at-bookings-api-fixes'),
            'current' => $bookings_active ? __('Active', 'at-bookings-api-fixes') : __('Not Active', 'at-bookings-api-fixes'),
            'status' => $bookings_active,
            'message' => $bookings_active ? __('Active', 'at-bookings-api-fixes') : __('Recommended for booking features', 'at-bookings-api-fixes')
        );
        
        // Memory limit
        $memory_limit = ini_get('memory_limit');
        $memory_bytes = wp_convert_hr_to_bytes($memory_limit);
        $required_memory = 256 * 1024 * 1024; // 256MB
        $checks['memory'] = array(
            'label' => __('PHP Memory Limit', 'at-bookings-api-fixes'),
            'required' => '256M',
            'current' => $memory_limit,
            'status' => $memory_bytes >= $required_memory,
            'message' => sprintf(__('Recommended: %s or higher', 'at-bookings-api-fixes'), '256M')
        );
        
        // Redis
        $redis_active = class_exists('Redis') && function_exists('wp_cache_get');
        $checks['redis'] = array(
            'label' => __('Redis Cache', 'at-bookings-api-fixes'),
            'required' => __('Optional', 'at-bookings-api-fixes'),
            'current' => $redis_active ? __('Active', 'at-bookings-api-fixes') : __('Not Active', 'at-bookings-api-fixes'),
            'status' => true, // Optional, so always pass
            'message' => $redis_active ? __('Object caching active', 'at-bookings-api-fixes') : __('Optional but recommended', 'at-bookings-api-fixes')
        );
        
        return $checks;
    }
    
    /**
     * Get site environment information
     * 
     * @return array Environment details
     */
    public static function get_environment() {
        global $wpdb;
        
        // Detect environment type
        $env_type = 'production';
        if (defined('WP_ENVIRONMENT_TYPE')) {
            $env_type = WP_ENVIRONMENT_TYPE;
        } elseif (defined('WP_LOCAL_DEV') && WP_LOCAL_DEV) {
            $env_type = 'local';
        } elseif (strpos(get_site_url(), 'localhost') !== false || strpos(get_site_url(), '.local') !== false) {
            $env_type = 'local';
        } elseif (strpos(get_site_url(), 'staging') !== false || strpos(get_site_url(), 'dev') !== false) {
            $env_type = 'staging';
        }
        
        return array(
            'type' => $env_type,
            'type_label' => self::get_environment_label($env_type),
            'url' => get_site_url(),
            'database' => $wpdb->dbname,
            'debug_mode' => defined('WP_DEBUG') && WP_DEBUG,
            'debug_log' => defined('WP_DEBUG_LOG') && WP_DEBUG_LOG,
            'php_version' => phpversion(),
            'wp_version' => get_bloginfo('version'),
            'is_multisite' => is_multisite(),
        );
    }
    
    /**
     * Get Zoho status and configuration
     * 
     * @return array Zoho connection details
     */
    public static function get_zoho_status() {
        if (!class_exists('AT_Zoho_CRM')) {
            return array(
                'configured' => false,
                'connected' => false,
                'message' => __('Zoho CRM module not loaded', 'at-bookings-api-fixes')
            );
        }
        
        $client_id = get_option('at_zoho_client_id');
        $client_secret = get_option('at_zoho_client_secret');
        $refresh_token = get_option('at_zoho_refresh_token');
        $domain = get_option('at_zoho_domain', 'com');
        $access_token = get_option('at_zoho_access_token');
        $token_expires = get_option('at_zoho_token_expires', 0);
        
        $configured = !empty($client_id) && !empty($client_secret) && !empty($refresh_token);
        $has_token = !empty($access_token);
        $token_valid = $has_token && $token_expires > time();
        
        // Detect environment (sandbox vs production)
        $zoho_env = 'production';
        if (strpos($domain, 'sandbox') !== false) {
            $zoho_env = 'sandbox';
        }
        
        return array(
            'configured' => $configured,
            'connected' => $configured && $token_valid,
            'has_token' => $has_token,
            'token_valid' => $token_valid,
            'token_expires' => $token_expires,
            'token_expires_human' => $token_expires > 0 ? human_time_diff($token_expires) : __('Never', 'at-bookings-api-fixes'),
            'domain' => $domain,
            'environment' => $zoho_env,
            'environment_label' => $zoho_env === 'sandbox' ? __('Sandbox', 'at-bookings-api-fixes') : __('Production', 'at-bookings-api-fixes'),
            'api_url' => 'https://www.zohoapis.' . $domain . '/crm/v2',
        );
    }
    
    /**
     * Get modules comparison between WP and Zoho
     * 
     * @return array Modules statistics
     */
    public static function get_modules_comparison() {
        // Check cache first
        $cached = get_transient('at_modules_comparison');
        if ($cached !== false) {
            return $cached;
        }
        
        $modules = array();
        
        // Products (regular products with SKU)
        $products_args = array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'meta_query' => array(
                array(
                    'key' => '_sku',
                    'value' => '',
                    'compare' => '!='
                )
            ),
            'fields' => 'ids'
        );
        $products_count = count(get_posts($products_args));
        
        $modules['products'] = array(
            'name' => __('Products', 'at-bookings-api-fixes'),
            'wp_count' => $products_count,
            'zoho_count' => self::get_zoho_record_count('Products'),
            'last_sync' => self::get_last_successful_sync('Products'),
            'icon' => 'dashicons-products'
        );
        
        // Tours/Cycles (ספירת מחזורים מ-1.11.25 ואילך עם הזמנות)
        $cycles_count = self::count_tour_cycles();
        
        $modules['tours'] = array(
            'name' => __('Cycles', 'at-bookings-api-fixes'),
            'wp_count' => $cycles_count,
            'zoho_count' => self::get_zoho_record_count('Events'), // Cycles might be stored as Events
            'last_sync' => self::get_last_successful_sync('Cycles'),
            'icon' => 'dashicons-location'
        );
        
        // Orders (הזמנות ששולמו/בתהליך)
        $orders = wc_orders_count('completed') + wc_orders_count('processing');
        $modules['orders'] = array(
            'name' => __('Orders', 'at-bookings-api-fixes'),
            'wp_count' => $orders,
            'zoho_count' => self::get_zoho_record_count('Sales_Orders'),
            'last_sync' => self::get_last_successful_sync('Sales_Orders'),
            'icon' => 'dashicons-cart'
        );
        
        // Customers
        $customers = count_users();
        $modules['customers'] = array(
            'name' => __('Customers', 'at-bookings-api-fixes'),
            'wp_count' => $customers['total_users'],
            'zoho_count' => self::get_zoho_record_count('Contacts'),
            'last_sync' => self::get_last_successful_sync('Contacts'),
            'icon' => 'dashicons-groups'
        );
        
        // Cache for 5 minutes
        set_transient('at_modules_comparison', $modules, 5 * MINUTE_IN_SECONDS);
        
        return $modules;
    }
    
    /**
     * Count tour cycles from 1.11.25 onwards with bookings
     * 
     * @return int Number of cycles
     */
    private static function count_tour_cycles() {
        if (!function_exists('at_get_future_tours_data')) {
            return 0;
        }
        
        try {
            // Get all cycles from Nov 1, 2025 to far future with bookings only
            $start_date = '2025-11-01';
            $end_date = date('Y-m-d', strtotime('+1 year')); // שנה קדימה
            
            $result = at_get_future_tours_data(
                $start_date, 
                $end_date, 
                '', // all cities
                0,  // all products
                true, // include past
                'booked_only' // only slots with bookings
            );
            
            return isset($result['recordsTotal']) ? (int) $result['recordsTotal'] : 0;
            
        } catch (Exception $e) {
            error_log('AT Bookings: Failed to count tour cycles - ' . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * Get last successful sync time from logs table
     * 
     * @param string $module Module name
     * @return int Unix timestamp of last successful sync, or 0
     */
    private static function get_last_successful_sync($module) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'at_zoho_sync_logs';
        
        // Check if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") != $table_name) {
            return 0;
        }
        
        // Get last successful sync for this module
        $last_sync = $wpdb->get_var($wpdb->prepare(
            "SELECT UNIX_TIMESTAMP(timestamp) 
            FROM {$table_name} 
            WHERE module = %s 
            AND status = 'success' 
            ORDER BY timestamp DESC 
            LIMIT 1",
            $module
        ));
        
        return $last_sync ? (int) $last_sync : 0;
    }
    
    /**
     * Get actual record count from Zoho module
     * Makes API call to get real count from Zoho
     * 
     * @param string $module Zoho module name
     * @return int Record count from Zoho
     */
    private static function get_zoho_record_count($module) {
        // Check cache first
        $cache_key = 'at_zoho_count_' . strtolower($module);
        $cached = get_transient($cache_key);
        if ($cached !== false) {
            return (int) $cached;
        }
        
        // Try to get from Zoho API
        if (!class_exists('AT_Zoho_API')) {
            return 0;
        }
        
        try {
            $api = AT_Zoho_API::get_instance();
            
            // Use reflection to call make_api_request
            $reflection = new ReflectionClass($api);
            $method = $reflection->getMethod('make_api_request');
            $method->setAccessible(true);
            
            // Get first page with just 1 record to extract total count
            $params = array(
                'page' => 1,
                'per_page' => 1
            );
            
            $response = $method->invoke($api, '/' . $module, 'GET', null, $params);
            
            // Extract total count from response
            $count = 0;
            if (isset($response['info']['count'])) {
                $count = (int) $response['info']['count'];
            } elseif (isset($response['info']['more_records']) && $response['info']['more_records'] === true) {
                // If there are more records, estimate based on per_page
                // Actually, Zoho doesn't return total count directly
                // We need to use COQL or count all pages (expensive)
                // For now, return estimated based on more_records flag
                $count = isset($response['data']) && !empty($response['data']) ? 200 : 0; // Placeholder
            } elseif (isset($response['data']) && is_array($response['data'])) {
                // Exact count if less than per_page
                $count = count($response['data']);
            }
            
            // Cache for 15 minutes
            set_transient($cache_key, $count, 15 * MINUTE_IN_SECONDS);
            
            return $count;
            
        } catch (Exception $e) {
            error_log('AT Bookings: Failed to get Zoho count for ' . $module . ' - ' . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * Test Zoho connection
     * 
     * @return array Connection test results
     */
    public static function test_zoho_connection() {
        if (!class_exists('AT_Zoho_API')) {
            return array(
                'success' => false,
                'message' => __('Zoho API class not available', 'at-bookings-api-fixes')
            );
        }
        
        try {
            $api = AT_Zoho_API::get_instance();
            $result = $api->test_connection();
            
            return array(
                'success' => true,
                'message' => __('Connection successful', 'at-bookings-api-fixes'),
                'data' => $result
            );
        } catch (Exception $e) {
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }
    
    /**
     * Get recent sync activity
     * 
     * @param int $limit Number of records to return
     * @return array Recent sync logs
     */
    public static function get_recent_activity($limit = 10) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'at_zoho_sync_logs';
        
        // Check if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") != $table_name) {
            return array();
        }
        
        // Use 'timestamp' column instead of 'created_at'
        $logs = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table_name} ORDER BY timestamp DESC LIMIT %d",
            $limit
        ), ARRAY_A);
        
        return $logs;
    }
    
    /**
     * Get environment label
     * 
     * @param string $env Environment type
     * @return string Translated label
     */
    private static function get_environment_label($env) {
        $labels = array(
            'local' => __('Local Development', 'at-bookings-api-fixes'),
            'development' => __('Development', 'at-bookings-api-fixes'),
            'staging' => __('Staging', 'at-bookings-api-fixes'),
            'production' => __('Production', 'at-bookings-api-fixes'),
        );
        
        return isset($labels[$env]) ? $labels[$env] : ucfirst($env);
    }
    
}

