<?php
/**
 * Admin Notifications Helper
 * 
 * Provides WordPress admin notices instead of alert() dialogs with accessibility support
 * 
 * @package AT_Bookings_API_Fixes
 * @subpackage Admin
 * @since 3.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Bookings_Notifications {
    
    const NOTICE_SUCCESS = 'success';
    const NOTICE_ERROR = 'error';
    const NOTICE_WARNING = 'warning';
    const NOTICE_INFO = 'info';
    
    private static $notices = [];
    private static $js_notices = [];
    
    /**
     * Initialize notifications system
     */
    public static function init() {
        add_action('admin_notices', array(__CLASS__, 'render_admin_notices'));
        add_action('admin_footer', array(__CLASS__, 'render_js_notices'));
        add_action('wp_ajax_at_dismiss_notice', array(__CLASS__, 'ajax_dismiss_notice'));
    }
    
    /**
     * Add admin notice
     * 
     * @param string $message Notice message
     * @param string $type Notice type (success, error, warning, info)
     * @param bool $dismissible Whether notice is dismissible
     * @param string $id Unique notice ID for dismissible notices
     */
    public static function add_notice($message, $type = self::NOTICE_INFO, $dismissible = false, $id = '') {
        self::$notices[] = [
            'message' => $message,
            'type' => $type,
            'dismissible' => $dismissible,
            'id' => $id ?: 'at-notice-' . uniqid()
        ];
    }
    
    /**
     * Add success notice
     * 
     * @param string $message Notice message
     * @param bool $dismissible Whether notice is dismissible
     * @param string $id Unique notice ID
     */
    public static function success($message, $dismissible = true, $id = '') {
        self::add_notice($message, self::NOTICE_SUCCESS, $dismissible, $id);
    }
    
    /**
     * Add error notice
     * 
     * @param string $message Notice message
     * @param bool $dismissible Whether notice is dismissible
     * @param string $id Unique notice ID
     */
    public static function error($message, $dismissible = true, $id = '') {
        self::add_notice($message, self::NOTICE_ERROR, $dismissible, $id);
    }
    
    /**
     * Add warning notice
     * 
     * @param string $message Notice message
     * @param bool $dismissible Whether notice is dismissible
     * @param string $id Unique notice ID
     */
    public static function warning($message, $dismissible = true, $id = '') {
        self::add_notice($message, self::NOTICE_WARNING, $dismissible, $id);
    }
    
    /**
     * Add info notice
     * 
     * @param string $message Notice message
     * @param bool $dismissible Whether notice is dismissible
     * @param string $id Unique notice ID
     */
    public static function info($message, $dismissible = true, $id = '') {
        self::add_notice($message, self::NOTICE_INFO, $dismissible, $id);
    }
    
    /**
     * Add JavaScript notice (for AJAX responses)
     * 
     * @param string $message Notice message
     * @param string $type Notice type
     * @param bool $dismissible Whether notice is dismissible
     * @param bool $speak Whether to use wp.a11y.speak for screen readers
     */
    public static function add_js_notice($message, $type = self::NOTICE_INFO, $dismissible = true, $speak = true) {
        self::$js_notices[] = [
            'message' => $message,
            'type' => $type,
            'dismissible' => $dismissible,
            'speak' => $speak,
            'id' => 'at-js-notice-' . uniqid()
        ];
    }
    
    /**
     * JavaScript success notice
     */
    public static function js_success($message, $dismissible = true, $speak = true) {
        self::add_js_notice($message, self::NOTICE_SUCCESS, $dismissible, $speak);
    }
    
    /**
     * JavaScript error notice
     */
    public static function js_error($message, $dismissible = true, $speak = true) {
        self::add_js_notice($message, self::NOTICE_ERROR, $dismissible, $speak);
    }
    
    /**
     * JavaScript warning notice
     */
    public static function js_warning($message, $dismissible = true, $speak = true) {
        self::add_js_notice($message, self::NOTICE_WARNING, $dismissible, $speak);
    }
    
    /**
     * JavaScript info notice
     */
    public static function js_info($message, $dismissible = true, $speak = true) {
        self::add_js_notice($message, self::NOTICE_INFO, $dismissible, $speak);
    }
    
    /**
     * Render admin notices
     */
    public static function render_admin_notices() {
        foreach (self::$notices as $notice) {
            $classes = ['notice', 'notice-' . $notice['type']];
            
            if ($notice['dismissible']) {
                $classes[] = 'is-dismissible';
            }
            
            printf(
                '<div class="%s" data-notice-id="%s"><p>%s</p></div>',
                esc_attr(implode(' ', $classes)),
                esc_attr($notice['id']),
                wp_kses_post($notice['message'])
            );
        }
        
        // Clear notices after rendering
        self::$notices = [];
    }
    
    /**
     * Render JavaScript notices container and handler
     */
    public static function render_js_notices() {
        if (empty(self::$js_notices)) {
            return;
        }
        
        // Notices container
        echo '<div id="at-js-notices-container" style="position: fixed; top: 32px; right: 20px; z-index: 999999; max-width: 400px;"></div>';
        
        // JavaScript handler
        ?>
        <script type="text/javascript">
        (function($) {
            'use strict';
            
            // AT Notifications object
            window.ATNotify = {
                container: null,
                
                init: function() {
                    this.container = $('#at-js-notices-container');
                    if (!this.container.length) {
                        $('body').append('<div id="at-js-notices-container" style="position: fixed; top: 32px; right: 20px; z-index: 999999; max-width: 400px;"></div>');
                        this.container = $('#at-js-notices-container');
                    }
                },
                
                show: function(message, type, dismissible, speak) {
                    if (!this.container) this.init();
                    
                    type = type || 'info';
                    dismissible = dismissible !== false;
                    speak = speak !== false;
                    
                    var noticeId = 'at-notice-' + Date.now();
                    var classes = 'notice notice-' + type;
                    if (dismissible) classes += ' is-dismissible';
                    
                    var noticeHtml = '<div class="' + classes + '" id="' + noticeId + '" style="margin-bottom: 10px; padding: 12px 15px; background: white; border-left: 4px solid; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">';
                    noticeHtml += '<p style="margin: 0;">' + message + '</p>';
                    if (dismissible) {
                        noticeHtml += '<button type="button" class="notice-dismiss" onclick="ATNotify.dismiss(\'' + noticeId + '\')">';
                        noticeHtml += '<span class="screen-reader-text"><?php esc_html_e('Dismiss this notice', 'at-bookings-api-fixes'); ?></span>';
                        noticeHtml += '</button>';
                    }
                    noticeHtml += '</div>';
                    
                    this.container.prepend(noticeHtml);
                    
                    // Accessibility announcement
                    if (speak && window.wp && window.wp.a11y) {
                        wp.a11y.speak(message);
                    }
                    
                    // Auto-dismiss after 5 seconds for success/info notices
                    if ((type === 'success' || type === 'info') && dismissible) {
                        setTimeout(function() {
                            ATNotify.dismiss(noticeId);
                        }, 5000);
                    }
                    
                    return noticeId;
                },
                
                success: function(message, dismissible, speak) {
                    return this.show(message, 'success', dismissible, speak);
                },
                
                error: function(message, dismissible, speak) {
                    return this.show(message, 'error', dismissible, speak);
                },
                
                warning: function(message, dismissible, speak) {
                    return this.show(message, 'warning', dismissible, speak);
                },
                
                info: function(message, dismissible, speak) {
                    return this.show(message, 'info', dismissible, speak);
                },
                
                dismiss: function(noticeId) {
                    $('#' + noticeId).fadeOut(300, function() {
                        $(this).remove();
                    });
                },
                
                clear: function() {
                    if (this.container) {
                        this.container.empty();
                    }
                }
            };
            
            // Initialize on document ready
            $(document).ready(function() {
                ATNotify.init();
                
                <?php if (!empty(self::$js_notices)): ?>
                // Render queued notices
                <?php foreach (self::$js_notices as $notice): ?>
                ATNotify.show(
                    <?php echo json_encode($notice['message']); ?>,
                    <?php echo json_encode($notice['type']); ?>,
                    <?php echo json_encode($notice['dismissible']); ?>,
                    <?php echo json_encode($notice['speak']); ?>
                );
                <?php endforeach; ?>
                <?php endif; ?>
            });
            
        })(jQuery);
        </script>
        <?php
        
        // Clear JS notices after rendering
        self::$js_notices = [];
    }
    
    /**
     * AJAX handler for dismissing notices
     */
    public static function ajax_dismiss_notice() {
        check_ajax_referer('at_dismiss_notice', 'nonce');
        
        $notice_id = sanitize_text_field($_POST['notice_id'] ?? '');
        
        if ($notice_id) {
            // Store dismissed notice to prevent showing again
            $dismissed = get_user_meta(get_current_user_id(), 'at_dismissed_notices', true) ?: [];
            $dismissed[] = $notice_id;
            update_user_meta(get_current_user_id(), 'at_dismissed_notices', $dismissed);
            
            wp_send_json_success();
        } else {
            wp_send_json_error(__('Invalid notice ID', 'at-bookings-api-fixes'));
        }
    }
    
    /**
     * Check if notice was dismissed by user
     * 
     * @param string $notice_id Notice ID to check
     * @return bool True if dismissed
     */
    public static function is_dismissed($notice_id) {
        $dismissed = get_user_meta(get_current_user_id(), 'at_dismissed_notices', true) ?: [];
        return in_array($notice_id, $dismissed);
    }
    
    /**
     * Clear all dismissed notices for current user
     */
    public static function clear_dismissed() {
        delete_user_meta(get_current_user_id(), 'at_dismissed_notices');
    }
}

// Initialize notifications system
AT_Bookings_Notifications::init();
