<?php
/**
 * Admin Dashboard Page
 * 
 * Main dashboard with system checks, Zoho status, and quick actions
 *
 * @package AT_Bookings_API_Fixes
 * @version 2.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Dashboard Class
 */
class AT_Bookings_Dashboard {
    
    /**
     * Render footer
     */
    public static function render_footer() {
        $last_sync = get_option('at_zoho_last_sync_time', 0);
        $last_sync_type = get_option('at_zoho_last_sync_type', 'manual');
        
        ?>
        <div class="at-admin-footer">
            <div class="at-footer-content">
                <div class="at-footer-left">
                    <strong>AT Bookings & CRM Sync</strong>
                    <?php printf(__('Version %s', 'at-bookings-api-fixes'), AT_BOOKINGS_API_FIXES_VERSION); ?>
                    &nbsp;|&nbsp;
                    <?php printf(
                        __('Developed by %s', 'at-bookings-api-fixes'),
                        '<a href="https://amit-trabelsi.co.il" target="_blank">Amit Trabelsi</a>'
                    ); ?>
                </div>
                <div class="at-footer-right">
                    <?php if ($last_sync > 0): ?>
                        <span class="at-last-sync">
                            <span class="dashicons dashicons-update"></span>
                            <?php 
                            $sync_type_label = $last_sync_type === 'automatic' 
                                ? __('Last Auto Sync', 'at-bookings-api-fixes') 
                                : __('Last Sync', 'at-bookings-api-fixes');
                            echo esc_html($sync_type_label) . ': ';
                            echo '<strong>' . esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $last_sync)) . '</strong>';
                            echo ' <small>(' . esc_html(human_time_diff($last_sync)) . ' ' . esc_html__('ago', 'at-bookings-api-fixes') . ')</small>';
                            ?>
                        </span>
                    <?php else: ?>
                        <span class="at-last-sync at-no-sync">
                            <span class="dashicons dashicons-warning"></span>
                            <?php esc_html_e('No sync performed yet', 'at-bookings-api-fixes'); ?>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render dashboard page
     */
    public static function render() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'at-bookings-api-fixes'));
        }
        
        $checks = AT_Bookings_System_Checks::check_requirements();
        $environment = AT_Bookings_System_Checks::get_environment();
        $zoho_status = AT_Bookings_System_Checks::get_zoho_status();
        $modules = AT_Bookings_System_Checks::get_modules_comparison();
        $recent_activity = AT_Bookings_System_Checks::get_recent_activity(10);
        
        ?>
        <div class="wrap at-bookings-dashboard">
            
            <!-- Header -->
            <div class="at-dashboard-header">
                <h1><?php esc_html_e('AT Bookings & CRM Sync', 'at-bookings-api-fixes'); ?></h1>
                <span class="at-version-badge">
                    <?php printf(esc_html__('Version %s', 'at-bookings-api-fixes'), AT_BOOKINGS_API_FIXES_VERSION); ?>
                </span>
            </div>
            
            <p class="at-dashboard-intro">
                <?php esc_html_e('Advanced booking management system with Zoho CRM integration, performance optimization, and comprehensive API.', 'at-bookings-api-fixes'); ?>
            </p>
            
            <!-- System Requirements Check -->
            <div class="at-dashboard-section at-requirements-section">
                <h2>
                    <span class="dashicons dashicons-yes-alt"></span>
                    <?php esc_html_e('System Requirements', 'at-bookings-api-fixes'); ?>
                </h2>
                
                <div class="at-requirements-grid">
                    <?php foreach ($checks as $key => $check): ?>
                        <div class="at-requirement-item <?php echo $check['status'] ? 'at-status-pass' : 'at-status-fail'; ?>">
                            <span class="at-requirement-icon">
                                <?php echo $check['status'] ? '✓' : '✗'; ?>
                            </span>
                            <div class="at-requirement-info">
                                <strong><?php echo esc_html($check['label']); ?></strong>
                                <span class="at-requirement-value">
                                    <?php echo esc_html($check['current']); ?>
                                </span>
                                <small><?php echo esc_html($check['message']); ?></small>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <!-- Environment Display -->
            <div class="at-dashboard-section at-environment-section">
                <h2>
                    <span class="dashicons dashicons-admin-site-alt3"></span>
                    <?php esc_html_e('Environment Information', 'at-bookings-api-fixes'); ?>
                </h2>
                
                <div class="at-environment-grid">
                    <!-- Site Environment -->
                    <div class="at-environment-box">
                        <h3><?php esc_html_e('Site Environment', 'at-bookings-api-fixes'); ?></h3>
                        <table class="at-info-table">
                            <tr>
                                <td><?php esc_html_e('Environment Type', 'at-bookings-api-fixes'); ?></td>
                                <td>
                                    <span class="at-env-badge at-env-<?php echo esc_attr($environment['type']); ?>">
                                        <?php echo esc_html($environment['type_label']); ?>
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td><?php esc_html_e('Site URL', 'at-bookings-api-fixes'); ?></td>
                                <td><code class="at-code" dir="ltr"><?php echo esc_html($environment['url']); ?></code></td>
                            </tr>
                            <tr>
                                <td><?php esc_html_e('Database', 'at-bookings-api-fixes'); ?></td>
                                <td><code><?php echo esc_html($environment['database']); ?></code></td>
                            </tr>
                            <tr>
                                <td><?php esc_html_e('Debug Mode', 'at-bookings-api-fixes'); ?></td>
                                <td>
                                    <?php if ($environment['debug_mode']): ?>
                                        <span class="at-badge at-badge-warning"><?php esc_html_e('Enabled', 'at-bookings-api-fixes'); ?></span>
                                    <?php else: ?>
                                        <span class="at-badge at-badge-success"><?php esc_html_e('Disabled', 'at-bookings-api-fixes'); ?></span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                    <!-- Zoho Environment -->
                    <div class="at-environment-box">
                        <h3><?php esc_html_e('Zoho Environment', 'at-bookings-api-fixes'); ?></h3>
                        <table class="at-info-table">
                            <tr>
                                <td><?php esc_html_e('Environment Type', 'at-bookings-api-fixes'); ?></td>
                                <td>
                                    <span class="at-env-badge at-env-<?php echo esc_attr($zoho_status['environment']); ?>">
                                        <?php echo esc_html($zoho_status['environment_label']); ?>
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td><?php esc_html_e('Domain', 'at-bookings-api-fixes'); ?></td>
                                <td><code class="at-code" dir="ltr">.<?php echo esc_html($zoho_status['domain']); ?></code></td>
                            </tr>
                            <tr>
                                <td><?php esc_html_e('Connection Status', 'at-bookings-api-fixes'); ?></td>
                                <td>
                                    <?php if ($zoho_status['connected']): ?>
                                        <span class="at-badge at-badge-success">
                                            ✓ <?php esc_html_e('Connected', 'at-bookings-api-fixes'); ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="at-badge at-badge-error">
                                            ✗ <?php esc_html_e('Not Connected', 'at-bookings-api-fixes'); ?>
                                        </span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <td><?php esc_html_e('Last Token Refresh', 'at-bookings-api-fixes'); ?></td>
                                <td>
                                    <?php if ($zoho_status['token_expires'] > 0): ?>
                                        <?php 
                                        $time_ago = human_time_diff($zoho_status['token_expires']);
                                        printf(esc_html__('%s ago', 'at-bookings-api-fixes'), $time_ago);
                                        ?>
                                    <?php else: ?>
                                        <?php esc_html_e('Never', 'at-bookings-api-fixes'); ?>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- Zoho Connection Health -->
            <div class="at-dashboard-section at-health-section">
                <h2>
                    <span class="dashicons dashicons-heart"></span>
                    <?php esc_html_e('Zoho Connection Health', 'at-bookings-api-fixes'); ?>
                </h2>
                
                <div class="at-health-checks">
                    <div class="at-health-item <?php echo $zoho_status['configured'] ? 'at-status-pass' : 'at-status-fail'; ?>">
                        <span class="at-health-icon"><?php echo $zoho_status['configured'] ? '✓' : '✗'; ?></span>
                        <span><?php esc_html_e('API Credentials Configured', 'at-bookings-api-fixes'); ?></span>
                    </div>
                    
                    <div class="at-health-item <?php echo $zoho_status['has_token'] ? 'at-status-pass' : 'at-status-fail'; ?>">
                        <span class="at-health-icon"><?php echo $zoho_status['has_token'] ? '✓' : '✗'; ?></span>
                        <span><?php esc_html_e('Access Token Available', 'at-bookings-api-fixes'); ?></span>
                    </div>
                    
                    <div class="at-health-item <?php echo $zoho_status['token_valid'] ? 'at-status-pass' : 'at-status-fail'; ?>">
                        <span class="at-health-icon"><?php echo $zoho_status['token_valid'] ? '✓' : '✗'; ?></span>
                        <span><?php esc_html_e('Access Token Valid', 'at-bookings-api-fixes'); ?></span>
                    </div>
                    
                    <div class="at-health-item <?php echo $zoho_status['connected'] ? 'at-status-pass' : 'at-status-pending'; ?>">
                        <span class="at-health-icon"><?php echo $zoho_status['connected'] ? '✓' : '?'; ?></span>
                        <span><?php esc_html_e('Can Reach Zoho API', 'at-bookings-api-fixes'); ?></span>
                    </div>
                </div>
                
                <?php if ($zoho_status['connected']): ?>
                    <div class="at-api-url">
                        <strong><?php esc_html_e('API Endpoint:', 'at-bookings-api-fixes'); ?></strong>
                        <code class="at-code" dir="ltr"><?php echo esc_html($zoho_status['api_url']); ?></code>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Quick Actions -->
            <div class="at-dashboard-section at-actions-section">
                <h2>
                    <span class="dashicons dashicons-controls-play"></span>
                    <?php esc_html_e('Quick Actions', 'at-bookings-api-fixes'); ?>
                </h2>
                
                <div class="at-quick-actions">
                    <button type="button" class="button button-primary at-action-btn" id="at-test-connection">
                        <span class="dashicons dashicons-update-alt"></span>
                        <?php esc_html_e('Test Zoho Connection', 'at-bookings-api-fixes'); ?>
                    </button>
                    
                    <button type="button" class="button at-action-btn" id="at-refresh-token">
                        <span class="dashicons dashicons-image-rotate"></span>
                        <?php esc_html_e('Refresh Access Token', 'at-bookings-api-fixes'); ?>
                    </button>
                    
                    <a href="<?php echo esc_url(admin_url('admin.php?page=at-bookings-zoho-logs')); ?>" class="button at-action-btn">
                        <span class="dashicons dashicons-list-view"></span>
                        <?php esc_html_e('View Sync Logs', 'at-bookings-api-fixes'); ?>
                    </a>
                    
                    <button type="button" class="button at-action-btn" id="at-clear-cache">
                        <span class="dashicons dashicons-trash"></span>
                        <?php esc_html_e('Clear Cache', 'at-bookings-api-fixes'); ?>
                    </button>
                    
                    <a href="<?php echo esc_url(admin_url('admin.php?page=at-bookings-zoho-settings')); ?>" class="button at-action-btn">
                        <span class="dashicons dashicons-admin-settings"></span>
                        <?php esc_html_e('Zoho Settings', 'at-bookings-api-fixes'); ?>
                    </a>
                    
                    <a href="<?php echo esc_url(admin_url('admin.php?page=at-bookings-system-status')); ?>" class="button at-action-btn">
                        <span class="dashicons dashicons-info"></span>
                        <?php esc_html_e('System Status', 'at-bookings-api-fixes'); ?>
                    </a>
                    
                    <button type="button" class="button button-secondary at-action-btn" id="at-populate-slots">
                        <span class="dashicons dashicons-calendar-alt"></span>
                        <?php esc_html_e('Generate Initial Slots', 'at-bookings-api-fixes'); ?>
                    </button>
                </div>
            </div>
            
            <!-- Modules Comparison -->
            <?php if (!empty($modules)): ?>
            <div class="at-dashboard-section at-modules-section">
                <h2>
                    <span class="dashicons dashicons-database"></span>
                    <?php esc_html_e('Modules Comparison', 'at-bookings-api-fixes'); ?>
                </h2>
                
                <table class="widefat at-modules-table">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('Module', 'at-bookings-api-fixes'); ?></th>
                            <th><?php esc_html_e('WP Records', 'at-bookings-api-fixes'); ?></th>
                            <th><?php esc_html_e('Zoho Records', 'at-bookings-api-fixes'); ?></th>
                            <th><?php esc_html_e('Last Sync', 'at-bookings-api-fixes'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($modules as $key => $module): ?>
                            <?php 
                            $last_sync_text = $module['last_sync'] > 0 
                                ? human_time_diff($module['last_sync']) . ' ' . __('ago', 'at-bookings-api-fixes')
                                : __('Never', 'at-bookings-api-fixes');
                            ?>
                            <tr data-module-key="<?php echo esc_attr($key); ?>">
                                <td>
                                    <span class="dashicons <?php echo esc_attr($module['icon']); ?>"></span>
                                    <strong><?php echo esc_html($module['name']); ?></strong>
                                </td>
                                <td><?php echo number_format_i18n($module['wp_count']); ?></td>
                                <td><?php echo number_format_i18n($module['zoho_count']); ?></td>
                                <td><?php echo esc_html($last_sync_text); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
            
            <!-- Recent Activity -->
            <?php if (!empty($recent_activity)): ?>
            <div class="at-dashboard-section at-activity-section">
                <h2>
                    <span class="dashicons dashicons-clock"></span>
                    <?php esc_html_e('Recent Sync Activity', 'at-bookings-api-fixes'); ?>
                </h2>
                
                <table class="widefat at-activity-table">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('Time', 'at-bookings-api-fixes'); ?></th>
                            <th><?php esc_html_e('Operation', 'at-bookings-api-fixes'); ?></th>
                            <th><?php esc_html_e('Module', 'at-bookings-api-fixes'); ?></th>
                            <th><?php esc_html_e('Status', 'at-bookings-api-fixes'); ?></th>
                            <th><?php esc_html_e('Details', 'at-bookings-api-fixes'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_activity as $log): ?>
                            <tr>
                                <td><?php echo esc_html(mysql2date(get_option('date_format') . ' ' . get_option('time_format'), $log['timestamp'])); ?></td>
                                <td><?php echo esc_html(isset($log['action']) ? $log['action'] : $log['operation']); ?></td>
                                <td><?php echo esc_html($log['module']); ?></td>
                                <td>
                                    <?php if ($log['status'] === 'success'): ?>
                                        <span class="at-badge at-badge-success"><?php esc_html_e('Success', 'at-bookings-api-fixes'); ?></span>
                                    <?php else: ?>
                                        <span class="at-badge at-badge-error"><?php esc_html_e('Error', 'at-bookings-api-fixes'); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if (!empty($log['error_message'])): ?>
                                        <small><?php echo esc_html($log['error_message']); ?></small>
                                    <?php else: ?>
                                        <a href="<?php echo esc_url(admin_url('admin.php?page=at-bookings-zoho-logs&log_id=' . $log['id'])); ?>">
                                            <?php esc_html_e('View Details', 'at-bookings-api-fixes'); ?>
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <p class="at-view-all-logs">
                    <a href="<?php echo esc_url(admin_url('admin.php?page=at-bookings-zoho-logs')); ?>" class="button">
                        <?php esc_html_e('View All Logs', 'at-bookings-api-fixes'); ?> →
                    </a>
                </p>
            </div>
            <?php endif; ?>
            
            <?php self::render_footer(); ?>
            
        </div>
        <?php
    }
}

