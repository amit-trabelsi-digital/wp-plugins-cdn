<?php
// Settings page for Zoho Webhook configuration

add_action('admin_init', function() {
    register_setting('at_zoho_settings', 'at_zoho_webhook_secret', array(
        'type' => 'string',
        'sanitize_callback' => 'sanitize_text_field',
        'default' => wp_generate_password(32, false)
    ));
});

// הוסף section ב-Tools > ZOHO CRM
add_action('at_zoho_settings_page_content', function() {
    $secret = get_option('at_zoho_webhook_secret', '');
    
    if (empty($secret)) {
        $secret = wp_generate_password(32, false);
        update_option('at_zoho_webhook_secret', $secret);
    }
    ?>
    <h3><?php _e('Webhook Configuration', 'at-bookings-api-fixes'); ?></h3>
    <table class="form-table">
        <tr>
            <th><?php _e('Webhook Secret', 'at-bookings-api-fixes'); ?></th>
            <td>
                <input type="text" class="regular-text" value="<?php echo esc_attr($secret); ?>" readonly onclick="this.select()">
                <p class="description">
                    <?php _e('Use this secret in Zoho webhooks for authentication', 'at-bookings-api-fixes'); ?>
                </p>
            </td>
        </tr>
        <tr>
            <th><?php _e('Webhook URLs', 'at-bookings-api-fixes'); ?></th>
            <td>
                <code><?php echo esc_html(rest_url('at/v1/zoho-webhook/order-update')); ?></code><br>
                <code><?php echo esc_html(rest_url('at/v1/zoho-webhook/cycle-update')); ?></code>
            </td>
        </tr>
    </table>
    <?php
});

