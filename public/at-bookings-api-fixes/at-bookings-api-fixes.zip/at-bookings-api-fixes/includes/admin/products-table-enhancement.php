<?php
/**
 * Products Table Enhancement
 * 
 * Adds available tours count column to WooCommerce products table
 * 
 * @package AT_Bookings_API_Fixes
 * @subpackage Admin
 * @since 3.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Bookings_Products_Table_Enhancement {
    
    /**
     * Initialize enhancements
     */
    public static function init() {
        // Add custom column to products table
        add_filter('manage_edit-product_columns', array(__CLASS__, 'add_available_tours_column'));
        add_action('manage_product_posts_custom_column', array(__CLASS__, 'render_available_tours_column'), 10, 2);
        
        // Make column sortable
        add_filter('manage_edit-product_sortable_columns', array(__CLASS__, 'make_available_tours_sortable'));
        add_action('pre_get_posts', array(__CLASS__, 'handle_available_tours_sorting'));
    }
    
    /**
     * Add available tours column to products table
     * 
     * @param array $columns Existing columns
     * @return array Modified columns
     */
    public static function add_available_tours_column($columns) {
        // Insert after 'product_type' column
        $new_columns = [];
        
        foreach ($columns as $key => $title) {
            $new_columns[$key] = $title;
            
            if ($key === 'product_type') {
                $new_columns['available_tours'] = __('Available Tours (30 days)', 'at-bookings-api-fixes');
                $new_columns['zoho_sync_status'] = __('Zoho Sync', 'at-bookings-api-fixes');
            }
        }
        
        return $new_columns;
    }
    
    /**
     * Render available tours column content
     * 
     * @param string $column Column name
     * @param int $post_id Product ID
     */
    public static function render_available_tours_column($column, $post_id) {
        if ($column === 'zoho_sync_status') {
            self::render_zoho_sync_status_column($post_id);
            return;
        }
        
        if ($column !== 'available_tours') {
            return;
        }
        
        $product = wc_get_product($post_id);
        
        if (!$product || $product->get_type() !== 'booking') {
            echo '<span style="color: #999;">—</span>';
            return;
        }
        
        $available_count = self::get_available_tours_count($post_id);
        
        if ($available_count > 0) {
            echo '<span class="at-tours-count at-tours-available">';
            echo '<strong>' . $available_count . '</strong>';
            echo '<br><small style="color: #0073aa;">' . __('tours available', 'at-bookings-api-fixes') . '</small>';
            echo '</span>';
        } else {
            echo '<span class="at-tours-count at-tours-none">';
            echo '<strong>0</strong>';
            echo '<br><small style="color: #d63638;">' . __('no tours', 'at-bookings-api-fixes') . '</small>';
            echo '</span>';
        }
        
        // Add quick action link
        $manage_url = admin_url('admin.php?page=at-slots-management&product_id=' . $post_id);
        echo '<br><a href="' . esc_url($manage_url) . '" style="font-size: 11px;">' . __('Manage Slots', 'at-bookings-api-fixes') . '</a>';
    }
    
    /**
     * Render Zoho sync status column
     * 
     * @param int $product_id Product ID
     */
    private static function render_zoho_sync_status_column($product_id) {
        $sync_state = get_post_meta($product_id, '_at_zoho_sync_state', true);
        $sync_state = $sync_state ? json_decode($sync_state, true) : [];
        
        if (empty($sync_state)) {
            echo '<span style="color: #999;">—</span>';
            return;
        }
        
        if (!empty($sync_state['synced']) && $sync_state['status'] === 'success') {
            echo '<span style="color: #28a745; font-weight: bold;">';
            echo '<strong>✓ ' . __('Synced', 'at-bookings-api-fixes') . '</strong>';
            
            if (!empty($sync_state['zoho_id'])) {
                $zoho_link = 'https://crm.zoho.com/app/records/Products/' . esc_attr($sync_state['zoho_id']);
                echo '<br><a href="' . esc_url($zoho_link) . '" target="_blank" style="font-size: 11px;">';
                echo __('View in Zoho', 'at-bookings-api-fixes') . ' <span class="dashicons dashicons-external" style="font-size: 10px; width: 10px; height: 10px;"></span>';
                echo '</a>';
            }
            
            if (!empty($sync_state['last_sync'])) {
                echo '<br><small style="color: #666; font-size: 10px;">';
                echo __('Last sync: ', 'at-bookings-api-fixes') . esc_html(date('M d, H:i', strtotime($sync_state['last_sync'])));
                echo '</small>';
            }
            
            echo '</span>';
        } else {
            echo '<span style="color: #dc3545; font-weight: bold;">';
            echo '<strong>✗ ' . __('Failed', 'at-bookings-api-fixes') . '</strong>';
            
            if (!empty($sync_state['error'])) {
                echo '<br><small style="color: #666; font-size: 10px;">';
                echo esc_html(substr($sync_state['error'], 0, 50));
                if (strlen($sync_state['error']) > 50) {
                    echo '...';
                }
                echo '</small>';
            }
            
            echo '</span>';
        }
    }
    
    /**
     * Get available tours count for next 30 days
     * 
     * @param int $product_id Product ID
     * @return int Available tours count
     */
    private static function get_available_tours_count($product_id) {
        global $wpdb;
        
        // Check cache first
        $cache_key = 'at_available_tours_' . $product_id;
        $cached_count = wp_cache_get($cache_key);
        
        if ($cached_count !== false) {
            return (int) $cached_count;
        }
        
        $slots_table = $wpdb->prefix . 'at_booking_slots';
        
        // Count available slots in next 30 days
        $count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) 
                FROM {$slots_table} 
                WHERE product_id = %d 
                AND status = 'active'
                AND slot_start >= NOW()
                AND slot_start <= DATE_ADD(NOW(), INTERVAL 30 DAY)
                AND (current_bookings < max_capacity OR max_capacity = 0)",
                $product_id
            )
        );
        
        $count = (int) $count;
        
        // Cache for 5 minutes
        wp_cache_set($cache_key, $count, '', 300);
        
        return $count;
    }
    
    /**
     * Make available tours column sortable
     * 
     * @param array $columns Sortable columns
     * @return array Modified columns
     */
    public static function make_available_tours_sortable($columns) {
        $columns['available_tours'] = 'available_tours';
        return $columns;
    }
    
    /**
     * Handle sorting by available tours
     * 
     * @param WP_Query $query Main query
     */
    public static function handle_available_tours_sorting($query) {
        if (!is_admin() || !$query->is_main_query()) {
            return;
        }
        
        $orderby = $query->get('orderby');
        
        if ($orderby === 'available_tours') {
            global $wpdb;
            
            $slots_table = $wpdb->prefix . 'at_booking_slots';
            
            // Join with slots table for sorting
            add_filter('posts_join', function($join) use ($wpdb, $slots_table) {
                return $join . " LEFT JOIN (
                    SELECT product_id, COUNT(*) as available_count
                    FROM {$slots_table}
                    WHERE status = 'active'
                    AND slot_start >= NOW()
                    AND slot_start <= DATE_ADD(NOW(), INTERVAL 30 DAY)
                    AND (current_bookings < max_capacity OR max_capacity = 0)
                    GROUP BY product_id
                ) as slots_count ON {$wpdb->posts}.ID = slots_count.product_id";
            });
            
            add_filter('posts_orderby', function($orderby) use ($wpdb) {
                $order = $query->get('order') === 'asc' ? 'ASC' : 'DESC';
                return "COALESCE(slots_count.available_count, 0) {$order}";
            });
        }
    }
    
    /**
     * Clear available tours cache for product
     * 
     * @param int $product_id Product ID
     */
    public static function clear_tours_cache($product_id) {
        wp_cache_delete('at_available_tours_' . $product_id);
    }
    
    /**
     * Clear all tours cache
     */
    public static function clear_all_tours_cache() {
        global $wpdb;
        
        // Get all booking product IDs
        $product_ids = $wpdb->get_col(
            "SELECT p.ID FROM {$wpdb->posts} p
            JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
            WHERE p.post_type = 'product'
            AND pm.meta_key = '_virtual'
            AND pm.meta_value = 'yes'"
        );
        
        foreach ($product_ids as $product_id) {
            self::clear_tours_cache($product_id);
        }
    }
}

// Initialize enhancements
AT_Bookings_Products_Table_Enhancement::init();

// Clear cache when slots are updated
add_action('at_slots_updated', function($product_id) {
    AT_Bookings_Products_Table_Enhancement::clear_tours_cache($product_id);
});
