<?php
/**
 * Cycle Management — open booking cycles, registrant counts, and closing
 *
 * A "cycle" (מחזור) = one bookable date/time block of a WooCommerce Bookings
 * product (from $product->get_blocks_in_range()).
 *
 * Features:
 *  - Admin screen listing all open future cycles with paid-registrant counts,
 *    filterable to cycles starting within 24h / 48h / 72h.
 *  - Close a cycle for sale (single or bulk) by adding a high-priority
 *    `custom:daterange` / `bookable=no` rule to the product's
 *    `_wc_booking_availability` (reversible — we tag what we closed).
 *  - Daily cron (+ "Run Now" button, identical logic) that auto-closes cycles
 *    with ZERO paid registrants that start within the next 48 hours.
 *
 * Registrant count counts wc_booking posts in status confirmed/paid/complete
 * only (matches the rest of the plugin's occupancy logic).
 *
 * @package AT_Bookings_API_Fixes
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AT_Cycle_Management {

	private static $instance = null;

	/** Daily cron hook. */
	const CRON_HOOK = 'at_daily_close_empty_cycles';

	/** Option storing the last auto-run report. */
	const OPT_LAST_RUN = 'at_cycle_autoclose_last_run';

	/** How many days ahead to scan for cycles. */
	const SCAN_DAYS = 14;

	/** Auto-close window in hours. */
	const AUTO_CLOSE_HOURS = 48;

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		// Cron handler (registered always, even on front-end requests).
		add_action( self::CRON_HOOK, array( $this, 'run_auto_close' ) );

		// Self-heal: ensure the daily event is scheduled even if the plugin
		// was already active when this feature shipped (activation hook only
		// fires on (re)activation).
		add_action( 'init', array( __CLASS__, 'schedule_cron' ) );

		// AJAX (admin only by nature of wp_ajax_).
		add_action( 'wp_ajax_at_cycles_list', array( $this, 'ajax_list' ) );
		add_action( 'wp_ajax_at_cycles_close', array( $this, 'ajax_close' ) );
		add_action( 'wp_ajax_at_cycles_run_autoclose', array( $this, 'ajax_run_autoclose' ) );
	}

	/* ===================================================================== */
	/* Cron scheduling (called from plugin activation/deactivation)          */
	/* ===================================================================== */

	public static function schedule_cron() {
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			// 03:00 Asia/Jerusalem today/tomorrow.
			$ts = strtotime( 'tomorrow 03:00' );
			wp_schedule_event( $ts, 'daily', self::CRON_HOOK );
		}
	}

	public static function unschedule_cron() {
		$ts = wp_next_scheduled( self::CRON_HOOK );
		if ( $ts ) {
			wp_unschedule_event( $ts, self::CRON_HOOK );
		}
		wp_clear_scheduled_hook( self::CRON_HOOK );
	}

	/* ===================================================================== */
	/* Data layer                                                            */
	/* ===================================================================== */

	/**
	 * Build the list of open future cycles.
	 *
	 * @param int $within_hours 0 = all (next SCAN_DAYS days); otherwise only
	 *                          cycles starting within this many hours.
	 * @return array[] each: product_id, product_name, city, date, start_time,
	 *                 end_time, datetime, starts_in_hours, registrants,
	 *                 max_capacity, is_closed
	 */
	public function get_open_cycles( $within_hours = 0 ) {
		$now    = current_time( 'timestamp' );
		$scan_s = $now;
		$scan_e = strtotime( '+' . self::SCAN_DAYS . ' days', $now );

		$products = wc_get_products(
			array(
				'type'   => 'booking',
				'limit'  => -1,
				'status' => 'publish',
			)
		);

		$cycles = array();

		foreach ( $products as $product ) {
			if ( ! method_exists( $product, 'get_blocks_in_range' ) ) {
				continue;
			}

			$product_id = $product->get_id();
			$city       = $this->get_product_city( $product_id );
			$max_cap    = (int) get_post_meta( $product_id, '_wc_booking_max_persons_group', true );
			if ( ! $max_cap ) {
				$max_cap = (int) get_post_meta( $product_id, '_wc_booking_max_persons', true );
			}

			$registrants_map = $this->get_registrants_map( $product_id, $scan_s, $scan_e );
			$blocks          = (array) $product->get_blocks_in_range( $scan_s, $scan_e );

			foreach ( $blocks as $block_ts ) {
				if ( $block_ts <= $now ) {
					continue; // past — skip
				}

				$starts_in = ( $block_ts - $now ) / 3600; // hours, float
				if ( $within_hours > 0 && $starts_in > $within_hours ) {
					continue;
				}

				$date  = date( 'Y-m-d', $block_ts );
				$time  = date( 'H:i:s', $block_ts );
				$key   = $date . '_' . $time;
				$count = isset( $registrants_map[ $key ] ) ? (int) $registrants_map[ $key ] : 0;

				// Duration -> end time (for the close rule + display).
				$end_ts = $this->block_end_timestamp( $product_id, $block_ts );

				$cycles[] = array(
					'product_id'      => $product_id,
					'product_name'    => $product->get_name(),
					'city'            => $city,
					'date'            => $date,
					'start_time'      => substr( $time, 0, 5 ),
					'end_time'        => date( 'H:i', $end_ts ),
					'datetime'        => $date . ' ' . substr( $time, 0, 5 ),
					'starts_in_hours' => round( $starts_in, 1 ),
					'registrants'     => $count,
					'max_capacity'    => $max_cap,
					'is_closed'       => $this->is_cycle_closed( $product_id, $date, substr( $time, 0, 5 ) ),
				);
			}
		}

		// Sort by soonest first.
		usort(
			$cycles,
			function ( $a, $b ) {
				return strcmp( $a['datetime'], $b['datetime'] );
			}
		);

		return $cycles;
	}

	/**
	 * Map of "Y-m-d_H:i:s" => total paid persons for a product within a range.
	 * Mirrors the proven counting logic in occupancy.php (serialized persons,
	 * varied date formats), counting confirmed/paid/complete only.
	 */
	private function get_registrants_map( $product_id, $range_start_ts, $range_end_ts ) {
		global $wpdb;

		$start_str = date( 'YmdHis', $range_start_ts );
		$end_str   = date( 'YmdHis', $range_end_ts );
		$start_d   = date( 'Y-m-d', $range_start_ts );
		$end_d     = date( 'Y-m-d', $range_end_ts );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT p.ID AS booking_id,
				        pm1.meta_value AS start_raw,
				        pm3.meta_value AS persons,
				        pm5.meta_value AS persons_total
				 FROM {$wpdb->posts} p
				 INNER JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = '_booking_start'
				 INNER JOIN {$wpdb->postmeta} pm4 ON p.ID = pm4.post_id AND pm4.meta_key = '_booking_product_id'
				 LEFT  JOIN {$wpdb->postmeta} pm3 ON p.ID = pm3.post_id AND pm3.meta_key = '_booking_persons'
				 LEFT  JOIN {$wpdb->postmeta} pm5 ON p.ID = pm5.post_id AND pm5.meta_key = '_booking_persons_total'
				 WHERE p.post_type = 'wc_booking'
				   AND p.post_status IN ('confirmed','paid','complete')
				   AND pm4.meta_value = %d
				   AND (
				        (pm1.meta_value >= %s AND pm1.meta_value <= %s)
				        OR (DATE(pm1.meta_value) >= %s AND DATE(pm1.meta_value) <= %s)
				   )",
				$product_id,
				$start_str,
				$end_str,
				$start_d,
				$end_d
			),
			ARRAY_A
		);

		$map = array();
		foreach ( (array) $rows as $b ) {
			$raw = $b['start_raw'];
			if ( is_numeric( $raw ) && strlen( $raw ) >= 14 ) {
				$d = substr( $raw, 0, 4 ) . '-' . substr( $raw, 4, 2 ) . '-' . substr( $raw, 6, 2 );
				$t = substr( $raw, 8, 2 ) . ':' . substr( $raw, 10, 2 ) . ':' . substr( $raw, 12, 2 );
			} elseif ( is_numeric( $raw ) && strlen( $raw ) <= 11 ) {
				$d = date( 'Y-m-d', (int) $raw );
				$t = date( 'H:i:s', (int) $raw );
			} else {
				$ts = strtotime( $raw );
				if ( ! $ts ) {
					continue;
				}
				$d = date( 'Y-m-d', $ts );
				$t = date( 'H:i:s', $ts );
			}

			$persons = 0;
			if ( is_numeric( $b['persons'] ) ) {
				$persons = (int) $b['persons'];
			} else {
				$pd = maybe_unserialize( $b['persons'] );
				if ( is_array( $pd ) ) {
					$persons = array_sum( array_map( 'intval', $pd ) );
				}
			}
			if ( 0 === $persons && ! empty( $b['persons_total'] ) ) {
				$persons = (int) $b['persons_total'];
			}
			$persons = max( 1, $persons );

			$key = $d . '_' . $t;
			if ( ! isset( $map[ $key ] ) ) {
				$map[ $key ] = 0;
			}
			$map[ $key ] += $persons;
		}

		return $map;
	}

	/** Resolve a block's end timestamp from product duration. */
	private function block_end_timestamp( $product_id, $start_ts ) {
		$duration = (int) get_post_meta( $product_id, '_wc_booking_duration', true );
		$unit     = get_post_meta( $product_id, '_wc_booking_duration_unit', true );
		if ( $duration <= 0 ) {
			$duration = ( 'hour' === $unit ) ? 2 : 120;
		}
		$seconds = ( 'hour' === $unit ) ? $duration * 3600 : $duration * 60;
		return $start_ts + $seconds;
	}

	/** City resolution — mirrors occupancy.php fallback chain. */
	private function get_product_city( $product_id ) {
		$city = '';
		if ( function_exists( 'get_field' ) ) {
			$city = get_field( 'TOUR_CITY', $product_id );
		}
		foreach ( array( 'tour_city', '_tour_city', 'TOUR_CITY' ) as $k ) {
			if ( empty( $city ) ) {
				$city = get_post_meta( $product_id, $k, true );
			}
		}
		return $city ? $city : 'לא צוין';
	}

	/* ===================================================================== */
	/* Close / reopen a cycle (WC Bookings availability rule)                */
	/* ===================================================================== */

	private function closed_meta_key( $date, $start_time ) {
		return '_at_cycle_closed_' . $date . '_' . str_replace( ':', '', $start_time );
	}

	public function is_cycle_closed( $product_id, $date, $start_time ) {
		return (bool) get_post_meta( $product_id, $this->closed_meta_key( $date, $start_time ), true );
	}

	/**
	 * Close a single cycle for sale by prepending a high-priority
	 * "not bookable" custom:daterange rule to the product availability.
	 *
	 * @return array { success, message }
	 */
	public function close_cycle( $product_id, $date, $start_time, $end_time, $source = 'manual' ) {
		$product_id = (int) $product_id;
		$product    = wc_get_product( $product_id );
		if ( ! $product ) {
			return array( 'success' => false, 'message' => 'מוצר לא נמצא (#' . $product_id . ')' );
		}

		if ( $this->is_cycle_closed( $product_id, $date, $start_time ) ) {
			return array( 'success' => true, 'message' => 'המחזור כבר סגור', 'already' => true );
		}

		$availability = get_post_meta( $product_id, '_wc_booking_availability', true );
		if ( ! is_array( $availability ) ) {
			$availability = array();
		}

		$rule = array(
			'type'      => 'custom:daterange',
			'bookable'  => 'no',
			'priority'  => 1, // lowest number = evaluated first = wins
			'from'      => substr( $start_time, 0, 5 ),
			'to'        => substr( $end_time, 0, 5 ),
			'from_date' => $date,
			'to_date'   => $date,
		);

		// Prepend so it takes precedence over any "bookable=yes" rules.
		array_unshift( $availability, $rule );

		update_post_meta( $product_id, '_wc_booking_availability', $availability );
		update_post_meta( $product_id, $this->closed_meta_key( $date, $start_time ), wp_json_encode(
			array(
				'rule'      => $rule,
				'closed_at' => current_time( 'mysql' ),
				'source'    => $source,
				'by'        => get_current_user_id(),
			)
		) );

		// Clear WC Bookings transient/cache for this product if available.
		if ( function_exists( 'wc_delete_product_transients' ) ) {
			wc_delete_product_transients( $product_id );
		}

		AT_Logger::info(
			'[Cycle] Closed cycle',
			array(
				'product_id' => $product_id,
				'date'       => $date,
				'time'       => $start_time,
				'source'     => $source,
			)
		);

		return array( 'success' => true, 'message' => 'המחזור נסגר למכירה' );
	}

	/* ===================================================================== */
	/* Cron / manual auto-close                                              */
	/* ===================================================================== */

	/**
	 * Auto-close cycles with ZERO paid registrants that start within 48h.
	 * Used by both the daily cron and the "Run Now" button.
	 *
	 * @return array report
	 */
	public function run_auto_close() {
		$cycles = $this->get_open_cycles( self::AUTO_CLOSE_HOURS );
		$closed = array();
		$skipped = 0;

		foreach ( $cycles as $c ) {
			if ( $c['is_closed'] ) {
				continue;
			}
			if ( (int) $c['registrants'] > 0 ) {
				$skipped++;
				continue;
			}
			$res = $this->close_cycle(
				$c['product_id'],
				$c['date'],
				$c['start_time'],
				$c['end_time'],
				'auto-cron'
			);
			if ( ! empty( $res['success'] ) && empty( $res['already'] ) ) {
				$closed[] = sprintf(
					'%s — %s %s',
					$c['product_name'],
					$c['date'],
					$c['start_time']
				);
			}
		}

		$report = array(
			'ran_at'        => current_time( 'mysql' ),
			'window_hours'  => self::AUTO_CLOSE_HOURS,
			'closed_count'  => count( $closed ),
			'closed'        => $closed,
			'had_regs_kept' => $skipped,
		);
		update_option( self::OPT_LAST_RUN, $report );

		AT_Logger::info(
			'[Cycle] Auto-close run finished',
			array(
				'closed' => count( $closed ),
				'kept'   => $skipped,
			)
		);

		return $report;
	}

	/* ===================================================================== */
	/* AJAX                                                                  */
	/* ===================================================================== */

	private function verify() {
		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'at_cycles' ) || ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => 'אימות נכשל או חסרות הרשאות' ) );
		}
	}

	public function ajax_list() {
		$this->verify();
		$within = isset( $_POST['within_hours'] ) ? absint( $_POST['within_hours'] ) : 0;
		$cycles = $this->get_open_cycles( $within );
		wp_send_json_success(
			array(
				'cycles' => $cycles,
				'count'  => count( $cycles ),
			)
		);
	}

	public function ajax_close() {
		$this->verify();
		$raw = isset( $_POST['cycles'] ) ? wp_unslash( $_POST['cycles'] ) : '';
		$list = json_decode( $raw, true );
		if ( ! is_array( $list ) || empty( $list ) ) {
			wp_send_json_error( array( 'message' => 'לא נבחרו מחזורים' ) );
		}

		$ok = 0;
		$fail = 0;
		$msgs = array();
		foreach ( $list as $c ) {
			$res = $this->close_cycle(
				isset( $c['product_id'] ) ? (int) $c['product_id'] : 0,
				isset( $c['date'] ) ? sanitize_text_field( $c['date'] ) : '',
				isset( $c['start_time'] ) ? sanitize_text_field( $c['start_time'] ) : '',
				isset( $c['end_time'] ) ? sanitize_text_field( $c['end_time'] ) : '',
				'manual'
			);
			if ( ! empty( $res['success'] ) ) {
				$ok++;
			} else {
				$fail++;
				$msgs[] = $res['message'];
			}
		}

		wp_send_json_success(
			array(
				'closed' => $ok,
				'failed' => $fail,
				'errors' => array_slice( $msgs, 0, 5 ),
			)
		);
	}

	public function ajax_run_autoclose() {
		$this->verify();
		$report = $this->run_auto_close();
		wp_send_json_success( $report );
	}

	/* ===================================================================== */
	/* Admin screen                                                          */
	/* ===================================================================== */

	public static function render() {
		$nonce    = wp_create_nonce( 'at_cycles' );
		$last_run = get_option( self::OPT_LAST_RUN );
		?>
		<div class="wrap at-bookings-page" dir="rtl" style="text-align:right;">
			<h1>🔄 ניהול מחזורים</h1>

			<div class="notice notice-info" style="direction:rtl;">
				<p>
					רשימת כל המחזורים הפתוחים להרשמה (<?php echo (int) self::SCAN_DAYS; ?> ימים קדימה).
					בדיקה אוטומטית רצה <strong>פעם ביום (03:00)</strong> וסוגרת למכירה מחזורים
					<strong>ללא נרשמים שמתחילים בתוך <?php echo (int) self::AUTO_CLOSE_HOURS; ?> שעות</strong>.
					ניתן להריץ גם ידנית, ולסגור מחזורים נבחרים.
				</p>
				<?php if ( is_array( $last_run ) ) : ?>
					<p style="color:#555;">
						הרצה אוטומטית אחרונה: <strong><?php echo esc_html( $last_run['ran_at'] ); ?></strong> —
						נסגרו <strong><?php echo (int) $last_run['closed_count']; ?></strong> מחזורים.
					</p>
				<?php endif; ?>
			</div>

			<div style="background:#fff;border:1px solid #ddd;border-radius:6px;padding:16px;margin-bottom:16px;">
				<label style="font-weight:bold;">סינון לפי זמן עד תחילת המחזור:</label>
				<select id="at-cyc-filter" style="margin:0 8px;">
					<option value="0">הכל (<?php echo (int) self::SCAN_DAYS; ?> ימים)</option>
					<option value="24">24 שעות</option>
					<option value="48" selected>48 שעות</option>
					<option value="72">72 שעות</option>
				</select>
				<button class="button button-secondary" id="at-cyc-refresh">🔄 רענן</button>
				<button class="button" id="at-cyc-runauto">⚙️ הרץ בדיקה אוטומטית עכשיו</button>
				<span id="at-cyc-status" style="margin-right:10px;color:#555;"></span>
			</div>

			<div style="margin-bottom:10px;">
				<button class="button button-primary" id="at-cyc-close-sel" disabled>🔒 סגור מחזורים נבחרים</button>
				<span style="color:#666;"> (בחר מחזורים בטבלה)</span>
			</div>

			<table class="widefat striped" id="at-cyc-table" style="background:#fff;">
				<thead>
					<tr>
						<th style="width:34px;"><input type="checkbox" id="at-cyc-all"></th>
						<th>מוצר / סיור</th>
						<th>עיר</th>
						<th>תאריך ושעה</th>
						<th>נרשמים (משולם)</th>
						<th>זמן עד התחלה</th>
						<th>סטטוס</th>
						<th>פעולה</th>
					</tr>
				</thead>
				<tbody id="at-cyc-body">
					<tr><td colspan="8" style="text-align:center;padding:20px;">טוען...</td></tr>
				</tbody>
			</table>
		</div>

		<script type="text/javascript">
			jQuery(function ($) {
				var nonce = '<?php echo esc_js( $nonce ); ?>';

				function esc(s) { return $('<div>').text(s == null ? '' : s).html(); }

				function rowHtml(c, i) {
					var closed = c.is_closed;
					var badge = closed
						? '<span style="color:#b91c1c;font-weight:bold;">🔒 סגור</span>'
						: (c.registrants > 0
							? '<span style="color:#15803d;font-weight:bold;">✅ ' + c.registrants + ' נרשמים</span>'
							: '<span style="color:#b45309;font-weight:bold;">⚠️ ריק</span>');
					var act = closed
						? '<em style="color:#999;">סגור</em>'
						: '<button class="button button-small at-cyc-close-one" data-i="' + i + '">🔒 סגור</button>';
					var cb = closed ? '' :
						'<input type="checkbox" class="at-cyc-cb" data-i="' + i + '">';
					return '<tr' + (closed ? ' style="opacity:.55;"' : '') + '>' +
						'<td>' + cb + '</td>' +
						'<td>' + esc(c.product_name) + ' <span style="color:#999;">#' + c.product_id + '</span></td>' +
						'<td>' + esc(c.city) + '</td>' +
						'<td>' + esc(c.date) + ' ' + esc(c.start_time) + '–' + esc(c.end_time) + '</td>' +
						'<td>' + c.registrants + (c.max_capacity ? ' / ' + c.max_capacity : '') + '</td>' +
						'<td>' + (c.starts_in_hours < 24
							? '<strong style="color:#b91c1c;">' + c.starts_in_hours + ' ש\'</strong>'
							: c.starts_in_hours + ' ש\'') + '</td>' +
						'<td>' + badge + '</td>' +
						'<td>' + act + '</td>' +
						'</tr>';
				}

				var DATA = [];

				function load() {
					$('#at-cyc-body').html('<tr><td colspan="8" style="text-align:center;padding:20px;">טוען...</td></tr>');
					$('#at-cyc-status').text('');
					$.post(ajaxurl, {
						action: 'at_cycles_list', nonce: nonce,
						within_hours: $('#at-cyc-filter').val()
					}).done(function (r) {
						if (!r.success) { $('#at-cyc-status').text('שגיאה: ' + (r.data && r.data.message)); return; }
						DATA = r.data.cycles;
						if (!DATA.length) {
							$('#at-cyc-body').html('<tr><td colspan="8" style="text-align:center;padding:20px;">אין מחזורים פתוחים בטווח שנבחר 🎉</td></tr>');
						} else {
							$('#at-cyc-body').html(DATA.map(rowHtml).join(''));
						}
						$('#at-cyc-status').text('נמצאו ' + r.data.count + ' מחזורים');
						$('#at-cyc-close-sel').prop('disabled', true);
						$('#at-cyc-all').prop('checked', false);
					}).fail(function (x, s, e) { $('#at-cyc-status').text('שגיאת שרת: ' + e); });
				}

				function selected() {
					var out = [];
					$('.at-cyc-cb:checked').each(function () {
						var c = DATA[$(this).data('i')];
						out.push({ product_id: c.product_id, date: c.date, start_time: c.start_time, end_time: c.end_time });
					});
					return out;
				}

				/**
				 * Close cycles one at a time (sequential per-entry AJAX).
				 *
				 * Why one at a time: closing a cycle invalidates the WC Bookings
				 * cache and rewrites _wc_booking_availability, which can take
				 * 5–15s per cycle on complex products. Posting the entire batch
				 * in a single AJAX call easily exceeds Cloudflare's 524 timeout
				 * (~100s), and the user sees a "server error" even though the
				 * server keeps working in the background.
				 *
				 * Per-entry posts keep each request fast and let us show live
				 * progress. The handler is the same `at_cycles_close` endpoint
				 * — we just send a one-element list each time.
				 */
				function closeCycles(list, label) {
					if (!list.length) return;
					if (!confirm('לסגור למכירה ' + list.length + ' מחזור/ים? פעולה זו חוסמת את התאריך/שעה במוצר.')) return;

					var total = list.length;
					var ok = 0;
					var fail = 0;
					var errors = [];
					var $btn = $('#at-cyc-close-sel').prop('disabled', true);
					var $status = $('#at-cyc-status');

					function step(i) {
						if (i >= total) {
							var msg = 'הסתיים — נסגרו ' + ok + (fail ? ', נכשלו ' + fail : '') + ' מתוך ' + total;
							$status.text(msg);
							if (errors.length) alert('שגיאות:\n' + errors.slice(0, 5).join('\n'));
							$btn.prop('disabled', false);
							load();
							return;
						}
						var entry = list[i];
						$status.text('סוגר ' + (i + 1) + ' / ' + total + ' (' + label + ')...');

						$.ajax({
							url: ajaxurl,
							type: 'POST',
							data: { action: 'at_cycles_close', nonce: nonce, cycles: JSON.stringify([entry]) },
							timeout: 60000 // 60s ceiling — single cycle should be well under this
						}).done(function (r) {
							if (r && r.success) {
								ok += (r.data && r.data.closed) || 0;
								fail += (r.data && r.data.failed) || 0;
								if (r.data && r.data.errors && r.data.errors.length) {
									errors.push.apply(errors, r.data.errors);
								}
							} else {
								fail++;
								errors.push('#' + (i + 1) + ': ' + ((r && r.data && r.data.message) || 'שגיאה לא ידועה'));
							}
						}).fail(function (xhr, s, e) {
							fail++;
							errors.push('#' + (i + 1) + ': שגיאת שרת (' + (s || e || xhr.status) + ')');
						}).always(function () {
							// Move on regardless — partial success is still progress
							step(i + 1);
						});
					}

					step(0);
				}

				$('#at-cyc-refresh, #at-cyc-filter').on('change click', function (e) {
					if (e.type === 'click' && this.id !== 'at-cyc-refresh') return;
					load();
				});

				$('#at-cyc-runauto').on('click', function () {
					if (!confirm('להריץ עכשיו את הבדיקה האוטומטית? תיסגר כל מחזור ללא נרשמים שמתחיל בתוך 48 שעות.')) return;
					var $b = $(this).prop('disabled', true).text('⚙️ רץ...');
					$('#at-cyc-status').text('מריץ בדיקה אוטומטית...');
					$.post(ajaxurl, { action: 'at_cycles_run_autoclose', nonce: nonce })
						.done(function (r) {
							if (r.success) {
								$('#at-cyc-status').text('הבדיקה הסתיימה — נסגרו ' + r.data.closed_count + ' מחזורים (' + r.data.had_regs_kept + ' עם נרשמים נשמרו)');
								if (r.data.closed && r.data.closed.length) alert('נסגרו:\n' + r.data.closed.join('\n'));
								load();
							} else { $('#at-cyc-status').text('שגיאה: ' + (r.data && r.data.message)); }
						}).fail(function (x, s, e) { $('#at-cyc-status').text('שגיאת שרת: ' + e); })
						.always(function () { $b.prop('disabled', false).text('⚙️ הרץ בדיקה אוטומטית עכשיו'); });
				});

				$('#at-cyc-table').on('change', '#at-cyc-all', function () {
					$('.at-cyc-cb').prop('checked', this.checked);
					$('#at-cyc-close-sel').prop('disabled', selected().length === 0);
				});
				$('#at-cyc-table').on('change', '.at-cyc-cb', function () {
					$('#at-cyc-close-sel').prop('disabled', selected().length === 0);
				});
				$('#at-cyc-close-sel').on('click', function () { closeCycles(selected(), 'נבחרים'); });
				$('#at-cyc-table').on('click', '.at-cyc-close-one', function () {
					var c = DATA[$(this).data('i')];
					closeCycles([{ product_id: c.product_id, date: c.date, start_time: c.start_time, end_time: c.end_time }], 'מחזור');
				});

				load();
			});
		</script>
		<?php

		if ( class_exists( 'AT_Bookings_Dashboard' ) ) {
			AT_Bookings_Dashboard::render_footer();
		}
	}
}

AT_Cycle_Management::get_instance();
