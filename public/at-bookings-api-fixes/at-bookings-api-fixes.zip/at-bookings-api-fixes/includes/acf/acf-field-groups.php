<?php
/**
 * ACF Field Groups for Zoho Integration
 * 
 * Creates and manages ACF field groups for Zoho sync metadata
 * 
 * @package AT_Bookings_API_Fixes
 * @subpackage ACF
 * @since 3.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Bookings_ACF_Fields {
    
    /**
     * Initialize ACF field groups
     */
    public static function init() {
        add_action('acf/init', array(__CLASS__, 'create_field_groups'));
    }
    
    /**
     * Create ACF field groups
     */
    public static function create_field_groups() {
        if (!function_exists('acf_add_local_field_group')) {
            return;
        }
        
        // Zoho Sync Meta for Orders
        acf_add_local_field_group(array(
            'key' => 'group_at_zoho_order_meta',
            'title' => 'Zoho Sync Metadata',
            'fields' => array(
                array(
                    'key' => 'field_zoho_contact_id',
                    'label' => 'Zoho Contact ID',
                    'name' => '_zoho_contact_id',
                    'type' => 'text',
                    'instructions' => 'Zoho CRM Contact ID for this order customer',
                    'required' => 0,
                    'readonly' => 1,
                    'wrapper' => array(
                        'width' => '50',
                    ),
                ),
                array(
                    'key' => 'field_zoho_sales_order_id',
                    'label' => 'Zoho Sales Order ID',
                    'name' => '_zoho_sales_order_id',
                    'type' => 'text',
                    'instructions' => 'Zoho CRM Sales Order ID (for paid orders)',
                    'required' => 0,
                    'readonly' => 1,
                    'wrapper' => array(
                        'width' => '50',
                    ),
                ),
                array(
                    'key' => 'field_zoho_lead_id',
                    'label' => 'Zoho Lead ID',
                    'name' => '_zoho_lead_id',
                    'type' => 'text',
                    'instructions' => 'Zoho CRM Lead ID (for unpaid orders)',
                    'required' => 0,
                    'readonly' => 1,
                    'wrapper' => array(
                        'width' => '50',
                    ),
                ),
                array(
                    'key' => 'field_zoho_cycle_id',
                    'label' => 'Zoho Cycle ID',
                    'name' => '_zoho_cycle_id',
                    'type' => 'text',
                    'instructions' => 'Zoho CRM Cycle ID for booking slot',
                    'required' => 0,
                    'readonly' => 1,
                    'wrapper' => array(
                        'width' => '50',
                    ),
                ),
                array(
                    'key' => 'field_zoho_sync_last_started',
                    'label' => 'Last Sync Started',
                    'name' => '_zoho_sync_last_started',
                    'type' => 'date_time_picker',
                    'instructions' => 'Last sync attempt timestamp',
                    'required' => 0,
                    'readonly' => 1,
                    'display_format' => 'd/m/Y g:i a',
                    'return_format' => 'Y-m-d H:i:s',
                    'wrapper' => array(
                        'width' => '50',
                    ),
                ),
                array(
                    'key' => 'field_zoho_sync_last_trigger',
                    'label' => 'Last Sync Trigger',
                    'name' => '_zoho_sync_last_trigger',
                    'type' => 'select',
                    'instructions' => 'How the last sync was triggered',
                    'required' => 0,
                    'readonly' => 1,
                    'choices' => array(
                        'manual' => 'Manual',
                        'automatic' => 'Automatic',
                    ),
                    'wrapper' => array(
                        'width' => '50',
                    ),
                ),
            ),
            'location' => array(
                array(
                    array(
                        'param' => 'post_type',
                        'operator' => '==',
                        'value' => 'shop_order',
                    ),
                ),
            ),
            'menu_order' => 0,
            'position' => 'side',
            'style' => 'default',
            'label_placement' => 'top',
            'instruction_placement' => 'label',
            'active' => true,
        ));
        
        // Zoho Sync Meta for Products
        acf_add_local_field_group(array(
            'key' => 'group_at_zoho_product_meta',
            'title' => 'Zoho Product Sync',
            'fields' => array(
                array(
                    'key' => 'field_zoho_product_id',
                    'label' => 'Zoho Product ID',
                    'name' => '_zoho_product_id',
                    'type' => 'text',
                    'instructions' => 'Zoho CRM Product ID for this tour/product',
                    'required' => 0,
                    'readonly' => 1,
                    'wrapper' => array(
                        'width' => '100',
                    ),
                ),
            ),
            'location' => array(
                array(
                    array(
                        'param' => 'post_type',
                        'operator' => '==',
                        'value' => 'product',
                    ),
                    array(
                        'param' => 'product_type',
                        'operator' => '==',
                        'value' => 'booking',
                    ),
                ),
            ),
            'menu_order' => 0,
            'position' => 'side',
            'style' => 'default',
            'label_placement' => 'top',
            'instruction_placement' => 'label',
            'active' => true,
        ));
        
        // Zoho Sync Meta for Users
        acf_add_local_field_group(array(
            'key' => 'group_at_zoho_user_meta',
            'title' => 'Zoho Contact Sync',
            'fields' => array(
                array(
                    'key' => 'field_zoho_user_contact_id',
                    'label' => 'Zoho Contact ID',
                    'name' => '_zoho_contact_id',
                    'type' => 'text',
                    'instructions' => 'Zoho CRM Contact ID for this user',
                    'required' => 0,
                    'readonly' => 1,
                    'wrapper' => array(
                        'width' => '100',
                    ),
                ),
            ),
            'location' => array(
                array(
                    array(
                        'param' => 'user_form',
                        'operator' => '==',
                        'value' => 'edit',
                    ),
                ),
            ),
            'menu_order' => 0,
            'position' => 'normal',
            'style' => 'default',
            'label_placement' => 'top',
            'instruction_placement' => 'label',
            'active' => true,
        ));
        
        // Enhanced Tour Details (extend existing if needed)
        acf_add_local_field_group(array(
            'key' => 'group_at_tour_details_extended',
            'title' => 'Tour Details (AT Bookings)',
            'fields' => array(
                array(
                    'key' => 'field_tour_max_participants',
                    'label' => 'Max Participants',
                    'name' => 'TOUR_MAX_PARTICIPANTS',
                    'type' => 'number',
                    'instructions' => 'Maximum number of participants for this tour',
                    'required' => 0,
                    'default_value' => 1,
                    'min' => 1,
                    'wrapper' => array(
                        'width' => '33',
                    ),
                ),
                array(
                    'key' => 'field_tour_min_participants',
                    'label' => 'Min Participants',
                    'name' => 'TOUR_MIN_PARTICIPANTS',
                    'type' => 'number',
                    'instructions' => 'Minimum participants required to run tour',
                    'required' => 0,
                    'default_value' => 1,
                    'min' => 1,
                    'wrapper' => array(
                        'width' => '33',
                    ),
                ),
                array(
                    'key' => 'field_tour_difficulty',
                    'label' => 'Tour Difficulty',
                    'name' => 'TOUR_DIFFICULTY',
                    'type' => 'select',
                    'instructions' => 'Physical difficulty level',
                    'required' => 0,
                    'choices' => array(
                        'easy' => 'Easy',
                        'moderate' => 'Moderate', 
                        'challenging' => 'Challenging',
                        'difficult' => 'Difficult',
                    ),
                    'default_value' => 'easy',
                    'wrapper' => array(
                        'width' => '33',
                    ),
                ),
            ),
            'location' => array(
                array(
                    array(
                        'param' => 'post_type',
                        'operator' => '==',
                        'value' => 'product',
                    ),
                    array(
                        'param' => 'product_type',
                        'operator' => '==',
                        'value' => 'booking',
                    ),
                ),
            ),
            'menu_order' => 1,
            'position' => 'normal',
            'style' => 'default',
            'label_placement' => 'top',
            'instruction_placement' => 'label',
            'active' => true,
        ));
    }
    
    /**
     * Get Zoho sync status for order
     * 
     * @param int $order_id Order ID
     * @return array Sync status data
     */
    public static function get_order_sync_status($order_id) {
        return [
            'contact_id' => get_field('_zoho_contact_id', $order_id),
            'sales_order_id' => get_field('_zoho_sales_order_id', $order_id),
            'lead_id' => get_field('_zoho_lead_id', $order_id),
            'cycle_id' => get_field('_zoho_cycle_id', $order_id),
            'last_started' => get_field('_zoho_sync_last_started', $order_id),
            'last_trigger' => get_field('_zoho_sync_last_trigger', $order_id),
        ];
    }
    
    /**
     * Update sync metadata for order
     * 
     * @param int $order_id Order ID
     * @param array $sync_data Sync data to update
     */
    public static function update_order_sync_metadata($order_id, $sync_data) {
        foreach ($sync_data as $key => $value) {
            if (strpos($key, '_zoho_') === 0) {
                update_field($key, $value, $order_id);
            }
        }
    }
}

// Initialize ACF fields
AT_Bookings_ACF_Fields::init();
