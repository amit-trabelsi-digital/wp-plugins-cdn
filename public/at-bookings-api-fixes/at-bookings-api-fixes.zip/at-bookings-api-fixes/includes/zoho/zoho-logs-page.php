<?php
/**
 * ZOHO Sync Logs Page Template
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap">
    <h1><?php _e('ZOHO CRM Sync Logs', 'at-bookings-api-fixes'); ?></h1>

    <div class="at-zoho-logs-filters" style="background: #fff; padding: 15px; margin: 20px 0; border: 1px solid #ccc;">
        <form method="get" action="">
            <input type="hidden" name="page" value="at-bookings-zoho-logs">
            
            <label for="filter_action"><?php _e('Action:', 'at-bookings-api-fixes'); ?></label>
            <select name="filter_action" id="filter_action">
                <option value=""><?php _e('All', 'at-bookings-api-fixes'); ?></option>
                <option value="search" <?php selected($filters['action'], 'search'); ?>><?php _e('Search', 'at-bookings-api-fixes'); ?></option>
                <option value="create" <?php selected($filters['action'], 'create'); ?>><?php _e('Create', 'at-bookings-api-fixes'); ?></option>
                <option value="update" <?php selected($filters['action'], 'update'); ?>><?php _e('Update', 'at-bookings-api-fixes'); ?></option>
                <option value="sync" <?php selected($filters['action'], 'sync'); ?>><?php _e('Sync', 'at-bookings-api-fixes'); ?></option>
            </select>

            <label for="filter_module"><?php _e('Module:', 'at-bookings-api-fixes'); ?></label>
            <select name="filter_module" id="filter_module">
                <option value=""><?php _e('All', 'at-bookings-api-fixes'); ?></option>
                <option value="Contacts" <?php selected($filters['module'], 'Contacts'); ?>><?php _e('Contacts', 'at-bookings-api-fixes'); ?></option>
                <option value="Leads" <?php selected($filters['module'], 'Leads'); ?>><?php _e('Leads', 'at-bookings-api-fixes'); ?></option>
                <option value="Products" <?php selected($filters['module'], 'Products'); ?>><?php _e('Products', 'at-bookings-api-fixes'); ?></option>
                <option value="Sales_Orders" <?php selected($filters['module'], 'Sales_Orders'); ?>><?php _e('Sales Orders', 'at-bookings-api-fixes'); ?></option>
            </select>

            <label for="filter_status"><?php _e('Status:', 'at-bookings-api-fixes'); ?></label>
            <select name="filter_status" id="filter_status">
                <option value=""><?php _e('All', 'at-bookings-api-fixes'); ?></option>
                <option value="success" <?php selected($filters['status'], 'success'); ?>><?php _e('Success', 'at-bookings-api-fixes'); ?></option>
                <option value="error" <?php selected($filters['status'], 'error'); ?>><?php _e('Error', 'at-bookings-api-fixes'); ?></option>
                <option value="pending" <?php selected($filters['status'], 'pending'); ?>><?php _e('Pending', 'at-bookings-api-fixes'); ?></option>
            </select>

            <button type="submit" class="button"><?php _e('Filter', 'at-bookings-api-fixes'); ?></button>
            <a href="<?php echo admin_url('admin.php?page=at-bookings-zoho-logs'); ?>" class="button"><?php _e('Reset', 'at-bookings-api-fixes'); ?></a>
            <button type="button" id="at-zoho-clear-logs" class="button button-secondary" style="float: left;">
                <?php _e('Clear All Logs', 'at-bookings-api-fixes'); ?>
            </button>
        </form>
    </div>

    <div class="at-zoho-logs-stats" style="background: #fff; padding: 15px; margin: 20px 0; border: 1px solid #ccc;">
        <strong><?php _e('Total Logs:', 'at-bookings-api-fixes'); ?></strong> <?php echo number_format($total_logs); ?>
    </div>

    <table class="widefat striped">
        <thead>
            <tr>
                <th><?php _e('Time', 'at-bookings-api-fixes'); ?></th>
                <th><?php _e('Action', 'at-bookings-api-fixes'); ?></th>
                <th><?php _e('Module', 'at-bookings-api-fixes'); ?></th>
                <th><?php _e('HTTP', 'at-bookings-api-fixes'); ?></th>
                <th><?php _e('API Version', 'at-bookings-api-fixes'); ?></th>
                <th><?php _e('Status', 'at-bookings-api-fixes'); ?></th>
                <th><?php _e('Details', 'at-bookings-api-fixes'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($logs)): ?>
                <tr>
                    <td colspan="7" style="text-align: center; padding: 20px;">
                        <?php _e('No logs found', 'at-bookings-api-fixes'); ?>
                    </td>
                </tr>
            <?php else: ?>
                <?php foreach ($logs as $log): ?>
                    <tr class="log-row log-status-<?php echo esc_attr($log->status); ?>">
                        <td><?php echo esc_html(date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($log->timestamp))); ?></td>
                        <td><strong><?php echo esc_html($log->action); ?></strong></td>
                        <td><code><?php echo esc_html($log->module); ?></code></td>
                        <td>
                            <?php if ($log->http_method): ?>
                                <span style="background: #e8f4f8; padding: 3px 8px; border-radius: 3px; font-weight: bold; color: #0073aa;">
                                    <?php echo esc_html($log->http_method); ?>
                                </span>
                            <?php else: ?>
                                <span style="color: #999;">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($log->api_version): ?>
                                <code style="background: #f0f0f0; padding: 2px 6px; border-radius: 3px;">
                                    <?php echo esc_html($log->api_version); ?>
                                </code>
                            <?php else: ?>
                                <span style="color: #999;">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php
                            $status_icons = array(
                                'success' => '✅',
                                'error' => '❌',
                                'pending' => '⏳'
                            );
                            echo $status_icons[$log->status] ?? '❓';
                            echo ' ' . esc_html($log->status);
                            ?>
                        </td>
                        <td>
                            <button type="button" class="button button-small view-log-details" data-log-id="<?php echo $log->id; ?>">
                                <?php _e('View Details', 'at-bookings-api-fixes'); ?>
                            </button>
                        </td>
                    </tr>
                    <tr class="log-details" id="log-details-<?php echo $log->id; ?>" style="display: none;">
                        <td colspan="7" style="background: #f9f9f9; padding: 20px;">
                            <div class="log-details-content">
                                <?php if ($log->api_url): ?>
                                    <div style="margin-bottom: 15px; background: #f0f7ff; padding: 12px; border-left: 4px solid #0073aa;">
                                        <strong><?php _e('API Endpoint:', 'at-bookings-api-fixes'); ?></strong><br>
                                        <code style="word-break: break-all; font-size: 12px; display: block; margin-top: 5px;">
                                            <?php 
                                            // קיצור הnon-sensitive parts של ה-URL
                                            $display_url = preg_replace('/([?&])[^=&]+=\*{4,}/', '$1***', $log->api_url);
                                            echo esc_html($display_url); 
                                            ?>
                                        </code>
                                    </div>
                                <?php endif; ?>

                                <?php if ($log->error_message): ?>
                                    <div style="color: #dc3545; margin-bottom: 15px; background: #ffe8e8; padding: 12px; border-left: 4px solid #dc3545;">
                                        <strong><?php _e('❌ Error Message:', 'at-bookings-api-fixes'); ?></strong><br>
                                        <?php echo esc_html($log->error_message); ?>
                                    </div>
                                <?php endif; ?>

                                <?php if ($log->request_data): ?>
                                    <div style="margin-bottom: 15px;">
                                        <strong><?php _e('📤 Request Data (Sent to ZOHO):', 'at-bookings-api-fixes'); ?></strong>
                                        <pre style="background: #fff; padding: 10px; border: 1px solid #ddd; max-height: 300px; overflow: auto; direction: ltr;"><?php echo esc_html(json_encode(json_decode($log->request_data), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)); ?></pre>
                                    </div>
                                <?php endif; ?>

                                <?php if ($log->response_data): ?>
                                    <div>
                                        <strong><?php _e('📥 Response Data (Received from ZOHO):', 'at-bookings-api-fixes'); ?></strong>
                                        <pre style="background: #fff; padding: 10px; border: 1px solid #ddd; max-height: 300px; overflow: auto; direction: ltr;"><?php echo esc_html(json_encode(json_decode($log->response_data), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)); ?></pre>
                                    </div>
                                <?php endif; ?>

                                <?php if ($log->wp_id || $log->zoho_id): ?>
                                    <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #ddd;">
                                        <strong><?php _e('IDs:', 'at-bookings-api-fixes'); ?></strong>
                                        <ul style="margin: 5px 0; padding-left: 20px;">
                                            <?php if ($log->wp_id): ?>
                                                <li><?php _e('WordPress ID:', 'at-bookings-api-fixes'); ?> <code><?php echo esc_html($log->wp_id); ?></code></li>
                                            <?php endif; ?>
                                            <?php if ($log->zoho_id): ?>
                                                <li><?php _e('ZOHO ID:', 'at-bookings-api-fixes'); ?> <code><?php echo esc_html($log->zoho_id); ?></code></li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <?php if ($total_pages > 1): ?>
        <div class="tablenav bottom">
            <div class="tablenav-pages">
                <?php
                echo paginate_links(array(
                    'base' => add_query_arg('paged', '%#%'),
                    'format' => '',
                    'prev_text' => __('&laquo;'),
                    'next_text' => __('&raquo;'),
                    'total' => $total_pages,
                    'current' => $current_page
                ));
                ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<style>
.log-status-success {
    background-color: #f0fff0;
}

.log-status-error {
    background-color: #fff0f0;
}

.log-status-pending {
    background-color: #fffef0;
}

.log-details-content pre {
    font-family: 'Courier New', monospace;
    font-size: 12px;
    line-height: 1.5;
}
</style>

<script>
jQuery(document).ready(function($) {
    // View log details
    $('.view-log-details').on('click', function() {
        var logId = $(this).data('log-id');
        $('#log-details-' + logId).toggle();
    });

    // Clear logs
    $('#at-zoho-clear-logs').on('click', function() {
        if (!confirm('<?php _e('Are you sure you want to clear all logs? This action cannot be undone.', 'at-bookings-api-fixes'); ?>')) {
            return;
        }

        var $button = $(this);
        $button.prop('disabled', true).text('<?php _e('Clearing...', 'at-bookings-api-fixes'); ?>');

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'at_zoho_clear_logs',
                nonce: '<?php echo wp_create_nonce('at_zoho_clear_logs'); ?>'
            },
            success: function(response) {
                if (response.success) {
                    alert(response.data);
                    location.reload();
                } else {
                    alert('<?php _e('Error:', 'at-bookings-api-fixes'); ?> ' + response.data);
                    $button.prop('disabled', false).text('<?php _e('Clear All Logs', 'at-bookings-api-fixes'); ?>');
                }
            },
            error: function() {
                alert('<?php _e('AJAX error occurred', 'at-bookings-api-fixes'); ?>');
                $button.prop('disabled', false).text('<?php _e('Clear All Logs', 'at-bookings-api-fixes'); ?>');
            }
        });
    });
});
</script>
