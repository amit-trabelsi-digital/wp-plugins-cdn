<?php
/**
 * Zoho Sync Service
 * 
 * Core orchestration for syncing WooCommerce orders/bookings to Zoho CRM
 * 
 * @package AT_Bookings_API_Fixes
 * @subpackage Zoho
 * @since 3.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Zoho_Sync_Service {
    
    const STOP_FLAG_TRANSIENT = 'at_sync_stop_';
    const STOP_FLAG_DURATION = 300; // 5 minutes
    
    private $zoho_api;
    private $user_id;
    private $stop_flag_key;
    
    public function __construct() {
        $this->user_id = get_current_user_id();
        $this->stop_flag_key = self::STOP_FLAG_TRANSIENT . $this->user_id;
        
        // Use AT_Zoho_API for actual API operations (search, create, update)
        if (class_exists('AT_Zoho_API')) {
            $this->zoho_api = AT_Zoho_API::get_instance();
        }
    }
    
    /**
     * Log API request and response for debugging
     * 
     * @param string $action Action name (e.g., 'Create Contacts', 'Update Products')
     * @param array $request_data Data sent to Zoho
     * @param array $response Response from Zoho
     * @param int $wp_id WordPress ID (order, product, etc.)
     */
    private function log_api_call($action, $request_data, $response, $wp_id = null) {
        // Log to file for immediate debugging
        $log_file = WP_CONTENT_DIR . '/debug-sync.log';
        file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] ==========================================\n", FILE_APPEND);
        file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] API CALL: $action\n", FILE_APPEND);
        file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] REQUEST: " . json_encode($request_data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . "\n", FILE_APPEND);
        file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] RESPONSE: " . json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . "\n", FILE_APPEND);
        
        $is_success = isset($response['success']) && $response['success'];
        $error_msg = !$is_success ? ($response['message'] ?? 'Unknown error') : null;
        
        if (!$is_success) {
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] ❌ ERROR: " . $error_msg . "\n", FILE_APPEND);
        } else {
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] ✓ SUCCESS\n", FILE_APPEND);
        }
        file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] ==========================================\n", FILE_APPEND);
        
        // Also log to database for display in admin page
        if (class_exists('AT_Zoho_Sync_Logs')) {
            $logs = AT_Zoho_Sync_Logs::get_instance();
            
            // Extract module from action (e.g., "Create Contact" -> "Contacts")
            $module = 'Unknown';
            if (stripos($action, 'Contact') !== false) $module = 'Contacts';
            elseif (stripos($action, 'Product') !== false) $module = 'Products';
            elseif (stripos($action, 'Cycle') !== false) $module = 'Cycles';
            elseif (stripos($action, 'Sales_Order') !== false) $module = 'Sales_Orders';
            elseif (stripos($action, 'Lead') !== false) $module = 'Leads';
            
            // Extract action type (create, update, search)
            $action_type = 'sync';
            if (stripos($action, 'Create') !== false) $action_type = 'create';
            elseif (stripos($action, 'Update') !== false) $action_type = 'update';
            elseif (stripos($action, 'Search') !== false) $action_type = 'search';
            
            // Extract Zoho ID from response
            $zoho_id = null;
            if (isset($response['id'])) {
                $zoho_id = $response['id'];
            } elseif (isset($response['data']['details']['id'])) {
                $zoho_id = $response['data']['details']['id'];
            }
            
            $logs->log_sync(
                $action_type,
                $module,
                $wp_id,
                $zoho_id,
                $is_success ? 'success' : 'error',
                $request_data,
                $response,
                $error_msg,
                null, // api_url - will be set by API context if available
                null, // http_method
                null  // api_version
            ,
                        null, // api_url
                        null, // http_method
                        null  // api_version
                    );
        }
    }
    
    /**
     * Sync complete order to Zoho
     * 
     * @param int $order_id Order ID
     * @param string $trigger 'manual' or 'automatic'
     * @return array Result with success status and details
     */
    public function sync_order($order_id, $trigger = 'manual') {
        $order_id = (int) $order_id;
        $order = wc_get_order($order_id);
        
        if (!$order) {
            return ['success' => false, 'message' => __('Order not found', 'at-bookings-api-fixes')];
        }
        
        // PRE-SYNC VALIDATION: Check basic required data
        $pre_validation = $this->validate_order_before_sync($order);
        if (!$pre_validation['valid']) {
            return [
                'success' => false,
                'message' => __('Pre-sync validation failed', 'at-bookings-api-fixes'),
                'errors' => $pre_validation['errors'],
                'steps' => [[
                    'step' => 'pre_validation',
                    'success' => false,
                    'message' => implode('; ', $pre_validation['errors']),
                    'method' => 'validate_order_before_sync'
                ]]
            ];
        }
        
        // Record sync start
        $this->record_sync_start($order_id, $trigger);
        
        $results = [
            'success' => true,
            'steps' => [],
            'entities' => []
        ];
        
        try {
            // Step 1: Sync Contact (required for Order)
            if (!$this->is_stopped()) {
                $contact_result = $this->sync_contact($order);
                $results['steps'][] = $contact_result;
                $results['entities']['contact'] = $contact_result;
                
                if (!$contact_result['success']) {
                    $results['success'] = false;
                    // CRITICAL: Stop here - can't create Order without Contact
                    throw new Exception(__('Failed to sync Contact - cannot continue', 'at-bookings-api-fixes'));
                }
            }
            
            // Step 2: Sync Products
            if (!$this->is_stopped() && $results['success']) {
                $product_results = $this->sync_order_products($order);
                $results['steps'] = array_merge($results['steps'], $product_results);
                $results['entities']['products'] = $product_results;
                
                foreach ($product_results as $result) {
                    if (!$result['success']) {
                        $results['success'] = false;
                        break;
                    }
                }
            }
            
            // Step 3: Sync Cycles (Slots) - REQUIRED for Order
            if (!$this->is_stopped() && $results['success']) {
                $cycle_results = $this->sync_order_cycles($order);
                $results['steps'] = array_merge($results['steps'], $cycle_results);
                $results['entities']['cycles'] = $cycle_results;
                
                // CRITICAL: At least one cycle must succeed
                $has_valid_cycle = false;
                foreach ($cycle_results as $result) {
                    if ($result['success'] && !empty($result['zoho_id'])) {
                        $has_valid_cycle = true;
                    }
                    if (!$result['success']) {
                        $results['success'] = false;
                    }
                }
                
                if (!$has_valid_cycle) {
                    throw new Exception(__('No valid Cycle found/created - cannot sync Order without Cycle', 'at-bookings-api-fixes'));
                }
            }
            
            // Step 4: Sync Order (Lead or Sales_Order) - ONLY if Contact & Cycle exist
            // 🔄 CRITICAL: Create separate Sales_Order for EACH booking/cycle
            if (!$this->is_stopped() && $results['success']) {
                // Verify prerequisites before creating Orders
                $contact_id = $results['entities']['contact']['zoho_id'] ?? null;
                
                if (!$contact_id) {
                    throw new Exception(__('Cannot create Order - missing Contact ID', 'at-bookings-api-fixes'));
                }
                
                // Get ALL valid cycle IDs (not just the first one!)
                $cycle_ids = [];
                foreach ($results['entities']['cycles'] as $cycle) {
                    if ($cycle['success'] && !empty($cycle['zoho_id'])) {
                        $cycle_ids[] = $cycle['zoho_id'];
                    }
                }
                
                if (empty($cycle_ids)) {
                    throw new Exception(__('Cannot create Order - no valid Cycle IDs found', 'at-bookings-api-fixes'));
                }
                
                // 🔁 LOOP: Create Sales_Order for EACH booking/cycle
                $order_results = [];
                foreach ($cycle_ids as $index => $cycle_id) {
                    $order_result = $this->sync_order_record($order, $contact_id, $cycle_id, $index);
                    $results['steps'][] = $order_result;
                    $order_results[] = $order_result;
                    
                    if (!$order_result['success']) {
                        $results['success'] = false;
                        // Don't throw - continue with other bookings
                    }
                }
                
                // Store all order results (not just one)
                $results['entities']['orders'] = $order_results;
                
                // Log summary
                write_detailed_log(sprintf(
                    '✅ Created %d Sales_Orders for Order #%d (%d bookings)',
                    count($cycle_ids),
                    $order->get_id(),
                    count($cycle_ids)
                ), 'INFO');
            }
            
            // Step 5: Update computed fields
            if (!$this->is_stopped() && $results['success']) {
                $computed_result = $this->update_computed_fields($order);
                $results['steps'][] = $computed_result;
            }
            
        } catch (Exception $e) {
            $results['success'] = false;
            $results['steps'][] = [
                'step' => 'exception',
                'success' => false,
                'message' => $e->getMessage(),
                'method' => 'Exception Handler'
            ];
        }
        
        // Record results in order notes
        $this->record_sync_results($order_id, $results, $trigger);
        
        return $results;
    }
    
    /**
     * Sync individual entity (contact, product, cycle, or order)
     * 
     * @param int $order_id Order ID
     * @param string $entity Entity type (contact, product, cycle, order)
     * @param string $trigger 'manual' or 'automatic'
     * @return array Result with success status and details
     */
    public function sync_entity($order_id, $entity, $trigger = 'manual') {
        $log_file = WP_CONTENT_DIR . '/debug-sync.log';
        file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] sync_entity START: entity=$entity, order_id=$order_id\n", FILE_APPEND);
        
        try {
            $order = wc_get_order($order_id);
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Order loaded\n", FILE_APPEND);
            
            if (!$order) {
                file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] ERROR: Order not found\n", FILE_APPEND);
                return ['success' => false, 'message' => __('Order not found', 'at-bookings-api-fixes')];
            }
            
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Checking entity type: $entity\n", FILE_APPEND);
            
            switch ($entity) {
                case 'contact':
                    file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Calling sync_contact\n", FILE_APPEND);
                    $result = $this->sync_contact($order);
                    
                    // Save Contact ID to order meta for later use
                    if ($result['success'] && !empty($result['zoho_id'])) {
                        update_post_meta($order_id, '_zoho_contact_id', $result['zoho_id']);
                        update_post_meta($order_id, '_zoho_last_sync_contact', current_time('mysql'));
                        file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Saved Contact ID to order meta: " . $result['zoho_id'] . "\n", FILE_APPEND);
                    }
                    
                    return $result;
                    
                case 'product':
                    file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Calling sync_order_products\n", FILE_APPEND);
                    $results = $this->sync_order_products($order);
                    $result = !empty($results) ? $results[0] : ['success' => false, 'message' => 'No products found'];
                    
                    // Save Product IDs to order meta
                    if (!empty($results)) {
                        $product_ids = [];
                        foreach ($results as $product_result) {
                            if ($product_result['success'] && !empty($product_result['zoho_id'])) {
                                $product_ids[] = $product_result['zoho_id'];
                            }
                        }
                        if (!empty($product_ids)) {
                            update_post_meta($order_id, '_zoho_product_ids', $product_ids);
                            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Saved Product IDs to order meta: " . implode(', ', $product_ids) . "\n", FILE_APPEND);
                        }
                    }
                    
                    return $result;
                    
                case 'cycle':
                    file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Calling sync_order_cycles\n", FILE_APPEND);
                    
                    // CRITICAL: Cycle requires Product to be synced first
                    // Check if products are synced, if not - sync them
                    $product_ids = get_post_meta($order_id, '_zoho_product_ids', true);
                    if (empty($product_ids) || !is_array($product_ids)) {
                        file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Products not synced - syncing products first...\n", FILE_APPEND);
                        
                        $product_results = $this->sync_order_products($order);
                        if (!empty($product_results)) {
                            $product_ids = [];
                            foreach ($product_results as $product_result) {
                                if ($product_result['success'] && !empty($product_result['zoho_id'])) {
                                    $product_ids[] = $product_result['zoho_id'];
                                }
                            }
                            if (!empty($product_ids)) {
                                update_post_meta($order_id, '_zoho_product_ids', $product_ids);
                                file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Products synced: " . implode(', ', $product_ids) . "\n", FILE_APPEND);
                            }
                        }
                    }
                    
                    $results = $this->sync_order_cycles($order);
                    $result = !empty($results) ? $results[0] : ['success' => false, 'message' => 'No cycles found'];
                    
                    // Save Cycle IDs to order meta
                    if (!empty($results)) {
                        $cycle_ids = [];
                        foreach ($results as $cycle_result) {
                            if ($cycle_result['success'] && !empty($cycle_result['zoho_id'])) {
                                $cycle_ids[] = $cycle_result['zoho_id'];
                            }
                        }
                        if (!empty($cycle_ids)) {
                            update_post_meta($order_id, '_zoho_cycle_ids', $cycle_ids);
                            update_post_meta($order_id, '_zoho_last_sync_cycle', current_time('mysql'));
                            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Saved Cycle IDs to order meta: " . implode(', ', $cycle_ids) . "\n", FILE_APPEND);
                        }
                    }
                    
                    return $result;
                    
                case 'order':
                    file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Calling sync_order_record\n", FILE_APPEND);
                    
                    // CRITICAL: sync_order_record needs Contact ID and Cycle ID!
                    // Try to get from order meta first
                    $contact_id = get_post_meta($order_id, '_zoho_contact_id', true);
                    $cycle_ids = get_post_meta($order_id, '_zoho_cycle_ids', true);
                    $cycle_id = is_array($cycle_ids) && !empty($cycle_ids) ? $cycle_ids[0] : null;
                    
                    file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Contact ID from meta: " . ($contact_id ?: 'MISSING') . "\n", FILE_APPEND);
                    file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Cycle ID from meta: " . ($cycle_id ?: 'MISSING') . "\n", FILE_APPEND);
                    
                    // If Contact ID missing, try to create/find contact first
                    if (!$contact_id) {
                        file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Contact missing - syncing contact first...\n", FILE_APPEND);
                        
                        $contact_result = $this->sync_contact($order);
                        if ($contact_result['success'] && !empty($contact_result['zoho_id'])) {
                            $contact_id = $contact_result['zoho_id'];
                            update_post_meta($order_id, '_zoho_contact_id', $contact_id);
                            update_post_meta($order_id, '_zoho_last_sync_contact', current_time('mysql'));
                            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Contact created/found: " . $contact_id . "\n", FILE_APPEND);
                        } else {
                            return [
                                'success' => false,
                                'message' => __('Failed to create/find Contact. ', 'at-bookings-api-fixes') . ($contact_result['message'] ?? ''),
                                'method' => 'sync_entity',
                                'step' => 'contact_auto_sync'
                            ];
                        }
                    }
                    
                    // If Cycle ID missing from meta, try to find it in Zoho
                    if (!$cycle_id) {
                        file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Cycle ID not in meta, searching in Zoho...\n", FILE_APPEND);
                        
                        $slot_data = $this->get_order_slot_data($order);
                        if ($slot_data) {
                            $product = wc_get_product($slot_data['product_id']);
                            $find_result = $this->find_or_create_cycle($slot_data, $product);
                            
                            if ($find_result['success'] && !empty($find_result['id'])) {
                                $cycle_id = $find_result['id'];
                                
                                // Save to meta for next time
                                update_post_meta($order_id, '_zoho_cycle_ids', [$cycle_id]);
                                update_post_meta($order_id, '_zoho_last_sync_cycle', current_time('mysql'));
                                
                                file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Found Cycle in Zoho: " . $cycle_id . "\n", FILE_APPEND);
                            } else {
                                file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Cycle NOT found: " . $find_result['message'] . "\n", FILE_APPEND);
                                
                                return [
                                    'success' => false,
                                    'message' => __('Cycle not found in Zoho. ', 'at-bookings-api-fixes') . $find_result['message'],
                                    'method' => 'sync_entity',
                                    'step' => 'cycle_search'
                                ];
                            }
                        } else {
                            return [
                                'success' => false,
                                'message' => __('No booking/slot data found for this order', 'at-bookings-api-fixes'),
                                'method' => 'sync_entity',
                                'step' => 'validation'
                            ];
                        }
                    }
                    
                    file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Ready to sync order with Contact: $contact_id, Cycle: $cycle_id\n", FILE_APPEND);
                    
                    $result = $this->sync_order_record($order, $contact_id, $cycle_id);
                    
                    // Save Order ID to order meta
                    if ($result['success'] && !empty($result['zoho_id'])) {
                        if ($order->is_paid()) {
                            update_post_meta($order_id, '_zoho_sales_order_id', $result['zoho_id']);
                            update_post_meta($order_id, '_zoho_last_sync_order', current_time('mysql'));
                        } else {
                            update_post_meta($order_id, '_zoho_lead_id', $result['zoho_id']);
                            update_post_meta($order_id, '_zoho_last_sync_lead', current_time('mysql'));
                        }
                        update_post_meta($order_id, '_zoho_sync_status', 'success');
                        file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Saved Order ID to order meta: " . $result['zoho_id'] . "\n", FILE_APPEND);
                    }
                    
                    return $result;
                    
                default:
                    file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] ERROR: Invalid entity type\n", FILE_APPEND);
                    return ['success' => false, 'message' => __('Invalid entity type', 'at-bookings-api-fixes')];
            }
        } catch (Exception $e) {
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] EXCEPTION in sync_entity: " . $e->getMessage() . "\n", FILE_APPEND);
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Trace: " . $e->getTraceAsString() . "\n", FILE_APPEND);
            return ['success' => false, 'message' => 'Exception: ' . $e->getMessage()];
        }
    }
    
    /**
     * Sync contact from order
     * 
     * @param WC_Order $order Order object
     * @return array Sync result
     */
    private function sync_contact($order) {
        $log_file = WP_CONTENT_DIR . '/debug-sync.log';
        file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] sync_contact START\n", FILE_APPEND);
        
        if (!$this->zoho_api) {
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] ERROR: zoho_api not initialized\n", FILE_APPEND);
            return ['success' => false, 'message' => 'Zoho API not available', 'method' => 'sync_contact'];
        }
        
        try {
            // Map order to contact data
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Mapping contact data\n", FILE_APPEND);
            $contact_data = AT_Zoho_Mapper::map_to_contact($order);
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Contact data mapped: " . json_encode(array_slice($contact_data, 0, 3)) . "\n", FILE_APPEND);
            
            // SKIP field validation for Contacts - Zoho will validate
            // The field name check causes false positives if cache is stale
            // Standard fields (First_Name, Last_Name, Email, Phone) always exist
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Basic validation\n", FILE_APPEND);
            
            // Basic validation - check required data
            if (empty($contact_data['Last_Name'])) {
                return [
                    'success' => false,
                    'message' => __('Contact must have Last Name', 'at-bookings-api-fixes'),
                    'method' => 'sync_contact',
                    'step' => 'validation'
                ];
            }
            
            if (empty($contact_data['Email']) && empty($contact_data['Phone'])) {
                return [
                    'success' => false,
                    'message' => __('Contact must have Email or Phone', 'at-bookings-api-fixes'),
                    'method' => 'sync_contact',
                    'step' => 'validation'
                ];
            }
            
            // Find existing contact
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Finding existing contact\n", FILE_APPEND);
            $existing = $this->find_existing_contact($order);
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Existing contact: " . ($existing ? $existing['id'] : 'NONE') . "\n", FILE_APPEND);
            
            if ($existing) {
                // Contact exists in Zoho - use its ID (do NOT update)
                $zoho_id = $existing['id'];
                file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Contact found in Zoho ID: {$zoho_id}\n", FILE_APPEND);
                
                update_post_meta($order->get_id(), '_zoho_contact_id', $zoho_id);
                if ($order->get_user_id()) {
                    update_user_meta($order->get_user_id(), '_zoho_contact_id', $zoho_id);
                }
                
                // Don't update contact data during order sync - just use its ID
                // Contact updates should be done through the Contacts admin page
                
                return [
                    'success' => true,
                    'message' => sprintf(__('✓ Contact found in Zoho (ID: %s)', 'at-bookings-api-fixes'), $zoho_id),
                    'zoho_id' => $zoho_id,
                    'action' => 'found',
                    'method' => 'sync_contact',
                    'step' => 'contact_found'
                ];
                
            } else {
                // Create new contact
                file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Creating new contact\n", FILE_APPEND);
                $result = $this->zoho_api->create_record('Contacts', $contact_data);
                $this->log_api_call("Create Contact", $contact_data, $result, $order->get_id());
                
                if ($result['success'] && !empty($result['id'])) {
                    update_post_meta($order->get_id(), '_zoho_contact_id', $result['id']);
                    if ($order->get_user_id()) {
                        update_user_meta($order->get_user_id(), '_zoho_contact_id', $result['id']);
                    }
                }
                
                return [
                    'success' => $result['success'],
                    'message' => $result['success'] ? __('Contact created', 'at-bookings-api-fixes') : $result['message'],
                    'zoho_id' => $result['id'] ?? null,
                    'action' => 'create',
                    'method' => 'sync_contact',
                    'step' => 'contact_create'
                ];
            }
            
        } catch (Exception $e) {
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] EXCEPTION in sync_contact: " . $e->getMessage() . "\n", FILE_APPEND);
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Trace: " . $e->getTraceAsString() . "\n", FILE_APPEND);
            return [
                'success' => false,
                'message' => $e->getMessage(),
                'method' => 'sync_contact',
                'step' => 'exception'
            ];
        }
    }
    
    /**
     * Sync products from order
     * 
     * @param WC_Order $order Order object
     * @return array Array of sync results for each product
     */
    private function sync_order_products($order) {
        $results = [];
        
        foreach ($order->get_items() as $item) {
            if ($this->is_stopped()) {
                break;
            }
            
            $product = $item->get_product();
            if (!$product) {
                continue;
            }
            
            $results[] = $this->sync_product($product);
        }
        
        return $results;
    }
    
    /**
     * Sync individual product
     * 
     * @param WC_Product $product Product object
     * @return array Sync result
     */
    private function sync_product($product) {
        if (!$this->zoho_api) {
            return ['success' => false, 'message' => 'Zoho CRM not available', 'method' => 'sync_product'];
        }
        
        try {
            $product_id = $product->get_id();
            $product_data = AT_Zoho_Mapper::map_to_product($product);
            
            // SKIP field validation for Products - Zoho will validate
            // Basic check only
            if (empty($product_data['Product_Name'])) {
                return [
                    'success' => false,
                    'message' => __('Product must have a name', 'at-bookings-api-fixes'),
                    'method' => 'sync_product',
                    'step' => 'validation'
                ];
            }
            
            // Find existing product
            $existing = $this->find_existing_product($product);
            
            if ($existing) {
                // Product exists in Zoho - use its ID
                $zoho_id = $existing['id'];
                update_post_meta($product_id, '_zoho_product_id', $zoho_id);
                
                // Update SKU in WooCommerce with Zoho Product ID if needed
                $current_sku = get_post_meta($product_id, '_sku', true);
                if (empty($current_sku) || $current_sku !== $zoho_id) {
                    update_post_meta($product_id, '_sku', $zoho_id);
                    AT_Bookings_Logger::info("Product #{$product_id} exists in Zoho, updated WC SKU to Zoho ID: {$zoho_id}" . ($current_sku ? " (was: {$current_sku})" : " (was empty)"));
                }
                
                // Don't update product data during order sync - just use its ID
                // Product updates should be done through the Products admin page
                
                return [
                    'success' => true,
                    'message' => sprintf(__('✓ Product "%s" found in Zoho (ID: %s)', 'at-bookings-api-fixes'), $product->get_name(), $zoho_id),
                    'zoho_id' => $zoho_id,
                    'action' => 'found',
                    'method' => 'sync_product',
                    'step' => 'product_found'
                ];
                
            } else {
                // Product does NOT exist in Zoho - STOP and notify
                // Products must be synced separately BEFORE order sync
                $product_name = $product->get_name();
                $product_sku = $product->get_sku();
                
                $error_message = sprintf(
                    __('❌ Product "%s" (ID: %d%s) not found in Zoho. Please sync this product to Zoho separately before syncing orders. Products should be synced through the Products admin page or Initial Sync page, not during order sync.', 'at-bookings-api-fixes'),
                    $product_name,
                    $product_id,
                    $product_sku ? ', SKU: ' . $product_sku : ''
                );
                
                write_detailed_log('ZOHO: Product not found in Zoho - stopping order sync: ' . $error_message, 'WARNING');
                AT_Bookings_Logger::warning($error_message);
                
                return [
                    'success' => false,
                    'message' => $error_message,
                    'action' => 'not_found',
                    'method' => 'sync_product',
                    'step' => 'product_validation',
                    'product_id' => $product_id,
                    'product_name' => $product_name,
                    'product_sku' => $product_sku
                ];
                
                // OLD CODE - Create new product during order sync (REMOVED per user request)
                // Products should be synced separately, not created on-the-fly during order sync
                // write_detailed_log('ZOHO: Creating new product #' . $product_id . ' with data: ' . json_encode($product_data, JSON_UNESCAPED_UNICODE), 'DEBUG');
                // $result = $this->zoho_api->create_record('Products', $product_data);
                // ... creation logic removed ...
            }
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage(),
                'method' => 'sync_product',
                'step' => 'exception'
            ];
        }
    }
    
    /**
     * Sync cycles from order
     * 
     * @param WC_Order $order Order object
     * @return array Array of sync results for each cycle
     */
    private function sync_order_cycles($order) {
        global $wpdb;
        
        $log_file = WP_CONTENT_DIR . '/debug-sync.log';
        file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] sync_order_cycles START\n", FILE_APPEND);
        
        $results = [];
        $order_id = $order->get_id();
        
        // Find booking IDs from order items
        $booking_ids = [];
        foreach ($order->get_items() as $item) {
            if ($booking_id = $item->get_meta('_booking_id')) {
                if (is_array($booking_id)) {
                    $booking_ids = array_merge($booking_ids, $booking_id);
                } else {
                    $booking_ids[] = (int) $booking_id;
                }
            }
        }
        
        file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Found booking IDs from items meta: " . json_encode($booking_ids) . "\n", FILE_APPEND);
        
        // Fallback: Try WC_Booking_Data_Store if no IDs found in items meta
        if (empty($booking_ids) && class_exists('WC_Booking_Data_Store')) {
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] No booking IDs in meta, trying WC_Booking_Data_Store...\n", FILE_APPEND);
            
            $data_store = new WC_Booking_Data_Store();
            $fallback_booking_ids = $data_store->get_booking_ids_from_order_id($order_id);
            
            if (!empty($fallback_booking_ids)) {
                $booking_ids = array_map('intval', $fallback_booking_ids);
                file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Found booking IDs via WC_Booking_Data_Store: " . json_encode($booking_ids) . "\n", FILE_APPEND);
            }
        }
        
        file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Final booking IDs: " . json_encode($booking_ids) . "\n", FILE_APPEND);
        
        if (empty($booking_ids)) {
            // Still no bookings found - this is a critical error
            $error_msg = __('No bookings found for this order. The order may not be a booking order, or booking data is missing.', 'at-bookings-api-fixes');
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] ERROR: $error_msg\n", FILE_APPEND);
            
            return [[
                'success' => false, 
                'message' => $error_msg,
                'method' => 'sync_order_cycles',
                'step' => 'validation'
            ]];
        }
        
        // Process each booking from WC_Bookings
        if (!class_exists('WC_Booking_Data_Store')) {
            // Fallback to custom tables if WC_Bookings not available
            $slots_table = $wpdb->prefix . 'at_booking_slots';
            $slot_bookings_table = $wpdb->prefix . 'at_slot_bookings';
            
            $slots = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT s.* FROM {$slots_table} s
                    JOIN {$slot_bookings_table} sb ON s.id = sb.slot_id
                    WHERE sb.order_id = %d",
                    $order_id
                ),
                ARRAY_A
            );
            
            foreach ($slots as $slot) {
                if ($this->is_stopped()) {
                    break;
                }
                $results[] = $this->sync_cycle($slot, $order);
            }
        } else {
            // Use WC_Bookings directly (preferred method)
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Using WC_Bookings Data Store\n", FILE_APPEND);
            
            foreach ($booking_ids as $booking_id) {
                if ($this->is_stopped()) {
                    break;
                }
                
                file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Processing booking ID: $booking_id\n", FILE_APPEND);
                
                $booking = get_wc_booking($booking_id);
                if (!$booking || !$booking->get_id()) {
                    file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Booking not found or invalid\n", FILE_APPEND);
                    continue;
                }
                
                $product = $booking->get_product();
                if (!$product) {
                    file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Product not found for booking\n", FILE_APPEND);
                    continue;
                }
                
                file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Booking start: " . gmdate('Y-m-d H:i:s', $booking->get_start()) . "\n", FILE_APPEND);
                
                // Convert WC_Booking to slot format
                $slot = [
                    'id' => $booking->get_id(),
                    'product_id' => $product->get_id(),
                    'slot_start' => gmdate('Y-m-d H:i:s', $booking->get_start()),
                    'slot_end' => gmdate('Y-m-d H:i:s', $booking->get_end()),
                    'status' => $booking->get_status(),
                    'zoho_cycle_id' => get_post_meta($booking->get_id(), '_zoho_cycle_id', true),
                    'tour_id' => $product->get_id() . '_' . (int)$booking->get_start(),
                    'current_bookings' => 1, // Single booking
                ];
                
                $results[] = $this->sync_cycle($slot, $order);
            }
        }
        
        file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] sync_order_cycles returning " . count($results) . " results\n", FILE_APPEND);
        
        return $results ?: [['success' => false, 'message' => __('No cycles to sync', 'at-bookings-api-fixes'), 'method' => 'sync_order_cycles']];
    }
    
    /**
     * Sync individual cycle/slot
     * 
     * @param array $slot Slot data
     * @param WC_Order $order Order object
     * @return array Sync result
     */
    public function sync_cycle($slot, $order = null) {
        if (!$this->zoho_api) {
            return ['success' => false, 'message' => 'Zoho CRM not available', 'method' => 'sync_cycle'];
        }
        
        try {
            $product = wc_get_product($slot['product_id']);
            $cycle_data = AT_Zoho_Mapper::map_to_cycle($slot, $product);
            
            // SKIP field validation for Cycles - Zoho will validate
            // Basic check for critical fields
            if (empty($cycle_data['Name']) || empty($cycle_data['Tour_SKU'])) {
                return [
                    'success' => false,
                    'message' => __('Cycle must have Name and Tour_SKU', 'at-bookings-api-fixes'),
                    'method' => 'sync_cycle',
                    'step' => 'validation'
                ];
            }
            
            // CRITICAL: Cycle must have Product link for sync
            if (empty($cycle_data['Product'])) {
                return [
                    'success' => false,
                    'message' => __('Cycle must have Product link. Product must be synced to Zoho first.', 'at-bookings-api-fixes'),
                    'method' => 'sync_cycle',
                    'step' => 'validation',
                    'details' => 'Product ID (SKU) not found in Zoho. Sync the product first.'
                ];
            }
            
            // Find existing cycle
            $existing = $this->find_existing_cycle($slot['tour_id']);
            
            if ($existing) {
                // Update existing cycle
                $result = $this->zoho_api->update_record('Cycles', $existing['id'], $cycle_data);
                $this->log_api_call("Update Cycle #{$existing['id']}", $cycle_data, $result, $slot['id']);
                
                if ($result['success']) {
                    $this->update_slot_zoho_id($slot['id'], $existing['id']);
                    
                    // 🔧 FIX: Use consistent cache key (same as find_existing_cycle)
                    $cache_key = 'at_zoho_cycle_' . md5($slot['tour_id']);
                    set_transient($cache_key, $existing, 12 * HOUR_IN_SECONDS);
                    
                    // Also save in option for backward compatibility
                    $option_key = 'at_zoho_cycle_id_' . md5($slot['tour_id']);
                    update_option($option_key, $existing['id'], 'no');
                }
                
                return [
                    'success' => $result['success'],
                    'message' => $result['success'] ? sprintf(__('Cycle "%s" updated', 'at-bookings-api-fixes'), $slot['tour_id']) : $result['message'],
                    'zoho_id' => $existing['id'],
                    'action' => 'update',
                    'method' => 'sync_cycle',
                    'step' => 'cycle_update',
                    'request_data' => $cycle_data,
                    'response_status' => $result['success'] ? 'success' : 'error',
                    'response_message' => $result['message'] ?? ($result['success'] ? __('Updated successfully', 'at-bookings-api-fixes') : __('Unknown error', 'at-bookings-api-fixes')),
                ];
                
            } else {
                // Create new cycle
                $result = $this->zoho_api->create_record('Cycles', $cycle_data);
                $this->log_api_call("Create Cycle", $cycle_data, $result, $slot['id']);
                
                // 🔍 CRITICAL: Validate we got a real Zoho ID back
                $zoho_id = $result['id'] ?? null;
                $has_valid_id = !empty($zoho_id) && is_string($zoho_id) && strlen($zoho_id) > 0;
                
                // Only mark as success if we have a valid Zoho ID!
                $actual_success = $result['success'] && $has_valid_id;
                
                if ($actual_success) {
                    $this->update_slot_zoho_id($slot['id'], $zoho_id);
                    
                    // 🔧 FIX: Cache the newly created cycle (same key as find_existing_cycle)
                    $cache_key = 'at_zoho_cycle_' . md5($slot['tour_id']);
                    $cycle_record = ['id' => $zoho_id] + $cycle_data;  // Combine ID with data
                    set_transient($cache_key, $cycle_record, 12 * HOUR_IN_SECONDS);
                    write_detailed_log("Cached newly created cycle for {$slot['tour_id']}: $zoho_id", 'DEBUG');
                    
                    // Also save in option for backward compatibility
                    $option_key = 'at_zoho_cycle_id_' . md5($slot['tour_id']);
                    update_option($option_key, $zoho_id, 'no');
                }
                
                return [
                    'success' => $actual_success,  // ⚠️ True ONLY if we have valid ID
                    'message' => $actual_success 
                        ? sprintf(__('Cycle "%s" created', 'at-bookings-api-fixes'), $slot['tour_id']) 
                        : ($result['message'] ?? __('Failed to create cycle - no ID returned', 'at-bookings-api-fixes')),
                    'zoho_id' => $zoho_id,
                    'action' => 'create',
                    'method' => 'sync_cycle',
                    'step' => 'cycle_create',
                    'request_data' => $cycle_data,
                    'response_status' => $actual_success ? 'success' : 'error',
                    'response_message' => $result['message'] ?? ($actual_success ? __('Created successfully', 'at-bookings-api-fixes') : __('No Zoho ID returned', 'at-bookings-api-fixes')),
                    'raw_response' => $result,  // Full response for debugging
                ];
            }
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage(),
                'method' => 'sync_cycle',
                'step' => 'exception'
            ];
        }
    }
    
    /**
     * Update an existing cycle in Zoho (without searching or creating)
     * 
     * Used when you already know the Zoho cycle ID and just want to update it.
     * This is useful for bulk updates where we've already verified existence.
     * 
     * @param array $slot Slot data with 'tour_id' and timing info
     * @param string $zoho_cycle_id Zoho cycle record ID
     * @param WC_Product|null $product Related product
     * @return array Sync result
     */
    public function update_cycle_only($slot, $zoho_cycle_id, $product = null) {
        if (!$this->zoho_api) {
            return ['success' => false, 'message' => __('Zoho CRM not available', 'at-bookings-api-fixes'), 'method' => 'update_cycle_only'];
        }
        
        if (empty($zoho_cycle_id)) {
            return ['success' => false, 'message' => __('Zoho cycle ID is required', 'at-bookings-api-fixes'), 'method' => 'update_cycle_only'];
        }
        
        try {
            // Load product if not provided
            if (!$product) {
                $product = wc_get_product($slot['product_id']);
            }
            
            if (!$product) {
                return ['success' => false, 'message' => __('Product not found', 'at-bookings-api-fixes'), 'method' => 'update_cycle_only'];
            }
            
            // Map to cycle data (centralized mapping)
            $cycle_data = AT_Zoho_Mapper::map_to_cycle($slot, $product);
            
            // SKIP field validation - Zoho will validate
            // Basic check for critical fields
            if (empty($cycle_data['Name']) || empty($cycle_data['Tour_SKU'])) {
                return [
                    'success' => false,
                    'message' => __('Cycle must have Name and Tour_SKU', 'at-bookings-api-fixes'),
                    'method' => 'update_cycle_only',
                    'step' => 'validation'
                ];
            }
            
            // CRITICAL: Cycle must have Product link
            if (empty($cycle_data['Product'])) {
                return [
                    'success' => false,
                    'message' => __('Cycle must have Product link. Product must be synced to Zoho first.', 'at-bookings-api-fixes'),
                    'method' => 'update_cycle_only',
                    'step' => 'validation'
                ];
            }
            
            // Update the record directly (no search, no create)
            $result = $this->zoho_api->update_record('Cycles', $zoho_cycle_id, $cycle_data);
            $this->log_api_call("Update Cycle (Direct) #{$zoho_cycle_id}", $cycle_data, $result, $slot['id'] ?? null);
            
            return [
                'success' => $result['success'],
                'message' => $result['success'] ? sprintf(__('Cycle "%s" updated', 'at-bookings-api-fixes'), $slot['tour_id']) : $result['message'],
                'zoho_id' => $zoho_cycle_id,
                'action' => 'update_only',
                'method' => 'update_cycle_only',
                'step' => 'cycle_update',
                'request_data' => $cycle_data,
                'response_status' => $result['success'] ? 'success' : 'error',
                'response_message' => $result['message'] ?? ($result['success'] ? __('Updated successfully', 'at-bookings-api-fixes') : __('Unknown error', 'at-bookings-api-fixes')),
            ];
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage(),
                'method' => 'update_cycle_only',
                'step' => 'exception'
            ];
        }
    }
    
    /**
     * Sync order record (Lead or Sales_Order)
     * 
     * @param WC_Order $order Order object
     * @param string $contact_id Zoho Contact ID (required)
     * @param string $cycle_id Zoho Cycle ID (required)
     * @return array Sync result
     */
    /**
     * Sync order record (Sales_Order or Lead)
     * 
     * @param WC_Order $order Order object
     * @param string $contact_id Zoho Contact ID
     * @param string $cycle_id Zoho Cycle ID
     * @param int $booking_index Index of booking (for multi-booking orders)
     * @return array Result
     */
    private function sync_order_record($order, $contact_id = null, $cycle_id = null, $booking_index = 0) {
        if (!$this->zoho_api) {
            return ['success' => false, 'message' => 'Zoho CRM not available', 'method' => 'sync_order_record'];
        }
        
        // Validate prerequisites
        if (!$contact_id) {
            return [
                'success' => false,
                'message' => __('Contact ID required to create Order', 'at-bookings-api-fixes'),
                'method' => 'sync_order_record',
                'step' => 'validation'
            ];
        }
        
        if (!$cycle_id) {
            return [
                'success' => false,
                'message' => __('Cycle ID required to create Order', 'at-bookings-api-fixes'),
                'method' => 'sync_order_record',
                'step' => 'validation'
            ];
        }
        
        $order_id = $order->get_id();
        $order_status = $order->get_status();
        
        // 🔍 Determine sync type: Sales_Order (paid) vs Lead (unpaid)
        // Sales_Order: completed, processing (שולמה/מעובדת)
        // Lead: pending, on-hold, failed, cancelled (לא שולמה)
        $paid_statuses = ['completed', 'processing'];
        $is_paid = in_array($order_status, $paid_statuses, true) || $order->is_paid();
        
        write_detailed_log(sprintf(
            '🔍 Order #%d Status: %s, Is Paid: %s → Will sync as: %s',
            $order_id,
            $order_status,
            $is_paid ? 'YES' : 'NO',
            $is_paid ? 'Sales_Order' : 'Lead'
        ), 'INFO');
        
        try {
            if ($is_paid) {
                // ✅ הזמנה שולמה → Sales_Order (עבור כל booking בנפרד)
                return $this->sync_sales_order($order, $contact_id, $cycle_id, $booking_index);
            } else {
                // ⏳ הזמנה לא שולמה → Lead (עבור כל booking בנפרד)
                return $this->sync_lead($order, $contact_id, $cycle_id, $booking_index);
            }
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => $e->getMessage(),
                'method' => 'sync_order_record',
                'step' => 'exception'
            ];
        }
    }
    
    /**
     * Sync as Sales_Order (paid orders)
     * 
     * @param WC_Order $order Order object
     * @param string $contact_id Zoho Contact ID
     * @param string $cycle_id Zoho Cycle ID
     * @param int $booking_index Index of booking (for multi-booking orders)
     * @return array Result
     */
    private function sync_sales_order($order, $contact_id, $cycle_id, $booking_index = 0) {
        $order_id = $order->get_id();
        
        // 🔍 Get ALL booking IDs from order (for multi-booking support)
        $all_booking_ids = AT_Zoho_Mapper::get_all_booking_ids_from_order($order);
        
        // Use the specific booking ID for this cycle
        $booking_id = isset($all_booking_ids[$booking_index]) ? $all_booking_ids[$booking_index] : null;
        
        // Get slot data for linking
        $slot_data = $this->get_order_slot_data($order);
        
        // Add Zoho IDs to slot data for proper linking
        if (!$slot_data) {
            $slot_data = [];
        }
        $slot_data['zoho_cycle_id'] = $cycle_id;
        
        // CRITICAL LOGGING: Verify cycle_id is passed to mapper
        $log_file = WP_CONTENT_DIR . '/debug-sync.log';
        file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] sync_sales_order: cycle_id = " . ($cycle_id ?: 'NULL') . "\n", FILE_APPEND);
        file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] sync_sales_order: slot_data[zoho_cycle_id] = " . ($slot_data['zoho_cycle_id'] ?? 'NULL') . "\n", FILE_APPEND);
        
        $sales_order_data = AT_Zoho_Mapper::map_to_sales_order($order, $slot_data);
        
        // CRITICAL LOGGING: Check if Cycle_rel is in the final payload
        file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] sync_sales_order: Cycle_rel in payload = " . (isset($sales_order_data['Cycle_rel']) ? json_encode($sales_order_data['Cycle_rel']) : 'NOT_SET') . "\n", FILE_APPEND);
        if (isset($sales_order_data['Ordered_Items']) && is_array($sales_order_data['Ordered_Items'])) {
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] sync_sales_order: First item Cycle_rel = " . (isset($sales_order_data['Ordered_Items'][0]['Cycle_rel']) ? json_encode($sales_order_data['Ordered_Items'][0]['Cycle_rel']) : 'NOT_SET') . "\n", FILE_APPEND);
        }
        
        // CRITICAL: Ensure Contact_Name lookup exists (mapper should set it, but verify)
        if (empty($sales_order_data['Contact_Name'])) {
            $sales_order_data['Contact_Name'] = ['id' => $contact_id];
        }
        
        // CRITICAL: Ensure Cycle_rel lookup exists (mapper should set it, but verify)
        if (empty($sales_order_data['Cycle_rel'])) {
            $sales_order_data['Cycle_rel'] = ['id' => $cycle_id];
        }
        
        // CRITICAL: Ensure Cycle_rel is in EVERY item in Ordered_Items subform
        // This is crucial - each ordered item must link to its cycle
        if (!empty($sales_order_data['Ordered_Items']) && is_array($sales_order_data['Ordered_Items'])) {
            foreach ($sales_order_data['Ordered_Items'] as $idx => &$item) {
                if (empty($item['Cycle_rel']) || empty($item['Cycle_rel']['id'])) {
                    $item['Cycle_rel'] = ['id' => $cycle_id];
                    file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] sync_sales_order: Added Cycle_rel to Ordered_Items[$idx] = $cycle_id\n", FILE_APPEND);
                }
            }
            unset($item); // Break reference
        }
        
        // Same for Product_Details (standard field)
        if (!empty($sales_order_data['Product_Details']) && is_array($sales_order_data['Product_Details'])) {
            foreach ($sales_order_data['Product_Details'] as $idx => &$item) {
                if (empty($item['Cycle_rel']) || empty($item['Cycle_rel']['id'])) {
                    $item['Cycle_rel'] = ['id' => $cycle_id];
                    file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] sync_sales_order: Added Cycle_rel to Product_Details[$idx] = $cycle_id\n", FILE_APPEND);
                }
            }
            unset($item); // Break reference
        }
        
        // SKIP field validation for Sales_Orders - Zoho will validate
        // Critical checks - ensure all required lookups exist
        
        // 1. Check Contact Name lookup (required!)
        if (empty($sales_order_data['Contact_Name']['id'])) {
            return [
                'success' => false,
                'message' => __('Sales Order requires Contact_Name lookup', 'at-bookings-api-fixes'),
                'method' => 'sync_sales_order',
                'step' => 'validation'
            ];
        }
        
        // 2. Check Cycle_rel lookup (required!)
        if (empty($sales_order_data['Cycle_rel']['id'])) {
            return [
                'success' => false,
                'message' => __('Sales Order requires Cycle_rel lookup', 'at-bookings-api-fixes'),
                'method' => 'sync_sales_order',
                'step' => 'validation'
            ];
        }
        
        // 3. Check Product IDs in items (at least one item should have product lookup)
        $has_product_link = false;
        if (!empty($sales_order_data['Product_Details']) && is_array($sales_order_data['Product_Details'])) {
            foreach ($sales_order_data['Product_Details'] as $item) {
                // Check both 'product' (standard) and 'Product_Name' (custom)
                if (!empty($item['product']['id']) || !empty($item['Product_Name']['id'])) {
                    $has_product_link = true;
                    break;
                }
            }
        }
        
        if (!$has_product_link) {
            write_detailed_log('WARNING: Sales Order has no Product links in Ordered_Items. Products should be synced first.', 'WARNING');
            // Don't fail - just warn
        }
        
        // CRITICAL LOGGING: Dump full payload before sending to Zoho
        file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] ========== FULL SALES ORDER PAYLOAD ==========\n", FILE_APPEND);
        file_put_contents($log_file, json_encode($sales_order_data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . "\n", FILE_APPEND);
        file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] ===============================================\n", FILE_APPEND);
        
        // Find existing sales order for this specific booking
        $existing = $this->find_existing_sales_order($order_id, $booking_id, $cycle_id);
        
        if ($existing) {
            // Update existing order
            $result = $this->zoho_api->update_record('Sales_Orders', $existing['id'], $sales_order_data);
            $this->log_api_call("Update Sales_Order #{$existing['id']} (Booking #{$booking_id})", $sales_order_data, $result, $order_id);
            
            if ($result['success']) {
                // 🔄 Store Sales_Order ID with booking index for multi-booking support
                $this->save_sales_order_id($order_id, $existing['id'], $booking_index, $booking_id);
            }
            
            return [
                'success' => $result['success'],
                'message' => $result['success'] 
                    ? sprintf(__('Sales Order updated (Booking #%d)', 'at-bookings-api-fixes'), $booking_index + 1)
                    : $result['message'],
                'zoho_id' => $existing['id'],
                'booking_id' => $booking_id,
                'booking_index' => $booking_index,
                'cycle_id' => $cycle_id,
                'action' => 'update',
                'method' => 'sync_sales_order',
                'step' => 'sales_order_update'
            ];
            
        } else {
            // Create new
            
            // DEBUG: Log the exact data being sent (for troubleshooting)
            AT_Bookings_Logger::debug('🚀 SENDING TO ZOHO - Sales_Order CREATE', [
                'order_id' => $order_id,
                'booking_id' => $booking_id,
                'booking_index' => $booking_index,
                'cycle_id' => $cycle_id,
                'data_keys' => array_keys($sales_order_data),
                'full_data' => $sales_order_data
            ]);
            error_log(sprintf(
                '🚀 ZOHO API CALL - Sales_Order CREATE for Order #%d (Booking #%d, Index %d)',
                $order_id,
                $booking_id,
                $booking_index
            ));
            error_log('📦 DATA BEING SENT: ' . json_encode($sales_order_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            
            $result = $this->zoho_api->create_record('Sales_Orders', $sales_order_data);
            $this->log_api_call("Create Sales_Order (Booking #{$booking_id})", $sales_order_data, $result, $order_id);
            
            // DEBUG: Log the response
            AT_Bookings_Logger::debug('📥 RESPONSE FROM ZOHO', [
                'success' => $result['success'] ?? false,
                'message' => $result['message'] ?? 'N/A',
                'full_response' => $result
            ]);
            error_log('📥 ZOHO RESPONSE: ' . json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            
            if ($result['success'] && !empty($result['id'])) {
                // 🔄 Store Sales_Order ID with booking index for multi-booking support
                $this->save_sales_order_id($order_id, $result['id'], $booking_index, $booking_id);
            }
            
            return [
                'success' => $result['success'],
                'message' => $result['success'] 
                    ? sprintf(__('Sales Order created (Booking #%d)', 'at-bookings-api-fixes'), $booking_index + 1)
                    : $result['message'],
                'zoho_id' => $result['id'] ?? null,
                'booking_id' => $booking_id,
                'booking_index' => $booking_index,
                'cycle_id' => $cycle_id,
                'action' => 'create',
                'method' => 'sync_sales_order',
                'step' => 'sales_order_create'
            ];
        }
    }
    
    /**
     * Sync as Lead (unpaid orders)
     * 
     * @param WC_Order $order Order object
     * @param string $contact_id Zoho Contact ID
     * @param string $cycle_id Zoho Cycle ID
     * @param int $booking_index Index of booking (for multi-booking orders)
     * @return array Result
     */
    private function sync_lead($order, $contact_id, $cycle_id, $booking_index = 0) {
        $order_id = $order->get_id();
        
        // 🔍 Get ALL booking IDs from order (for multi-booking support)
        $all_booking_ids = AT_Zoho_Mapper::get_all_booking_ids_from_order($order);
        
        // Use the specific booking ID for this cycle
        $booking_id = isset($all_booking_ids[$booking_index]) ? $all_booking_ids[$booking_index] : null;
        
        $slot_data = $this->get_order_slot_data($order);
        
        // Add Zoho IDs for proper linking
        if (!$slot_data) {
            $slot_data = [];
        }
        $slot_data['zoho_cycle_id'] = $cycle_id;
        
        $lead_data = AT_Zoho_Mapper::map_to_lead($order, $slot_data);
        
        // CRITICAL: Override/add Contact and Cycle IDs
        // Note: Field names may vary - adjust based on actual Zoho Lead schema
        if (isset($lead_data['Contact_ID'])) {
            $lead_data['Contact_ID'] = $contact_id;
        }
        
        // Store Cycle ID in custom field
        $lead_data['Cycle_ID'] = $cycle_id;
        
        // SKIP field validation for Leads - Zoho will validate
        // Critical checks - ensure basic data exists
        
        // 1. Check Last Name or Email
        if (empty($lead_data['Last_Name']) && empty($lead_data['Email'])) {
            return [
                'success' => false,
                'message' => __('Lead requires Last_Name or Email', 'at-bookings-api-fixes'),
                'method' => 'sync_lead',
                'step' => 'validation'
            ];
        }
        
        // 2. Check Cycle ID (if added to lead_data)
        if (!empty($lead_data['Cycle_ID']) && $lead_data['Cycle_ID'] === $cycle_id) {
            // Cycle ID is set correctly
        } else {
            write_detailed_log('WARNING: Lead missing Cycle_ID reference', 'WARNING');
        }
        
        // Find existing lead for this specific booking
        $existing = $this->find_existing_lead($order_id, $booking_id, $cycle_id);
        
        if ($existing) {
            // Update existing
            $result = $this->zoho_api->update_record('Leads', $existing['id'], $lead_data);
            $this->log_api_call("Update Lead #{$existing['id']} (Booking #{$booking_id})", $lead_data, $result, $order_id);
            
            if ($result['success']) {
                // 🔄 Store Lead ID with booking index for multi-booking support
                $this->save_lead_id($order_id, $existing['id'], $booking_index, $booking_id);
            }
            
            return [
                'success' => $result['success'],
                'message' => $result['success'] 
                    ? sprintf(__('Lead updated (Booking #%d)', 'at-bookings-api-fixes'), $booking_index + 1)
                    : $result['message'],
                'zoho_id' => $existing['id'],
                'booking_id' => $booking_id,
                'booking_index' => $booking_index,
                'cycle_id' => $cycle_id,
                'action' => 'update',
                'method' => 'sync_lead',
                'step' => 'lead_update'
            ];
            
        } else {
            // Create new
            $result = $this->zoho_api->create_record('Leads', $lead_data);
            $this->log_api_call("Create Lead (Booking #{$booking_id})", $lead_data, $result, $order_id);
            
            if ($result['success'] && !empty($result['id'])) {
                // 🔄 Store Lead ID with booking index for multi-booking support
                $this->save_lead_id($order_id, $result['id'], $booking_index, $booking_id);
            }
            
            return [
                'success' => $result['success'],
                'message' => $result['success'] 
                    ? sprintf(__('Lead created (Booking #%d)', 'at-bookings-api-fixes'), $booking_index + 1)
                    : $result['message'],
                'zoho_id' => $result['id'] ?? null,
                'booking_id' => $booking_id,
                'booking_index' => $booking_index,
                'cycle_id' => $cycle_id,
                'action' => 'create',
                'method' => 'sync_lead',
                'step' => 'lead_create'
            ];
        }
    }
    
    /**
     * Find existing contact by email or phone
     */
    private function find_existing_contact($order) {
        $log_file = WP_CONTENT_DIR . '/debug-sync.log';
        $logs = class_exists('AT_Zoho_Sync_Logs') ? AT_Zoho_Sync_Logs::get_instance() : null;
        
        try {
            $email = $order->get_billing_email();
            $phone = $order->get_billing_phone();
            
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] find_existing_contact: Email=$email, Phone=$phone\n", FILE_APPEND);
            
            if ($email) {
                file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Searching by email...\n", FILE_APPEND);
                $result = $this->zoho_api->search_records('Contacts', 'Email', $email);
                file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Email search result: " . json_encode($result) . "\n", FILE_APPEND);
                
                // Log to database
                if ($logs) {
                    $logs->log_sync(
                        'search',
                        'Contacts',
                        $order->get_id(),
                        (!empty($result['data']) && isset($result['data'][0]['id'])) ? $result['data'][0]['id'] : null,
                        (isset($result['success']) && $result['success']) ? 'success' : 'error',
                        ['Email' => $email],
                        $result,
                        (isset($result['success']) && !$result['success']) ? ($result['message'] ?? null) : null,
                        null, // api_url
                        null, // http_method
                        null  // api_version
                    );
                }
                
                if (isset($result['success']) && $result['success'] && !empty($result['data'])) {
                    file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Found by email: {$result['data'][0]['id']}\n", FILE_APPEND);
                    return $result['data'][0];
                }
                
                if (isset($result['success']) && !$result['success']) {
                    file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Email search failed: " . ($result['message'] ?? 'Unknown error') . "\n", FILE_APPEND);
                }
            }
            
            if ($phone) {
                file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Searching by phone...\n", FILE_APPEND);
                $result = $this->zoho_api->search_records('Contacts', 'Phone', $phone);
                file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Phone search result: " . json_encode($result) . "\n", FILE_APPEND);
                
                // Log to database
                if ($logs) {
                    $logs->log_sync(
                        'search',
                        'Contacts',
                        $order->get_id(),
                        (!empty($result['data']) && isset($result['data'][0]['id'])) ? $result['data'][0]['id'] : null,
                        (isset($result['success']) && $result['success']) ? 'success' : 'error',
                        ['Phone' => $phone],
                        $result,
                        (isset($result['success']) && !$result['success']) ? ($result['message'] ?? null) : null,
                        null, // api_url
                        null, // http_method
                        null  // api_version
                    );
                }
                
                if (isset($result['success']) && $result['success'] && !empty($result['data'])) {
                    file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Found by phone: {$result['data'][0]['id']}\n", FILE_APPEND);
                    return $result['data'][0];
                }
                
                if (isset($result['success']) && !$result['success']) {
                    file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Phone search failed: " . ($result['message'] ?? 'Unknown error') . "\n", FILE_APPEND);
                }
            }
            
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] No existing contact found\n", FILE_APPEND);
            return null;
            
        } catch (Exception $e) {
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] EXCEPTION in find_existing_contact: " . $e->getMessage() . "\n", FILE_APPEND);
            file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Trace: " . $e->getTraceAsString() . "\n", FILE_APPEND);
            
            // Log exception to database
            if ($logs) {
                $logs->log_sync(
                    'search',
                    'Contacts',
                    $order->get_id(),
                    null,
                    'error',
                    ['Email' => $email ?? null, 'Phone' => $phone ?? null],
                    null,
                    $e->getMessage()
                ,
                        null, // api_url
                        null, // http_method
                        null  // api_version
                    );
            }
            
            return null; // Return null on error to allow creation
        }
    }
    
    /**
     * Find existing product by Product_Code or PID
     */
    private function find_existing_product($product) {
        $logs = class_exists('AT_Zoho_Sync_Logs') ? AT_Zoho_Sync_Logs::get_instance() : null;
        
        try {
            $sku = $product->get_sku();
            $product_id = $product->get_id();
            
            if ($sku) {
                $result = $this->zoho_api->search_records('Products', 'Product_Code', $sku);
                
                // Log to database
                if ($logs) {
                    $logs->log_sync(
                        'search',
                        'Products',
                        $product_id,
                        (!empty($result['data']) && isset($result['data'][0]['id'])) ? $result['data'][0]['id'] : null,
                        (isset($result['success']) && $result['success']) ? 'success' : 'error',
                        ['Product_Code' => $sku],
                        $result,
                        (isset($result['success']) && !$result['success']) ? ($result['message'] ?? null) : null,
                        null, // api_url
                        null, // http_method
                        null  // api_version
                    );
                }
                
                if (isset($result['success']) && $result['success'] && !empty($result['data'])) {
                    return $result['data'][0];
                }
            }
            
            // Search by PID (WordPress Product ID)
            $result = $this->zoho_api->search_records('Products', 'PID', $product_id);
            
            // Log to database
            if ($logs) {
                $logs->log_sync(
                    'search',
                    'Products',
                    $product_id,
                    (!empty($result['data']) && isset($result['data'][0]['id'])) ? $result['data'][0]['id'] : null,
                    (isset($result['success']) && $result['success']) ? 'success' : 'error',
                    ['PID' => $product_id],
                    $result,
                    (isset($result['success']) && !$result['success']) ? ($result['message'] ?? null) : null
                ,
                        null, // api_url
                        null, // http_method
                        null  // api_version
                    );
            }
            
            if (isset($result['success']) && $result['success'] && !empty($result['data'])) {
                return $result['data'][0];
            }
            
            return null;
        } catch (Exception $e) {
            write_detailed_log('find_existing_product exception: ' . $e->getMessage(), 'ERROR');
            
            // Log exception to database
            if ($logs) {
                $logs->log_sync(
                    'search',
                    'Products',
                    $product->get_id(),
                    null,
                    'error',
                    ['Product_Code' => $sku ?? null, 'PID' => $product_id ?? null],
                    null,
                    $e->getMessage()
                ,
                        null, // api_url
                        null, // http_method
                        null  // api_version
                    );
            }
            
            return null;
        }
    }
    
    /**
     * Find existing cycle by Tour_SKU
     * 
     * Includes transient caching to avoid redundant API searches during bulk syncs.
     * Cache is valid for 12 hours (43200 seconds) or cleared manually.
     */
    private function find_existing_cycle($tour_id) {
        $logs = class_exists('AT_Zoho_Sync_Logs') ? AT_Zoho_Sync_Logs::get_instance() : null;
        
        // Check cache first (only for positive results - actual cycle data)
        $cache_key = 'at_zoho_cycle_' . md5($tour_id);
        $cached_cycle = get_transient($cache_key);
        
        // 🔧 CRITICAL FIX: Only use cache if it contains actual cycle data (not null)
        // Never return null from cache - always perform fresh search if not found before
        if ($cached_cycle !== false && $cached_cycle !== null && is_array($cached_cycle)) {
            // Actual cycle data from cache
            $cycle_id = isset($cached_cycle['id']) ? $cached_cycle['id'] : 'unknown';
            write_detailed_log("✅ Found cycle in cache for $tour_id: $cycle_id", 'INFO');
            return $cached_cycle;
        }
        
        // No cache or invalid cache - perform fresh search
        write_detailed_log("🔍 No valid cache for $tour_id - performing fresh search", 'DEBUG');
        
        try {
            // 🔍 Try multiple search strategies to find existing cycle
            $result = null;
            
            // Strategy 1: Search by Tour_SKU (preferred - unique identifier)
            write_detailed_log("Searching for cycle by Tour_SKU: $tour_id", 'DEBUG');
            $result = $this->zoho_api->search_records('Cycles', 'Tour_SKU', $tour_id);
            
            // Strategy 2: If not found by Tour_SKU, try by Name (fallback)
            if (isset($result['success']) && $result['success'] && empty($result['data'])) {
                // Build expected cycle name from tour_id
                // tour_id format: "product_id_timestamp" (e.g., "3176_1767634400")
                $parts = explode('_', $tour_id);
                if (count($parts) >= 2) {
                    $timestamp = end($parts);
                    $cycle_date = date('d/m H:i', $timestamp);
                    
                    // Get product to find city
                    $product_id = (int)$parts[0];
                    $product = wc_get_product($product_id);
                    $city = 'Unknown';
                    
                    if ($product) {
                        $terms = wp_get_post_terms($product_id, 'pa_city', array('fields' => 'names'));
                        if (!empty($terms)) {
                            $city = $terms[0];
                        }
                    }
                    
                    $expected_name = $cycle_date . ' - ' . $city;
                    write_detailed_log("Cycle not found by Tour_SKU, trying by Name: $expected_name", 'DEBUG');
                    
                    $result = $this->zoho_api->search_records('Cycles', 'Name', $expected_name);
                }
            }
            
            // Log to database
            if ($logs) {
                $logs->log_sync(
                    'search',
                    'Cycles',
                    null,
                    (!empty($result['data']) && isset($result['data'][0]['id'])) ? $result['data'][0]['id'] : null,
                    (isset($result['success']) && $result['success']) ? 'success' : 'error',
                    ['Tour_SKU' => $tour_id],
                    $result,
                    (isset($result['success']) && !$result['success']) ? ($result['message'] ?? null) : null
                ,
                        null, // api_url
                        null, // http_method
                        null  // api_version
                    );
            }
            
            if (isset($result['success']) && $result['success'] && !empty($result['data'])) {
                $cycle_record = $result['data'][0];
                $zoho_id = $cycle_record['id'] ?? 'unknown';
                
                // Cache the result for 12 hours (43200 seconds)
                // This prevents redundant API calls during bulk syncs
                set_transient($cache_key, $cycle_record, 12 * HOUR_IN_SECONDS);
                write_detailed_log("✅ Found existing cycle for $tour_id in Zoho: $zoho_id", 'INFO');
                
                return $cycle_record;
            }
            
            // 🔧 FIX: Don't cache negative results!
            // If cycle not found now, it might be created next, so we should search again
            // Only cache successful finds to avoid blocking new cycle creation
            write_detailed_log("ℹ️ Cycle NOT found in Zoho for $tour_id (will create new)", 'INFO');
            return null;
            
        } catch (Exception $e) {
            write_detailed_log('find_existing_cycle exception: ' . $e->getMessage(), 'ERROR');
            
            // Log exception to database
            if ($logs) {
                $logs->log_sync(
                    'search',
                    'Cycles',
                    null,
                    null,
                    'error',
                    ['Tour_SKU' => $tour_id],
                    null,
                    $e->getMessage()
                ,
                        null, // api_url
                        null, // http_method
                        null  // api_version
                    );
            }
            
            return null;
        }
    }
    
    /**
     * Clear cycle cache for a specific tour_id
     * 
     * Use this when updating a cycle to ensure fresh data on next lookup
     * 
     * @param string $tour_id Tour ID (used to generate cache key)
     */
    public function clear_cycle_cache($tour_id) {
        $cache_key = 'at_zoho_cycle_' . md5($tour_id);
        delete_transient($cache_key);
        write_detailed_log("Cleared cycle cache for $tour_id", 'DEBUG');
    }
    
    /**
     * Find existing sales order by OID + BID + Cycle
     * 
     * 🔄 UPDATED: Support multi-booking by searching with Cycle_rel ID
     * 
     * @param int $order_id WooCommerce Order ID
     * @param int $booking_id WooCommerce Booking ID
     * @param string $cycle_id Zoho Cycle ID (optional)
     * @return array|null Zoho Sales_Order record or null
     */
    private function find_existing_sales_order($order_id, $booking_id, $cycle_id = null) {
        $logs = class_exists('AT_Zoho_Sync_Logs') ? AT_Zoho_Sync_Logs::get_instance() : null;
        
        try {
            // Search by OID first
            $result = $this->zoho_api->search_records('Sales_Orders', 'OID', $order_id);
            
            // Log to database
            if ($logs) {
                $logs->log_sync(
                    'search',
                    'Sales_Orders',
                    $order_id,
                    (!empty($result['data']) && isset($result['data'][0]['id'])) ? $result['data'][0]['id'] : null,
                    (isset($result['success']) && $result['success']) ? 'success' : 'error',
                    ['OID' => $order_id, 'BID' => $booking_id, 'Cycle_ID' => $cycle_id],
                    $result,
                    (isset($result['success']) && !$result['success']) ? ($result['message'] ?? null) : null
                ,
                        null, // api_url
                        null, // http_method
                        null  // api_version
                    );
            }
            
            if (isset($result['success']) && $result['success'] && !empty($result['data'])) {
                // 🔍 Filter by BID AND/OR Cycle_rel for multi-booking support
                foreach ($result['data'] as $record) {
                    // Priority 1: Match by Cycle_rel (most specific)
                    if ($cycle_id && isset($record['Cycle_rel']['id']) && $record['Cycle_rel']['id'] === $cycle_id) {
                        return $record;
                    }
                    
                    // Priority 2: Match by BID (backward compatibility)
                    if ($booking_id && isset($record['BID']) && (int) $record['BID'] === $booking_id) {
                        return $record;
                    }
                }
                
                // Fallback: Return first if no specific match (backward compatibility)
                if (!$booking_id && !$cycle_id) {
                    return $result['data'][0];
                }
            }
            
            return null;
        } catch (Exception $e) {
            write_detailed_log('find_existing_sales_order exception: ' . $e->getMessage(), 'ERROR');
            
            // Log exception to database
            if ($logs) {
                $logs->log_sync(
                    'search',
                    'Sales_Orders',
                    $order_id,
                    null,
                    'error',
                    ['OID' => $order_id, 'BID' => $booking_id, 'Cycle_ID' => $cycle_id],
                    null,
                    $e->getMessage()
                ,
                        null, // api_url
                        null, // http_method
                        null  // api_version
                    );
            }
            
            return null;
        }
    }
    
    /**
     * Save Sales_Order ID to order meta (supports multi-booking)
     * 
     * 🔄 NEW: Store multiple Sales_Order IDs in array format
     * 
     * @param int $order_id WooCommerce Order ID
     * @param string $sales_order_id Zoho Sales_Order ID
     * @param int $booking_index Booking index (0, 1, 2, ...)
     * @param int $booking_id WooCommerce Booking ID
     */
    private function save_sales_order_id($order_id, $sales_order_id, $booking_index, $booking_id) {
        // Get existing Sales_Order IDs array
        $existing_ids = get_post_meta($order_id, '_zoho_sales_order_ids', true);
        
        if (!is_array($existing_ids)) {
            // Initialize array if doesn't exist
            $existing_ids = [];
            
            // Migrate old single ID if exists
            $old_single_id = get_post_meta($order_id, '_zoho_sales_order_id', true);
            if ($old_single_id) {
                $existing_ids[0] = [
                    'zoho_id' => $old_single_id,
                    'booking_id' => null,
                    'created_at' => current_time('mysql')
                ];
            }
        }
        
        // Store new Sales_Order ID with metadata
        $existing_ids[$booking_index] = [
            'zoho_id' => $sales_order_id,
            'booking_id' => $booking_id,
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql')
        ];
        
        // Save array
        update_post_meta($order_id, '_zoho_sales_order_ids', $existing_ids);
        
        // Also update single ID for backward compatibility (use first one)
        if ($booking_index === 0) {
            update_post_meta($order_id, '_zoho_sales_order_id', $sales_order_id);
        }
        
        write_detailed_log(sprintf(
            '💾 Saved Sales_Order ID: %s (Booking Index: %d, Booking ID: %d) for Order #%d',
            $sales_order_id,
            $booking_index,
            $booking_id,
            $order_id
        ), 'INFO');
    }
    
    /**
     * Save Lead ID to order meta (supports multi-booking)
     * 
     * 🔄 NEW: Store multiple Lead IDs in array format
     * 
     * @param int $order_id WooCommerce Order ID
     * @param string $lead_id Zoho Lead ID
     * @param int $booking_index Booking index (0, 1, 2, ...)
     * @param int $booking_id WooCommerce Booking ID
     */
    private function save_lead_id($order_id, $lead_id, $booking_index, $booking_id) {
        // Get existing Lead IDs array
        $existing_ids = get_post_meta($order_id, '_zoho_lead_ids', true);
        
        if (!is_array($existing_ids)) {
            // Initialize array if doesn't exist
            $existing_ids = [];
            
            // Migrate old single ID if exists
            $old_single_id = get_post_meta($order_id, '_zoho_lead_id', true);
            if ($old_single_id) {
                $existing_ids[0] = [
                    'zoho_id' => $old_single_id,
                    'booking_id' => null,
                    'created_at' => current_time('mysql')
                ];
            }
        }
        
        // Store new Lead ID with metadata
        $existing_ids[$booking_index] = [
            'zoho_id' => $lead_id,
            'booking_id' => $booking_id,
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql')
        ];
        
        // Save array
        update_post_meta($order_id, '_zoho_lead_ids', $existing_ids);
        
        // Also update single ID for backward compatibility (use first one)
        if ($booking_index === 0) {
            update_post_meta($order_id, '_zoho_lead_id', $lead_id);
        }
        
        write_detailed_log(sprintf(
            '💾 Saved Lead ID: %s (Booking Index: %d, Booking ID: %d) for Order #%d',
            $lead_id,
            $booking_index,
            $booking_id,
            $order_id
        ), 'INFO');
    }
    
    /**
     * Find existing lead by WP_OID + WP_BID + Cycle
     * 
     * 🔄 UPDATED: Support multi-booking by searching with Cycle_ID
     * 
     * @param int $order_id WooCommerce Order ID
     * @param int $booking_id WooCommerce Booking ID
     * @param string $cycle_id Zoho Cycle ID (optional)
     * @return array|null Zoho Lead record or null
     */
    private function find_existing_lead($order_id, $booking_id, $cycle_id = null) {
        $logs = class_exists('AT_Zoho_Sync_Logs') ? AT_Zoho_Sync_Logs::get_instance() : null;
        
        try {
            $result = $this->zoho_api->search_records('Leads', 'WP_OID', $order_id);
            
            // Log to database
            if ($logs) {
                $logs->log_sync(
                    'search',
                    'Leads',
                    $order_id,
                    (!empty($result['data']) && isset($result['data'][0]['id'])) ? $result['data'][0]['id'] : null,
                    (isset($result['success']) && $result['success']) ? 'success' : 'error',
                    ['WP_OID' => $order_id, 'WP_BID' => $booking_id, 'Cycle_ID' => $cycle_id],
                    $result,
                    (isset($result['success']) && !$result['success']) ? ($result['message'] ?? null) : null
                ,
                        null, // api_url
                        null, // http_method
                        null  // api_version
                    );
            }
            
            if (isset($result['success']) && $result['success'] && !empty($result['data'])) {
                // 🔍 Filter by Cycle_ID AND/OR WP_BID for multi-booking support
                foreach ($result['data'] as $record) {
                    // Priority 1: Match by Cycle_ID (most specific)
                    if ($cycle_id && isset($record['Cycle_ID']) && $record['Cycle_ID'] === $cycle_id) {
                        return $record;
                    }
                    
                    // Priority 2: Match by WP_BID (backward compatibility)
                    if ($booking_id && isset($record['WP_BID']) && (int) $record['WP_BID'] === $booking_id) {
                        return $record;
                    }
                }
                
                // Fallback: Return first if no specific match (backward compatibility)
                if (!$booking_id && !$cycle_id) {
                    return $result['data'][0];
                }
            }
            
            return null;
        } catch (Exception $e) {
            write_detailed_log('find_existing_lead exception: ' . $e->getMessage(), 'ERROR');
            
            // Log exception to database
            if ($logs) {
                $logs->log_sync(
                    'search',
                    'Leads',
                    $order_id,
                    null,
                    'error',
                    ['WP_OID' => $order_id, 'WP_BID' => $booking_id, 'Cycle_ID' => $cycle_id],
                    null,
                    $e->getMessage()
                ,
                        null, // api_url
                        null, // http_method
                        null  // api_version
                    );
            }
            
            return null;
        }
    }
    
    /**
     * Update computed fields in Zoho
     */
    private function update_computed_fields($order) {
        // This would update computed fields like participant counts and revenue
        // Implementation depends on specific Zoho workflow requirements
        
        return [
            'success' => true,
            'message' => __('Computed fields updated', 'at-bookings-api-fixes'),
            'method' => 'update_computed_fields',
            'step' => 'computed_update'
        ];
    }
    
    /**
     * Get order slot data
     */
    private function get_order_slot_data($order) {
        global $wpdb;
        
        $slots_table = $wpdb->prefix . 'at_booking_slots';
        $slot_bookings_table = $wpdb->prefix . 'at_slot_bookings';
        
        $slot = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT s.* FROM {$slots_table} s
                JOIN {$slot_bookings_table} sb ON s.id = sb.slot_id
                WHERE sb.order_id = %d
                LIMIT 1",
                $order->get_id()
            ),
            ARRAY_A
        );
        
        // FALLBACK: If no slot found in custom table, try to build from WC_Booking
        if (!$slot) {
            AT_Bookings_Logger::debug('No slot found in at_slot_bookings table, trying WC_Booking fallback', [
                'order_id' => $order->get_id()
            ]);
            
            $booking_ids = WC_Booking_Data_Store::get_booking_ids_from_order_id($order->get_id());
            if (!empty($booking_ids)) {
                $booking_id = reset($booking_ids);
                $booking = get_wc_booking($booking_id);
                
                if ($booking && $booking->get_id()) {
                    $product_id = $booking->get_product_id();
                    $start_timestamp = $booking->get_start();
                    $end_timestamp = $booking->get_end();
                    
                    // Build slot data from WC_Booking
                    $slot = [
                        'id' => null, // No custom table ID
                        'product_id' => $product_id,
                        'slot_start' => date('Y-m-d H:i:s', $start_timestamp),
                        'slot_end' => date('Y-m-d H:i:s', $end_timestamp),
                        'tour_id' => $product_id . '_' . $start_timestamp,
                        'booking_id' => $booking_id,
                        'fallback_source' => 'wc_booking' // Mark as fallback data
                    ];
                    
                    AT_Bookings_Logger::info('Built slot data from WC_Booking', [
                        'order_id' => $order->get_id(),
                        'booking_id' => $booking_id,
                        'product_id' => $product_id,
                        'tour_id' => $slot['tour_id']
                    ]);
                }
            }
        }
        
        // If slot found but missing tour_id, generate it
        if ($slot && empty($slot['tour_id'])) {
            $slot_start = strtotime($slot['slot_start']);
            $slot['tour_id'] = $slot['product_id'] . '_' . (int)$slot_start;
        }
        
        // Add booking/WC_Booking data if available
        // This provides tickets_types from the API format
        if ($slot) {
            // Get WC_Booking data
            $booking_ids = WC_Booking_Data_Store::get_booking_ids_from_order_id($order->get_id());
            if (!empty($booking_ids)) {
                $booking_id = reset($booking_ids);
                $booking = get_wc_booking($booking_id);
                
                if ($booking && $booking->get_id()) {
                    // Add ticket types data
                    $person_counts = $booking->get_person_counts();
                    $person_type_posts = get_posts([
                        'post_type'      => 'bookable_person',
                        'post_status'    => 'publish',
                        'posts_per_page' => -1,
                        'orderby'        => 'menu_order',
                        'order'          => 'ASC',
                        'post_parent'    => $slot['product_id']
                    ]);
                    
                    $tickets_types = [];
                    foreach ($person_type_posts as $person_type) {
                        $person_id = $person_type->ID;
                        $count = isset($person_counts[$person_id]) ? (int) $person_counts[$person_id] : 0;
                        
                        $tickets_types[] = [
                            'id'           => $person_id,
                            'name'         => $person_type->post_title,
                            'ticket_price' => (float) get_post_meta($person_id, 'cost', true),
                            'count'        => $count
                        ];
                    }
                    
                    // Only add if we have ticket types
                    if (!empty($tickets_types)) {
                        $slot['tickets_types'] = $tickets_types;
                    }
                }
            }
        }
        
        return $slot;
    }
    
    /**
     * Update slot with Zoho cycle ID
     */
    private function update_slot_zoho_id($slot_id, $zoho_cycle_id) {
        global $wpdb;
        
        $slots_table = $wpdb->prefix . 'at_booking_slots';
        
        $wpdb->update(
            $slots_table,
            ['zoho_cycle_id' => $zoho_cycle_id],
            ['id' => $slot_id],
            ['%s'],
            ['%d']
        );
    }
    
    /**
     * Record sync start in order meta
     */
    private function record_sync_start($order_id, $trigger) {
        $timestamp = current_time('mysql');
        update_post_meta($order_id, '_zoho_sync_last_started', $timestamp);
        update_post_meta($order_id, '_zoho_sync_last_trigger', $trigger);
        
        // Also update global sync time option
        update_option('at_zoho_last_sync_time', $timestamp);
        update_option('at_zoho_last_sync_type', $trigger);
        
        // Log sync start
        error_log("AT Bookings: Zoho sync started for order #{$order_id} (trigger: {$trigger})");
    }
    
    /**
     * Record sync results in order notes
     */
    private function record_sync_results($order_id, $results, $trigger) {
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }
        
        $timestamp = current_time('mysql');
        $success_count = 0;
        $total_steps = count($results['steps']);
        
        foreach ($results['steps'] as $step) {
            if ($step['success']) {
                $success_count++;
            }
        }
        
        // Add summary note (existing behavior)
        $note = sprintf(
            __('Zoho Sync %s (%s) - %d/%d steps successful', 'at-bookings-api-fixes'),
            $trigger === 'manual' ? __('Manual', 'at-bookings-api-fixes') : __('Automatic', 'at-bookings-api-fixes'),
            $timestamp,
            $success_count,
            $total_steps
        );
        
        // Add detailed steps
        foreach ($results['steps'] as $step) {
            $note .= "\n- " . ($step['success'] ? '✓' : '✗') . ' ' . $step['message'];
            if (!empty($step['method'])) {
                $note .= ' [' . $step['method'] . ']';
            }
        }
        
        $order->add_order_note($note, false, true);
        
        // NEW: Update meta fields for better tracking
        $this->update_order_meta_fields($order, $results);
    }
    
    /**
     * Set stop flag
     */
    public function set_stop_flag() {
        set_transient($this->stop_flag_key, true, self::STOP_FLAG_DURATION);
    }
    
    /**
     * Clear stop flag
     */
    public function clear_stop_flag() {
        delete_transient($this->stop_flag_key);
    }
    
    /**
     * Check if sync should be stopped
     */
    private function is_stopped() {
        return get_transient($this->stop_flag_key) === true;
    }
    
    /**
     * Validate order before sync - check basic requirements
     * 
     * @param WC_Order $order Order object
     * @return array {valid, errors}
     */
    private function validate_order_before_sync(WC_Order $order) {
        $errors = [];
        
        // 1. Check billing email (required for Contact)
        if (!$order->get_billing_email()) {
            $errors[] = __('Order missing billing email (required for Contact)', 'at-bookings-api-fixes');
        }
        
        // 2. Check customer name (at least last name required)
        if (!$order->get_billing_last_name() && !$order->get_billing_first_name()) {
            $errors[] = __('Order missing customer name', 'at-bookings-api-fixes');
        }
        
        // 3. Check order has items
        if (count($order->get_items()) === 0) {
            $errors[] = __('Order has no items', 'at-bookings-api-fixes');
        }
        
        // 4. REMOVED: Booking ID check - causes false negatives
        // Booking might exist but not be found by get_booking_id_from_order()
        // Let the sync process handle missing booking data
        
        return [
            'valid' => empty($errors),
            'errors' => $errors
        ];
    }
    
    /**
     * Add order note for sync operation
     * Note: is_customer_note = false means it won't email the customer
     * 
     * @param WC_Order $order Order object
     * @param array $result Result from sync operation
     */
    public function add_order_note(WC_Order $order, $result) {
        $note = $this->format_sync_note($result);
        if (!empty($note)) {
            $order->add_order_note($note, false, true);
        }
    }
    
    /**
     * Format sync result into readable order note
     * 
     * @param array $result Sync result
     * @return string Formatted note
     */
    private function format_sync_note($result) {
        $timestamp = current_time('mysql');
        $status = $result['success'] ? '✓ Success' : '✗ Failed';
        $action = $result['action'] ?? $result['step'] ?? 'Unknown Action';
        $module = $result['module'] ?? 'Unknown Module';
        
        $note = sprintf(
            "[Zoho Sync - %s]\nAction: %s\nModule: %s\nStatus: %s",
            $timestamp,
            $action,
            $module,
            $status
        );
        
        if (isset($result['zoho_id'])) {
            $note .= "\nZoho ID: " . $result['zoho_id'];
        }
        
        if ($result['message'] ?? false) {
            $note .= "\nMessage: " . $result['message'];
        }
        
        $note .= "\n---";
        
        return $note;
    }
    
    /**
     * REMOVED: find_or_create_cycle() - USE find_existing_cycle() INSTEAD
     * This function was duplicating existing logic.
     * Use find_existing_cycle() which has caching and proper error handling.
     * 
     * Wrapper for backward compatibility with admin/zoho-order-sync.php
     */
    public function find_or_create_cycle($slot, $product) {
        $tour_id = $slot['tour_id'] ?? null;
        
        if (!$tour_id) {
            // Generate tour_id if missing
            if (isset($slot['slot_start']) && isset($slot['product_id'])) {
                $slot_start = strtotime($slot['slot_start']);
                $tour_id = $slot['product_id'] . '_' . (int)$slot_start;
            }
        }
        
        if (!$tour_id) {
            return [
                'success' => false,
                'id' => null,
                'created' => false,
                'message' => __('Cannot search cycle - missing tour_id', 'at-bookings-api-fixes')
            ];
        }
        
        // Use existing find_existing_cycle() with caching
        $existing = $this->find_existing_cycle($tour_id);
        
        if ($existing && isset($existing['id'])) {
            return [
                'success' => true,
                'id' => $existing['id'],
                'created' => false,
                'message' => sprintf(__('Cycle found by Tour_SKU: %s', 'at-bookings-api-fixes'), $tour_id)
            ];
        }
        
        // Cycle NOT found - return error (don't create!)
        $error_msg = sprintf(
            __('Cycle not found in Zoho (Tour_SKU: %s). Please sync cycle first before syncing order.', 'at-bookings-api-fixes'),
            $tour_id
        );
        
        write_detailed_log($error_msg, 'ERROR');
        
        return [
            'success' => false,
            'id' => null,
            'created' => false,
            'message' => $error_msg,
            'tour_sku' => $tour_id
        ];
    }
    
    /**
     * Update order meta fields based on sync results
     * 
     * @param WC_Order $order Order object
     * @param array $results All sync results
     */
    public function update_order_meta_fields(WC_Order $order, $results) {
        $order_id = $order->get_id();
        $timestamp = current_time('mysql');
        
        // Update Contact ID
        if ($results['entities']['contact']['success'] ?? false) {
            update_post_meta($order_id, '_zoho_contact_id', $results['entities']['contact']['zoho_id']);
            update_post_meta($order_id, '_zoho_last_sync_contact', $timestamp);
        }
        
        // Update Products IDs
        if ($results['entities']['products'] ?? false) {
            $product_ids = [];
            foreach ($results['entities']['products'] as $product_result) {
                if ($product_result['success'] && isset($product_result['zoho_id'])) {
                    $product_ids[] = $product_result['zoho_id'];
                }
            }
            if (!empty($product_ids)) {
                update_post_meta($order_id, '_zoho_product_ids', $product_ids);
            }
        }
        
        // Update Cycle/Slot IDs
        if ($results['entities']['cycles'] ?? false) {
            $cycle_ids = [];
            foreach ($results['entities']['cycles'] as $cycle_result) {
                if ($cycle_result['success'] && isset($cycle_result['zoho_id'])) {
                    $cycle_ids[] = $cycle_result['zoho_id'];
                }
            }
            if (!empty($cycle_ids)) {
                update_post_meta($order_id, '_zoho_cycle_ids', $cycle_ids);
                update_post_meta($order_id, '_zoho_last_sync_cycle', $timestamp);
            }
        }
        
        // Update Order (Sales_Order or Lead) IDs
        // 🔄 UPDATED: Handle multiple orders (multi-booking support)
        if (!empty($results['entities']['orders']) && is_array($results['entities']['orders'])) {
            $successful_orders = array_filter($results['entities']['orders'], function($order_result) {
                return $order_result['success'] ?? false;
            });
            
            if (!empty($successful_orders)) {
                // Note: Individual order IDs are saved in save_sales_order_id() and save_lead_id()
                // Here we just update the timestamp
                update_post_meta($order_id, '_zoho_last_sync_order', $timestamp);
                
                // Log summary
                write_detailed_log(sprintf(
                    '✅ Successfully synced %d orders for Order #%d',
                    count($successful_orders),
                    $order_id
                ), 'INFO');
            }
        }
        
        // Update overall sync metadata
        update_post_meta($order_id, '_zoho_last_sync_started', $timestamp);
        update_post_meta($order_id, '_zoho_last_sync_trigger', 'manual');
        
        $overall_status = $results['success'] ? 'success' : 'partial';
        update_post_meta($order_id, '_zoho_sync_status', $overall_status);
    }
    
    /**
     * Clear ALL cycle cache transients
     * 
     * Use this before bulk sync to ensure fresh data for all cycles
     * This prevents old cached Zoho IDs from interfering with new syncs
     * 
     * @return int Number of transients cleared
     */
    public function clear_all_cycles_cache() {
        global $wpdb;
        
        // Find all transients matching our cycle cache pattern
        $transients = $wpdb->get_results(
            "SELECT option_name FROM {$wpdb->options} 
             WHERE option_name LIKE '%_transient_at_zoho_cycle_%'
             LIMIT 1000"
        );
        
        $cleared_count = 0;
        
        if (!empty($transients)) {
            foreach ($transients as $transient) {
                // Extract transient key (remove '_transient_' prefix)
                $transient_key = str_replace('_transient_', '', $transient->option_name);
                delete_transient($transient_key);
                $cleared_count++;
            }
        }
        
        write_detailed_log("Cleared $cleared_count cycle cache transients", 'INFO');
        
        return $cleared_count;
    }
}

// ============================================================================
// AJAX HANDLER FOR SINGLE CYCLE SYNC (from Slots Management page)
// ============================================================================

/**
 * AJAX handler for syncing a single cycle to Zoho
 * Called from: Slots Management admin page (sync-cycle button)
 * 
 * POST Parameters:
 * - action: 'at_sync_single_cycle'
 * - nonce: security nonce
 * - tour_id: unique cycle identifier (product_id_timestamp)
 * - product_id: WooCommerce product ID
 * - cycle_data: JSON string of cycle data to sync
 */
add_action('wp_ajax_at_sync_single_cycle', function() {
    // 🔒 Security check
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'at_slots_management_nonce')) {
        wp_send_json_error(__('Security verification failed', 'at-bookings-api-fixes'));
        return;
    }
    
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
        return;
    }
    
    // 📥 Get parameters
    $tour_id = isset($_POST['tour_id']) ? sanitize_text_field($_POST['tour_id']) : '';
    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    // ⚠️ Important: DO NOT use sanitize_text_field on JSON!
    // It removes JSON structural characters. Use wp_unslash instead.
    $cycle_data_json = isset($_POST['cycle_data']) ? wp_unslash($_POST['cycle_data']) : '';
    
    if (!$tour_id || !$product_id) {
        wp_send_json_error(__('Missing required parameters', 'at-bookings-api-fixes'));
        return;
    }
    
    try {
        // 🔍 Parse cycle data
        $cycle_data = json_decode($cycle_data_json, true);
        if (!is_array($cycle_data)) {
            // Debug: log what we received
            write_detailed_log("Failed to decode JSON. Received: " . substr($cycle_data_json, 0, 100), 'ERROR');
            throw new Exception(__('Invalid cycle data format', 'at-bookings-api-fixes'));
        }
        
        // ✅ Get the sync service
        if (!class_exists('AT_Zoho_Sync_Service')) {
            throw new Exception(__('Sync service not available', 'at-bookings-api-fixes'));
        }
        
        $sync_service = new AT_Zoho_Sync_Service();
        
        // 🎯 Get the product for sync
        $product = wc_get_product($product_id);
        if (!$product) {
            throw new Exception(sprintf(__('Product %d not found', 'at-bookings-api-fixes'), $product_id));
        }
        
        // 🚀 Sync the cycle
        // Build slot_data from cycle_data for sync_cycle function
        $slot_data = array(
            'id' => null,
            'product_id' => $product_id,
            'slot_start' => isset($cycle_data['startCycle_datatime']) ? $cycle_data['startCycle_datatime'] : '',
            'tour_id' => $tour_id,
            'status' => isset($cycle_data['Status_Cycle']) ? $cycle_data['Status_Cycle'] : 'pending',
        );
        
        // 🚀 Execute the sync
        $sync_result = $sync_service->sync_cycle($slot_data, $product);
        
        // 📝 Log sync result (simplified to avoid timeout)
        write_detailed_log('Sync cycle result - Tour ID: ' . $tour_id . ', Success: ' . ($sync_result['success'] ? 'yes' : 'no'), 'DEBUG');
        
        // 🔍 CRITICAL: Verify actual success with Zoho ID validation
        // Don't trust success flag alone - verify we got a real Zoho ID!
        $zoho_id = $sync_result['zoho_id'] ?? '';
        $has_valid_id = !empty($zoho_id) && $zoho_id !== '' && $zoho_id !== 'null' && strlen($zoho_id) > 5;
        
        if ($sync_result['success'] && $has_valid_id) {
            // ✨ Real Success - we have a valid Zoho ID
            write_detailed_log('✅ Cycle synced: ' . $tour_id . ' → ' . $zoho_id, 'INFO');
            
            // 💾 Cache the Zoho ID for frontend display
            $cache_key = 'at_zoho_cycle_id_' . md5($tour_id);
            update_option($cache_key, $zoho_id, 'no');
            
            // 📤 Return response immediately (minimal data to avoid timeout)
            wp_send_json_success(array(
                'message' => $sync_result['message'],
                'zoho_id' => $zoho_id,
                'action' => $sync_result['action'] ?? 'unknown',
                'zoho_message' => $sync_result['response_message'] ?? 'record added'
            ));
        } else {
            // ❌ Failed - either success=false OR no valid Zoho ID
            
            // 📤 Prepare error response with EXACT Zoho message
            $zoho_raw_message = null;
            $zoho_full_response = null;
            
            // Extract exact message from Zoho
            if (isset($sync_result['raw_response'])) {
                $zoho_full_response = $sync_result['raw_response'];
                
                // Try to extract message from various response structures
                if (isset($sync_result['raw_response']['message'])) {
                    $zoho_raw_message = $sync_result['raw_response']['message'];
                } elseif (isset($sync_result['raw_response']['data'][0]['message'])) {
                    $zoho_raw_message = $sync_result['raw_response']['data'][0]['message'];
                } elseif (isset($sync_result['raw_response']['data'][0]['details']['message'])) {
                    $zoho_raw_message = $sync_result['raw_response']['data'][0]['details']['message'];
                }
            }
            
            // Use exact Zoho message if available, otherwise our processed message
            $error_msg = $zoho_raw_message ?? $sync_result['message'] ?? __('Sync failed without specific error', 'at-bookings-api-fixes');
            
            // If false positive, add warning prefix
            if ($sync_result['success'] && !$has_valid_id) {
                $error_msg = '⚠️ False positive detected!\n\n' . $error_msg;
            }
            
            $error_details = array(
                'sync_result' => $sync_result,
                'zoho_id_received' => $zoho_id,
                'has_valid_id' => $has_valid_id,
                'slot_data_sent' => $slot_data
            );
            
            write_detailed_log('❌ Cycle sync FAILED: ' . $error_msg, 'ERROR');
            
            // 📤 Return error with minimal data (avoid timeout)
            wp_send_json_error(array(
                'message' => $error_msg,
                'zoho_message' => $zoho_raw_message ?? 'No Zoho message'
            ));
        }
        
    } catch (Exception $e) {
        write_detailed_log('Cycle sync exception: ' . $e->getMessage(), 'ERROR');
        wp_send_json_error($e->getMessage());
    }
    
    // This should not be reached
    wp_send_json_error(__('Unknown error occurred', 'at-bookings-api-fixes'));
});

// ============================================================================
// DEBUG HELPER: Get Cycles Module Fields from Zoho
// ============================================================================

/**
 * AJAX handler to get all fields from Zoho Cycles module
 * This helps verify which fields actually exist in your Zoho setup
 */
add_action('wp_ajax_at_get_cycles_fields', function() {
    // Security check
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'at_slots_management_nonce')) {
        wp_send_json_error('Security verification failed');
        return;
    }
    
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Insufficient permissions');
        return;
    }
    
    try {
        if (!class_exists('AT_Zoho_API')) {
            wp_send_json_error('Zoho API not available');
            return;
        }
        
        $zoho_api = AT_Zoho_API::get_instance();
        $fields = $zoho_api->get_module_fields('Cycles');
        
        if (empty($fields)) {
            wp_send_json_error('No fields returned from Zoho');
            return;
        }
        
        // Extract relevant info for each field
        $field_list = array();
        foreach ($fields as $field) {
            $field_list[] = array(
                'api_name' => $field['api_name'] ?? 'unknown',
                'field_label' => $field['field_label'] ?? 'unknown',
                'data_type' => $field['data_type'] ?? 'unknown',
                'json_type' => $field['json_type'] ?? 'unknown',
                'read_only' => $field['read_only'] ?? false,
                'system_mandatory' => $field['system_mandatory'] ?? false,
                'custom_field' => $field['custom_field'] ?? false,
                'lookup' => isset($field['lookup']) ? $field['lookup']['module']['api_name'] : null
            );
        }
        
        write_detailed_log('Fetched ' . count($field_list) . ' fields from Cycles module', 'INFO');
        
        wp_send_json_success(array(
            'total_fields' => count($field_list),
            'fields' => $field_list
        ));
        
    } catch (Exception $e) {
        write_detailed_log('Error getting Cycles fields: ' . $e->getMessage(), 'ERROR');
        wp_send_json_error($e->getMessage());
    }
});

// ============================================================================
// AJAX HANDLER: Clear ALL Cycle Cache
// ============================================================================

/**
 * AJAX handler to manually clear all cycle cache transients
 * Called from: Initial Sync page (Clear Cache button)
 * 
 * Clears all cached cycle data to force fresh lookups in Zoho
 * Useful after deleting records in Zoho or when sync is stuck
 */
add_action('wp_ajax_at_clear_cycles_cache', function() {
    // Security check
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'at_bookings_dashboard')) {
        wp_send_json_error('Security verification failed');
        return;
    }
    
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error('Insufficient permissions');
        return;
    }
    
    try {
        if (!class_exists('AT_Zoho_Sync_Service')) {
            wp_send_json_error('Sync service not available');
            return;
        }
        
        $sync_service = new AT_Zoho_Sync_Service();
        $cleared_count = $sync_service->clear_all_cycles_cache();
        
        write_detailed_log("Manual cache clear: $cleared_count transients removed", 'INFO');
        
        wp_send_json_success(array(
            'message' => sprintf(__('Cleared %d cycle cache entries', 'at-bookings-api-fixes'), $cleared_count),
            'count' => $cleared_count
        ));
        
    } catch (Exception $e) {
        write_detailed_log('Error clearing cache: ' . $e->getMessage(), 'ERROR');
        wp_send_json_error($e->getMessage());
    }
});
