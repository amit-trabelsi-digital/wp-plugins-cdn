<?php
/**
 * Zoho Data Mapper
 * 
 * Maps WordPress/WooCommerce data to Zoho CRM format with exact field names
 * 
 * @package AT_Bookings_API_Fixes
 * @subpackage Zoho
 * @since 3.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Zoho_Mapper {
    
    /**
     * Map WordPress user/order data to Zoho Contact
     * 
     * @param WC_Order|WP_User $source Order or User object
     * @return array Zoho Contact payload
     */
    public static function map_to_contact($source, $context = []) {
        $data = [];
        
        if ($source instanceof WC_Order) {
            // Map from order billing data
            $data['First_Name'] = $source->get_billing_first_name() ?: '';
            $data['Last_Name'] = $source->get_billing_last_name() ?: __('Unknown', 'at-bookings-api-fixes');
            $data['Email'] = $source->get_billing_email() ?: '';
            $data['Phone'] = $source->get_billing_phone() ?: '';
            $data['Mailing_City'] = $source->get_billing_city() ?: '';
            $data['Mailing_Country'] = $source->get_billing_country() ?: '';
            $data['Mailing_Street'] = $source->get_billing_address_1() ?: '';
            
            // Custom fields
            $data['WP_User_ID'] = $source->get_user_id() ?: null;
            
            // Email_Opt_In - בדיקה אם הלקוח הסכים להצטרפות למועדון בcheckout
            // שדה checkout: club_registration (ב-checkout.php)
            $club_registration = $source->get_meta('club_registration', true);
            $email_opt_in_meta = $source->get_meta('email_opt_in', true);
            
            // 🔍 DEBUG: Log WooCommerce Email Opt-In detection
            if ( function_exists( 'write_detailed_log' ) ) {
                write_detailed_log( "🟡 ZOHO MAPPER - WC_Order #" . $source->get_id(), 'DEBUG' );
                write_detailed_log( "   club_registration meta value: " . var_export( $club_registration, true ), 'DEBUG' );
                write_detailed_log( "   club_registration type: " . gettype( $club_registration ), 'DEBUG' );
                write_detailed_log( "   club_registration === '1': " . ( $club_registration === '1' ? 'YES' : 'NO' ), 'DEBUG' );
                write_detailed_log( "   club_registration === 1: " . ( $club_registration === 1 ? 'YES' : 'NO' ), 'DEBUG' );
                write_detailed_log( "   club_registration == true: " . ( $club_registration == true ? 'YES' : 'NO' ), 'DEBUG' );
                write_detailed_log( "   email_opt_in meta value: " . var_export( $email_opt_in_meta, true ), 'DEBUG' );
                write_detailed_log( "   context['email_opt_in']: " . ( isset( $context['email_opt_in'] ) ? var_export( $context['email_opt_in'], true ) : '(not set)' ), 'DEBUG' );
            }
            
            // אם העביר בהקשר - השתמש בו, אחרת בדוק meta
            if (isset($context['email_opt_in'])) {
                $data['Email_Opt_In'] = $context['email_opt_in'] ? 'כן' : 'לא';
                if ( function_exists( 'write_detailed_log' ) ) {
                    write_detailed_log( "   ➡️ Using context['email_opt_in']: " . ( $context['email_opt_in'] ? 'TRUE → כן' : 'FALSE → לא' ), 'DEBUG' );
                }
            } elseif (!empty($email_opt_in_meta)) {
                // Check if we explicitly saved email_opt_in (from updated checkout.php)
                $data['Email_Opt_In'] = $email_opt_in_meta ? 'כן' : 'לא';
                if ( function_exists( 'write_detailed_log' ) ) {
                    write_detailed_log( "   ➡️ Using email_opt_in meta: " . ( $email_opt_in_meta ? 'TRUE → כן' : 'FALSE → לא' ), 'DEBUG' );
                }
            } elseif (!empty($club_registration)) {
                // checkbox "הצטרפות למועדון" מסומן = הסכמה לדיוור
                // Support multiple formats: '1', 1, 'on', true, etc.
                $is_checked = ( $club_registration === '1' || $club_registration === 1 || $club_registration === 'on' || $club_registration === true );
                $data['Email_Opt_In'] = $is_checked ? 'כן' : 'לא';
                if ( function_exists( 'write_detailed_log' ) ) {
                    write_detailed_log( "   ➡️ Using club_registration (flexible check): " . ( $is_checked ? 'TRUE → כן' : 'FALSE → לא' ), 'DEBUG' );
                }
            } else {
                // ברירת מחדל - עבור הזמנות מהאתר: "כן" (לקוח שמזמין = מעוניין)
                // 🔄 CHANGED: Default from "לא" to "כן" for orders
                $data['Email_Opt_In'] = 'כן';
                if ( function_exists( 'write_detailed_log' ) ) {
                    write_detailed_log( "   ➡️ Default (nothing found): TRUE → כן (order default)", 'DEBUG' );
                }
            }
            
            // Reffe - מקור הלקוח
            $data['Reffe'] = 'הזמנה - אתר';
            
        } elseif ($source instanceof WP_User) {
            // Map from user data
            $data['First_Name'] = $source->first_name ?: '';
            $data['Last_Name'] = $source->last_name ?: __('Unknown', 'at-bookings-api-fixes');
            $data['Email'] = $source->user_email ?: '';
            
            // Custom fields
            $data['WP_User_ID'] = $source->ID;
            
            // Email_Opt_In - ברירת מחדל "כן" (משתמש שנרשם באתר = מעוניין)
            // 🔄 CHANGED: Default from "לא" to "כן" for users
            $data['Email_Opt_In'] = isset($context['email_opt_in']) && $context['email_opt_in'] === false ? 'לא' : 'כן';
            
            // Reffe - מקור הלקוח
            $data['Reffe'] = isset($context['reffe']) ? $context['reffe'] : 'אתר';
            
        } elseif (is_array($source)) {
            // Map from Gravity Forms entry or array
            $data['First_Name'] = $source['firstname'] ?? $source['First_Name'] ?? '';
            $data['Last_Name'] = $source['lastname'] ?? $source['Last_Name'] ?? __('Unknown', 'at-bookings-api-fixes');
            $data['Email'] = $source['email'] ?? $source['Email'] ?? '';
            $data['Phone'] = $source['phone'] ?? $source['Phone'] ?? '';
            $data['Mailing_City'] = $source['city'] ?? $source['Mailing_City'] ?? '';
            $data['Mailing_Country'] = $source['country'] ?? $source['Mailing_Country'] ?? '';
            $data['Mailing_Street'] = $source['address'] ?? $source['Mailing_Street'] ?? '';
            
            // Custom fields
            $data['WP_User_ID'] = $source['user_id'] ?? $source['WP_User_ID'] ?? null;
            
            // 🔍 DEBUG: Log Gravity Forms Email Opt-In detection
            if ( function_exists( 'write_detailed_log' ) ) {
                write_detailed_log( "🟢 ZOHO MAPPER - Gravity Forms Array", 'DEBUG' );
                write_detailed_log( "   email_opt_in key exists: " . ( isset( $source['email_opt_in'] ) ? 'YES' : 'NO' ), 'DEBUG' );
                if ( isset( $source['email_opt_in'] ) ) {
                    write_detailed_log( "   email_opt_in value: " . var_export( $source['email_opt_in'], true ), 'DEBUG' );
                    write_detailed_log( "   email_opt_in type: " . gettype( $source['email_opt_in'] ), 'DEBUG' );
                }
            }
            
            // Email_Opt_In - הסכמה לדיוור (חובה!)
            // ברירת מחדל: "לא" אלא אם סומן בטופס
            if (isset($source['email_opt_in'])) {
                $opt_in_value = $source['email_opt_in'];
                $data['Email_Opt_In'] = $opt_in_value ? 'כן' : 'לא';
                if ( function_exists( 'write_detailed_log' ) ) {
                    write_detailed_log( "   ➡️ Email_Opt_In set to: " . ( $opt_in_value ? 'TRUE → כן' : 'FALSE → לא' ), 'DEBUG' );
                }
            } else {
                // ברירת מחדל - עבור טפסים: "כן" (מי שממלא טופס = מעוניין)
                // 🔄 CHANGED: Default from "לא" to "כן" for forms
                $data['Email_Opt_In'] = 'כן';
                if ( function_exists( 'write_detailed_log' ) ) {
                    write_detailed_log( "   ➡️ Email_Opt_In default: TRUE → כן (form default)", 'DEBUG' );
                }
            }
            
            // Reffe - מקור הלקוח
            // אם יש שם טופס מפורש בהקשר, השתמש בו
            if (!empty($context['form_name'])) {
                $data['Reffe'] = $context['form_name'];
            } 
            // אם יש שדה source
            elseif (!empty($source['source'])) {
                $data['Reffe'] = $source['source'];
            }
            // ברירת מחדל
            else {
                $data['Reffe'] = 'אתר';
            }
        }
        
        // Ensure required fields
        if (empty($data['Last_Name'])) {
            $data['Last_Name'] = __('Unknown', 'at-bookings-api-fixes');
        }
        
        // Note: Created_By is auto-set by Zoho based on API authentication
        
        return array_filter($data, function($value) {
            return $value !== null && $value !== '';
        });
    }
    
    /**
     * Map WooCommerce product to Zoho Product
     * 
     * @param WC_Product $product Product object
     * @return array Zoho Product payload
     */
    public static function map_to_product($product) {
        $product_id = $product->get_id();
        
        $data = [
            'Product_Name' => $product->get_name(),
            'Product_Code' => $product->get_sku() ?: '',
            'PID' => (string) $product_id, // Custom field - WordPress Product ID (must be string for Zoho)
            'Product_Active' => ($product->get_status() === 'publish'),
        ];
        
        // --- Description (Use Short Description) ---
        // User requested to use the short description (summary)
        $description = $product->get_short_description();
        if (empty($description)) {
            $description = $product->get_description();
        }
        $data['Description'] = strip_tags($description);
        
        // --- City Mapping ---
        $city = '';
        
        // 1. Try ACF 'TOUR_CITY'
        if (function_exists('get_field')) {
            $city = get_field('TOUR_CITY', $product_id);
        }
        
        // 2. Try Product Attributes (Global 'pa_city', Custom 'עיר', 'City')
        if (empty($city)) {
            $attributes = $product->get_attributes();
            
            foreach ($attributes as $attr) {
                // Check attribute name (slug) or label
                $attr_name = $attr->get_name();
                // We check for: pa_city, עיר (Hebrew), City (English)
                if ($attr_name === 'pa_city' || $attr_name === 'עיר' || $attr_name === 'City' || $attr_name === 'city') {
                    if ($attr->is_taxonomy()) {
                        $terms = wc_get_product_terms($product_id, $attr_name, array('fields' => 'names'));
                        if (!empty($terms) && !is_wp_error($terms)) {
                            $city = $terms[0];
                            break;
                        }
                    } else {
                        // Custom product attribute (text based)
                        $options = $attr->get_options();
                        if (!empty($options)) {
                            $city = $options[0]; // First value
                            break;
                        }
                    }
                }
            }
        }
        
        if (!empty($city)) {
            $data['Tour_City'] = $city;
        }
        
        // --- Duration ---
        if (function_exists('get_field')) {
            $duration = (int) get_field('TOUR_DURATION', $product_id);
            if ($duration > 0) {
                // ⚠️ TODO: Verify 'Tour_duration' API name
                // $data['Tour_duration'] = $duration;
            }
            
            // --- Pricing fields ---
            $adult_price = get_field('PRICE_ADULT', $product_id);
            $child_price = get_field('PRICE_CHILD', $product_id);
            $under5_price = get_field('PRICE_UNDER5', $product_id);
            
            if ($adult_price) {
                $data['Unit_Price'] = (float) $adult_price;
            }
            if ($child_price) {
                $data['Unit_Price2'] = (float) $child_price;
            }
            if ($under5_price) {
                $data['Unit_Price3'] = (float) $under5_price;
            }
        }
        
        // --- Accessibility fields (ACF field_6586e28d8df7c) ---
        if (function_exists('get_field')) {
            $accessibility = get_field('field_6586e28d8df7c', $product_id);
            
            // Parse accessibility value for wheelchair (Ally) and stroller (Babies)
            if (!empty($accessibility)) {
                // Could be array or comma-separated string
                $accessibility_values = is_array($accessibility) ? $accessibility : array_map('trim', explode(',', $accessibility));
                
                $has_wheelchair = false;
                $has_stroller = false;
                
                foreach ($accessibility_values as $value) {
                    $value_lower = strtolower($value);
                    if (strpos($value_lower, 'wheelchair') !== false || strpos($value_lower, 'כיסא') !== false) {
                        $has_wheelchair = true;
                    }
                    if (strpos($value_lower, 'stroller') !== false || strpos($value_lower, 'עגלה') !== false || strpos($value_lower, 'תינוק') !== false) {
                        $has_stroller = true;
                    }
                }
                
                // Fix: Send exact strings matching Zoho picklist options
                $data['Ally'] = $has_wheelchair ? 'כן' : 'לא';
                $data['Babies'] = $has_stroller ? 'כן' : 'לא';
            } else {
                $data['Ally'] = 'לא';
                $data['Babies'] = 'לא';
            }
        }
        
        // --- Participant Type (field7) Logic ---
        // If PRICE_CHILD exists -> "ילדים + מבוגרים", Else -> "מבוגרים בלבד"
        if (function_exists('get_field')) {
            $has_adult_price = !empty(get_field('PRICE_ADULT', $product_id));
            $has_child_price = !empty(get_field('PRICE_CHILD', $product_id));
            
            // Fix: Use exact values from screenshot
            if ($has_child_price) {
                $data['field7'] = 'ילדים + מבוגרים';
            } else {
                $data['field7'] = 'מבוגרים בלבד';
            }
        }
        
        // --- Person Types Support ---
        if ($product->get_type() === 'booking') {
            $has_persons = get_post_meta($product_id, '_wc_booking_has_persons', true);
            $has_person_types = get_post_meta($product_id, '_wc_booking_has_person_types', true);
            
            if ($has_persons === 'yes' || $has_person_types === 'yes') {
                $data['has_person'] = 'Yes'; // שדה Zoho
                
                // קבל person types
                $person_types = get_posts([
                    'post_type' => 'bookable_person',
                    'post_parent' => $product_id,
                    'post_status' => 'publish',
                    'numberposts' => -1
                ]);
                
                $person_types_data = [];
                foreach ($person_types as $person) {
                    $person_types_data[] = [
                        'type_id' => $person->ID,
                        'type_name' => $person->post_title,
                        'base_cost' => get_post_meta($person->ID, 'cost', true)
                    ];
                }
                
                // שמור כ-JSON (Zoho יתמוך)
                if (!empty($person_types_data)) {
                    $data['Person_Types_JSON'] = json_encode($person_types_data, JSON_UNESCAPED_UNICODE);
                }
            }
        }
        
        // --- Capacity fields from WC Bookings ---
        if ($product->get_type() === 'booking') {
            $max_capacity = (int) get_post_meta($product_id, '_wc_booking_qty', true) ?: 1;
            
            // Only override Ally/Babies if accessibility field wasn't set
            if (!isset($data['Ally']) || $data['Ally'] === 'לא') {
                // Set numeric capacity (though Zoho expects yes/no for these fields)
                // Keep as is from accessibility
            }
        }
        
        // Note: Created_By is auto-set by Zoho based on API authentication
        
        return array_filter($data, function($value) {
            return $value !== null && $value !== '';
        });
    }
    
    /**
     * Map booking slot to Zoho Cycle
     * 
     * @param array $slot Slot data from wp_at_booking_slots
     * @param WC_Product $product Related product
     * @return array Zoho Cycle payload
     */
    public static function map_to_cycle($slot, $product = null) {
        // לפי טבלת השדות בזוהו - רק שדות שאנחנו צריכים לשלוח
        // שדות Lookup (מיכום אופק) מחושבים אוטומטית ע"י Zoho
        
        // ⚠️ CRITICAL: NO timezone conversion! Treat time as absolute.
        // Use WordPress local time directly (already in Asia/Jerusalem from strtotime)
        // Simple date() formatting to avoid double conversions
        $slot_timestamp = strtotime($slot['slot_start']);
        
        // Format for display (local time) - no conversion, just formatting
        $cycle_date = date('d/m H:i', $slot_timestamp);  // Local time!
        
        // קבלת העיר מהמוצר
        $city = 'Unknown';
        if ($product) {
            $terms = wp_get_post_terms($product->get_id(), 'pa_city', array('fields' => 'names'));
            if (!empty($terms)) {
                $city = $terms[0];
            }
        }
        
        // בניית שם המחזור: DD/MM HH:MM - City (local time)
        $cycle_name = $cycle_date . ' - ' . $city;
        
        $data = [
            // **שדות חובה שאנחנו שולחים:**
            
            // שם המחזור (Name - חובה, טקסט) - בשעון מקומי
            'Name' => $cycle_name,
            
            // SKU של המחזור (Tour_SKU - מזהה ייחודי בZoho, חובה להימנע מכפילויות)
            'Tour_SKU' => $slot['tour_id'] ?? null,
            
            // קישור לעיר (Tour_City_Rel - חיפוש)
            'Tour_City_Rel' => $city,
            
            // **שדות אופציונליים:**
            
            // תאריך ושעת התחלה - ISO 8601 WITHOUT timezone offset
            // 🔧 FIXED: Removed 'P' (timezone offset) to prevent double timezone conversion in Zoho
            // Zoho will treat this as local Israel time (Asia/Jerusalem)
            // Format: YYYY-MM-DDTHH:MM:SS (ISO format, no offset)
            'startCycle_datatime' => date('Y-m-d\TH:i:s', $slot_timestamp),  // ISO 8601 WITHOUT timezone offset
            
            // סטטוס המחזור - לפי תאריך ותפוסה
            'Status_Cycle' => self::get_cycle_status($slot),
            
            // סימון שנוצר מהאתר (isCreatedByWebsite - בוליאני)
            'isCreatedByWebsite' => true,
            
            // קישור לסיור באתר (Product_URL_Website - URL)
            'Product_URL_Website' => $product ? $product->get_permalink() : null,
            
            // תאריך ושעת סנכרון (Sync_DT - תאריך ושעה) - ISO 8601 format required by Zoho
            'Sync_DT' => current_time('Y-m-d\TH:i:s'), // ISO 8601: 2025-11-11T09:25:19
            
            // תאריך ושעה כטקסט (startDateTimeTXT - טקסט, אם קיים) - local time
            // 🔧 FIXED: Appending Tour ID (unique) to text to avoid 'DUPLICATE_DATA' error in Zoho
            // Format: 2025-12-19 11:00:00 (521_1766142000)
            'startDateTimeTXT' => date('Y-m-d H:i:s', $slot_timestamp) . " ({$slot['tour_id']})"
        ];
        
        // קישור למוצר/סיור אם זמין (Product - Lookup field)
        // ✅ Smart linking: Only link if product exists in Zoho
        if ($product) {
            $product_sku = $product->get_sku();  // SKU = Zoho Product ID
            
            if (!empty($product_sku)) {
                // Verify product exists in Zoho before linking
                $product_exists = self::verify_product_exists_in_zoho($product_sku);
                
                if ($product_exists) {
                    $data['Product'] = array('id' => $product_sku);
                    write_detailed_log("Product verified in Zoho, linking: $product_sku", 'DEBUG');
                } else {
                    write_detailed_log("Product $product_sku not found in Zoho - cycle will be created without product link. Sync product first!", 'WARNING');
                    // Don't add Product field - cycle created without product link
                }
            } else {
                write_detailed_log("Product #{$product->get_id()} has no SKU - cannot link to Zoho", 'WARNING');
            }
        }
        
        // **שדות שלא נשלחים (מחושבים אוטומטית ע"י Zoho):**
        // - Num_of_Participants (Lookup - מסכם מכל ה-Orders/Sales_Orders המקושרים)
        // - Final_Total_of_Participants (Lookup - מסכם מכל ה-Orders/Sales_Orders)
        // - Sum_Income (Lookup - מסכם הכנסות מכל ההזמנות)
        
        // **שדות שלא קיימים בטבלת Zoho:**
        // - startDateTimeTXT
        
        // Note: Created_By is auto-set by Zoho based on API authentication
        
        return array_filter($data, function($value) {
            return $value !== null && $value !== '';
        });
    }
    
    /**
     * Determine cycle status based on date and occupancy
     * 
     * - פתוח להרשמה (Open for Registration) - עתידי + יש מקומות פנויים
     * - מלא (Full) - עתידי + אין מקומות פנויים
     * - התקיים (Completed/Occurred) - עבר
     * 
     * @param array $slot Slot data
     * @return string Cycle status for Zoho
     */
    private static function get_cycle_status($slot) {
        // בדיקה אם המחזור בעבר
        $slot_timestamp = strtotime($slot['slot_start']);
        $now_timestamp = time();
        
        if ($slot_timestamp < $now_timestamp) {
            // המחזור בעבר
            return 'התקיים';
        }
        
        // המחזור עתידי - בדוק תפוסה
        $booked_persons = isset($slot['booked_persons']) ? (int)$slot['booked_persons'] : 0;
        $max_capacity = isset($slot['max_capacity']) ? (int)$slot['max_capacity'] : 0;
        
        if ($max_capacity > 0 && $booked_persons >= $max_capacity) {
            // אין מקומות פנויים
            return 'מלא';
        }
        
        // יש מקומות פנויים
        return 'פתוח להרשמה';
    }
    
    /**
     * Map WooCommerce order to Zoho Sales_Order (paid orders)
     * 
     * @param WC_Order $order Order object
     * @param array $slot_data Optional slot data
     * @return array Zoho Sales_Order payload
     */
    public static function map_to_sales_order($order, $slot_data = null) {
        $order_id = $order->get_id();
        $booking_id = self::get_booking_id_from_order($order);
        
        // Build Subject with customer name + tour city + cycle date
        $customer_name = trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
        
        // Get tour city (from slot_data or product ACF field or product title)
        $tour_city = '';
        $product_name = '';
        
        if ($slot_data && isset($slot_data['tour_city'])) {
            $tour_city = $slot_data['tour_city'];
        }
        
        // Try to get from first product's ACF field TOUR_CITY or product name
        $items = $order->get_items();
        if ($items) {
            $first_item = reset($items);
            if ($first_item) {
                $product = wc_get_product($first_item->get_product_id());
                if ($product) {
                    // Get product name for fallback
                    $product_name = $product->get_name();
                    
                    // Try ACF TOUR_CITY field
                    if (empty($tour_city)) {
                        $tour_city = get_field('TOUR_CITY', $product->get_id()) ?: '';
                    }
                    
                    // Fallback: Try to extract city from product name (e.g., "סיור בירושלים")
                    if (empty($tour_city) && $product_name) {
                        if (preg_match('/(ירושלים|תל אביב|חיפה|באר שבע|אילת|טבריה|צפת|עכו|נצרת|ראשון לציון)/u', $product_name, $matches)) {
                            $tour_city = $matches[1];
                        }
                    }
                }
            }
        }
        
        // Get cycle date from slot_data
        $cycle_date = '';
        if ($slot_data && isset($slot_data['slot_start'])) {
            $cycle_date = date('d/m/Y H:i', strtotime($slot_data['slot_start']));
        }
        
        // Build subject with fallback to product name if city is missing
        if (!empty($tour_city) && !empty($cycle_date)) {
            $subject = sprintf('%s - %s - %s', $customer_name, $tour_city, $cycle_date);
        } elseif (!empty($product_name) && !empty($cycle_date)) {
            $subject = sprintf('%s - %s - %s', $customer_name, $product_name, $cycle_date);
        } elseif (!empty($tour_city)) {
            $subject = sprintf('%s - %s', $customer_name, $tour_city);
        } else {
            $subject = sprintf('%s - הזמנה #%d', $customer_name, $order_id);
        }
        
        $data = [
            // Basic fields
            'Subject' => $subject,  // String
            'OID' => (string) $order_id,  // String (custom text field)
            'BID' => $booking_id ? (string) $booking_id : '',  // String (never send null)
            
            // Financial fields (Currency/Decimal)
            'Sub_Total' => (float) $order->get_subtotal(),
            'Tax' => (float) $order->get_total_tax(),
            'Discount' => (float) $order->get_discount_total(),
            
            // Status and type fields (Picklist/String)
            'Status' => self::map_order_status($order->get_status(), $order->is_paid()),
            'Cycle_type' => 'קבוצתי',  // String field - tour type (not a lookup!)
            
            // Note: payment_status removed - may not exist in your Zoho setup
            // Order payment status is reflected in 'Status' field
            
            // Date fields (Y-m-d format - Zoho 'date' type)
            'Create_D_Order_On_Website' => $order->get_date_created()->format('Y-m-d'),
            'Paid_DT_Order_On_Website' => $order->is_paid() && $order->get_date_paid() 
                ? $order->get_date_paid()->format('Y-m-d')
                : '',  // Empty string instead of null for consistency
            
            // DateTime field (ISO 8601 with UTC timezone - Zoho standard)
            // Per Zoho API docs: YYYY-MM-DDTHH:MM:SSZ for datetime fields
            'Create_DT_Order_On_Website_Full' => gmdate('Y-m-d\TH:i:s\Z', $order->get_date_created()->getTimestamp()),
            
            // Text fields
            'Important_Notes' => $order->get_customer_note() ?: '',  // Never null
            'Description' => self::get_order_description($order),
        ];
        
        // Lookup fields as objects with 'id' key
        
        // Contact_Name lookup: {"id": "zoho_contact_id"}
        if ($zoho_contact_id = get_post_meta($order_id, '_zoho_contact_id', true)) {
            $data['Contact_Name'] = ['id' => $zoho_contact_id];
        }
        
        // Cycle_rel lookup: {"id": "zoho_cycle_id"} - THE ACTUAL CYCLE LINK!
        // Note: This is different from 'Cycle_type' which is just the text "קבוצתי"
        if (isset($slot_data['zoho_cycle_id']) && $slot_data['zoho_cycle_id']) {
            $data['Cycle_rel'] = ['id' => $slot_data['zoho_cycle_id']];
        }
        
        // CRITICAL: Build items subform
        $items_subform = self::build_ordered_items_subform($order, $slot_data);
        
        // Send as BOTH Product_Details (standard Zoho field) AND Ordered_Items (custom field)
        // This ensures compatibility with both standard and custom Zoho CRM setups
        $data['Product_Details'] = $items_subform;  // Standard Zoho Sales_Orders field
        $data['Ordered_Items'] = $items_subform;     // Custom field (if exists)
        
        // NOTE: Participants is auto-calculated by Zoho from Total_Participants in items
        // Don't send it manually to avoid conflicts
        
        // Check for accessibility requirements in line items
        $has_wheelchair = false;
        $has_stroller = false;
        foreach ($order->get_items() as $item) {
            $meta_data = $item->get_meta_data();
            foreach ($meta_data as $meta) {
                if ($meta->key === 'הנגשה' || $meta->key === 'Accessibility') {
                    $value = $meta->value;
                    if (strpos($value, 'כיסא גלגלים') !== false || strpos($value, 'wheelchair') !== false) {
                        $has_wheelchair = true;
                    }
                    if (strpos($value, 'עגלת תינוק') !== false || strpos($value, 'stroller') !== false) {
                        $has_stroller = true;
                    }
                }
            }
        }
        
        // Set accessibility fields
        $data['Ally'] = $has_wheelchair ? 'כן' : 'לא';
        $data['Babies'] = $has_stroller ? 'כן' : 'לא';
        
        // Set referral source - website + origin (if available)
        $order_origin = $order->get_meta('_order_origin') ?: $order->get_meta('_wc_order_attribution_source_type');
        if ($order_origin) {
            $data['Referral'] = 'אתר - ' . $order_origin;
        } else {
            $data['Referral'] = 'אתר';
        }
        
        // Payment status (text field) - סטטוס התשלום
        $data['payment_status'] = $order->is_paid() ? 'שולם' : 'ממתין לתשלום';
        
        // Note: Created_By is auto-set by Zoho based on API authentication
        // Don't send it manually - it's a User Lookup field requiring user ID
        
        // Don't filter out any fields - Zoho will ignore fields that don't exist
        // Just remove completely null values (but keep empty strings)
        return array_filter($data, function($value) {
            // Keep everything except null
            // Empty strings, empty arrays, zero values - all OK
            return $value !== null;
        });
    }
    
    // REMOVED: get_checkout_notes_and_agreements() - was adding extra data
    // Important_Notes should contain only customer's checkout note
    
    /**
     * Map WooCommerce order to Zoho Lead (unpaid orders)
     * 
     * @param WC_Order $order Order object
     * @param array $slot_data Optional slot data
     * @return array Zoho Lead payload
     */
    public static function map_to_lead($order, $slot_data = null) {
        $order_id = $order->get_id();
        $booking_id = self::get_booking_id_from_order($order);
        
        $data = [
            'Subject' => sprintf('Lead: %s - %s', self::get_order_product_names($order), $order->get_date_created()->format('Y-m-d')),
            'First_Name' => $order->get_billing_first_name(),
            'Last_Name' => $order->get_billing_last_name() ?: __('Unknown', 'at-bookings-api-fixes'),
            'Email' => $order->get_billing_email(),
            'Phone' => $order->get_billing_phone(),
            'Lead_Source' => 'Website',
            'Lead_Status' => 'Open',
            'Company' => $order->get_billing_company() ?: 'Individual',
        ];
        
        // Custom fields
        $data['WP_OID'] = $order_id;
        $data['WP_BID'] = $booking_id ?: null;
        
        // Tour date from slot
        if ($slot_data) {
            $data['tour_date'] = gmdate('Y-m-d', strtotime($slot_data['slot_start']));
        }
        
        // Link to product interest
        $products = self::get_order_products($order);
        if (!empty($products)) {
            $first_product = reset($products);
            if ($zoho_product_id = get_post_meta($first_product['id'], '_zoho_product_id', true)) {
                $data['Product_Interest'] = $zoho_product_id;
            }
        }
        
        // Note: Created_By is auto-set by Zoho based on API authentication
        
        return array_filter($data, function($value) {
            return $value !== null && $value !== '';
        });
    }
    
    /**
     * Calculate diff between current Zoho record and new data
     * 
     * @param array $current_data Current Zoho record
     * @param array $new_data New data to compare
     * @return array Diff with 'changed', 'added', 'removed' keys
     */
    public static function calculate_diff($current_data, $new_data) {
        $diff = [
            'changed' => [],
            'added' => [],
            'removed' => []
        ];
        
        // Find changed and added fields
        foreach ($new_data as $key => $new_value) {
            if (!isset($current_data[$key])) {
                $diff['added'][$key] = $new_value;
            } elseif ($current_data[$key] !== $new_value) {
                $diff['changed'][$key] = [
                    'old' => $current_data[$key],
                    'new' => $new_value
                ];
            }
        }
        
        // Find removed fields (fields that exist in current but not in new)
        foreach ($current_data as $key => $current_value) {
            if (!isset($new_data[$key])) {
                $diff['removed'][$key] = $current_value;
            }
        }
        
        return $diff;
    }
    
    /**
     * Helper: Get ALL booking IDs from order (for multi-booking support)
     * 🔄 NEW: Returns array of ALL booking IDs
     * 
     * @param WC_Order|int $order Order object or ID
     * @return array Array of booking IDs
     */
    public static function get_all_booking_ids_from_order($order) {
        $order_id = is_numeric($order) ? $order : $order->get_id();
        
        // Method 1: Use WC_Booking_Data_Store (most reliable)
        if (class_exists('WC_Booking_Data_Store')) {
            $booking_ids = WC_Booking_Data_Store::get_booking_ids_from_order_id($order_id);
            if (!empty($booking_ids)) {
                return array_map('intval', $booking_ids);
            }
        }
        
        // Method 2: Fallback to order item meta
        $order_obj = is_numeric($order) ? wc_get_order($order) : $order;
        $all_booking_ids = [];
        
        if ($order_obj) {
            foreach ($order_obj->get_items() as $item) {
                $booking_id_meta = $item->get_meta('_booking_id');
                
                if (is_array($booking_id_meta)) {
                    $all_booking_ids = array_merge($all_booking_ids, array_map('intval', $booking_id_meta));
                } elseif ($booking_id_meta) {
                    $all_booking_ids[] = (int) $booking_id_meta;
                }
            }
        }
        
        return array_unique(array_filter($all_booking_ids));
    }
    
    /**
     * Helper: Get booking ID from order
     * Uses WC_Booking_Data_Store for reliable booking ID retrieval
     * 
     * @deprecated Use get_all_booking_ids_from_order() for multi-booking support
     * @param WC_Order|int $order Order object or ID
     * @return int First booking ID (for backward compatibility)
     */
    public static function get_booking_id_from_order($order) {
        $all_booking_ids = self::get_all_booking_ids_from_order($order);
        return !empty($all_booking_ids) ? $all_booking_ids[0] : 0;
    }
    
    /**
     * Helper: Get product names from order
     */
    private static function get_order_product_names($order) {
        $names = [];
        foreach ($order->get_items() as $item) {
            $names[] = $item->get_name();
        }
        return implode(', ', $names);
    }
    
    /**
     * Helper: Map WooCommerce order status to Zoho status options
     * 
     * Zoho status options:
     * - "00. פוטנציאל" - Potential orders (pending, processing, on-hold)
     * - "01. מאושרת" - Confirmed orders (completed, paid)
     * - "02. מבוטלת" - Cancelled orders (cancelled, refunded, failed)
     * - "03. לא יצא לפועל - ביטול קבוצה" - Tour cancelled (not used here)
     */
    private static function map_order_status($wc_status, $is_paid = false) {
        // If paid or completed → Confirmed
        if ($is_paid || in_array($wc_status, ['completed'])) {
            return '01. מאושרת';
        }
        
        // If cancelled/refunded/failed → Cancelled
        if (in_array($wc_status, ['cancelled', 'refunded', 'failed'])) {
            return '02. מבוטלת';
        }
        
        // Otherwise → Potential (pending, processing, on-hold)
        return '00. פוטנציאל';
    }
    
    /**
     * Helper: Get payment status
     */
    private static function get_payment_status($order) {
        if ($order->is_paid()) {
            return 'Paid';
        }
        
        $status = $order->get_status();
        if (in_array($status, ['pending', 'on-hold'])) {
            return 'Pending';
        }
        
        if (in_array($status, ['failed', 'cancelled'])) {
            return 'Failed';
        }
        
        return 'Pending';
    }
    
    // REMOVED: get_order_items_data() - REPLACED by build_ordered_items_subform()
    // Old version returned simple array for JSON encoding
    // New version returns proper subform structure for Zoho
    
    /**
     * Normalize ticket type name to Zoho category
     * 
     * ONLY valid Zoho ticket types (exact strings):
     * - "מבוגר" (Adult - default)
     * - "גיל 6-12" (Children 6-12 years)
     * - "עד גיל 5" (Children under 5 years)
     * 
     * Website can return many variations like:
     * - "מבוגרים (מעל גיל 18)", "adults", "senior"
     * - "ילדים (6-12)", "child (6-12)", "kids"
     * - "ילדים (עד גיל 5)", "infants", "babies"
     * 
     * @param string $type_name Original type name from WC_Booking
     * @return string Normalized type name (one of the 3 exact Zoho options)
     */
    private static function normalize_ticket_type($type_name) {
        // עד גיל 5 - תינוקות/ילדים עד גיל 5
        // EXACT Zoho value: "עד גיל 5"
        if (preg_match('/(עד\s*גיל\s*5|תינוק|baby|infant|under\s*5|מתחת.*5|less.*5)/i', $type_name)) {
            return 'עד גיל 5';
        }
        
        // גיל 6-12 - ילדים בטווח גילים 6-12
        // EXACT Zoho value: "גיל 6-12"
        if (preg_match('/(6.*12|ילד|child|kid|under\s*12|מתחת.*12|6-12|6–12|6‐12)/i', $type_name)) {
            return 'גיל 6-12';
        }
        
        // מבוגר - ברירת מחדל
        // EXACT Zoho value: "מבוגר"
        // Matches: "מבוגרים", "adult", "senior", "18+", etc.
        return 'מבוגר';
    }
    
    /**
     * Helper: Parse ticket types from order item
     */
    private static function parse_ticket_types($item) {
        $types = [];
        
        // Look for person type meta data
        $meta_data = $item->get_meta_data();
        foreach ($meta_data as $meta) {
            $key = $meta->get_data()['key'];
            $value = $meta->get_data()['value'];
            
            // Enhanced parsing for various ticket type formats
            if (preg_match('/persons?_(\w+)/i', $key, $matches)) {
                $person_type = strtolower($matches[1]);
                $types[$person_type] = (int) $value;
            } elseif (preg_match('/(adult|child|kid|senior|infant|baby)/i', $key, $matches)) {
                $person_type = strtolower($matches[1]);
                $types[$person_type] = (int) $value;
            } elseif (strpos(strtolower($key), 'persons') !== false) {
                // Generic persons field
                $types['adult'] = (int) $value;
            }
        }
        
        // If no specific types found, assume all are adults
        if (empty($types)) {
            $types['adult'] = $item->get_quantity();
        }
        
        return $types;
    }
    
    /**
     * Build Ordered_Items subform for Zoho (not JSON string!)
     * Returns array of items for proper subform handling in Zoho
     * 
     * CRITICAL: Each ticket type gets its own row!
     * Adult x2 + Child x1 = 2 rows in Ordered_Items
     * 
     * Uses tickets_types data from WC_Booking when available
     * Format: [{id, name, ticket_price, count}, ...]
     * 
     * @param WC_Order $order Order object
     * @param array $slot_data Optional slot data with zoho_cycle_id or bookings data
     * @return array Subform data (array of arrays)
     */
    private static function build_ordered_items_subform($order, $slot_data = null) {
        $items = [];
        $cycle_id = isset($slot_data['zoho_cycle_id']) ? $slot_data['zoho_cycle_id'] : null;
        
        // CRITICAL LOGGING: Track cycle_id for debugging
        $log_file = WP_CONTENT_DIR . '/debug-sync.log';
        file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] build_ordered_items_subform: cycle_id from slot_data = " . ($cycle_id ?: 'NULL') . "\n", FILE_APPEND);
        file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] slot_data keys: " . (is_array($slot_data) ? json_encode(array_keys($slot_data)) : 'NOT_ARRAY') . "\n", FILE_APPEND);
        
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            
            // Get actual ticket types from WC_Booking if available
            // Otherwise parse from order item meta
            $ticket_types = [];
            
            // Try to get from booking data if available in slot_data
            if ($slot_data && isset($slot_data['tickets_types']) && is_array($slot_data['tickets_types'])) {
                // Use API format: {id, name, ticket_price, count}
                foreach ($slot_data['tickets_types'] as $ticket_type) {
                    if ($ticket_type['count'] > 0) {
                        $ticket_types[$ticket_type['name']] = [
                            'count' => $ticket_type['count'],
                            'price' => $ticket_type['ticket_price']
                        ];
                    }
                }
            } else {
                // Fallback: parse from order item meta
                $parsed_types = self::parse_ticket_types($item);
                foreach ($parsed_types as $type => $count) {
                    $ticket_types[$type] = ['count' => $count, 'price' => 0];
                }
            }
            
            // Item discount (difference between subtotal and total)
            $item_discount = $item->get_subtotal() - $item->get_total();
            
            // Get product Zoho ID
            $zoho_product_id = null;
            if ($product) {
                $zoho_product_id = get_post_meta($product->get_id(), '_zoho_product_id', true);
                if (!$zoho_product_id) {
                    $zoho_product_id = $product->get_sku(); // SKU = Zoho ID
                }
            }
            
            // CRITICAL: Create separate row for each ticket type!
            foreach ($ticket_types as $type_name => $type_data) {
                $count = $type_data['count'];
                if ($count > 0) {
                    // Calculate total tickets and actual price paid per ticket
                    $total_tickets = 0;
                    foreach ($ticket_types as $td) {
                        $total_tickets += $td['count'];
                    }
                    
                    // ACTUAL price per ticket (after discounts) - עלות בפועל
                    $actual_price_per_ticket = $total_tickets > 0 ? ($item->get_total() / $total_tickets) : 0;
                    
                    // LIST price per ticket (catalog/menu price) - מחיר מחירון
                    // Try to get from ticket type data, otherwise fallback to subtotal (before discount)
                    $list_price_per_ticket = isset($type_data['price']) && $type_data['price'] > 0 
                        ? (float) $type_data['price']
                        : ($total_tickets > 0 ? ($item->get_subtotal() / $total_tickets) : $actual_price_per_ticket);
                    
                    // Calculate discount per ticket
                    $discount_per_ticket = ($item_discount / $total_tickets);
                    
                    $row = [
                        // ZOHO STANDARD FIELDS (lowercase - required by API!)
                        'product' => $zoho_product_id ? ['id' => $zoho_product_id] : null,        // ⚠️ REQUIRED
                        'quantity' => $count,                                                      // ⚠️ REQUIRED
                        'list_price' => (float) $list_price_per_ticket,                           // מחיר מחירון
                        'unit_price' => (float) $actual_price_per_ticket,                         // עלות בפועל (לאחר הנחה)
                        'discount' => (float) ($discount_per_ticket * $count),                    // הנחה כוללת
                        'total' => (float) ($actual_price_per_ticket * $count),                   // סכום כולל בפועל
                        
                        // YOUR CUSTOM FIELDS (Capitalized - for custom logic/reports)
                        'Product_Name' => $zoho_product_id ? ['id' => $zoho_product_id] : null,  // Custom lookup
                        
                        // All ticket type fields (multiple field names for same data)
                        'Ticket_types' => self::normalize_ticket_type($type_name),                // Custom picklist - סוג כרטיס
                        'ticket_types' => self::normalize_ticket_type($type_name),                // Custom picklist - סוג כרטיס
                        'TheTicket_type' => self::normalize_ticket_type($type_name),              // Alternate field name
                        'Ticket' => self::normalize_ticket_type($type_name),                      // Alternate field name
                        'field4' => self::normalize_ticket_type($type_name),                      // Legacy field name
                        
                        'Quantity' => $count,                                                      // Custom integer
                        'Total_Participants' => $count,                                            // Custom integer
                        'total_participants' => $count,                                            // Custom integer
                        'List_Price' => (float) $list_price_per_ticket,                           // מחיר מחירון
                        'Unit_price' => (float) $actual_price_per_ticket,                         // עלות בפועל
                        'Discount' => (float) ($discount_per_ticket * $count),                    // הנחה כוללת
                        'Total' => (float) ($actual_price_per_ticket * $count),                   // סכום כולל בפועל
                        'Cycle_rel' => $cycle_id ? ['id' => $cycle_id] : null,                    // Custom lookup - שיוך למחזור
                        'cycle_rel' => $cycle_id ? ['id' => $cycle_id] : null,                    // Custom lookup - שיוך למחזור
                        'Description' => $product ? strip_tags($product->get_short_description()) : '',  // Custom text
                    ];
                    
                    // CRITICAL LOGGING: Check if Cycle_rel is included
                    file_put_contents($log_file, "[" . date('Y-m-d H:i:s') . "] Item row Cycle_rel = " . ($cycle_id ? "{'id': '$cycle_id'}" : 'NULL') . "\n", FILE_APPEND);
                    
                    // Keep all fields (don't filter nulls in subforms - Zoho handles it)
                    // Only remove specific internal WordPress fields
                    unset($row['product_id']);  // Internal WP field
                    
                    $items[] = $row;
                }
            }
        }
        
        return $items;
    }
    
    /**
     * Build Ticket_types subform (nested within Ordered_Items)
     * Returns array for Zoho subform, not JSON string
     * 
     * @param array $ticket_types Parsed ticket types (e.g., ['adult' => 2, 'child' => 1])
     * @param WC_Order_Item $item Order item
     * @return array Subform data for ticket types
     */
    private static function build_ticket_types_subform($ticket_types, $item) {
        $subform = [];
        $item_total = $item->get_total();
        $total_tickets = array_sum($ticket_types);
        
        if ($total_tickets > 0) {
            $price_per_ticket = $item_total / $total_tickets;
            
            foreach ($ticket_types as $type => $count) {
                if ($count > 0) {
                    $subform[] = [
                        'type' => ucfirst($type),  // "Adult", "Child", etc.
                        'quantity' => $count,
                        'price' => (float) $price_per_ticket
                    ];
                }
            }
        }
        
        return $subform;
    }
    
    /**
     * Helper: Get order description (summary of items)
     * 
     * @param WC_Order $order Order object
     * @return string Order description
     */
    private static function get_order_description($order) {
        $parts = [];
        
        foreach ($order->get_items() as $item) {
            $parts[] = $item->get_name() . ' x' . $item->get_quantity();
        }
        
        $description = implode(', ', $parts);
        
        // Add customer note if exists
        if ($note = $order->get_customer_note()) {
            $description .= "\n\nCustomer Note: " . $note;
        }
        
        return $description;
    }
    
    /**
     * Calculate total revenue with ticket type breakdown
     * 
     * @param WC_Order $order Order object
     * @return array Revenue breakdown by ticket type
     */
    public static function calculate_revenue_breakdown($order) {
        $breakdown = [
            'total' => (float) $order->get_total(),
            'subtotal' => (float) $order->get_subtotal(),
            'tax' => (float) $order->get_total_tax(),
            'discount' => (float) $order->get_discount_total(),
            'by_ticket_type' => []
        ];
        
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            if (!$product) continue;
            
            $ticket_types = self::parse_ticket_types($item);
            $item_total = $item->get_total();
            
            // Calculate price per ticket type
            $total_tickets = array_sum($ticket_types);
            if ($total_tickets > 0) {
                $price_per_ticket = $item_total / $total_tickets;
                
                foreach ($ticket_types as $type => $count) {
                    if (!isset($breakdown['by_ticket_type'][$type])) {
                        $breakdown['by_ticket_type'][$type] = [
                            'count' => 0,
                            'total' => 0.0
                        ];
                    }
                    
                    $breakdown['by_ticket_type'][$type]['count'] += $count;
                    $breakdown['by_ticket_type'][$type]['total'] += $price_per_ticket * $count;
                }
            }
        }
        
        return $breakdown;
    }
    
    /**
     * Validate revenue against expected pricing
     * 
     * @param WC_Order $order Order object
     * @return array Validation result with discrepancies
     */
    public static function validate_order_revenue($order) {
        $breakdown = self::calculate_revenue_breakdown($order);
        $discrepancies = [];
        $expected_total = 0.0;
        
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            if (!$product) continue;
            
            $ticket_types = self::parse_ticket_types($item);
            
            // Get ACF pricing
            $adult_price = (float) get_field('PRICE_ADULT', $product->get_id());
            $child_price = (float) get_field('PRICE_CHILD', $product->get_id());
            
            $item_expected = 0.0;
            
            foreach ($ticket_types as $type => $count) {
                switch (strtolower($type)) {
                    case 'adult':
                    case 'adults':
                        $item_expected += $adult_price * $count;
                        break;
                    case 'child':
                    case 'children':
                    case 'kid':
                    case 'kids':
                        $item_expected += $child_price * $count;
                        break;
                    default:
                        // Unknown type, use adult price
                        $item_expected += $adult_price * $count;
                        break;
                }
            }
            
            $expected_total += $item_expected;
            
            // Check for discrepancies
            $actual_total = $item->get_total();
            $difference = abs($actual_total - $item_expected);
            
            if ($difference > 0.01) { // Allow for small rounding differences
                $discrepancies[] = [
                    'item' => $item->get_name(),
                    'expected' => $item_expected,
                    'actual' => $actual_total,
                    'difference' => $difference
                ];
            }
        }
        
        return [
            'valid' => empty($discrepancies),
            'expected_total' => $expected_total,
            'actual_total' => $breakdown['total'],
            'discrepancies' => $discrepancies,
            'breakdown' => $breakdown
        ];
    }
    
    /**
     * Helper: Calculate total participants from order
     */
    private static function calculate_order_participants($order) {
        $total = 0;
        foreach ($order->get_items() as $item) {
            $ticket_types = self::parse_ticket_types($item);
            $total += array_sum($ticket_types);
        }
        return $total ?: 1;
    }
    
    /**
     * Helper: Get products from order
     */
    private static function get_order_products($order) {
        $products = [];
        foreach ($order->get_items() as $item) {
            if ($product = $item->get_product()) {
                $products[] = [
                    'id' => $product->get_id(),
                    'name' => $product->get_name(),
                    'sku' => $product->get_sku()
                ];
            }
        }
        return $products;
    }
    
    /**
     * Verify if product exists in Zoho by ID
     * 
     * ⚠️ SIMPLIFIED: No API call during sync - let Zoho validate
     * If product doesn't exist, Zoho will return clear error message
     * 
     * @param string $zoho_product_id Zoho Product ID (from SKU)
     * @return bool True to attempt linking (Zoho will validate)
     */
    private static function verify_product_exists_in_zoho($zoho_product_id) {
        if (empty($zoho_product_id)) {
            return false;
        }
        
        // ✅ SIMPLIFIED: Always return true and let Zoho validate
        // This avoids timeout from API call during sync
        // If product doesn't exist, Zoho will return "invalid data" error
        // and we'll handle it gracefully
        
        write_detailed_log("Will attempt to link Product: $zoho_product_id (Zoho will validate)", 'DEBUG');
        return true;
    }
    
    /**
     * Helper: Calculate slot income from bookings
     */
    private static function calculate_slot_income($slot_id) {
        global $wpdb;
        
        $bookings_table = $wpdb->prefix . 'at_slot_bookings';
        
        $total = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT SUM(o.total_amount) 
                FROM {$bookings_table} sb
                JOIN {$wpdb->prefix}wc_orders o ON sb.order_id = o.id
                WHERE sb.slot_id = %d 
                AND sb.status IN ('confirmed', 'paid', 'completed')",
                $slot_id
            )
        );
        
        return (float) $total ?: 0.0;
    }
}
