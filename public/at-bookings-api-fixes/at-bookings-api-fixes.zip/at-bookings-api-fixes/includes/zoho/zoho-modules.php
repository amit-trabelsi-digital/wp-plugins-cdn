<?php
/**
 * ZOHO CRM Modules Manager
 * Handles all module-specific operations for ZOHO CRM
 *
 * @package AT_Bookings_API_Fixes
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * ZOHO Modules Manager Class
 * Provides modular access to all ZOHO CRM modules
 */
class AT_Zoho_Modules {

    private static $instance = null;
    private $api;

    // Module API names
    const MODULE_CONTACTS = 'Contacts';
    const MODULE_LEADS = 'Leads';
    const MODULE_ACCOUNTS = 'Accounts';
    const MODULE_DEALS = 'Deals';
    const MODULE_PRODUCTS = 'Products';
    const MODULE_SALES_ORDERS = 'Sales_Orders';
    const MODULE_TOURS = 'Tours'; // Custom module
    const MODULE_TOUR_SCHEDULES = 'Tour_Schedules'; // Custom module
    const MODULE_COUPONS = 'Coupons'; // Custom module

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->api = AT_Zoho_API::get_instance();
    }

    // ==================== GENERIC SEARCH ====================

    /**
     * Generic search in any module
     * 
     * @param string $module Module name
     * @param string $field Field to search
     * @param mixed $value Value to search for
     * @param array $additional_fields Additional search criteria
     * @return array|false Records found or false
     */
    public function search_in_module($module, $field, $value, $additional_fields = array()) {
        try {
            $result = $this->api->search_records($module, $field, $value);
            
            // Apply additional filters if provided
            if (!empty($additional_fields) && !empty($result)) {
                $result = array_filter($result, function($record) use ($additional_fields) {
                    foreach ($additional_fields as $key => $val) {
                        if (!isset($record[$key]) || $record[$key] != $val) {
                            return false;
                        }
                    }
                    return true;
                });
            }
            
            return !empty($result) ? $result : false;
            
        } catch (Exception $e) {
            write_detailed_log("ZOHO search in $module failed: " . $e->getMessage(), 'ERROR');
            return false;
        }
    }

    /**
     * Get single record by ID
     * 
     * @param string $module Module name
     * @param string $id Record ID
     * @return array|false Record data or false
     */
    public function get_record($module, $id) {
        try {
            return $this->api->get_record($module, $id);
        } catch (Exception $e) {
            write_detailed_log("ZOHO get record from $module failed: " . $e->getMessage(), 'ERROR');
            return false;
        }
    }

    /**
     * Create record in any module
     * 
     * @param string $module Module name
     * @param array $data Record data
     * @return array|false Created record with ID or false
     */
    public function create_record($module, $data) {
        try {
            $result = $this->api->create_record($module, $data);
            write_detailed_log("ZOHO record created in $module: " . json_encode($result), 'INFO');
            return $result;
        } catch (Exception $e) {
            write_detailed_log("ZOHO create record in $module failed: " . $e->getMessage(), 'ERROR');
            return false;
        }
    }

    /**
     * Update record in any module
     * 
     * @param string $module Module name
     * @param string $id Record ID
     * @param array $data Record data to update
     * @return array|false Updated record or false
     */
    public function update_record($module, $id, $data) {
        try {
            $result = $this->api->update_record($module, $id, $data);
            write_detailed_log("ZOHO record updated in $module (ID: $id)", 'INFO');
            return $result;
        } catch (Exception $e) {
            write_detailed_log("ZOHO update record in $module failed: " . $e->getMessage(), 'ERROR');
            return false;
        }
    }

    // ==================== CONTACTS ====================

    /**
     * Search contact by email or phone
     * 
     * @param string $email Email address
     * @param string $phone Phone number (optional)
     * @return array|false Contact object or false if not found
     */
    public function search_contact($email = '', $phone = '') {
        if (empty($email) && empty($phone)) {
            return false;
        }

        // Try email first
        if (!empty($email)) {
            $result = $this->search_in_module(self::MODULE_CONTACTS, 'Email', $email);
            if ($result && !empty($result[0])) {
                return $result[0]; // Return first match
            }
        }

        // Try phone if email didn't work
        if (!empty($phone)) {
            $result = $this->search_in_module(self::MODULE_CONTACTS, 'Phone', $phone);
            if ($result && !empty($result[0])) {
                return $result[0];
            }
        }

        return false;
    }

    /**
     * Create new contact
     * 
     * @param array $data Contact data (First_Name, Last_Name, Email, Phone, etc.)
     * @return array|false Created contact with ID or false
     */
    public function create_contact($data) {
        // Validate required fields
        if (empty($data['Last_Name'])) {
            write_detailed_log('ZOHO create contact: Last_Name is required', 'ERROR');
            return false;
        }

        return $this->create_record(self::MODULE_CONTACTS, $data);
    }

    /**
     * Get or create contact (find by email/phone, create if not exists)
     * 
     * @param array $data Contact data
     * @return array|false Contact object or false
     */
    public function get_or_create_contact($data) {
        $email = isset($data['Email']) ? $data['Email'] : '';
        $phone = isset($data['Phone']) ? $data['Phone'] : '';

        // Try to find existing
        $contact = $this->search_contact($email, $phone);
        if ($contact) {
            write_detailed_log("Found existing contact in ZOHO: " . $contact['id'], 'DEBUG');
            return $contact;
        }

        // Create new if not found
        write_detailed_log("Creating new contact in ZOHO", 'DEBUG');
        $result = $this->create_contact($data);
        
        if ($result && isset($result['details']['id'])) {
            // Return contact object with id field (not details.id)
            return array(
                'id' => $result['details']['id'],
                'details' => $result['details']
            );
        }
        
        write_detailed_log("Failed to create contact - no ID returned", 'ERROR');
        return false;
    }

    // ==================== LEADS ====================

    /**
     * Search lead
     * 
     * @param string $field Field to search (Email, Phone, Company, etc.)
     * @param mixed $value Value to search for
     * @return array|false Lead object or false
     */
    public function search_lead($field, $value) {
        $result = $this->search_in_module(self::MODULE_LEADS, $field, $value);
        return ($result && !empty($result[0])) ? $result[0] : false;
    }

    /**
     * Create new lead
     * 
     * @param array $data Lead data (Last_Name, Company required)
     * @return array|false Created lead with ID or false
     */
    public function create_lead($data) {
        // Validate required fields
        if (empty($data['Last_Name']) || empty($data['Company'])) {
            write_detailed_log('ZOHO create lead: Last_Name and Company are required', 'ERROR');
            return false;
        }

        return $this->create_record(self::MODULE_LEADS, $data);
    }

    // ==================== PRODUCTS / TOURS ====================

    /**
     * Search tour/product
     * 
     * @param string $field Field to search (Product_Name, Product_Code, etc.)
     * @param mixed $value Value to search for
     * @return array|false Product object or false
     */
    public function search_tour($field, $value) {
        // Try custom Tours module first, fallback to Products
        $result = $this->search_in_module(self::MODULE_TOURS, $field, $value);
        
        if (!$result) {
            $result = $this->search_in_module(self::MODULE_PRODUCTS, $field, $value);
        }
        
        return ($result && !empty($result[0])) ? $result[0] : false;
    }

    // ==================== TOUR SCHEDULES / CYCLES ====================

    /**
     * Search tour schedule/cycle
     * 
     * @param string $field Field to search (custom field name)
     * @param mixed $value Value to search for
     * @return array|false Schedule object or false
     */
    public function search_tour_schedule($field, $value) {
        $result = $this->search_in_module(self::MODULE_TOUR_SCHEDULES, $field, $value);
        return ($result && !empty($result[0])) ? $result[0] : false;
    }

    /**
     * Create tour schedule/cycle
     * 
     * @param array $data Schedule data (must include: Tour_ID, Start_Date, Start_Time, etc.)
     * @return array|false Created schedule with ID or false
     */
    public function create_tour_schedule($data) {
        // Validate required fields
        $required = array('Tour_ID', 'Start_Date', 'Start_Time');
        foreach ($required as $field) {
            if (empty($data[$field])) {
                write_detailed_log("ZOHO create tour schedule: $field is required", 'ERROR');
                return false;
            }
        }

        return $this->create_record(self::MODULE_TOUR_SCHEDULES, $data);
    }

    // ==================== SALES ORDERS ====================

    /**
     * Search sales order
     * 
     * @param string $field Field to search (Subject, Order_Number, Contact_Name, etc.)
     * @param mixed $value Value to search for
     * @return array|false Sales order object or false
     */
    public function search_sales_order($field, $value) {
        $result = $this->search_in_module(self::MODULE_SALES_ORDERS, $field, $value);
        return ($result && !empty($result[0])) ? $result[0] : false;
    }

    /**
     * Create sales order
     * 
     * @param array $data Order data (must include: Subject, Contact_Name, Product_Details, etc.)
     * @return array|false Created order with ID or false
     */
    public function create_sales_order($data) {
        // Validate required fields
        $required = array('Subject', 'Contact_Name');
        foreach ($required as $field) {
            if (empty($data[$field])) {
                write_detailed_log("ZOHO create sales order: $field is required", 'ERROR');
                return false;
            }
        }

        return $this->create_record(self::MODULE_SALES_ORDERS, $data);
    }

    // ==================== COUPONS ====================

    /**
     * Search coupon
     * 
     * @param string $field Field to search (Coupon_Code, Coupon_Name, etc.)
     * @param mixed $value Value to search for
     * @return array|false Coupon object or false
     */
    public function search_coupon($field, $value) {
        $result = $this->search_in_module(self::MODULE_COUPONS, $field, $value);
        return ($result && !empty($result[0])) ? $result[0] : false;
    }

    /**
     * Create coupon
     * 
     * @param array $data Coupon data
     * @return array|false Created coupon with ID or false
     */
    public function create_coupon($data) {
        return $this->create_record(self::MODULE_COUPONS, $data);
    }

    // ==================== HELPER FUNCTIONS ====================

    /**
     * Convert WooCommerce customer to ZOHO contact format
     * 
     * @param WC_Customer|WC_Order $customer Customer or order object
     * @return array Contact data for ZOHO
     */
    public function wc_customer_to_zoho_contact($customer) {
        if ($customer instanceof WC_Order) {
            return array(
                'First_Name' => $customer->get_billing_first_name(),
                'Last_Name' => $customer->get_billing_last_name(),
                'Email' => $customer->get_billing_email(),
                'Phone' => $customer->get_billing_phone(),
                'Mailing_Street' => $customer->get_billing_address_1(),
                'Mailing_City' => $customer->get_billing_city(),
                'Mailing_State' => $customer->get_billing_state(),
                'Mailing_Zip' => $customer->get_billing_postcode(),
                'Mailing_Country' => $customer->get_billing_country(),
            );
        }

        return array(
            'First_Name' => $customer->get_first_name(),
            'Last_Name' => $customer->get_last_name(),
            'Email' => $customer->get_email(),
            'Phone' => $customer->get_billing_phone(),
            'Mailing_Street' => $customer->get_billing_address_1(),
            'Mailing_City' => $customer->get_billing_city(),
            'Mailing_State' => $customer->get_billing_state(),
            'Mailing_Zip' => $customer->get_billing_postcode(),
            'Mailing_Country' => $customer->get_billing_country(),
        );
    }

    // REMOVED: wc_order_to_zoho_sales_order() - USE AT_Zoho_Mapper::map_to_sales_order() INSTEAD
    // This function was duplicating AT_Zoho_Mapper logic - consolidated to single source
    
    // REMOVED: get_ticket_types_from_order() - USE AT_Zoho_Mapper::parse_ticket_types() INSTEAD
    // Ticket type parsing is now centralized in AT_Zoho_Mapper

    /**
     * Get ticket types from booking object
     * 
     * @param WC_Booking $booking Booking object
     * @return array Ticket types breakdown
     */
    public function get_ticket_types_from_booking($booking) {
        $ticket_types = array();
        
        try {
            $product = $booking->get_product();
            
            if ($product && method_exists($product, 'has_person_types') && $product->has_person_types()) {
                // Get person types from product
                $person_types_objects = $product->get_person_types();
                $person_counts = method_exists($booking, 'get_persons') ? $booking->get_persons() : array();
                
                if (!empty($person_types_objects) && is_array($person_types_objects)) {
                    foreach ($person_types_objects as $person_type) {
                        $person_id = $person_type->get_id();
                        $count = isset($person_counts[$person_id]) ? intval($person_counts[$person_id]) : 0;
                        
                        if ($count > 0) {
                            $ticket_types[] = array(
                                'type' => $person_type->get_name(),
                                'type_id' => $person_id,
                                'quantity' => $count
                            );
                        }
                    }
                }
            } else {
                // No person types - simple booking
                $total_persons = method_exists($booking, 'get_persons_total') ? $booking->get_persons_total() : 1;
                if ($total_persons > 0) {
                    $ticket_types[] = array(
                        'type' => 'כללי',
                        'type_id' => 0,
                        'quantity' => $total_persons
                    );
                }
            }
        } catch (Exception $e) {
            write_detailed_log('Error getting ticket types from booking: ' . $e->getMessage(), 'ERROR');
        }
        
        return $ticket_types;
    }

    // REMOVED: get_order_description() - USE AT_Zoho_Mapper::get_order_description() INSTEAD
    // Consolidated to AT_Zoho_Mapper for single source of truth

    /**
     * Get order coupon ZOHO ID if exists
     * 
     * @param WC_Order $order Order object
     * @return array|null Coupon relation or null
     */
    private function get_order_coupon_id($order) {
        $coupons = $order->get_coupon_codes();
        
        if (!empty($coupons)) {
            $coupon_code = $coupons[0]; // First coupon
            $coupon_post = get_page_by_title($coupon_code, OBJECT, 'shop_coupon');
            
            if ($coupon_post) {
                $zoho_coupon_id = get_post_meta($coupon_post->ID, '_zoho_coupon_id', true);
                if ($zoho_coupon_id) {
                    return array('id' => $zoho_coupon_id);
                }
            }
        }
        
        return null;
    }

    /**
     * Find or create cycle from WooCommerce booking
     * 
     * @param WC_Booking $booking Booking object
     * @return array|false Cycle result with ID or false
     */
    public function get_or_create_cycle_from_booking($booking) {
        $booking_id = $booking->get_id();
        
        // Check if already synced
        $zoho_cycle_id = get_post_meta($booking_id, '_zoho_cycle_id', true);
        
        if ($zoho_cycle_id) {
            // Verify it exists
            try {
                $cycle = $this->get_record(self::MODULE_TOUR_SCHEDULES, $zoho_cycle_id);
                if ($cycle) {
                    return array('id' => $zoho_cycle_id, 'action' => 'existing');
                }
            } catch (Exception $e) {
                // Doesn't exist, will create new
            }
        }
        
        // Get product and verify it's synced to ZOHO
        $product = $booking->get_product();
        if (!$product) {
            throw new Exception('Booking has no product');
        }
        
        $product_id = $product->get_id();
        $product_sku = $product->get_sku();
        
        // Find ZOHO product ID
        // Priority 1: SKU is the ZOHO ID itself (products created from ZOHO)
        $product_zoho_id = null;
        
        if ($product_sku) {
            // SKU is the ZOHO Product ID
            $product_zoho_id = $product_sku;
            write_detailed_log("Using SKU as ZOHO Product ID: $product_zoho_id", 'DEBUG');
        } else {
            // Fallback: Check if we saved it previously
            $product_zoho_id = get_post_meta($product_id, '_zoho_product_id', true);
        }
        
        if (!$product_zoho_id) {
            throw new Exception('Product has no SKU (ZOHO ID). Please set product SKU to ZOHO Product ID. (Product: ' . $product->get_name() . ')');
        }
        
        // Verify product exists in ZOHO
        try {
            $zoho_product = $this->get_record(self::MODULE_PRODUCTS, $product_zoho_id);
            if (!$zoho_product) {
                throw new Exception('Product ID ' . $product_zoho_id . ' not found in ZOHO');
            }
            write_detailed_log("Found product in ZOHO: " . $zoho_product['Product_Name'], 'DEBUG');
        } catch (Exception $e) {
            throw new Exception('Product not found in ZOHO (ID: ' . $product_zoho_id . '). Error: ' . $e->getMessage());
        }
        
        // Get timing info
        $start = $booking->get_start();
        $start_timestamp = is_numeric($start) ? intval($start) : strtotime($start);
        
        if (!$start_timestamp) {
            throw new Exception('Invalid booking start time');
        }
        
        $start_date = date('Y-m-d', $start_timestamp);
        $start_time = date('H:i', $start_timestamp);
        
        // Calculate end time
        $end = method_exists($booking, 'get_end') ? $booking->get_end() : null;
        $end_timestamp = $end ? (is_numeric($end) ? intval($end) : strtotime($end)) : null;
        $duration_hours = $end_timestamp ? round(($end_timestamp - $start_timestamp) / 3600, 2) : null;
        
        // Create unique cycle ID: product_WP_ID_timestamp_in_israel_time
        // Convert to Israel timezone
        $israel_tz = new DateTimeZone('Asia/Jerusalem');
        $datetime = new DateTime('@' . $start_timestamp);
        $datetime->setTimezone($israel_tz);
        $israel_timestamp = $datetime->getTimestamp();
        
        $unique_cycle_id = $product_id . '_' . $israel_timestamp;
        write_detailed_log("Cycle unique ID (tour_id): $unique_cycle_id", 'DEBUG');
        
        // 🔍 Search for existing cycle by Tour_SKU (unique identifier)
        // 🔧 FIXED: Changed from 'Cycle' field to 'Tour_SKU' field
        try {
            write_detailed_log("🔍 Searching for cycle by Tour_SKU: $unique_cycle_id", 'INFO');
            $result = $this->search_in_module(self::MODULE_TOUR_SCHEDULES, 'Tour_SKU', $unique_cycle_id);
            
            if ($result && is_array($result) && !empty($result[0])) {
                $cycle = $result[0];
                $zoho_cycle_id = $cycle['id'];
                update_post_meta($booking_id, '_zoho_cycle_id', $zoho_cycle_id);
                write_detailed_log("✅ Found existing cycle by Tour_SKU: $zoho_cycle_id", 'INFO');
                return array('id' => $zoho_cycle_id, 'action' => 'found');
            } else {
                write_detailed_log("❌ Cycle not found by Tour_SKU: $unique_cycle_id - will create new", 'INFO');
            }
        } catch (Exception $e) {
            write_detailed_log('⚠️ Cycle search failed: ' . $e->getMessage(), 'ERROR');
            // Continue to creation if search fails
        }
        
        // Prepare slot data structure for Mapper
        $slot_data = array(
            'id' => $booking_id,
            'product_id' => $product_id,
            'slot_start' => date('Y-m-d H:i:s', $start_timestamp),
            'slot_end' => date('Y-m-d H:i:s', $end_timestamp ?: $start_timestamp),
            'status' => $booking->get_status(),
            'zoho_cycle_id' => get_post_meta($booking_id, '_zoho_cycle_id', true),
            'tour_id' => $unique_cycle_id,
            'current_bookings' => 1,
        );
        
        // Use centralized mapper to build cycle data
        // This ensures consistent field mapping with the main sync service
        if (!class_exists('AT_Zoho_Mapper')) {
            require_once dirname(__FILE__) . '/zoho-mapper.php';
        }
        $cycle_data = AT_Zoho_Mapper::map_to_cycle($slot_data, $product);
        
        write_detailed_log('Cycle data mapped from booking: ' . json_encode(array_keys($cycle_data)), 'DEBUG');
        
        $cycle = $this->create_tour_schedule($cycle_data);
        
        if ($cycle && isset($cycle['details']['id'])) {
            $zoho_cycle_id = $cycle['details']['id'];
            update_post_meta($booking_id, '_zoho_cycle_id', $zoho_cycle_id);
            return array('id' => $zoho_cycle_id, 'action' => 'created');
        }
        
        throw new Exception('Failed to create cycle in ZOHO');
    }

    /**
     * Convert WooCommerce order status to ZOHO status
     * 
     * @param string $wc_status WooCommerce status
     * @return string ZOHO status
     */
    private function wc_status_to_zoho_status($wc_status) {
        $status_map = array(
            'pending' => 'Pending',
            'processing' => 'חדש',
            'on-hold' => 'Pending',
            'completed' => 'Paid',
            'cancelled' => 'Cancelled',
            'refunded' => 'Cancelled',
            'failed' => 'Cancelled',
        );

        return isset($status_map[$wc_status]) ? $status_map[$wc_status] : 'Pending';
    }
}

// Initialize ZOHO Modules
AT_Zoho_Modules::get_instance();
