<?php
/**
 * ZOHO Module Activation Script
 * Run this once to create the logs table
 */

// Load WordPress
require_once dirname(__FILE__) . '/../../../../wp-load.php';

if (!current_user_can('manage_options')) {
    die('Insufficient permissions');
}

// Load the sync logs class
require_once dirname(__FILE__) . '/zoho-sync-logs.php';

// Create table
AT_Zoho_Sync_Logs::create_table();

echo "✅ ZOHO Sync Logs table created successfully!\n";
echo "You can now access the logs at: Tools > ZOHO Sync Logs\n";

