<?php
/**
 * ZOHO CRM Sync Logs Manager
 * Comprehensive logging system for all ZOHO sync operations
 *
 * @package AT_Bookings_API_Fixes
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * ZOHO Sync Logs Class
 */
class AT_Zoho_Sync_Logs {

    private static $instance = null;
    private $table_name;
    private $current_api_context = array(); // Track current API call context

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'at_zoho_sync_logs';
        
        // Ensure table exists on first load
        $this->maybe_create_table();
        
        $this->init_hooks();
    }
    
    /**
     * Set API context for logging (URL, method, version)
     * This allows API class to provide context to logs
     */
    public function set_api_context($url = null, $method = null, $version = null) {
        $this->current_api_context = array(
            'url' => $url,
            'method' => $method,
            'version' => $version
        );
    }
    
    /**
     * Get and clear API context
     */
    private function get_and_clear_api_context() {
        $context = $this->current_api_context;
        $this->current_api_context = array();
        return $context;
    }
    
    /**
     * Create table if it doesn't exist
     */
    private function maybe_create_table() {
        global $wpdb;
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$this->table_name}'");
        
        if (!$table_exists) {
            self::create_table();
        } else {
            self::add_missing_columns();
        }
    }

    /**
     * Initialize hooks
     */
    private function init_hooks() {
        // Menu is now managed by AT_Bookings_Menu_Manager
        // add_action('admin_menu', array($this, 'add_admin_menu')); // REMOVED - duplicate
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('wp_ajax_at_zoho_clear_logs', array($this, 'ajax_clear_logs'));
    }

    /**
     * Create logs table
     */
    public static function create_table() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'at_zoho_sync_logs';
        
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            timestamp datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            action varchar(50) NOT NULL,
            module varchar(50) NOT NULL,
            wp_id bigint(20),
            zoho_id varchar(100),
            status varchar(20) NOT NULL,
            request_data longtext,
            response_data longtext,
            error_message text,
            user_id bigint(20),
            http_status int(3) DEFAULT NULL,
            retry_count int(2) DEFAULT 0,
            execution_time float DEFAULT NULL,
            api_url text DEFAULT NULL,
            http_method varchar(10) DEFAULT NULL,
            api_version varchar(10) DEFAULT NULL,
            PRIMARY KEY  (id),
            KEY action (action),
            KEY module (module),
            KEY status (status),
            KEY timestamp (timestamp),
            KEY http_status (http_status)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        // Add new columns if they don't exist (for existing tables)
        self::add_missing_columns();
    }
    
    /**
     * Add missing columns to existing table
     */
    private static function add_missing_columns() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'at_zoho_sync_logs';
        
        // Check and add http_status column
        if ($wpdb->get_var("SHOW COLUMNS FROM $table_name LIKE 'http_status'") === null) {
            $wpdb->query("ALTER TABLE $table_name ADD COLUMN http_status int(3) DEFAULT NULL AFTER user_id");
        }
        
        // Check and add retry_count column
        if ($wpdb->get_var("SHOW COLUMNS FROM $table_name LIKE 'retry_count'") === null) {
            $wpdb->query("ALTER TABLE $table_name ADD COLUMN retry_count int(2) DEFAULT 0 AFTER http_status");
        }
        
        // Check and add execution_time column
        if ($wpdb->get_var("SHOW COLUMNS FROM $table_name LIKE 'execution_time'") === null) {
            $wpdb->query("ALTER TABLE $table_name ADD COLUMN execution_time float DEFAULT NULL AFTER retry_count");
        }
        
        // Check and add api_url column
        if ($wpdb->get_var("SHOW COLUMNS FROM $table_name LIKE 'api_url'") === null) {
            $wpdb->query("ALTER TABLE $table_name ADD COLUMN api_url text DEFAULT NULL AFTER execution_time");
        }
        
        // Check and add http_method column
        if ($wpdb->get_var("SHOW COLUMNS FROM $table_name LIKE 'http_method'") === null) {
            $wpdb->query("ALTER TABLE $table_name ADD COLUMN http_method varchar(10) DEFAULT NULL AFTER api_url");
        }
        
        // Check and add api_version column
        if ($wpdb->get_var("SHOW COLUMNS FROM $table_name LIKE 'api_version'") === null) {
            $wpdb->query("ALTER TABLE $table_name ADD COLUMN api_version varchar(10) DEFAULT NULL AFTER http_method");
        }
    }

    /**
     * Log sync operation
     * 
     * @param string $action Action type (search, create, update, delete)
     * @param string $module ZOHO module name
     * @param int $wp_id WordPress object ID
     * @param string $zoho_id ZOHO record ID
     * @param string $status Status (success, error, pending)
     * @param array $request_data Data sent to ZOHO
     * @param array $response_data Response from ZOHO
     * @param string $error_message Error message if any
     * @param string $api_url Full API URL that was called
     * @param string $http_method HTTP method (GET, POST, PUT, DELETE, etc.)
     * @param string $api_version API version (v2, v2.1, v3, etc.)
     */
    public function log_sync($action, $module, $wp_id = null, $zoho_id = null, $status = 'success', $request_data = null, $response_data = null, $error_message = null, $api_url = null, $http_method = null, $api_version = null) {
        global $wpdb;

        // Get API context and clear it
        $context = $this->get_and_clear_api_context();
        
        // Use provided values, fallback to context values
        $final_api_url = $api_url ?? $context['url'] ?? null;
        $final_http_method = $http_method ?? $context['method'] ?? null;
        $final_api_version = $api_version ?? $context['version'] ?? null;

        $data = array(
            'action' => sanitize_text_field($action),
            'module' => sanitize_text_field($module),
            'wp_id' => $wp_id ? intval($wp_id) : null,
            'zoho_id' => $zoho_id ? sanitize_text_field($zoho_id) : null,
            'status' => sanitize_text_field($status),
            'request_data' => $request_data ? json_encode($request_data, JSON_UNESCAPED_UNICODE) : null,
            'response_data' => $response_data ? json_encode($response_data, JSON_UNESCAPED_UNICODE) : null,
            'error_message' => $error_message ? sanitize_text_field($error_message) : null,
            'user_id' => get_current_user_id(),
            'api_url' => $final_api_url ? esc_url_raw($final_api_url) : null,
            'http_method' => $final_http_method ? sanitize_text_field(strtoupper($final_http_method)) : null,
            'api_version' => $final_api_version ? sanitize_text_field($final_api_version) : null
        );

        $wpdb->insert($this->table_name, $data);

        // Keep only last 1000 logs
        $this->cleanup_old_logs();
    }

    /**
     * Get logs with filters
     */
    public function get_logs($filters = array()) {
        global $wpdb;

        $where = array('1=1');
        $params = array();

        if (!empty($filters['action'])) {
            $where[] = 'action = %s';
            $params[] = $filters['action'];
        }

        if (!empty($filters['module'])) {
            $where[] = 'module = %s';
            $params[] = $filters['module'];
        }

        if (!empty($filters['status'])) {
            $where[] = 'status = %s';
            $params[] = $filters['status'];
        }

        if (!empty($filters['wp_id'])) {
            $where[] = 'wp_id = %d';
            $params[] = intval($filters['wp_id']);
        }

        if (!empty($filters['date_from'])) {
            $where[] = 'timestamp >= %s';
            $params[] = $filters['date_from'];
        }

        if (!empty($filters['date_to'])) {
            $where[] = 'timestamp <= %s';
            $params[] = $filters['date_to'];
        }

        $where_clause = implode(' AND ', $where);
        $limit = isset($filters['limit']) ? intval($filters['limit']) : 100;
        $offset = isset($filters['offset']) ? intval($filters['offset']) : 0;

        $query = "SELECT * FROM {$this->table_name} WHERE $where_clause ORDER BY timestamp DESC LIMIT $limit OFFSET $offset";

        if (!empty($params)) {
            $query = $wpdb->prepare($query, $params);
        }

        return $wpdb->get_results($query);
    }

    /**
     * Get log count
     */
    public function get_log_count($filters = array()) {
        global $wpdb;

        $where = array('1=1');
        $params = array();

        if (!empty($filters['action'])) {
            $where[] = 'action = %s';
            $params[] = $filters['action'];
        }

        if (!empty($filters['module'])) {
            $where[] = 'module = %s';
            $params[] = $filters['module'];
        }

        if (!empty($filters['status'])) {
            $where[] = 'status = %s';
            $params[] = $filters['status'];
        }

        $where_clause = implode(' AND ', $where);
        $query = "SELECT COUNT(*) FROM {$this->table_name} WHERE $where_clause";

        if (!empty($params)) {
            $query = $wpdb->prepare($query, $params);
        }

        return $wpdb->get_var($query);
    }

    /**
     * Cleanup old logs (keep last 1000)
     */
    private function cleanup_old_logs() {
        global $wpdb;

        $wpdb->query("
            DELETE FROM {$this->table_name}
            WHERE id NOT IN (
                SELECT id FROM (
                    SELECT id FROM {$this->table_name}
                    ORDER BY timestamp DESC
                    LIMIT 1000
                ) AS keeper
            )
        ");
    }

    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_submenu_page(
            'tools.php',
            __('ZOHO Sync Logs', 'at-bookings-api-fixes'),
            __('ZOHO Sync Logs', 'at-bookings-api-fixes'),
            'manage_options',
            'at-zoho-sync-logs',
            array($this, 'logs_page')
        );
    }

    /**
     * Enqueue admin scripts
     */
    public function enqueue_admin_scripts($hook) {
        // Check for the correct hook suffix (managed by AT_Bookings_Menu_Manager)
        if (strpos($hook, 'at-bookings-zoho-logs') === false) {
            return;
        }

        wp_enqueue_style('at-zoho-logs', AT_BOOKINGS_API_FIXES_PLUGIN_URL . 'assets/zoho-logs.css', array(), AT_BOOKINGS_API_FIXES_VERSION);
    }

    /**
     * Logs page
     */
    public function logs_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }

        // Get filters from URL
        $filters = array(
            'action' => isset($_GET['filter_action']) ? sanitize_text_field($_GET['filter_action']) : '',
            'module' => isset($_GET['filter_module']) ? sanitize_text_field($_GET['filter_module']) : '',
            'status' => isset($_GET['filter_status']) ? sanitize_text_field($_GET['filter_status']) : '',
            'limit' => 50,
            'offset' => isset($_GET['paged']) ? (intval($_GET['paged']) - 1) * 50 : 0
        );

        $logs = $this->get_logs($filters);
        $total_logs = $this->get_log_count($filters);
        $total_pages = ceil($total_logs / 50);
        $current_page = isset($_GET['paged']) ? intval($_GET['paged']) : 1;

        include dirname(__FILE__) . '/zoho-logs-page.php';
    }

    /**
     * AJAX: Clear logs
     */
    public function ajax_clear_logs() {
        check_ajax_referer('at_zoho_clear_logs', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions'));
        }

        global $wpdb;
        $wpdb->query("TRUNCATE TABLE {$this->table_name}");

        wp_send_json_success(__('Logs cleared successfully', 'at-bookings-api-fixes'));
    }
}

// Initialize on plugin activation
register_activation_hook(AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'at-bookings-api-fixes.php', array('AT_Zoho_Sync_Logs', 'create_table'));

// Initialize Sync Logs
AT_Zoho_Sync_Logs::get_instance();
