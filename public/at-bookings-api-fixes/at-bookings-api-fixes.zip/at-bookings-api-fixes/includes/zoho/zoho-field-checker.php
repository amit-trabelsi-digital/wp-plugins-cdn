<?php
/**
 * Zoho Field Checker
 * 
 * Validates that required custom fields exist in Zoho modules
 * 
 * @package AT_Bookings_API_Fixes
 * @subpackage Zoho
 * @since 3.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Zoho_Field_Checker {
    
    /**
     * Required fields per module based on screenshots and requirements
     */
    const REQUIRED_FIELDS = [
        'Products' => [
            'PID' => ['type' => 'text', 'label' => 'WordPress Product ID'],
            'Product_Code' => ['type' => 'text', 'label' => 'Product Code (SKU)'],
            'Product_Name' => ['type' => 'text', 'label' => 'Product Name'],
            'Tour_City' => ['type' => 'picklist', 'label' => 'Tour City'],
            'Tour_duration' => ['type' => 'number', 'label' => 'Tour Duration'],
            'Unit_Price' => ['type' => 'currency', 'label' => 'Adult Price'],
            'Unit_Price2' => ['type' => 'currency', 'label' => 'Child Price'],
            'Ally' => ['type' => 'number', 'label' => 'Adult Capacity'],
            'Babies' => ['type' => 'number', 'label' => 'Child Capacity']
        ],
        'Contacts' => [
            'WP_User_ID' => ['type' => 'number', 'label' => 'WordPress User ID'],
            'Email' => ['type' => 'email', 'label' => 'Email'],
            'Phone' => ['type' => 'phone', 'label' => 'Phone'],
            'First_Name' => ['type' => 'text', 'label' => 'First Name'],
            'Last_Name' => ['type' => 'text', 'label' => 'Last Name']
        ],
        'Cycles' => [
            'Tour_SKU' => ['type' => 'text', 'label' => 'Tour SKU (Unique)'],
            'WP_Booking_IDs' => ['type' => 'textarea', 'label' => 'WordPress Booking IDs'],
            'startDateTimeTXT' => ['type' => 'datetime', 'label' => 'Start Date Time'],
            'Product' => ['type' => 'lookup', 'label' => 'Product Relation'],
            'Status_Cycle' => ['type' => 'picklist', 'label' => 'Cycle Status']
        ],
        'Sales_Orders' => [
            'OID' => ['type' => 'number', 'label' => 'WordPress Order ID'],
            'BID' => ['type' => 'number', 'label' => 'WordPress Booking ID'],
            'Subject' => ['type' => 'text', 'label' => 'Subject'],
            'Customer_No' => ['type' => 'lookup', 'label' => 'Customer'],
            'Grand_Total' => ['type' => 'currency', 'label' => 'Grand Total'],
            'payment_status' => ['type' => 'picklist', 'label' => 'Payment Status']
        ],
        'Leads' => [
            'WP_OID' => ['type' => 'number', 'label' => 'WordPress Order ID'],
            'WP_BID' => ['type' => 'number', 'label' => 'WordPress Booking ID'],
            'tour_date' => ['type' => 'date', 'label' => 'Tour Date'],
            'Product_Interest' => ['type' => 'lookup', 'label' => 'Product Interest'],
            'Lead_Source' => ['type' => 'picklist', 'label' => 'Lead Source'],
            'Lead_Status' => ['type' => 'picklist', 'label' => 'Lead Status']
        ]
    ];
    
    /**
     * Check all required fields across modules
     * 
     * @return array Validation results per module
     */
    public static function check_all_modules() {
        $results = [];
        
        foreach (self::REQUIRED_FIELDS as $module => $fields) {
            $results[$module] = self::check_module_fields($module, $fields);
        }
        
        return $results;
    }
    
    /**
     * Check fields for a specific module
     * 
     * @param string $module Module name
     * @param array $required_fields Required fields array
     * @return array Validation result
     */
    public static function check_module_fields($module, $required_fields) {
        $module_fields = AT_Zoho_Fields::get_module_fields($module);
        
        if (empty($module_fields)) {
            return [
                'success' => false,
                'message' => sprintf('Could not fetch fields for module %s', $module),
                'fields' => []
            ];
        }
        
        // Build field map for quick lookup
        $field_map = [];
        foreach ($module_fields as $field) {
            $field_map[$field['api_name']] = $field;
        }
        
        $field_results = [];
        $missing_count = 0;
        
        foreach ($required_fields as $field_api_name => $field_config) {
            $exists = isset($field_map[$field_api_name]);
            $type_match = false;
            $api_enabled = false;
            
            if ($exists) {
                $zoho_field = $field_map[$field_api_name];
                $type_match = self::check_field_type_compatibility($field_config['type'], $zoho_field['field_type']);
                $api_enabled = !empty($zoho_field['api_read']) || !empty($zoho_field['api_write']);
            }
            
            $field_results[$field_api_name] = [
                'exists' => $exists,
                'type_match' => $type_match,
                'api_enabled' => $api_enabled,
                'label' => $field_config['label'],
                'expected_type' => $field_config['type'],
                'actual_type' => $exists ? $field_map[$field_api_name]['field_type'] : null
            ];
            
            if (!$exists || !$type_match || !$api_enabled) {
                $missing_count++;
            }
        }
        
        return [
            'success' => $missing_count === 0,
            'missing_count' => $missing_count,
            'total_count' => count($required_fields),
            'fields' => $field_results,
            'message' => $missing_count > 0 ? 
                sprintf('%d of %d required fields need attention', $missing_count, count($required_fields)) :
                'All required fields are properly configured'
        ];
    }
    
    /**
     * Check if field types are compatible
     * 
     * @param string $expected Expected field type
     * @param string $actual Actual Zoho field type
     * @return bool
     */
    private static function check_field_type_compatibility($expected, $actual) {
        // Exact match
        if ($expected === $actual) {
            return true;
        }
        
        // Compatible type mappings
        $compatible_types = [
            'text' => ['text', 'textarea', 'url', 'email'],
            'textarea' => ['text', 'textarea'],
            'number' => ['number', 'integer', 'bigint'],
            'currency' => ['currency', 'number'],
            'email' => ['email', 'text'],
            'phone' => ['phone', 'text'],
            'date' => ['date'],
            'datetime' => ['datetime'],
            'picklist' => ['picklist', 'multiselectpicklist'],
            'lookup' => ['lookup']
        ];
        
        if (isset($compatible_types[$expected])) {
            return in_array($actual, $compatible_types[$expected]);
        }
        
        return false;
    }
    
    /**
     * Get missing fields summary
     * 
     * @return array Summary of missing fields across all modules
     */
    public static function get_missing_fields_summary() {
        $all_results = self::check_all_modules();
        $summary = [
            'total_missing' => 0,
            'modules_affected' => 0,
            'critical_issues' => [],
            'recommendations' => []
        ];
        
        foreach ($all_results as $module => $result) {
            if (!$result['success']) {
                $summary['modules_affected']++;
                $summary['total_missing'] += $result['missing_count'];
                
                foreach ($result['fields'] as $field_name => $field_result) {
                    if (!$field_result['exists']) {
                        $summary['critical_issues'][] = [
                            'module' => $module,
                            'field' => $field_name,
                            'issue' => 'missing',
                            'recommendation' => sprintf('Add %s field (%s) to %s module', $field_name, $field_result['expected_type'], $module)
                        ];
                    } elseif (!$field_result['type_match']) {
                        $summary['critical_issues'][] = [
                            'module' => $module,
                            'field' => $field_name,
                            'issue' => 'type_mismatch',
                            'recommendation' => sprintf('Change %s field type from %s to %s in %s module', $field_name, $field_result['actual_type'], $field_result['expected_type'], $module)
                        ];
                    } elseif (!$field_result['api_enabled']) {
                        $summary['critical_issues'][] = [
                            'module' => $module,
                            'field' => $field_name,
                            'issue' => 'api_disabled',
                            'recommendation' => sprintf('Enable API access for %s field in %s module', $field_name, $module)
                        ];
                    }
                }
            }
        }
        
        return $summary;
    }
    
    /**
     * Generate setup instructions
     * 
     * @return string HTML instructions for missing fields
     */
    public static function generate_setup_instructions() {
        $summary = self::get_missing_fields_summary();
        
        if ($summary['total_missing'] === 0) {
            return '<div class="notice notice-success"><p><strong>✓ All required fields are properly configured!</strong></p></div>';
        }
        
        $html = '<div class="notice notice-warning">';
        $html .= '<p><strong>⚠ Field Configuration Required</strong></p>';
        $html .= sprintf('<p>Found %d missing/misconfigured fields across %d modules.</p>', $summary['total_missing'], $summary['modules_affected']);
        $html .= '</div>';
        
        $html .= '<div class="at-setup-instructions">';
        $html .= '<h3>Required Actions:</h3>';
        $html .= '<ol>';
        
        foreach ($summary['critical_issues'] as $issue) {
            $html .= '<li>';
            $html .= '<strong>' . esc_html($issue['module']) . ':</strong> ';
            $html .= esc_html($issue['recommendation']);
            $html .= '</li>';
        }
        
        $html .= '</ol>';
        $html .= '<p><em>See <a href="' . AT_BOOKINGS_API_FIXES_PLUGIN_URL . 'docs/ZOHO-SETUP-GUIDE-HE.md" target="_blank">ZOHO Setup Guide</a> for detailed instructions.</em></p>';
        $html .= '</div>';
        
        return $html;
    }
    
    /**
     * AJAX endpoint for field validation
     */
    public static function ajax_check_fields() {
        check_ajax_referer('at_field_validation', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $results = self::check_all_modules();
        $summary = self::get_missing_fields_summary();
        
        wp_send_json_success([
            'results' => $results,
            'summary' => $summary,
            'instructions' => self::generate_setup_instructions()
        ]);
    }
}

// Register AJAX handler
add_action('wp_ajax_at_check_zoho_fields', array('AT_Zoho_Field_Checker', 'ajax_check_fields'));
