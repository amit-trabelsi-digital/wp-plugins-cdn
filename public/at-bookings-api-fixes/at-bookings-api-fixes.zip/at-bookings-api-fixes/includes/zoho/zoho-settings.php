<?php
/**
 * DEPRECATED: Use zoho-settings-new.php instead
 * This file is kept for backward compatibility only
 *
 * ZOHO CRM Settings Page
 *
 * @package AT_Bookings_API_Fixes
 */

if (!defined('ABSPATH')) {
    exit;
}

// Get current settings
$settings = AT_Zoho_CRM::get_settings();
?>

<div class="wrap">
    <h1><?php _e('ZOHO CRM Integration Settings', 'at-bookings-api-fixes'); ?></h1>

    <?php settings_errors('at_zoho_crm'); ?>

    <!-- Quick Start Guide -->
    <div style="background: #d1ecf1; border: 1px solid #bee5eb; border-radius: 4px; padding: 20px; margin-bottom: 20px;">
        <h3 style="margin-top: 0;">🚀 Getting Started with ZOHO CRM</h3>
        <ol>
            <li><strong>Create ZOHO OAuth App</strong> (if not already done):
                <ul>
                    <li>Go to <a href="https://api-console.zoho.com" target="_blank">ZOHO API Console</a></li>
                    <li>Create a new OAuth 2.0 app</li>
                    <li>Set Redirect URI to: <code style="background: white; padding: 2px 5px;"><?php echo esc_url(admin_url('admin-post.php?action=at_zoho_oauth_callback')); ?></code></li>
                    <li>Copy <strong>Client ID</strong> and <strong>Client Secret</strong> and paste below</li>
                </ul>
            </li>
            <li><strong>Generate Authorization Code</strong>:
                <ul>
                    <li><a href="#" onclick="alert('Please use the Authorization button in the new settings page'); return false;">Click here to authorize</a> (Use new settings page)</li>
                    <li>You'll be redirected to a page with your Authorization Code</li>
                </ul>
            </li>
            <li><strong>Get Refresh Token</strong>:
                <ul>
                    <li>Copy the Authorization Code from the callback page</li>
                    <li>Run this cURL command in terminal:<br>
                    <code style="display: block; background: #f5f5f5; padding: 10px; margin: 10px 0; border-radius: 3px; overflow-x: auto;">curl -X POST https://accounts.zoho.com/oauth/v2/token \\
  -d "grant_type=authorization_code" \\
  -d "client_id=YOUR_CLIENT_ID" \\
  -d "client_secret=YOUR_CLIENT_SECRET" \\
  -d "redirect_uri=<?php echo esc_url(admin_url('admin-post.php?action=at_zoho_oauth_callback')); ?>" \\
  -d "code=AUTHORIZATION_CODE"</code>
                    </li>
                    <li>Copy the <code>refresh_token</code> from the response</li>
                </ul>
            </li>
            <li><strong>Fill the form below</strong> with your credentials</li>
            <li><strong>Click "Test Connection"</strong> to verify everything works</li>
        </ol>
    </div>

    <div class="at-zoho-settings-container">
        <form method="post" action="">
            <?php wp_nonce_field('at_zoho_settings'); ?>

            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="zoho_client_id"><?php _e('Client ID', 'at-bookings-api-fixes'); ?></label>
                    </th>
                    <td>
                        <input type="text"
                               id="zoho_client_id"
                               name="zoho_client_id"
                               value="<?php echo esc_attr($settings['client_id']); ?>"
                               placeholder="1000.JKGTVS60364DF6KH5LWPJYTJQ3HIDE"
                               class="regular-text"
                               required>
                        <p class="description">
                            <?php _e('ZOHO CRM Client ID - Get from <a href="https://api-console.zoho.com" target="_blank">API Console</a>', 'at-bookings-api-fixes'); ?>
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="zoho_client_secret"><?php _e('Client Secret', 'at-bookings-api-fixes'); ?></label>
                    </th>
                    <td>
                        <input type="password"
                               id="zoho_client_secret"
                               name="zoho_client_secret"
                               value="<?php echo esc_attr($settings['client_secret']); ?>"
                               placeholder="6270604ddeca36eaf54bc275ea5adda9707a1a58a4"
                               class="regular-text"
                               required>
                        <p class="description">
                            <?php _e('ZOHO CRM Client Secret - Keep this confidential!', 'at-bookings-api-fixes'); ?>
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="zoho_domain"><?php _e('Domain', 'at-bookings-api-fixes'); ?></label>
                    </th>
                    <td>
                        <select id="zoho_domain" name="zoho_domain" required>
                            <option value=""><?php _e('Select Domain', 'at-bookings-api-fixes'); ?></option>
                            <option value="com" <?php selected($settings['domain'], 'com'); ?>>zohoapis.com (US Production)</option>
                            <option value="com-sandbox" <?php selected($settings['domain'], 'com-sandbox'); ?>>sandbox.zohoapis.com (US Sandbox)</option>
                            <option value="eu" <?php selected($settings['domain'], 'eu'); ?>>zohoapis.eu (EU Production)</option>
                            <option value="eu-sandbox" <?php selected($settings['domain'], 'eu-sandbox'); ?>>sandbox.zohoapis.eu (EU Sandbox)</option>
                            <option value="in" <?php selected($settings['domain'], 'in'); ?>>zohoapis.in (India Production)</option>
                            <option value="in-sandbox" <?php selected($settings['domain'], 'in-sandbox'); ?>>sandbox.zohoapis.in (India Sandbox)</option>
                            <option value="au" <?php selected($settings['domain'], 'au'); ?>>zohoapis.au (Australia Production)</option>
                            <option value="au-sandbox" <?php selected($settings['domain'], 'au-sandbox'); ?>>sandbox.zohoapis.au (Australia Sandbox)</option>
                        </select>
                        <p class="description">
                            <?php _e('Select your ZOHO CRM data center location and environment', 'at-bookings-api-fixes'); ?>
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="zoho_refresh_token"><?php _e('Refresh Token', 'at-bookings-api-fixes'); ?></label>
                    </th>
                    <td>
                        <input type="password"
                               id="zoho_refresh_token"
                               name="zoho_refresh_token"
                               value="<?php echo esc_attr($settings['refresh_token']); ?>"
                               placeholder="1000.d932337d828d9a4a3ca11709437f2053.e3835ef9b1ff2989fd78b4cb43c4e8cf"
                               class="regular-text"
                               required>
                        <p class="description">
                            <?php _e('ZOHO CRM Refresh Token - See "Getting Started" section for instructions', 'at-bookings-api-fixes'); ?>
                        </p>
                    </td>
                </tr>
            </table>

            <p class="submit">
                <input type="submit"
                       name="at_zoho_save_settings"
                       class="button button-primary"
                       value="<?php _e('Save Settings', 'at-bookings-api-fixes'); ?>">
            </p>
        </form>

        <?php if (AT_Zoho_CRM::is_configured()): ?>
        <div class="at-zoho-connection-test" style="margin-top: 30px;">
            <h3><?php _e('Connection Test', 'at-bookings-api-fixes'); ?></h3>
            <button type="button"
                    id="at-zoho-test-connection"
                    class="button button-secondary">
                <?php _e('Test Connection', 'at-bookings-api-fixes'); ?>
            </button>
            <div id="at-zoho-connection-result" style="margin-top: 10px;"></div>
        </div>

        <div class="at-zoho-modules-list" style="margin-top: 30px;">
            <h3><?php _e('Available Modules', 'at-bookings-api-fixes'); ?></h3>
            <button type="button"
                    id="at-zoho-get-modules"
                    class="button button-secondary">
                <?php _e('Load Modules', 'at-bookings-api-fixes'); ?>
            </button>
            <div id="at-zoho-modules-result" style="margin-top: 10px;"></div>
        </div>

        <div class="at-zoho-search-test" style="margin-top: 30px;">
            <h3><?php _e('Search Records', 'at-bookings-api-fixes'); ?></h3>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="search_module"><?php _e('Module', 'at-bookings-api-fixes'); ?></label>
                    </th>
                    <td>
                        <select id="search_module">
                            <option value=""><?php _e('Select Module', 'at-bookings-api-fixes'); ?></option>
                            <option value="Leads"><?php _e('Leads', 'at-bookings-api-fixes'); ?></option>
                            <option value="Contacts"><?php _e('Contacts', 'at-bookings-api-fixes'); ?></option>
                            <option value="Accounts"><?php _e('Accounts', 'at-bookings-api-fixes'); ?></option>
                            <option value="Deals"><?php _e('Deals', 'at-bookings-api-fixes'); ?></option>
                            <option value="Products"><?php _e('Products', 'at-bookings-api-fixes'); ?></option>
                            <option value="Sales_Orders"><?php _e('Sales Orders', 'at-bookings-api-fixes'); ?></option>
                            <option value="Tour_Schedules"><?php _e('Tour Schedules', 'at-bookings-api-fixes'); ?></option>
                        </select>
                        <button type="button" id="at-zoho-auto-populate-modules" class="button button-small" style="margin-right: 10px;">
                            🔄 <?php _e('Auto-populate from ZOHO', 'at-bookings-api-fixes'); ?>
                        </button>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="search_criteria"><?php _e('Search Criteria', 'at-bookings-api-fixes'); ?></label>
                    </th>
                    <td>
                        <input type="text"
                               id="search_criteria"
                               placeholder="email"
                               class="regular-text">
                        <p class="description">
                            <?php _e('Field name to search by (e.g., email, phone, first_name)', 'at-bookings-api-fixes'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="search_value"><?php _e('Search Value', 'at-bookings-api-fixes'); ?></label>
                    </th>
                    <td>
                        <input type="text"
                               id="search_value"
                               placeholder="example@email.com"
                               class="regular-text">
                    </td>
                </tr>
            </table>
            <button type="button"
                    id="at-zoho-search-records"
                    class="button button-secondary">
                <?php _e('Search Records', 'at-bookings-api-fixes'); ?>
            </button>
            <div id="at-zoho-search-result" style="margin-top: 10px;"></div>
        </div>
        <?php endif; ?>
    </div>
</div>

<style>
.at-zoho-settings-container {
    max-width: 800px;
}

.at-zoho-connection-test,
.at-zoho-modules-list,
.at-zoho-search-test {
    background: #f9f9f9;
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 4px;
}

#at-zoho-connection-result,
#at-zoho-modules-result,
#at-zoho-search-result {
    font-family: monospace;
    background: #fff;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 4px;
    max-height: 500px;
    overflow-y: auto;
}

.at-zoho-success {
    color: #28a745;
}

.at-zoho-error {
    color: #dc3545;
}
</style>

<script>
jQuery(document).ready(function($) {
    // Auto-populate modules in search dropdown
    $('#at-zoho-auto-populate-modules').on('click', function() {
        var $button = $(this);
        var $select = $('#search_module');
        
        $button.prop('disabled', true).text('<?php _e('Loading...', 'at-bookings-api-fixes'); ?>');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'at_zoho_get_modules',
                nonce: '<?php echo wp_create_nonce('at_zoho_get_modules'); ?>'
            },
            success: function(response) {
                if (response.success) {
                    // Clear existing options except first
                    $select.find('option:gt(0)').remove();
                    
                    // Add modules from ZOHO
                    $.each(response.data, function(index, module) {
                        if (module.api_supported) {
                            $select.append(
                                $('<option></option>')
                                    .attr('value', module.api_name)
                                    .text(module.singular_label + ' (' + module.api_name + ')')
                            );
                        }
                    });
                    
                    $button.prop('disabled', false).html('✅ <?php _e('Updated!', 'at-bookings-api-fixes'); ?>');
                    
                    setTimeout(function() {
                        $button.html('🔄 <?php _e('Auto-populate from ZOHO', 'at-bookings-api-fixes'); ?>');
                    }, 2000);
                } else {
                    alert('<?php _e('Error loading modules:', 'at-bookings-api-fixes'); ?> ' + response.data);
                    $button.prop('disabled', false).html('🔄 <?php _e('Auto-populate from ZOHO', 'at-bookings-api-fixes'); ?>');
                }
            },
            error: function(xhr, status, error) {
                alert('<?php _e('AJAX Error:', 'at-bookings-api-fixes'); ?> ' + error);
                $button.prop('disabled', false).html('🔄 <?php _e('Auto-populate from ZOHO', 'at-bookings-api-fixes'); ?>');
            }
        });
    });
    
    // Get modules
    $('#at-zoho-get-modules').on('click', function() {
        var $button = $(this);
        var $result = $('#at-zoho-modules-result');

        $button.prop('disabled', true).text('<?php _e('Loading...', 'at-bookings-api-fixes'); ?>');
        $result.html('<p><?php _e('Loading modules from ZOHO CRM...', 'at-bookings-api-fixes'); ?></p>');

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'at_zoho_get_modules',
                nonce: '<?php echo wp_create_nonce('at_zoho_get_modules'); ?>'
            },
            success: function(response) {
                if (response.success) {
                    var html = '<div class="at-zoho-success"><strong><?php _e('Found', 'at-bookings-api-fixes'); ?> ' + response.data.length + ' <?php _e('modules', 'at-bookings-api-fixes'); ?>:</strong></div>';
                    html += '<div style="max-height: 400px; overflow-y: auto;">';
                    html += '<table class="widefat striped" style="margin-top: 10px;">';
                    html += '<thead><tr>';
                    html += '<th><?php _e('Module Name', 'at-bookings-api-fixes'); ?></th>';
                    html += '<th><?php _e('API Name', 'at-bookings-api-fixes'); ?></th>';
                    html += '<th><?php _e('Plural', 'at-bookings-api-fixes'); ?></th>';
                    html += '<th><?php _e('Editable', 'at-bookings-api-fixes'); ?></th>';
                    html += '<th><?php _e('Creatable', 'at-bookings-api-fixes'); ?></th>';
                    html += '</tr></thead><tbody>';
                    
                    $.each(response.data, function(index, module) {
                        html += '<tr>';
                        html += '<td><strong>' + module.singular_label + '</strong></td>';
                        html += '<td><code>' + module.api_name + '</code></td>';
                        html += '<td>' + module.plural_label + '</td>';
                        html += '<td>' + (module.editable ? '✅' : '❌') + '</td>';
                        html += '<td>' + (module.creatable ? '✅' : '❌') + '</td>';
                        html += '</tr>';
                    });
                    
                    html += '</tbody></table></div>';
                    $result.html(html);
                } else {
                    $result.html('<div class="at-zoho-error"><strong><?php _e('Error:', 'at-bookings-api-fixes'); ?></strong> ' + response.data + '</div>');
                }
            },
            error: function(xhr, status, error) {
                $result.html('<div class="at-zoho-error"><strong><?php _e('AJAX Error:', 'at-bookings-api-fixes'); ?></strong> ' + error + '</div>');
            },
            complete: function() {
                $button.prop('disabled', false).text('<?php _e('Load Modules', 'at-bookings-api-fixes'); ?>');
            }
        });
    });

    // Test connection
    $('#at-zoho-test-connection').on('click', function() {
        var $button = $(this);
        var $result = $('#at-zoho-connection-result');

        $button.prop('disabled', true).text('<?php _e('Testing...', 'at-bookings-api-fixes'); ?>');
        $result.html('<p><?php _e('Testing connection to ZOHO CRM...', 'at-bookings-api-fixes'); ?></p>');

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'at_zoho_test_connection',
                nonce: '<?php echo wp_create_nonce('at_zoho_test_connection'); ?>'
            },
            success: function(response) {
                if (response.success) {
                    $result.html('<div class="at-zoho-success"><strong><?php _e('Success!', 'at-bookings-api-fixes'); ?></strong><br>' +
                        '<?php _e('Connected to ZOHO CRM', 'at-bookings-api-fixes'); ?><br>' +
                        'API Domain: ' + response.data.api_domain + '<br>' +
                        'Available Modules: ' + response.data.modules_count + '<br>' +
                        'Token Expires: ' + new Date(response.data.expires_at * 1000).toLocaleString() + '</div>');
                } else {
                    $result.html('<div class="at-zoho-error"><strong><?php _e('Error:', 'at-bookings-api-fixes'); ?></strong> ' + response.data + '</div>');
                }
            },
            error: function(xhr, status, error) {
                $result.html('<div class="at-zoho-error"><strong><?php _e('AJAX Error:', 'at-bookings-api-fixes'); ?></strong> ' + error + '</div>');
            },
            complete: function() {
                $button.prop('disabled', false).text('<?php _e('Test Connection', 'at-bookings-api-fixes'); ?>');
            }
        });
    });

    // Search records
    $('#at-zoho-search-records').on('click', function() {
        var $button = $(this);
        var $result = $('#at-zoho-search-result');

        var module = $('#search_module').val();
        var criteria = $('#search_criteria').val();
        var value = $('#search_value').val();

        if (!module || !criteria || !value) {
            $result.html('<div class="at-zoho-error"><?php _e('Please fill in all search fields', 'at-bookings-api-fixes'); ?></div>');
            return;
        }

        $button.prop('disabled', true).text('<?php _e('Searching...', 'at-bookings-api-fixes'); ?>');
        $result.html('<p><?php _e('Searching ZOHO CRM records...', 'at-bookings-api-fixes'); ?></p>');

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'at_zoho_search_records',
                module: module,
                criteria: criteria,
                value: value,
                nonce: '<?php echo wp_create_nonce('at_zoho_search_records'); ?>'
            },
            success: function(response) {
                if (response.success) {
                    var html = '<div class="at-zoho-success"><strong><?php _e('Found', 'at-bookings-api-fixes'); ?> ' + response.data.length + ' <?php _e('records', 'at-bookings-api-fixes'); ?>:</strong></div>';
                    html += '<pre>' + JSON.stringify(response.data, null, 2) + '</pre>';
                    $result.html(html);
                } else {
                    $result.html('<div class="at-zoho-error"><strong><?php _e('Error:', 'at-bookings-api-fixes'); ?></strong> ' + response.data + '</div>');
                }
            },
            error: function(xhr, status, error) {
                $result.html('<div class="at-zoho-error"><strong><?php _e('AJAX Error:', 'at-bookings-api-fixes'); ?></strong> ' + error + '</div>');
            },
            complete: function() {
                $button.prop('disabled', false).text('<?php _e('Search Records', 'at-bookings-api-fixes'); ?>');
            }
        });
    });
});
</script>
