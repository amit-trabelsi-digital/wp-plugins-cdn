<?php
/**
 * ZOHO CRM Settings Page - Professional Stepped Configuration
 *
 * Features:
 * - Automatic OAuth token generation
 * - Real-time validation
 * - Module auto-loading
 * - Hebrew/RTL support
 *
 * @package AT_Bookings_API_Fixes
 */

if (!defined('ABSPATH')) {
    exit;
}

// Get current settings and instance
try {
    $crm_instance = AT_Zoho_CRM::get_instance();
    $settings = AT_Zoho_CRM::get_settings();
} catch (Exception $e) {
    wp_die('Error loading ZOHO CRM settings. Check debug log.');
}

$has_client_id = !empty($settings['client_id']);
$has_client_secret = !empty($settings['client_secret']);
$has_domain = !empty($settings['domain']);
$has_refresh_token = !empty($settings['refresh_token']);
$is_configured = $has_client_id && $has_client_secret && $has_domain && $has_refresh_token;
?>

<div class="wrap">
    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; margin-bottom: 20px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
        <h1 style="margin-top: 0; color: white;">🚀 ZOHO CRM Integration</h1>
        <p style="margin: 10px 0 0 0; opacity: 0.95;">Professional setup guide for Hebrew tour booking system</p>
    </div>

    <?php settings_errors('at_zoho_crm'); ?>

    <div class="at-zoho-settings-wrapper">
        
        <!-- Progress Indicator -->
        <div class="at-progress-bar">
            <div class="at-progress-step <?php echo $has_client_id && $has_client_secret && $has_domain ? 'at-active' : ''; ?>">
                <div class="at-progress-number">1</div>
                <div class="at-progress-label"><?php _e('Setup', 'at-bookings-api-fixes'); ?></div>
            </div>
            <div class="at-progress-line"></div>
            <div class="at-progress-step <?php echo $has_refresh_token ? 'at-active' : ''; ?>">
                <div class="at-progress-number">2</div>
                <div class="at-progress-label"><?php _e('Token', 'at-bookings-api-fixes'); ?></div>
            </div>
            <div class="at-progress-line"></div>
            <div class="at-progress-step <?php echo $is_configured ? 'at-active' : ''; ?>">
                <div class="at-progress-number">3</div>
                <div class="at-progress-label"><?php _e('Verify', 'at-bookings-api-fixes'); ?></div>
            </div>
        </div>

        <!-- Step 1: Credentials -->
        <div class="at-step-card at-step-1">
            <div class="at-step-header">
                <h2>Step 1: OAuth Credentials</h2>
                <p class="at-step-description">Enter your ZOHO API credentials. Get these from <a href="https://api-console.zoho.com" target="_blank">ZOHO API Console</a></p>
            </div>

            <div class="at-step-form">
                <div class="at-form-group">
                    <label for="zoho_client_id">
                        <?php _e('Client ID', 'at-bookings-api-fixes'); ?>
                        <span class="at-required">*</span>
                    </label>
                    <input 
                        type="text"
                        id="zoho_client_id"
                        class="at-input-field"
                        value="<?php echo esc_attr($settings['client_id']); ?>"
                        placeholder="1000.xxxxxxxxxxxxxxxxxxxx"
                        data-validation="client_id"
                    >
                    <small class="at-hint">Found in ZOHO API Console under your OAuth app</small>
                </div>

                <div class="at-form-group">
                    <label for="zoho_client_secret">
                        <?php _e('Client Secret', 'at-bookings-api-fixes'); ?>
                        <span class="at-required">*</span>
                    </label>
                    <input 
                        type="password"
                        id="zoho_client_secret"
                        class="at-input-field"
                        value="<?php echo esc_attr($settings['client_secret']); ?>"
                        placeholder="Your client secret"
                        data-validation="client_secret"
                    >
                    <small class="at-hint">Keep this confidential! Do not share this value.</small>
                </div>

                <div class="at-form-group">
                    <label for="zoho_domain">
                        <?php _e('ZOHO Region', 'at-bookings-api-fixes'); ?>
                        <span class="at-required">*</span>
                    </label>
                    <select id="zoho_domain" class="at-select-field" data-validation="domain">
                        <option value=""><?php _e('Select Region', 'at-bookings-api-fixes'); ?></option>
                        <option value="com" <?php selected($settings['domain'], 'com'); ?>>🇺🇸 US Production (API: zohoapis.com)</option>
                        <option value="eu" <?php selected($settings['domain'], 'eu'); ?>>🇪🇺 EU Production (API: zohoapis.eu)</option>
                        <option value="in" <?php selected($settings['domain'], 'in'); ?>>🇮🇳 India Production (API: zohoapis.in)</option>
                        <option value="au" <?php selected($settings['domain'], 'au'); ?>>🇦🇺 Australia (API: zohoapis.au)</option>
                        <option value="com-sandbox" <?php selected($settings['domain'], 'com-sandbox'); ?>>🔬 US Sandbox (API: sandbox.zohoapis.com)</option>
                        <option value="eu-sandbox" <?php selected($settings['domain'], 'eu-sandbox'); ?>>🔬 EU Sandbox (API: sandbox.zohoapis.eu)</option>
                    </select>
                    <small class="at-hint">
                        <?php _e('Select your region and environment. Note: OAuth always uses the same accounts server (e.g., accounts.zoho.com), only API calls use the sandbox domain.', 'at-bookings-api-fixes'); ?>
                    </small>
                </div>

                <div class="at-form-actions">
                    <button type="button" id="at-save-credentials-btn" class="button button-primary button-large">
                        💾 <?php _e('Save & Continue', 'at-bookings-api-fixes'); ?>
                    </button>
                    <span id="at-credentials-status" class="at-status-indicator"></span>
                </div>
            </div>
        </div>

        <!-- Step 2: Authorization & Token -->
        <?php if ($has_client_id && $has_client_secret && $has_domain): ?>
        <div class="at-step-card at-step-2">
            <div class="at-step-header">
                <h2>Step 2: Generate Refresh Token</h2>
                <p class="at-step-description">Authorize this application to access your ZOHO CRM account</p>
            </div>

            <div class="at-step-content">
                <div class="at-auth-flow">
                    <ol class="at-auth-steps">
                        <li>
                            <strong><?php _e('Click the authorization link below', 'at-bookings-api-fixes'); ?></strong>
                            <p><?php _e('This will open a ZOHO login page. Sign in with your ZOHO account.', 'at-bookings-api-fixes'); ?></p>
                        </li>
                        <li>
                            <strong><?php _e('Grant permission', 'at-bookings-api-fixes'); ?></strong>
                            <p><?php _e('Click "Accept" to authorize this app to access your CRM', 'at-bookings-api-fixes'); ?></p>
                        </li>
                        <li>
                            <strong><?php _e('Get your code', 'at-bookings-api-fixes'); ?></strong>
                            <p><?php _e('You will be redirected with an authorization code', 'at-bookings-api-fixes'); ?></p>
                        </li>
                    </ol>

                    <div class="at-button-group">
                        <a href="<?php echo esc_url($crm_instance->get_zoho_auth_url()); ?>" 
                           class="button button-primary button-hero"
                           target="_blank"
                           id="at-authorize-link">
                            🔐 <?php _e('Authorize with ZOHO', 'at-bookings-api-fixes'); ?>
                        </a>
                        <button type="button" class="button" id="at-copy-curl-btn">
                            📋 <?php _e('Copy cURL Command', 'at-bookings-api-fixes'); ?>
                        </button>
                    </div>

                    <!-- Manual Token Entry -->
                    <div class="at-manual-token-section">
                        <h3><?php _e('Or paste your refresh token directly', 'at-bookings-api-fixes'); ?></h3>
                        <p class="at-step-description"><?php _e('If you already have a refresh token, paste it here:', 'at-bookings-api-fixes'); ?></p>
                        
                        <div class="at-form-group">
                            <textarea 
                                id="zoho_refresh_token_input"
                                class="at-textarea-field"
                                rows="3"
                                placeholder="1000.xxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                                data-validation="refresh_token"
                            ></textarea>
                            <small class="at-hint"><?php _e('This is a long alphanumeric string starting with "1000."', 'at-bookings-api-fixes'); ?></small>
                        </div>

                        <div class="at-form-actions">
                            <button type="button" id="at-save-token-btn" class="button button-primary">
                                💾 <?php _e('Save Refresh Token', 'at-bookings-api-fixes'); ?>
                            </button>
                            <span id="at-token-status" class="at-status-indicator"></span>
                        </div>
                    </div>

                    <!-- cURL Command Reference -->
                    <div class="at-curl-reference" style="display: none;">
                        <h4><?php _e('cURL Command:', 'at-bookings-api-fixes'); ?></h4>
                        <pre id="at-curl-command" class="at-code-block">curl -X POST https://<?php echo esc_html(AT_Zoho_CRM::get_accounts_domain($settings['domain'])); ?>/oauth/v2/token \
  -d "grant_type=authorization_code" \
  -d "client_id=<?php echo esc_html($settings['client_id']); ?>" \
  -d "client_secret=<?php echo esc_html($settings['client_secret']); ?>" \
  -d "redirect_uri=<?php echo esc_url(admin_url('admin-post.php?action=at_zoho_oauth_callback')); ?>" \
  -d "code=YOUR_CODE_HERE"</pre>
                        <p class="at-step-description">
                            <?php _e('After getting the authorization code, run this command and copy the "refresh_token" value from the response.', 'at-bookings-api-fixes'); ?>
                            <br><strong><?php _e('Note:', 'at-bookings-api-fixes'); ?></strong> 
                            <?php _e('OAuth server is the same for Production and Sandbox (only API domain differs).', 'at-bookings-api-fixes'); ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Step 3: Verification & Testing -->
        <?php if ($has_refresh_token): ?>
        <div class="at-step-card at-step-3">
            <div class="at-step-header">
                <h2>Step 3: Verify Connection</h2>
                <p class="at-step-description">Test your ZOHO CRM connection and load available modules</p>
            </div>

            <div class="at-step-content">
                <div class="at-button-group">
                    <button type="button" class="button button-primary" id="at-test-connection-btn">
                        🧪 <?php _e('Test Connection', 'at-bookings-api-fixes'); ?>
                    </button>
                    <button type="button" class="button" id="at-load-modules-btn">
                        📦 <?php _e('Load Modules', 'at-bookings-api-fixes'); ?>
                    </button>
                    <button type="button" class="button" id="at-refresh-access-token-btn">
                        🔄 <?php _e('Refresh Access Token', 'at-bookings-api-fixes'); ?>
                    </button>
                </div>

                <div id="at-verification-result" class="at-result-area"></div>

                <?php if ($is_configured): ?>
                <div class="at-status-success">
                    <h3>✅ <?php _e('All Systems Ready!', 'at-bookings-api-fixes'); ?></h3>
                    <p><?php _e('Your ZOHO CRM integration is properly configured.', 'at-bookings-api-fixes'); ?></p>
                    <p>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=at-bookings-zoho-logs')); ?>" class="button">
                            📋 <?php _e('View Sync Logs', 'at-bookings-api-fixes'); ?>
                        </a>
                    </p>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Settings Summary -->
        <div class="at-step-card at-settings-summary">
            <h2><?php _e('Current Configuration', 'at-bookings-api-fixes'); ?></h2>
            <table class="at-settings-table">
                <tr class="<?php echo $has_client_id ? 'at-row-success' : 'at-row-pending'; ?>">
                    <td><?php _e('Client ID', 'at-bookings-api-fixes'); ?></td>
                    <td class="at-status-cell"><?php echo $has_client_id ? '✓ ' . substr($settings['client_id'], 0, 20) . '...' : '⧐ Not Set'; ?></td>
                </tr>
                <tr class="<?php echo $has_client_secret ? 'at-row-success' : 'at-row-pending'; ?>">
                    <td><?php _e('Client Secret', 'at-bookings-api-fixes'); ?></td>
                    <td class="at-status-cell"><?php echo $has_client_secret ? '✓ Configured' : '⧐ Not Set'; ?></td>
                </tr>
                <tr class="<?php echo $has_domain ? 'at-row-success' : 'at-row-pending'; ?>">
                    <td><?php _e('Region', 'at-bookings-api-fixes'); ?></td>
                    <td class="at-status-cell"><?php echo $has_domain ? '✓ ' . esc_html($settings['domain']) : '⧐ Not Set'; ?></td>
                </tr>
                <tr class="<?php echo $has_refresh_token ? 'at-row-success' : 'at-row-pending'; ?>">
                    <td><?php _e('Refresh Token', 'at-bookings-api-fixes'); ?></td>
                    <td class="at-status-cell">
                        <?php if ($has_refresh_token): ?>
                            ✓ <?php echo substr($settings['refresh_token'], 0, 20); ?>...<br>
                            <small style="color: #666;"><?php _e('Permanent token (never expires)', 'at-bookings-api-fixes'); ?></small>
                        <?php else: ?>
                            ⧐ Not Set
                        <?php endif; ?>
                    </td>
                </tr>
                <tr class="<?php echo !empty($settings['access_token']) ? 'at-row-success' : 'at-row-pending'; ?>">
                    <td><?php _e('Access Token', 'at-bookings-api-fixes'); ?></td>
                    <td class="at-status-cell">
                        <?php if (!empty($settings['access_token'])): ?>
                            ✓ <?php echo substr($settings['access_token'], 0, 20); ?>...<br>
                            <small style="color: #666;">
                                <?php 
                                $expires_at = !empty($settings['token_expires']) ? $settings['token_expires'] : 0;
                                if ($expires_at > time()) {
                                    $minutes_left = round(($expires_at - time()) / 60);
                                    printf(__('Expires in %d minutes', 'at-bookings-api-fixes'), $minutes_left);
                                } else {
                                    echo '<span style="color: #dc3545;">' . __('Expired - will auto-refresh', 'at-bookings-api-fixes') . '</span>';
                                }
                                ?>
                            </small>
                        <?php else: ?>
                            ⧐ Not Set
                        <?php endif; ?>
                    </td>
                </tr>
                <tr class="<?php echo $is_configured ? 'at-row-success' : 'at-row-pending'; ?>">
                    <td><?php _e('Status', 'at-bookings-api-fixes'); ?></td>
                    <td class="at-status-cell"><?php echo $is_configured ? '✅ Ready' : '⏳ In Progress'; ?></td>
                </tr>
            </table>
        </div>
        
        <!-- Auto-Sync Configuration -->
        <?php if ($is_configured): ?>
        <div class="at-step-card">
            <h2><?php _e('🔄 Auto-Sync Settings', 'at-bookings-api-fixes'); ?></h2>
            <p class="at-step-description"><?php _e('Configure automatic synchronization of new orders to ZOHO', 'at-bookings-api-fixes'); ?></p>
            
            <?php
            $auto_sync_enabled = get_option('at_zoho_auto_sync_enabled', false);
            $sync_on_order_create = get_option('at_zoho_sync_on_order_create', true);
            $sync_on_order_complete = get_option('at_zoho_sync_on_order_complete', true);
            ?>
            
            <table class="form-table">
                <tr>
                    <th scope="row"><?php _e('Enable Auto-Sync', 'at-bookings-api-fixes'); ?></th>
                    <td>
                        <label>
                            <input type="checkbox" id="at_zoho_auto_sync_enabled" <?php checked($auto_sync_enabled); ?>>
                            <?php _e('סנכרן הזמנות חדשות אוטומטית ל-ZOHO', 'at-bookings-api-fixes'); ?>
                        </label>
                        <p class="description">
                            <?php _e('When enabled, new orders will be automatically synced to ZOHO CRM without manual intervention.', 'at-bookings-api-fixes'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php _e('Sync Triggers', 'at-bookings-api-fixes'); ?></th>
                    <td>
                        <label>
                            <input type="checkbox" id="at_zoho_sync_on_order_create" <?php checked($sync_on_order_create); ?>>
                            <?php _e('סנכרן בעת יצירת הזמנה חדשה', 'at-bookings-api-fixes'); ?>
                        </label><br>
                        <label>
                            <input type="checkbox" id="at_zoho_sync_on_order_complete" <?php checked($sync_on_order_complete); ?>>
                            <?php _e('סנכרן בעת השלמת הזמנה', 'at-bookings-api-fixes'); ?>
                        </label>
                    </td>
                </tr>
            </table>
            
            <button type="button" class="button button-primary" id="at-save-autosync-btn">
                💾 <?php _e('Save Auto-Sync Settings', 'at-bookings-api-fixes'); ?>
            </button>
            <span id="at-autosync-status"></span>
            
            <div style="margin-top: 20px; padding: 15px; background: #e7f3ff; border-radius: 4px;">
                <h4 style="margin-top: 0;">ℹ️ <?php _e('How Auto-Sync Works', 'at-bookings-api-fixes'); ?></h4>
                <ul style="margin: 0;">
                    <li><?php _e('Access token auto-refreshes every 50 minutes', 'at-bookings-api-fixes'); ?></li>
                    <li><?php _e('Background cron job ensures tokens never expire', 'at-bookings-api-fixes'); ?></li>
                    <li><?php _e('Sync happens in background - no delays for customers', 'at-bookings-api-fixes'); ?></li>
                    <li><?php _e('All sync operations are logged for debugging', 'at-bookings-api-fixes'); ?></li>
                </ul>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<style>
:root {
    --at-primary: #667eea;
    --at-secondary: #764ba2;
    --at-success: #28a745;
    --at-error: #dc3545;
    --at-warning: #ffc107;
    --at-light: #f8f9fa;
}

.at-zoho-settings-wrapper {
    max-width: 900px;
    margin: 20px 0;
}

/* Progress Bar */
.at-progress-bar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 30px;
    padding: 20px;
    background: white;
    border-radius: 8px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.08);
}

.at-progress-step {
    display: flex;
    flex-direction: column;
    align-items: center;
    flex: 0 0 auto;
    position: relative;
}

.at-progress-number {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: #e9ecef;
    color: #666;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    margin-bottom: 8px;
    transition: all 0.3s ease;
}

.at-progress-step.at-active .at-progress-number {
    background: linear-gradient(135deg, var(--at-primary) 0%, var(--at-secondary) 100%);
    color: white;
    box-shadow: 0 2px 8px rgba(102, 126, 234, 0.4);
}

.at-progress-label {
    font-size: 13px;
    font-weight: 500;
    color: #666;
    white-space: nowrap;
}

.at-progress-line {
    flex-grow: 1;
    height: 2px;
    background: #e9ecef;
    margin: 0 15px;
    position: relative;
    top: -24px;
}

.at-progress-step.at-active ~ .at-progress-line {
    background: linear-gradient(90deg, var(--at-primary), var(--at-secondary));
}

/* Step Cards */
.at-step-card {
    background: white;
    border-radius: 8px;
    padding: 30px;
    margin-bottom: 20px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.08);
    border-left: 4px solid #e9ecef;
    transition: all 0.3s ease;
}

.at-step-1 {
    border-left-color: #667eea;
}

.at-step-2 {
    border-left-color: #764ba2;
}

.at-step-3 {
    border-left-color: var(--at-success);
}

.at-step-header {
    margin-bottom: 20px;
    border-bottom: 1px solid #f0f0f0;
    padding-bottom: 15px;
}

.at-step-header h2 {
    margin: 0 0 10px;
    font-size: 20px;
    color: #333;
}

.at-step-description {
    margin: 0;
    color: #666;
    font-size: 14px;
}

.at-step-description a {
    color: var(--at-primary);
    text-decoration: none;
}

.at-step-description a:hover {
    text-decoration: underline;
}

/* Form Groups */
.at-form-group {
    margin-bottom: 20px;
}

.at-form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: #333;
}

.at-required {
    color: var(--at-error);
}

.at-input-field,
.at-select-field,
.at-textarea-field {
    width: 100%;
    padding: 10px 12px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 14px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
}

.at-input-field:focus,
.at-select-field:focus,
.at-textarea-field:focus {
    outline: none;
    border-color: var(--at-primary);
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

.at-hint {
    display: block;
    margin-top: 5px;
    color: #999;
    font-size: 12px;
}

/* Buttons */
.at-form-actions {
    display: flex;
    gap: 10px;
    align-items: center;
    margin-top: 20px;
}

.at-button-group {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin: 20px 0;
}

.button {
    padding: 8px 16px;
    border-radius: 4px;
    border: 1px solid #ddd;
    cursor: pointer;
    transition: all 0.2s ease;
}

.button-primary {
    background: linear-gradient(135deg, var(--at-primary) 0%, var(--at-secondary) 100%);
    color: white;
    border: none;
}

.button-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(102, 126, 234, 0.3);
}

.button-hero {
    padding: 12px 24px;
    font-size: 16px;
    font-weight: 600;
}

/* Status Indicators */
.at-status-indicator {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-size: 13px;
    font-weight: 500;
}

.at-status-indicator.at-success {
    color: var(--at-success);
}

.at-status-indicator.at-error {
    color: var(--at-error);
}

/* Auth Flow */
.at-auth-steps {
    margin: 15px 0;
    padding-left: 20px;
}

.at-auth-steps li {
    margin-bottom: 15px;
    line-height: 1.6;
}

.at-auth-steps strong {
    color: #333;
}

.at-manual-token-section {
    margin-top: 30px;
    padding-top: 20px;
    border-top: 1px solid #f0f0f0;
}

.at-manual-token-section h3 {
    margin: 0 0 10px;
    color: #333;
}

.at-curl-reference {
    background: var(--at-light);
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 15px;
    margin-top: 20px;
}

.at-code-block {
    background: #2d2d2d;
    color: #f8f8f2;
    padding: 15px;
    border-radius: 4px;
    overflow-x: auto;
    font-family: 'Monaco', 'Courier New', monospace;
    font-size: 13px;
    line-height: 1.5;
    margin: 10px 0;
}

/* Result Area */
.at-result-area {
    margin-top: 20px;
    padding: 15px;
    border-radius: 4px;
    display: none;
}

.at-result-area.at-show {
    display: block;
}

.at-result-success {
    background: #d4edda;
    border: 1px solid #c3e6cb;
    color: #155724;
    border-radius: 4px;
    padding: 12px;
}

.at-result-error {
    background: #f8d7da;
    border: 1px solid #f5c6cb;
    color: #721c24;
    border-radius: 4px;
    padding: 12px;
}

/* Settings Summary */
.at-settings-summary {
    background: linear-gradient(135deg, var(--at-light) 0%, #fff 100%);
    border-left-color: #999;
}

.at-settings-table {
    width: 100%;
    border-collapse: collapse;
}

.at-settings-table tr {
    border-bottom: 1px solid #f0f0f0;
}

.at-settings-table tr:last-child {
    border-bottom: none;
}

.at-settings-table td {
    padding: 12px;
}

.at-settings-table td:first-child {
    font-weight: 600;
    color: #333;
    width: 30%;
}

.at-status-cell {
    color: #666;
    font-size: 13px;
    font-family: 'Monaco', 'Courier New', monospace;
}

.at-row-success {
    background: rgba(40, 167, 69, 0.05);
}

.at-row-pending {
    background: rgba(255, 193, 7, 0.05);
}

/* Status Messages */
.at-status-success {
    background: #d4edda;
    border: 1px solid #c3e6cb;
    border-radius: 4px;
    padding: 15px;
    color: #155724;
    margin-top: 20px;
}

.at-status-success h3 {
    margin: 0 0 10px;
}

.at-status-success p {
    margin: 5px 0;
}

/* RTL Support */
body.rtl .at-progress-bar {
    flex-direction: row-reverse;
}

body.rtl .at-form-group label {
    text-align: right;
}

body.rtl .at-status-cell {
    text-align: right;
}

body.rtl .at-code-block {
    direction: ltr;
    text-align: left;
}

/* Loading State */
.at-loading {
    opacity: 0.6;
    pointer-events: none;
}

.at-loading::after {
    content: "";
    display: inline-block;
    width: 12px;
    height: 12px;
    margin-left: 8px;
    border: 2px solid #667eea;
    border-radius: 50%;
    border-top-color: transparent;
    animation: spin 0.8s linear infinite;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}
</style>

<script>
jQuery(document).ready(function($) {
    const nonces = {
        basicSettings: '<?php echo wp_create_nonce('at_zoho_save_basic_settings'); ?>',
        saveToken: '<?php echo wp_create_nonce('at_zoho_save_token'); ?>',
        testConnection: '<?php echo wp_create_nonce('at_zoho_test_connection'); ?>',
        getModules: '<?php echo wp_create_nonce('at_zoho_get_modules'); ?>'
    };

    // Save Credentials
    $('#at-save-credentials-btn').on('click', function() {
        const clientId = $('#zoho_client_id').val().trim();
        const clientSecret = $('#zoho_client_secret').val().trim();
        const domain = $('#zoho_domain').val().trim();
        
        if (!clientId || !clientSecret || !domain) {
            alert('<?php _e('Please fill all required fields', 'at-bookings-api-fixes'); ?>');
            return;
        }

        const $btn = $(this);
        const $status = $('#at-credentials-status');
        
        $btn.prop('disabled', true).text('⏳ Saving...');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'at_zoho_save_basic_settings',
                at_zoho_basic_nonce: nonces.basicSettings,
                zoho_client_id: clientId,
                zoho_client_secret: clientSecret,
                zoho_domain: domain
            },
            success: function(response) {
                if (response.success) {
                    $status.html('<span class="at-status-indicator at-success">✓ <?php _e('Saved!', 'at-bookings-api-fixes'); ?></span>');
                    setTimeout(() => location.reload(), 1000);
                } else {
                    $status.html('<span class="at-status-indicator at-error">✗ Error</span>');
                    alert('Error: ' + (response.data || 'Unknown error'));
                }
            },
            error: function() {
                $status.html('<span class="at-status-indicator at-error">✗ Error</span>');
                alert('<?php _e('Connection error', 'at-bookings-api-fixes'); ?>');
            },
            complete: function() {
                $btn.prop('disabled', false).text('💾 <?php _e('Save & Continue', 'at-bookings-api-fixes'); ?>');
            }
        });
    });

    // Save Refresh Token
    $('#at-save-token-btn').on('click', function() {
        const token = $('#zoho_refresh_token_input').val().trim();
        
        if (!token) {
            alert('<?php _e('Please paste your refresh token', 'at-bookings-api-fixes'); ?>');
            return;
        }

        if (!token.startsWith('1000.')) {
            alert('<?php _e('Refresh token should start with "1000."', 'at-bookings-api-fixes'); ?>');
            return;
        }

        const $btn = $(this);
        const $status = $('#at-token-status');
        
        $btn.prop('disabled', true).text('⏳ Saving...');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'at_zoho_save_refresh_token',
                at_zoho_save_token: nonces.saveToken,  // Fixed nonce parameter name
                zoho_refresh_token: token  // Changed from refresh_token to zoho_refresh_token
            },
            success: function(response) {
                if (response.success) {
                    $status.html('<span class="at-status-indicator at-success">✓ <?php _e('Saved!', 'at-bookings-api-fixes'); ?></span>');
                    setTimeout(() => location.reload(), 1000);
                } else {
                    $status.html('<span class="at-status-indicator at-error">✗ Error</span>');
                    alert('Error: ' + (response.data || 'Unknown error'));
                }
            },
            error: function() {
                $status.html('<span class="at-status-indicator at-error">✗ Error</span>');
                alert('<?php _e('Connection error', 'at-bookings-api-fixes'); ?>');
            },
            complete: function() {
                $btn.prop('disabled', false).text('💾 <?php _e('Save Refresh Token', 'at-bookings-api-fixes'); ?>');
            }
        });
    });

    // Test Connection
    $('#at-test-connection-btn').on('click', function() {
        const $btn = $(this);
        const $result = $('#at-verification-result');
        
        $btn.prop('disabled', true).text('🧪 Testing...');
        $result.html('<p><?php _e('Testing connection...', 'at-bookings-api-fixes'); ?></p>').addClass('at-show');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'at_zoho_test_connection',
                nonce: nonces.testConnection
            },
            success: function(response) {
                if (response.success) {
                    const data = response.data;
                    $result.html('<div class="at-result-success"><strong>✓ Connection Successful!</strong><br>' +
                        'API Domain: ' + data.api_domain + '<br>' +
                        'Available Modules: ' + data.modules_count + '<br>' +
                        'Token Expires: ' + new Date(data.expires_at * 1000).toLocaleString() +
                        '</div>');
                } else {
                    $result.html('<div class="at-result-error"><strong>✗ Connection Failed</strong><br>' + response.data + '</div>');
                }
            },
            error: function() {
                $result.html('<div class="at-result-error"><strong>✗ Error</strong><br><?php _e('Could not connect', 'at-bookings-api-fixes'); ?></div>');
            },
            complete: function() {
                $btn.prop('disabled', false).text('🧪 <?php _e('Test Connection', 'at-bookings-api-fixes'); ?>');
            }
        });
    });

    // Load Modules
    $('#at-load-modules-btn').on('click', function() {
        const $btn = $(this);
        const $result = $('#at-verification-result');
        
        $btn.prop('disabled', true).text('📦 Loading...');
        $result.html('<p><?php _e('Loading modules from ZOHO...', 'at-bookings-api-fixes'); ?></p>').addClass('at-show');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'at_zoho_get_modules',
                nonce: nonces.getModules
            },
            success: function(response) {
                if (response.success) {
                    const data = response.data;
                    
                    // Convert object to array if needed
                    let modules = [];
                    if (Array.isArray(data)) {
                        modules = data;
                    } else if (typeof data === 'object' && data !== null) {
                        // Convert object values to array
                        modules = Object.values(data);
                    }
                    
                    if (modules.length === 0) {
                        $result.html('<div class="at-result-error"><strong>⚠️ No modules found</strong><br>Check ZOHO permissions</div>');
                        return;
                    }
                    
                    let html = '<div class="at-result-success"><strong>✓ Found ' + modules.length + ' Modules:</strong><br>';
                    html += '<table style="width:100%; margin-top:10px; font-size:12px; border-collapse: collapse;"><tr style="background:#f0f0f0; border-bottom:2px solid #ccc;"><th style="text-align:right; padding:8px; font-weight:bold;">Module</th><th style="text-align:right; padding:8px; font-weight:bold;">API Name</th></tr>';
                    
                    modules.forEach(mod => {
                        const label = mod.singular_label || mod.module_name || mod.actual_singular_label || 'N/A';
                        const apiName = mod.api_name || 'N/A';
                        html += '<tr style="border-bottom:1px solid #eee;"><td style="padding:8px; text-align:right;">' + label + '</td><td style="padding:8px; font-family:monospace; text-align:left; direction:ltr;">' + apiName + '</td></tr>';
                    });
                    
                    html += '</table></div>';
                    $result.html(html);
                } else {
                    $result.html('<div class="at-result-error"><strong>✗ Error</strong><br>' + (response.data || 'Unknown error') + '</div>');
                }
            },
            error: function() {
                $result.html('<div class="at-result-error"><strong>✗ Error</strong><br><?php _e('Could not load modules', 'at-bookings-api-fixes'); ?></div>');
            },
            complete: function() {
                $btn.prop('disabled', false).text('📦 <?php _e('Load Modules', 'at-bookings-api-fixes'); ?>');
            }
        });
    });

    // Refresh Access Token
    $('#at-refresh-access-token-btn').on('click', function() {
        const $btn = $(this);
        const $result = $('#at-verification-result');
        
        $btn.prop('disabled', true).text('🔄 Refreshing...');
        $result.html('<p><?php _e('Refreshing access token...', 'at-bookings-api-fixes'); ?></p>').addClass('at-show');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'at_zoho_test_connection',  // This also validates and refreshes token
                nonce: nonces.testConnection
            },
            success: function(response) {
                if (response.success) {
                    $result.html('<div class="at-result-success"><strong>✓ Token Refreshed!</strong><br>' +
                        'Access token was validated and refreshed.<br>' +
                        'New token will be used on next request.' +
                        '</div>');
                } else {
                    $result.html('<div class="at-result-error"><strong>✗ Error</strong><br>' + response.data + '</div>');
                }
            },
            error: function(xhr) {
                let errorMsg = '<?php _e('Could not refresh token', 'at-bookings-api-fixes'); ?>';
                if (xhr.responseText) {
                    errorMsg += '<br><small>' + xhr.status + ': ' + xhr.statusText + '</small>';
                }
                $result.html('<div class="at-result-error"><strong>✗ Error</strong><br>' + errorMsg + '</div>');
            },
            complete: function() {
                $btn.prop('disabled', false).text('🔄 <?php _e('Refresh Access Token', 'at-bookings-api-fixes'); ?>');
            }
        });
    });

    // Copy cURL Command
    $('#at-copy-curl-btn').on('click', function() {
        const curlCmd = document.getElementById('at-curl-command');
        const text = curlCmd.textContent;
        
        navigator.clipboard.writeText(text).then(() => {
            const $btn = $(this);
            const oldText = $btn.text();
            $btn.text('✓ Copied!');
            setTimeout(() => $btn.text(oldText), 2000);
        });
    });

    // Toggle cURL command
    $('#at-copy-curl-btn').on('click', function(e) {
        e.preventDefault();
        $('.at-curl-reference').slideToggle();
    });

    // Save Auto-Sync Settings
    $('#at-save-autosync-btn').on('click', function() {
        const $btn = $(this);
        const $status = $('#at-autosync-status');
        
        const autoSyncEnabled = $('#at_zoho_auto_sync_enabled').is(':checked');
        const syncOnCreate = $('#at_zoho_sync_on_order_create').is(':checked');
        const syncOnComplete = $('#at_zoho_sync_on_order_complete').is(':checked');
        
        $btn.prop('disabled', true).text('⏳ Saving...');
        $status.html('');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'at_zoho_save_autosync_settings',
                nonce: nonces.basicSettings,  // Reuse existing nonce
                auto_sync_enabled: autoSyncEnabled ? '1' : '0',
                sync_on_order_create: syncOnCreate ? '1' : '0',
                sync_on_order_complete: syncOnComplete ? '1' : '0'
            },
            success: function(response) {
                if (response.success) {
                    $status.html('<span class="at-status-indicator at-success">✓ <?php _e('Saved!', 'at-bookings-api-fixes'); ?></span>');
                    setTimeout(() => $status.html(''), 3000);
                } else {
                    $status.html('<span class="at-status-indicator at-error">✗ Error</span>');
                    alert('Error: ' + (response.data || 'Unknown error'));
                }
            },
            error: function() {
                $status.html('<span class="at-status-indicator at-error">✗ Error</span>');
                alert('<?php _e('Connection error', 'at-bookings-api-fixes'); ?>');
            },
            complete: function() {
                $btn.prop('disabled', false).text('💾 <?php _e('Save Auto-Sync Settings', 'at-bookings-api-fixes'); ?>');
            }
        });
    });
});
</script>
