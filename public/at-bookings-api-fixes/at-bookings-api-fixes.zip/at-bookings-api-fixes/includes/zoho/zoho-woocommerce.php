<?php
/**
 * ZOHO CRM WooCommerce Integration
 * Adds sync buttons and functionality to WooCommerce
 *
 * @package AT_Bookings_API_Fixes
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * ZOHO WooCommerce Integration Class
 */
class AT_Zoho_WooCommerce {

    private static $instance = null;
    private $modules;
    private $logs;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Only init if ZOHO is configured
        if (!AT_Zoho_CRM::is_configured()) {
            return;
        }

        $this->modules = AT_Zoho_Modules::get_instance();
        $this->logs = AT_Zoho_Sync_Logs::get_instance();
        $this->init_hooks();
    }

    /**
     * Initialize hooks
     */
    private function init_hooks() {
        // Add sync button to product edit page
        add_action('woocommerce_product_options_general_product_data', array($this, 'add_product_sync_button'));
        
        // Add sync button to order edit page
        add_action('woocommerce_admin_order_data_after_order_details', array($this, 'add_order_sync_button'));
        
        // AJAX handlers
        add_action('wp_ajax_at_zoho_preview_product', array($this, 'ajax_preview_product'));
        add_action('wp_ajax_at_zoho_sync_product', array($this, 'ajax_sync_product'));
        add_action('wp_ajax_at_zoho_preview_order', array($this, 'ajax_preview_order'));
        add_action('wp_ajax_at_zoho_sync_order', array($this, 'ajax_sync_order'));
        add_action('wp_ajax_at_zoho_sync_contact_only', array($this, 'ajax_sync_contact_only'));
        add_action('wp_ajax_at_zoho_sync_cycle_only', array($this, 'ajax_sync_cycle_only'));
        
        // 🔄 AUTO-SYNC: Automatic order synchronization hooks
        // Hook into order status changes (when order is paid/completed)
        add_action('woocommerce_order_status_changed', array($this, 'auto_sync_on_status_change'), 10, 4);
        
        // Hook into new booking creation (for booking-specific orders)
        add_action('woocommerce_booking_confirmed', array($this, 'auto_sync_on_booking_confirmed'), 10, 1);
        
        // Log REST API product updates (for Zoho integration via standard API)
        add_action('woocommerce_rest_insert_product_object', array($this, 'log_rest_product_update'), 10, 3);
        
        // Enqueue admin scripts
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
    }

    /**
     * Log REST API product updates
     */
    public function log_rest_product_update($product, $request, $creating) {
        if (class_exists('AT_Zoho_Sync_Logs')) {
            AT_Zoho_Sync_Logs::get_instance()->log_sync(
                $creating ? 'create' : 'update',
                'Products',
                $product->get_id(),
                null, // Zoho ID might be in meta or not yet
                'success',
                $request->get_params(),
                null,
                'Product ' . ($creating ? 'created' : 'updated') . ' via REST API',
                'wc/v3/products',
                $request->get_method()
            );
        }
    }

    /**
     * Enqueue admin scripts
     */
    public function enqueue_admin_scripts($hook) {
        // Check for product edit pages
        $is_product_page = false;
        $is_order_page = false;

        // Product pages
        if (in_array($hook, array('post.php', 'post-new.php'))) {
            global $post;
            if ($post && $post->post_type === 'product') {
                $is_product_page = true;
            }
        }

        // Order pages (support both old and new WooCommerce)
        if (in_array($hook, array('post.php', 'post-new.php'))) {
            global $post;
            if ($post && in_array($post->post_type, array('shop_order', 'woocommerce_page_wc-orders'))) {
                $is_order_page = true;
            }
        }

        // WooCommerce HPOS - new order screen
        if (strpos($hook, 'woocommerce_page_wc-orders') !== false) {
            $is_order_page = true;
        }

        if (!$is_product_page && !$is_order_page) {
            return;
        }

        // Enqueue console logger for debugging
        wp_enqueue_script(
            'at-zoho-console',
            AT_BOOKINGS_API_FIXES_PLUGIN_URL . 'assets/js/admin/zoho-sync-console.js',
            array(),
            AT_BOOKINGS_API_FIXES_VERSION,
            true
        );
        
        wp_enqueue_script(
            'at-zoho-woocommerce',
            AT_BOOKINGS_API_FIXES_PLUGIN_URL . 'assets/zoho-woocommerce.js',
            array('jquery', 'at-zoho-console'),
            AT_BOOKINGS_API_FIXES_VERSION,
            true
        );

        wp_localize_script('at-zoho-woocommerce', 'atZoho', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'product_nonce' => wp_create_nonce('at_zoho_sync_product'),
            'order_nonce' => wp_create_nonce('at_zoho_sync_order'),
            'strings' => array(
                'syncing' => __('Syncing...', 'at-bookings-api-fixes'),
                'success' => __('Synced successfully!', 'at-bookings-api-fixes'),
                'error' => __('Sync failed:', 'at-bookings-api-fixes'),
            )
        ));

        // Debug info
        add_action('admin_footer', function() use ($hook) {
            echo '<script>console.log("🔷 ZOHO script enqueued on hook: ' . esc_js($hook) . '");</script>';
        });
    }

    /**
     * Add sync button to product edit page
     */
    public function add_product_sync_button() {
        global $post;
        
        echo '<div class="options_group">';
        echo '<p class="form-field">';
        echo '<label>' . __('ZOHO CRM Sync', 'at-bookings-api-fixes') . '</label>';
        echo '<button type="button" class="button button-secondary at-zoho-sync-product" data-product-id="' . $post->ID . '">';
        echo '📤 ' . __('Sync to ZOHO CRM', 'at-bookings-api-fixes');
        echo '</button>';
        echo '<span class="at-zoho-sync-result" style="margin-right: 10px;"></span>';
        
        // Show last sync time if exists
        $last_sync = get_post_meta($post->ID, '_zoho_last_sync', true);
        if ($last_sync) {
            echo '<br><small style="color: #666;">' . 
                 sprintf(__('Last synced: %s', 'at-bookings-api-fixes'), 
                 date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $last_sync)) . 
                 '</small>';
        }
        
        // Show ZOHO ID if exists
        $zoho_id = get_post_meta($post->ID, '_zoho_product_id', true);
        if ($zoho_id) {
            echo '<br><small style="color: #28a745;"><strong>ZOHO ID:</strong> ' . esc_html($zoho_id) . '</small>';
        }
        
        echo '</p>';
        echo '</div>';
    }

    /**
     * Add sync button to order edit page
     */
    public function add_order_sync_button($order) {
        $order_id = $order->get_id();
        
        echo '<div class="order_data_column at-zoho-order-sync-section" style="clear:both; width:100%; margin-top:20px; background:#f9f9f9; padding:15px; border:1px solid #ddd;">';
        echo '<h3>' . __('ZOHO CRM Sync', 'at-bookings-api-fixes') . '</h3>';
        echo '<p class="form-field">';
        echo '<button type="button" class="button button-secondary at-zoho-sync-order" data-order-id="' . esc_attr($order_id) . '">';
        echo '📤 ' . __('Sync Order to ZOHO CRM', 'at-bookings-api-fixes');
        echo '</button>';
        echo '<span class="at-zoho-sync-result" style="margin-right: 10px;"></span>';
        echo '</p>';
        
        // Debug info and inline JavaScript fallback
        ?>
        <script>
        console.log("🔷 ZOHO order sync button added for order #<?php echo esc_js($order_id); ?>");
        
        // Fallback inline handler if main script doesn't load
        jQuery(document).ready(function($) {
            console.log('🔷 Inline fallback loaded');
            console.log('🔷 Button exists:', $('.at-zoho-sync-order').length);
            
            if (typeof atZoho === 'undefined') {
                console.error('❌ atZoho object not found! Main script not loaded.');
                
                // Define atZoho locally
                window.atZoho = {
                    ajax_url: '<?php echo admin_url('admin-ajax.php'); ?>',
                    order_nonce: '<?php echo wp_create_nonce('at_zoho_sync_order'); ?>',
                    product_nonce: '<?php echo wp_create_nonce('at_zoho_sync_product'); ?>',
                    strings: {
                        syncing: 'Syncing...',
                        success: 'Synced successfully!',
                        error: 'Sync failed:'
                    }
                };
            }
            
            // Re-bind click handler
            $('.at-zoho-sync-order').off('click').on('click', function(e) {
                e.preventDefault();
                console.log('🔷 Order button clicked (inline handler)');
                
                var $button = $(this);
                var $result = $button.next('.at-zoho-sync-result');
                var orderId = $button.data('order-id');
                
                console.log('🔷 Order ID:', orderId);
                console.log('🔷 Ajax URL:', atZoho.ajax_url);
                
                $button.prop('disabled', true).text('Preview...');
                
                $.ajax({
                    url: atZoho.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'at_zoho_preview_order',
                        order_id: orderId,
                        nonce: atZoho.order_nonce
                    },
                    success: function(response) {
                        console.log('🔷 Preview response:', response);
                        alert('Preview data received! Check console.');
                        $button.prop('disabled', false).text('📤 Sync Order to ZOHO CRM');
                    },
                    error: function(xhr, status, error) {
                        console.error('❌ AJAX Error:', error);
                        console.error('❌ Response:', xhr.responseText);
                        alert('AJAX Error: ' + error);
                        $button.prop('disabled', false).text('📤 Sync Order to ZOHO CRM');
                    }
                });
            });
        });
        </script>
        <?php
        
        // Show last sync time if exists
        $last_sync = get_post_meta($order_id, '_zoho_last_sync', true);
        if ($last_sync) {
            echo '<p><small style="color: #666;">' . 
                 sprintf(__('Last synced: %s', 'at-bookings-api-fixes'), 
                 date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $last_sync)) . 
                 '</small></p>';
        }
        
        // Show ZOHO IDs if exist
        $zoho_contact_id = get_post_meta($order_id, '_zoho_contact_id', true);
        $zoho_order_id = get_post_meta($order_id, '_zoho_order_id', true);
        
        if ($zoho_contact_id || $zoho_order_id) {
            echo '<p>';
            if ($zoho_contact_id) {
                echo '<small style="color: #28a745;"><strong>Contact ID:</strong> ' . esc_html($zoho_contact_id) . '</small><br>';
            }
            if ($zoho_order_id) {
                echo '<small style="color: #28a745;"><strong>Order ID:</strong> ' . esc_html($zoho_order_id) . '</small>';
            }
            echo '</p>';
        }
        
        echo '</div>';
    }

    /**
     * AJAX: Preview product data before sync
     */
    public function ajax_preview_product() {
        check_ajax_referer('at_zoho_sync_product', 'nonce');

        if (!current_user_can('edit_products')) {
            wp_send_json_error(__('Insufficient permissions'));
        }

        $product_id = intval($_POST['product_id']);
        $sync_mode = isset($_POST['sync_mode']) ? sanitize_text_field($_POST['sync_mode']) : 'full';
        $product = wc_get_product($product_id);

        if (!$product) {
            wp_send_json_error(__('Product not found'));
        }

        if ($sync_mode === 'link_only') {
            // For link-only mode, just show minimal preview
            $preview_data = array(
                'record' => array(
                    'mode' => 'link_only',
                    'product_id' => $product_id,
                    'product_name' => $product->get_name(),
                    'message' => 'יישמר רק קישור ID בין וורדפרס לזוהו'
                ),
                'action' => 'link_only'
            );
        } else {
            // Full sync - use existing preparation
            $preview_data = $this->prepare_product_data($product);
            $preview_data['sync_mode'] = 'full';
        }

        wp_send_json_success($preview_data);
    }

    /**
     * AJAX: Sync product to ZOHO
     */
    public function ajax_sync_product() {
        check_ajax_referer('at_zoho_sync_product', 'nonce');

        if (!current_user_can('edit_products')) {
            wp_send_json_error(__('Insufficient permissions'));
        }

        $product_id = intval($_POST['product_id']);
        $sync_mode = isset($_POST['sync_mode']) ? sanitize_text_field($_POST['sync_mode']) : 'full';
        $product = wc_get_product($product_id);

        if (!$product) {
            wp_send_json_error(__('Product not found'));
        }

        $result = $this->sync_product_to_zoho($product, $sync_mode);

        if ($result) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error(__('Sync failed. Check logs for details.'));
        }
    }

    /**
     * AJAX: Preview order data before sync
     */
    public function ajax_preview_order() {
        try {
            write_detailed_log('ZOHO preview order AJAX called', 'DEBUG');
            
            check_ajax_referer('at_zoho_sync_order', 'nonce');

            if (!current_user_can('edit_shop_orders')) {
                write_detailed_log('ZOHO preview order: insufficient permissions', 'ERROR');
                wp_send_json_error(__('Insufficient permissions'));
            }

            $order_id = intval($_POST['order_id']);
            write_detailed_log("ZOHO preview order: Order ID = $order_id", 'DEBUG');
            
            $order = wc_get_order($order_id);

            if (!$order) {
                write_detailed_log('ZOHO preview order: Order not found', 'ERROR');
                wp_send_json_error(__('Order not found'));
            }

            write_detailed_log('ZOHO preview order: Preparing data...', 'DEBUG');
            $preview_data = $this->prepare_order_data($order);
            
            write_detailed_log('ZOHO preview order: Data prepared successfully', 'DEBUG');
            wp_send_json_success($preview_data);
            
        } catch (Exception $e) {
            write_detailed_log('ZOHO preview order ERROR: ' . $e->getMessage(), 'ERROR');
            write_detailed_log('ZOHO preview order TRACE: ' . $e->getTraceAsString(), 'ERROR');
            wp_send_json_error('Error: ' . $e->getMessage());
        } catch (Error $e) {
            write_detailed_log('ZOHO preview order FATAL: ' . $e->getMessage(), 'ERROR');
            write_detailed_log('ZOHO preview order TRACE: ' . $e->getTraceAsString(), 'ERROR');
            wp_send_json_error('Fatal Error: ' . $e->getMessage());
        }
    }

    /**
     * AJAX: Sync order to ZOHO
     */
    public function ajax_sync_order() {
        check_ajax_referer('at_zoho_sync_order', 'nonce');

        if (!current_user_can('edit_shop_orders')) {
            wp_send_json_error(__('Insufficient permissions'));
        }

        $order_id = intval($_POST['order_id']);
        $order = wc_get_order($order_id);

        if (!$order) {
            wp_send_json_error(__('Order not found'));
        }

        $result = $this->sync_order_to_zoho($order);

        if ($result) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error(__('Sync failed. Check logs for details.'));
        }
    }

    /**
     * Prepare product data for preview
     * 
     * @param WC_Product $product Product object
     * @return array Preview data with existing check
     */
    private function prepare_product_data($product) {
        $product_id = $product->get_id();
        
        // Use centralized mapper for consistency
        $zoho_data = AT_Zoho_Mapper::map_to_product($product);
        
        // Check if already synced
        $zoho_product_id = get_post_meta($product_id, '_zoho_product_id', true);
        $existing = null;

        if ($zoho_product_id) {
            // Try to get existing record
            try {
                $existing = $this->modules->get_record(AT_Zoho_Modules::MODULE_PRODUCTS, $zoho_product_id);
            } catch (Exception $e) {
                // Record not found, will create new
                $existing = null;
            }
        }

        return array(
            'record' => $zoho_data,
            'existing' => $existing,
            'action' => $existing ? 'update' : 'create',
            'zoho_id' => $zoho_product_id
        );
    }

    /**
     * Sync product to ZOHO
     * 
     * @param WC_Product $product Product object
     * @param string $sync_mode 'full' for complete sync, 'link_only' for ID linking only
     * @param bool $force_full_sync Force full sync even if already synced (for Force Create mode)
     * @return array|false Sync result or false
     */
    public function sync_product_to_zoho($product, $sync_mode = 'full', $force_full_sync = false) {
        $product_id = $product->get_id();
        
        // Link-only mode: only update IDs without creating/updating records
        if ($sync_mode === 'link_only') {
            return $this->sync_product_link_only($product);
        }
        
        // Full sync mode: prepare and send complete data
        $preview = $this->prepare_product_data($product);
        $zoho_data = $preview['record'];
        $zoho_product_id = $preview['zoho_id'];
        $action = $preview['action'];
        
        // 🔍 NEW: If no local Zoho ID, search in Zoho by PID (WordPress Product ID)
        if (empty($zoho_product_id) && $force_full_sync) {
            write_detailed_log("ZOHO: Product #{$product_id} has no local Zoho ID. Searching in Zoho by PID...", 'DEBUG');
            try {
                // Use API directly for search
                $zoho_api = AT_Zoho_API::get_instance();
                $search_result = $zoho_api->search_records(
                    AT_Zoho_Modules::MODULE_PRODUCTS,
                    'PID',  // Field name
                    (string) $product_id  // Value to search for (must be string)
                );
                
                if (!empty($search_result['data']) && count($search_result['data']) > 0) {
                    $found_product = $search_result['data'][0];
                    $zoho_product_id = $found_product['id'] ?? null;
                    
                    if ($zoho_product_id) {
                        write_detailed_log("ZOHO: Found existing product in Zoho with PID={$product_id}, Zoho ID: {$zoho_product_id}. Linking...", 'INFO');
                        
                        // Save the Zoho ID locally
                        update_post_meta($product_id, '_zoho_product_id', $zoho_product_id);
                        
                        // Update SKU to match Zoho ID
                        update_post_meta($product_id, '_sku', $zoho_product_id);
                        
                        // Change action to update since we found existing record
                        $action = 'update';
                        
                        write_detailed_log("ZOHO: Linked product #{$product_id} with Zoho ID: {$zoho_product_id}", 'INFO');
                    }
                }
            } catch (Exception $e) {
                write_detailed_log("ZOHO: Error searching for product by PID: " . $e->getMessage(), 'WARNING');
                // Continue with create if search fails
            }
        }

        try {
            if ($action === 'update' && $zoho_product_id) {
                // Update existing
                $result = $this->modules->update_record(AT_Zoho_Modules::MODULE_PRODUCTS, $zoho_product_id, $zoho_data);
                
                // Log update
                $this->logs->log_sync('update', 'Products', $product_id, $zoho_product_id, 'success', $zoho_data, $result, null, null, null, null);
                
            } else {
                // Create new
                write_detailed_log('ZOHO: Creating new product #' . $product_id . ' with data: ' . json_encode($zoho_data, JSON_UNESCAPED_UNICODE), 'DEBUG');
                
                $result = $this->modules->create_record(AT_Zoho_Modules::MODULE_PRODUCTS, $zoho_data);
                
                write_detailed_log('ZOHO: Create product response: ' . json_encode($result, JSON_UNESCAPED_UNICODE), 'DEBUG');
                
                // Check for ID in multiple possible locations
                if ($result) {
                    // Try result['id'] first (new API format)
                    if (isset($result['id'])) {
                        $zoho_product_id = $result['id'];
                        write_detailed_log('ZOHO: Found product ID in result[id]: ' . $zoho_product_id, 'DEBUG');
                    }
                    // Fallback to result['details']['id'] (old format)
                    elseif (isset($result['details']['id'])) {
                        $zoho_product_id = $result['details']['id'];
                        write_detailed_log('ZOHO: Found product ID in result[details][id]: ' . $zoho_product_id, 'DEBUG');
                    }
                    // Fallback to result['data'][0]['details']['id']
                    elseif (isset($result['data'][0]['details']['id'])) {
                        $zoho_product_id = $result['data'][0]['details']['id'];
                        write_detailed_log('ZOHO: Found product ID in result[data][0][details][id]: ' . $zoho_product_id, 'DEBUG');
                    }
                    
                    if (!empty($zoho_product_id)) {
                        update_post_meta($product_id, '_zoho_product_id', $zoho_product_id);
                        
                        // Log creation
                        $this->logs->log_sync('create', 'Products', $product_id, $zoho_product_id, 'success', $zoho_data, $result, null, null, null, null);
                        write_detailed_log('ZOHO: Product #' . $product_id . ' created successfully with Zoho ID: ' . $zoho_product_id, 'INFO');
                    } else {
                        // No ID found - log the full response for debugging
                        write_detailed_log('ZOHO: Product creation succeeded but no ID found in response structure!', 'ERROR');
                        write_detailed_log('ZOHO: Full response keys: ' . implode(', ', array_keys($result)), 'ERROR');
                        write_detailed_log('ZOHO: Full response: ' . json_encode($result, JSON_UNESCAPED_UNICODE), 'ERROR');
                    }
                }
            }

            if ($result && !empty($zoho_product_id)) {
                // Update last sync time
                update_post_meta($product_id, '_zoho_last_sync', time());
                
                // Update SKU in WooCommerce with Zoho Product ID (using direct meta update)
                $current_sku = get_post_meta($product_id, '_sku', true);
                if ($current_sku !== $zoho_product_id) {
                    update_post_meta($product_id, '_sku', $zoho_product_id);
                    AT_Bookings_Logger::info("Updated product #{$product_id} SKU to Zoho ID: {$zoho_product_id}" . ($current_sku ? " (was: {$current_sku})" : " (was empty)"));
                }
                
                return array(
                    'zoho_id' => $zoho_product_id,
                    'action' => $action,
                    'message' => __('Product synced successfully', 'at-bookings-api-fixes')
                );
            }

            // Log error
            $this->logs->log_sync($action, 'Products', $product_id, $zoho_product_id, 'error', $zoho_data, null, 'Sync failed - no result', null, null, null);
            return false;

        } catch (Exception $e) {
            // Log error
            $this->logs->log_sync($action, 'Products', $product_id, $zoho_product_id, 'error', $zoho_data, null, $e->getMessage(), null, null, null);
            write_detailed_log('ZOHO product sync failed: ' . $e->getMessage(), 'ERROR');
            return false;
        }
    }

    /**
     * Sync product IDs only (link_only mode)
     * Updates WooCommerce SKU with Zoho ID and saves PID reference
     * 
     * @param WC_Product $product Product object
     * @return array Sync result
     */
    private function sync_product_link_only($product) {
        $product_id = $product->get_id();
        $wordpress_id = (string) $product_id;
        
        try {
            // Check if product already has a Zoho ID
            $zoho_product_id = get_post_meta($product_id, '_zoho_product_id', true);
            
            if (!$zoho_product_id) {
                return array(
                    'success' => false,
                    'message' => __('Product has no Zoho ID. Run full sync first.', 'at-bookings-api-fixes'),
                    'action' => 'link_only'
                );
            }
            
            // Update WooCommerce SKU with Zoho ID (if not already set)
            $current_sku = get_post_meta($product_id, '_sku', true);
            if ($current_sku !== $zoho_product_id) {
                update_post_meta($product_id, '_sku', $zoho_product_id);
                write_detailed_log("Updated product #{$product_id} SKU to Zoho ID: {$zoho_product_id}", 'INFO');
            }
            
            // Save WordPress ID for reference (already saved during full sync)
            update_post_meta($product_id, '_zoho_wp_product_id', $wordpress_id);
            
            // Update last sync time
            update_post_meta($product_id, '_zoho_last_sync', time());
            
            // Log the link
            $this->logs->log_sync('link', 'Products', $product_id, $zoho_product_id, 'success', 
                array('action' => 'link_only', 'wp_id' => $wordpress_id), 
                array('id' => $zoho_product_id), null, null, null, null);
            
            return array(
                'success' => true,
                'zoho_id' => $zoho_product_id,
                'action' => 'link_only',
                'message' => __('Product IDs linked successfully', 'at-bookings-api-fixes')
            );
            
        } catch (Exception $e) {
            write_detailed_log('ZOHO product link-only sync failed: ' . $e->getMessage(), 'ERROR');
            $this->logs->log_sync('link', 'Products', $product_id, null, 'error', 
                array('action' => 'link_only'), null, $e->getMessage(), null, null, null);
            return array(
                'success' => false,
                'message' => $e->getMessage(),
                'action' => 'link_only'
            );
        }
    }

    /**
     * Prepare full cycle information from order (for preview)
     * 
     * @param WC_Order $order Order object
     * @return array Full cycle data for preview
     */
    private function prepare_cycle_info_from_order($order) {
        $cycle_data = array(
            'zoho_id' => null,
            'booking_id' => null,
            'product_id' => null,
            'product_zoho_id' => null,
            'product_name' => null,
            'sku' => null,
            'start_date' => null,
            'start_time' => null,
            'end_date' => null,
            'end_time' => null,
            'duration' => null,
            'persons_total' => null,
            'ticket_types' => array(),
            'unit_price' => null,
            'unique_id' => null,
        );
        
        foreach ($order->get_items() as $item) {
            $booking_id = wc_get_order_item_meta($item->get_id(), '_booking_id', true);
            if ($booking_id && function_exists('get_wc_booking')) {
                $booking = get_wc_booking($booking_id);
                if ($booking && method_exists($booking, 'get_start')) {
                    $zoho_cycle_id = get_post_meta($booking_id, '_zoho_cycle_id', true);
                    
                    // Get start time
                    $start = $booking->get_start();
                    $start_timestamp = is_numeric($start) ? intval($start) : strtotime($start);
                    
                    if (!$start_timestamp) {
                        write_detailed_log('Invalid booking start time: ' . $start, 'ERROR');
                        continue;
                    }
                    
                    // Get end time
                    $end = method_exists($booking, 'get_end') ? $booking->get_end() : null;
                    $end_timestamp = $end ? (is_numeric($end) ? intval($end) : strtotime($end)) : null;
                    
                    // Convert to Israel timezone
                    $israel_tz = new DateTimeZone('Asia/Jerusalem');
                    $datetime_start = new DateTime('@' . $start_timestamp);
                    $datetime_start->setTimezone($israel_tz);
                    $israel_timestamp = $datetime_start->getTimestamp();
                    
                    // Get product info
                    $product = method_exists($booking, 'get_product') ? $booking->get_product() : null;
                    $product_id = $product ? $product->get_id() : null;
                    $sku = $product ? $product->get_sku() : null;
                    $product_zoho_id = $sku ?: get_post_meta($product_id, '_zoho_product_id', true);
                    
                    // Get persons
                    $persons_total = method_exists($booking, 'get_persons_total') ? $booking->get_persons_total() : 0;
                    
                    // Get ticket types breakdown
                    $ticket_types = $this->modules->get_ticket_types_from_booking($booking);
                    
                    // Calculate duration
                    $duration_hours = null;
                    $end_date = null;
                    $end_time = null;
                    if ($end_timestamp) {
                        $datetime_end = new DateTime('@' . $end_timestamp);
                        $datetime_end->setTimezone($israel_tz);
                        $duration_hours = round(($end_timestamp - $start_timestamp) / 3600, 2);
                        $end_date = $datetime_end->format('Y-m-d');
                        $end_time = $datetime_end->format('H:i');
                    }
                    
                    // Unique cycle ID
                    $unique_id = $product_id . '_' . $israel_timestamp;
                    
                    $cycle_data = array(
                        'zoho_id' => $zoho_cycle_id ?: null,
                        'booking_id' => $booking_id,
                        'product_id' => $product_id,
                        'product_zoho_id' => $product_zoho_id,
                        'product_name' => $product ? $product->get_name() : '',
                        'sku' => $sku,
                        'start_date' => $datetime_start->format('Y-m-d'),
                        'start_time' => $datetime_start->format('H:i'),
                        'end_date' => $end_date,
                        'end_time' => $end_time,
                        'duration' => $duration_hours,
                        'persons_total' => $persons_total,
                        'ticket_types' => $ticket_types,
                        'unit_price' => $product ? floatval($product->get_price()) : 0,
                        'unique_id' => $unique_id,
                    );
                    
                    break; // Take first booking only
                }
            }
        }
        
        return $cycle_data;
    }

    /**
     * Get cycle info from order (simple version for backward compatibility)
     * 
     * @param WC_Order $order Order object
     * @return array Cycle info (zoho_id, booking_id, date, time)
     */
    private function get_cycle_info_from_order($order) {
        foreach ($order->get_items() as $item) {
            $booking_id = wc_get_order_item_meta($item->get_id(), '_booking_id', true);
            if ($booking_id && function_exists('get_wc_booking')) {
                $booking = get_wc_booking($booking_id);
                if ($booking && method_exists($booking, 'get_start')) {
                    $zoho_cycle_id = get_post_meta($booking_id, '_zoho_cycle_id', true);
                    
                    // Get start time - handle both timestamp and string
                    $start = $booking->get_start();
                    $start_timestamp = is_numeric($start) ? intval($start) : strtotime($start);
                    
                    if (!$start_timestamp) {
                        write_detailed_log('Invalid booking start time: ' . $start, 'ERROR');
                        continue;
                    }
                    
                    // Get end time
                    $end = method_exists($booking, 'get_end') ? $booking->get_end() : null;
                    $end_timestamp = $end ? (is_numeric($end) ? intval($end) : strtotime($end)) : null;
                    
                    // Get product info
                    $product = method_exists($booking, 'get_product') ? $booking->get_product() : null;
                    $product_id = $product ? $product->get_id() : null;
                    
                    // Get ZOHO Product ID - SKU is the ZOHO ID!
                    $product_zoho_id = null;
                    if ($product) {
                        $sku = $product->get_sku();
                        $product_zoho_id = $sku ?: get_post_meta($product_id, '_zoho_product_id', true);
                    }
                    
                    // Get persons
                    $persons_total = method_exists($booking, 'get_persons_total') ? $booking->get_persons_total() : 0;
                    
                    return array(
                        'zoho_id' => $zoho_cycle_id ?: null,
                        'booking_id' => $booking_id,
                        'product_id' => $product_id,
                        'product_zoho_id' => $product_zoho_id,
                        'product_name' => $product ? $product->get_name() : '',
                        'start_date' => date('Y-m-d', $start_timestamp),
                        'start_time' => date('H:i', $start_timestamp),
                        'end_date' => $end_timestamp ? date('Y-m-d', $end_timestamp) : null,
                        'end_time' => $end_timestamp ? date('H:i', $end_timestamp) : null,
                        'duration' => $end_timestamp ? (($end_timestamp - $start_timestamp) / 3600) : null,
                        'persons_total' => $persons_total,
                        'unit_price' => $product ? $product->get_price() : 0,
                    );
                }
            }
        }
        
        return array(
            'zoho_id' => null,
            'booking_id' => null,
            'start_date' => null,
            'start_time' => null,
            'product_name' => null,
        );
    }

    /**
     * Prepare order data for preview
     * 
     * @param WC_Order $order Order object
     * @return array Preview data with existing check
     */
    private function prepare_order_data($order) {
        $order_id = $order->get_id();

        // Prepare contact data
        $contact_data = $this->modules->wc_customer_to_zoho_contact($order);
        
        // Check for existing contact
        $existing_contact = null;
        $zoho_contact_id = get_post_meta($order_id, '_zoho_contact_id', true);
        
        if ($zoho_contact_id) {
            try {
                $existing_contact = $this->modules->get_record(AT_Zoho_Modules::MODULE_CONTACTS, $zoho_contact_id);
            } catch (Exception $e) {
                // Will search by email/phone
                $existing_contact = $this->modules->search_contact($order->get_billing_email(), $order->get_billing_phone());
            }
        } else {
            // Search by email/phone
            $existing_contact = $this->modules->search_contact($order->get_billing_email(), $order->get_billing_phone());
        }

        $contact_id = $existing_contact ? $existing_contact['id'] : null;

        // Get full cycle information with all details
        $cycle_full_info = $this->prepare_cycle_info_from_order($order);

        // Prepare order data using centralized mapper (single source of truth!)
        $temp_contact_id = $contact_id ?: 'WILL_BE_CREATED';
        $temp_cycle_id = isset($cycle_full_info['zoho_id']) ? $cycle_full_info['zoho_id'] : 'WILL_BE_CREATED';
        
        try {
            // Use AT_Zoho_Mapper - single source for payload building
            $slot_data = ['zoho_cycle_id' => $temp_cycle_id];
            $order_data = AT_Zoho_Mapper::map_to_sales_order($order, $slot_data);
            
            // Override with IDs (even temporary ones for preview)
            $order_data['Customer_No'] = $temp_contact_id;
            $order_data['Cycle_type'] = $temp_cycle_id;
        } catch (Exception $e) {
            write_detailed_log('Error preparing order data: ' . $e->getMessage(), 'ERROR');
            $order_data = array(
                'Subject' => 'Order #' . $order->get_order_number(),
                'Customer_No' => $temp_contact_id,
                'Cycle_type' => $temp_cycle_id,
                'error' => $e->getMessage()
            );
        }

        // Check for existing order
        $existing_order = null;
        $zoho_order_id = get_post_meta($order_id, '_zoho_order_id', true);
        
        if ($zoho_order_id) {
            try {
                $existing_order = $this->modules->get_record(AT_Zoho_Modules::MODULE_SALES_ORDERS, $zoho_order_id);
            } catch (Exception $e) {
                $existing_order = null;
            }
        }

        return array(
            'contact' => array(
                'data' => $contact_data,
                'existing' => $existing_contact,
                'action' => $existing_contact ? 'update' : 'create',
                'zoho_id' => $contact_id
            ),
            'cycle' => array(
                'zoho_id' => $cycle_full_info['zoho_id'],
                'action' => $cycle_full_info['zoho_id'] ? 'existing' : 'create',
                'booking_id' => $cycle_full_info['booking_id'],
                'product_id' => $cycle_full_info['product_id'],
                'product_zoho_id' => $cycle_full_info['product_zoho_id'],
                'product_name' => $cycle_full_info['product_name'],
                'sku' => $cycle_full_info['sku'],
                'start_date' => $cycle_full_info['start_date'],
                'start_time' => $cycle_full_info['start_time'],
                'end_date' => $cycle_full_info['end_date'],
                'end_time' => $cycle_full_info['end_time'],
                'duration' => $cycle_full_info['duration'],
                'persons_total' => $cycle_full_info['persons_total'],
                'ticket_types' => $cycle_full_info['ticket_types'],
                'unit_price' => $cycle_full_info['unit_price'],
                'unique_id' => $cycle_full_info['unique_id'],
            ),
            'order' => array(
                'data' => $order_data,
                'existing' => $existing_order,
                'action' => $existing_order ? 'update' : 'create',
                'zoho_id' => $zoho_order_id
            ),
            'record' => array(
                'contact' => $contact_data,
                'cycle' => $cycle_full_info,
                'order' => $order_data
            )
        );
    }

    /**
     * Sync order to ZOHO
     * 
     * @param WC_Order $order Order object
     * @return array|false Sync result or false
     */
    public function sync_order_to_zoho($order) {
        $order_id = $order->get_id();

        try {
            // Step 1: Get or create contact
            $contact_data = $this->modules->wc_customer_to_zoho_contact($order);
            
            // Check if we have ZOHO ID first
            $zoho_contact_id = get_post_meta($order_id, '_zoho_contact_id', true);
            
            if ($zoho_contact_id) {
                // Try to verify it exists
                try {
                    $contact = $this->modules->get_record(AT_Zoho_Modules::MODULE_CONTACTS, $zoho_contact_id);
                    // Update existing contact
                    $this->modules->update_record(AT_Zoho_Modules::MODULE_CONTACTS, $zoho_contact_id, $contact_data);
                    $this->logs->log_sync('update', 'Contacts', $order_id, $zoho_contact_id, 'success', $contact_data, $contact, null, null, null, null);
                } catch (Exception $e) {
                    // ID is invalid, search again
                    $contact = $this->modules->get_or_create_contact($contact_data);
                    $zoho_contact_id = $contact['id'];
                    $this->logs->log_sync('create', 'Contacts', $order_id, $zoho_contact_id, 'success', $contact_data, $contact, null, null, null, null);
                }
            } else {
                // No ID saved, get or create
                $contact = $this->modules->get_or_create_contact($contact_data);
                $zoho_contact_id = $contact['id'];
                $this->logs->log_sync('create', 'Contacts', $order_id, $zoho_contact_id, 'success', $contact_data, $contact, null, null, null, null);
            }

            if (!$contact || !isset($contact['id'])) {
                throw new Exception('Failed to create/find contact in ZOHO');
            }

            update_post_meta($order_id, '_zoho_contact_id', $zoho_contact_id);

            // Step 2: Get or create cycle from booking
            $zoho_cycle_id = null;
            foreach ($order->get_items() as $item) {
                $booking_id = wc_get_order_item_meta($item->get_id(), '_booking_id', true);
                if ($booking_id && function_exists('get_wc_booking')) {
                    $booking = get_wc_booking($booking_id);
                    if ($booking) {
                        try {
                            $cycle_result = $this->modules->get_or_create_cycle_from_booking($booking);
                            if ($cycle_result && isset($cycle_result['id'])) {
                                $zoho_cycle_id = $cycle_result['id'];
                                $this->logs->log_sync('cycle', 'Tour_Schedules', $booking_id, $zoho_cycle_id, 'success', null, $cycle_result, null, null, null, null);
                            }
                        } catch (Exception $e) {
                            // Log warning but continue (cycle is optional)
                            write_detailed_log('Could not sync cycle: ' . $e->getMessage(), 'WARNING');
                            $this->logs->log_sync('cycle', 'Tour_Schedules', $booking_id, null, 'error', null, null, $e->getMessage(), null, null, null);
                        }
                        break; // Take first booking only
                    }
                }
            }

            // Step 3: Create/update sales order using centralized mapper
            $slot_data = ['zoho_cycle_id' => $zoho_cycle_id];
            $order_data = AT_Zoho_Mapper::map_to_sales_order($order, $slot_data);
            
            // Override with confirmed IDs
            $order_data['Customer_No'] = $zoho_contact_id;
            $order_data['Cycle_type'] = $zoho_cycle_id;
            
            $zoho_order_id = get_post_meta($order_id, '_zoho_order_id', true);

            if ($zoho_order_id) {
                // Verify it exists
                try {
                    $this->modules->get_record(AT_Zoho_Modules::MODULE_SALES_ORDERS, $zoho_order_id);
                    // Update existing
                    $result = $this->modules->update_record(AT_Zoho_Modules::MODULE_SALES_ORDERS, $zoho_order_id, $order_data);
                    $this->logs->log_sync('update', 'Sales_Orders', $order_id, $zoho_order_id, 'success', $order_data, $result, null, null, null, null);
                } catch (Exception $e) {
                    // Create new
                    $result = $this->modules->create_record(AT_Zoho_Modules::MODULE_SALES_ORDERS, $order_data);
                    $zoho_order_id = $result['details']['id'];
                    update_post_meta($order_id, '_zoho_order_id', $zoho_order_id);
                    $this->logs->log_sync('create', 'Sales_Orders', $order_id, $zoho_order_id, 'success', $order_data, $result, null, null, null, null);
                }
            } else {
                // Create new
                $result = $this->modules->create_record(AT_Zoho_Modules::MODULE_SALES_ORDERS, $order_data);
                
                if ($result && isset($result['details']['id'])) {
                    $zoho_order_id = $result['details']['id'];
                    update_post_meta($order_id, '_zoho_order_id', $zoho_order_id);
                    $this->logs->log_sync('create', 'Sales_Orders', $order_id, $zoho_order_id, 'success', $order_data, $result, null, null, null, null);
                }
            }

            if ($result) {
                // Update last sync time
                update_post_meta($order_id, '_zoho_last_sync', time());
                
                return array(
                    'contact_id' => $zoho_contact_id,
                    'order_id' => $zoho_order_id,
                    'message' => __('Order synced successfully', 'at-bookings-api-fixes')
                );
            }

            // Log error
            $this->logs->log_sync('sync', 'Sales_Orders', $order_id, $zoho_order_id, 'error', $order_data, null, 'Sync failed - no result', null, null, null);
            return false;

        } catch (Exception $e) {
            // Log error
            $this->logs->log_sync('sync', 'Sales_Orders', $order_id, null, 'error', null, null, $e->getMessage(), null, null, null);
            write_detailed_log('ZOHO order sync failed: ' . $e->getMessage(), 'ERROR');
            return false;
        }
    }

    /**
     * AJAX: Sync contact only
     */
    public function ajax_sync_contact_only() {
        check_ajax_referer('at_zoho_sync_order', 'nonce');

        if (!current_user_can('edit_shop_orders')) {
            wp_send_json_error(__('Insufficient permissions'));
        }

        $order_id = intval($_POST['order_id']);
        $order = wc_get_order($order_id);

        if (!$order) {
            wp_send_json_error(__('Order not found'));
        }

        try {
            // Create/update contact
            $contact_data = $this->modules->wc_customer_to_zoho_contact($order);
            $contact = $this->modules->get_or_create_contact($contact_data);

            if ($contact && isset($contact['id'])) {
                update_post_meta($order_id, '_zoho_contact_id', $contact['id']);
                $this->logs->log_sync('create', 'Contacts', $order_id, $contact['id'], 'success', $contact_data, $contact, null, null, null, null);
                
                wp_send_json_success(array(
                    'contact_id' => $contact['id'],
                    'message' => 'Contact synced successfully'
                ));
            } else {
                wp_send_json_error('Failed to create contact');
            }

        } catch (Exception $e) {
            write_detailed_log('Contact sync error: ' . $e->getMessage(), 'ERROR');
            wp_send_json_error($e->getMessage());
        }
    }

    /**
     * AJAX: Sync cycle only
     */
    public function ajax_sync_cycle_only() {
        check_ajax_referer('at_zoho_sync_order', 'nonce');

        if (!current_user_can('edit_shop_orders')) {
            wp_send_json_error(__('Insufficient permissions'));
        }

        $order_id = intval($_POST['order_id']);
        $order = wc_get_order($order_id);

        if (!$order) {
            wp_send_json_error(__('Order not found'));
        }

        try {
            // Get booking
            $booking = null;
            foreach ($order->get_items() as $item) {
                $booking_id = wc_get_order_item_meta($item->get_id(), '_booking_id', true);
                if ($booking_id && function_exists('get_wc_booking')) {
                    $booking = get_wc_booking($booking_id);
                    if ($booking) {
                        break;
                    }
                }
            }

            if (!$booking) {
                wp_send_json_error('No booking found in order');
            }

            // Try to create/find cycle
            $cycle_result = $this->modules->get_or_create_cycle_from_booking($booking);

            if ($cycle_result && isset($cycle_result['id'])) {
                $this->logs->log_sync($cycle_result['action'], 'Tour_Schedules', $booking->get_id(), $cycle_result['id'], 'success', null, $cycle_result, null, null, null, null);
                
                wp_send_json_success(array(
                    'cycle_id' => $cycle_result['id'],
                    'action' => $cycle_result['action'],
                    'message' => 'Cycle synced successfully'
                ));
            } else {
                wp_send_json_error('Failed to create cycle');
            }

        } catch (Exception $e) {
            write_detailed_log('Cycle sync error: ' . $e->getMessage(), 'ERROR');
            wp_send_json_error($e->getMessage());
        }
    }
    
    /**
     * 🔄 AUTO-SYNC: Automatically sync order when status changes
     * 
     * Triggered when order status changes. Syncs ALL orders:
     * - Paid orders (completed, processing) → Sales_Order in Zoho
     * - Unpaid orders (pending, on-hold, etc.) → Lead in Zoho
     * 
     * Only syncs if auto-sync is enabled in settings
     * 
     * @param int $order_id Order ID
     * @param string $old_status Old order status
     * @param string $new_status New order status
     * @param WC_Order $order Order object
     */
    public function auto_sync_on_status_change($order_id, $old_status, $new_status, $order) {
        // Check if auto-sync is enabled
        $auto_sync_enabled = get_option('at_zoho_auto_sync_enabled', false);
        
        if (!$auto_sync_enabled) {
            write_detailed_log("🔕 Auto-sync disabled - Order #{$order_id} status change ($old_status → $new_status) NOT synced", 'DEBUG');
            return;
        }
        
        // 🔍 Sync ALL orders (not just paid ones)
        // The sync_order_record() function will decide:
        // - Paid (completed, processing) → Sales_Order
        // - Unpaid (pending, on-hold, failed) → Lead
        
        // Skip if status hasn't really changed (prevent duplicate syncs on same status)
        if ($old_status === $new_status) {
            write_detailed_log("⏭️ Auto-sync skipped - Order #{$order_id} status unchanged ($new_status)", 'DEBUG');
            return;
        }
        
        // Skip cancelled/refunded orders (unless you want to sync them too)
        $skip_statuses = array('trash', 'auto-draft');
        if (in_array($new_status, $skip_statuses)) {
            write_detailed_log("⏭️ Auto-sync skipped - Order #{$order_id} status '$new_status' in skip list", 'DEBUG');
            return;
        }
        
        // Prevent duplicate syncs - check if already synced recently (within 5 minutes)
        $last_auto_sync = get_post_meta($order_id, '_zoho_last_auto_sync', true);
        if ($last_auto_sync && (time() - $last_auto_sync) < 300) {
            write_detailed_log("⏭️ Auto-sync skipped - Order #{$order_id} already synced recently", 'DEBUG');
            return;
        }
        
        // Determine expected sync type for logging
        $paid_statuses = array('completed', 'processing');
        $is_paid = in_array($new_status, $paid_statuses) || $order->is_paid();
        $expected_type = $is_paid ? 'Sales_Order' : 'Lead';
        
        write_detailed_log(sprintf(
            "🔄 AUTO-SYNC TRIGGERED: Order #%d status changed from '%s' to '%s' (will sync as: %s)",
            $order_id,
            $old_status,
            $new_status,
            $expected_type
        ), 'INFO');
        
        // Load sync service
        if (!class_exists('AT_Zoho_Sync_Service')) {
            require_once AT_BOOKINGS_API_FIXES_PLUGIN_DIR . 'includes/zoho/zoho-sync-service.php';
        }
        
        // 🔧 FIX: AT_Zoho_Sync_Service doesn't use singleton pattern
        $sync_service = new AT_Zoho_Sync_Service();
        
        // Run sync in background (prevent blocking checkout/order creation)
        try {
            // Perform sync
            $result = $sync_service->sync_order($order_id, 'automatic');
            
            // Update last auto-sync timestamp
            update_post_meta($order_id, '_zoho_last_auto_sync', time());
            
            if ($result['success']) {
                // Count how many orders/leads were created
                $num_synced = 0;
                if (!empty($result['entities']['orders']) && is_array($result['entities']['orders'])) {
                    $num_synced = count($result['entities']['orders']);
                }
                
                write_detailed_log(sprintf(
                    "✅ AUTO-SYNC SUCCESS: Order #%d synced to Zoho CRM as %s (%d items)",
                    $order_id,
                    $expected_type,
                    $num_synced
                ), 'INFO');
                
                // Add order note with type and count
                $order->add_order_note(
                    sprintf(
                        __('🔄 Automatically synced to Zoho CRM as %s (status: %s, %d bookings)', 'at-bookings-api-fixes'),
                        $expected_type === 'Sales_Order' ? 'Sales Order' : 'Lead',
                        $new_status,
                        $num_synced
                    ),
                    false,
                    true
                );
            } else {
                write_detailed_log(sprintf(
                    "❌ AUTO-SYNC FAILED: Order #%d (expected: %s) - %s",
                    $order_id,
                    $expected_type,
                    $result['message'] ?? 'Unknown error'
                ), 'ERROR');
                
                // Add order note about failure
                $order->add_order_note(
                    sprintf(
                        __('⚠️ Auto-sync to Zoho CRM failed (%s): %s', 'at-bookings-api-fixes'),
                        $expected_type === 'Sales_Order' ? 'Sales Order' : 'Lead',
                        $result['message'] ?? 'Unknown error'
                    ),
                    false,
                    true
                );
            }
            
        } catch (Exception $e) {
            write_detailed_log("❌ AUTO-SYNC EXCEPTION: Order #{$order_id} - " . $e->getMessage(), 'ERROR');
            
            $order->add_order_note(
                sprintf(
                    __('⚠️ Auto-sync to Zoho CRM failed: %s', 'at-bookings-api-fixes'),
                    $e->getMessage()
                ),
                false,
                true
            );
        }
    }
    
    /**
     * 🔄 AUTO-SYNC: Automatically sync when booking is confirmed
     * 
     * Triggered when a WooCommerce Booking is confirmed
     * Only syncs if auto-sync is enabled in settings
     * 
     * @param WC_Booking $booking Booking object
     */
    public function auto_sync_on_booking_confirmed($booking) {
        // Check if auto-sync is enabled
        $auto_sync_enabled = get_option('at_zoho_auto_sync_enabled', false);
        
        if (!$auto_sync_enabled) {
            return;
        }
        
        // Get order ID from booking
        $order_id = $booking->get_order_id();
        
        if (!$order_id) {
            write_detailed_log("⏭️ Auto-sync skipped - Booking #{$booking->get_id()} has no order", 'DEBUG');
            return;
        }
        
        $order = wc_get_order($order_id);
        
        if (!$order) {
            write_detailed_log("❌ Auto-sync failed - Order #{$order_id} not found for booking #{$booking->get_id()}", 'ERROR');
            return;
        }
        
        // Prevent duplicate syncs
        $last_auto_sync = get_post_meta($order_id, '_zoho_last_auto_sync', true);
        if ($last_auto_sync && (time() - $last_auto_sync) < 300) {
            return;
        }
        
        write_detailed_log("🔄 AUTO-SYNC TRIGGERED: Booking #{$booking->get_id()} confirmed for Order #{$order_id}", 'INFO');
        
        // Delegate to order status change handler
        $this->auto_sync_on_status_change($order_id, $order->get_status(), $order->get_status(), $order);
    }
}

// Initialize ZOHO WooCommerce Integration
AT_Zoho_WooCommerce::get_instance();
