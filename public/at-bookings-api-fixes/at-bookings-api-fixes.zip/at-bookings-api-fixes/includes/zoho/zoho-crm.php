<?php
/**
 * ZOHO CRM Integration Module
 *
 * @package AT_Bookings_API_Fixes
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * ZOHO CRM Integration Class
 */
class AT_Zoho_CRM {

    private static $instance = null;

    // ZOHO API endpoints
    // ✅ FIXED: Use centralized constant from AT_Zoho_API
    const ZOHO_ACCOUNTS_URL = 'https://accounts.zoho.com';
    
    /**
     * Get Zoho CRM API URL (delegates to AT_Zoho_API)
     * ✅ FIXED: Single source of truth
     */
    public static function get_api_url() {
        if (class_exists('AT_Zoho_API')) {
            return AT_Zoho_API::get_api_base_url();
        }
        // Fallback for backward compatibility
        return 'https://www.zohoapis.com/crm/v2';
    }
    
    // Legacy constant for backward compatibility
    const ZOHO_CRM_API_URL = 'https://www.zohoapis.com/crm/v2';

    // Settings keys
    const OPTION_CLIENT_ID = 'at_zoho_client_id';
    const OPTION_CLIENT_SECRET = 'at_zoho_client_secret';
    const OPTION_DOMAIN = 'at_zoho_domain';
    const OPTION_REFRESH_TOKEN = 'at_zoho_refresh_token';
    const OPTION_ACCESS_TOKEN = 'at_zoho_access_token';
    const OPTION_TOKEN_EXPIRES = 'at_zoho_token_expires';

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init_hooks();
        $this->load_dependencies();
    }

    /**
     * Initialize hooks
     */
    private function init_hooks() {
        // Menu is now handled by AT_Bookings_Menu_Manager
        // Note: register_settings removed - now only registered once to prevent duplication
        add_action('wp_ajax_at_zoho_test_connection', array($this, 'ajax_test_connection'));
        add_action('wp_ajax_at_zoho_search_records', array($this, 'ajax_search_records'));
        add_action('wp_ajax_at_zoho_get_modules', array($this, 'ajax_get_modules'));
        add_action('wp_ajax_at_zoho_save_refresh_token', array($this, 'ajax_save_refresh_token'));
        add_action('wp_ajax_at_zoho_save_basic_settings', array($this, 'ajax_save_basic_settings'));
        add_action('wp_ajax_at_zoho_save_autosync_settings', array($this, 'ajax_save_autosync_settings'));
        
        // Add handler for OAuth callback via admin-post.php (to avoid 403 errors on direct file access)
        add_action('admin_post_at_zoho_oauth_callback', array($this, 'handle_oauth_callback'));
        
        // Schedule automatic token refresh
        add_action('at_zoho_refresh_token', array($this, 'scheduled_token_refresh'));
        
        // Check if we need to schedule the refresh
        if (!wp_next_scheduled('at_zoho_refresh_token')) {
            wp_schedule_event(time(), 'hourly', 'at_zoho_refresh_token');
        }
    }

    /**
     * Load module dependencies
     */
    private function load_dependencies() {
        // Load ZOHO API class
        if (file_exists(dirname(__FILE__) . '/zoho-api.php')) {
            require_once dirname(__FILE__) . '/zoho-api.php';
        }
        
        // Load ZOHO Modules Manager
        if (file_exists(dirname(__FILE__) . '/zoho-modules.php')) {
            require_once dirname(__FILE__) . '/zoho-modules.php';
        }
        
        // Load Sync Logs Manager
        if (file_exists(dirname(__FILE__) . '/zoho-sync-logs.php')) {
            require_once dirname(__FILE__) . '/zoho-sync-logs.php';
        }
        
        // Load WooCommerce Integration
        if (file_exists(dirname(__FILE__) . '/zoho-woocommerce.php')) {
            require_once dirname(__FILE__) . '/zoho-woocommerce.php';
        }
    }
    
    /**
     * Create a new record in Zoho CRM
     * 
     * @param string $module Module name (e.g., 'Contacts', 'Products', 'Sales_Orders')
     * @param array $data Record data
     * @return array Result with success status and record ID
     */
    public function create_record($module, $data) {
        $api = AT_Zoho_API::get_instance();
        return $api->create_record($module, $data);
    }
    
    /**
     * Update an existing record in Zoho CRM
     * 
     * @param string $module Module name
     * @param string $record_id Record ID
     * @param array $data Record data to update
     * @return array Result with success status
     */
    public function update_record($module, $record_id, $data) {
        $api = AT_Zoho_API::get_instance();
        return $api->update_record($module, $record_id, $data);
    }

    /**
     * Add admin menu
     * 
     * @deprecated 2.0.0 Menu is now handled by AT_Bookings_Menu_Manager
     */
    public function add_admin_menu() {
        // Menu registration moved to AT_Bookings_Menu_Manager in version 2.0.0
        // This method is kept for backward compatibility but does nothing
    }

    /**
     * Register settings
     * 
     * @deprecated 3.3.0 Settings registration is handled by the main plugin.
     * Kept for backward compatibility but no longer used.
     */
    public function register_settings() {
        // Settings are registered by AT_Bookings_API_Fixes::register_zoho_settings().
        // This method is kept for backward compatibility only
    }

    /**
     * Admin page callback
     */
    public function admin_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }

        // DEBUG
        error_log('AT_Zoho_CRM::admin_page() called');
        
        // Include new stepped settings page (ALWAYS use new version)
        $new_settings_file = dirname(__FILE__) . '/zoho-settings-new.php';
        $old_settings_file = dirname(__FILE__) . '/zoho-settings.php';
        
        error_log('New settings file: ' . $new_settings_file . ' exists: ' . (file_exists($new_settings_file) ? 'YES' : 'NO'));
        
        if (file_exists($new_settings_file)) {
            error_log('Loading new settings file');
            require_once $new_settings_file;
        } else {
            // Fallback only if new file doesn't exist
            error_log('New settings file not found, checking old file...');
            if (file_exists($old_settings_file)) {
                error_log('Loading old settings file');
                require_once $old_settings_file;
            }
        }
    }

    /**
     * Save settings
     */
    private function save_settings() {
        if (!wp_verify_nonce($_POST['_wpnonce'], 'at_zoho_settings')) {
            wp_die(__('Security check failed'));
        }

        $client_id = sanitize_text_field($_POST['zoho_client_id']);
        $client_secret = sanitize_text_field($_POST['zoho_client_secret']);
        $domain = sanitize_text_field($_POST['zoho_domain']);
        $refresh_token = sanitize_text_field($_POST['zoho_refresh_token']);

        update_option(self::OPTION_CLIENT_ID, $client_id);
        update_option(self::OPTION_CLIENT_SECRET, $client_secret);
        update_option(self::OPTION_DOMAIN, $domain);
        update_option(self::OPTION_REFRESH_TOKEN, $refresh_token);

        // Clear any cached tokens
        delete_option(self::OPTION_ACCESS_TOKEN);
        delete_option(self::OPTION_TOKEN_EXPIRES);

        add_settings_error('at_zoho_crm', 'settings_updated', __('Settings saved successfully.', 'at-bookings-api-fixes'), 'success');
    }

    /**
     * AJAX test connection
     */
    public function ajax_test_connection() {
        check_ajax_referer('at_zoho_test_connection', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions'));
        }

        $api = AT_Zoho_API::get_instance();
        $logs = AT_Zoho_Sync_Logs::get_instance();

        try {
            $result = $api->test_connection();
            
            // Log successful connection test
            $logs->log_sync(
                'test_connection',
                'System',
                null,
                null,
                'success',
                array('domain' => self::get_settings()['domain']),
                $result,
                null,
                AT_Zoho_API::get_api_base_url() . '/settings/modules',
                'GET',
                AT_Zoho_API::ZOHO_CRM_API_VERSION
            );
            
            wp_send_json_success($result);
        } catch (Exception $e) {
            // Log failed connection test
            $logs->log_sync(
                'test_connection',
                'System',
                null,
                null,
                'error',
                array('domain' => self::get_settings()['domain']),
                null,
                $e->getMessage(),
                AT_Zoho_API::get_api_base_url() . '/settings/modules',
                'GET',
                AT_Zoho_API::ZOHO_CRM_API_VERSION
            );
            
            wp_send_json_error($e->getMessage());
        }
    }

    /**
     * AJAX search records
     */
    public function ajax_search_records() {
        check_ajax_referer('at_zoho_search_records', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions'));
        }

        $module = sanitize_text_field($_POST['module']);
        $criteria = sanitize_text_field($_POST['criteria']);
        $value = sanitize_text_field($_POST['value']);

        if (empty($module) || empty($criteria) || empty($value)) {
            wp_send_json_error(__('Missing required parameters'));
        }

        $api = AT_Zoho_API::get_instance();
        $logs = AT_Zoho_Sync_Logs::get_instance();

        $search_criteria = array(
            'module' => $module,
            'field' => $criteria,
            'value' => $value
        );

        try {
            $result = $api->search_records($module, $criteria, $value);
            
            // Log successful search
            $logs->log_sync(
                'search',
                $module,
                null,
                null,
                'success',
                $search_criteria,
                array('count' => count($result), 'results' => $result),
                null,
                AT_Zoho_API::get_api_base_url() . '/' . $module . '/search',
                'GET',
                AT_Zoho_API::ZOHO_CRM_API_VERSION
            );
            
            wp_send_json_success($result);
        } catch (Exception $e) {
            // Log failed search
            $logs->log_sync(
                'search',
                $module,
                null,
                null,
                'error',
                $search_criteria,
                null,
                $e->getMessage(),
                AT_Zoho_API::get_api_base_url() . '/' . $module . '/search',
                'GET',
                AT_Zoho_API::ZOHO_CRM_API_VERSION
            );
            
            wp_send_json_error($e->getMessage());
        }
    }

    /**
     * AJAX get modules
     */
    public function ajax_get_modules() {
        check_ajax_referer('at_zoho_get_modules', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions'));
        }

        $api = AT_Zoho_API::get_instance();
        $logs = AT_Zoho_Sync_Logs::get_instance();

        try {
            $modules = $api->get_modules();
            
            // Log successful modules fetch
            $logs->log_sync(
                'get_modules',
                'System',
                null,
                null,
                'success',
                array('action' => 'fetch_modules'),
                array('count' => count($modules), 'modules' => array_column($modules, 'api_name')),
                null,
                AT_Zoho_API::get_api_base_url() . '/settings/modules',
                'GET',
                AT_Zoho_API::ZOHO_CRM_API_VERSION
            );
            
            wp_send_json_success($modules);
        } catch (Exception $e) {
            // Log failed modules fetch
            $logs->log_sync(
                'get_modules',
                'System',
                null,
                null,
                'error',
                array('action' => 'fetch_modules'),
                null,
                $e->getMessage(),
                AT_Zoho_API::get_api_base_url() . '/settings/modules',
                'GET',
                AT_Zoho_API::ZOHO_CRM_API_VERSION
            );
            
            wp_send_json_error($e->getMessage());
        }
    }

    /**
     * Get settings
     */
    public static function get_settings() {
        return array(
            'client_id' => get_option(self::OPTION_CLIENT_ID),
            'client_secret' => get_option(self::OPTION_CLIENT_SECRET),
            'domain' => get_option(self::OPTION_DOMAIN),
            'refresh_token' => get_option(self::OPTION_REFRESH_TOKEN),
            'access_token' => get_option(self::OPTION_ACCESS_TOKEN),
            'token_expires' => get_option(self::OPTION_TOKEN_EXPIRES)
        );
    }

    /**
     * Check if ZOHO is configured
     */
    public static function is_configured() {
        $settings = self::get_settings();
        return !empty($settings['client_id']) &&
               !empty($settings['client_secret']) &&
               !empty($settings['domain']) &&
               !empty($settings['refresh_token']);
    }

    /**
     * Scheduled token refresh
     * Runs automatically every hour to keep token fresh
     */
    public function scheduled_token_refresh() {
        // Only refresh if configured
        if (!self::is_configured()) {
            return;
        }

        $settings = self::get_settings();
        
        // Check if token is about to expire (within 30 minutes)
        $token_expires = $settings['token_expires'];
        $time_left = $token_expires - time();
        
        // If less than 30 minutes left, or already expired, refresh
        if ($time_left < 1800) {
            try {
                $api = AT_Zoho_API::get_instance();
                $api->refresh_access_token();
                
                write_detailed_log('ZOHO token auto-refreshed successfully', 'INFO');
                
                // Update last refresh time
                update_option('at_zoho_last_refresh', current_time('mysql'));
                
            } catch (Exception $e) {
                write_detailed_log('ZOHO token auto-refresh failed: ' . $e->getMessage(), 'ERROR');
                
                // Send admin notification if refresh fails
                $this->notify_admin_refresh_failed($e->getMessage());
            }
        }
    }

    /**
     * Notify admin if token refresh failed
     */
    private function notify_admin_refresh_failed($error_message) {
        // Check if we already notified in the last 24 hours
        $last_notification = get_option('at_zoho_last_notification', 0);
        if (time() - $last_notification < 86400) {
            return; // Already notified recently
        }
        
        // Send admin notice
        $admin_email = get_option('admin_email');
        $subject = '[ARTERNATIVE] ZOHO CRM Token Refresh Failed';
        $message = "שלום,\n\n";
        $message .= "הרענון האוטומטי של אסימון ZOHO CRM נכשל.\n\n";
        $message .= "שגיאה: {$error_message}\n\n";
        $message .= "אנא התחבר לאתר וחדש את ההגדרות ב-Tools > ZOHO CRM\n\n";
        $message .= "תודה,\nמערכת ARTERNATIVE";
        
        wp_mail($admin_email, $subject, $message);
        
        // Update last notification time
        update_option('at_zoho_last_notification', time());
    }

    /**
     * Manual token refresh (for testing)
     */
    public function manual_token_refresh() {
        if (!self::is_configured()) {
            return array('error' => 'ZOHO not configured');
        }

        try {
            $api = AT_Zoho_API::get_instance();
            $api->refresh_access_token();
            
            return array(
                'success' => true,
                'expires_at' => get_option(AT_Zoho_CRM::OPTION_TOKEN_EXPIRES)
            );
            
        } catch (Exception $e) {
            return array('error' => $e->getMessage());
        }
    }

    /**
     * AJAX Save Basic Settings (Step 1)
     * This is independent - does NOT require refresh token
     */
    public function ajax_save_basic_settings() {
        check_ajax_referer('at_zoho_save_basic_settings', 'at_zoho_basic_nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
        }

        if (!isset($_POST['zoho_client_id']) || !isset($_POST['zoho_client_secret']) || !isset($_POST['zoho_domain'])) {
            wp_send_json_error(__('Missing required fields', 'at-bookings-api-fixes'));
        }

        $client_id = sanitize_text_field($_POST['zoho_client_id']);
        $client_secret = sanitize_text_field($_POST['zoho_client_secret']);
        $domain = sanitize_text_field($_POST['zoho_domain']);

        if (empty($client_id) || empty($client_secret) || empty($domain)) {
            wp_send_json_error(__('All fields are required', 'at-bookings-api-fixes'));
        }

        // Validate domain
        $valid_domains = array('com', 'com-sandbox', 'eu', 'eu-sandbox', 'in', 'in-sandbox', 'au', 'au-sandbox');
        if (!in_array($domain, $valid_domains)) {
            wp_send_json_error(__('Invalid domain selected', 'at-bookings-api-fixes'));
        }

        // Save Step 1 credentials INDEPENDENTLY
        update_option(self::OPTION_CLIENT_ID, $client_id);
        update_option(self::OPTION_CLIENT_SECRET, $client_secret);
        update_option(self::OPTION_DOMAIN, $domain);

        // Clear any cached tokens (fresh start)
        delete_option(self::OPTION_ACCESS_TOKEN);
        delete_option(self::OPTION_TOKEN_EXPIRES);
        
        // Note: Do NOT clear refresh token - let user keep it if exists
        // This allows re-saving credentials without losing token

        wp_send_json_success(array(
            'message' => __('Step 1 Complete! Credentials saved. Proceed to Step 2.', 'at-bookings-api-fixes')
        ));
    }

    /**
     * AJAX Save Refresh Token (Step 2)
     */
    public function ajax_save_refresh_token() {
        check_ajax_referer('at_zoho_save_token', 'at_zoho_save_token');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
        }

        if (!isset($_POST['zoho_refresh_token']) || empty($_POST['zoho_refresh_token'])) {
            wp_send_json_error(__('Refresh token is required', 'at-bookings-api-fixes'));
        }

        $refresh_token = sanitize_text_field($_POST['zoho_refresh_token']);

        update_option(self::OPTION_REFRESH_TOKEN, $refresh_token);

        // Clear access token to force new one to be obtained
        delete_option(self::OPTION_ACCESS_TOKEN);
        delete_option(self::OPTION_TOKEN_EXPIRES);

        wp_send_json_success(array(
            'message' => __('Refresh token saved successfully!', 'at-bookings-api-fixes')
        ));
    }

    /**
     * Get accounts server domain for a specific region
     * NOTE: Accounts server is THE SAME for both Production and Sandbox!
     * Only the API domain differs (www.zohoapis.com vs sandbox.zohoapis.com)
     * 
     * Reference: https://help.zoho.com/portal/en/community/topic/kaizen-120-a-guide-to-api-calls-in-zoho-crm-sandboxes
     * 
     * @param string $domain_key Domain key from settings (e.g., 'com', 'com-sandbox')
     * @return string Accounts server domain (e.g., 'accounts.zoho.com')
     */
    public static function get_accounts_domain($domain_key = null) {
        if ($domain_key === null) {
            $settings = self::get_settings();
            $domain_key = $settings['domain'] ?? 'com';
        }
        
        // Strip '-sandbox' suffix if present, as accounts server is the same for all environments
        $region = str_replace('-sandbox', '', $domain_key);
        
        // Map region to accounts server
        $accounts_map = array(
            'com' => 'accounts.zoho.com',
            'eu' => 'accounts.zoho.eu',
            'in' => 'accounts.zoho.in',
            'au' => 'accounts.zoho.com.au'
        );
        
        return $accounts_map[$region] ?? 'accounts.zoho.com';
    }

    /**
     * Get ZOHO Authorization URL
     */
    public function get_zoho_auth_url() {
        $settings = self::get_settings();
        
        $accounts_domain = self::get_accounts_domain($settings['domain']);
        
        // Build redirect URI dynamically based on current site
        // Use admin-post.php to avoid 403 Forbidden errors on direct file access
        $redirect_uri = admin_url('admin-post.php?action=at_zoho_oauth_callback');
        
        $auth_url = "https://{$accounts_domain}/oauth/v2/auth?";
        $auth_url .= 'client_id=' . urlencode($settings['client_id']);
        $auth_url .= '&response_type=code';
        $auth_url .= '&scope=' . urlencode('ZohoCRM.modules.ALL,ZohoCRM.settings.ALL');
        $auth_url .= '&redirect_uri=' . urlencode($redirect_uri);
        $auth_url .= '&access_type=offline';
        $auth_url .= '&state=' . urlencode(wp_create_nonce('at_zoho_oauth'));
        
        return $auth_url;
    }

    /**
     * Handle OAuth callback via admin-post.php
     */
    public function handle_oauth_callback() {
        if (!current_user_can('manage_options')) {
            wp_die(
                esc_html__('You are not allowed to configure Zoho OAuth.', 'at-bookings-api-fixes'),
                esc_html__('Forbidden', 'at-bookings-api-fixes'),
                array('response' => 403)
            );
        }

        $state = isset($_GET['state']) ? sanitize_text_field(wp_unslash($_GET['state'])) : '';
        if ($state === '' || !wp_verify_nonce($state, 'at_zoho_oauth')) {
            wp_die(
                esc_html__('Invalid or expired Zoho OAuth state. Start authorization again from the settings page.', 'at-bookings-api-fixes'),
                esc_html__('Invalid OAuth state', 'at-bookings-api-fixes'),
                array('response' => 403)
            );
        }

        // Include the callback logic file
        // It handles the display and logic
        $callback_file = dirname(dirname(dirname(__FILE__))) . '/zoho-callback.php';
        if (file_exists($callback_file)) {
            require_once $callback_file;
        } else {
            wp_die('Zoho callback file not found.');
        }
        exit;
    }

    /**
     * AJAX Save Auto-Sync Settings
     */
    public function ajax_save_autosync_settings() {
        check_ajax_referer('at_zoho_save_basic_settings', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
        }

        $auto_sync_enabled = isset($_POST['auto_sync_enabled']) && $_POST['auto_sync_enabled'] === '1';
        $sync_on_order_create = isset($_POST['sync_on_order_create']) && $_POST['sync_on_order_create'] === '1';
        $sync_on_order_complete = isset($_POST['sync_on_order_complete']) && $_POST['sync_on_order_complete'] === '1';

        update_option('at_zoho_auto_sync_enabled', $auto_sync_enabled);
        update_option('at_zoho_sync_on_order_create', $sync_on_order_create);
        update_option('at_zoho_sync_on_order_complete', $sync_on_order_complete);

        write_detailed_log('ZOHO: Auto-sync settings updated - Enabled: ' . ($auto_sync_enabled ? 'Yes' : 'No'), 'INFO');

        wp_send_json_success(array(
            'message' => __('Auto-sync settings saved successfully!', 'at-bookings-api-fixes')
        ));
    }
}

// Initialize ZOHO CRM module
AT_Zoho_CRM::get_instance();
