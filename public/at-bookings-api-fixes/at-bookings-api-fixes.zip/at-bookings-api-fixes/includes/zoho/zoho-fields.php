<?php
/**
 * Zoho Fields Management
 * 
 * Handles caching and retrieval of Zoho module field definitions
 * 
 * @package AT_Bookings_API_Fixes
 * @subpackage Zoho
 * @since 3.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Zoho_Fields {
    
    const FIELDS_CACHE_TRANSIENT = 'at_zoho_module_fields_';
    const FIELDS_CACHE_DURATION = 15 * MINUTE_IN_SECONDS; // 15 minutes
    
    /**
     * Get fields for a module
     * 
     * @param string $module Module name (e.g., 'Contacts', 'Products')
     * @return array Array of fields or empty array on error
     */
    public static function get_module_fields($module) {
        $module = sanitize_text_field($module);
        
        // Check cache first
        $cache_key = self::FIELDS_CACHE_TRANSIENT . $module;
        $cached_fields = get_transient($cache_key);
        
        if ($cached_fields !== false) {
            return $cached_fields;
        }
        
        // Fetch from API
        if (!class_exists('AT_Zoho_CRM')) {
            return [];
        }
        
        try {
            $zoho_api = AT_Zoho_API::get_instance();
            $fields = $zoho_api->get_module_fields($module);
            
            if (!empty($fields)) {
                set_transient($cache_key, $fields, self::FIELDS_CACHE_DURATION);
                return $fields;
            }
            
        } catch (Exception $e) {
            error_log('AT Bookings: Error fetching Zoho fields for ' . $module . ': ' . $e->getMessage());
        }
        
        return [];
    }
    
    /**
     * Get field by API name
     * 
     * @param string $module Module name
     * @param string $field_api_name Field API name
     * @return array|null Field data or null if not found
     */
    public static function get_field($module, $field_api_name) {
        $fields = self::get_module_fields($module);
        
        foreach ($fields as $field) {
            if ($field['api_name'] === $field_api_name) {
                return $field;
            }
        }
        
        return null;
    }
    
    /**
     * Check if field exists
     * 
     * @param string $module Module name
     * @param string $field_api_name Field API name
     * @return bool
     */
    public static function field_exists($module, $field_api_name) {
        return self::get_field($module, $field_api_name) !== null;
    }
    
    /**
     * Get field type
     * 
     * @param string $module Module name
     * @param string $field_api_name Field API name
     * @return string|null Field type or null if not found
     */
    public static function get_field_type($module, $field_api_name) {
        $field = self::get_field($module, $field_api_name);
        return $field ? $field['field_type'] : null;
    }
    
    /**
     * Get required fields for module
     * 
     * @param string $module Module name
     * @return array Array of required field API names
     */
    public static function get_required_fields($module) {
        $fields = self::get_module_fields($module);
        $required = [];
        
        foreach ($fields as $field) {
            if (isset($field['mandatory']) && $field['mandatory']) {
                $required[] = $field['api_name'];
            }
        }
        
        return $required;
    }
    
    /**
     * Validate field values against field definitions
     * 
     * @param string $module Module name
     * @param array $data Field data to validate (api_name => value)
     * @return array Array with 'valid' bool and 'errors' array
     */
    public static function validate_field_data($module, $data) {
        $fields = self::get_module_fields($module);
        $errors = [];
        $field_map = [];
        
        // Build field map for quick lookup
        foreach ($fields as $field) {
            $field_map[$field['api_name']] = $field;
        }
        
        // Validate provided data
        foreach ($data as $field_api_name => $value) {
            if (!isset($field_map[$field_api_name])) {
                $errors[] = sprintf(__('Field "%s" does not exist in module "%s"', 'at-bookings-api-fixes'), $field_api_name, $module);
                continue;
            }
            
            $field = $field_map[$field_api_name];
            $validation_error = self::validate_field_value($field, $value);
            
            if ($validation_error) {
                $errors[] = $validation_error;
            }
        }
        
        // Check required fields
        foreach ($field_map as $field_api_name => $field) {
            if ($field['mandatory'] && !isset($data[$field_api_name])) {
                $errors[] = sprintf(__('Required field "%s" is missing', 'at-bookings-api-fixes'), $field['label']);
            }
        }
        
        return [
            'valid' => empty($errors),
            'errors' => $errors
        ];
    }
    
    /**
     * Validate single field value
     * 
     * @param array $field Field definition
     * @param mixed $value Value to validate
     * @return string|null Error message or null if valid
     */
    private static function validate_field_value($field, $value) {
        if ($value === null || $value === '') {
            return null; // Allow empty for non-mandatory
        }
        
        $field_type = $field['field_type'];
        
        // Type-specific validation
        switch ($field_type) {
            case 'number':
            case 'currency':
                if (!is_numeric($value)) {
                    return sprintf(__('Field "%s" must be numeric', 'at-bookings-api-fixes'), $field['label']);
                }
                break;
                
            case 'email':
                if (!is_email($value)) {
                    return sprintf(__('Field "%s" must be a valid email', 'at-bookings-api-fixes'), $field['label']);
                }
                break;
                
            case 'phone':
                // Basic phone validation
                if (!preg_match('/^[0-9\-\+\(\)\s]+$/', $value)) {
                    return sprintf(__('Field "%s" contains invalid phone characters', 'at-bookings-api-fixes'), $field['label']);
                }
                break;
                
            case 'picklist':
            case 'multiselectpicklist':
                if (!isset($field['pick_list_values'])) {
                    break;
                }
                
                $valid_values = array_map(function($opt) {
                    return $opt['display_value'] ?? $opt['value'];
                }, $field['pick_list_values']);
                
                $values = is_array($value) ? $value : [$value];
                foreach ($values as $v) {
                    if (!in_array($v, $valid_values)) {
                        return sprintf(__('Field "%s" contains invalid option "%s"', 'at-bookings-api-fixes'), $field['label'], $v);
                    }
                }
                break;
                
            case 'date':
                if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
                    return sprintf(__('Field "%s" must be in YYYY-MM-DD format', 'at-bookings-api-fixes'), $field['label']);
                }
                break;
                
            case 'datetime':
                if (!preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/', $value)) {
                    return sprintf(__('Field "%s" must be in ISO 8601 format', 'at-bookings-api-fixes'), $field['label']);
                }
                break;
        }
        
        return null;
    }
    
    /**
     * Get field label by API name
     * 
     * @param string $module Module name
     * @param string $field_api_name Field API name
     * @return string|null Field label or null if not found
     */
    public static function get_field_label($module, $field_api_name) {
        $field = self::get_field($module, $field_api_name);
        return $field ? $field['label'] : null;
    }
    
    /**
     * Clear fields cache for a module
     * 
     * @param string $module Module name (optional, clears all if empty)
     */
    public static function clear_cache($module = '') {
        if ($module) {
            delete_transient(self::FIELDS_CACHE_TRANSIENT . $module);
        } else {
            // Clear all module fields caches
            global $wpdb;
            $wpdb->query(
                $wpdb->prepare(
                    "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
                    '%' . $wpdb->esc_like(self::FIELDS_CACHE_TRANSIENT) . '%'
                )
            );
        }
    }
}
