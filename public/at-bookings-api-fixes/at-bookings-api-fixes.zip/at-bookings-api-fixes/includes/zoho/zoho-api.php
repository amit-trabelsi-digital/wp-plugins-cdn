<?php
/**
 * ZOHO CRM API Integration
 *
 * @package AT_Bookings_API_Fixes
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * ZOHO CRM API Class
 */
class AT_Zoho_API {

    private static $instance = null;

    // ZOHO API Version - Single source of truth
    // Change this to update API version across entire system
    const ZOHO_CRM_API_VERSION = 'v2.1'; // Options: v2, v3, v4, v5, v6, v7, v8
    
    // ZOHO API endpoints
    const ZOHO_ACCOUNTS_URL = 'https://accounts.zoho.com';
    
    /**
     * Get full Zoho CRM API base URL
     * Uses centralized API version constant
     * 
     * @param string|null $api_domain Optional API domain. If not provided, uses default (US).
     *                                Pass domain from get_api_domain() to use user's configured domain.
     * @return string Full API base URL
     */
    public static function get_api_base_url($api_domain = null) {
        // ✅ FIXED: Use provided domain or fallback to default
        if ($api_domain === null) {
            $api_domain = 'https://www.zohoapis.com'; // Default for backward compatibility
        }
        return $api_domain . '/crm/' . self::ZOHO_CRM_API_VERSION;
    }
    
    /**
     * Get default API domain (for backward compatibility)
     * @deprecated Use get_api_domain() instance method instead
     */
    private static function get_default_api_domain() {
        return 'https://www.zohoapis.com';
    }
    
    // Available domains
    private static $domains = array(
        'com' => 'https://www.zohoapis.com',
        'com-sandbox' => 'https://sandbox.zohoapis.com',
        'eu' => 'https://www.zohoapis.eu',
        'eu-sandbox' => 'https://sandbox.zohoapis.eu',
        'in' => 'https://www.zohoapis.in',
        'in-sandbox' => 'https://sandbox.zohoapis.in',
        'au' => 'https://www.zohoapis.au',
        'au-sandbox' => 'https://sandbox.zohoapis.au'
    );

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Constructor
    }

    /**
     * Get API domain URL
     */
    private function get_api_domain() {
        $settings = AT_Zoho_CRM::get_settings();
        $domain = $settings['domain'];

        if (isset(self::$domains[$domain])) {
            return self::$domains[$domain];
        }

        return self::$domains['com']; // Default to US
    }

    /**
     * Get access token (with refresh if needed)
     */
    private function get_access_token() {
        $settings = AT_Zoho_CRM::get_settings();

        // Check if we have a valid token
        if (!empty($settings['access_token']) && !empty($settings['token_expires'])) {
            if (time() < ($settings['token_expires'] - 300)) { // 5 minutes buffer
                return $settings['access_token'];
            }
        }

        // Need to refresh token
        return $this->refresh_access_token();
    }

    /**
     * Refresh access token using refresh token
     */
    public function refresh_access_token() {
        $settings = AT_Zoho_CRM::get_settings();

        if (empty($settings['client_id']) || empty($settings['client_secret']) || empty($settings['refresh_token'])) {
            throw new Exception(__('ZOHO CRM credentials not configured', 'at-bookings-api-fixes'));
        }

        // Get accounts domain from centralized function (CRITICAL: must use same domain as grant token!)
        $accounts_domain = AT_Zoho_CRM::get_accounts_domain($settings['domain']);
        $url = "https://{$accounts_domain}/oauth/v2/token";
        
        write_detailed_log('ZOHO: Attempting token refresh from URL: ' . $url, 'DEBUG');
        write_detailed_log('ZOHO: Client ID: ' . substr($settings['client_id'], 0, 10) . '...', 'DEBUG');
        write_detailed_log('ZOHO: Refresh Token (first 50 chars): ' . substr($settings['refresh_token'], 0, 50) . '...', 'DEBUG');
        write_detailed_log('ZOHO: Refresh Token Length: ' . strlen($settings['refresh_token']), 'DEBUG');

        $args = array(
            'method' => 'POST',
            'body' => array(
                'grant_type' => 'refresh_token',
                'client_id' => $settings['client_id'],
                'client_secret' => $settings['client_secret'],
                'refresh_token' => $settings['refresh_token']
            ),
            'headers' => array(
                'Content-Type' => 'application/x-www-form-urlencoded'
            ),
            'timeout' => 30
        );

        $response = wp_remote_post($url, $args);

        if (is_wp_error($response)) {
            write_detailed_log('ZOHO: WP Error - ' . $response->get_error_message(), 'ERROR');
            throw new Exception(__('Failed to connect to ZOHO: ', 'at-bookings-api-fixes') . $response->get_error_message());
        }

        $body = wp_remote_retrieve_body($response);
        $status_code = wp_remote_retrieve_response_code($response);
        
        write_detailed_log('ZOHO: Token response status: ' . $status_code, 'DEBUG');
        write_detailed_log('ZOHO: Token response body: ' . substr($body, 0, 200), 'DEBUG');

        $data = json_decode($body, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            write_detailed_log('ZOHO: JSON decode error - ' . json_last_error_msg(), 'ERROR');
            throw new Exception(__('Invalid response from ZOHO', 'at-bookings-api-fixes'));
        }

        if (isset($data['error'])) {
            $error_msg = $data['error'];
            if (!empty($data['error_description'])) {
                $error_msg .= ': ' . $data['error_description'];
            }
            write_detailed_log('ZOHO: API Error - ' . $error_msg, 'ERROR');
            throw new Exception(__('ZOHO API Error: ', 'at-bookings-api-fixes') . $error_msg);
        }

        if (empty($data['access_token'])) {
            write_detailed_log('ZOHO: No access token in response', 'ERROR');
            throw new Exception(__('No access token received from ZOHO', 'at-bookings-api-fixes'));
        }

        // Store the new token
        $expires_at = time() + ($data['expires_in'] ?? 3600);
        update_option(AT_Zoho_CRM::OPTION_ACCESS_TOKEN, $data['access_token']);
        update_option(AT_Zoho_CRM::OPTION_TOKEN_EXPIRES, $expires_at);

        write_detailed_log('ZOHO access token refreshed successfully', 'INFO');

        return $data['access_token'];
    }

    /**
     * Make API request to ZOHO
     */
    private function make_api_request($endpoint, $method = 'GET', $body = null, $params = array(), $retry_on_auth_fail = true) {
        $access_token = $this->get_access_token();
        $api_domain = $this->get_api_domain(); // ✅ Gets domain from user settings

        // ✅ FIXED: Use user's configured domain instead of hardcoded default
        $api_base = self::get_api_base_url($api_domain);
        $url = $api_base . '/' . ltrim($endpoint, '/');

        // Add query parameters
        if (!empty($params)) {
            $url .= '?' . http_build_query($params);
        }

        $args = array(
            'method' => $method,
            'headers' => array(
                'Authorization' => 'Zoho-oauthtoken ' . $access_token,
                'Content-Type' => 'application/json'
            ),
            'timeout' => 30
        );

        if ($body !== null) {
            if (is_array($body)) {
                $args['body'] = json_encode($body);
            } else {
                $args['body'] = $body;
            }
        }

        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            throw new Exception(__('ZOHO API request failed: ', 'at-bookings-api-fixes') . $response->get_error_message());
        }

        $status_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);

        write_detailed_log("ZOHO API Request: $method $url - Status: $status_code", 'DEBUG');

        // 204 No Content = no results found (not an error)
        if ($status_code === 204) {
            write_detailed_log("ZOHO API: No results found (204)", 'DEBUG');
            return array('data' => array());
        }

        // Check for authentication errors (401 or INVALID_TOKEN)
        if ($status_code === 401 || $status_code === 403) {
            $error_data = json_decode($response_body, true);
            $error_code = isset($error_data['code']) ? $error_data['code'] : '';
            
            // If this is an auth error and we haven't retried yet, refresh token and retry
            if ($retry_on_auth_fail && (in_array($error_code, array('INVALID_TOKEN', 'AUTHENTICATION_FAILURE', 'OAUTH_SCOPE_MISMATCH')))) {
                write_detailed_log("ZOHO API: Token expired/invalid (code: $error_code), refreshing automatically...", 'WARNING');
                
                try {
                    // Refresh the token
                    $new_token = $this->refresh_access_token();
                    write_detailed_log("ZOHO API: Token refreshed successfully, retrying request...", 'INFO');
                    
                    // Retry the same request with new token (prevent infinite loop with retry_on_auth_fail = false)
                    return $this->make_api_request($endpoint, $method, $body, $params, false);
                    
                } catch (Exception $e) {
                    write_detailed_log("ZOHO API: Token refresh failed: " . $e->getMessage(), 'ERROR');
                    throw new Exception(__('ZOHO authentication failed. Please reconnect in settings.', 'at-bookings-api-fixes'));
                }
            }
        }

        if ($status_code < 200 || $status_code >= 300) {
            $error_data = json_decode($response_body, true);
            $error_message = isset($error_data['message']) ? $error_data['message'] : "HTTP $status_code";
            $error_code = isset($error_data['code']) ? $error_data['code'] : '';
            
            // Add detailed error info if available
            if (isset($error_data['details'])) {
                $error_message .= ' Details: ' . json_encode($error_data['details'], JSON_UNESCAPED_UNICODE);
            }
            
            // Fallback: If no structured error, include raw body for debugging
            if (empty($error_data['message']) && !empty($response_body)) {
                $error_message .= " Response: " . substr($response_body, 0, 500);
            }
            
            throw new Exception(__('ZOHO API Error: ', 'at-bookings-api-fixes') . $error_message . ($error_code ? " (Code: $error_code)" : ''));
        }

        // Empty body is valid for some responses
        if (empty($response_body)) {
            write_detailed_log("ZOHO API: Empty response body", 'DEBUG');
            return array('data' => array());
        }

        $data = json_decode($response_body, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            write_detailed_log("ZOHO API: JSON decode error - " . json_last_error_msg(), 'ERROR');
            write_detailed_log("ZOHO API: Body = " . substr($response_body, 0, 500), 'ERROR');
            throw new Exception(__('Invalid JSON response from ZOHO', 'at-bookings-api-fixes'));
        }

        return $data;
    }

    /**
     * Test connection to ZOHO CRM
     */
    public function test_connection() {
        try {
            $settings = AT_Zoho_CRM::get_settings();

            if (empty($settings['client_id']) || empty($settings['client_secret']) || empty($settings['refresh_token'])) {
                throw new Exception(__('ZOHO credentials not configured', 'at-bookings-api-fixes'));
            }

            // Try to refresh token to test credentials
            $access_token = $this->refresh_access_token();

            // Test API call - get available modules (requires less permissions)
            $modules_data = $this->make_api_request('/settings/modules', 'GET', null, array('type' => 'api_supported'));

            return array(
                'status' => 'connected',
                'api_domain' => $this->get_api_domain(),
                'expires_at' => get_option(AT_Zoho_CRM::OPTION_TOKEN_EXPIRES),
                'modules_count' => isset($modules_data['modules']) ? count($modules_data['modules']) : 0
            );

        } catch (Exception $e) {
            throw new Exception(__('Connection test failed: ', 'at-bookings-api-fixes') . $e->getMessage());
        }
    }

    /**
     * Search records in ZOHO CRM
     */
    public function search_records($module, $criteria, $value) {
        try {
            // ZOHO CRM search API
            $search_params = array(
                'criteria' => "($criteria:equals:$value)"
            );

            // Log API context
            self::log_api_call_context("/$module/search", 'GET', $search_params);
            
            $data = $this->make_api_request("/$module/search", 'GET', null, $search_params);

            if (isset($data['data']) && is_array($data['data'])) {
                return array(
                    'success' => true,
                    'data' => $data['data']
                );
            }

            return array(
                'success' => true,
                'data' => array()
            );

        } catch (Exception $e) {
            write_detailed_log('ZOHO: Search exception: ' . $e->getMessage(), 'ERROR');
            return array(
                'success' => false,
                'message' => $e->getMessage(),
                'data' => array()
            );
        }
    }

    /**
     * Get record by ID
     */
    public function get_record($module, $id) {
        try {
            // Log API context
            self::log_api_call_context("/$module/$id", 'GET');
            
            $data = $this->make_api_request("/$module/$id", 'GET');

            if (isset($data['data']) && is_array($data['data']) && !empty($data['data'])) {
                return $data['data'][0];
            }

            throw new Exception(__('Record not found', 'at-bookings-api-fixes'));

        } catch (Exception $e) {
            throw new Exception(__('Get record failed: ', 'at-bookings-api-fixes') . $e->getMessage());
        }
    }

    /**
     * Create new record
     */
    public function create_record($module, $record_data) {
        try {
            $body = array(
                'data' => array($record_data)
            );

            // Log API context
            self::log_api_call_context("/$module", 'POST');
            
            $data = $this->make_api_request("/$module", 'POST', $body);

            // 🔍 CRITICAL: Validate response structure and verify we got an ID
            if (isset($data['data']) && is_array($data['data']) && !empty($data['data'])) {
                $record = $data['data'][0];
                $zoho_id = $record['details']['id'] ?? null;
                
                // ⚠️ IMPORTANT: Only return success if we have a valid Zoho ID!
                // Sometimes Zoho returns success status but with error in details
                if (!empty($zoho_id) && is_string($zoho_id)) {
                    return array(
                        'success' => true,
                        'id' => $zoho_id,
                        'data' => $record,
                        'message' => $record['message'] ?? 'Record created'
                    );
                }
                
                // If no ID, check for error in response
                $error_message = $record['message'] ?? __('No ID returned from Zoho', 'at-bookings-api-fixes');
                if (isset($record['details']['api_name'])) {
                    $error_message .= ' (Field: ' . $record['details']['api_name'] . ')';
                }
                
                write_detailed_log('ZOHO: Create record returned data but no valid ID. Response: ' . json_encode($record, JSON_UNESCAPED_UNICODE), 'ERROR');
                
                return array(
                    'success' => false,
                    'message' => $error_message,
                    'raw_response' => $record
                );
            }

            return array(
                'success' => false,
                'message' => __('Failed to create record - no data returned', 'at-bookings-api-fixes'),
                'raw_response' => $data
            );

        } catch (Exception $e) {
            write_detailed_log('ZOHO: Create record exception: ' . $e->getMessage(), 'ERROR');
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }

    /**
     * Update existing record
     */
    public function update_record($module, $id, $record_data) {
        try {
            $body = array(
                'data' => array($record_data)
            );

            // Log API context
            self::log_api_call_context("/$module/$id", 'PUT');
            
            $data = $this->make_api_request("/$module/$id", 'PUT', $body);

            // 🔍 CRITICAL: Validate response and check for actual success
            if (isset($data['data']) && is_array($data['data']) && !empty($data['data'])) {
                $record = $data['data'][0];
                
                // Check if update actually succeeded (Zoho returns status in response)
                $update_status = $record['code'] ?? $record['status'] ?? 'unknown';
                $is_success = ($update_status === 'success' || $update_status === 'SUCCESS');
                
                if ($is_success) {
                    return array(
                        'success' => true,
                        'id' => $id,
                        'data' => $record,
                        'message' => $record['message'] ?? 'Record updated'
                    );
                }
                
                // Update failed - extract error
                $error_message = $record['message'] ?? __('Update failed', 'at-bookings-api-fixes');
                write_detailed_log('ZOHO: Update record failed. Response: ' . json_encode($record, JSON_UNESCAPED_UNICODE), 'ERROR');
                
                return array(
                    'success' => false,
                    'message' => $error_message,
                    'raw_response' => $record
                );
            }

            return array(
                'success' => false,
                'message' => __('Failed to update record - no data returned', 'at-bookings-api-fixes'),
                'raw_response' => $data
            );

        } catch (Exception $e) {
            write_detailed_log('ZOHO: Update record exception: ' . $e->getMessage(), 'ERROR');
            return array(
                'success' => false,
                'message' => $e->getMessage()
            );
        }
    }

    /**
     * Get available modules
     */
    public function get_modules() {
        try {
            write_detailed_log('ZOHO: Getting modules from API', 'DEBUG');
            $data = $this->make_api_request('/settings/modules', 'GET');
            
            write_detailed_log('ZOHO: Modules response received', 'DEBUG');
            write_detailed_log('ZOHO: Response keys: ' . implode(', ', array_keys($data)), 'DEBUG');

            if (isset($data['modules']) && is_array($data['modules'])) {
                $filtered = array_filter($data['modules'], function($module) {
                    return isset($module['api_supported']) && $module['api_supported'];
                });
                
                write_detailed_log('ZOHO: Found ' . count($filtered) . ' API-supported modules', 'INFO');
                return array_values($filtered);  // Re-index array
            }

            write_detailed_log('ZOHO: No modules found in response', 'WARNING');
            return array();

        } catch (Exception $e) {
            write_detailed_log('ZOHO: Get modules error - ' . $e->getMessage(), 'ERROR');
            throw new Exception(__('Get modules failed: ', 'at-bookings-api-fixes') . $e->getMessage());
        }
    }

    /**
     * Get the organization (org) info for the connected Zoho account.
     *
     * Used to build deep links to records in the Zoho CRM UI
     * (URL format: https://crm.zoho.<domain>/crm/org<zgid>/tab/<Module>/<recordId>).
     *
     * @return array Org data or empty array on failure.
     */
    public function get_organization() {
        try {
            $data = $this->make_api_request('/org', 'GET');
            if (isset($data['org']) && is_array($data['org']) && !empty($data['org'][0])) {
                return $data['org'][0];
            }
            return array();
        } catch (Exception $e) {
            if (function_exists('write_detailed_log')) {
                write_detailed_log('ZOHO: get_organization error - ' . $e->getMessage(), 'WARNING');
            }
            return array();
        }
    }

    /**
     * Get module fields
     */
    public function get_module_fields($module) {
        try {
            // Log API context
            self::log_api_call_context("/settings/fields", 'GET', array('module' => $module));
            
            $data = $this->make_api_request("/settings/fields", 'GET', null, array('module' => $module));

            if (isset($data['fields']) && is_array($data['fields'])) {
                return $data['fields'];
            }

            return array();

        } catch (Exception $e) {
            throw new Exception(__('Get module fields failed: ', 'at-bookings-api-fixes') . $e->getMessage());
        }
    }
    
    /**
     * Helper method to log API context to sync logs
     * Useful for recording which API endpoint and method was used
     */
    public static function log_api_call_context($endpoint, $method = 'GET', $params = array()) {
        if (!class_exists('AT_Zoho_Sync_Logs')) {
            return;
        }
        
        $api_base = self::get_api_base_url();
        $url = $api_base . '/' . ltrim($endpoint, '/');
        
        if (!empty($params)) {
            $url .= '?' . http_build_query($params);
        }
        
        $logs = AT_Zoho_Sync_Logs::get_instance();
        $logs->set_api_context($url, $method, self::ZOHO_CRM_API_VERSION);
    }
}

// Initialize ZOHO API
AT_Zoho_API::get_instance();
