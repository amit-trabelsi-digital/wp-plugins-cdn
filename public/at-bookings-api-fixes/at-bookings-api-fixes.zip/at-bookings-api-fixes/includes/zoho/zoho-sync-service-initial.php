<?php
/**
 * Initial Sync Helper - Wraps AT_Zoho_Sync_Service for bulk insert-only operations
 *
 * Provides batched product/cycle/order sync with insert-only constraints,
 * resume/stop controls, and per-record logging without duplicating sync logic.
 *
 * @package AT_Bookings_API_Fixes
 * @subpackage Zoho
 * @since 3.5.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Zoho_Sync_Service_Initial {
    
    const SYNC_STATE_META_KEY = '_at_zoho_sync_state';
    const STOP_FLAG_TRANSIENT = 'at_initial_sync_stop_';
    const SYNC_MODE_INSERT_ONLY = 'insert_only';
    
    private $sync_service;
    private $zoho_api;
    private $user_id;
    private $stop_flag_key;
    private $insert_only_mode = true;
    private $batch_processed = 0;
    private $batch_errors = [];
    
    public function __construct() {
        $this->user_id = get_current_user_id();
        $this->stop_flag_key = self::STOP_FLAG_TRANSIENT . $this->user_id;
        $this->sync_service = new AT_Zoho_Sync_Service();
        
        // Initialize Zoho API for direct operations
        if (class_exists('AT_Zoho_API')) {
            $this->zoho_api = AT_Zoho_API::get_instance();
        }
    }
    
    /**
     * Get products to sync (publish status only, not yet synced or failed)
     *
     * @param int $limit Maximum products to fetch
     * @param int $offset Offset for pagination
     * @param bool $insert_only_mode Whether to skip already synced products (default: true for safety)
     * @return array Product objects
     */
    public function get_products_to_sync($limit = 50, $offset = 0, $insert_only_mode = true) {
        // Update the instance property for use in other methods
        $this->insert_only_mode = $insert_only_mode;
        
        $args = [
            'post_type' => 'product',
            'post_status' => 'publish',
            'numberposts' => $limit,
            'offset' => $offset,
            'orderby' => 'ID',
            'order' => 'ASC',
        ];
        
        $products = get_posts($args);
        $filtered_products = [];
        
        foreach ($products as $product_post) {
            $product = wc_get_product($product_post->ID);
            
            // Only process booking products
            if (!$product || $product->get_type() !== 'booking') {
                continue;
            }
            
            // Check if already synced (only skip in insert-only mode)
            $sync_state = $this->get_sync_state($product->get_id());
            
            if ($insert_only_mode && !empty($sync_state['synced'])) {
                continue;
            }
            
            $filtered_products[] = $product;
        }
        
        return $filtered_products;
    }
    
    /**
     * Get cycles to sync (for a given date range)
     *
     * @param string $start_date Start date (Y-m-d)
     * @param string $end_date End date (Y-m-d)
     * @param int $limit Batch size
     * @return array Array of cycle data
     */
    public function get_cycles_to_sync($start_date = null, $end_date = null, $limit = 50) {
        if (!$start_date) {
            $start_date = date('Y-m-d');
        }
        if (!$end_date) {
            $end_date = date('Y-m-d', strtotime('+90 days'));
        }
        
        // ✅ Use the centralized function that gets live WooCommerce Bookings data
        if (!function_exists('at_get_future_tours_data')) {
            AT_Bookings_Logger::error('[Initial Sync] at_get_future_tours_data() function not available');
            return array();
        }
        
        // Get tours data from WooCommerce Bookings (not custom table)
        $result = at_get_future_tours_data(
            $start_date,
            $end_date,
            null,  // city filter
            null,  // product filter
            true,  // include_past
            'all'  // mode - all tours (with and without bookings)
        );
        
        $tours = $result['data'] ?? array();
        
        // Sort by date + time (ascending - nearest first)
        usort($tours, function($a, $b) {
            $datetime_a = strtotime($a['date'] . ' ' . $a['start_time']);
            $datetime_b = strtotime($b['date'] . ' ' . $b['start_time']);
            return $datetime_a - $datetime_b;  // Ascending: nearest first
        });
        
        // Limit results
        if ($limit && count($tours) > $limit) {
            $tours = array_slice($tours, 0, $limit);
        }
        
        AT_Bookings_Logger::debug("[Initial Sync] Found " . count($tours) . " cycles for period $start_date to $end_date (sorted by date)");
        
        return $tours;
    }
    
    /**
     * Get orders to sync (with optional status filter)
     *
     * @param string $start_date Start date (Y-m-d)
     * @param string $order_status WooCommerce order status (e.g., 'wc-completed', 'wc-pending')
     * @param int $limit Batch size
     * @return array WC_Order objects
     */
    public function get_orders_to_sync($start_date = null, $order_status = null, $limit = 50) {
        if (!$start_date) {
            $start_date = date('Y-m-d', strtotime('-30 days'));
        }
        
        $args = [
            'status' => $order_status ?: ['pending', 'processing', 'on-hold', 'completed'],
            'date_created' => '>=' . strtotime($start_date),
            'limit' => $limit,
            'orderby' => 'ID',
            'order' => 'ASC',
        ];
        
        $orders = wc_get_orders($args);
        $filtered_orders = [];
        
        foreach ($orders as $order) {
            // Skip if already synced in insert-only mode
            if ($this->insert_only_mode) {
                $zoho_id = get_post_meta($order->get_id(), '_zoho_sales_order_id', true) 
                    ?: get_post_meta($order->get_id(), '_zoho_lead_id', true);
                
                if (!empty($zoho_id)) {
                    continue;
                }
            }
            
            $filtered_orders[] = $order;
        }
        
        return $filtered_orders;
    }
    
    /**
     * Sync batch of products (uses existing AT_Zoho_WooCommerce::sync_product_to_zoho)
     *
     * @param array $products Product objects
     * @param bool $insert_only Force insert-only (skip existing)
     * @param int $batch_limit Optional limit for how many to actually sync (default: sync all provided)
     * @return array Results with success/error counts
     */
    public function sync_products_batch($products, $insert_only = true, $batch_limit = null) {
        $this->insert_only_mode = $insert_only;
        $results = [
            'success_count' => 0,
            'error_count' => 0,
            'records' => [],
        ];
        
        // Apply batch limit if specified
        if ($batch_limit !== null && $batch_limit > 0) {
            $products = array_slice($products, 0, $batch_limit);
            AT_Bookings_Logger::debug("[Initial Sync] Batch limited to {$batch_limit} products");
        }
        
        // Use existing AT_Zoho_WooCommerce for product sync
        if (!class_exists('AT_Zoho_WooCommerce')) {
            AT_Bookings_Logger::error('AT_Zoho_WooCommerce class not found');
            return $results;
        }
        
        $zoho_wc = AT_Zoho_WooCommerce::get_instance();
        
        foreach ($products as $product) {
            if ($this->is_stopped()) {
                break;
            }
            
            $product_id = $product->get_id();
            $product_name = $product->get_name();
            $sku = $product->get_sku();
            $wc_product_id = $product->get_id();
            
            $sync_state = $this->get_sync_state($product_id);
            $existing_zoho_id = get_post_meta($product_id, '_zoho_product_id', true);
            
            // Determine if we should sync this product
            $should_sync = true;
            $skip_reason = '';
            
            if ($insert_only) {
                // Insert-only mode (safe mode):
                // Skip if already synced OR has Zoho ID
                if (!empty($sync_state['synced']) || !empty($existing_zoho_id)) {
                    $should_sync = false;
                    $skip_reason = __('Already synced to Zoho (skipped in insert-only mode)', 'at-bookings-api-fixes');
                }
            }
            // else: Force create mode - sync everything (even if has Zoho ID)
            
            if (!$should_sync) {
                AT_Bookings_Logger::debug("[Initial Sync] Product #$product_id skipping: $skip_reason");
                $results['records'][] = [
                    'id' => $product_id,
                    'sku' => $sku ?: '(ריק)',
                    'wc_pid' => $wc_product_id,
                    'name' => $product_name,
                    'success' => true,
                    'message' => $skip_reason,
                    'zoho_id' => $existing_zoho_id,
                ];
                continue;
            }
            
            // Sync the product
            AT_Bookings_Logger::debug("[Initial Sync] Syncing product #$product_id: $product_name [SKU: " . ($sku ?: '(empty)') . ", Insert-only: " . ($insert_only ? 'YES' : 'NO') . "]");
            
            // Use existing sync_product_to_zoho method
            // Pass force_full_sync = true if NOT in insert_only mode
            try {
                $result = $zoho_wc->sync_product_to_zoho($product, 'full', !$insert_only);
                
                if (!empty($result['zoho_id'])) {
                    $results['success_count']++;
                    $this->update_sync_state($product_id, [
                        'synced' => true,
                        'zoho_id' => $result['zoho_id'],
                        'last_sync' => current_time('mysql'),
                        'status' => 'success',
                    ]);
                    
                    AT_Bookings_Logger::info("[Initial Sync] Product #$product_id synced successfully. Zoho ID: " . $result['zoho_id']);
                } else {
                    $results['error_count']++;
                    $this->update_sync_state($product_id, [
                        'synced' => false,
                        'last_sync' => current_time('mysql'),
                        'status' => 'error',
                        'error' => $result['message'] ?? 'Unknown error',
                    ]);
                    
                    AT_Bookings_Logger::error("[Initial Sync] Product #$product_id sync failed: " . ($result['message'] ?? 'Unknown error'));
                }
                
                $results['records'][] = [
                    'id' => $product_id,
                    'sku' => $sku ?: '(ריק)',
                    'wc_pid' => $wc_product_id,
                    'name' => $product_name,
                    'success' => !empty($result['zoho_id']),
                    'message' => $result['message'] ?? '',
                    'zoho_id' => $result['zoho_id'] ?? null,
                ];
                
            } catch (Exception $e) {
                $results['error_count']++;
                $error_msg = $e->getMessage();
                AT_Bookings_Logger::error("[Initial Sync] Exception syncing product #$product_id: $error_msg");
                
                $this->update_sync_state($product_id, [
                    'synced' => false,
                    'last_sync' => current_time('mysql'),
                    'status' => 'error',
                    'error' => $error_msg,
                ]);
                
                $results['records'][] = [
                    'id' => $product_id,
                    'sku' => $sku ?: '(ריק)',
                    'wc_pid' => $wc_product_id,
                    'name' => $product_name,
                    'success' => false,
                    'message' => $error_msg,
                    'zoho_id' => null,
                ];
            }
            
            $this->batch_processed++;
        }
        
        return $results;
    }
    
    /**
     * Sync batch of cycles/slots
     *
     * @param array $cycles Cycle data arrays
     * @param WC_Order|null $order Associated order (for proper mapping)
     * @return array Results
     */
    public function sync_cycles_batch($cycles, $order = null) {
        $results = [
            'success_count' => 0,
            'error_count' => 0,
            'records' => [],
        ];
        
        foreach ($cycles as $cycle_data) {
            if ($this->is_stopped()) {
                break;
            }
            
            // Map slot data to cycle format for Zoho
            $cycle_result = $this->sync_cycle_item($cycle_data, $order);
            
            if ($cycle_result['success']) {
                $results['success_count']++;
            } else {
                $results['error_count']++;
            }
            
            $results['records'][] = $cycle_result;
            $this->batch_processed++;
        }
        
        return $results;
    }
    
    /**
     * Sync single cycle/slot (uses existing AT_Zoho_Sync_Service::sync_cycle)
     *
     * @param array $cycle_data Tour/cycle data from at_get_future_tours_data()
     * @param WC_Product|null $product Associated product (optional)
     * @return array Result
     */
    private function sync_cycle_item($cycle_data, $product = null) {
        $tour_id = $cycle_data['tour_id'] ?? 'unknown';
        $product_id = $cycle_data['product_id'] ?? 0;
        
        AT_Bookings_Logger::debug("[Initial Sync] Syncing cycle Tour ID: $tour_id, Product: $product_id");
        
        try {
            // Get product if not provided
            if (!$product && $product_id) {
                $product = wc_get_product($product_id);
            }
            
            // Convert tour data to slot format for sync_cycle()
            $slot_data = array(
                'id' => null,  // No specific booking ID for tour slots
                'product_id' => $product_id,
                'slot_start' => $cycle_data['date'] . ' ' . $cycle_data['start_time'],
                'slot_end' => $cycle_data['date'] . ' ' . $cycle_data['end_time'],
                'tour_id' => $tour_id,
                'status' => 'confirmed',  // Default status for published tours
                'current_bookings' => $cycle_data['bookings_count'] ?? 0,
                'booked_persons' => $cycle_data['booked_persons'] ?? 0,
                'max_capacity' => $cycle_data['max_capacity'] ?? 0,
            );
            
            // Use AT_Zoho_Sync_Service::sync_cycle
            // This function handles mapping, validation, search, and create/update
            $result = $this->sync_service->sync_cycle($slot_data, $product);
            
            if ($result['success']) {
                $zoho_id = $result['zoho_id'] ?? 'N/A';
                AT_Bookings_Logger::info("[Initial Sync] Cycle $tour_id synced successfully. Zoho ID: $zoho_id");
            } else {
                AT_Bookings_Logger::error("[Initial Sync] Cycle $tour_id sync failed: " . ($result['message'] ?? 'Unknown error'));
            }
            
            return [
                'id' => $tour_id,
                'tour_id' => $tour_id,
                'success' => $result['success'],
                'message' => $result['message'] ?? '',
                'zoho_id' => $result['zoho_id'] ?? null,
            ];
            
        } catch (Exception $e) {
            $error_msg = $e->getMessage();
            AT_Bookings_Logger::error("[Initial Sync] Exception syncing cycle $tour_id: $error_msg");
            return [
                'id' => $tour_id,
                'tour_id' => $tour_id,
                'success' => false,
                'message' => $error_msg,
                'zoho_id' => null,
            ];
        }
    }
    
    /**
     * Sync batch of orders (uses existing AT_Zoho_Sync_Service::sync_order)
     *
     * @param array $orders WC_Order objects
     * @return array Results
     */
    public function sync_orders_batch($orders) {
        $results = [
            'success_count' => 0,
            'error_count' => 0,
            'records' => [],
        ];
        
        foreach ($orders as $order) {
            if ($this->is_stopped()) {
                break;
            }
            
            $order_id = $order->get_id();
            $order_number = $order->get_order_number();
            
            // Skip if already synced in insert-only mode
            if ($this->insert_only_mode) {
                $zoho_sales_order_id = get_post_meta($order_id, '_zoho_sales_order_id', true);
                $zoho_lead_id = get_post_meta($order_id, '_zoho_lead_id', true);
                
                if (!empty($zoho_sales_order_id) || !empty($zoho_lead_id)) {
                    $zoho_id = $zoho_sales_order_id ?: $zoho_lead_id;
                    AT_Bookings_Logger::debug("[Initial Sync] Order #$order_id has Zoho ID: $zoho_id, skipping (insert-only mode)");
                    $results['records'][] = [
                        'id' => $order_id,
                        'order_number' => $order_number,
                        'success' => true,
                        'message' => __('Already synced to Zoho (skipped in insert-only mode)', 'at-bookings-api-fixes'),
                        'zoho_id' => $zoho_id,
                    ];
                    continue;
                }
            }
            
            AT_Bookings_Logger::debug("[Initial Sync] Syncing order #$order_id ($order_number)");
            
            try {
                // Use AT_Zoho_Sync_Service::sync_order (includes contact, products, cycles, and order record)
                $result = $this->sync_service->sync_order($order_id, 'initial_sync');
                
                if ($result['success']) {
                    $results['success_count']++;
                    AT_Bookings_Logger::info("[Initial Sync] Order #$order_id synced successfully. Zoho ID: " . ($result['zoho_id'] ?? 'N/A'));
                } else {
                    $results['error_count']++;
                    AT_Bookings_Logger::error("[Initial Sync] Order #$order_id sync failed: " . ($result['message'] ?? 'Unknown error'));
                }
                
                $results['records'][] = [
                    'id' => $order_id,
                    'order_number' => $order_number,
                    'success' => $result['success'],
                    'message' => $result['message'] ?? '',
                    'zoho_id' => $result['zoho_id'] ?? null,
                ];
                
            } catch (Exception $e) {
                $results['error_count']++;
                $error_msg = $e->getMessage();
                AT_Bookings_Logger::error("[Initial Sync] Exception syncing order #$order_id: $error_msg");
                
                $results['records'][] = [
                    'id' => $order_id,
                    'order_number' => $order_number,
                    'success' => false,
                    'message' => $error_msg,
                    'zoho_id' => null,
                ];
            }
            
            $this->batch_processed++;
        }
        
        return $results;
    }
    
    /**
     * Get sync state for a product
     *
     * @param int $product_id Product ID
     * @return array Sync state
     */
    public function get_sync_state($product_id) {
        $state = get_post_meta($product_id, self::SYNC_STATE_META_KEY, true);
        return $state ? json_decode($state, true) : [];
    }
    
    /**
     * Update sync state for a product
     *
     * @param int $product_id Product ID
     * @param array $state State data
     */
    public function update_sync_state($product_id, $state) {
        $current_state = $this->get_sync_state($product_id);
        $merged_state = array_merge($current_state, $state);
        update_post_meta($product_id, self::SYNC_STATE_META_KEY, json_encode($merged_state));
    }
    
    /**
     * Set stop flag to halt sync
     */
    public function set_stop_flag() {
        set_transient($this->stop_flag_key, true, 300); // 5 minutes
    }
    
    /**
     * Clear stop flag
     */
    public function clear_stop_flag() {
        delete_transient($this->stop_flag_key);
    }
    
    /**
     * Check if sync is stopped
     *
     * @return bool
     */
    public function is_stopped() {
        return (bool) get_transient($this->stop_flag_key);
    }
    
    /**
     * Get batch processed count
     *
     * @return int
     */
    public function get_batch_processed() {
        return $this->batch_processed;
    }
}

