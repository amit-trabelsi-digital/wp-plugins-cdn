<?php
/**
 * Slots Sync Manager
 * 
 * Links bookings to slots and maintains booking counts
 * 
 * @package AT_Bookings_API_Fixes
 * @subpackage Slots
 * @since 3.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Bookings_Slots_Sync {
    
    /**
     * Initialize sync hooks
     */
    public static function init() {
        // Hook into order status changes
        add_action('woocommerce_order_status_changed', array(__CLASS__, 'handle_order_status_change'), 10, 3);
        
        // Hook into booking status changes
        add_action('woocommerce_booking_confirmed', array(__CLASS__, 'handle_booking_confirmed'));
        add_action('woocommerce_booking_cancelled', array(__CLASS__, 'handle_booking_cancelled'));
        
        // Hook into order creation/update
        add_action('woocommerce_new_order', array(__CLASS__, 'handle_new_order'));
        add_action('woocommerce_update_order', array(__CLASS__, 'handle_order_update'));
    }
    
    /**
     * Handle order status changes
     * 
     * @param int $order_id Order ID
     * @param string $old_status Old status
     * @param string $new_status New status
     */
    public static function handle_order_status_change($order_id, $old_status, $new_status) {
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }
        
        // Update slot booking status based on order status
        $slot_status = self::map_order_status_to_slot_status($new_status);
        self::update_order_slot_status($order_id, $slot_status);
        
        // If order becomes paid, update slot counts
        if (in_array($new_status, ['processing', 'completed']) && !in_array($old_status, ['processing', 'completed'])) {
            self::sync_order_to_slots($order);
        }
    }
    
    /**
     * Handle booking confirmation
     * 
     * @param int $booking_id Booking ID
     */
    public static function handle_booking_confirmed($booking_id) {
        $booking = get_wc_booking($booking_id);
        if (!$booking) {
            return;
        }
        
        $order = $booking->get_order();
        if ($order) {
            self::sync_order_to_slots($order);
        }
    }
    
    /**
     * Handle booking cancellation
     * 
     * @param int $booking_id Booking ID
     */
    public static function handle_booking_cancelled($booking_id) {
        $booking = get_wc_booking($booking_id);
        if (!$booking) {
            return;
        }
        
        $order = $booking->get_order();
        if ($order) {
            self::update_order_slot_status($order->get_id(), 'cancelled');
        }
    }
    
    /**
     * Handle new order
     * 
     * @param int $order_id Order ID
     */
    public static function handle_new_order($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }
        
        self::sync_order_to_slots($order);
    }
    
    /**
     * Handle order update
     * 
     * @param int $order_id Order ID
     */
    public static function handle_order_update($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }
        
        self::sync_order_to_slots($order);
    }
    
    /**
     * Sync order to slots table
     * 
     * @param WC_Order $order Order object
     * @return array Result with success status
     */
    public static function sync_order_to_slots($order) {
        global $wpdb;
        
        $order_id = $order->get_id();
        $results = [];
        
        try {
            foreach ($order->get_items() as $item) {
                $product = $item->get_product();
                if (!$product || $product->get_type() !== 'booking') {
                    continue;
                }
                
                $booking_id = $item->get_meta('_booking_id');
                if (!$booking_id) {
                    continue;
                }
                
                $booking = get_wc_booking($booking_id);
                if (!$booking) {
                    continue;
                }
                
                // Get booking start time
                $booking_start = $booking->get_start_date();
                if (!$booking_start) {
                    continue;
                }
                
                // Convert to DateTime object
                $slot_start = new DateTime($booking_start, new DateTimeZone('UTC'));
                
                // Link to slot
                $link_result = AT_Bookings_Slots_Manager::link_booking_to_slot(
                    $order_id,
                    $product->get_id(),
                    $slot_start,
                    $booking_id
                );
                
                $results[] = $link_result;
                
                // Parse ticket types
                $ticket_types = self::parse_order_item_ticket_types($item);
                $participants = array_sum($ticket_types);
                
                // Update slot booking record with ticket details
                if ($link_result['success'] && isset($link_result['slot_id'])) {
                    self::update_slot_booking_details($link_result['slot_id'], $order_id, $booking_id, $participants, $ticket_types);
                }
            }
            
            return [
                'success' => true,
                'results' => $results,
                'message' => sprintf('Processed %d booking items', count($results))
            ];
            
        } catch (Exception $e) {
            error_log('AT Bookings: Slots sync error - ' . $e->getMessage());
            return [
                'success' => false,
                'message' => $e->getMessage()
            ];
        }
    }
    
    /**
     * Update slot booking details
     * 
     * @param int $slot_id Slot ID
     * @param int $order_id Order ID
     * @param int $booking_id Booking ID
     * @param int $participants Participant count
     * @param array $ticket_types Ticket types breakdown
     */
    private static function update_slot_booking_details($slot_id, $order_id, $booking_id, $participants, $ticket_types) {
        global $wpdb;
        
        $slot_bookings_table = $wpdb->prefix . 'at_slot_bookings';
        
        $wpdb->update(
            $slot_bookings_table,
            [
                'participants' => $participants,
                'ticket_types' => json_encode($ticket_types),
                'status' => 'confirmed'
            ],
            [
                'slot_id' => $slot_id,
                'order_id' => $order_id,
                'booking_id' => $booking_id
            ],
            ['%d', '%s', '%s'],
            ['%d', '%d', '%d']
        );
    }
    
    /**
     * Parse ticket types from order item
     * 
     * @param WC_Order_Item $item Order item
     * @return array Ticket types with counts
     */
    private static function parse_order_item_ticket_types($item) {
        $types = [];
        
        // Get all meta data
        $meta_data = $item->get_meta_data();
        
        foreach ($meta_data as $meta) {
            $key = $meta->get_data()['key'];
            $value = $meta->get_data()['value'];
            
            // Look for person type fields
            if (preg_match('/persons?_(\w+)/i', $key, $matches)) {
                $person_type = strtolower($matches[1]);
                $types[$person_type] = (int) $value;
            }
            // Also check for direct adult/child fields
            elseif (in_array(strtolower($key), ['adult', 'adults', 'child', 'children', 'kids'])) {
                $types[strtolower($key)] = (int) $value;
            }
        }
        
        // If no specific types found, assume all are adults
        if (empty($types)) {
            $types['adult'] = $item->get_quantity();
        }
        
        return $types;
    }
    
    /**
     * Map order status to slot booking status
     * 
     * @param string $order_status WooCommerce order status
     * @return string Slot booking status
     */
    private static function map_order_status_to_slot_status($order_status) {
        $status_map = [
            'pending' => 'pending',
            'processing' => 'confirmed',
            'on-hold' => 'pending',
            'completed' => 'completed',
            'cancelled' => 'cancelled',
            'refunded' => 'cancelled',
            'failed' => 'cancelled'
        ];
        
        return $status_map[$order_status] ?? 'pending';
    }
    
    /**
     * Update slot booking status for an order
     * 
     * @param int $order_id Order ID
     * @param string $status New status
     */
    private static function update_order_slot_status($order_id, $status) {
        global $wpdb;
        
        $slot_bookings_table = $wpdb->prefix . 'at_slot_bookings';
        
        $wpdb->update(
            $slot_bookings_table,
            ['status' => $status],
            ['order_id' => $order_id],
            ['%s'],
            ['%d']
        );
        
        // Update slot counts for all affected slots
        $affected_slots = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT DISTINCT slot_id FROM {$slot_bookings_table} WHERE order_id = %d",
                $order_id
            )
        );
        
        foreach ($affected_slots as $slot_id) {
            AT_Bookings_Slots_Manager::update_slot_bookings_count($slot_id);
        }
    }
    
    /**
     * Get slot data for order
     * 
     * @param int $order_id Order ID
     * @return array Slot data or empty array
     */
    public static function get_order_slot_data($order_id) {
        global $wpdb;
        
        $slots_table = $wpdb->prefix . 'at_booking_slots';
        $slot_bookings_table = $wpdb->prefix . 'at_slot_bookings';
        
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT s.*, sb.participants, sb.ticket_types, sb.status as booking_status
                FROM {$slots_table} s
                JOIN {$slot_bookings_table} sb ON s.id = sb.slot_id
                WHERE sb.order_id = %d",
                $order_id
            ),
            ARRAY_A
        );
    }
    
    /**
     * Get booking data for slot
     * 
     * @param int $slot_id Slot ID
     * @return array Booking data
     */
    public static function get_slot_booking_data($slot_id) {
        global $wpdb;
        
        $slot_bookings_table = $wpdb->prefix . 'at_slot_bookings';
        
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT sb.*, o.post_status as order_status
                FROM {$slot_bookings_table} sb
                JOIN {$wpdb->posts} o ON sb.order_id = o.ID
                WHERE sb.slot_id = %d
                AND o.post_type = 'shop_order'",
                $slot_id
            ),
            ARRAY_A
        );
    }
    
    /**
     * Calculate revenue for slot
     * 
     * @param int $slot_id Slot ID
     * @return float Total revenue
     */
    public static function calculate_slot_revenue($slot_id) {
        global $wpdb;
        
        $slot_bookings_table = $wpdb->prefix . 'at_slot_bookings';
        
        $total = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT SUM(pm.meta_value)
                FROM {$slot_bookings_table} sb
                JOIN {$wpdb->postmeta} pm ON sb.order_id = pm.post_id
                WHERE sb.slot_id = %d
                AND pm.meta_key = '_order_total'
                AND sb.status IN ('confirmed', 'paid', 'completed')",
                $slot_id
            )
        );
        
        return (float) $total ?: 0.0;
    }
}

// Initialize slots sync
AT_Bookings_Slots_Sync::init();
