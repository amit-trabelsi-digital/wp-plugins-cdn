<?php
/**
 * WordPress Hooks for Slots Management
 * 
 * Handles automatic slot regeneration and updates based on product/booking changes
 * 
 * @package AT_Bookings_API_Fixes
 * @subpackage Slots
 * @since 3.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Bookings_Slots_Hooks {
    
    /**
     * Initialize hooks
     */
    public static function init() {
        // Product save/update hooks
        add_action('woocommerce_process_product_meta', array(__CLASS__, 'handle_product_save'), 20);
        add_action('woocommerce_update_product', array(__CLASS__, 'handle_product_update'));
        
        // Booking rules changes
        add_action('save_post', array(__CLASS__, 'handle_booking_rule_save'));
        
        // ACF field updates (for tour city, duration, etc.)
        add_action('acf/save_post', array(__CLASS__, 'handle_acf_save'), 20);
        
        // Admin action for manual slot regeneration
        add_action('wp_ajax_at_regenerate_slots', array(__CLASS__, 'ajax_regenerate_slots'));
    }
    
    /**
     * Handle product save
     * 
     * @param int $product_id Product ID
     */
    public static function handle_product_save($product_id) {
        $product = wc_get_product($product_id);
        
        if ($product && $product->get_type() === 'booking') {
            self::regenerate_product_slots($product_id);
        }
    }
    
    /**
     * Handle product update
     * 
     * @param int $product_id Product ID
     */
    public static function handle_product_update($product_id) {
        self::handle_product_save($product_id);
    }
    
    /**
     * Handle booking rule save
     * 
     * @param int $post_id Post ID
     */
    public static function handle_booking_rule_save($post_id) {
        $post = get_post($post_id);
        
        if ($post && $post->post_type === 'wc_booking_rule') {
            $product_id = $post->post_parent;
            if ($product_id) {
                self::regenerate_product_slots($product_id);
            }
        }
    }
    
    /**
     * Handle ACF field save
     * 
     * @param int $post_id Post ID
     */
    public static function handle_acf_save($post_id) {
        // Check if this is a product
        if (get_post_type($post_id) === 'product') {
            $product = wc_get_product($post_id);
            if ($product && $product->get_type() === 'booking') {
                self::regenerate_product_slots($post_id);
            }
        }
    }
    
    /**
     * Regenerate slots for a product
     * 
     * @param int $product_id Product ID
     * @return array Result
     */
    private static function regenerate_product_slots($product_id) {
        // Prevent infinite loops during bulk operations
        if (wp_cache_get('at_regenerating_slots_' . $product_id)) {
            return ['success' => false, 'message' => 'Already regenerating'];
        }
        
        wp_cache_set('at_regenerating_slots_' . $product_id, true, '', 300); // 5 minutes
        
        try {
            // Clear existing future slots for this product (keep past slots with bookings)
            self::clear_future_slots($product_id);
            
            // Generate new slots
            $result = AT_Bookings_Slots_Manager::generate_slots_for_product($product_id);
            
            wp_cache_delete('at_regenerating_slots_' . $product_id);
            
            return $result;
            
        } catch (Exception $e) {
            wp_cache_delete('at_regenerating_slots_' . $product_id);
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    /**
     * Clear future slots (keep past slots with bookings)
     * 
     * @param int $product_id Product ID
     */
    private static function clear_future_slots($product_id) {
        global $wpdb;
        
        $slots_table = $wpdb->prefix . 'at_booking_slots';
        $slot_bookings_table = $wpdb->prefix . 'at_slot_bookings';
        
        // Get slots to delete (future slots without bookings)
        $slots_to_delete = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT s.id FROM {$slots_table} s
                LEFT JOIN {$slot_bookings_table} sb ON s.id = sb.slot_id
                WHERE s.product_id = %d
                AND s.slot_start > NOW()
                AND sb.id IS NULL",
                $product_id
            )
        );
        
        if (!empty($slots_to_delete)) {
            $placeholders = implode(',', array_fill(0, count($slots_to_delete), '%d'));
            
            $wpdb->query(
                $wpdb->prepare(
                    "DELETE FROM {$slots_table} WHERE id IN ({$placeholders})",
                    ...$slots_to_delete
                )
            );
        }
        
        // Mark future slots with bookings as 'closed' instead of deleting
        $wpdb->update(
            $slots_table,
            ['status' => 'closed'],
            [
                'product_id' => $product_id,
                'slot_start' => ['>', current_time('mysql')]
            ],
            ['%s'],
            ['%d', '%s']
        );
    }
    
    /**
     * AJAX handler for manual slot regeneration
     */
    public static function ajax_regenerate_slots() {
        check_ajax_referer('at_regenerate_slots', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(__('Insufficient permissions', 'at-bookings-api-fixes'));
        }
        
        $product_id = (int) ($_POST['product_id'] ?? 0);
        
        if (!$product_id) {
            wp_send_json_error(__('Missing product ID', 'at-bookings-api-fixes'));
        }
        
        $result = self::regenerate_product_slots($product_id);
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result['message']);
        }
    }
    
    /**
     * Bulk regenerate all booking product slots
     * 
     * @param int $limit Maximum products to process (default 10)
     * @return array Result with processed count
     */
    public static function bulk_regenerate_slots($limit = 10) {
        global $wpdb;
        
        // Get booking products
        $product_ids = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT p.ID FROM {$wpdb->posts} p
                JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
                WHERE p.post_type = 'product'
                AND p.post_status = 'publish'
                AND pm.meta_key = '_virtual'
                AND pm.meta_value = 'yes'
                LIMIT %d",
                $limit
            )
        );
        
        $processed = 0;
        $errors = [];
        
        foreach ($product_ids as $product_id) {
            $result = self::regenerate_product_slots($product_id);
            
            if ($result['success']) {
                $processed++;
            } else {
                $errors[] = "Product {$product_id}: " . $result['message'];
            }
        }
        
        return [
            'success' => true,
            'processed' => $processed,
            'total' => count($product_ids),
            'errors' => $errors
        ];
    }
}

// Initialize hooks
AT_Bookings_Slots_Hooks::init();
