<?php
/**
 * Slots Manager
 * 
 * Manages generation and maintenance of booking slots from WooCommerce Bookings rules
 * 
 * @package AT_Bookings_API_Fixes
 * @subpackage Slots
 * @since 3.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Bookings_Slots_Manager {
    
    /**
     * Generate slots for a product
     * 
     * @param int $product_id Product ID
     * @param int $days_ahead Number of days to generate slots for (default 180)
     * @return array Array of generated slots with status
     */
    public static function generate_slots_for_product($product_id, $days_ahead = 180) {
        global $wpdb;
        
        $product_id = (int) $product_id;
        if ($product_id <= 0) {
            return ['success' => false, 'message' => 'Invalid product ID'];
        }
        
        $product = wc_get_product($product_id);
        if (!$product || $product->get_type() !== 'booking') {
            return ['success' => false, 'message' => 'Product is not a booking product'];
        }
        
        $generated = 0;
        $updated = 0;
        $errors = [];
        
        try {
            // Get WC Bookings availability rules
            $rules = self::get_booking_rules($product_id);
            if (empty($rules)) {
                return ['success' => false, 'message' => 'No booking rules defined for this product'];
            }
            
            // Generate slots for the next N days
            $start_date = new DateTime('now', new DateTimeZone('UTC'));
            $end_date = new DateTime("+{$days_ahead} days", new DateTimeZone('UTC'));
            
            $current_date = clone $start_date;
            
            while ($current_date < $end_date) {
                $day_of_week = (int) $current_date->format('w'); // 0 = Sunday, 1 = Monday, etc.
                
                // Find applicable rules for this day
                foreach ($rules as $rule) {
                    if (self::rule_applies_to_date($rule, $current_date)) {
                        // Create slots based on rule
                        $slot_results = self::create_slots_from_rule($product_id, $current_date, $rule);
                        $generated += $slot_results['generated'];
                        $updated += $slot_results['updated'];
                        
                        if (!empty($slot_results['errors'])) {
                            $errors = array_merge($errors, $slot_results['errors']);
                        }
                    }
                }
                
                $current_date->modify('+1 day');
            }
            
            return [
                'success' => true,
                'generated' => $generated,
                'updated' => $updated,
                'errors' => $errors,
                'message' => sprintf('Generated %d slots, updated %d slots', $generated, $updated)
            ];
            
        } catch (Exception $e) {
            error_log('AT Bookings: Slots generation error - ' . $e->getMessage());
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
    
    /**
     * Get WC Bookings rules for a product
     * 
     * @param int $product_id Product ID
     * @return array Array of booking rules
     */
    private static function get_booking_rules($product_id) {
        global $wpdb;
        
        // Query booking availability rules from WC Bookings
        $rules = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->posts} 
                WHERE post_parent = %d 
                AND post_type = 'wc_booking_rule'
                AND post_status = 'publish'",
                $product_id
            ),
            ARRAY_A
        );
        
        $formatted_rules = [];
        foreach ($rules as $rule) {
            $rule_data = [
                'id' => $rule['ID'],
                'title' => $rule['post_title'],
                'priority' => get_post_meta($rule['ID'], '_priority', true),
                'type' => get_post_meta($rule['ID'], '_type', true),
                'block' => get_post_meta($rule['ID'], '_block', true),
                'bookable' => get_post_meta($rule['ID'], '_bookable', true),
                'min_date' => get_post_meta($rule['ID'], '_min_date', true),
                'max_date' => get_post_meta($rule['ID'], '_max_date', true),
                'applying_blocks' => get_post_meta($rule['ID'], '_applying_blocks', true) ?: [],
            ];
            $formatted_rules[] = $rule_data;
        }
        
        // Sort by priority (lowest first)
        usort($formatted_rules, function($a, $b) {
            return (int) $a['priority'] - (int) $b['priority'];
        });
        
        return $formatted_rules;
    }
    
    /**
     * Check if a rule applies to a specific date
     * 
     * @param array $rule Rule data
     * @param DateTime $date Date to check
     * @return bool
     */
    private static function rule_applies_to_date($rule, $date) {
        // Check if rule type is daily (applies to specific time range each day)
        if ($rule['type'] === 'time_range' && $rule['block']) {
            return true;
        }
        
        // Check date range
        if ($rule['min_date']) {
            $min_date = new DateTime($rule['min_date'], new DateTimeZone('UTC'));
            if ($date < $min_date) {
                return false;
            }
        }
        
        if ($rule['max_date']) {
            $max_date = new DateTime($rule['max_date'], new DateTimeZone('UTC'));
            if ($date > $max_date) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Create slots from a rule
     * 
     * @param int $product_id Product ID
     * @param DateTime $date Date for slots
     * @param array $rule Rule data
     * @return array Array with generated and updated counts
     */
    private static function create_slots_from_rule($product_id, $date, $rule) {
        global $wpdb;
        
        $generated = 0;
        $updated = 0;
        $errors = [];
        
        try {
            // Get product for capacity info
            $product = wc_get_product($product_id);
            $max_capacity = (int) get_post_meta($product_id, '_wc_booking_qty', true) ?: 1;
            
            // Get tour city and duration from ACF fields
            $tour_city = get_field('TOUR_CITY', 'product_' . $product_id) ?: '';
            $tour_duration = get_field('TOUR_DURATION', 'product_' . $product_id) ?: 0;
            
            // Create slot for this time block
            $slot_start = clone $date;
            $slot_start->setTime(intval($rule['block']['from'] ?? '09'), intval($rule['block']['from_minutes'] ?? '0'));
            
            $slot_end = clone $date;
            $slot_end->setTime(intval($rule['block']['to'] ?? '17'), intval($rule['block']['to_minutes'] ?? '0'));
            
            // Generate tour_id as product_id_utc_timestamp
            $tour_id = $product_id . '_' . $slot_start->format('U');
            
            $slots_table = $wpdb->prefix . 'at_booking_slots';
            
            // Check if slot already exists
            $existing = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT id FROM {$slots_table} WHERE tour_id = %s",
                    $tour_id
                )
            );
            
            if ($existing) {
                // Update existing slot
                $wpdb->update(
                    $slots_table,
                    [
                        'max_capacity' => $max_capacity,
                        'slot_start' => $slot_start->format('Y-m-d H:i:s'),
                        'slot_end' => $slot_end->format('Y-m-d H:i:s'),
                    ],
                    ['id' => $existing->id],
                    ['%d', '%s', '%s'],
                    ['%d']
                );
                $updated++;
            } else {
                // Insert new slot
                $wpdb->insert(
                    $slots_table,
                    [
                        'product_id' => $product_id,
                        'slot_start' => $slot_start->format('Y-m-d H:i:s'),
                        'slot_end' => $slot_end->format('Y-m-d H:i:s'),
                        'tour_id' => $tour_id,
                        'max_capacity' => $max_capacity,
                        'current_bookings' => 0,
                        'status' => 'active',
                    ],
                    ['%d', '%s', '%s', '%s', '%d', '%d', '%s']
                );
                
                if ($wpdb->last_error) {
                    $errors[] = 'Error inserting slot: ' . $wpdb->last_error;
                } else {
                    $generated++;
                }
            }
            
        } catch (Exception $e) {
            $errors[] = 'Exception: ' . $e->getMessage();
        }
        
        return [
            'generated' => $generated,
            'updated' => $updated,
            'errors' => $errors
        ];
    }
    
    /**
     * Update slot bookings count
     * 
     * @param int $slot_id Slot ID
     * @return int Updated booking count
     */
    public static function update_slot_bookings_count($slot_id) {
        global $wpdb;
        
        $slot_id = (int) $slot_id;
        $slots_table = $wpdb->prefix . 'at_booking_slots';
        $bookings_table = $wpdb->prefix . 'at_slot_bookings';
        
        // Count paid bookings for this slot
        $booking_count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$bookings_table} 
                WHERE slot_id = %d 
                AND status IN ('confirmed', 'paid', 'completed')",
                $slot_id
            )
        );
        
        $booking_count = (int) $booking_count;
        
        // Update slot with new count
        $wpdb->update(
            $slots_table,
            ['current_bookings' => $booking_count],
            ['id' => $slot_id],
            ['%d'],
            ['%d']
        );
        
        // Update status if slot is full
        $slot = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT max_capacity, current_bookings FROM {$slots_table} WHERE id = %d",
                $slot_id
            )
        );
        
        if ($slot && $slot->current_bookings >= $slot->max_capacity) {
            $wpdb->update(
                $slots_table,
                ['status' => 'full'],
                ['id' => $slot_id],
                ['%s'],
                ['%d']
            );
        } elseif ($slot && $slot->max_capacity > 0 && $slot->current_bookings < $slot->max_capacity) {
            $wpdb->update(
                $slots_table,
                ['status' => 'active'],
                ['id' => $slot_id],
                ['%s'],
                ['%d']
            );
        }
        
        return $booking_count;
    }
    
    /**
     * Link booking to slot
     * 
     * @param int $order_id Order ID
     * @param int $booking_id Booking ID (optional)
     * @param int $product_id Product ID
     * @param DateTime $slot_start Slot start time
     * @return array Result array with success status
     */
    public static function link_booking_to_slot($order_id, $product_id, $slot_start, $booking_id = 0) {
        global $wpdb;
        
        $order_id = (int) $order_id;
        $product_id = (int) $product_id;
        $booking_id = (int) $booking_id;
        
        try {
            // Find matching slot
            $tour_id = $product_id . '_' . $slot_start->format('U');
            
            $slots_table = $wpdb->prefix . 'at_booking_slots';
            $bookings_table = $wpdb->prefix . 'at_slot_bookings';
            
            $slot = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT id FROM {$slots_table} WHERE tour_id = %s",
                    $tour_id
                )
            );
            
            if (!$slot) {
                return ['success' => false, 'message' => 'Slot not found'];
            }
            
            // Check if booking already linked
            $existing = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT id FROM {$bookings_table} 
                    WHERE slot_id = %d AND order_id = %d",
                    $slot->id,
                    $order_id
                )
            );
            
            if ($existing) {
                return ['success' => true, 'message' => 'Booking already linked', 'slot_id' => $slot->id];
            }
            
            // Insert new booking link
            $result = $wpdb->insert(
                $bookings_table,
                [
                    'slot_id' => $slot->id,
                    'order_id' => $order_id,
                    'booking_id' => $booking_id ?: null,
                    'status' => 'pending',
                ],
                ['%d', '%d', $booking_id ? '%d' : null, '%s']
            );
            
            if ($result === false) {
                return ['success' => false, 'message' => $wpdb->last_error];
            }
            
            // Update slot booking counts
            self::update_slot_bookings_count($slot->id);
            
            return ['success' => true, 'message' => 'Booking linked successfully', 'slot_id' => $slot->id];
            
        } catch (Exception $e) {
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
}
