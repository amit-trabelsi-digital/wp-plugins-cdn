-- AT Bookings API Fixes - Database Cleanup Script
-- מומלץ לביצוע לניקוי נתונים מיותרים במסד הנתונים
-- 
-- הערה: הסקריפט בטוח לביצוע ולא ימחק נתונים קריטיים
-- Date: 2025-01-15
-- Version: 3.0.0

-- ===================================
-- חלק 1: ניקוי Options מיותרות
-- ===================================

-- ניקוי נתוני ביצועים ישנים שאוגרים מקום (6KB)
-- מכיל 31 רשומות של טעינות עמודים איטיות מחודשים קודמים
DELETE FROM qtx_options WHERE option_name = 'at_slow_page_loads';

-- הסרת דגל יצירת טבלאות (מיותר לאחר יצירה מוצלחת)
DELETE FROM qtx_options WHERE option_name = 'at_booking_tables_created';

-- הסרת הגדרות ZOHO ריקות
DELETE FROM qtx_options WHERE option_name = 'zoho_campaigns_credentials' AND option_value = '';

-- ===================================
-- חלק 2: ניקוי Transients מיותרים
-- ===================================

-- ניקוי השוואת מודולים ישנה של התוסף
DELETE FROM qtx_options WHERE option_name LIKE '_transient_at_modules_comparison%';
DELETE FROM qtx_options WHERE option_name LIKE '_transient_timeout_at_modules_comparison%';

-- ===================================
-- חלק 3: ניקוי WooCommerce Transients (אופציונלי)
-- ===================================

-- הסרת מוצרים קשורים cached (יתחדש אוטומטית)
DELETE FROM qtx_options WHERE 
    option_name LIKE '_transient_wc_related_%' OR 
    option_name LIKE '_transient_timeout_wc_related_%';

-- הסרת דוחות WooCommerce ישנים (יתחדש לפי הצורך)
DELETE FROM qtx_options WHERE 
    option_name LIKE '_transient_wc_report_%' OR 
    option_name LIKE '_transient_timeout_wc_report_%';

-- ===================================
-- חלק 4: בדיקת תוצאות הניקוי
-- ===================================

-- הצגת סטטיסטיקות לאחר הניקוי
SELECT 
    'AT Plugin Options' as category,
    COUNT(*) as remaining_count
FROM qtx_options 
WHERE option_name LIKE 'at_%'

UNION ALL

SELECT 
    'ZOHO Options' as category,
    COUNT(*) as remaining_count
FROM qtx_options 
WHERE option_name LIKE '%zoho%'

UNION ALL

SELECT 
    'AT Transients' as category,
    COUNT(*) as remaining_count
FROM qtx_options 
WHERE option_name LIKE '_transient%at_%'

UNION ALL

SELECT 
    'Total Options' as category,
    COUNT(*) as remaining_count
FROM qtx_options;

-- ===================================
-- חלק 5: בדיקת גודל מסד נתונים
-- ===================================

-- הצגת גודל טבלת options לאחר הניקוי
SELECT 
    'qtx_options' as table_name,
    ROUND(((data_length + index_length) / 1024 / 1024), 2) AS "Size (MB)"
FROM information_schema.TABLES 
WHERE table_schema = DATABASE() 
AND table_name = 'qtx_options';

-- ===================================
-- הערות לביצוע:
-- ===================================
-- 1. גבה את מסד הנתונים לפני הביצוע
-- 2. הסקריפט בטוח ולא ימחק נתונים קריטיים
-- 3. הטבלאות החדשות (qtx_at_booking_slots, qtx_at_slot_bookings) נשמרות לשימוש עתידי
-- 4. אפשר להריץ חלקים ספציפיים בלבד
-- 5. לאחר הביצוע מומלץ לבדוק שהאתר עובד תקין

-- סיום הסקריפט