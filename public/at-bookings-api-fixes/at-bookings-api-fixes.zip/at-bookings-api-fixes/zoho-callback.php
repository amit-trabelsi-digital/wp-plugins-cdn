<?php
/**
 * ZOHO OAuth Callback Handler
 * This file receives the authorization code from ZOHO
 */

// Load WordPress
// בסביבת Docker, הנתיב הוא /var/www/html/wp-load.php
if (!defined('ABSPATH')) {
    // Try to find wp-load.php - support both local and Docker environments
    $wp_load_paths = array(
        '/var/www/html/wp-load.php',  // Docker
        dirname(__FILE__) . '/../../../../wp-load.php',  // מתיקיית התוסף
        dirname(__FILE__) . '/../../../../../wp-load.php',  // גיבוי
        dirname(dirname(dirname(dirname(__FILE__)))) . '/wp-load.php',  // מתיקיית wp-content
    );
    
    $wp_loaded = false;
    foreach ($wp_load_paths as $path) {
        if (file_exists($path)) {
            require_once($path);
            $wp_loaded = true;
            break;
        }
    }
    
    if (!$wp_loaded) {
        // Show debug info
        echo '<h3>Debug Info:</h3>';
        echo '<pre>';
        echo 'Current file: ' . __FILE__ . "\n";
        echo 'Current dir: ' . dirname(__FILE__) . "\n";
        echo "\nTried paths:\n";
        foreach ($wp_load_paths as $path) {
            echo "- $path: " . (file_exists($path) ? 'EXISTS' : 'NOT FOUND') . "\n";
        }
        echo '</pre>';
        die('WordPress not found. Please check paths above.');
    }
}

// בדיקת הרשאות - רק אם המשתמש מחובר
// אם לא מחובר, הדף עדיין יציג את הקוד אבל יבקש התחברות
$is_admin = is_user_logged_in() && current_user_can('manage_options');

// Get the authorization code from URL
$code = isset($_GET['code']) ? sanitize_text_field($_GET['code']) : '';
$error = isset($_GET['error']) ? sanitize_text_field($_GET['error']) : '';
$error_description = isset($_GET['error_description']) ? sanitize_text_field($_GET['error_description']) : '';

// Auto-convert authorization code to refresh token
$refresh_token = '';
$access_token = '';
$conversion_error = '';
$token_expires_in = 0;

if ($code && !$error && class_exists('AT_Zoho_CRM')) {
    try {
        $settings = AT_Zoho_CRM::get_settings();
        
        if (!empty($settings['client_id']) && !empty($settings['client_secret'])) {
            // Convert authorization code to tokens - use same redirect_uri as authorization
            // $plugin_url = plugins_url('at-bookings-api-fixes');
            // $redirect_uri = $plugin_url . '/zoho-callback.php';
            $redirect_uri = admin_url('admin-post.php?action=at_zoho_oauth_callback');
            
            // Get accounts domain from centralized function (MUST match the authorization request!)
            $accounts_domain = AT_Zoho_CRM::get_accounts_domain($settings['domain']);
            $token_url = "https://{$accounts_domain}/oauth/v2/token";
            
            if (function_exists('write_detailed_log')) {
                write_detailed_log('ZOHO Callback: Converting auth code to tokens', 'DEBUG');
                write_detailed_log('ZOHO Callback: Using accounts server: ' . $accounts_domain, 'DEBUG');
                write_detailed_log('ZOHO Callback: Token URL: ' . $token_url, 'DEBUG');
                write_detailed_log('ZOHO Callback: Redirect URI: ' . $redirect_uri, 'DEBUG');
                write_detailed_log('ZOHO Callback: Code length: ' . strlen($code), 'DEBUG');
            }
            
            $response = wp_remote_post($token_url, array(
                'body' => array(
                    'grant_type' => 'authorization_code',
                    'client_id' => $settings['client_id'],
                    'client_secret' => $settings['client_secret'],
                    'redirect_uri' => $redirect_uri,
                    'code' => $code
                ),
                'timeout' => 30
            ));
            
            if (!is_wp_error($response)) {
                $body = wp_remote_retrieve_body($response);
                $data = json_decode($body, true);
                
                if (!empty($data['refresh_token'])) {
                    $refresh_token = $data['refresh_token'];
                    $access_token = $data['access_token'] ?? '';
                    $token_expires_in = $data['expires_in'] ?? 3600;
                    
                    if (function_exists('write_detailed_log')) {
                        write_detailed_log('ZOHO Callback: Received refresh_token: ' . substr($refresh_token, 0, 30) . '...', 'INFO');
                        write_detailed_log('ZOHO Callback: Received access_token: ' . substr($access_token, 0, 30) . '...', 'INFO');
                    }
                    
                    // Auto-save if user is logged in as admin
                    if ($is_admin) {
                        $saved_refresh = update_option(AT_Zoho_CRM::OPTION_REFRESH_TOKEN, $refresh_token);
                        $saved_access = update_option(AT_Zoho_CRM::OPTION_ACCESS_TOKEN, $access_token);
                        $saved_expires = update_option(AT_Zoho_CRM::OPTION_TOKEN_EXPIRES, time() + $token_expires_in);
                        
                        if (function_exists('write_detailed_log')) {
                            write_detailed_log('ZOHO: Refresh token auto-saved from callback - Success: ' . ($saved_refresh ? 'YES' : 'NO'), 'INFO');
                            write_detailed_log('ZOHO: Access token saved: ' . ($saved_access ? 'YES' : 'NO'), 'INFO');
                            write_detailed_log('ZOHO: Token expires saved: ' . ($saved_expires ? 'YES' : 'NO'), 'INFO');
                            
                            // Verify it was saved
                            $verify = get_option(AT_Zoho_CRM::OPTION_REFRESH_TOKEN);
                            write_detailed_log('ZOHO: Verified saved token: ' . substr($verify, 0, 30) . '...', 'INFO');
                        }
                    }
                } elseif (!empty($data['error'])) {
                    $conversion_error = $data['error'];
                    if (!empty($data['error_description'])) {
                        $conversion_error .= ': ' . $data['error_description'];
                    }
                }
            } else {
                $conversion_error = $response->get_error_message();
            }
        }
    } catch (Exception $e) {
        $conversion_error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html dir="rtl" lang="he-IL">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ZOHO OAuth Callback - ARTERNATIVE</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #f5f5f5;
            direction: rtl;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .success {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 4px;
            margin: 20px 0;
        }
        .error {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 4px;
            margin: 20px 0;
        }
        .code-box {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 4px;
            font-family: monospace;
            word-break: break-all;
            margin: 10px 0;
        }
        .copy-btn {
            background: #007cba;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }
        .copy-btn:hover {
            background: #005a87;
        }
        .instructions {
            background: #fff3cd;
            color: #856404;
            padding: 15px;
            border-radius: 4px;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔗 ZOHO OAuth Callback</h1>
        <p>ברוכים הבאים לדף קבלת ההרשאה של ZOHO CRM</p>

        <?php if ($error): ?>
            <div class="error">
                <h3>❌ שגיאה בקבלת ההרשאה</h3>
                <p><strong>שגיאה:</strong> <?php echo esc_html($error); ?></p>
                <?php if ($error_description): ?>
                    <p><strong>תיאור:</strong> <?php echo esc_html($error_description); ?></p>
                <?php endif; ?>
            </div>
        <?php elseif ($code): ?>
            <?php if ($refresh_token): ?>
                <!-- Successfully converted to refresh token -->
                <div class="success">
                    <h3>✅ קוד הרשאה התקבל בהצלחה!</h3>
                    <p>העתק את הקוד הבא והשתמש בו כדי לקבל Refresh Token:</p>

                    <div class="code-box" id="auth-code">
                        <?php echo esc_html($code); ?>
                    </div>

                    <button class="copy-btn" onclick="copyToClipboard('auth-code')">
                        📋 העתק קוד
                    </button>
                </div>
                
                <div class="success">
                    <h3>✅ Refresh Token נוצר בהצלחה!</h3>
                    <p>העתק את הטוקן הבא ושמור אותו ב-WordPress:</p>

                    <div class="code-box" id="refresh-token">
                        <?php echo esc_html($refresh_token); ?>
                    </div>

                    <button class="copy-btn" onclick="copyToClipboard('refresh-token')">
                        📋 העתק קוד
                    </button>
                    
                    <?php if ($is_admin): ?>
                        <div style="background: #d4edda; color: #155724; padding: 20px; border-radius: 4px; margin-top: 20px; text-align: center;">
                            <h3 style="margin: 0 0 10px 0;">✅ הכל מוכן!</h3>
                            <p style="margin: 10px 0;"><strong>הטוקן נשמר אוטומטית במסד הנתונים!</strong></p>
                            <p style="margin: 10px 0;">עכשיו אתה יכול לסגור את הדף הזה ולחזור להגדרות.</p>
                            <a href="<?php echo admin_url('admin.php?page=at-bookings-zoho-settings'); ?>" 
                               class="button button-primary" 
                               style="background: #28a745; border-color: #28a745; font-size: 16px; padding: 10px 30px; margin-top: 10px;">
                                🚀 חזור להגדרות ZOHO
                            </a>
                        </div>
                    <?php else: ?>
                        <p style="color: orange; margin-top: 15px;">
                            ⚠️ אנא התחבר כמנהל כדי לשמור אוטומטית
                        </p>
                        <a href="<?php echo wp_login_url(admin_url('admin.php?page=at-bookings-zoho-settings')); ?>" class="copy-btn">
                            🔐 התחבר כעת
                        </a>
                    <?php endif; ?>
                </div>
            <?php elseif ($conversion_error): ?>
                <!-- Error converting -->
                <div class="error">
                    <h3>❌ שגיאה בהמרת הקוד</h3>
                    <p><strong>שגיאה:</strong> <?php echo esc_html($conversion_error); ?></p>
                </div>
                
                <div class="success">
                    <h3>📋 קוד ההרשאה שהתקבל:</h3>
                    <div class="code-box" id="auth-code">
                        <?php echo esc_html($code); ?>
                    </div>
                    <button class="copy-btn" onclick="copyToClipboard('auth-code')">
                        📋 העתק קוד
                    </button>
                </div>
            <?php else: ?>
                <!-- Show authorization code (fallback) -->
                <div class="success">
                    <h3>✅ קוד הרשאה התקבל בהצלחה!</h3>
                    <p>העתק את הקוד הבא והשתמש בו כדי לקבל Refresh Token:</p>

                    <div class="code-box" id="auth-code">
                        <?php echo esc_html($code); ?>
                    </div>

                    <button class="copy-btn" onclick="copyToClipboard('auth-code')">
                        📋 העתק קוד
                    </button>
                </div>
            <?php endif; ?>

            <div class="instructions">
                <h4>📋 השלבים הבאים:</h4>
                <ol>
                    <li>העתק את הקוד למעלה</li>
                    <li>פתח terminal או command prompt</li>
                    <li>הרץ את הפקודה הבאה (החלף את הפרטים שלך):</li>
                </ol>

                <div class="code-box">
curl -X POST https://accounts.zoho.com/oauth/v2/token \<br>
  -d "grant_type=authorization_code" \<br>
  -d "client_id=YOUR_CLIENT_ID" \<br>
  -d "client_secret=YOUR_CLIENT_SECRET" \<br>
  -d "redirect_uri=<?php echo esc_html($_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['SCRIPT_NAME']); ?>" \<br>
  -d "code=<span id="code-placeholder"><?php echo esc_html($code); ?></span>"
                </div>

                <button class="copy-btn" onclick="copyCurlCommand()">
                    📋 העתק פקודת cURL
                </button>
                
                <div class="instructions" style="margin-top: 20px;">
                    <h4>⚠️ חשוב מאוד!</h4>
                    <p>ה-<strong>redirect_uri</strong> חייב להיות <strong>זהה בדיוק</strong> למה שרשום ב-ZOHO API Console:</p>
                    <div class="code-box">
                        <?php 
                        // $current_redirect_uri = plugins_url('at-bookings-api-fixes') . '/zoho-callback.php';
                        $current_redirect_uri = admin_url('admin-post.php?action=at_zoho_oauth_callback');
                        echo esc_html($current_redirect_uri); 
                        ?>
                    </div>
                    <button class="copy-btn" onclick="navigator.clipboard.writeText('<?php echo esc_js($current_redirect_uri); ?>').then(() => alert('הועתק!'))">
                        📋 העתק Redirect URI
                    </button>
                </div>
            </div>

            <div class="instructions">
                <h4>🔧 לאחר קבלת ה-Refresh Token:</h4>
                <ol>
                    <li>לך ל-<strong>WordPress Admin → Tools → ZOHO CRM</strong></li>
                    <li>מלא את כל השדות (כולל ה-Refresh Token)</li>
                    <li>שמור הגדרות</li>
                    <li>לחץ על <strong>"Test Connection"</strong></li>
                </ol>
            </div>
        <?php else: ?>
            <div class="error">
                <h3>❓ לא התקבל קוד הרשאה</h3>
                <p>נראה שהגעת לדף זה בלי קוד הרשאה מ-ZOHO.</p>
                <p>אנא חזור לתהליך יצירת האפליקציה ב-ZOHO API Console ונסה שוב.</p>
            </div>
        <?php endif; ?>
    </div>

    <script>
        function copyToClipboard(elementId) {
            const element = document.getElementById(elementId);
            const text = element.textContent || element.innerText;

            navigator.clipboard.writeText(text).then(function() {
                alert('הקוד הועתק ללוח!');
            }, function(err) {
                // Fallback for older browsers
                const textArea = document.createElement("textarea");
                textArea.value = text;
                document.body.appendChild(textArea);
                textArea.focus();
                textArea.select();
                try {
                    document.execCommand('copy');
                    alert('הקוד הועתק ללוח!');
                } catch (err) {
                    alert('שגיאה בהעתקה. העתק ידנית: ' + text);
                }
                document.body.removeChild(textArea);
            });
        }

        function copyCurlCommand() {
            const code = document.getElementById('code-placeholder').textContent;
            const curlCommand = `curl -X POST https://accounts.zoho.com/oauth/v2/token \\
  -d "grant_type=authorization_code" \\
  -d "client_id=YOUR_CLIENT_ID" \\
  -d "client_secret=YOUR_CLIENT_SECRET" \\
  -d "code=${code}"`;

            navigator.clipboard.writeText(curlCommand).then(function() {
                alert('פקודת cURL הועתקה ללוח!');
            }, function(err) {
                const textArea = document.createElement("textarea");
                textArea.value = curlCommand;
                document.body.appendChild(textArea);
                textArea.focus();
                textArea.select();
                try {
                    document.execCommand('copy');
                    alert('פקודת cURL הועתקה ללוח!');
                } catch (err) {
                    alert('שגיאה בהעתקה. העתק ידנית.');
                }
                document.body.removeChild(textArea);
            });
        }
    </script>
</body>
</html>
