<?php
/**
 * ZOHO OAuth Callback Handler
 * This file receives the authorization code from ZOHO
 */

// This handler must only be included through the authenticated admin-post route.
if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('manage_options')) {
    wp_die(
        esc_html__('You are not allowed to configure Zoho OAuth.', 'at-bookings-api-fixes'),
        esc_html__('Forbidden', 'at-bookings-api-fixes'),
        array('response' => 403)
    );
}

$is_admin = true;

// Get the authorization code from URL
$code = isset($_GET['code']) ? sanitize_text_field($_GET['code']) : '';
$error = isset($_GET['error']) ? sanitize_text_field($_GET['error']) : '';
$error_description = isset($_GET['error_description']) ? sanitize_text_field($_GET['error_description']) : '';

// Auto-convert authorization code to refresh token
$refresh_token = '';
$access_token = '';
$conversion_error = '';
$token_expires_in = 0;

if ($code && !$error && class_exists('AT_Zoho_CRM')) {
    try {
        $settings = AT_Zoho_CRM::get_settings();
        
        if (!empty($settings['client_id']) && !empty($settings['client_secret'])) {
            // Convert authorization code to tokens - use same redirect_uri as authorization
            // $plugin_url = plugins_url('at-bookings-api-fixes');
            // $redirect_uri = $plugin_url . '/zoho-callback.php';
            $redirect_uri = admin_url('admin-post.php?action=at_zoho_oauth_callback');
            
            // Get accounts domain from centralized function (MUST match the authorization request!)
            $accounts_domain = AT_Zoho_CRM::get_accounts_domain($settings['domain']);
            $token_url = "https://{$accounts_domain}/oauth/v2/token";
            
            if (function_exists('write_detailed_log')) {
                write_detailed_log('ZOHO Callback: Converting auth code to tokens', 'DEBUG');
                write_detailed_log('ZOHO Callback: Using accounts server: ' . $accounts_domain, 'DEBUG');
                write_detailed_log('ZOHO Callback: Token URL: ' . $token_url, 'DEBUG');
                write_detailed_log('ZOHO Callback: Redirect URI: ' . $redirect_uri, 'DEBUG');
                write_detailed_log('ZOHO Callback: Code length: ' . strlen($code), 'DEBUG');
            }
            
            $response = wp_remote_post($token_url, array(
                'body' => array(
                    'grant_type' => 'authorization_code',
                    'client_id' => $settings['client_id'],
                    'client_secret' => $settings['client_secret'],
                    'redirect_uri' => $redirect_uri,
                    'code' => $code
                ),
                'timeout' => 30
            ));
            
            if (!is_wp_error($response)) {
                $body = wp_remote_retrieve_body($response);
                $data = json_decode($body, true);
                
                if (!empty($data['refresh_token'])) {
                    $refresh_token = $data['refresh_token'];
                    $access_token = $data['access_token'] ?? '';
                    $token_expires_in = $data['expires_in'] ?? 3600;
                    
                    if (function_exists('write_detailed_log')) {
                        write_detailed_log('ZOHO Callback: OAuth tokens received', 'INFO');
                    }
                    
                    // Auto-save if user is logged in as admin
                    if ($is_admin) {
                        $saved_refresh = update_option(AT_Zoho_CRM::OPTION_REFRESH_TOKEN, $refresh_token);
                        $saved_access = update_option(AT_Zoho_CRM::OPTION_ACCESS_TOKEN, $access_token);
                        $saved_expires = update_option(AT_Zoho_CRM::OPTION_TOKEN_EXPIRES, time() + $token_expires_in);
                        
                        if (function_exists('write_detailed_log')) {
                            write_detailed_log('ZOHO: Refresh token auto-saved from callback - Success: ' . ($saved_refresh ? 'YES' : 'NO'), 'INFO');
                            write_detailed_log('ZOHO: Access token saved: ' . ($saved_access ? 'YES' : 'NO'), 'INFO');
                            write_detailed_log('ZOHO: Token expires saved: ' . ($saved_expires ? 'YES' : 'NO'), 'INFO');
                            
                            write_detailed_log('ZOHO: OAuth token persistence verified', 'INFO');
                        }
                    }
                } elseif (!empty($data['error'])) {
                    $conversion_error = $data['error'];
                    if (!empty($data['error_description'])) {
                        $conversion_error .= ': ' . $data['error_description'];
                    }
                }
            } else {
                $conversion_error = $response->get_error_message();
            }
        }
    } catch (Exception $e) {
        $conversion_error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html dir="rtl" lang="he-IL">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ZOHO OAuth Callback - ARTERNATIVE</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #f5f5f5;
            direction: rtl;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .success {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 4px;
            margin: 20px 0;
        }
        .error {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 4px;
            margin: 20px 0;
        }
        .code-box {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 4px;
            font-family: monospace;
            word-break: break-all;
            margin: 10px 0;
        }
        .copy-btn {
            background: #007cba;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }
        .copy-btn:hover {
            background: #005a87;
        }
        .instructions {
            background: #fff3cd;
            color: #856404;
            padding: 15px;
            border-radius: 4px;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔗 ZOHO OAuth Callback</h1>
        <p>ברוכים הבאים לדף קבלת ההרשאה של ZOHO CRM</p>

        <?php if ($error): ?>
            <div class="error">
                <h3>❌ שגיאה בקבלת ההרשאה</h3>
                <p><strong>שגיאה:</strong> <?php echo esc_html($error); ?></p>
                <?php if ($error_description): ?>
                    <p><strong>תיאור:</strong> <?php echo esc_html($error_description); ?></p>
                <?php endif; ?>
            </div>
        <?php elseif ($code): ?>
            <?php if ($refresh_token): ?>
                <div class="success">
                    <h3>✅ הכל מוכן!</h3>
                    <p><strong>ההרשאה התקבלה והטוקנים נשמרו בצורה מאובטחת.</strong></p>
                    <p>מטעמי אבטחה קוד ההרשאה והטוקנים אינם מוצגים בדף.</p>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=at-bookings-zoho-settings')); ?>"
                       class="button button-primary"
                       style="background: #28a745; border-color: #28a745; font-size: 16px; padding: 10px 30px; margin-top: 10px;">
                        🚀 חזור להגדרות ZOHO
                    </a>
                </div>
            <?php elseif ($conversion_error): ?>
                <div class="error">
                    <h3>❌ שגיאה בהמרת הקוד</h3>
                    <p><strong>שגיאה:</strong> <?php echo esc_html($conversion_error); ?></p>
                    <p>מטעמי אבטחה קוד ההרשאה אינו מוצג. חזור להגדרות והתחל את תהליך ההרשאה מחדש.</p>
                </div>
            <?php else: ?>
                <div class="error">
                    <h3>❌ לא ניתן היה להשלים את ההרשאה</h3>
                    <p>קוד ההרשאה לא נשמר או הוצג. חזור להגדרות והתחל מחדש.</p>
                </div>
            <?php endif; ?>

            <div class="instructions">
                <a href="<?php echo esc_url(admin_url('admin.php?page=at-bookings-zoho-settings')); ?>">
                    חזור להגדרות ZOHO
                </a>
            </div>
        <?php else: ?>
            <div class="error">
                <h3>❓ לא התקבל קוד הרשאה</h3>
                <p>נראה שהגעת לדף זה בלי קוד הרשאה מ-ZOHO.</p>
                <p>אנא חזור לתהליך יצירת האפליקציה ב-ZOHO API Console ונסה שוב.</p>
            </div>
        <?php endif; ?>
    </div>

    <script>
        function copyToClipboard(elementId) {
            const element = document.getElementById(elementId);
            const text = element.textContent || element.innerText;

            navigator.clipboard.writeText(text).then(function() {
                alert('הקוד הועתק ללוח!');
            }, function(err) {
                // Fallback for older browsers
                const textArea = document.createElement("textarea");
                textArea.value = text;
                document.body.appendChild(textArea);
                textArea.focus();
                textArea.select();
                try {
                    document.execCommand('copy');
                    alert('הקוד הועתק ללוח!');
                } catch (err) {
                    alert('שגיאה בהעתקה. העתק ידנית: ' + text);
                }
                document.body.removeChild(textArea);
            });
        }

        function copyCurlCommand() {
            const code = document.getElementById('code-placeholder').textContent;
            const curlCommand = `curl -X POST https://accounts.zoho.com/oauth/v2/token \\
  -d "grant_type=authorization_code" \\
  -d "client_id=YOUR_CLIENT_ID" \\
  -d "client_secret=YOUR_CLIENT_SECRET" \\
  -d "code=${code}"`;

            navigator.clipboard.writeText(curlCommand).then(function() {
                alert('פקודת cURL הועתקה ללוח!');
            }, function(err) {
                const textArea = document.createElement("textarea");
                textArea.value = curlCommand;
                document.body.appendChild(textArea);
                textArea.focus();
                textArea.select();
                try {
                    document.execCommand('copy');
                    alert('פקודת cURL הועתקה ללוח!');
                } catch (err) {
                    alert('שגיאה בהעתקה. העתק ידנית.');
                }
                document.body.removeChild(textArea);
            });
        }
    </script>
</body>
</html>
