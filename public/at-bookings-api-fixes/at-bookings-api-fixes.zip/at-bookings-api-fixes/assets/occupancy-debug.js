(function($){
  // בדיקה אם המוצר הנוכחי הוא bookable product
  function isBookableProduct(){
    // בדיקה 1: האם קיימים שדות של WC Bookings
    if ($("[name^='wc_bookings_field_']").length > 0) {
      return true;
    }
    // בדיקה 2: האם הטופס כולל את הקלאס של booking form
    if ($('form.cart').hasClass('wc-bookings-booking-form')) {
      return true;
    }
    // בדיקה 3: האם קיים booking form container
    if ($('.wc-bookings-booking-form').length > 0) {
      return true;
    }
    // אם אף אחת מהבדיקות לא עברה - זה לא מוצר bookable
    return false;
  }

  function getPersonsTotal(){
    var total=0; $("[name^='wc_bookings_field_person']").each(function(){
      total += parseInt($(this).val()||0,10) || 0;
    });
    return total;
  }

  function ensureNoticeContainer(){
    var $form = $('form.cart');
    if (!$form.length) return $();
    var $n = $form.find('.at-occupancy-notice');
    if (!$n.length){
      $n = $('<div class="at-occupancy-notice woocommerce-error" role="alert" style="display:none;margin:12px 0;"></div>');
      $n.insertBefore($form.find('.single_add_to_cart_button').first());
    }
    return $n;
  }

  function setButtonEnabled(enabled){
    var $btn = $('form.cart .single_add_to_cart_button');
    $btn.prop('disabled', !enabled).attr('aria-disabled', !enabled);
    if (!enabled) { $btn.addClass('disabled'); } else { $btn.removeClass('disabled'); }
  }

  function validateBooking(){
    // בדיקה אם זה מוצר bookable - אם לא, תמיד מאפשרים
    if (!isBookableProduct()) {
      return true;
    }

    var $notice = ensureNoticeContainer();
    var persons = getPersonsTotal();

    if (persons <= 0){
      $notice.text(AT_BOOKINGS_DEBUG.i18n_personRequired).show();
      setButtonEnabled(false);
      return false;
    } else {
      // הסרנו את הבדיקה המקומית של לפחות 2 משתתפים
      // נתן לשרת להחליט בהתבסס על מצב הסלוט (ריק או לא)
      $notice.hide();
      // לא משנים את מצב הכפתור כאן - נתן ל-AJAX להחליט
      return true;
    }
  }

  // פונקציה לחילוץ מידע על הסלוט שנבחר
  function logSlotSelection(data, settings) {
    try {
      // ניסיון לחלץ מידע על התאריך והשעה שנבחרו
      var selectedDate = '';
      var selectedTime = '';
      var productId = '';
      var persons = getPersonsTotal();

      // חיפוש בפרמטרי הבקשה אחר מידע על התאריך
      if (data.indexOf('_date=') !== -1) {
        var dateMatch = data.match(/_date=([^&]*)/);
        if (dateMatch && dateMatch[1]) {
          var timestamp = parseInt(dateMatch[1]);
          if (!isNaN(timestamp)) {
            selectedDate = new Date(timestamp * 1000).toLocaleDateString('he-IL');
          }
        }
      }

      // חיפוש בפרמטרי הבקשה אחר מידע על השעה
      if (data.indexOf('_time=') !== -1) {
        var timeMatch = data.match(/_time=([^&]*)/);
        if (timeMatch && timeMatch[1]) {
          selectedTime = decodeURIComponent(timeMatch[1]);
        }
      }

      // חיפוש מזהה המוצר
      if (data.indexOf('product_id=') !== -1) {
        var productMatch = data.match(/product_id=([^&]*)/);
        if (productMatch && productMatch[1]) {
          productId = productMatch[1];
        }
      }

      // חיפוש ב-URL של העמוד אחר מזהה המוצר
      if (!productId) {
        var urlMatch = window.location.href.match(/\/product\/([^\/]+)\/?$/);
        if (urlMatch && urlMatch[1]) {
          // ניסיון למצוא את מזהה המוצר ב-post ID
          var productElement = $('input[name="product_id"], input[name="add-to-cart"]');
          if (productElement.length > 0) {
            productId = productElement.val();
          }
        }
      }

      // הדפסת מידע מפורט לקונסול
      console.log('🎯 AT Bookings - בחירת סלוט פנוי:');
      console.log('📅 תאריך:', selectedDate || 'לא נמצא');
      console.log('🕐 שעה:', selectedTime || 'לא נמצאה');
      console.log('🆔 מזהה מוצר:', productId || 'לא נמצא');
      console.log('👥 כמות משתתפים:', persons);
      console.log('📋 פעולה:', data.indexOf('action=wc_bookings_calculate_costs') !== -1 ? 'חישוב מחיר' : 'קבלת blocks');
      console.log('🔗 URL:', settings.url);
      console.log('📊 נתונים מלאים:', data);
      console.log('---');

    } catch (error) {
      console.log('❌ AT Bookings - שגיאה בחילוץ מידע הסלוט:', error);
    }
  }

  // hooks: calculate costs / get blocks
  $(document).ajaxSuccess(function(e,xhr,settings){
    // בדיקה אם זה מוצר bookable - אם לא, יוצאים מיד
    if (!isBookableProduct()) {
      return;
    }

    try{
      var url = settings.url||''; if(url.indexOf('admin-ajax.php')===-1) return;
      var data = settings.data; if(typeof data!=='string') data=$.param(data||{});
      if (data.indexOf('action=wc_bookings_calculate_costs')!==-1 || data.indexOf('action=wc_bookings_get_blocks')!==-1){
        // הדפסת מידע על בחירת סלוט לקונסול
        logSlotSelection(data, settings);

        // בדיקת תגובה מהשרת - אם יש שגיאה, הכפתור נשאר disabled
        var response = xhr.responseJSON || {};
        var hasServerError = response.error || response.errors || (response.success === false);

        // הסרנו את הקריאה ל-occupancy API - נשתמש רק בבדיקה מקומית של כמות המשתתפים
        var $n = ensureNoticeContainer();
        if (getPersonsTotal() <= 0){
          $n.text(AT_BOOKINGS_DEBUG.i18n_personRequired).show();
          setButtonEnabled(false);
        } else if (hasServerError) {
          // אם השרת מחזיר שגיאה (למשל סלוט ריק דורש לפחות 2 משתתפים), הכפתור נשאר disabled
          console.log('🚫 AT Bookings - שגיאה מהשרת, הכפתור נשאר disabled');
          setButtonEnabled(false);
        } else {
          // השרת אישר - הכפתור יכול להיות enabled
          $n.hide();
          setButtonEnabled(true);
        }
      }
    }catch(err){}
  });

  // בדיקת הכמויות בכל שינוי שדה אנשים
  $(document).on('change input', "[name^='wc_bookings_field_person']", function(){
    // בדיקה אם זה מוצר bookable
    if (!isBookableProduct()) {
      return;
    }
    console.log('👥 AT Bookings - שינוי כמות משתתפים:', getPersonsTotal());
    validateBooking();
  });

  // הדפסת מידע על בחירת תאריך ושעה
  $(document).on('change', "[name^='wc_bookings_field_start_date']", function(){
    // בדיקה אם זה מוצר bookable
    if (!isBookableProduct()) {
      return;
    }
    var selectedDate = $(this).val();
    console.log('📅 AT Bookings - בחירת תאריך:', selectedDate);
    console.log('📋 פרטי התאריך הנבחר:', {
      date: selectedDate,
      formatted: selectedDate ? new Date(selectedDate).toLocaleDateString('he-IL') : 'לא נבחר',
      timestamp: selectedDate ? new Date(selectedDate).getTime() / 1000 : null
    });
  });

  // הדפסת מידע על בחירת שעה
  $(document).on('change', "[name^='wc_bookings_field_start_time']", function(){
    // בדיקה אם זה מוצר bookable
    if (!isBookableProduct()) {
      return;
    }
    var selectedTime = $(this).val();
    console.log('🕐 AT Bookings - בחירת שעה:', selectedTime);
    console.log('⏰ פרטי השעה הנבחרת:', {
      time: selectedTime,
      formatted: selectedTime || 'לא נבחר'
    });
  });

  // הדפסת מידע על בחירת משאב (אם קיים)
  $(document).on('change', "[name^='wc_bookings_field_resource']", function(){
    // בדיקה אם זה מוצר bookable
    if (!isBookableProduct()) {
      return;
    }
    var selectedResource = $(this).val();
    var resourceText = $(this).find('option:selected').text();
    console.log('🏢 AT Bookings - בחירת משאב:', selectedResource, resourceText);
  });

  // מניעת שליחה אם המגבלה מופרת
  $(document).on('submit', 'form.cart', function(e){
    // בדיקה אם זה מוצר bookable - אם לא, מאפשרים שליחה רגילה
    if (!isBookableProduct()) {
      return true;
    }

    console.log('📤 AT Bookings - ניסיון שליחת טופס הזמנה');
    console.log('👥 כמות משתתפים בבדיקה:', getPersonsTotal());

    if (!validateBooking()){
      console.log('❌ AT Bookings - שליחה נחסמה - לא נבחרה כמות משתתפים');
      e.preventDefault();
      e.stopImmediatePropagation();
      return false;
    }

    console.log('✅ AT Bookings - טופס עובר אימות, ממשיך לשליחה');
  });

  // הדפסת מידע כללי על טעינת הדף
  $(document).ready(function(){
    // בדיקה ראשונית אם זה מוצר bookable
    var isBookable = isBookableProduct();
    
    console.log('🚀 AT Bookings Debug - דף נטען');
    console.log('📄 URL:', window.location.href);
    console.log('🛒 מוצר בוקינג:', $('input[name="product_id"]').val() || 'לא נמצא');
    console.log('📦 סוג מוצר:', isBookable ? 'Bookable Product ✅' : 'Simple Product (לא bookable) ⚠️');

    // אם זה לא מוצר bookable, עוצרים כאן
    if (!isBookable) {
      console.log('ℹ️ AT Bookings - זה לא מוצר Bookable, הסקריפט לא יפעל על מוצר זה');
      return;
    }

    console.log('👥 כמות משתתפים נוכחית:', getPersonsTotal());

    // הדפסת מידע על שדות הבוקינג הקיימים
    var bookingFields = {};
    $("[name^='wc_bookings_field_']").each(function(){
      bookingFields[$(this).attr('name')] = $(this).val();
    });
    console.log('📝 שדות בוקינג:', bookingFields);

    // בדיקה ראשונית - אם אין משתתפים בכלל, הכפתור מתחיל disabled
    if (getPersonsTotal() <= 0) {
      console.log('🚫 AT Bookings - אין משתתפים נבחרים, הכפתור מתחיל disabled');
      setButtonEnabled(false);
    }
  });

})(jQuery);


