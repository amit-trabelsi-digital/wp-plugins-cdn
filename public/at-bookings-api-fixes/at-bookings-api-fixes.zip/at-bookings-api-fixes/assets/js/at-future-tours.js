jQuery(document).ready(function($) {
    'use strict';

    console.log('AT Future Tours JS loaded');
    console.log('at_tours_vars:', at_tours_vars);

    // Global variables
    let toursTable;
    let currentFilters = {
        start_date: $('#start-date').val(),
        end_date: $('#end-date').val(),
        city: '',
        product_id: '',
        mode: 'all',
        include_past: false
    };

    // Initialize table
    function initTable() {
        console.log('Initializing DataTable with URL:', at_tours_vars.ajax_url);

        toursTable = $('#future-tours-table').DataTable({
            ajax: {
                url: at_tours_vars.ajax_url,
                type: 'POST',
                data: function(d) {
                    console.log('Sending AJAX data:', d);
                    d.action = 'at_get_future_tours';
                    d.nonce = at_tours_vars.nonce;
                    d.start_date = currentFilters.start_date;
                    d.end_date = currentFilters.end_date;
                    d.city = currentFilters.city;
                    d.product_id = currentFilters.product_id;
                    d.mode = currentFilters.mode;
                    d.include_past = currentFilters.include_past;
                    return d;
                },
                dataSrc: function(json) {
                    console.log('Received data from server:', json);
                    if (json.data && json.data.length > 0) {
                        console.log('First row sample:', json.data[0]);
                    }
                    return json.data || [];
                },
                error: function(xhr, error, thrown) {
                    console.error('DataTables AJAX Error:', {
                        xhr: xhr,
                        error: error,
                        thrown: thrown,
                        status: xhr.status,
                        responseText: xhr.responseText
                    });
                    alert('Error loading data: ' + error + '\n' + xhr.responseText);
                }
            },
            columns: [
                {
                    data: 'tour_id',
                    title: 'Tour ID',
                    orderable: true,
                    defaultContent: '',
                    render: function(data) {
                        if (!data) return '';
                        return '<code style="font-size: 11px; color: #666;">' + data + '</code>';
                    }
                },
                {
                    data: 'product_name',
                    title: 'Product',
                    orderable: true,
                    defaultContent: '',
                    render: function(data, type, row) {
                        if (!data) return '';
                        const editUrl = at_tours_vars.admin_url + 'post.php?post=' + row.product_id + '&action=edit';
                        return '<a href="' + editUrl + '" target="_blank" style="color: #0073aa; text-decoration: none;">' + data + '</a>';
                    }
                },
                {
                    data: 'city',
                    title: 'City',
                    orderable: true,
                    defaultContent: 'Not specified'
                },
                {
                    data: null,
                    title: 'Date & Time',
                    orderable: true,
                    defaultContent: '',
                    render: function(data, type, row) {
                        if (!row.date) return '';
                        
                        // For sorting, use ISO format
                        if (type === 'sort' || type === 'type') {
                            return row.date + ' ' + (row.start_time || '00:00:00');
                        }
                        
                        // For display, use Israeli format
                        const dateStr = formatIsraeliDate(row.date);
                        const timeStr = row.start_time ? row.start_time.substring(0, 5) : '';
                        return dateStr + ' ' + timeStr;
                    }
                },
                {
                    data: 'bookings_count',
                    title: 'Bookings',
                    orderable: true,
                    defaultContent: '0',
                    className: 'clickable-count',
                    render: function(data, type, row) {
                        data = data || 0;
                        if (data > 0) {
                            return '<a href="#" class="show-orders" data-product-id="' + row.product_id + '" data-date="' + row.date + '" data-time="' + row.start_time + '">' + data + '</a>';
                        }
                        return '<span style="color: #999;">0</span>';
                    }
                },
                {
                    data: null,
                    title: 'Occupancy',
                    orderable: true,
                    defaultContent: '0/0',
                    className: 'clickable-count',
                    render: function(data, type, row) {
                        const booked = row.booked_persons || 0;
                        const capacity = row.max_capacity || 0;
                        const available = row.available || 0;
                        
                        let statusColor = '#999';
                        let statusText = '';
                        
                        if (capacity === 0) {
                            statusText = 'N/A';
                        } else if (available === 0) {
                            statusColor = 'red';
                            statusText = ' (Full)';
                        } else if (available <= 3) {
                            statusColor = 'orange';
                            statusText = ' (Low)';
                        } else {
                            statusColor = 'green';
                        }
                        
                        if (booked > 0) {
                            return '<a href="#" class="show-orders" data-product-id="' + row.product_id + '" data-date="' + row.date + '" data-time="' + row.start_time + '" style="color: ' + statusColor + '; font-weight: bold;">' + booked + '/' + capacity + '</a><span style="color: ' + statusColor + ';">' + statusText + '</span>';
                        }
                        return '<span style="color: ' + statusColor + ';">0/' + capacity + '</span>';
                    }
                }
            ],
            language: {
                url: '//cdn.datatables.net/plug-ins/1.13.7/i18n/en-GB.json'
            },
            responsive: true,
            pageLength: 25,
            order: [[3, 'asc'], [4, 'asc']], // Sort by date then time
            dom: '<"top"f>rt<"bottom"lp><"clear">',
            columnDefs: [
                {
                    targets: '_all',
                    defaultContent: ''
                }
            ],
            drawCallback: function(settings) {
                console.log('Table drawn with', settings.aiDisplay.length, 'rows');
            }
        });
    }

    // Function to format English date
    function formatEnglishDate(dateString) {
        const date = new Date(dateString);
        const options = {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        };
        return date.toLocaleDateString('en-US', options);
    }
    
    // Function to format Hebrew/Israeli date
    function formatIsraeliDate(dateString) {
        const date = new Date(dateString);
        const day = ('0' + date.getDate()).slice(-2);
        const month = ('0' + (date.getMonth() + 1)).slice(-2);
        const year = date.getFullYear().toString().slice(-2);
        return `${day}/${month}/${year}`;
    }

    // Initialize filters
    function initFilters() {
        // Update filters on change
        $('#start-date, #end-date, #city-filter, #product-filter, #mode-filter').on('change', function() {
            updateFilters();
        });

        // Refresh button
        $('#refresh-tours').on('click', function(e) {
            e.preventDefault();
            updateFilters();
        });

        // Load cities and products
        loadCities();
        loadProducts();
    }

    // Update filters
    function updateFilters() {
        const mode = $('#mode-filter').val();
        
        currentFilters = {
            start_date: $('#start-date').val(),
            end_date: $('#end-date').val(),
            city: $('#city-filter').val(),
            product_id: $('#product-filter').val(),
            mode: mode,
            include_past: (mode === 'past_booked') // אוטומטית true אם מצב past
        };

        if (toursTable) {
            toursTable.ajax.reload();
        }
    }

    // Load cities list
    function loadCities() {
        $.ajax({
            url: at_tours_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'at_get_tour_cities',
                nonce: at_tours_vars.nonce
            },
            success: function(response) {
                if (response.success && response.data) {
                    const $cityFilter = $('#city-filter');
                    $cityFilter.empty();
                    $cityFilter.append('<option value="">All Cities</option>');

                    response.data.forEach(function(city) {
                        $cityFilter.append('<option value="' + city + '">' + city + '</option>');
                    });
                }
            }
        });
    }

    // Load products list
    function loadProducts() {
        $.ajax({
            url: at_tours_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'at_get_tour_products',
                nonce: at_tours_vars.nonce
            },
            success: function(response) {
                if (response.success && response.data) {
                    const $productFilter = $('#product-filter');
                    $productFilter.empty();
                    $productFilter.append('<option value="">All Products</option>');

                    response.data.forEach(function(product) {
                        $productFilter.append('<option value="' + product.id + '">' + product.name + '</option>');
                    });
                }
            }
        });
    }

    // Handle click on booking count
    $(document).on('click', '.show-orders', function(e) {
        e.preventDefault();

        const productId = $(this).data('product-id');
        const date = $(this).data('date');
        const time = $(this).data('time');

        showOrdersModal(productId, date, time);
    });

    // Show orders modal
    function showOrdersModal(productId, date, time) {
        $('#orders-modal').show();

        // Load orders
        $.ajax({
            url: at_tours_vars.ajax_url,
            type: 'POST',
            data: {
                action: 'at_get_tour_orders',
                nonce: at_tours_vars.nonce,
                product_id: productId,
                date: date,
                time: time
            },
            success: function(response) {
                if (response.success) {
                    displayOrders(response.data, date, time);
                } else {
                    $('#orders-list').html('<p>Error loading orders</p>');
                }
            },
            error: function() {
                $('#orders-list').html('<p>Error loading orders</p>');
            }
        });
    }

    // Display orders in modal
    function displayOrders(orders, date, time) {
        const dateStr = formatIsraeliDate(date);
        const timeStr = time ? time.substring(0, 5) : '';
        let html = '<h3>סיור בתאריך ' + dateStr + ' בשעה ' + timeStr + '</h3>';

        if (orders && orders.length > 0) {
            let totalPersons = orders.reduce((sum, order) => sum + parseInt(order.persons), 0);
            html += '<p><strong>Total Orders:</strong> ' + orders.length + ' | <strong>Total Participants:</strong> ' + totalPersons + '</p>';
            html += '<div class="orders-container">';

            orders.forEach(function(order) {
                // Order link - uses admin_url
                const orderLink = at_tours_vars.admin_url + 'post.php?post=' + order.order_id + '&action=edit';
                // Booking link (if different from order)
                const bookingLink = at_tours_vars.admin_url + 'post.php?post=' + order.booking_id + '&action=edit';

                html += `
                    <div class="booking-item">
                        <h4>
                            <a href="${orderLink}" target="_blank" style="color: #0073aa; font-weight: bold;">Order #${order.order_id}</a>
                            ${order.booking_id != order.order_id ? ' | <a href="' + bookingLink + '" target="_blank" style="color: #666; font-size: 0.9em;">Booking #' + order.booking_id + '</a>' : ''}
                        </h4>
                        <div class="booking-details">
                            <p><strong>Customer:</strong> ${order.customer_name}</p>
                            <p><strong>Email:</strong> <a href="mailto:${order.customer_email}" style="color: #0073aa;">${order.customer_email}</a></p>
                            <p><strong>Phone:</strong> <a href="tel:${order.customer_phone}" style="color: #0073aa;">${order.customer_phone}</a></p>
                            <p><strong>Participants:</strong> ${order.persons}</p>
                            <p><strong>Status:</strong> ${translateStatus(order.status)}</p>
                            <p><strong>Order Date:</strong> ${order.booking_date}</p>
                        </div>
                    </div>
                `;
            });

            html += '</div>';
        } else {
            html += '<p>No orders for this tour</p>';
        }

        $('#orders-list').html(html);
    }

    // Translate status
    function translateStatus(status) {
        const statusMap = {
            'confirmed': 'Confirmed',
            'paid': 'Paid',
            'complete': 'Completed',
            'pending': 'Pending',
            'cancelled': 'Cancelled'
        };
        return statusMap[status] || status;
    }

    // Close modal
    $(document).on('click', '.at-modal-close', function() {
        $('#orders-modal').hide();
    });

    // Close modal on background click
    $(document).on('click', '#orders-modal', function(e) {
        if (e.target === this) {
            $('#orders-modal').hide();
        }
    });

    // Initialize everything
    console.log('Initializing table...');
    if ($('#future-tours-table').length > 0) {
        initTable();
        initFilters();
        console.log('Table initialized successfully');

        // Auto-refresh every 5 minutes
        setInterval(function() {
            if (toursTable) {
                console.log('Auto-refreshing table...');
                toursTable.ajax.reload(null, false); // false = don't reset page
            }
        }, 300000); // 5 minutes
    } else {
        console.error('Table #future-tours-table not found!');
    }
});
