/**
 * AT Bookings Admin Dashboard JavaScript
 * 
 * Handles AJAX interactions for dashboard actions
 *
 * @package AT_Bookings_API_Fixes
 * @version 2.0.0
 */

(function($) {
    'use strict';
    
    /**
     * Dashboard object
     */
    const ATBookingsDashboard = {
        
        /**
         * Initialize
         */
        init: function() {
            this.bindEvents();
        },
        
        /**
         * Bind event handlers
         */
        bindEvents: function() {
            // Test Connection
            $('#at-test-connection').on('click', this.testConnection.bind(this));
            
            // Refresh Token
            $('#at-refresh-token').on('click', this.refreshToken.bind(this));
            
            // Clear Cache
            $('#at-clear-cache').on('click', this.clearCache.bind(this));
            
            // Generate Initial Slots
            $('#at-populate-slots').on('click', this.populateSlots.bind(this));
            
            // Copy API Key
            $('.at-copy-key').on('click', this.copyApiKey.bind(this));
            
            // Test API Endpoint
            $('.at-test-endpoint').on('click', this.testEndpoint.bind(this));
        },
        
        /**
         * Test Zoho connection
         */
        testConnection: function(e) {
            e.preventDefault();
            
            const $btn = $(e.currentTarget);
            const originalText = $btn.html();
            
            // Confirm
            if (!confirm(atBookings.i18n.confirmTest)) {
                return;
            }
            
            // Set loading state
            this.setButtonLoading($btn, atBookings.i18n.testingConnection);
            
            // AJAX request
            $.ajax({
                url: atBookings.ajaxurl,
                type: 'POST',
                data: {
                    action: 'at_test_zoho_connection',
                    nonce: atBookings.nonce
                },
                success: function(response) {
                    if (response.success) {
                        if (window.ATNotify) {
                            ATNotify.success(atBookings.i18n.connectionSuccess);
                        } else {
                            alert(atBookings.i18n.connectionSuccess);
                        }
                        // Reload page to show updated status
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        if (window.ATNotify) {
                            ATNotify.error(atBookings.i18n.connectionFailed + ': ' + (response.data || ''));
                        } else {
                            alert(atBookings.i18n.connectionFailed + ': ' + (response.data || ''));
                        }
                    }
                },
                error: function(xhr, status, error) {
                    if (window.ATNotify) {
                        ATNotify.error(atBookings.i18n.error + ': ' + error);
                    } else {
                        alert(atBookings.i18n.error + ': ' + error);
                    }
                },
                complete: function() {
                    $btn.html(originalText).removeClass('loading');
                }
            });
        },
        
        /**
         * Refresh access token
         */
        refreshToken: function(e) {
            e.preventDefault();
            
            const $btn = $(e.currentTarget);
            const originalText = $btn.html();
            
            // Confirm
            if (!confirm(atBookings.i18n.confirmRefresh)) {
                return;
            }
            
            // Set loading state
            this.setButtonLoading($btn, atBookings.i18n.refreshingToken);
            
            // AJAX request
            $.ajax({
                url: atBookings.ajaxurl,
                type: 'POST',
                data: {
                    action: 'at_refresh_zoho_token',
                    nonce: atBookings.nonce
                },
                success: function(response) {
                    if (response.success) {
                        if (window.ATNotify) {
                            ATNotify.success(atBookings.i18n.tokenRefreshed);
                        }
                        // Reload page to show updated status
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        if (window.ATNotify) {
                            ATNotify.error(atBookings.i18n.tokenRefreshFailed + ': ' + (response.data || ''));
                        } else {
                            alert(atBookings.i18n.tokenRefreshFailed + ': ' + (response.data || ''));
                        }
                    }
                },
                error: function(xhr, status, error) {
                    if (window.ATNotify) {
                        ATNotify.error(atBookings.i18n.error + ': ' + error);
                    } else {
                        alert(atBookings.i18n.error + ': ' + error);
                    }
                },
                complete: function() {
                    $btn.html(originalText).removeClass('loading');
                }
            });
        },
        
        /**
         * Clear cache
         */
        clearCache: function(e) {
            e.preventDefault();
            
            const $btn = $(e.currentTarget);
            const originalText = $btn.html();
            
            // Confirm
            if (!confirm(atBookings.i18n.confirmClear)) {
                return;
            }
            
            // Set loading state
            this.setButtonLoading($btn, atBookings.i18n.clearingCache);
            
            // AJAX request
            $.ajax({
                url: atBookings.ajaxurl,
                type: 'POST',
                data: {
                    action: 'at_clear_cache',
                    nonce: atBookings.nonce
                },
                success: function(response) {
                    if (response.success) {
                        if (window.ATNotify) {
                            ATNotify.success(atBookings.i18n.cacheCleared);
                        } else {
                            alert(atBookings.i18n.cacheCleared);
                        }
                        // Reload page to show updated data
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        if (window.ATNotify) {
                            ATNotify.error(atBookings.i18n.error + ': ' + (response.data || ''));
                        } else {
                            alert(atBookings.i18n.error + ': ' + (response.data || ''));
                        }
                    }
                },
                error: function(xhr, status, error) {
                    if (window.ATNotify) {
                        ATNotify.error(atBookings.i18n.error + ': ' + error);
                    } else {
                        alert(atBookings.i18n.error + ': ' + error);
                    }
                },
                complete: function() {
                    $btn.html(originalText).removeClass('loading');
                }
            });
        },
        
        /**
         * Copy API Key
         */
        copyApiKey: function(e) {
            e.preventDefault();
            
            const $btn = $(e.currentTarget);
            const apiKey = $btn.data('key');
            
            // Create temporary input
            const $temp = $('<input>');
            $('body').append($temp);
            $temp.val(apiKey).select();
            
            try {
                document.execCommand('copy');
                const originalText = $btn.text();
                $btn.text('✓ ' + (atBookings.i18n.copied || 'Copied!'));
                
                setTimeout(function() {
                    $btn.text(originalText);
                }, 2000);
            } catch (err) {
                alert('Failed to copy');
            }
            
            $temp.remove();
        },
        
        /**
         * Generate initial slots
         */
        populateSlots: function(e) {
            e.preventDefault();
            
            const $btn = $(e.currentTarget);
            const originalText = $btn.html();
            
            if (!confirm('Generate initial booking slots for all products? This may take a few minutes.')) {
                return;
            }
            
            // Set loading state
            this.setButtonLoading($btn, 'Generating slots...');
            
            // AJAX request
            $.ajax({
                url: atBookings.ajaxurl,
                type: 'POST',
                data: {
                    action: 'at_populate_initial_slots',
                    nonce: atBookings.nonce
                },
                success: function(response) {
                    if (response.success) {
                        if (window.ATNotify) {
                            ATNotify.success(response.data.message || 'Slots generated successfully');
                        } else {
                            alert(response.data.message || 'Slots generated successfully');
                        }
                        // Reload page to show updated data
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        if (window.ATNotify) {
                            ATNotify.error(response.data || 'Failed to generate slots');
                        } else {
                            alert(response.data || 'Failed to generate slots');
                        }
                    }
                },
                error: function(xhr, status, error) {
                    if (window.ATNotify) {
                        ATNotify.error('Error: ' + error);
                    } else {
                        alert('Error: ' + error);
                    }
                },
                complete: function() {
                    $btn.html(originalText).removeClass('loading');
                }
            });
        },
        
        /**
         * Test API Endpoint
         */
        testEndpoint: function(e) {
            e.preventDefault();
            
            const $btn = $(e.currentTarget);
            const $result = $btn.closest('.at-try-it').find('.at-endpoint-result');
            const url = $btn.data('url');
            const apiKey = String($btn.data('api-key') || '');
            const isProduction = $btn.data('is-production') === 1;
            
            // Confirm in production
            if (isProduction) {
                const confirmed = confirm(
                    atBookings.i18n.productionWarning || 
                    'You are in a PRODUCTION environment. Testing this endpoint will affect live data. Continue?'
                );
                if (!confirmed) {
                    return;
                }
            }
            
            // Set loading state
            const originalHtml = $btn.html();
            $btn.prop('disabled', true);
            $result.removeClass('success error')
                   .addClass('loading')
                   .text(atBookings.i18n.testing || 'Testing...');
            
            // Test endpoint
            $.ajax({
                url: url,
                type: 'GET',
                dataType: 'json',
                headers: {
                    Authorization: 'Bearer ' + apiKey
                },
                success: function(response) {
                    $result.removeClass('loading')
                           .addClass('success')
                           .html('✓ ' + (atBookings.i18n.endpointSuccess || 'Success! Check console for response.'));
                    console.log('API Response:', response);
                },
                error: function(xhr, status, error) {
                    $result.removeClass('loading')
                           .addClass('error')
                           .html('✗ ' + (atBookings.i18n.endpointError || 'Error:') + ' ' + error);
                    console.error('API Error:', xhr.responseText);
                },
                complete: function() {
                    $btn.prop('disabled', false).html(originalHtml);
                }
            });
        },
        
        /**
         * Set button loading state
         * 
         * @param {jQuery} $btn Button element
         * @param {string} text Loading text
         */
        setButtonLoading: function($btn, text) {
            $btn.addClass('loading').prop('disabled', true);
            
            // Find dashicon and make it spin
            const $icon = $btn.find('.dashicons');
            if ($icon.length) {
                $icon.addClass('dashicons-update-alt');
            }
            
            // Update text if provided
            if (text) {
                const iconHtml = $icon.length ? $icon.prop('outerHTML') : '';
                $btn.html(iconHtml + ' ' + text);
            }
        }
    };
    
    /**
     * Initialize on document ready
     */
    $(document).ready(function() {
        ATBookingsDashboard.init();
    });
    
})(jQuery);
