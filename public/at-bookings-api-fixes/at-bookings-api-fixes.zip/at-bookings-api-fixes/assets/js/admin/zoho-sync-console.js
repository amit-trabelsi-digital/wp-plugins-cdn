/**
 * Zoho Sync Console Logger
 * 
 * Provides detailed console logging for Zoho sync operations
 * Helps with debugging and monitoring sync processes
 * 
 * @package AT_Bookings_API_Fixes
 * @since 3.5.0
 */

(function() {
    'use strict';
    
    // Define global console logger
    window.ATZohoConsole = {
        
        /**
         * Formatting helper - colorize console output
         */
        styles: {
            group: 'color: #2196F3; font-weight: bold; font-size: 14px;',
            step: 'color: #1976D2; font-weight: bold;',
            request: 'color: #4CAF50;',
            response: 'color: #FF9800;',
            success: 'color: #4CAF50; font-weight: bold;',
            error: 'color: #F44336; font-weight: bold;',
            warning: 'color: #FF9800; font-weight: bold;',
            time: 'color: #999; font-size: 11px;'
        },
        
        /**
         * Get current timestamp
         */
        getTimestamp: function() {
            var now = new Date();
            var hours = String(now.getHours()).padStart(2, '0');
            var minutes = String(now.getMinutes()).padStart(2, '0');
            var seconds = String(now.getSeconds()).padStart(2, '0');
            return hours + ':' + minutes + ':' + seconds;
        },
        
        /**
         * Log sync start
         */
        syncStart: function(orderId) {
            var timestamp = this.getTimestamp();
            console.group('%c🔄 [' + timestamp + '] Syncing Order #' + orderId, this.styles.group);
            console.log('%cTimestamp: ' + new Date().toISOString(), this.styles.time);
            console.log('%cOrder ID: ' + orderId, this.styles.step);
        },
        
        /**
         * Log sync end
         */
        syncEnd: function(orderId, success) {
            var timestamp = this.getTimestamp();
            var icon = success ? '✓' : '✗';
            var message = success ? 'Sync completed successfully' : 'Sync completed with errors';
            var style = success ? this.styles.success : this.styles.error;
            
            console.log('%c' + icon + ' ' + message, style);
            console.log('%cEnd time: ' + timestamp, this.styles.time);
            console.groupEnd();
        },
        
        /**
         * Log individual step
         */
        step: function(stepNumber, stepName, module) {
            var timestamp = this.getTimestamp();
            console.group('%c📋 Step ' + stepNumber + ': ' + stepName, this.styles.step);
            console.log('%cModule: ' + module, this.styles.step);
            console.log('%cTime: ' + timestamp, this.styles.time);
        },
        
        /**
         * Log API request
         */
        apiRequest: function(action, data) {
            console.group('%c➡️ API Request', this.styles.request);
            console.log('%cAction: ' + action, this.styles.request);
            console.table(data);
            console.groupEnd();
        },
        
        /**
         * Log API response
         */
        apiResponse: function(response) {
            var success = response.success ? 'Yes' : 'No';
            var style = response.success ? this.styles.success : this.styles.error;
            
            console.group('%c⬅️ API Response', this.styles.response);
            console.log('%cSuccess: ' + success, style);
            
            if (response.id) {
                console.log('%cZoho ID: ' + response.id, this.styles.response);
            }
            
            if (response.message) {
                console.log('%cMessage: ' + response.message, this.styles.response);
            }
            
            if (response.data) {
                console.log('%cFull Response:', this.styles.response);
                console.table(response.data);
            }
            
            console.groupEnd();
        },
        
        /**
         * Log error
         */
        error: function(message, details) {
            console.group('%c❌ Error', this.styles.error);
            console.error('%c' + message, this.styles.error);
            
            if (details) {
                console.log('%cDetails:', this.styles.error);
                console.table(details);
            }
            
            console.groupEnd();
        },
        
        /**
         * Log warning
         */
        warning: function(message) {
            console.warn('%c⚠️ Warning: ' + message, this.styles.warning);
        },
        
        /**
         * Log info
         */
        info: function(message) {
            console.log('%cℹ️ ' + message, this.styles.step);
        },
        
        /**
         * Log search result
         */
        searchResult: function(module, field, value, found, data) {
            console.group('%c🔍 Search in ' + module, this.styles.step);
            console.log('%cField: ' + field + ' = ' + value, this.styles.step);
            console.log('%cFound: ' + (found ? 'Yes' : 'No'), found ? this.styles.success : this.styles.warning);
            
            if (found && data) {
                console.log('%cResult:', this.styles.step);
                console.table(data);
            }
            
            console.groupEnd();
        },
        
        /**
         * Log field mapping
         */
        fieldMapping: function(source, target) {
            console.group('%c🔗 Field Mapping', this.styles.step);
            console.log('%cSource → Target:', this.styles.step);
            console.table(target);
            console.groupEnd();
        },
        
        /**
         * Log summary
         */
        summary: function(results) {
            console.group('%c📊 Sync Summary', this.styles.group);
            
            var total = results.length || 0;
            var succeeded = 0;
            var failed = 0;
            
            if (results.length > 0) {
                results.forEach(function(result) {
                    if (result.success) {
                        succeeded++;
                    } else {
                        failed++;
                    }
                });
            }
            
            console.log('%cTotal Steps: ' + total, this.styles.step);
            console.log('%c✓ Succeeded: ' + succeeded, this.styles.success);
            console.log('%c✗ Failed: ' + failed, this.styles.error);
            
            console.table(results);
            console.groupEnd();
        }
    };
    
    // Expose globally for testing
    if (typeof window !== 'undefined') {
        window.ATZohoSync = window.ATZohoConsole;
    }
    
})();

// Example usage:
// ATZohoConsole.syncStart(1234);
// ATZohoConsole.step(1, 'Create Contact', 'Contacts');
// ATZohoConsole.apiRequest('Create Contact', {name: 'John Doe', email: 'john@example.com'});
// ATZohoConsole.apiResponse({success: true, id: '1234567890', message: 'Contact created'});
// ATZohoConsole.syncEnd(1234, true);

