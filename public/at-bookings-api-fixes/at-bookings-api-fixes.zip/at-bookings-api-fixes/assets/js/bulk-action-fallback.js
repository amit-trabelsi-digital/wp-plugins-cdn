/**
 * Gravity Forms Bulk Action Fallback
 * 
 * Adds "סנכרן ל-Zoho CRM" option to bulk actions dropdown
 * if it's missing from the PHP-generated options
 * 
 * @package AT_Bookings_API_Fixes
 * @version 1.0.0
 */

jQuery(document).ready(function($) {
    
    // הוסף את האופציה ל-bulk actions אם היא חסרה
    function addZohoBulkAction() {
        // בדוק אם אנחנו בדף Gravity Forms entries
        if (window.location.href.indexOf('page=gf_entries') === -1) {
            return; // לא בדף entries, לא צריך לעשות כלום
        }

        // המתן קצת כדי שה-DOM יהיה מוכן
        setTimeout(function() {
            
            // בחר את כל select dropdowns של bulk actions (יכולים להיות כמה)
            // WP_List_Table renders both top ('action') and bottom ('action2') selects.
            $('select[name="action"], select[name="action2"], select[name="bulk_action2"]').each(function() {
                var $select = $(this);
                
                // בדוק אם כבר קיימת האופציה
                if ($select.find('option[value="sync_to_zoho"]').length > 0) {
                    console.log('✅ Zoho bulk action already exists');
                    return; // אופציה כבר קיימת, דלג
                }
                
                // הוסף את האופציה
                $select.append(
                    $('<option>')
                        .attr('value', 'sync_to_zoho')
                        .text('סנכרן ל-Zoho CRM')
                );
                
                console.log('✅ Added "סנכרן ל-Zoho CRM" to bulk actions dropdown');
            });
            
        }, 100); // המתן 100ms
    }
    
    // הרץ כשהDOOM מוכן
    addZohoBulkAction();
    
    // אם הדף משתנה דינמית (AJAX), הרץ שוב
    $(document).on('click', 'a.page-numbers, input[type="submit"][name="doaction"], input[type="submit"][name="doaction2"]', function() {
        setTimeout(addZohoBulkAction, 500);
    });
    
    // בדוק כל 2 שניות (fallback - אם AJAX לא נתפס)
    setInterval(addZohoBulkAction, 2000);
});
