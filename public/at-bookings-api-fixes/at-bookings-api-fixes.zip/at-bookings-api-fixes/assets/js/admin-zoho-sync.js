/**
 * AT Bookings - Zoho Order Sync Interface
 * 
 * Handles real-time order synchronization testing with timeline and entity cards
 * 
 * @package AT_Bookings_API_Fixes
 * @since 3.0.0
 */

(function($) {
    'use strict';
    
    // Main sync object
    window.ATZohoSync = {
        currentOrderId: 0,
        isRunning: false,
        timeline: [],
        
        /**
         * Initialize the sync interface
         */
        init: function() {
            this.bindEvents();
            this.loadFieldValidation();
            this.initializeCollapsibles();

            // Load order if ID is provided and sync content is not already loaded
            const urlParams = new URLSearchParams(window.location.search);
            const orderId = urlParams.get('order_id');
            if (orderId) {
                this.currentOrderId = orderId;
                
                // Load timeline from localStorage
                this.loadTimelineFromStorage();
                
                if (!$('#at-sync-content').length) {
                    this.loadOrder(orderId);
                }
            }
        },
        
        /**
         * Bind event handlers
         */
        bindEvents: function() {
            // Order loading
            $('#at-load-order').on('click', this.handleLoadOrder.bind(this));
            $('#at-order-search').on('keypress', function(e) {
                if (e.which === 13) { // Enter key
                    $('#at-load-order').click();
                }
            });
            
            // Entity sync buttons
            $(document).on('click', '.at-sync-entity', this.handleSyncEntity.bind(this));
            
            // Entity search buttons
            $(document).on('click', '.at-search-entity', this.handleSearchEntity.bind(this));
            
            // Full sync controls
            $('#at-run-full-sync').on('click', this.handleRunFullSync.bind(this));
            $('#at-stop-sync').on('click', this.handleStopSync.bind(this));
            
            // Timeline clear button
            $(document).on('click', '#at-clear-timeline', this.handleClearTimeline.bind(this));
            
            // View full object button
            $(document).on('click', '.at-view-full-object', this.handleViewFullObject.bind(this));
        },
        
        /**
         * Load field validation
         */
        loadFieldValidation: function() {
            const $container = $('#at-field-checks');
            
            // Simulate field validation (would be real AJAX in production)
            $container.html(`
                <div class="at-field-check">
                    <span class="dashicons dashicons-yes-alt at-check-success"></span>
                    <strong>Products:</strong> PID, Tour_City, Tour_duration - ${atZohoSync.i18n.allFieldsPresent}
                </div>
                <div class="at-field-check">
                    <span class="dashicons dashicons-yes-alt at-check-success"></span>
                    <strong>Contacts:</strong> WP_User_ID - ${atZohoSync.i18n.allFieldsPresent}
                </div>
                <div class="at-field-check">
                    <span class="dashicons dashicons-yes-alt at-check-success"></span>
                    <strong>Cycles:</strong> Tour_SKU, WP_Booking_IDs - ${atZohoSync.i18n.allFieldsPresent}
                </div>
                <div class="at-field-check">
                    <span class="dashicons dashicons-yes-alt at-check-success"></span>
                    <strong>Sales_Orders:</strong> OID, BID - ${atZohoSync.i18n.allFieldsPresent}
                </div>
                <div class="at-field-check">
                    <span class="dashicons dashicons-yes-alt at-check-success"></span>
                    <strong>Leads:</strong> WP_OID, WP_BID, tour_date, Product_Interest - ${atZohoSync.i18n.allFieldsPresent}
                </div>
            `);
        },
        
        /**
         * Initialize collapsible sections
         */
        initializeCollapsibles: function() {
            $('.at-collapsible-header').on('click', function(e) {
                e.preventDefault();
                const $collapsible = $(this).closest('.at-collapsible');
                $collapsible.toggleClass('collapsed');
                
                // Save state to localStorage
                const id = $collapsible.attr('id') || 'field-validation';
                const isCollapsed = $collapsible.hasClass('collapsed');
                localStorage.setItem('at-sync-' + id, isCollapsed ? 'collapsed' : 'expanded');
            });
            
            // Restore collapsed state from localStorage
            $('.at-collapsible').each(function() {
                const id = $(this).attr('id') || 'field-validation';
                const state = localStorage.getItem('at-sync-' + id);
                if (state === 'collapsed') {
                    $(this).addClass('collapsed');
                }
            });
        },
        
        /**
         * Handle load order button
         */
        handleLoadOrder: function(e) {
            e.preventDefault();
            
            const orderId = $('#at-order-search').val().trim();
            if (!orderId) {
                if (window.ATNotify) {
                    ATNotify.warning(atZohoSync.i18n.enterOrderId);
                }
                return;
            }
            
            this.loadOrder(orderId);
        },
        
        /**
         * Load order data
         */
        loadOrder: function(orderId) {
            const $btn = $('#at-load-order');
            const originalText = $btn.text();
            
            $btn.prop('disabled', true).text(atZohoSync.i18n.loading);
            
            $.ajax({
                url: atZohoSync.ajaxurl,
                type: 'POST',
                data: {
                    action: 'at_zoho_sync_load_order',
                    nonce: atZohoSync.nonce,
                    order_id: orderId
                },
                success: function(response) {
                    if (response.success) {
                        // Update URL without reload
                        const url = new URL(window.location);
                        url.searchParams.set('order_id', orderId);
                        window.history.pushState({}, '', url);
                        
                        // Reload page to show sync interface
                        window.location.reload();
                    } else {
                        if (window.ATNotify) {
                            ATNotify.error(response.data);
                        }
                    }
                },
                error: function(xhr, status, error) {
                    if (window.ATNotify) {
                        ATNotify.error(atZohoSync.i18n.error + ': ' + error);
                    }
                },
                complete: function() {
                    $btn.prop('disabled', false).text(originalText);
                }
            });
        },
        
        /**
         * Handle search entity
         */
        handleSearchEntity: function(e) {
            e.preventDefault();
            
            const $btn = $(e.currentTarget);
            const entity = $btn.data('entity');
            const orderId = $btn.data('order-id');
            
            if (!entity || !orderId) {
                if (window.ATNotify) {
                    ATNotify.error(atZohoSync.i18n.missingParameters);
                }
                return;
            }
            
            this.searchEntity(entity, orderId, $btn);
        },
        
        /**
         * Search entity in Zoho
         */
        searchEntity: function(entity, orderId, $btn) {
            const originalHtml = $btn.html();
            
            $btn.prop('disabled', true).html('<span class="dashicons dashicons-search at-spin"></span> Searching...');
            
            // First, get search config options
            $.ajax({
                url: atZohoSync.ajaxurl,
                type: 'POST',
                data: {
                    action: 'at_zoho_sync_get_search_config',
                    nonce: atZohoSync.nonce,
                    order_id: orderId,
                    entity: entity
                },
                success: function(response) {
                    $btn.prop('disabled', false).html(originalHtml);
                    
                    if (response.success) {
                        const config = response.data;
                        ATZohoSync.showSearchDialog(entity, orderId, config);
                    } else {
                        if (window.ATNotify) {
                            ATNotify.error('Could not load search config: ' + response.data);
                        }
                    }
                },
                error: function(xhr, status, error) {
                    $btn.prop('disabled', false).html(originalHtml);
                    if (window.ATNotify) {
                        ATNotify.error('Error: ' + error);
                    }
                }
            });
        },
        
        /**
         * Show search dialog with editable query
         */
        showSearchDialog: function(entity, orderId, config) {
            const dialog = `
                <div id="at-search-dialog" style="display: none;">
                    <div style="background: white; padding: 20px; border-radius: 8px; max-width: 600px;">
                        <h3>${entity.charAt(0).toUpperCase() + entity.slice(1)} Search</h3>
                        <p style="color: #666; margin: 15px 0;">
                            <label style="display: block; margin-bottom: 10px;">
                                <strong>Search Field:</strong><br>
                                <select id="at-search-field" style="width: 100%; padding: 8px; margin-top: 5px;">
                                    ${Object.keys(config.field_options).map(field => 
                                        `<option value="${field}" ${field === config.default_field ? 'selected' : ''}>${field}</option>`
                                    ).join('')}
                                </select>
                            </label>
                        </p>
                        <p style="color: #666; margin: 15px 0;">
                            <label style="display: block; margin-bottom: 10px;">
                                <strong>Search Value:</strong><br>
                                <input type="text" id="at-search-value" style="width: 100%; padding: 8px; margin-top: 5px; box-sizing: border-box;" />
                            </label>
                        </p>
                        <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px;">
                            <button class="button button-secondary" onclick="jQuery('#at-search-dialog').hide(); jQuery(document).off('keydown.at-search');">Cancel</button>
                            <button class="button button-primary" onclick="ATZohoSync.performSearch('${entity}', ${orderId}, '${config.module}');">Search in Zoho</button>
                        </div>
                    </div>
                </div>
            `;
            
            if (jQuery('#at-search-dialog').length) {
                jQuery('#at-search-dialog').remove();
            }
            
            jQuery('body').append(dialog);
            
            // Set default values
            const fieldSelect = jQuery('#at-search-field');
            const valueInput = jQuery('#at-search-value');
            
            fieldSelect.on('change', function() {
                const field = jQuery(this).val();
                valueInput.val(config.field_options[field] || '');
            });
            
            // Set initial value
            valueInput.val(config.field_options[fieldSelect.val()] || '');
            
            // Show dialog with overlay
            const overlay = `<div id="at-search-overlay" style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 999; display: flex; align-items: center; justify-content: center;"></div>`;
            jQuery('body').append(overlay);
            jQuery('#at-search-overlay').append(jQuery('#at-search-dialog'));
            jQuery('#at-search-dialog').show();
            
            // Close on overlay click
            jQuery('#at-search-overlay').on('click', function(e) {
                if (e.target === this) {
                    jQuery(this).remove();
                    jQuery('#at-search-dialog').remove();
                }
            });
            
            // Close on ESC key
            jQuery(document).on('keydown.at-search', function(e) {
                if (e.keyCode === 27) {
                    jQuery('#at-search-overlay').remove();
                    jQuery('#at-search-dialog').remove();
                    jQuery(document).off('keydown.at-search');
                }
            });
        },
        
        /**
         * Perform actual search in Zoho
         */
        performSearch: function(entity, orderId, module) {
            const field = jQuery('#at-search-field').val();
            const value = jQuery('#at-search-value').val();
            
            if (!field || !value) {
                if (window.ATNotify) {
                    ATNotify.warning('Please enter search field and value');
                }
                return;
            }
            
            jQuery('#at-search-dialog').find('button').prop('disabled', true);
            
            $.ajax({
                url: atZohoSync.ajaxurl,
                type: 'POST',
                data: {
                    action: 'at_zoho_sync_search',
                    nonce: atZohoSync.nonce,
                    module: module,
                    search_field: field,
                    search_value: value
                },
                success: function(response) {
                    jQuery('#at-search-overlay').remove();
                    jQuery('#at-search-dialog').remove();
                    
                    if (response.success) {
                        const data = response.data;
                        let msg = `Found ${data.count} result(s) in Zoho ${module} where ${data.search_field} = "${data.search_value}"`;
                        
                        if (window.ATNotify) {
                            ATNotify.success(msg);
                        }
                        ATZohoSync.addTimelineEntry(entity, 'success', msg);
                    } else {
                        if (window.ATNotify) {
                            ATNotify.error('Search failed: ' + response.data);
                        }
                        ATZohoSync.addTimelineEntry(entity, 'error', 'Search failed: ' + response.data);
                    }
                },
                error: function(xhr, status, error) {
                    if (window.ATNotify) {
                        ATNotify.error('Error: ' + error);
                    }
                    ATZohoSync.addTimelineEntry(entity, 'error', 'Error: ' + error);
                },
                complete: function() {
                    jQuery('#at-search-dialog').find('button').prop('disabled', false);
                }
            });
        },
        
        /**
         * Handle individual entity sync
         */
        handleSyncEntity: function(e) {
            e.preventDefault();
            
            const $btn = $(e.currentTarget);
            const entity = $btn.data('entity');
            const orderId = $btn.data('order-id');
            
            if (!entity || !orderId) {
                if (window.ATNotify) {
                    ATNotify.error(atZohoSync.i18n.missingParameters);
                }
                return;
            }
            
            this.syncEntity(entity, orderId, $btn);
        },
        
        /**
         * Sync individual entity
         */
        syncEntity: function(entity, orderId, $btn) {
            const originalText = $btn.html();
            
            $btn.prop('disabled', true).html('<span class="dashicons dashicons-update at-spin"></span> ' + atZohoSync.i18n.syncing);
            
            // Add to timeline
            this.addTimelineEntry(entity, 'started', atZohoSync.i18n.syncStarted);
            
            // Use ATZohoConsole if available
            if (window.ATZohoConsole) {
                const moduleMap = {
                    'contact': 'Contacts',
                    'product': 'Products', 
                    'cycle': 'Cycles',
                    'order': 'Sales_Orders'
                };
                ATZohoConsole.step(0, 'Sync ' + entity, moduleMap[entity] || entity);
            }
            
            $.ajax({
                url: atZohoSync.ajaxurl,
                type: 'POST',
                data: {
                    action: 'at_zoho_sync_entity',
                    nonce: atZohoSync.nonce,
                    order_id: orderId,
                    entity: entity
                },
                success: function(response) {
                    // Use enhanced console logging
                    if (window.ATZohoConsole) {
                        ATZohoConsole.apiResponse(response.data || response);
                    } else {
                        console.log('Sync Entity Response:', response);
                    }
                    
                    if (response.success) {
                        ATZohoSync.addTimelineEntry(entity, 'success', response.data.message);
                        
                        // Update card with new Zoho ID
                        if (response.data.zoho_id) {
                            ATZohoSync.updateEntityCard(entity, response.data);
                        }
                        
                        if (window.ATNotify) {
                            ATNotify.success(response.data.message);
                        }
                    } else {
                        const errorMsg = typeof response.data === 'string' ? response.data : (response.data.message || 'Unknown error');
                        console.error('Sync failed:', response);
                        
                        ATZohoSync.addTimelineEntry(entity, 'error', 'An error occurred: ' + errorMsg);
                        
                        if (window.ATNotify) {
                            ATNotify.error(errorMsg);
                        }
                    }
                },
                error: function(xhr, status, error) {
                    ATZohoSync.addTimelineEntry(entity, 'error', atZohoSync.i18n.error + ': ' + error);
                    
                    if (window.ATNotify) {
                        ATNotify.error(atZohoSync.i18n.error + ': ' + error);
                    }
                },
                complete: function() {
                    $btn.prop('disabled', false).html(originalText);
                }
            });
        },
        
        /**
         * Handle full sync
         */
        handleRunFullSync: function(e) {
            e.preventDefault();
            
            if (this.isRunning) {
                return;
            }
            
            const orderId = this.currentOrderId || $('#at-order-search').val();
            if (!orderId) {
                if (window.ATNotify) {
                    ATNotify.warning(atZohoSync.i18n.selectOrder);
                }
                return;
            }
            
            this.runFullSync(orderId);
        },
        
        /**
         * Run full synchronization
         */
        runFullSync: function(orderId) {
            this.isRunning = true;
            this.currentOrderId = orderId;
            
            const $runBtn = $('#at-run-full-sync');
            const $stopBtn = $('#at-stop-sync');
            
            // Update UI
            $runBtn.hide();
            $stopBtn.show();
            
            // Clear timeline
            this.clearTimeline();
            
            // Add start entry
            this.addTimelineEntry('sync', 'started', atZohoSync.i18n.fullSyncStarted);
            
            // Use ATZohoConsole for full sync tracking
            if (window.ATZohoConsole) {
                ATZohoConsole.syncStart(orderId);
            }
            
            // Disable entity buttons
            $('.at-sync-entity').prop('disabled', true);
            
            $.ajax({
                url: atZohoSync.ajaxurl,
                type: 'POST',
                data: {
                    action: 'at_zoho_sync_run_all',
                    nonce: atZohoSync.nonce,
                    order_id: orderId
                },
                success: function(response) {
                    if (response.success) {
                        // Process each step with enhanced logging
                        if (response.data.steps) {
                            response.data.steps.forEach(function(step, index) {
                                const status = step.success ? 'success' : 'error';
                                ATZohoSync.addTimelineEntry(step.step || 'step', status, step.message);
                                
                                // Enhanced console logging
                                if (window.ATZohoConsole) {
                                    if (step.success) {
                                        ATZohoConsole.info('Step ' + (index + 1) + ': ' + step.message);
                                    } else {
                                        ATZohoConsole.error(step.message, step);
                                    }
                                }
                            });
                        }
                        
                        ATZohoSync.addTimelineEntry('sync', 'success', atZohoSync.i18n.fullSyncCompleted);
                        
                        // Close console group
                        if (window.ATZohoConsole) {
                            ATZohoConsole.syncEnd(orderId, true);
                            ATZohoConsole.summary(response.data.steps || []);
                        }
                        
                        if (window.ATNotify) {
                            ATNotify.success(atZohoSync.i18n.fullSyncCompleted);
                        }
                        
                        // Reload page to show updated data
                        setTimeout(function() {
                            window.location.reload();
                        }, 2000);
                        
                    } else {
                        ATZohoSync.addTimelineEntry('sync', 'error', response.data.message || atZohoSync.i18n.syncFailed);
                        
                        // Enhanced error logging
                        if (window.ATZohoConsole) {
                            ATZohoConsole.syncEnd(orderId, false);
                            ATZohoConsole.error(response.data.message || atZohoSync.i18n.syncFailed, response.data);
                        }
                        
                        if (window.ATNotify) {
                            ATNotify.error(response.data.message || atZohoSync.i18n.syncFailed);
                        }
                    }
                },
                error: function(xhr, status, error) {
                    ATZohoSync.addTimelineEntry('sync', 'error', atZohoSync.i18n.error + ': ' + error);
                    
                    // Enhanced error logging
                    if (window.ATZohoConsole) {
                        ATZohoConsole.syncEnd(orderId, false);
                        ATZohoConsole.error('AJAX Error: ' + error, {xhr: xhr, status: status});
                    }
                    
                    if (window.ATNotify) {
                        ATNotify.error(atZohoSync.i18n.error + ': ' + error);
                    }
                },
                complete: function() {
                    ATZohoSync.isRunning = false;
                    $runBtn.show();
                    $stopBtn.hide();
                    $('.at-sync-entity').prop('disabled', false);
                }
            });
        },
        
        /**
         * Handle stop sync
         */
        handleStopSync: function(e) {
            e.preventDefault();
            
            if (!this.isRunning) {
                return;
            }
            
            $.ajax({
                url: atZohoSync.ajaxurl,
                type: 'POST',
                data: {
                    action: 'at_zoho_sync_stop',
                    nonce: atZohoSync.nonce
                },
                success: function(response) {
                    if (response.success) {
                        ATZohoSync.addTimelineEntry('sync', 'warning', atZohoSync.i18n.syncStopped);
                        
                        if (window.ATNotify) {
                            ATNotify.warning(atZohoSync.i18n.syncStopped);
                        }
                    }
                }
            });
        },
        
        /**
         * Add entry to timeline
         */
        addTimelineEntry: function(entity, status, message) {
            const $timeline = $('#at-timeline-content');
            
            // Remove empty message if exists
            $timeline.find('.at-timeline-empty').remove();
            
            const timestamp = new Date().toLocaleTimeString('he-IL');
            const statusIcon = this.getStatusIcon(status);
            const entityLabel = this.getEntityLabel(entity);
            
            const entryHtml = `
                <div class="at-timeline-entry at-timeline-${status}">
                    <div class="at-timeline-time">${timestamp}</div>
                    <div class="at-timeline-content">
                        <span class="at-timeline-icon">${statusIcon}</span>
                        <strong>${entityLabel}:</strong> ${message}
                    </div>
                </div>
            `;
            
            $timeline.append(entryHtml);
            
            // Auto-scroll to bottom
            $timeline.scrollTop($timeline[0].scrollHeight);
            
            // Store in timeline array
            const entry = {
                entity: entity,
                status: status,
                message: message,
                timestamp: new Date().toISOString()
            };
            this.timeline.push(entry);
            
            // Save to localStorage
            this.saveTimelineToStorage();
        },
        
        /**
         * Save timeline to localStorage
         */
        saveTimelineToStorage: function() {
            if (!this.currentOrderId) return;
            
            const key = 'at_zoho_timeline_' + this.currentOrderId;
            try {
                localStorage.setItem(key, JSON.stringify(this.timeline));
            } catch (e) {
                console.error('Failed to save timeline to localStorage:', e);
            }
        },
        
        /**
         * Load timeline from localStorage
         */
        loadTimelineFromStorage: function() {
            if (!this.currentOrderId) return;
            
            const key = 'at_zoho_timeline_' + this.currentOrderId;
            try {
                const stored = localStorage.getItem(key);
                if (stored) {
                    this.timeline = JSON.parse(stored);
                    
                    // Render stored timeline
                    const $timeline = $('#at-timeline-content');
                    $timeline.find('.at-timeline-empty').remove();
                    
                    this.timeline.forEach(entry => {
                        const date = new Date(entry.timestamp);
                        const timestamp = date.toLocaleTimeString('he-IL');
                        const statusIcon = this.getStatusIcon(entry.status);
                        const entityLabel = this.getEntityLabel(entry.entity);
                        
                        const entryHtml = `
                            <div class="at-timeline-entry at-timeline-${entry.status}">
                                <div class="at-timeline-time">${timestamp}</div>
                                <div class="at-timeline-content">
                                    <span class="at-timeline-icon">${statusIcon}</span>
                                    <strong>${entityLabel}:</strong> ${entry.message}
                                </div>
                            </div>
                        `;
                        
                        $timeline.append(entryHtml);
                    });
                    
                    // Auto-scroll to bottom
                    $timeline.scrollTop($timeline[0].scrollHeight);
                }
            } catch (e) {
                console.error('Failed to load timeline from localStorage:', e);
            }
        },
        
        /**
         * Clear timeline and localStorage
         */
        handleClearTimeline: function() {
            if (!confirm('האם אתה בטוח שברצונך למחוק את היסטוריית הסנכרון?')) {
                return;
            }
            
            this.clearTimeline();
            
            // Clear from localStorage
            if (this.currentOrderId) {
                const key = 'at_zoho_timeline_' + this.currentOrderId;
                try {
                    localStorage.removeItem(key);
                } catch (e) {
                    console.error('Failed to clear timeline from localStorage:', e);
                }
            }
            
            if (window.ATNotify) {
                ATNotify.success('היסטוריית הסנכרון נמחקה');
            }
        },
        
        /**
         * Clear timeline
         */
        clearTimeline: function() {
            $('#at-timeline-content').html('<div class="at-timeline-empty">' + atZohoSync.i18n.timelineEmpty + '</div>');
            this.timeline = [];
        },
        
        /**
         * Update entity card with new data
         */
        updateEntityCard: function(entity, data) {
            const $card = $(`.at-entity-card[data-entity="${entity}"]`);
            
            if (data.zoho_id) {
                const $status = $card.find('.at-card-status');
                $status.html(`
                    <span class="at-status-connected">
                        <a href="${data.zoho_url || '#'}" target="_blank">${data.zoho_id}</a>
                    </span>
                `);
            }
            
            // Update action button text
            const $btn = $card.find('.at-sync-entity');
            $btn.html('<span class="dashicons dashicons-update"></span> ' + atZohoSync.i18n.update);
            
            // CRITICAL: If contact or cycle was synced, refresh order preview
            // Order depends on contact_id and cycle_id - rebuild preview with new IDs
            if (entity === 'contact' || entity === 'cycle') {
                console.log('🔄 Refreshing order preview after ' + entity + ' sync...');
                this.refreshOrderPreview();
            }
        },
        
        /**
         * Refresh order preview (rebuild with current IDs)
         */
        refreshOrderPreview: function() {
            const orderId = this.currentOrderId;
            if (!orderId) return;
            
            $.ajax({
                url: atZohoSync.ajaxurl,
                type: 'POST',
                data: {
                    action: 'at_zoho_sync_load_order',
                    nonce: atZohoSync.nonce,
                    order_id: orderId
                },
                success: function(response) {
                    if (response.success && response.data.entities) {
                        // Update order card preview with fresh data
                        const orderEntity = response.data.entities.order;
                        if (orderEntity && orderEntity.preview) {
                            const $orderCard = $('.at-entity-card[data-entity="order"]');
                            const $preview = $orderCard.find('.at-card-preview');
                            
                            // Update preview display
                            $preview.html('<pre style="max-height: 300px; overflow: auto;">' + 
                                JSON.stringify(orderEntity.preview, null, 2) + '</pre>');
                            
                            console.log('✅ Order preview refreshed');
                            console.log('New order data:', orderEntity.preview);
                        }
                    }
                },
                error: function() {
                    console.warn('Failed to refresh order preview');
                }
            });
        },
        
        /**
         * Get status icon
         */
        getStatusIcon: function(status) {
            const icons = {
                'started': '<span class="dashicons dashicons-update at-spin"></span>',
                'success': '<span class="dashicons dashicons-yes-alt" style="color: #00a32a;"></span>',
                'error': '<span class="dashicons dashicons-dismiss" style="color: #d63638;"></span>',
                'warning': '<span class="dashicons dashicons-warning" style="color: #dba617;"></span>'
            };
            
            return icons[status] || '<span class="dashicons dashicons-marker"></span>';
        },
        
        /**
         * Get entity label
         */
        getEntityLabel: function(entity) {
            const labels = {
                'contact': atZohoSync.i18n.contact,
                'product': atZohoSync.i18n.product,
                'cycle': atZohoSync.i18n.cycle,
                'order': atZohoSync.i18n.order,
                'sync': atZohoSync.i18n.fullSync,
                'step': atZohoSync.i18n.step
            };
            
            return labels[entity] || entity;
        },
        
        /**
         * Handle view full object - show complete JSON
         */
        handleViewFullObject: function(e) {
            e.preventDefault();
            
            const $btn = $(e.currentTarget);
            const entity = $btn.data('entity');
            const orderId = $btn.data('order-id');
            
            // Use different endpoint based on entity
            let action, dataKey;
            
            if (entity === 'order') {
                // For order - use dedicated endpoint that builds with AT_Zoho_Mapper
                action = 'at_zoho_get_order_object';
                dataKey = 'object';
            } else {
                // For other entities - use standard load
                action = 'at_zoho_sync_load_order';
                dataKey = 'entities';
            }
            
            // Load fresh data from server
            $.ajax({
                url: atZohoSync.ajaxurl,
                type: 'POST',
                data: {
                    action: action,
                    nonce: atZohoSync.nonce,
                    order_id: orderId
                },
                success: function(response) {
                    if (response.success) {
                        let preview;
                        
                        if (entity === 'order' && response.data.object) {
                            preview = response.data.object;
                            
                            // Show meta info
                            if (response.data.meta_info) {
                                console.group('ℹ️ Meta Information');
                                console.table(response.data.meta_info);
                                console.groupEnd();
                            }
                        } else if (response.data.entities && response.data.entities[entity]) {
                            preview = response.data.entities[entity].preview || {};
                        } else {
                            alert('Failed to load object data');
                            return;
                        }
                        
                        // Create modal with full object
                        ATZohoSync.showFullObjectModal(entity, preview, orderId);
                        
                        // Also log to console for developers
                        console.group('📋 Full ' + entity.toUpperCase() + ' Object (Order #' + orderId + ')');
                        console.log('Will be sent to Zoho:', preview);
                        console.log('JSON String:');
                        console.log(JSON.stringify(preview, null, 2));
                        console.groupEnd();
                    } else {
                        alert('Failed to load object data: ' + (response.data || 'Unknown error'));
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', {xhr, status, error});
                    alert('Error loading object data: ' + error);
                }
            });
        },
        
        /**
         * Show full object modal
         */
        showFullObjectModal: function(entity, data, orderId) {
            // Remove existing modal
            $('#at-object-modal').remove();
            
            const jsonString = JSON.stringify(data, null, 2);
            const entityLabel = entity.charAt(0).toUpperCase() + entity.slice(1);
            
            // Create modal HTML
            const modal = $(`
                <div id="at-object-modal" style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; 
                     background: rgba(0,0,0,0.7); z-index: 999999; display: flex; align-items: center; justify-content: center;">
                    <div style="background: white; padding: 20px; border-radius: 8px; max-width: 900px; max-height: 85vh; 
                         overflow: auto; width: 95%; box-shadow: 0 4px 20px rgba(0,0,0,0.3);">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; 
                             border-bottom: 2px solid #0073aa; padding-bottom: 10px;">
                            <h2 style="margin: 0;">
                                📋 ${entityLabel} Object 
                                <small style="color: #666;">(Order #${orderId})</small>
                            </h2>
                            <button type="button" class="button" style="padding: 5px 15px;">✕ Close</button>
                        </div>
                        
                        <div style="margin-bottom: 15px; display: flex; gap: 10px;">
                            <button type="button" class="button button-primary at-copy-json">
                                📋 Copy JSON
                            </button>
                            <button type="button" class="button at-refresh-preview">
                                🔄 Refresh
                            </button>
                            <span style="flex: 1; text-align: right; color: #666; font-size: 12px; padding: 5px;">
                                ${Object.keys(data).length} fields
                            </span>
                        </div>
                        
                        <pre class="at-json-preview" style="background: #282c34; color: #abb2bf; padding: 15px; border-radius: 4px; 
                             overflow: auto; max-height: 500px; font-family: 'Courier New', monospace; font-size: 13px; 
                             line-height: 1.6; margin: 0;"></pre>
                        
                        <div style="margin-top: 15px; padding: 12px; background: #e7f3ff; border-left: 4px solid #0073aa; border-radius: 4px; font-size: 12px;">
                            <strong>💡 Developer Info:</strong><br>
                            • This is the exact object that will be sent to Zoho CRM<br>
                            • Arrays shown as subforms (not JSON strings) ✅<br>
                            • Check console (F12) for the same data<br>
                            • Click "Refresh" to rebuild with latest IDs from meta fields
                        </div>
                    </div>
                </div>
            `);
            
            // Set JSON content
            modal.find('.at-json-preview').text(jsonString);
            
            // Bind events
            modal.find('.button:contains("✕")').on('click', function() {
                modal.remove();
            });
            
            modal.find('.at-copy-json').on('click', function() {
                navigator.clipboard.writeText(jsonString).then(function() {
                    alert('✅ JSON copied to clipboard!');
                }, function() {
                    // Fallback
                    const textarea = document.createElement('textarea');
                    textarea.value = jsonString;
                    document.body.appendChild(textarea);
                    textarea.select();
                    document.execCommand('copy');
                    document.body.removeChild(textarea);
                    alert('✅ JSON copied!');
                });
            });
            
            modal.find('.at-refresh-preview').on('click', function() {
                modal.remove();
                // Trigger view again to get fresh data
                $('.at-view-full-object[data-entity="' + entity + '"][data-order-id="' + orderId + '"]').click();
            });
            
            // Close on overlay click
            modal.on('click', function(e) {
                if (e.target.id === 'at-object-modal') {
                    modal.remove();
                }
            });
            
            // ESC key to close
            $(document).on('keydown.at-modal', function(e) {
                if (e.key === 'Escape' || e.keyCode === 27) {
                    modal.remove();
                    $(document).off('keydown.at-modal');
                }
            });
            
            $('body').append(modal);
        }
    };
    
    // Initialize when document is ready
    $(document).ready(function() {
        if (typeof atZohoSync !== 'undefined') {
            ATZohoSync.init();
        }
    });
    
})(jQuery);

// CSS animations
const style = document.createElement('style');
style.textContent = `
    .at-spin {
        animation: at-spin 1s linear infinite;
    }
    
    @keyframes at-spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
    }
    
    .at-timeline-entry {
        display: flex;
        padding: 10px;
        border-bottom: 1px solid #eee;
        animation: at-fade-in 0.3s ease-in;
    }
    
    @keyframes at-fade-in {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .at-timeline-time {
        width: 80px;
        font-size: 12px;
        color: #666;
        flex-shrink: 0;
    }
    
    .at-timeline-content {
        flex: 1;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .at-timeline-success {
        background-color: #f0f8f0;
        border-left: 3px solid #00a32a;
    }
    
    .at-timeline-error {
        background-color: #fdf2f2;
        border-left: 3px solid #d63638;
    }
    
    .at-timeline-warning {
        background-color: #fef8e7;
        border-left: 3px solid #dba617;
    }
    
    .at-entity-card {
        background: white;
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    .at-card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
        border-bottom: 1px solid #eee;
        padding-bottom: 10px;
    }
    
    .at-card-header h3 {
        margin: 0;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .at-status-connected {
        color: #00a32a;
        font-weight: bold;
    }
    
    .at-status-not-found {
        color: #d63638;
        font-style: italic;
    }
    
    .at-sync-interface {
        display: grid;
        grid-template-columns: 2fr 1fr;
        gap: 20px;
        margin-top: 20px;
    }
    
    .at-sync-controls {
        text-align: center;
        margin: 20px 0;
    }
    
    .at-sync-timeline {
        background: white;
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 20px;
        max-height: 600px;
    }
    
    .at-timeline-content {
        max-height: 500px;
        overflow-y: auto;
        border: 1px solid #eee;
        border-radius: 4px;
    }
    
    .at-field-validation {
        background: white;
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 20px;
        margin-bottom: 20px;
    }
    
    .at-field-check {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 8px 0;
        border-bottom: 1px solid #f0f0f0;
    }
    
    .at-field-check:last-child {
        border-bottom: none;
    }
    
    .at-check-success {
        color: #00a32a;
    }
    
    .at-check-error {
        color: #d63638;
    }
`;
document.head.appendChild(style);
