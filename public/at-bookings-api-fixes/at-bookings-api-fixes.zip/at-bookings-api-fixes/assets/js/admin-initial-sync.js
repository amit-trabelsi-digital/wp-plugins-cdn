/**
 * Initial Sync Admin Controller
 * Handles product/cycle/order synchronization UI
 */

(function($) {
    'use strict';

    const InitialSyncController = {
        currentSyncType: null,
        isSyncing: false,
        currentOffset: 0,
        currentBatch: 0,
        totalBatches: 0,

        init: function() {
            this.bindEvents();
        },

        bindEvents: function() {
            const self = this;

            // Tab switching
            $('.at-tab-trigger').on('click', function(e) {
                e.preventDefault();
                const tabName = $(this).data('tab');
                self.switchTab(tabName);
            });

            // Start sync buttons
            $('.at-sync-start-btn').on('click', function() {
                const syncType = $(this).data('sync-type');
                self.startSync(syncType);
            });

            // Stop sync buttons
            $('.at-sync-stop-btn').on('click', function() {
                const syncType = $(this).data('sync-type');
                self.stopSync(syncType);
            });
            
            // Reset metadata buttons
            $('.at-reset-metadata-btn').on('click', function() {
                const syncType = $(this).data('sync-type');
                self.resetMetadata(syncType);
            });
            
            // Clear cache button
            $('#clear-cycles-cache-btn').on('click', function() {
                self.clearCyclesCache();
            });
        },

        switchTab: function(tabName) {
            // Update active tab
            $('.nav-tab').removeClass('nav-tab-active');
            $('.nav-tab[data-tab="' + tabName + '"]').addClass('nav-tab-active');

            // Show/hide content
            $('.at-tab-content').removeClass('active');
            $('.at-tab-' + tabName).addClass('active');

            this.currentSyncType = tabName;
        },

        startSync: function(syncType) {
            const self = this;
            
            // For cycles, show preview dialog first
            if (syncType === 'cycles') {
                this.showCyclesPreview(function() {
                    self.executeSync(syncType);
                });
            } else {
                this.executeSync(syncType);
            }
        },
        
        showCyclesPreview: function(onConfirm) {
            const self = this;
            const params = {
                action: 'at_initial_sync_get_cycles',
                nonce: atInitialSync.nonce,
                start_date: $('#cycles-start-date').val(),
                end_date: $('#cycles-end-date').val(),
                batch_size: parseInt($('#cycles-batch-size').val()) || 20,
                sync_all: $('#cycles-sync-all').is(':checked') ? 1 : 0,
                with_bookings_only: $('#cycles-with-bookings-only').is(':checked') ? 1 : 0
            };
            
            // Show loading
            const $btn = $('.at-sync-start-btn[data-sync-type="cycles"]');
            const originalHtml = $btn.html();
            $btn.html('<span class="dashicons dashicons-update at-spin"></span> טוען...').prop('disabled', true);
            
            $.post(ajaxurl, params, function(response) {
                $btn.html(originalHtml).prop('disabled', false);
                
                if (response.success) {
                    const count = response.data.count || 0;
                    const preview = response.data.preview || [];
                    const hasMore = response.data.has_more || false;
                    
                    if (count === 0) {
                        alert('❌ לא נמצאו מחזורים בטווח התאריכים שנבחר.\n\nנסה להרחיב את טווח התאריכים.');
                        return;
                    }
                    
                    // Build preview list
                    let previewText = '';
                    if (preview.length > 0) {
                        previewText += '\n\nרשימה חלקית (עד 20 ראשונים):\n';
                        previewText += '═══════════════════════════════\n';
                        preview.forEach(function(cycle, idx) {
                            previewText += (idx + 1) + '. ' + cycle.product_name + '\n';
                            previewText += '   📅 ' + cycle.date + ' ' + cycle.time;
                            if (cycle.city) {
                                previewText += ' | 📍 ' + cycle.city;
                            }
                            previewText += '\n';
                            previewText += '   🆔 ' + cycle.tour_id + '\n\n';
                        });
                        
                        if (hasMore) {
                            previewText += '... ועוד ' + (count - 20) + ' מחזורים\n';
                        }
                    }
                    
                    // Show confirmation dialog
                    const message = '🔍 נמצאו ' + count + ' מחזורים לסנכרון\n\n' +
                                  '📆 תאריכים: ' + params.start_date + ' ← ' + params.end_date + '\n' +
                                  '📦 גודל batch: ' + params.batch_size + 
                                  previewText +
                                  '\n═══════════════════════════════\n' +
                                  'להמשיך בסנכרון?';
                    
                    if (confirm(message)) {
                        onConfirm();
                    }
                } else {
                    alert('❌ שגיאה בטעינת מחזורים: ' + (response.data || 'Unknown error'));
                }
            }).fail(function(xhr) {
                $btn.html(originalHtml).prop('disabled', false);
                alert('❌ שגיאת רשת: ' + xhr.statusText);
            });
        },
        
        executeSync: function(syncType) {
            const self = this;
            this.currentSyncType = syncType;
            this.isSyncing = true;
            this.currentOffset = 0;
            this.currentBatch = 0;

            // Disable buttons
            $('.at-sync-start-btn[data-sync-type="' + syncType + '"]').prop('disabled', true);
            $('.at-sync-stop-btn[data-sync-type="' + syncType + '"]').prop('disabled', false);

            // Show progress
            $('#' + syncType + '-progress').closest('.at-sync-progress').addClass('active');

            // Clear log
            $('#' + syncType + '-log').html('');

            this.addLogEntry(syncType, 'info', 'Starting sync...');

            // Get parameters
            const params = this.getParameters(syncType);

            // Start sync process
            this.syncBatch(syncType, params);
        },

        getParameters: function(syncType) {
            const params = {
                action: 'at_initial_sync_sync_' + syncType,
                nonce: atInitialSync.nonce,
            };

            if (syncType === 'products') {
                params.batch_size = parseInt($('#products-batch-size').val()) || 10;
                params.sync_all = $('#products-sync-all').is(':checked') ? 1 : 0;
                params.force_create = $('#products-force-create').is(':checked') ? 1 : 0;
                
                // DEBUG: Log the force_create value
                console.log('🔍 Force Create Value:', params.force_create, 'Checkbox checked:', $('#products-force-create').is(':checked'));
            } else if (syncType === 'cycles') {
                params.batch_size = parseInt($('#cycles-batch-size').val()) || 20;
                params.sync_all = $('#cycles-sync-all').is(':checked') ? 1 : 0;
                params.start_date = $('#cycles-start-date').val();
                params.end_date = $('#cycles-end-date').val();
                params.with_bookings_only = $('#cycles-with-bookings-only').is(':checked') ? 1 : 0;
            } else if (syncType === 'orders') {
                params.batch_size = parseInt($('#orders-batch-size').val()) || 15;
                params.sync_all = $('#orders-sync-all').is(':checked') ? 1 : 0;
                params.start_date = $('#orders-start-date').val();
                params.order_status = $('#orders-status').val();
            }

            return params;
        },

        syncBatch: function(syncType, params) {
            const self = this;

            if (!this.isSyncing) {
                this.addLogEntry(syncType, 'warning', 'Sync stopped by user');
                return;
            }

            params.offset = this.currentOffset;

            $.ajax({
                url: atInitialSync.ajaxurl,
                type: 'POST',
                data: params,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        self.currentBatch++;
                        const result = response.data.result;

                        // Log batch results
                        if (result.success_count > 0) {
                            self.addLogEntry(syncType, 'success', 
                                'Batch ' + self.currentBatch + ': ' + result.success_count + ' synced successfully');
                        }
                        if (result.error_count > 0) {
                            self.addLogEntry(syncType, 'error', 
                                'Batch ' + self.currentBatch + ': ' + result.error_count + ' failed');
                        }

                        // Log individual record details
                        if (result.records && result.records.length > 0) {
                            result.records.forEach(function(record) {
                                let message = record.name || record.order_number || 'Record #' + record.id;
                                const status = record.success ? 'success' : 'error';
                                
                                // Add diagnostic info for products
                                if (record.sku !== undefined || record.wc_pid !== undefined) {
                                    message += ' [SKU: ' + (record.sku || '(empty)') + ', PID: ' + record.wc_pid + ']';
                                }
                                
                                self.addLogEntry(syncType, status, message + ': ' + record.message);
                                
                                // Log debug information if available
                                if (record.debug) {
                                    const debugStr = JSON.stringify(record.debug, null, 2);
                                    console.log('Debug info for record #' + record.id + ':', record.debug);
                                    self.addLogEntry(syncType, 'info', '[DEBUG] ' + debugStr.substring(0, 150) + (debugStr.length > 150 ? '...' : ''));
                                }
                            });
                        }

                        // Update progress
                        self.updateProgress(syncType, self.currentBatch);

                        // Check if done
                        if (response.data.done) {
                            self.isSyncing = false;
                            self.addLogEntry(syncType, 'info', 'Sync complete!');
                            self.finishSync(syncType);
                        } else {
                            // Continue to next batch
                            self.currentOffset = response.data.offset;
                            setTimeout(function() {
                                self.syncBatch(syncType, params);
                            }, 500);
                        }
                    } else {
                        self.addLogEntry(syncType, 'error', response.data || 'Unknown error');
                        self.finishSync(syncType);
                    }
                },
                error: function(xhr, status, error) {
                    self.addLogEntry(syncType, 'error', 'AJAX error: ' + error);
                    self.finishSync(syncType);
                }
            });
        },

        stopSync: function(syncType) {
            const self = this;
            this.isSyncing = false;

            $.ajax({
                url: atInitialSync.ajaxurl,
                type: 'POST',
                data: {
                    action: 'at_initial_sync_stop',
                    nonce: atInitialSync.nonce,
                },
                dataType: 'json',
                success: function(response) {
                    self.addLogEntry(syncType, 'warning', atInitialSync.i18n.syncStopped);
                    self.finishSync(syncType);
                }
            });
        },

        updateProgress: function(syncType, batchNum) {
            const percentage = Math.min((batchNum * 20), 100); // Rough estimate
            $('#' + syncType + '-progress').css('width', percentage + '%');
            $('#' + syncType + '-progress-text').text(percentage + '%');
        },

        finishSync: function(syncType) {
            // Re-enable buttons
            $('.at-sync-start-btn[data-sync-type="' + syncType + '"]').prop('disabled', false);
            $('.at-sync-stop-btn[data-sync-type="' + syncType + '"]').prop('disabled', true);

            // Update status
            const status = this.isSyncing ? 'Running...' : 'Completed';
            $('#' + syncType + '-status, #' + syncType + '-status-display').text(status);
        },

        addLogEntry: function(syncType, type, message) {
            const timestamp = new Date().toLocaleTimeString();
            const entry = $('<div class="at-log-entry ' + type + '">' + 
                '[' + timestamp + '] ' + message + 
                '</div>');

            const console = $('#' + syncType + '-log');
            console.append(entry);

            // Scroll to bottom
            console.scrollTop(console.prop('scrollHeight'));
        },
        
        resetMetadata: function(syncType) {
            const self = this;
            
            if (!confirm('האם אתה בטוח שברצונך לנקות את כל מידע הסנכרון?\n\nפעולה זו תמחק:\n• מזהה זוהו (_zoho_product_id)\n• מצב סנכרון (_at_zoho_sync_state)\n• תאריך סנכרון אחרון\n• SKU (מקט) של מוצרים עם מזהה זוהו\n\nלאחר ניקוי תוכל לסנכרן את המוצרים מחדש.')) {
                return;
            }
            
            const $btn = $('.at-reset-metadata-btn[data-sync-type="' + syncType + '"]');
            const originalHtml = $btn.html();
            
            // Disable button during operation
            $btn.prop('disabled', true).html('<span class="dashicons dashicons-update spinning"></span> מנקה...');
            
            this.addLogEntry(syncType, 'info', 'מנקה מטא-דאטה של סנכרון...');
            
            $.ajax({
                url: atInitialSync.ajaxurl,
                type: 'POST',
                data: {
                    action: 'at_initial_sync_reset_metadata',
                    nonce: atInitialSync.nonce,
                    sync_type: syncType,
                    reset_sku: true  // Also reset SKU if it's a Zoho ID
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        self.addLogEntry(syncType, 'success', response.data.message + ' (' + response.data.count + ' מוצרים)');
                        alert('✅ הצלחה!\n\n' + response.data.message + '\n\nכעת תוכל לסנכרן את המוצרים מחדש.');
                    } else {
                        self.addLogEntry(syncType, 'error', response.data || 'שגיאה לא ידועה');
                        alert('❌ שגיאה!\n\n' + (response.data || 'שגיאה לא ידועה'));
                    }
                    
                    // Re-enable button
                    $btn.prop('disabled', false).html(originalHtml);
                },
                error: function(xhr, status, error) {
                    self.addLogEntry(syncType, 'error', 'AJAX error: ' + error);
                    alert('❌ שגיאת רשת!\n\n' + error);
                    
                    // Re-enable button
                    $btn.prop('disabled', false).html(originalHtml);
                }
            });
        },
        
        clearCyclesCache: function() {
            const self = this;
            
            if (!confirm('Clear all cycle cache?\n\nThis will force fresh lookups in Zoho on next sync.')) {
                return;
            }
            
            const $btn = $('#clear-cycles-cache-btn');
            const originalHtml = $btn.html();
            
            // Disable button during operation
            $btn.prop('disabled', true).html('<span class="dashicons dashicons-update spinning"></span> Clearing...');
            
            this.addLogEntry('cycles', 'info', 'Clearing cycle cache...');
            
            $.ajax({
                url: atInitialSync.ajaxurl,
                type: 'POST',
                data: {
                    action: 'at_clear_cycles_cache',
                    nonce: atInitialSync.nonce
                },
                success: function(response) {
                    if (response.success) {
                        self.addLogEntry('cycles', 'success', '✅ ' + response.data.message);
                        alert('✅ Cache cleared!\n\n' + response.data.count + ' cycle cache entries removed.');
                    } else {
                        self.addLogEntry('cycles', 'error', '❌ ' + (response.data || 'Cache clear failed'));
                        alert('❌ Error clearing cache!\n\n' + (response.data || 'Unknown error'));
                    }
                    
                    // Re-enable button
                    $btn.prop('disabled', false).html(originalHtml);
                },
                error: function(xhr, status, error) {
                    self.addLogEntry('cycles', 'error', 'AJAX error: ' + error);
                    alert('❌ Network error!\n\n' + error);
                    
                    // Re-enable button
                    $btn.prop('disabled', false).html(originalHtml);
                }
            });
        }
    };

    // Initialize on document ready
    $(document).ready(function() {
        InitialSyncController.init();
    });

})(jQuery);

