/**
 * ZOHO WooCommerce Integration JavaScript
 * Handles sync buttons for products and orders
 */

jQuery(document).ready(function($) {
    console.log('🔷 ZOHO WooCommerce JS loaded');
    console.log('🔷 Product buttons found:', $('.at-zoho-sync-product').length);
    console.log('🔷 Order buttons found:', $('.at-zoho-sync-order').length);
    console.log('🔷 atZoho object:', atZoho);
    
    // Sync Product
    $('.at-zoho-sync-product').on('click', function(e) {
        console.log('🔷 Product sync button clicked!');
        e.preventDefault();
        
        var $button = $(this);
        var $result = $button.next('.at-zoho-sync-result');
        var productId = $button.data('product-id');
        
        // Show sync mode selection modal
        showSyncModeModal(
            'בחר אופן סנכרון',
            function(syncMode) {
                // User selected a mode
                $button.prop('disabled', true).text('מכין...');
                $result.html('').removeClass('success error');
                
                $.ajax({
                    url: atZoho.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'at_zoho_preview_product',
                        product_id: productId,
                        sync_mode: syncMode,
                        nonce: atZoho.product_nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            // Show confirmation modal
                            showConfirmationModal(
                                'אישור סנכרון מוצר',
                                response.data,
                                function() {
                                    // User confirmed - proceed with sync
                                    syncProduct(productId, $button, $result, syncMode);
                                },
                                function() {
                                    // User cancelled
                                    $button.prop('disabled', false).html('📤 סנכרון ל-ZOHO CRM');
                                }
                            );
                        } else {
                            $result.html('<span style="color: #dc3545;">✗ שגיאת תצוגה מקדימה: ' + response.data + '</span>');
                            $button.prop('disabled', false).html('📤 סנכרון ל-ZOHO CRM');
                        }
                    },
                    error: function(xhr, status, error) {
                        $result.html('<span style="color: #dc3545;">✗ שגיאת AJAX: ' + error + '</span>');
                        $button.prop('disabled', false).html('📤 סנכרון ל-ZOHO CRM');
                    }
                });
            },
            function() {
                // User cancelled
                $button.prop('disabled', false).html('📤 סנכרון ל-ZOHO CRM');
            }
        );
    });
    
    function syncProduct(productId, $button, $result, syncMode) {
        syncMode = syncMode || 'full'; // Default to full sync
        $button.prop('disabled', true).text(atZoho.strings.syncing);
        
        $.ajax({
            url: atZoho.ajax_url,
            type: 'POST',
            data: {
                action: 'at_zoho_sync_product',
                product_id: productId,
                sync_mode: syncMode,
                nonce: atZoho.product_nonce
            },
            success: function(response) {
                if (response.success) {
                    var syncModeText = syncMode === 'link_only' ? 'קישור ID' : 'סנכרון מלא';
                    $result.html('<span style="color: #28a745;">✓ ' + atZoho.strings.success + ' (' + syncModeText + ')</span>');
                    if (response.data.zoho_id) {
                        $result.append('<br><small><strong>ZOHO ID:</strong> ' + response.data.zoho_id + '</small>');
                    }
                    
                    // Reload page after 2 seconds to show updated meta
                    setTimeout(function() {
                        location.reload();
                    }, 2000);
                } else {
                    $result.html('<span style="color: #dc3545;">✗ ' + atZoho.strings.error + ' ' + response.data + '</span>');
                }
            },
            error: function(xhr, status, error) {
                $result.html('<span style="color: #dc3545;">✗ שגיאת AJAX: ' + error + '</span>');
            },
            complete: function() {
                $button.prop('disabled', false).html('📤 סנכרון ל-ZOHO CRM');
            }
        });
    }
    
    // Sync Order  
    $('.at-zoho-sync-order').on('click', function(e) {
        console.log('🔷 Order sync button clicked!');
        e.preventDefault();
        
        var $button = $(this);
        var $result = $button.next('.at-zoho-sync-result');
        var orderId = $button.data('order-id');
        
        // Step 1: Get preview data
        $button.prop('disabled', true).text('Preparing...');
        $result.html('').removeClass('success error');
        
        $.ajax({
            url: atZoho.ajax_url,
            type: 'POST',
            data: {
                action: 'at_zoho_preview_order',
                order_id: orderId,
                nonce: atZoho.order_nonce
            },
            success: function(response) {
                if (response.success) {
                    // Show confirmation modal
                    showConfirmationModal(
                        'Order Sync Confirmation',
                        response.data,
                        function() {
                            // User confirmed - proceed with sync
                            syncOrder(orderId, $button, $result);
                        },
                        function() {
                            // User cancelled
                            $button.prop('disabled', false).html('📤 Sync Order to ZOHO CRM');
                        }
                    );
                } else {
                    $result.html('<span style="color: #dc3545;">✗ Preview Error: ' + response.data + '</span>');
                    $button.prop('disabled', false).html('📤 Sync Order to ZOHO CRM');
                }
            },
            error: function(xhr, status, error) {
                $result.html('<span style="color: #dc3545;">✗ AJAX Error: ' + error + '</span>');
                $button.prop('disabled', false).html('📤 Sync Order to ZOHO CRM');
            }
        });
    });
    
    function syncOrder(orderId, $button, $result) {
        $button.prop('disabled', true).text(atZoho.strings.syncing);
        
        $.ajax({
            url: atZoho.ajax_url,
            type: 'POST',
            data: {
                action: 'at_zoho_sync_order',
                order_id: orderId,
                nonce: atZoho.order_nonce
            },
            success: function(response) {
                if (response.success) {
                    $result.html('<span style="color: #28a745;">✓ ' + atZoho.strings.success + '</span>');
                    if (response.data.contact_id) {
                        $result.append('<br><small><strong>Contact ID:</strong> ' + response.data.contact_id + '</small>');
                    }
                    if (response.data.order_id) {
                        $result.append('<br><small><strong>Order ID:</strong> ' + response.data.order_id + '</small>');
                    }
                    
                    // Reload page after 2 seconds to show updated meta
                    setTimeout(function() {
                        location.reload();
                    }, 2000);
                } else {
                    $result.html('<span style="color: #dc3545;">✗ ' + atZoho.strings.error + ' ' + response.data + '</span>');
                }
            },
            error: function(xhr, status, error) {
                $result.html('<span style="color: #dc3545;">✗ AJAX Error: ' + error + '</span>');
            },
            complete: function() {
                $button.prop('disabled', false).html('📤 Sync Order to ZOHO CRM');
            }
        });
    }
    
    // Sync Mode Selection Modal
    function showSyncModeModal(title, onSelect, onCancel) {
        var modalHtml = '<div id="at-zoho-mode-modal" style="display:none;">' +
            '<div style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); z-index: 999999;">' +
            '<div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: #fff; padding: 30px; border-radius: 8px; max-width: 500px; direction: rtl; box-shadow: 0 0 20px rgba(0,0,0,0.3);">' +
            '<h2 style="margin-top: 0; text-align: center;">' + title + '</h2>' +
            '<p style="text-align: center; color: #666; margin-bottom: 25px;">בחר את אופן הסנכרון:</p>' +
            '<div style="display: flex; gap: 15px; justify-content: center; flex-direction: column;">' +
            '<button id="at-zoho-mode-full" class="button button-primary" style="font-size: 14px; padding: 15px 20px; width: 100%; text-align: center; background: #0073aa; color: #fff; border: none; cursor: pointer;">' +
            '📤 סנכרון מלא<br><small style="font-size: 11px; font-weight: normal;">שידרוס את המידע בZOHO עם הנתונים מהאתר</small>' +
            '</button>' +
            '<button id="at-zoho-mode-link" class="button" style="font-size: 14px; padding: 15px 20px; width: 100%; text-align: center; background: #ffc107; color: #000; border: 1px solid #ffc107; cursor: pointer;">' +
            '🔗 קישור ID בלבד<br><small style="font-size: 11px; font-weight: normal;">ישמור רק את מזהי המוצרים (לא ישנה מידע קיים)</small>' +
            '</button>' +
            '</div>' +
            '<div style="text-align: center; margin-top: 20px;">' +
            '<button id="at-zoho-mode-cancel" class="button" style="font-size: 13px; padding: 8px 20px; color: #999;">ביטול</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>';
        
        $('body').append(modalHtml);
        $('#at-zoho-mode-modal').fadeIn(200);
        
        $('#at-zoho-mode-full').on('click', function(e) {
            e.preventDefault();
            $('#at-zoho-mode-modal').fadeOut(200, function() {
                $(this).remove();
            });
            onSelect('full');
        });
        
        $('#at-zoho-mode-link').on('click', function(e) {
            e.preventDefault();
            $('#at-zoho-mode-modal').fadeOut(200, function() {
                $(this).remove();
            });
            onSelect('link_only');
        });
        
        $('#at-zoho-mode-cancel').on('click', function(e) {
            e.preventDefault();
            $('#at-zoho-mode-modal').fadeOut(200, function() {
                $(this).remove();
            });
            onCancel();
        });
    }
    
    // Confirmation Modal
    function showConfirmationModal(title, data, onConfirm, onCancel) {
        var modalHtml = '<div id="at-zoho-confirm-modal" style="display:none;">' +
            '<div style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); z-index: 999999;">' +
            '<div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: #fff; padding: 30px; border-radius: 8px; max-width: 900px; max-height: 85vh; overflow: auto; direction: rtl;">' +
            '<h2 style="margin-top: 0;">' + title + '</h2>';
        
        // Show contact info
        if (data.contact) {
            modalHtml += '<div style="margin: 15px 0; padding: 15px; background: #e8f4f8; border: 1px solid #0073aa; border-radius: 4px;">';
            modalHtml += '<h3 style="margin-top: 0;">👤 איש קשר:</h3>';
            
            if (data.contact.existing) {
                modalHtml += '<div style="background: #fff3cd; border: 1px solid #ffc107; padding: 8px; margin-bottom: 10px; border-radius: 4px;">' +
                    '<strong>⚠️ איש קשר קיים נמצא!</strong><br>' +
                    'ZOHO ID: <code>' + data.contact.existing.id + '</code><br>' +
                    'פעולה: <strong>עדכון</strong>' +
                    '</div>';
            } else {
                modalHtml += '<div style="background: #d4edda; border: 1px solid #28a745; padding: 8px; margin-bottom: 10px; border-radius: 4px;">' +
                    '<strong>✨ איש קשר חדש ייווצר</strong>' +
                    '</div>';
            }
            
            modalHtml += '<pre style="background: #fff; padding: 10px; border: 1px solid #ddd; max-height: 200px; overflow: auto; direction: ltr; text-align: left; font-size: 11px;">' +
                JSON.stringify(data.contact.data || data.record.contact, null, 2) +
                '</pre>';
            
            // Add sync contact button
            if (!data.contact.existing) {
                modalHtml += '<button type="button" class="button button-small at-zoho-partial-sync" data-type="contact" style="margin-top: 10px;">📤 סנכרן איש קשר בלבד</button>';
            }
            
            modalHtml += '</div>';
        }
        
        // Show cycle info
        if (data.cycle) {
            modalHtml += '<div style="margin: 15px 0; padding: 15px; background: #fff4e6; border: 1px solid #ff9800; border-radius: 4px;">';
            modalHtml += '<h3 style="margin-top: 0;">🎫 מחזור סיור:</h3>';
            
            if (data.cycle.zoho_id) {
                modalHtml += '<div style="background: #fff3cd; border: 1px solid #ffc107; padding: 8px; margin-bottom: 10px; border-radius: 4px;">' +
                    '<strong>✓ מחזור קיים ב-ZOHO</strong><br>' +
                    'ZOHO ID: <code>' + data.cycle.zoho_id + '</code><br>' +
                    'פעולה: <strong>קישור</strong>' +
                    '</div>';
            } else {
                modalHtml += '<div style="background: #d4edda; border: 1px solid #28a745; padding: 8px; margin-bottom: 10px; border-radius: 4px;">' +
                    '<strong>✨ מחזור חדש ייווצר</strong>' +
                    '</div>';
            }
            
            if (data.cycle || data.record.cycle) {
                var cycle = data.cycle || data.record.cycle;
                modalHtml += '<div style="background: #fff; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 12px;">';
                
                if (cycle.product_name) {
                    modalHtml += '<strong>📍 סיור:</strong> ' + cycle.product_name + '<br>';
                }
                if (cycle.sku || cycle.product_zoho_id) {
                    modalHtml += '<strong>🔑 ZOHO Product ID:</strong> <code>' + (cycle.sku || cycle.product_zoho_id) + '</code><br>';
                }
                if (cycle.unique_id) {
                    modalHtml += '<strong>🆔 Cycle ID:</strong> <code>' + cycle.unique_id + '</code><br>';
                }
                if (cycle.start_date) {
                    modalHtml += '<strong>📅 תאריך:</strong> ' + cycle.start_date + '<br>';
                }
                if (cycle.start_time) {
                    modalHtml += '<strong>🕐 שעת התחלה:</strong> ' + cycle.start_time;
                    if (cycle.end_time) {
                        modalHtml += ' - ' + cycle.end_time;
                    }
                    if (cycle.duration) {
                        modalHtml += ' (' + cycle.duration + ' שעות)';
                    }
                    modalHtml += '<br>';
                }
                if (cycle.persons_total) {
                    modalHtml += '<strong>👥 סה"כ משתתפים:</strong> ' + cycle.persons_total + '<br>';
                }
                if (cycle.ticket_types && cycle.ticket_types.length > 0) {
                    modalHtml += '<strong>🎫 פירוט כרטיסים:</strong><br>';
                    modalHtml += '<ul style="margin: 5px 0; padding-right: 20px;">';
                    cycle.ticket_types.forEach(function(ticket) {
                        modalHtml += '<li>' + ticket.type + ': ' + ticket.quantity + '</li>';
                    });
                    modalHtml += '</ul>';
                }
                if (cycle.unit_price) {
                    modalHtml += '<strong>💰 מחיר יחידה:</strong> ₪' + cycle.unit_price;
                }
                
                modalHtml += '</div>';
            }
            
            // Add sync cycle button
            if (!data.cycle.zoho_id) {
                modalHtml += '<button type="button" class="button button-small at-zoho-partial-sync" data-type="cycle" style="margin-top: 10px;">📤 סנכרן מחזור בלבד</button>';
            }
            
            modalHtml += '</div>';
        }
        
        // Show order info
        if (data.order) {
            modalHtml += '<div style="margin: 15px 0; padding: 15px; background: #f0f8e8; border: 1px solid #46b450; border-radius: 4px;">';
            modalHtml += '<h3 style="margin-top: 0;">🛒 הזמנה:</h3>';
            
            if (data.order.existing) {
                modalHtml += '<div style="background: #fff3cd; border: 1px solid #ffc107; padding: 8px; margin-bottom: 10px; border-radius: 4px;">' +
                    '<strong>⚠️ הזמנה קיימת נמצאה!</strong><br>' +
                    'ZOHO ID: <code>' + data.order.existing.id + '</code><br>' +
                    'פעולה: <strong>עדכון</strong>' +
                    '</div>';
            } else {
                modalHtml += '<div style="background: #d4edda; border: 1px solid #28a745; padding: 8px; margin-bottom: 10px; border-radius: 4px;">' +
                    '<strong>✨ הזמנה חדשה תיווצר</strong>' +
                    '</div>';
            }
            
            if (data.record.order) {
                modalHtml += '<pre style="background: #fff; padding: 10px; border: 1px solid #ddd; max-height: 300px; overflow: auto; direction: ltr; text-align: left; font-size: 11px;">' +
                    JSON.stringify(data.record.order, null, 2) +
                    '</pre>';
            }
            
            modalHtml += '</div>';
        }
        
        // Simple record view (for products)
        if (data.record && !data.contact && !data.order) {
            if (data.existing) {
                modalHtml += '<div style="background: #fff3cd; border: 1px solid #ffc107; padding: 10px; margin: 15px 0; border-radius: 4px;">' +
                    '<strong>⚠️ רשומה קיימת נמצאה!</strong><br>' +
                    'ZOHO ID: <code>' + data.existing.id + '</code><br>' +
                    'פעולה: <strong>עדכון</strong>' +
                    '</div>';
            } else {
                modalHtml += '<div style="background: #d4edda; border: 1px solid #28a745; padding: 10px; margin: 15px 0; border-radius: 4px;">' +
                    '<strong>✨ רשומה חדשה תיווצר</strong>' +
                    '</div>';
            }
            
            modalHtml += '<h3>נתונים שישלחו ל-ZOHO:</h3>' +
                '<pre style="background: #fff; padding: 10px; border: 1px solid #ddd; max-height: 400px; overflow: auto; direction: ltr; text-align: left; font-size: 11px;">' +
                JSON.stringify(data.record, null, 2) +
                '</pre>';
        }
        
        modalHtml += '<div style="text-align: center; margin-top: 20px;">' +
            '<button id="at-zoho-confirm-yes" class="button button-primary" style="margin-left: 10px; font-size: 14px; padding: 8px 20px;">✓ אישור וסנכרון</button>' +
            '<button id="at-zoho-confirm-no" class="button" style="font-size: 14px; padding: 8px 20px;">✗ ביטול</button>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>';
        
        $('body').append(modalHtml);
        $('#at-zoho-confirm-modal').fadeIn(200);
        
        $('#at-zoho-confirm-yes').on('click', function() {
            $('#at-zoho-confirm-modal').fadeOut(200, function() {
                $(this).remove();
            });
            onConfirm();
        });
        
        $('#at-zoho-confirm-no').on('click', function() {
            $('#at-zoho-confirm-modal').fadeOut(200, function() {
                $(this).remove();
            });
            onCancel();
        });
        
        // Partial sync handlers
        $(document).on('click', '.at-zoho-partial-sync', function(e) {
            e.preventDefault();
            var syncType = $(this).data('type');
            var $button = $(this);
            var orderId = $('.at-zoho-sync-order').data('order-id');
            
            $button.prop('disabled', true).text('מסנכרן...');
            
            console.log('🔷 Partial sync requested:', syncType, 'for order:', orderId);
            
            var action = syncType === 'contact' ? 'at_zoho_sync_contact_only' : 'at_zoho_sync_cycle_only';
            
            $.ajax({
                url: atZoho.ajax_url,
                type: 'POST',
                data: {
                    action: action,
                    order_id: orderId,
                    nonce: atZoho.order_nonce
                },
                success: function(response) {
                    console.log('🔷 Partial sync response:', response);
                    
                    if (response.success) {
                        var message = syncType === 'contact' ? 
                            '✅ איש קשר סונכרן!\nZOHO ID: ' + response.data.contact_id :
                            '✅ מחזור סונכרן!\nZOHO ID: ' + response.data.cycle_id;
                        
                        alert(message + '\n\nעכשיו תוכל לסנכרן את ההזמנה.');
                        
                        // Close modal and reload page
                        $('#at-zoho-confirm-modal').fadeOut(200, function() {
                            $(this).remove();
                            location.reload();
                        });
                    } else {
                        alert('❌ שגיאה: ' + response.data);
                        $button.prop('disabled', false).text('📤 סנכרן ' + (syncType === 'contact' ? 'איש קשר' : 'מחזור') + ' בלבד');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('❌ Partial sync error:', error);
                    alert('❌ שגיאת AJAX: ' + error);
                    $button.prop('disabled', false).text('📤 סנכרן ' + (syncType === 'contact' ? 'איש קשר' : 'מחזור') + ' בלבד');
                }
            });
        });
    }
});

