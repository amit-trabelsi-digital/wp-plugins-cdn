/* Reading tools meta box: generate summary / audio via AJAX. */
(function () {
    'use strict';
    var box = document.querySelector('.at-ai-reading-box');
    if (!box || typeof atAiReading === 'undefined') { return; }

    var postId = box.getAttribute('data-post-id');
    var status = document.getElementById('at-ai-reading-status');
    var t = atAiReading.i18n;

    function say(msg) { if (status) { status.textContent = msg; } }

    function call(action, button, onOk) {
        if (!postId || postId === '0') { say(t.saveFirst); return; }
        button.disabled = true;
        say(t.working);
        var body = new URLSearchParams();
        body.set('action', action);
        body.set('nonce', atAiReading.nonce);
        body.set('post_id', postId);
        fetch(atAiReading.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body })
            .then(function (r) { return r.json(); })
            .then(function (res) {
                if (res && res.success) { onOk(res.data); say(t.done); }
                else { say(t.error + ': ' + (res && res.data && res.data.message ? res.data.message : '')); }
            })
            .catch(function () { say(t.error); })
            .then(function () { button.disabled = false; });
    }

    var sumBtn = document.getElementById('at-ai-gen-summary');
    if (sumBtn) {
        sumBtn.addEventListener('click', function () {
            call('at_ai_reading_generate_summary', sumBtn, function (d) {
                document.getElementById('at-ai-reading-summary').value = d.summary;
                var cb = box.querySelector('input[name="at_ai_reading_summary_approved"]');
                if (cb) { cb.checked = false; }
                document.getElementById('at-ai-reading-summary-stale').hidden = true;
            });
        });
    }

    var audBtn = document.getElementById('at-ai-gen-audio');
    if (audBtn) {
        audBtn.addEventListener('click', function () {
            call('at_ai_reading_generate_audio', audBtn, function (d) {
                var a = document.getElementById('at-ai-reading-audio');
                a.src = d.url;
                a.hidden = false;
                document.getElementById('at-ai-reading-tts-stale').hidden = true;
            });
        });
    }
})();
