<?php
/**
 * Chat settings page (content-finder chat).
 *
 * Self-contained submenu "Chat" so it does not touch the main settings tabs.
 *
 * @package WordPress_AI_Assistant
 * @since 1.10.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_AI_Chat_Settings {

    const GROUP = 'at_ai_assistant_chat_settings';

    public function __construct() {
        add_action('admin_menu', array($this, 'add_menu'), 30);
        add_action('admin_init', array($this, 'register'));
    }

    public function add_menu() {
        add_submenu_page(
            'wordpress-ai-assistant',
            __('Chat', 'wordpress-ai-assistant'),
            __('Chat', 'wordpress-ai-assistant'),
            'manage_options',
            'wordpress-ai-assistant-chat',
            array($this, 'render')
        );
    }

    private function fields() {
        $bool = array('type' => 'boolean', 'sanitize_callback' => 'rest_sanitize_boolean');
        $text = array('type' => 'string', 'sanitize_callback' => 'sanitize_textarea_field');
        return array(
            'chat_enabled' => array($bool, 'checkbox', __('Enable chat', 'wordpress-ai-assistant')),
            'chat_mode' => array(array('type' => 'string', 'sanitize_callback' => array($this, 'sanitize_mode')), 'select', __('Mode', 'wordpress-ai-assistant')),
            'chat_enabled_for_visitors' => array($bool, 'checkbox', __('Open to logged-out visitors', 'wordpress-ai-assistant')),
            'chat_enabled_for_all' => array($bool, 'checkbox', __('Open to all logged-in users', 'wordpress-ai-assistant')),
            'chat_monthly_cost_cap' => array(array('type' => 'number', 'sanitize_callback' => array($this, 'sanitize_cap')), 'number', __('Monthly cost cap (USD, 0 = no cap)', 'wordpress-ai-assistant')),
            'chat_max_message_length' => array(array('type' => 'integer', 'sanitize_callback' => 'absint'), 'number', __('Max message length (characters)', 'wordpress-ai-assistant')),
            'chat_welcome_message' => array($text, 'textarea', __('Greeting (empty = built-in text per language)', 'wordpress-ai-assistant')),
            'chat_disclaimer' => array($text, 'textarea', __('Disclaimer shown before the first message (empty = built-in text per language)', 'wordpress-ai-assistant')),
            'chat_suggestions' => array($text, 'textarea', __('Suggested questions, one per line', 'wordpress-ai-assistant')),
            'chat_emergency_text' => array($text, 'textarea', __('Emergency text, Hebrew/default (empty = built-in draft)', 'wordpress-ai-assistant')),
            'chat_emergency_text_en' => array($text, 'textarea', __('Emergency text, English', 'wordpress-ai-assistant')),
            'chat_emergency_text_ar' => array($text, 'textarea', __('Emergency text, Arabic', 'wordpress-ai-assistant')),
            'chat_emergency_keywords' => array($text, 'textarea', __('Extra emergency keywords, one per line (added to the built-in he/ar/en list)', 'wordpress-ai-assistant')),
            'chat_stats_enabled' => array($bool, 'checkbox', __('Keep anonymous aggregate statistics for 30 days (no message text)', 'wordpress-ai-assistant')),
            'chat_persist_history' => array($bool, 'checkbox', __('Store message text (off by default, privacy risk)', 'wordpress-ai-assistant')),
        );
    }

    public function sanitize_mode($v) {
        return $v === 'site_finder' ? 'site_finder' : 'general';
    }

    public function sanitize_cap($v) {
        return max(0, round((float) $v, 2));
    }

    public function register() {
        foreach ($this->fields() as $name => $def) {
            register_setting(self::GROUP, 'at_ai_assistant_' . $name, $def[0]);
        }
    }

    public function render() {
        if (!current_user_can('manage_options')) {
            return;
        }
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Chat settings', 'wordpress-ai-assistant'); ?></h1>
            <?php
            $cap = (float) at_ai_assistant_get_option('chat_monthly_cost_cap', 0);
            $spent = AT_AI_Manager::get_instance()->get_chat_month_cost();
            printf(
                '<p>%s</p>',
                esc_html(sprintf(
                    /* translators: 1: spent USD, 2: cap USD */
                    __('Chat spend this month: $%1$s of $%2$s.', 'wordpress-ai-assistant'),
                    number_format_i18n($spent, 4),
                    $cap > 0 ? number_format_i18n($cap, 2) : '∞'
                ))
            );
            ?>
            <form action="options.php" method="post">
                <?php settings_fields(self::GROUP); ?>
                <table class="form-table" role="presentation">
                <?php foreach ($this->fields() as $name => $def) :
                    $opt = 'at_ai_assistant_' . $name;
                    $val = at_ai_assistant_get_option($name, $name === 'chat_stats_enabled' ? true : ($name === 'chat_max_message_length' ? 500 : ''));
                    ?>
                    <tr>
                        <th scope="row"><label for="<?php echo esc_attr($opt); ?>"><?php echo esc_html($def[2]); ?></label></th>
                        <td>
                        <?php if ($def[1] === 'checkbox') : ?>
                            <input type="hidden" name="<?php echo esc_attr($opt); ?>" value="0">
                            <input type="checkbox" id="<?php echo esc_attr($opt); ?>" name="<?php echo esc_attr($opt); ?>" value="1" <?php checked((bool) $val); ?>>
                        <?php elseif ($def[1] === 'select') : ?>
                            <select id="<?php echo esc_attr($opt); ?>" name="<?php echo esc_attr($opt); ?>">
                                <option value="general" <?php selected($val, 'general'); ?>><?php esc_html_e('General chat', 'wordpress-ai-assistant'); ?></option>
                                <option value="site_finder" <?php selected($val, 'site_finder'); ?>><?php esc_html_e('Site content finder (uses tools)', 'wordpress-ai-assistant'); ?></option>
                            </select>
                        <?php elseif ($def[1] === 'number') : ?>
                            <input type="number" step="any" min="0" class="small-text" id="<?php echo esc_attr($opt); ?>" name="<?php echo esc_attr($opt); ?>" value="<?php echo esc_attr($val); ?>">
                        <?php else : ?>
                            <textarea rows="4" class="large-text" id="<?php echo esc_attr($opt); ?>" name="<?php echo esc_attr($opt); ?>"><?php echo esc_textarea($val); ?></textarea>
                        <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
}

new AT_AI_Chat_Settings();
