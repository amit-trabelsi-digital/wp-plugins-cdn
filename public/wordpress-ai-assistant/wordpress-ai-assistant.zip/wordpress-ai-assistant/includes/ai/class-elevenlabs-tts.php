<?php
/**
 * ElevenLabs text-to-speech client.
 *
 * Small, self-contained provider used by the reading tools. It does not extend
 * the text providers (AT_AI_Provider): TTS has a different request/response
 * shape (binary audio in, no tokens out).
 *
 * API: POST https://api.elevenlabs.io/v1/text-to-speech/{voice_id}?output_format=mp3_44100_128
 *      header xi-api-key, JSON body {text, model_id}. Response body = MP3 bytes.
 * Limits per request: eleven_v3 5,000 chars; eleven_multilingual_v2 10,000;
 * eleven_flash_v2_5 40,000. eleven_v3 supports Hebrew and Arabic.
 *
 * @package WordPress_AI_Assistant
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_ElevenLabs_TTS {

    const ENDPOINT      = 'https://api.elevenlabs.io/v1/text-to-speech/';
    const OUTPUT_FORMAT = 'mp3_44100_128';

    /** Documented per-request character limits, with a safety margin. */
    const MODEL_LIMITS = array(
        'eleven_v3'              => 4500,
        'eleven_multilingual_v2' => 9000,
        'eleven_flash_v2_5'      => 35000,
        'eleven_turbo_v2_5'      => 35000,
    );

    /**
     * Whether an API key is stored.
     */
    public static function has_key() {
        return (string) at_ai_assistant_get_option('elevenlabs_api_key', '') !== '';
    }

    /**
     * Max characters of one request for the model.
     */
    public static function chunk_limit($model) {
        $limit = isset(self::MODEL_LIMITS[$model]) ? self::MODEL_LIMITS[$model] : 4500;
        return (int) apply_filters('at_ai_assistant_tts_chunk_limit', $limit, $model);
    }

    /**
     * Split text into chunks of at most $max characters, on sentence
     * boundaries (falling back to clause, word, then hard cut).
     *
     * @param string $text
     * @param int    $max
     * @return string[]
     */
    public static function chunk_text($text, $max) {
        $text = trim(preg_replace('/[ \t]+/u', ' ', (string) $text));
        $max  = max(200, (int) $max);
        if ($text === '') {
            return array();
        }
        if (mb_strlen($text) <= $max) {
            return array($text);
        }

        // Sentences: split after . ! ? ; … : (Latin and Arabic ? ؟) or a newline.
        $parts = preg_split('/(?<=[.!?;:…؟])\s+|\n+/u', $text, -1, PREG_SPLIT_NO_EMPTY);
        $units = array();
        foreach ($parts as $part) {
            if (mb_strlen($part) <= $max) {
                $units[] = $part;
                continue;
            }
            // Over-long sentence: clauses, then words, then hard cut.
            $sub = preg_split('/(?<=[,،\-–—])\s+/u', $part, -1, PREG_SPLIT_NO_EMPTY);
            foreach ($sub as $s) {
                if (mb_strlen($s) <= $max) {
                    $units[] = $s;
                    continue;
                }
                $buf = '';
                foreach (preg_split('/\s+/u', $s, -1, PREG_SPLIT_NO_EMPTY) as $word) {
                    while (mb_strlen($word) > $max) {
                        if ($buf !== '') {
                            $units[] = $buf;
                            $buf = '';
                        }
                        $units[] = mb_substr($word, 0, $max);
                        $word = mb_substr($word, $max);
                    }
                    if ($buf === '') {
                        $buf = $word;
                    } elseif (mb_strlen($buf) + 1 + mb_strlen($word) <= $max) {
                        $buf .= ' ' . $word;
                    } else {
                        $units[] = $buf;
                        $buf = $word;
                    }
                }
                if ($buf !== '') {
                    $units[] = $buf;
                }
            }
        }

        $chunks = array();
        $cur    = '';
        foreach ($units as $u) {
            if ($cur === '') {
                $cur = $u;
            } elseif (mb_strlen($cur) + 1 + mb_strlen($u) <= $max) {
                $cur .= ' ' . $u;
            } else {
                $chunks[] = $cur;
                $cur = $u;
            }
        }
        if ($cur !== '') {
            $chunks[] = $cur;
        }
        return $chunks;
    }

    /**
     * Voice ID for a language code (he / ar / en), falling back to English.
     */
    public static function voice_for($lang) {
        $lang  = strtolower(substr((string) $lang, 0, 2));
        $voice = (string) at_ai_assistant_get_option('elevenlabs_voice_' . $lang, '');
        if ($voice === '') {
            $voice = (string) at_ai_assistant_get_option('elevenlabs_voice_en', '');
        }
        return apply_filters('at_ai_assistant_tts_voice', $voice, $lang);
    }

    /**
     * Convert text to one MP3 binary string.
     *
     * @param string $text
     * @param string $lang     Language code (he / ar / en).
     * @param int    $post_id  For usage tracking.
     * @return string|WP_Error MP3 bytes
     */
    public function synthesize($text, $lang, $post_id = 0) {
        $model = (string) at_ai_assistant_get_option('elevenlabs_model', 'eleven_v3');
        if ($model === '') {
            $model = 'eleven_v3';
        }
        $voice  = self::voice_for($lang);
        $chunks = self::chunk_text($text, self::chunk_limit($model));
        if (!$chunks) {
            return new WP_Error('at_tts_empty', __('אין טקסט להקראה', 'wordpress-ai-assistant'));
        }

        $audio = '';
        $chars = 0;
        foreach ($chunks as $chunk) {
            $args = array(
                'text'     => $chunk,
                'voice_id' => $voice,
                'model_id' => $model,
                'lang'     => $lang,
            );

            /**
             * Short-circuit one TTS request (tests, alternative engines).
             * Return MP3 bytes (string) or WP_Error; null = call ElevenLabs.
             */
            $pre = apply_filters('at_ai_assistant_tts_request', null, $args);
            if ($pre === null) {
                $pre = $this->request($args);
            }
            if (is_wp_error($pre)) {
                return $pre;
            }
            $audio .= $pre;
            $chars += mb_strlen($chunk);
        }

        $this->track($model, $chars, count($chunks), $post_id);
        return $audio;
    }

    /**
     * One real HTTP request.
     */
    private function request(array $args) {
        $key = (string) at_ai_assistant_get_option('elevenlabs_api_key', '');
        if ($key === '') {
            return new WP_Error('at_tts_no_key', __('מפתח ElevenLabs לא הוגדר', 'wordpress-ai-assistant'));
        }
        if ($args['voice_id'] === '') {
            return new WP_Error('at_tts_no_voice', __('לא הוגדר קול (Voice ID) לשפה זו', 'wordpress-ai-assistant'));
        }

        $url = add_query_arg('output_format', self::OUTPUT_FORMAT, self::ENDPOINT . rawurlencode($args['voice_id']));
        $res = wp_remote_post($url, array(
            'timeout' => 180,
            'headers' => array(
                'xi-api-key'   => $key,
                'Content-Type' => 'application/json',
                'Accept'       => 'audio/mpeg',
            ),
            'body'    => wp_json_encode(array(
                'text'     => $args['text'],
                'model_id' => $args['model_id'],
            )),
        ));
        if (is_wp_error($res)) {
            return $res;
        }
        $code = (int) wp_remote_retrieve_response_code($res);
        $body = wp_remote_retrieve_body($res);
        if ($code !== 200 || $body === '') {
            $msg = '';
            $json = json_decode($body, true);
            if (is_array($json) && isset($json['detail'])) {
                $d   = $json['detail'];
                $msg = is_array($d) ? (isset($d['message']) ? $d['message'] : wp_json_encode($d)) : (string) $d;
            }
            return new WP_Error('at_tts_http_' . $code, sprintf(
                /* translators: 1: HTTP status, 2: message */
                __('שגיאת ElevenLabs (%1$d): %2$s', 'wordpress-ai-assistant'),
                $code,
                $msg
            ));
        }
        return $body;
    }

    /**
     * Log usage (characters) through the existing tracker. Cost is not
     * computed here (ElevenLabs bills credits per character by plan).
     */
    private function track($model, $chars, $requests, $post_id) {
        if (!class_exists('AT_AI_Usage_Tracker')) {
            return;
        }
        $tracker = new AT_AI_Usage_Tracker();
        $tracker->track_usage('elevenlabs', 'text_to_speech', array(
            'model'    => $model,
            'usage'    => array('input_tokens' => $chars, 'output_tokens' => 0, 'total_tokens' => $chars),
            'post_id'  => $post_id ?: null,
            'metadata' => array('unit' => 'characters', 'requests' => $requests),
        ));
    }
}
