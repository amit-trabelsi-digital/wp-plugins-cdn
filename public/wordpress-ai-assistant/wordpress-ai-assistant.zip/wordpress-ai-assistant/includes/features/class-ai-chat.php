<?php
/**
 * AI Chat Feature
 *
 * @package WordPress_AI_Assistant
 * @subpackage Features
 * @since 1.3.0
 */

if (!defined('ABSPATH')) {
    exit;
}

require_once __DIR__ . '/class-ai-chat-strings.php';
require_once __DIR__ . '/class-ai-chat-engine.php';
if (is_admin()) {
    require_once dirname(__DIR__, 2) . '/admin/class-chat-settings.php';
}

/**
 * AI Chat Class
 * 
 * Provides chat interface functionality using AI providers
 */
class AT_AI_Chat {

    const MAX_MESSAGE_LENGTH = 500;
    const VISITOR_MINUTE_LIMIT = 8;
    const VISITOR_HOUR_LIMIT = 40;
    const USER_MINUTE_LIMIT = 20;
    const USER_HOUR_LIMIT = 200;
    
    /**
     * AI Manager instance
     *
     * @var AT_AI_Manager
     */
    private $ai_manager;

    /** @var bool Guards against double registration (the class is also built on init). */
    private static $booted = false;

    /** @var array Data passed to the finder UI. */
    private $finder_data = array();
    
    /**
     * Chat session ID
     *
     * @var string
     */
    private $session_id;
    
    /**
     * Constructor
     */
    public function __construct() {
        if (self::$booted) {
            return;
        }
        self::$booted = true;
        $this->ai_manager = AT_AI_Manager::get_instance();
        $this->init_hooks();
    }
    
    /**
     * Initialize hooks
     */
    private function init_hooks() {
        // AJAX handlers
        add_action('wp_ajax_at_ai_chat_send_message', array($this, 'ajax_send_message'));
        add_action('wp_ajax_nopriv_at_ai_chat_send_message', array($this, 'ajax_send_message_nopriv'));
        add_action('wp_ajax_at_ai_chat_get_history', array($this, 'ajax_get_history'));
        add_action('wp_ajax_at_ai_chat_clear_history', array($this, 'ajax_clear_history'));
        add_action('wp_ajax_at_ai_chat_export_history', array($this, 'ajax_export_history'));
        
        // Shortcode for embedding chat
        add_shortcode('ai_chat', array($this, 'render_chat_shortcode'));
        
        // Add chat widget to admin bar
        add_action('admin_bar_menu', array($this, 'add_admin_bar_item'), 100);
        
        // Enqueue scripts
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        
        // Auto-add floating chat widget if enabled
        if (!is_admin()) {
            add_action('wp_footer', array($this, 'render_finder_widget'));
        }
        if (at_ai_assistant_get_option('chat_auto_show_floating', false)) {
            add_action('admin_footer', array($this, 'render_floating_chat'));
        }
    }
    
    /**
     * Get or create session ID
     */
    private function get_session_id() {
        if (!$this->session_id) {
            if (is_user_logged_in()) {
                $user_id = get_current_user_id();
                $this->session_id = 'user_' . $user_id;
            } else {
                $cookie_name = 'at_ai_chat_session';
                $visitor_id = isset($_COOKIE[$cookie_name])
                    ? sanitize_text_field(wp_unslash($_COOKIE[$cookie_name]))
                    : '';

                if (!preg_match('/^[A-Za-z0-9]{32}$/', $visitor_id)) {
                    $visitor_id = wp_generate_password(32, false, false);
                    setcookie($cookie_name, $visitor_id, array(
                        'expires' => time() + DAY_IN_SECONDS,
                        'path' => COOKIEPATH ?: '/',
                        'domain' => COOKIE_DOMAIN,
                        'secure' => is_ssl(),
                        'httponly' => true,
                        'samesite' => 'Lax',
                    ));
                }

                $this->session_id = 'anon_' . $visitor_id;
            }
        }
        return $this->session_id;
    }
    
    /**
     * Whether the current visitor may use the chat.
     */
    private function can_use_chat() {
        if (current_user_can('manage_options') || current_user_can('use_ai_chat')) {
            return true;
        }
        if (is_user_logged_in()) {
            return (bool) at_ai_assistant_get_option('chat_enabled_for_all', false)
                || (bool) at_ai_assistant_get_option('chat_enabled_for_visitors', false);
        }
        return (bool) at_ai_assistant_get_option('chat_enabled_for_visitors', false);
    }

    /**
     * AJAX handler for sending messages.
     *
     * Logged-in users must send a valid nonce. Logged-out requests skip the nonce on
     * purpose: a visitor nonce is time-based only (uid 0) and full-page caches serve
     * stale ones, so it adds no protection here; abuse is bounded by the rate limit,
     * message cap and monthly cost cap.
     */
    public function ajax_send_message() {
        if (is_user_logged_in()
            && !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'] ?? '')), 'at_ai_chat_nonce')) {
            wp_send_json_error(array('message' => __('Security check failed', 'wordpress-ai-assistant')), 403);
        }

        if (!at_ai_assistant_get_option('chat_enabled', false) || !$this->can_use_chat()) {
            wp_send_json_error(array('message' => __('You do not have permission to use the chat', 'wordpress-ai-assistant')), 403);
        }

        $message = sanitize_textarea_field(wp_unslash($_POST['message'] ?? ''));
        $context = sanitize_key(wp_unslash($_POST['context'] ?? 'general'));
        $language = AT_AI_Chat_Strings::resolve_language(wp_unslash($_POST['language'] ?? ($_POST['lang'] ?? '')));
        $history = json_decode(wp_unslash($_POST['history'] ?? '[]'), true);

        if ($message === '') {
            wp_send_json_error(array('message' => __('Message cannot be empty', 'wordpress-ai-assistant')), 400);
        }
        if (!in_array($context, array('general', 'post', 'page', 'product'), true)) {
            $context = 'general';
        }

        // Emergency messages are answered for free and never rate limited.
        if (!AT_AI_Chat_Engine::is_emergency($message)) {
            $rate_limit = $this->check_rate_limit();
            if (is_wp_error($rate_limit)) {
                wp_send_json_error(
                    array(
                        'message' => AT_AI_Chat_Strings::get($language)['rate_limited'],
                        'retry_after' => (int) ($rate_limit->get_error_data()['retry_after'] ?? 60),
                    ),
                    429
                );
            }
        }

        $result = AT_AI_Chat_Engine::handle($message, is_array($history) ? $history : array(), $language, $context);

        if (is_wp_error($result)) {
            $data = $result->get_error_data();
            $status = is_array($data) && isset($data['status']) ? (int) $data['status'] : 500;
            $message_out = $result->get_error_message();
            if ($status === 500) {
                // Provider errors can carry raw API bodies: log them, show visitors a generic text.
                error_log('[wordpress-ai-assistant] chat error ' . $result->get_error_code() . ': ' . $message_out);
                $strings = AT_AI_Chat_Strings::get($language);
                $message_out = $strings['error'];
            }
            wp_send_json_error(array('message' => $message_out), $status);
        }

        // Message text is stored only when an administrator opts in.
        $this->save_to_history($message, $result['text'], $context);

        wp_send_json_success(array(
            'response' => $result['text'],
            'text' => $result['text'],
            'items' => $result['items'],
            'emergency' => $result['emergency'],
            'timestamp' => current_time('mysql'),
        ));
    }
    
    /**
     * AJAX handler for non-logged users
     */
    public function ajax_send_message_nopriv() {
        $this->ajax_send_message();
    }

    /**
     * Limit AI spend and abuse for both visitors and authenticated users.
     *
     * Visitors are limited per IP (a cookie-based id would be bypassed by dropping the cookie);
     * filter `at_ai_chat_client_ip` when the site sits behind a proxy that REMOTE_ADDR does not resolve.
     * Only hashes are persisted in transient names; raw IPs are not stored.
     *
     * @return true|WP_Error
     */
    private function check_rate_limit() {
        $is_user = is_user_logged_in();
        $minute_limit = $is_user ? self::USER_MINUTE_LIMIT : self::VISITOR_MINUTE_LIMIT;
        $hour_limit = $is_user ? self::USER_HOUR_LIMIT : self::VISITOR_HOUR_LIMIT;
        $identity = $is_user
            ? 'user:' . get_current_user_id()
            : 'visitor:' . apply_filters('at_ai_chat_client_ip', $_SERVER['REMOTE_ADDR'] ?? '');
        $identity_hash = hash_hmac('sha256', $identity, wp_salt('auth'));

        $buckets = array(
            array(
                'key' => 'at_ai_chat_rate_m_' . gmdate('YmdHi') . '_' . $identity_hash,
                'limit' => $minute_limit,
                'ttl' => MINUTE_IN_SECONDS + 10,
                'retry_after' => 60,
            ),
            array(
                'key' => 'at_ai_chat_rate_h_' . gmdate('YmdH') . '_' . $identity_hash,
                'limit' => $hour_limit,
                'ttl' => HOUR_IN_SECONDS + MINUTE_IN_SECONDS,
                'retry_after' => HOUR_IN_SECONDS,
            ),
        );

        foreach ($buckets as $bucket) {
            $count = (int) get_transient($bucket['key']);
            if ($count >= $bucket['limit']) {
                return new WP_Error(
                    'rate_limited',
                    __('Too many chat requests. Please try again later.', 'wordpress-ai-assistant'),
                    array('retry_after' => $bucket['retry_after'])
                );
            }

            set_transient($bucket['key'], $count + 1, $bucket['ttl']);
        }

        return true;
    }
    
    /**
     * Get chat history
     */
    private function get_chat_history() {
        $session_id = $this->get_session_id();
        $history = get_transient('at_ai_chat_history_' . $session_id);
        
        return is_array($history) ? $history : array();
    }
    
    /**
     * Save to chat history
     */
private function save_to_history($user_message, $ai_response, $context = 'general') {
        // Privacy default: no message text is stored. Both stores are opt-in.
        if (!at_ai_assistant_get_option('chat_persist_history', false)) {
            return;
        }

        $session_id = $this->get_session_id();
        $history = $this->get_chat_history();
        $now = current_time('mysql');
        $history[] = array('role' => 'user', 'content' => $user_message, 'timestamp' => $now, 'context' => $context);
        $history[] = array('role' => 'assistant', 'content' => $ai_response, 'timestamp' => $now, 'context' => $context);
        if (count($history) > 50) {
            $history = array_slice($history, -50);
        }
        set_transient('at_ai_chat_history_' . $session_id, $history, DAY_IN_SECONDS);

        if (is_user_logged_in()) {
            $this->save_to_database($user_message, $ai_response, $context);
        }
    }
    
    /**
     * Save chat to database
     */
    private function save_to_database($user_message, $ai_response, $context) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'ai_assistant_chat_logs';
        
        $wpdb->insert(
            $table_name,
            array(
                'user_id' => get_current_user_id(),
                'session_id' => $this->get_session_id(),
                'user_message' => $user_message,
                'ai_response' => $ai_response,
                'context' => $context,
                'timestamp' => current_time('mysql')
            ),
            array('%d', '%s', '%s', '%s', '%s', '%s')
        );
    }
    
    /**
     * AJAX handler for getting chat history
     */
    public function ajax_get_history() {
        // Check nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'at_ai_chat_nonce')) {
            wp_send_json_error(__('Security check failed', 'wordpress-ai-assistant'));
        }
        
        $history = $this->get_chat_history();
        
        wp_send_json_success(array(
            'history' => $history,
            'count' => count($history)
        ));
    }
    
    /**
     * AJAX handler for clearing history
     */
    public function ajax_clear_history() {
        // Check nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'at_ai_chat_nonce')) {
            wp_send_json_error(__('Security check failed', 'wordpress-ai-assistant'));
        }
        
        $session_id = $this->get_session_id();
        delete_transient('at_ai_chat_history_' . $session_id);
        
        wp_send_json_success(__('Chat history cleared', 'wordpress-ai-assistant'));
    }
    
    /**
     * AJAX handler for exporting history
     */
    public function ajax_export_history() {
        // Check nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'at_ai_chat_nonce')) {
            wp_send_json_error(__('Security check failed', 'wordpress-ai-assistant'));
        }
        
        $history = $this->get_chat_history();
        $format = sanitize_text_field($_POST['format'] ?? 'json');
        
        if ($format === 'txt') {
            $export = $this->export_as_text($history);
        } else {
            $export = json_encode($history, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        }
        
        wp_send_json_success(array(
            'data' => $export,
            'format' => $format,
            'filename' => 'chat_history_' . date('Y-m-d_H-i-s') . '.' . $format
        ));
    }
    
    /**
     * Export history as text
     */
    private function export_as_text($history) {
        $text = __('Chat History Export', 'wordpress-ai-assistant') . "\n";
        $text .= __('Date: ', 'wordpress-ai-assistant') . current_time('Y-m-d H:i:s') . "\n";
        $text .= str_repeat('=', 50) . "\n\n";
        
        foreach ($history as $msg) {
            $role = $msg['role'] === 'user' ? __('You', 'wordpress-ai-assistant') : __('AI', 'wordpress-ai-assistant');
            $text .= "[{$msg['timestamp']}] {$role}:\n";
            $text .= $msg['content'] . "\n\n";
        }
        
        return $text;
    }
    
    /**
     * Render chat shortcode
     */
    public function render_chat_shortcode($atts) {
        $atts = shortcode_atts(array(
            'title' => __('AI Assistant', 'wordpress-ai-assistant'),
            'placeholder' => __('Type your message...', 'wordpress-ai-assistant'),
            'position' => 'inline', // inline, fixed-bottom-right, fixed-bottom-left
            'theme' => 'light', // light, dark, auto
            'height' => '400px',
            'width' => '100%'
        ), $atts, 'ai_chat');
        
        // Check if chat is enabled
        if (!at_ai_assistant_get_option('chat_enabled', false)) {
            return '';
        }
        
        // Check permissions - Allow administrators by default
        if (!current_user_can('manage_options') && !current_user_can('use_ai_chat')) {
            if (!at_ai_assistant_get_option('chat_enabled_for_all', false)) {
                if (!at_ai_assistant_get_option('chat_enabled_for_visitors', false) && !is_user_logged_in()) {
                    return '';
                }
            }
        }
        
        $this->enqueue_legacy_scripts();
        ob_start();
        include WORDPRESS_AI_ASSISTANT_PATH . 'templates/chat-widget.php';
        return ob_get_clean();
    }
    
    /**
     * Add admin bar item
     */
    public function add_admin_bar_item($wp_admin_bar) {
        if (!at_ai_assistant_get_option('chat_show_in_admin_bar', true)) {
            return;
        }
        
        // Check permissions - Allow administrators by default
        if (!current_user_can('manage_options') && !current_user_can('use_ai_chat')) {
            if (!at_ai_assistant_get_option('chat_enabled_for_all', false)) {
                return;
            }
        }
        
        $wp_admin_bar->add_node(array(
            'id' => 'at-ai-chat',
            'title' => '<span class="ab-icon dashicons dashicons-format-chat"></span>' . __('AI Chat', 'wordpress-ai-assistant'),
            'href' => '#',
            'meta' => array(
                'class' => 'at-ai-chat-toggle'
            )
        ));
    }
    
    /**
     * Whether the accessible finder widget should appear on this request.
     */
    private function should_show_finder() {
        if (is_admin() || !at_ai_assistant_get_option('chat_enabled', false)) {
            return false;
        }
        if (!$this->can_use_chat()) {
            return false;
        }
        if (AT_AI_Chat_Engine::mode() !== 'site_finder' && !at_ai_assistant_get_option('chat_auto_show_floating', false)) {
            return false;
        }
        $load_on_pages = at_ai_assistant_get_option('chat_load_on_pages', 'all');
        if ($load_on_pages !== 'all') {
            $pages = (array) at_ai_assistant_get_option('chat_specific_pages', array());
            if (!in_array(get_queried_object_id(), array_map('intval', $pages), true)) {
                return false;
            }
        }
        return (bool) apply_filters('at_ai_chat_show_widget', true);
    }

    /**
     * Enqueue the accessible finder UI (frontend only).
     */
    public function enqueue_frontend_scripts() {
        if (!$this->should_show_finder()) {
            return;
        }

        $lang = AT_AI_Chat_Strings::resolve_language();
        $strings = AT_AI_Chat_Strings::get($lang);

        $disclaimer = trim((string) at_ai_assistant_get_option('chat_disclaimer', ''));
        $greeting = trim((string) at_ai_assistant_get_option('chat_welcome_message', ''));
        $suggestions_raw = (string) at_ai_assistant_get_option('chat_suggestions', '');
        $suggestions = array_values(array_filter(array_map('trim', preg_split('/\R/u', $suggestions_raw))));

        $data = array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => is_user_logged_in() ? wp_create_nonce('at_ai_chat_nonce') : '',
            'lang' => $lang,
            'position' => apply_filters('at_ai_chat_position', 'end') === 'start' ? 'start' : 'end',
            'maxLength' => AT_AI_Chat_Engine::max_message_length(),
            'maxHistory' => AT_AI_Chat_Engine::MAX_HISTORY_MESSAGES,
            'strings' => array_merge($strings, array(
                'disclaimer' => $disclaimer !== '' ? $disclaimer : $strings['disclaimer'],
                'greeting' => $greeting !== '' ? $greeting : $strings['greeting'],
            )),
            'suggestions' => apply_filters('at_ai_chat_suggestions', $suggestions, $lang),
        );
        $data['strings']['disclaimer'] = apply_filters('at_ai_chat_disclaimer', $data['strings']['disclaimer'], $lang);
        $this->finder_data = $data;

        wp_enqueue_style('at-ai-chat-finder', WORDPRESS_AI_ASSISTANT_URL . 'public/css/chat-finder.css', array(), WORDPRESS_AI_ASSISTANT_VERSION);
        wp_enqueue_script('at-ai-chat-finder', WORDPRESS_AI_ASSISTANT_URL . 'public/js/chat-finder.js', array(), WORDPRESS_AI_ASSISTANT_VERSION, array('strategy' => 'defer', 'in_footer' => true));
        wp_add_inline_script('at-ai-chat-finder', 'window.atAiFinder = ' . wp_json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . ';', 'before');
    }

    /**
     * Render the finder launcher + dialog.
     */
    public function render_finder_widget() {
        if (empty($this->finder_data) || !$this->should_show_finder()) {
            return;
        }
        $d = $this->finder_data;
        $s = $d['strings'];
        $dir = in_array($d['lang'], array('he', 'ar'), true) ? 'rtl' : 'ltr';
        include WORDPRESS_AI_ASSISTANT_PATH . 'templates/chat-finder.php';
    }

    /**
     * Enqueue the legacy chat (admin and the [ai_chat] shortcode).
     */
    public function enqueue_legacy_scripts() {
        if (!at_ai_assistant_get_option('chat_enabled', false)) {
            return;
        }
        
        // Check if should load on current page
        $load_on_pages = at_ai_assistant_get_option('chat_load_on_pages', 'all');
        if ($load_on_pages !== 'all') {
            $pages = at_ai_assistant_get_option('chat_specific_pages', array());
            if (!in_array(get_the_ID(), $pages)) {
                return;
            }
        }
        
        wp_enqueue_style(
            'at-ai-chat',
            WORDPRESS_AI_ASSISTANT_URL . 'public/css/chat.css',
            array(),
            WORDPRESS_AI_ASSISTANT_VERSION
        );
        
        wp_enqueue_script(
            'at-ai-chat',
            WORDPRESS_AI_ASSISTANT_URL . 'public/js/chat.js',
            array('jquery'),
            WORDPRESS_AI_ASSISTANT_VERSION,
            true
        );
        
        wp_localize_script('at-ai-chat', 'at_ai_chat', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('at_ai_chat_nonce'),
            'strings' => array(
                'sending' => __('Sending...', 'wordpress-ai-assistant'),
                'typing' => __('AI is typing...', 'wordpress-ai-assistant'),
                'error' => __('An error occurred', 'wordpress-ai-assistant'),
                'clear_confirm' => __('Are you sure you want to clear the chat history?', 'wordpress-ai-assistant'),
                'welcome_message' => at_ai_assistant_get_option('chat_welcome_message', __('Hi! How can I help you today?', 'wordpress-ai-assistant')),
                'connection_error' => __('Connection error. Please try again.', 'wordpress-ai-assistant'),
                'copy_success' => __('Copied to clipboard!', 'wordpress-ai-assistant'),
                'export_success' => __('Chat exported successfully!', 'wordpress-ai-assistant')
            ),
            'settings' => array(
                'auto_open' => at_ai_assistant_get_option('chat_auto_open', false),
                'sound_enabled' => at_ai_assistant_get_option('chat_sound_enabled', true),
                'show_timestamp' => at_ai_assistant_get_option('chat_show_timestamp', true),
                'enable_markdown' => at_ai_assistant_get_option('chat_enable_markdown', true),
                'language' => AT_AI_Chat_Strings::resolve_language()
            )
        ));
    }
    
    /**
     * Enqueue admin scripts
     */
    public function enqueue_admin_scripts() {
        if (!at_ai_assistant_get_option('chat_enabled', false)) {
            return;
        }
        
        if (!at_ai_assistant_get_option('chat_enabled_in_admin', true)) {
            return;
        }
        
        $this->enqueue_legacy_scripts();
    }
    
    /**
     * Render floating chat widget
     */
    public function render_floating_chat() {
        // Check if chat is enabled
        if (!at_ai_assistant_get_option('chat_enabled', false)) {
            return;
        }
        
        // Check context
        if (is_admin() && !at_ai_assistant_get_option('chat_enabled_in_admin', true)) {
            return;
        }
        
        // Render the chat widget
        echo do_shortcode('[ai_chat position="fixed-bottom-right" theme="light"]');
    }
}

// Initialize the class
new AT_AI_Chat();
