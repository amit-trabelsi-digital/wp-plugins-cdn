<?php
/**
 * Image Alt Text Generator
 *
 * @since      1.1.0
 * @package    WordPress_AI_Assistant
 * @subpackage WordPress_AI_Assistant/includes/features
 * @author     Amit Trabelsi <amit@amit-trabelsi.co.il>
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Image Alt Text Generator Class
 */
class AT_Image_Alt_Generator {

    /**
     * AI Manager instance
     *
     * @var AT_AI_Manager
     */
    private $ai_manager;

    /**
     * Constructor
     */
    public function __construct($register_hooks = true) {
        $this->ai_manager = AT_AI_Manager::get_instance();

        if (!$register_hooks) {
            return;
        }

        // Hook into WordPress.
        add_filter('wp_generate_attachment_metadata', array($this, 'generate_alt_text_for_images'), 10, 2);
        add_action('at_ai_generate_alt_text_delayed', array($this, 'generate_alt_text'), 10, 1);
        add_filter('attachment_fields_to_edit', array($this, 'add_attachment_action'), 10, 2);

        // AJAX handlers
        add_action('wp_ajax_at_ai_generate_alt_text', array($this, 'ajax_generate_alt_text'));
        add_action('wp_ajax_at_ai_regenerate_alt_text', array($this, 'ajax_regenerate_alt_text'));
    }

    /**
     * Generate alt text for images in metadata generation
     *
     * @param array $metadata
     * @param int $attachment_id
     * @return array
     */
    public function generate_alt_text_for_images($metadata, $attachment_id) {
        // Check if auto-generation is enabled
        if (!at_ai_assistant_get_option('auto_generate_alt_text', true)) {
            return $metadata;
        }

        // Check if it's an image
        if (!wp_attachment_is_image($attachment_id)) {
            return $metadata;
        }

        // Check if alt text already exists
        $alt_text = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
        if (!empty($alt_text)) {
            return $metadata;
        }

        // Generate alt text (delay execution to ensure metadata is saved)
        if (!wp_next_scheduled('at_ai_generate_alt_text_delayed', array($attachment_id))) {
            wp_schedule_single_event(time() + 5, 'at_ai_generate_alt_text_delayed', array($attachment_id));
        }

        return $metadata;
    }

    /**
     * Generate alt text for attachment
     *
     * @param int $attachment_id
     * @return bool|WP_Error
     */
    public function generate_alt_text($attachment_id) {
        if (!$this->is_supported_image($attachment_id)) {
            return new WP_Error('unsupported_attachment', __('The selected attachment is not a supported image.', 'wordpress-ai-assistant'));
        }

        $image_input = $this->get_image_input($attachment_id);
        if (is_wp_error($image_input)) {
            return $image_input;
        }

        $image_url = wp_get_attachment_url($attachment_id);
        if (!$image_url) {
            return new WP_Error('invalid_attachment', __('Invalid attachment', 'wordpress-ai-assistant'));
        }

        // Analyze image with AI
        $analysis = $this->ai_manager->analyze_image($image_input, array(
            'prompt' => $this->get_alt_text_prompt($attachment_id),
        ));

        if (is_wp_error($analysis)) {
            at_ai_assistant_log('image_analysis', 'error', $analysis->get_error_message(), array(
                'attachment_id' => $attachment_id,
                'image_url' => $image_url,
            ), $attachment_id);
            return $analysis;
        }

        // Extract alt text from description
        $alt_text = $this->extract_alt_text($analysis['description']);

        // Update attachment alt text
        $updated = update_post_meta($attachment_id, '_wp_attachment_image_alt', $alt_text);

        // Log success
        at_ai_assistant_log('image_analysis', 'success', __('Alt text generated successfully', 'wordpress-ai-assistant'), array(
            'attachment_id' => $attachment_id,
            'alt_text' => $alt_text,
            'usage' => $analysis['usage'],
        ), $attachment_id);

        return $updated || get_post_meta($attachment_id, '_wp_attachment_image_alt', true) === $alt_text;
    }

    /**
     * Build an image input that OpenAI can read even when the site is private.
     *
     * @param int $attachment_id Attachment ID.
     * @return string|WP_Error
     */
    private function get_image_input($attachment_id) {
        $file = get_attached_file($attachment_id);
        $mime_type = get_post_mime_type($attachment_id);

        if (!$file || !is_readable($file) || !$mime_type) {
            $url = wp_get_attachment_url($attachment_id);
            return $url ? $url : new WP_Error('invalid_attachment', __('Unable to read the selected image.', 'wordpress-ai-assistant'));
        }

        $max_bytes = (int) apply_filters('at_ai_assistant_max_inline_image_bytes', 10 * MB_IN_BYTES, $attachment_id);
        $file_size = filesize($file);
        if ($file_size === false || $file_size > $max_bytes) {
            return new WP_Error('image_too_large', __('The selected image is too large for AI analysis.', 'wordpress-ai-assistant'));
        }

        $contents = file_get_contents($file);
        if ($contents === false) {
            return new WP_Error('image_read_failed', __('Unable to read the selected image.', 'wordpress-ai-assistant'));
        }

        return 'data:' . $mime_type . ';base64,' . base64_encode($contents);
    }

    /**
     * Add a one-click action in attachment details, including the media modal.
     *
     * @param array   $fields Attachment fields.
     * @param WP_Post $post   Attachment post.
     * @return array
     */
    public function add_attachment_action($fields, $post) {
        if (!$this->is_supported_image($post->ID) || !current_user_can('edit_post', $post->ID)) {
            return $fields;
        }

        $fields['at_ai_generate_alt_text'] = array(
            'label' => __('AI accessibility', 'wordpress-ai-assistant'),
            'input' => 'html',
            'html'  => sprintf(
                '<button type="button" class="button at-ai-generate-alt-text" data-attachment-id="%d">%s</button>',
                (int) $post->ID,
                esc_html__('Generate alt text with AI', 'wordpress-ai-assistant')
            ),
        );

        return $fields;
    }

    /**
     * Get prompt for alt text generation
     *
     * @param int $attachment_id Optional attachment ID for language context
     * @return string
     */
    private function get_alt_text_prompt($attachment_id = null) {
        $base_prompt = __("Analyze this image and provide a concise, descriptive alt text that would be appropriate for accessibility purposes. Focus on the main subject, key elements, and context. Keep it under 125 characters. Do not include phrases like 'image of' or 'picture of' - just describe what's in the image directly.", 'wordpress-ai-assistant');
        
        // Add language context if attachment ID is provided
        if ($attachment_id) {
            // Try to get post ID from attachment
            $post_id = get_post_meta($attachment_id, '_wp_attachment_parent', true);
            if ($post_id) {
                $post_language = at_ai_assistant_get_post_language($post_id);
                if ($post_language) {
                    $lang_name = at_ai_assistant_get_language_name($post_language);
                    $base_prompt = sprintf(__('IMPORTANT: Generate the alt text in %s (%s).', 'wordpress-ai-assistant'), $lang_name, $post_language) . "\n\n" . $base_prompt;
                }
            }
        }
        
        // Add general instructions if available
        $general_instructions = at_ai_assistant_get_option('general_prompt_instructions', '');
        if (!empty($general_instructions)) {
            $base_prompt = $general_instructions . "\n\n" . $base_prompt;
        }
        
        return $base_prompt;
    }

    /**
     * Extract alt text from AI description
     *
     * @param string $description
     * @return string
     */
    private function extract_alt_text($description) {
        // Clean up the description
        $description = strip_tags($description);
        $description = trim($description);

        // If description is too long, truncate it
        if (function_exists('mb_strlen') && function_exists('mb_substr')) {
            if (mb_strlen($description) > 125) {
                $description = mb_substr($description, 0, 122) . '...';
            }
        } elseif (strlen($description) > 125) {
            $description = substr($description, 0, 122) . '...';
        }

        // Remove common prefixes that AI might add
        $remove_prefixes = array(
            'This image shows',
            'The image depicts',
            'Image of',
            'Picture of',
            'Photo of',
            'This is',
            'Here is',
        );

        foreach ($remove_prefixes as $prefix) {
            if (stripos($description, $prefix) === 0) {
                $description = trim(substr($description, strlen($prefix)));
                break;
            }
        }

        return $description;
    }

    /**
     * AJAX handler for generating alt text
     */
    public function ajax_generate_alt_text() {
        // Check permissions
        if (!current_user_can('upload_files')) {
            wp_send_json_error(__('Insufficient permissions', 'wordpress-ai-assistant'));
        }

        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'at_ai_generate_alt_text')) {
            wp_send_json_error(__('Security check failed', 'wordpress-ai-assistant'));
        }

        $attachment_id = intval($_POST['attachment_id'] ?? 0);

        if (!$attachment_id || !current_user_can('edit_post', $attachment_id)) {
            wp_send_json_error(__('Invalid attachment ID', 'wordpress-ai-assistant'));
        }

        $result = $this->generate_alt_text($attachment_id);

        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        }

        $alt_text = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);

        wp_send_json_success(array(
            'alt_text' => $alt_text,
            'message' => __('Alt text generated successfully', 'wordpress-ai-assistant'),
        ));
    }

    /**
     * AJAX handler for regenerating alt text
     */
    public function ajax_regenerate_alt_text() {
        // Check permissions
        if (!current_user_can('upload_files')) {
            wp_send_json_error(__('Insufficient permissions', 'wordpress-ai-assistant'));
        }

        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'at_ai_regenerate_alt_text')) {
            wp_send_json_error(__('Security check failed', 'wordpress-ai-assistant'));
        }

        $attachment_id = intval($_POST['attachment_id'] ?? 0);

        if (!$attachment_id || !current_user_can('edit_post', $attachment_id)) {
            wp_send_json_error(__('Invalid attachment ID', 'wordpress-ai-assistant'));
        }

        $result = $this->generate_alt_text($attachment_id);

        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        }

        $alt_text = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);

        wp_send_json_success(array(
            'alt_text' => $alt_text,
            'message' => __('Alt text regenerated successfully', 'wordpress-ai-assistant'),
        ));
    }

    /**
     * Get supported image types
     *
     * @return array
     */
    public function get_supported_mime_types() {
        return array(
            'image/jpeg',
            'image/png',
            'image/gif',
            'image/webp',
        );
    }

    /**
     * Check if attachment is supported image type
     *
     * @param int $attachment_id
     * @return bool
     */
    public function is_supported_image($attachment_id) {
        $mime_type = get_post_mime_type($attachment_id);
        return in_array($mime_type, $this->get_supported_mime_types());
    }
}
