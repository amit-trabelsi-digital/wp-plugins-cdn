<?php
/**
 * WP-CLI commands for the reading tools.
 *
 * @package WordPress_AI_Assistant
 */

if (!defined('ABSPATH') || !defined('WP_CLI') || !WP_CLI) {
    return;
}

/**
 * Article summaries (draft, unapproved) in bulk.
 */
class AT_Reading_Tools_CLI {

    /**
     * Generate draft summaries for published articles that have none.
     * Drafts are never shown on the site until an editor approves them.
     *
     * ## OPTIONS
     *
     * [--post_type=<types>]
     * : Comma-separated post types. Default: the types enabled in "כלי קריאה".
     *
     * [--limit=<n>]
     * : Max articles to process in this run. Default 20.
     *
     * [--dry-run]
     * : List the articles that would be processed, without calling the AI.
     *
     * ## EXAMPLES
     *
     *     wp ai-assistant summaries generate --post_type=post --limit=5 --dry-run
     *
     * @subcommand generate
     */
    public function generate($args, $assoc_args) {
        $types = isset($assoc_args['post_type'])
            ? array_filter(array_map('trim', explode(',', $assoc_args['post_type'])))
            : AT_Reading_Tools::enabled_post_types();
        if (!$types) {
            WP_CLI::error('No post types: pass --post_type or enable some in the reading tools settings.');
        }
        $limit   = isset($assoc_args['limit']) ? max(1, (int) $assoc_args['limit']) : 20;
        $dry     = !empty($assoc_args['dry-run']);

        $ids = get_posts(array(
            'post_type'        => $types,
            'post_status'      => 'publish',
            'has_password'     => false,
            'posts_per_page'   => $limit,
            'fields'           => 'ids',
            'orderby'          => 'ID',
            'order'            => 'ASC',
            'suppress_filters' => true,
            'lang'             => '',
            'meta_query'       => array(
                'relation' => 'OR',
                array('key' => AT_Reading_Tools::META_SUMMARY, 'compare' => 'NOT EXISTS'),
                array('key' => AT_Reading_Tools::META_SUMMARY, 'value' => '', 'compare' => '='),
            ),
        ));

        if (!$ids) {
            WP_CLI::success('Nothing to do: every matching article already has a summary.');
            return;
        }

        $ok = 0;
        $fail = 0;
        foreach ($ids as $id) {
            $label = sprintf('#%d [%s] %s', $id, AT_Reading_Tools::post_language($id), get_the_title($id));
            if ($dry) {
                WP_CLI::log('would generate: ' . $label);
                continue;
            }
            $res = AT_Reading_Tools::generate_summary($id);
            if (is_wp_error($res)) {
                $fail++;
                WP_CLI::warning($label . ' - ' . $res->get_error_message());
            } else {
                $ok++;
                WP_CLI::log('draft created: ' . $label);
            }
        }
        if ($dry) {
            WP_CLI::success(count($ids) . ' article(s) would get a draft summary.');
        } else {
            WP_CLI::success("Drafts created: {$ok}, failed: {$fail}. Approve them in each article.");
        }
    }
}

WP_CLI::add_command('ai-assistant summaries', 'AT_Reading_Tools_CLI');
