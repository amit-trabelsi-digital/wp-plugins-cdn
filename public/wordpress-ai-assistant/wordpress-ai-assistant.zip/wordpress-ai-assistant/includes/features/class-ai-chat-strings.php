<?php
/**
 * Chat strings, languages and safety defaults.
 *
 * English strings go through gettext (translatable with the plugin text domain);
 * Hebrew and Arabic have built-in maps so a he/ar/en site works without .po files.
 * Everything is filterable via `at_ai_chat_strings`.
 *
 * @package WordPress_AI_Assistant
 * @since 1.10.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_AI_Chat_Strings {

    const LANGS = array('he', 'en', 'ar');

    /**
     * Resolve the request language: explicit value, Polylang current language, locale.
     */
    public static function resolve_language($requested = '') {
        $requested = sanitize_key($requested);
        if (in_array($requested, self::LANGS, true)) {
            return $requested;
        }
        if (function_exists('pll_current_language')) {
            $lang = pll_current_language('slug');
            if (in_array($lang, self::LANGS, true)) {
                return $lang;
            }
        }
        $prefix = substr(determine_locale(), 0, 2);
        return in_array($prefix, self::LANGS, true) ? $prefix : 'he';
    }

    /**
     * UI strings for a language.
     *
     * @return array<string,string>
     */
    public static function get($lang) {
        $en = array(
            'launcher'      => __('Find content', 'wordpress-ai-assistant'),
            'title'         => __('Content finder', 'wordpress-ai-assistant'),
            'close'         => __('Close chat', 'wordpress-ai-assistant'),
            'input_label'   => __('Your question', 'wordpress-ai-assistant'),
            'placeholder'   => __('What are you looking for?', 'wordpress-ai-assistant'),
            'send'          => __('Send', 'wordpress-ai-assistant'),
            'log_label'     => __('Conversation', 'wordpress-ai-assistant'),
            'suggestions'   => __('Suggested questions', 'wordpress-ai-assistant'),
            'loading'       => __('Searching the site, please wait.', 'wordpress-ai-assistant'),
            'error'         => __('Something went wrong. Please try again.', 'wordpress-ai-assistant'),
            'you'           => __('You:', 'wordpress-ai-assistant'),
            'assistant'     => __('Assistant:', 'wordpress-ai-assistant'),
            'results'       => __('Results found', 'wordpress-ai-assistant'),
            'greeting'      => __('Hi! I can help you find articles, publications, training and events on this site.', 'wordpress-ai-assistant'),
            'disclaimer'    => __('This is an automated assistant that searches the site content. Do not write identifying details.', 'wordpress-ai-assistant'),
            'cap_reached'   => __('The assistant is unavailable right now. You can use the site search instead.', 'wordpress-ai-assistant'),
            'too_long'      => __('The message is too long. Please shorten it.', 'wordpress-ai-assistant'),
            'rate_limited'  => __('Too many requests. Please try again in a few minutes.', 'wordpress-ai-assistant'),
            'emergency'     => __('If a child is in immediate danger, call the police (emergency number in your country). Contact your local child protection services or a crisis line.', 'wordpress-ai-assistant'),
        );

        $maps = array(
            'he' => array(
                'launcher'     => 'חיפוש תכנים',
                'title'        => 'עוזר איתור תכנים',
                'close'        => 'סגירת הצ׳אט',
                'input_label'  => 'השאלה שלכם',
                'placeholder'  => 'מה תרצו למצוא?',
                'send'         => 'שליחה',
                'log_label'    => 'השיחה',
                'suggestions'  => 'שאלות מוצעות',
                'loading'      => 'מחפש באתר, רגע בבקשה.',
                'error'        => 'משהו השתבש. נסו שוב.',
                'you'          => 'אתם:',
                'assistant'    => 'העוזר:',
                'results'      => 'תוצאות שנמצאו',
                'greeting'     => 'שלום! אפשר לשאול אותי איפה למצוא מאמרים, פרסומים, הכשרות ואירועים באתר.',
                'disclaimer'   => 'זה עוזר אוטומטי שמחפש בתכני האתר. אל תכתבו פרטים מזהים.',
                'cap_reached'  => 'העוזר אינו זמין כרגע. אפשר להשתמש בחיפוש באתר.',
                'too_long'     => 'ההודעה ארוכה מדי. נסו לקצר.',
                'rate_limited' => 'יותר מדי בקשות. נסו שוב בעוד כמה דקות.',
                'emergency'    => 'אם ילד או ילדה נמצאים בסכנה מיידית — התקשרו למשטרה 100. לדיווח על פגיעה בילדים: מוקד 105 של המטה הלאומי להגנה על ילדים ברשת / מוקד 118 של משרד הרווחה. לתמיכה רגשית: ער״ן 1201.',
            ),
            'ar' => array(
                'launcher'     => 'البحث عن محتوى',
                'title'        => 'مساعد البحث عن المحتوى',
                'close'        => 'إغلاق المحادثة',
                'input_label'  => 'سؤالك',
                'placeholder'  => 'عمّ تبحث؟',
                'send'         => 'إرسال',
                'log_label'    => 'المحادثة',
                'suggestions'  => 'أسئلة مقترحة',
                'loading'      => 'جارٍ البحث في الموقع، لحظة من فضلك.',
                'error'        => 'حدث خطأ ما. حاول مرة أخرى.',
                'you'          => 'أنت:',
                'assistant'    => 'المساعد:',
                'results'      => 'النتائج',
                'greeting'     => 'مرحبًا! يمكنني مساعدتك في العثور على مقالات ومنشورات ودورات وفعاليات في الموقع.',
                'disclaimer'   => 'هذا مساعد آلي يبحث في محتوى الموقع. لا تكتب تفاصيل تعريفية.',
                'cap_reached'  => 'المساعد غير متاح حاليًا. يمكنك استخدام البحث في الموقع.',
                'too_long'     => 'الرسالة طويلة جدًا. حاول الاختصار.',
                'rate_limited' => 'طلبات كثيرة جدًا. حاول مرة أخرى بعد دقائق.',
                'emergency'    => 'إذا كان طفل في خطر فوري، اتصلوا بالشرطة 100. للإبلاغ عن إيذاء الأطفال: الخط 105 (الطاقم الوطني لحماية الأطفال على الشبكة) أو الخط 118 التابع لوزارة الرفاه. للدعم النفسي: عران 1201.',
            ),
        );

        $strings = $en;
        if ($lang !== 'en' && isset($maps[$lang])) {
            $strings = array_merge($en, $maps[$lang]);
        }

        /**
         * Filter the chat UI strings.
         *
         * @param array  $strings Keys: launcher, title, ... emergency.
         * @param string $lang    he|en|ar.
         */
        return apply_filters('at_ai_chat_strings', $strings, $lang);
    }

    /**
     * Default emergency keywords (normalised at match time). Kept to first-person or
     * explicit danger phrases so content searches such as "materials on sexual abuse" do not trigger.
     */
    public static function default_emergency_keywords() {
        return array(
            // Hebrew.
            'פגע בי', 'פגעו בי', 'פוגעים בי', 'מתעלל בי', 'מתעללים בי', 'מתעללת בי', 'מכה אותי', 'מכים אותי',
            'נאנסתי', 'אנס אותי', 'אנסו אותי', 'נוגע בי', 'נגעו בי', 'ילד בסכנה', 'ילדה בסכנה', 'הילד שלי בסכנה',
            'הילדה שלי בסכנה', 'בסכנה מיידית', 'מתעללים בילד', 'מתעללים בילדה', 'רוצה להתאבד', 'רוצה למות', 'להרוג את עצמי',
            // Arabic.
            'اعتدى علي', 'يعتدي علي', 'اعتدوا علي', 'تحرش بي', 'يتحرش بي', 'يضربني', 'اغتصبني', 'اغتصبت', 'طفل في خطر',
            'طفلة في خطر', 'اريد ان انتحر', 'اريد الانتحار', 'اريد ان اموت',
            // English.
            'hurting me', 'hurt me', 'abusing me', 'abused me', 'molested me', 'touching me', 'raped me', 'i was raped',
            'child in danger', 'kid in danger', 'being abused', 'want to die', 'kill myself', 'end my life',
        );
    }

    /**
     * Normalise text for keyword matching (he/ar/en).
     */
    public static function normalize($text) {
        $text = (string) $text;
        $text = function_exists('mb_strtolower') ? mb_strtolower($text, 'UTF-8') : strtolower($text);
        // Hebrew niqqud and cantillation, Arabic tashkeel and tatweel.
        $text = preg_replace('/[\x{0591}-\x{05C7}\x{064B}-\x{065F}\x{0670}\x{0640}]/u', '', $text);
        // Arabic letter variants.
        $text = strtr($text, array('أ' => 'ا', 'إ' => 'ا', 'آ' => 'ا', 'ى' => 'ي', 'ة' => 'ه', 'ؤ' => 'و', 'ئ' => 'ي'));
        // Quotes, geresh, gershayim, punctuation.
        $text = preg_replace('/[\x{05F3}\x{05F4}"\'`´‘’“”.,;:!?()\[\]{}\-_\/\\\\]+/u', ' ', $text);
        $text = preg_replace('/\s+/u', ' ', $text);
        return trim($text);
    }
}
