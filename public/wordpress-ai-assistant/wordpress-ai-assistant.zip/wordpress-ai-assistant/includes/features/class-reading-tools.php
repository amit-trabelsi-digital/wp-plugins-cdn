<?php
/**
 * Reading tools: AI article summary and read-aloud (text to speech).
 *
 * Self-contained feature: settings screen, per-article meta box, summary
 * generation, TTS generation (ElevenLabs), WP-CLI and front-end rendering
 * helpers. Generic: no site-specific code. Themes decide placement through
 * the `at_ai_assistant_reading_tools` action.
 *
 * Meta keys:
 *   _at_ai_reading_show        '' | yes | no   per-article override
 *   _at_ai_summary             bullet lines (plain text, one per line)
 *   _at_ai_summary_approved    0 | 1
 *   _at_ai_summary_hash        content hash the summary was generated from
 *   _at_ai_tts_attachment      attachment ID of the MP3
 *   _at_ai_tts_hash            content hash the audio was generated from
 *
 * @package WordPress_AI_Assistant
 */

if (!defined('ABSPATH')) {
    exit;
}

class AT_Reading_Tools {

    const PAGE  = 'wordpress-ai-assistant-reading-tools';
    const GROUP = 'at_ai_reading_tools';
    const NONCE = 'at_ai_reading_tools';

    const META_SHOW     = '_at_ai_reading_show';
    const META_SUMMARY  = '_at_ai_summary';
    const META_APPROVED = '_at_ai_summary_approved';
    const META_SUM_HASH = '_at_ai_summary_hash';
    const META_TTS_ATT  = '_at_ai_tts_attachment';
    const META_TTS_HASH = '_at_ai_tts_hash';

    /** @var AT_Reading_Tools */
    private static $instance = null;

    public static function init() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu', array($this, 'add_menu'), 20);
        add_action('admin_init', array($this, 'register_settings'));
        add_action('add_meta_boxes', array($this, 'add_meta_box'));
        add_action('save_post', array($this, 'save_meta'), 10, 2);
        add_action('admin_enqueue_scripts', array($this, 'admin_assets'));
        add_action('wp_ajax_at_ai_reading_generate_summary', array($this, 'ajax_generate_summary'));
        add_action('wp_ajax_at_ai_reading_generate_audio', array($this, 'ajax_generate_audio'));

        // Front end
        add_action('at_ai_assistant_reading_tools', array($this, 'action_render'));
        add_filter('the_content', array($this, 'auto_insert'), 5);
        add_action('wp_enqueue_scripts', array($this, 'enqueue_front'));
    }

    /* ------------------------------------------------------------------
     * Option helpers
     * ---------------------------------------------------------------- */

    public static function summary_enabled() {
        return (bool) at_ai_assistant_get_option('reading_summary_enabled', false);
    }

    public static function tts_enabled() {
        return (bool) at_ai_assistant_get_option('reading_tts_enabled', false);
    }

    public static function enabled_post_types() {
        $types = at_ai_assistant_get_option('reading_post_types', array());
        return is_array($types) ? array_values(array_filter($types, 'post_type_exists')) : array();
    }

    public static function summary_points() {
        return (int) at_ai_assistant_get_option('reading_summary_points', 5) === 3 ? 3 : 5;
    }

    /**
     * Whether a feature ('summary' | 'tts') is active for the article.
     * Per-article "no" always wins; "yes" enables it even if the type is not listed.
     */
    public static function is_active_for($post_id, $feature) {
        $on = $feature === 'tts' ? self::tts_enabled() : self::summary_enabled();
        if (!$on) {
            return false;
        }
        $override = get_post_meta($post_id, self::META_SHOW, true);
        if ($override === 'no') {
            return false;
        }
        if ($override === 'yes') {
            return true;
        }
        return in_array(get_post_type($post_id), self::enabled_post_types(), true);
    }

    /* ------------------------------------------------------------------
     * Text and hash
     * ---------------------------------------------------------------- */

    /**
     * Clean plain text of an article body, as a reader sees it.
     *
     * Blocks are rendered like the front end does (so ACF block render
     * callbacks run, with the post set up as the global post), then the markup
     * is reduced to text: shortcodes, [n] footnote markers, hidden / screen
     * reader-only nodes, navigation, buttons, forms and media are dropped.
     * Sites exclude further blocks (filter at_ai_assistant_reading_text_exclude_blocks)
     * or elements by class (at_ai_assistant_reading_text_exclude_classes).
     * If rendering yields too little, ACF block field values are used instead.
     */
    public static function get_clean_text($post) {
        $post = get_post($post);
        if (!$post) {
            return '';
        }
        $exclude_blocks = (array) apply_filters('at_ai_assistant_reading_text_exclude_blocks', array(), $post);
        $blocks = parse_blocks($post->post_content);

        $html = self::render_blocks_html($blocks, $exclude_blocks, $post);
        $text = self::html_to_text($html);

        $min = (int) apply_filters('at_ai_assistant_reading_text_min_chars', 200);
        if (mb_strlen($text) < $min) {
            $fallback = self::html_to_text(self::acf_fields_html($blocks, $exclude_blocks));
            if (mb_strlen($fallback) > mb_strlen($text)) {
                $text = $fallback;
            }
        }
        return $text;
    }

    /**
     * Render blocks (minus excluded ones) with $post as the global post.
     */
    private static function render_blocks_html($blocks, $exclude_blocks, $post) {
        $prev = isset($GLOBALS['post']) ? $GLOBALS['post'] : null;
        $GLOBALS['post'] = $post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
        setup_postdata($post);

        $html = '';
        foreach ($blocks as $block) {
            $name = isset($block['blockName']) ? (string) $block['blockName'] : '';
            if ($name !== '' && in_array($name, $exclude_blocks, true)) {
                continue;
            }
            if (apply_filters('at_ai_assistant_reading_skip_block', false, $block, $post)) {
                continue;
            }
            $html .= render_block($block) . "\n";
        }

        if ($prev) {
            $GLOBALS['post'] = $prev; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
            setup_postdata($prev);
        } else {
            wp_reset_postdata();
        }
        return $html;
    }

    /**
     * Fallback: the text-like values stored in ACF blocks' field data.
     */
    private static function acf_fields_html($blocks, $exclude_blocks) {
        $html = '';
        foreach ($blocks as $block) {
            $name = isset($block['blockName']) ? (string) $block['blockName'] : '';
            if (strpos($name, 'acf/') === 0 && !in_array($name, $exclude_blocks, true) && !empty($block['attrs']['data']) && is_array($block['attrs']['data'])) {
                foreach ($block['attrs']['data'] as $key => $value) {
                    if (is_string($value) && $key[0] !== '_' && mb_strlen(wp_strip_all_tags($value)) > 40) {
                        $html .= '<p>' . $value . "</p>\n";
                    }
                }
            }
            if (!empty($block['innerBlocks'])) {
                $html .= self::acf_fields_html($block['innerBlocks'], $exclude_blocks);
            }
        }
        return $html;
    }

    /**
     * Markup to readable plain text.
     */
    private static function html_to_text($html) {
        $html = strip_shortcodes($html);
        $html = preg_replace('#<(script|style|noscript)\b[^>]*>.*?</\1>#is', ' ', $html);
        if (trim($html) === '') {
            return '';
        }

        // Drop noise nodes (DOM): hidden, screen-reader-only, nav, buttons, forms, media,
        // footnote markers, and any class the site excluded.
        $classes = (array) apply_filters(
            'at_ai_assistant_reading_text_exclude_classes',
            array('screen-reader-text', 'sr-only', 'visually-hidden')
        );
        $queries = array(
            '//*[@aria-hidden="true"]',
            '//*[@hidden]',
            '//nav | //button | //form | //figure | //iframe | //svg | //select | //textarea | //sup',
        );
        foreach ($classes as $cls) {
            $cls = preg_replace('/[^A-Za-z0-9_\-]/', '', (string) $cls);
            if ($cls !== '') {
                $queries[] = "//*[contains(concat(' ', normalize-space(@class), ' '), ' {$cls} ')]";
            }
        }
        $prev = libxml_use_internal_errors(true);
        $dom  = new DOMDocument();
        $dom->loadHTML('<?xml encoding="utf-8"?><div id="at-root">' . $html . '</div>', LIBXML_NOERROR | LIBXML_NOWARNING);
        $xp = new DOMXPath($dom);
        foreach ($queries as $q) {
            $nodes = $xp->query($q);
            if ($nodes) {
                foreach (iterator_to_array($nodes) as $node) {
                    if ($node->parentNode && $node->getAttribute('id') !== 'at-root') {
                        $node->parentNode->removeChild($node);
                    }
                }
            }
        }
        $root = $dom->getElementById('at-root');
        $html = '';
        if ($root) {
            foreach ($root->childNodes as $child) {
                $html .= $dom->saveHTML($child);
            }
        }
        libxml_clear_errors();
        libxml_use_internal_errors($prev);

        $html = preg_replace('#</(p|h[1-6]|li|blockquote|div|tr|ul|ol|section)>|<br\s*/?>#i', "\n", $html);
        $text = wp_strip_all_tags($html);
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = preg_replace('/\[\d{1,3}\]/u', '', $text);           // footnote markers
        $text = preg_replace('/[ \t\x{00A0}]+/u', ' ', $text);
        $text = preg_replace('/ *\n[\s]*/u', "\n", $text);
        return trim($text);
    }


    /**
     * Text sent to TTS: title, then body.
     */
    public static function get_tts_text($post) {
        $post = get_post($post);
        return trim(html_entity_decode(wp_strip_all_tags(get_the_title($post)), ENT_QUOTES, 'UTF-8') . ".\n" . self::get_clean_text($post));
    }

    public static function content_hash($post) {
        $post = get_post($post);
        return $post ? md5(get_the_title($post) . "\n" . self::get_clean_text($post)) : '';
    }

    public static function post_language($post_id) {
        return function_exists('at_ai_assistant_get_post_language')
            ? at_ai_assistant_get_post_language($post_id)
            : substr(get_locale(), 0, 2);
    }

    /**
     * Approved summary as an array of lines, or [] (never returns a draft).
     */
    public static function get_approved_summary($post_id) {
        if (!get_post_meta($post_id, self::META_APPROVED, true)) {
            return array();
        }
        return self::summary_lines(get_post_meta($post_id, self::META_SUMMARY, true));
    }

    public static function summary_lines($raw) {
        $out = array();
        foreach (preg_split('/\R/u', (string) $raw) as $line) {
            $line = trim(preg_replace('/^\s*(?:[-*\x{2022}\x{2013}]|\d+[.)])\s*/u', '', $line));
            if ($line !== '') {
                $out[] = $line;
            }
        }
        return $out;
    }

    public static function get_audio_url($post_id) {
        $att = (int) get_post_meta($post_id, self::META_TTS_ATT, true);
        if (!$att || get_post_type($att) !== 'attachment') {
            return '';
        }
        $url = wp_get_attachment_url($att);
        return $url ? $url : '';
    }

    /* ------------------------------------------------------------------
     * Settings screen
     * ---------------------------------------------------------------- */

    public function add_menu() {
        add_submenu_page(
            'wordpress-ai-assistant',
            __('כלי קריאה', 'wordpress-ai-assistant'),
            __('כלי קריאה', 'wordpress-ai-assistant'),
            'manage_options',
            self::PAGE,
            array($this, 'render_settings_page')
        );
    }

    public function register_settings() {
        $bool = array('type' => 'boolean', 'sanitize_callback' => array($this, 'sanitize_bool'));
        register_setting(self::GROUP, 'at_ai_assistant_reading_summary_enabled', $bool);
        register_setting(self::GROUP, 'at_ai_assistant_reading_tts_enabled', $bool);
        register_setting(self::GROUP, 'at_ai_assistant_reading_post_types', array('type' => 'array', 'sanitize_callback' => array($this, 'sanitize_post_types')));
        register_setting(self::GROUP, 'at_ai_assistant_reading_summary_points', array('sanitize_callback' => array($this, 'sanitize_points')));
        register_setting(self::GROUP, 'at_ai_assistant_reading_summary_instructions', array('sanitize_callback' => 'sanitize_textarea_field'));
        register_setting(self::GROUP, 'at_ai_assistant_elevenlabs_api_key', array('sanitize_callback' => array($this, 'sanitize_api_key')));
        register_setting(self::GROUP, 'at_ai_assistant_elevenlabs_model', array('sanitize_callback' => array($this, 'sanitize_model')));
        foreach (array('he', 'ar', 'en') as $l) {
            register_setting(self::GROUP, 'at_ai_assistant_elevenlabs_voice_' . $l, array('sanitize_callback' => array($this, 'sanitize_voice')));
        }
    }

    public function sanitize_bool($v) {
        return empty($v) ? 0 : 1;
    }

    public function sanitize_points($v) {
        return (int) $v === 3 ? 3 : 5;
    }

    public function sanitize_model($v) {
        $v = preg_replace('/[^a-z0-9_\-.]/i', '', (string) $v);
        return $v !== '' ? $v : 'eleven_v3';
    }

    public function sanitize_voice($v) {
        return preg_replace('/[^A-Za-z0-9_\-]/', '', (string) $v);
    }

    public function sanitize_post_types($v) {
        $v = is_array($v) ? $v : array();
        return array_values(array_filter(array_map('sanitize_key', $v), 'post_type_exists'));
    }

    /**
     * Blank submit keeps the stored key; the "remove" checkbox clears it.
     * (Reached only through options.php, which has verified the settings nonce.)
     */
    public function sanitize_api_key($v) {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        if (!empty($_POST['at_ai_reading_clear_key'])) {
            return '';
        }
        $v = trim((string) $v);
        if ($v === '') {
            return (string) get_option('at_ai_assistant_elevenlabs_api_key', '');
        }
        return preg_replace('/[^A-Za-z0-9_\-]/', '', $v);
    }

    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        $types     = get_post_types(array('public' => true), 'objects');
        unset($types['attachment']);
        $selected  = self::enabled_post_types();
        $has_key   = (string) at_ai_assistant_get_option('elevenlabs_api_key', '') !== '';
        $points    = self::summary_points();
        $model     = (string) at_ai_assistant_get_option('elevenlabs_model', 'eleven_v3');
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('כלי קריאה: סיכום והקראה', 'wordpress-ai-assistant'); ?></h1>
            <form method="post" action="options.php">
                <?php settings_fields(self::GROUP); ?>

                <h2><?php esc_html_e('סיכום מאמרים', 'wordpress-ai-assistant'); ?></h2>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php esc_html_e('הפעלה', 'wordpress-ai-assistant'); ?></th>
                        <td><label><input type="checkbox" name="at_ai_assistant_reading_summary_enabled" value="1" <?php checked(self::summary_enabled()); ?>> <?php esc_html_e('הצגת תקציר מאושר בראש המאמר', 'wordpress-ai-assistant'); ?></label>
                        <p class="description"><?php esc_html_e('הסיכום נוצר פעם אחת בניהול, וחייב אישור עורך לפני שהוא מוצג באתר.', 'wordpress-ai-assistant'); ?></p></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="at-ai-reading-points"><?php esc_html_e('מספר נקודות', 'wordpress-ai-assistant'); ?></label></th>
                        <td><select id="at-ai-reading-points" name="at_ai_assistant_reading_summary_points">
                            <option value="3" <?php selected($points, 3); ?>>3</option>
                            <option value="5" <?php selected($points, 5); ?>>5</option>
                        </select></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="at-ai-reading-instr"><?php esc_html_e('הנחיות סגנון', 'wordpress-ai-assistant'); ?></label></th>
                        <td><textarea id="at-ai-reading-instr" name="at_ai_assistant_reading_summary_instructions" rows="4" class="large-text"><?php echo esc_textarea((string) at_ai_assistant_get_option('reading_summary_instructions', '')); ?></textarea>
                        <p class="description"><?php esc_html_e('למשל טון, רמת שפה, ומה להימנע ממנו. מתווסף לפרומפט הסיכום.', 'wordpress-ai-assistant'); ?></p></td>
                    </tr>
                </table>

                <h2><?php esc_html_e('הקראת מאמרים', 'wordpress-ai-assistant'); ?></h2>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php esc_html_e('הפעלה', 'wordpress-ai-assistant'); ?></th>
                        <td><label><input type="checkbox" name="at_ai_assistant_reading_tts_enabled" value="1" <?php checked(self::tts_enabled()); ?>> <?php esc_html_e('הצגת נגן הקראה במאמרים שיש להם קובץ שמע', 'wordpress-ai-assistant'); ?></label></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="at-ai-el-key"><?php esc_html_e('מפתח API של ElevenLabs', 'wordpress-ai-assistant'); ?></label></th>
                        <td>
                            <input type="password" id="at-ai-el-key" name="at_ai_assistant_elevenlabs_api_key" value="" class="regular-text" autocomplete="new-password" placeholder="<?php echo $has_key ? esc_attr__('מוגדר (השאירו ריק כדי לשמור)', 'wordpress-ai-assistant') : ''; ?>">
                            <?php if ($has_key) : ?>
                                <strong><?php esc_html_e('מוגדר', 'wordpress-ai-assistant'); ?></strong>
                                <label><input type="checkbox" name="at_ai_reading_clear_key" value="1"> <?php esc_html_e('הסרת המפתח', 'wordpress-ai-assistant'); ?></label>
                            <?php endif; ?>
                            <p class="description"><?php esc_html_e('המפתח לא מוצג שוב אחרי השמירה.', 'wordpress-ai-assistant'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="at-ai-el-model"><?php esc_html_e('מודל', 'wordpress-ai-assistant'); ?></label></th>
                        <td><input type="text" id="at-ai-el-model" name="at_ai_assistant_elevenlabs_model" value="<?php echo esc_attr($model !== '' ? $model : 'eleven_v3'); ?>" class="regular-text" dir="ltr">
                        <p class="description"><?php esc_html_e('ברירת מחדל eleven_v3 (תומך בעברית ובערבית, עד 5,000 תווים לבקשה; ארוכים יותר מחולקים אוטומטית).', 'wordpress-ai-assistant'); ?></p></td>
                    </tr>
                    <?php foreach (array('he' => __('עברית', 'wordpress-ai-assistant'), 'ar' => __('ערבית', 'wordpress-ai-assistant'), 'en' => __('אנגלית', 'wordpress-ai-assistant')) as $l => $label) : ?>
                    <tr>
                        <th scope="row"><label for="at-ai-el-voice-<?php echo esc_attr($l); ?>"><?php echo esc_html(sprintf(__('Voice ID: %s', 'wordpress-ai-assistant'), $label)); ?></label></th>
                        <td><input type="text" id="at-ai-el-voice-<?php echo esc_attr($l); ?>" name="at_ai_assistant_elevenlabs_voice_<?php echo esc_attr($l); ?>" value="<?php echo esc_attr((string) at_ai_assistant_get_option('elevenlabs_voice_' . $l, '')); ?>" class="regular-text" dir="ltr"></td>
                    </tr>
                    <?php endforeach; ?>
                </table>

                <h2><?php esc_html_e('סוגי תוכן', 'wordpress-ai-assistant'); ?></h2>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><?php esc_html_e('פעיל בסוגי התוכן', 'wordpress-ai-assistant'); ?></th>
                        <td><fieldset>
                            <?php foreach ($types as $slug => $obj) : ?>
                                <label style="display:block"><input type="checkbox" name="at_ai_assistant_reading_post_types[]" value="<?php echo esc_attr($slug); ?>" <?php checked(in_array($slug, $selected, true)); ?>> <?php echo esc_html($obj->labels->singular_name); ?> <code><?php echo esc_html($slug); ?></code></label>
                            <?php endforeach; ?>
                        </fieldset>
                        <p class="description"><?php esc_html_e('בכל מאמר אפשר לעקוף את ההגדרה בתיבת "כלי קריאה".', 'wordpress-ai-assistant'); ?></p></td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    /* ------------------------------------------------------------------
     * Meta box
     * ---------------------------------------------------------------- */

    public function add_meta_box() {
        $types = array_unique(array_merge(self::enabled_post_types(), array()));
        foreach ($types as $type) {
            add_meta_box(
                'at_ai_reading_tools',
                __('כלי קריאה: סיכום והקראה', 'wordpress-ai-assistant'),
                array($this, 'render_meta_box'),
                $type,
                'normal',
                'default'
            );
        }
    }

    public function admin_assets($hook) {
        if (!in_array($hook, array('post.php', 'post-new.php'), true)) {
            return;
        }
        $screen = get_current_screen();
        if (!$screen || !in_array($screen->post_type, self::enabled_post_types(), true)) {
            return;
        }
        wp_enqueue_script(
            'at-ai-reading-tools-admin',
            WORDPRESS_AI_ASSISTANT_URL . 'admin/js/reading-tools.js',
            array(),
            WORDPRESS_AI_ASSISTANT_VERSION,
            true
        );
        wp_localize_script('at-ai-reading-tools-admin', 'atAiReading', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce(self::NONCE),
            'i18n'    => array(
                'working' => __('מייצר... זה יכול לקחת זמן', 'wordpress-ai-assistant'),
                'done'    => __('בוצע', 'wordpress-ai-assistant'),
                'error'   => __('שגיאה', 'wordpress-ai-assistant'),
                'saveFirst' => __('יש לשמור את המאמר כטיוטה לפני היצירה', 'wordpress-ai-assistant'),
            ),
        ));
    }

    public function render_meta_box($post) {
        wp_nonce_field(self::NONCE, 'at_ai_reading_nonce');
        $show     = get_post_meta($post->ID, self::META_SHOW, true);
        $summary  = (string) get_post_meta($post->ID, self::META_SUMMARY, true);
        $approved = (bool) get_post_meta($post->ID, self::META_APPROVED, true);
        $hash     = self::content_hash($post);
        $sum_stale = $summary !== '' && get_post_meta($post->ID, self::META_SUM_HASH, true) !== $hash;
        $audio    = self::get_audio_url($post->ID);
        $tts_stale = $audio && get_post_meta($post->ID, self::META_TTS_HASH, true) !== $hash;
        ?>
        <div class="at-ai-reading-box" data-post-id="<?php echo (int) $post->ID; ?>">
            <p>
                <label for="at-ai-reading-show"><strong><?php esc_html_e('הצג במאמר זה', 'wordpress-ai-assistant'); ?></strong></label>
                <select id="at-ai-reading-show" name="at_ai_reading_show">
                    <option value="" <?php selected($show, ''); ?>><?php esc_html_e('ברירת מחדל', 'wordpress-ai-assistant'); ?></option>
                    <option value="yes" <?php selected($show, 'yes'); ?>><?php esc_html_e('כן', 'wordpress-ai-assistant'); ?></option>
                    <option value="no" <?php selected($show, 'no'); ?>><?php esc_html_e('לא', 'wordpress-ai-assistant'); ?></option>
                </select>
            </p>

            <h4><?php esc_html_e('סיכום', 'wordpress-ai-assistant'); ?></h4>
            <?php if (!self::summary_enabled()) : ?>
                <p class="description"><?php esc_html_e('סיכום מאמרים כבוי בהגדרות "כלי קריאה".', 'wordpress-ai-assistant'); ?></p>
            <?php endif; ?>
            <p>
                <label for="at-ai-reading-summary" class="screen-reader-text"><?php esc_html_e('טקסט הסיכום', 'wordpress-ai-assistant'); ?></label>
                <textarea id="at-ai-reading-summary" name="at_ai_reading_summary" rows="7" class="large-text"><?php echo esc_textarea($summary); ?></textarea>
            </p>
            <p id="at-ai-reading-summary-stale" class="notice notice-warning inline" <?php echo $sum_stale ? '' : 'hidden'; ?>><?php esc_html_e('לא עדכני: תוכן המאמר השתנה מאז יצירת הסיכום.', 'wordpress-ai-assistant'); ?></p>
            <p>
                <button type="button" class="button" id="at-ai-gen-summary"><?php esc_html_e('צור סיכום', 'wordpress-ai-assistant'); ?></button>
                <label style="margin-inline-start:1em"><input type="checkbox" name="at_ai_reading_summary_approved" value="1" <?php checked($approved); ?>> <?php esc_html_e('אישור סיכום (רק סיכום מאושר מוצג באתר)', 'wordpress-ai-assistant'); ?></label>
            </p>

            <h4><?php esc_html_e('הקראה', 'wordpress-ai-assistant'); ?></h4>
            <?php if (!self::tts_enabled()) : ?>
                <p class="description"><?php esc_html_e('הקראת מאמרים כבויה בהגדרות "כלי קריאה".', 'wordpress-ai-assistant'); ?></p>
            <?php endif; ?>
            <p id="at-ai-reading-tts-stale" class="notice notice-warning inline" <?php echo $tts_stale ? '' : 'hidden'; ?>><?php esc_html_e('לא עדכני: תוכן המאמר השתנה מאז יצירת ההקראה.', 'wordpress-ai-assistant'); ?></p>
            <p>
                <button type="button" class="button" id="at-ai-gen-audio"><?php esc_html_e('צור הקראה', 'wordpress-ai-assistant'); ?></button>
            </p>
            <audio id="at-ai-reading-audio" controls preload="none" <?php echo $audio ? 'src="' . esc_url($audio) . '"' : 'hidden'; ?>></audio>
            <p id="at-ai-reading-status" role="status" aria-live="polite"></p>
        </div>
        <?php
    }

    public function save_meta($post_id, $post) {
        if (!isset($_POST['at_ai_reading_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['at_ai_reading_nonce'])), self::NONCE)) {
            return;
        }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        if (wp_is_post_revision($post_id) || !current_user_can('edit_post', $post_id)) {
            return;
        }

        $show = isset($_POST['at_ai_reading_show']) ? sanitize_key(wp_unslash($_POST['at_ai_reading_show'])) : '';
        if (!in_array($show, array('yes', 'no'), true)) {
            delete_post_meta($post_id, self::META_SHOW);
        } else {
            update_post_meta($post_id, self::META_SHOW, $show);
        }

        $raw   = isset($_POST['at_ai_reading_summary']) ? sanitize_textarea_field(wp_unslash($_POST['at_ai_reading_summary'])) : '';
        $lines = self::summary_lines($raw);
        $old   = (string) get_post_meta($post_id, self::META_SUMMARY, true);
        $new   = implode("\n", $lines);
        update_post_meta($post_id, self::META_SUMMARY, $new);
        if ($new !== '' && $old === '') {
            // Manually written summary: tie it to the current content.
            update_post_meta($post_id, self::META_SUM_HASH, self::content_hash($post_id));
        }
        $approve = !empty($_POST['at_ai_reading_summary_approved']) && $new !== '';
        update_post_meta($post_id, self::META_APPROVED, $approve ? 1 : 0);
    }


    /* ------------------------------------------------------------------
     * Summary generation
     * ---------------------------------------------------------------- */

    /**
     * Build the summary prompt for an article.
     */
    public static function build_summary_prompt($post) {
        $post   = get_post($post);
        $points = self::summary_points();
        $lang   = self::post_language($post->ID);
        $name   = function_exists('at_ai_assistant_get_language_name') ? at_ai_assistant_get_language_name($lang) : $lang;
        $body   = self::get_clean_text($post);
        $max    = (int) apply_filters('at_ai_assistant_reading_summary_max_chars', 12000);
        if (mb_strlen($body) > $max) {
            $body = mb_substr($body, 0, $max);
        }

        $prompt  = "Summarise the article below for readers who want a quick overview.\n";
        $prompt .= "Rules:\n";
        $prompt .= "- Write exactly {$points} bullet points, in {$name} ({$lang}).\n";
        $prompt .= "- Output plain text only: one point per line, no numbering, no bullet symbols, no markdown, no heading, no intro or closing sentence.\n";
        $prompt .= "- Each point is one complete sentence of at most 25 words.\n";
        $prompt .= "- Use only facts that appear in the article. Do not add opinions, advice or details that are not in the text.\n";
        $prompt .= "- The article may deal with sensitive subjects. Stay factual and neutral, and do not include names or identifying details of children or victims.\n";
        $extra = trim((string) at_ai_assistant_get_option('reading_summary_instructions', ''));
        if ($extra !== '') {
            $prompt .= "- Additional style instructions from the site editor: {$extra}\n";
        }
        $prompt .= "\nTitle: " . wp_strip_all_tags(get_the_title($post)) . "\n\nArticle:\n" . $body;
        return apply_filters('at_ai_assistant_reading_summary_prompt', $prompt, $post);
    }

    /**
     * Generate and store a DRAFT (unapproved) summary.
     *
     * @return string|WP_Error The stored summary text.
     */
    public static function generate_summary($post_id) {
        $post = get_post($post_id);
        if (!$post) {
            return new WP_Error('at_reading_no_post', __('המאמר לא נמצא', 'wordpress-ai-assistant'));
        }
        if (mb_strlen(self::get_clean_text($post)) < 200) {
            return new WP_Error('at_reading_short', __('אין מספיק טקסט בגוף המאמר לסיכום', 'wordpress-ai-assistant'));
        }

        $result = AT_AI_Manager::get_instance()->generate_text(
            self::build_summary_prompt($post),
            array('max_tokens' => 1500, 'temperature' => 0.3),
            $post->ID
        );
        if (is_wp_error($result)) {
            return $result;
        }
        $lines = array_slice(self::summary_lines(isset($result['text']) ? $result['text'] : ''), 0, self::summary_points());
        if (!$lines) {
            return new WP_Error('at_reading_empty', __('ה-AI לא החזיר סיכום', 'wordpress-ai-assistant'));
        }
        $text = implode("\n", $lines);
        update_post_meta($post->ID, self::META_SUMMARY, $text);
        update_post_meta($post->ID, self::META_APPROVED, 0);   // an editor must approve it
        update_post_meta($post->ID, self::META_SUM_HASH, self::content_hash($post));
        at_ai_assistant_log('reading_summary', 'success', 'Summary draft generated', array(), $post->ID);
        return $text;
    }

    public function ajax_generate_summary() {
        check_ajax_referer(self::NONCE, 'nonce');
        $post_id = isset($_POST['post_id']) ? absint($_POST['post_id']) : 0;
        if (!$post_id || !current_user_can('edit_post', $post_id)) {
            wp_send_json_error(array('message' => __('אין הרשאה', 'wordpress-ai-assistant')), 403);
        }
        $res = self::generate_summary($post_id);
        if (is_wp_error($res)) {
            wp_send_json_error(array('message' => $res->get_error_message()));
        }
        wp_send_json_success(array('summary' => $res));
    }


    /* ------------------------------------------------------------------
     * Read-aloud (TTS)
     * ---------------------------------------------------------------- */

    /**
     * Generate the MP3 for an article and store it as a media attachment.
     * The previous attachment (if any) is deleted.
     *
     * @return int|WP_Error New attachment ID.
     */
    public static function generate_audio($post_id) {
        $post = get_post($post_id);
        if (!$post) {
            return new WP_Error('at_reading_no_post', __('המאמר לא נמצא', 'wordpress-ai-assistant'));
        }
        $text = self::get_tts_text($post);
        if (mb_strlen($text) < 50) {
            return new WP_Error('at_reading_short', __('אין מספיק טקסט להקראה', 'wordpress-ai-assistant'));
        }

        $tts   = new AT_ElevenLabs_TTS();
        $audio = $tts->synthesize($text, self::post_language($post->ID), $post->ID);
        if (is_wp_error($audio)) {
            return $audio;
        }

        $filename = 'read-aloud-' . $post->ID . '-' . substr(md5($audio), 0, 8) . '.mp3';
        $upload   = wp_upload_bits($filename, null, $audio);
        if (!empty($upload['error'])) {
            return new WP_Error('at_reading_upload', $upload['error']);
        }
        $att_id = wp_insert_attachment(array(
            'post_mime_type' => 'audio/mpeg',
            'post_title'     => sprintf(
                /* translators: %s: article title */
                __('הקראה: %s', 'wordpress-ai-assistant'),
                wp_strip_all_tags(get_the_title($post))
            ),
            'post_status'    => 'inherit',
            'post_parent'    => $post->ID,
        ), $upload['file'], $post->ID);
        if (is_wp_error($att_id) || !$att_id) {
            return is_wp_error($att_id) ? $att_id : new WP_Error('at_reading_attach', __('שמירת הקובץ נכשלה', 'wordpress-ai-assistant'));
        }
        if (!function_exists('wp_generate_attachment_metadata')) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
        }
        wp_update_attachment_metadata($att_id, wp_generate_attachment_metadata($att_id, $upload['file']));

        $old = (int) get_post_meta($post->ID, self::META_TTS_ATT, true);
        update_post_meta($post->ID, self::META_TTS_ATT, $att_id);
        update_post_meta($post->ID, self::META_TTS_HASH, self::content_hash($post));
        if ($old && $old !== $att_id && get_post_type($old) === 'attachment') {
            wp_delete_attachment($old, true);
        }
        at_ai_assistant_log('reading_tts', 'success', 'Read-aloud generated', array('attachment' => $att_id), $post->ID);
        return $att_id;
    }

    public function ajax_generate_audio() {
        check_ajax_referer(self::NONCE, 'nonce');
        $post_id = isset($_POST['post_id']) ? absint($_POST['post_id']) : 0;
        if (!$post_id || !current_user_can('edit_post', $post_id)) {
            wp_send_json_error(array('message' => __('אין הרשאה', 'wordpress-ai-assistant')), 403);
        }
        @set_time_limit(300);
        $res = self::generate_audio($post_id);
        if (is_wp_error($res)) {
            wp_send_json_error(array('message' => $res->get_error_message()));
        }
        wp_send_json_success(array('url' => self::get_audio_url($post_id), 'attachment' => $res));
    }

    /* ------------------------------------------------------------------
     * Front end
     * ---------------------------------------------------------------- */

    /** @var array<int,bool> Articles already rendered on this request. */
    private static $rendered = array();

    /**
     * What to show for an article: ['summary' => string[], 'audio' => string].
     * Unapproved summaries are never returned.
     */
    public static function get_front_data($post_id) {
        $post_id = (int) $post_id;
        $data    = array('summary' => array(), 'audio' => '');
        if (!$post_id || get_post_status($post_id) !== 'publish' || post_password_required($post_id)) {
            return $data;
        }
        if (self::is_active_for($post_id, 'summary')) {
            $data['summary'] = self::get_approved_summary($post_id);
        }
        if (self::is_active_for($post_id, 'tts')) {
            $data['audio'] = self::get_audio_url($post_id);
        }
        return $data;
    }

    /**
     * The component markup (empty string when there is nothing to show).
     */
    public static function render($post_id = null) {
        $post_id = $post_id ? (int) $post_id : (int) get_the_ID();
        $data    = self::get_front_data($post_id);
        if (!$data['summary'] && !$data['audio']) {
            return '';
        }
        self::$rendered[$post_id] = true;
        $uid = 'at-ai-reading-' . $post_id;

        ob_start();
        ?>
        <section class="at-ai-reading" aria-label="<?php echo esc_attr__('כלי קריאה', 'wordpress-ai-assistant'); ?>">
            <?php if ($data['audio']) : ?>
                <div class="at-ai-reading__audio">
                    <p class="at-ai-reading__label" id="<?php echo esc_attr($uid); ?>-audio-label"><?php echo esc_html__('האזנה למאמר', 'wordpress-ai-assistant'); ?></p>
                    <div class="at-ai-reading__player">
                        <audio class="at-ai-reading__audio-el" controls preload="none" src="<?php echo esc_url($data['audio']); ?>" aria-labelledby="<?php echo esc_attr($uid); ?>-audio-label"></audio>
                        <button type="button" class="at-ai-reading__speed" aria-pressed="false"
                                data-speeds="1,1.25,1.5"
                                data-label="<?php echo esc_attr__('מהירות: %s', 'wordpress-ai-assistant'); ?>"
                                data-live="<?php echo esc_attr__('מהירות ההשמעה: %s', 'wordpress-ai-assistant'); ?>">
                            <?php echo esc_html(sprintf(__('מהירות: %s', 'wordpress-ai-assistant'), '1x')); ?>
                        </button>
                    </div>
                    <span class="screen-reader-text at-ai-reading__live" role="status" aria-live="polite"></span>
                </div>
            <?php endif; ?>
            <?php if ($data['summary']) : ?>
                <details class="at-ai-reading__summary">
                    <summary><?php echo esc_html__('תקציר', 'wordpress-ai-assistant'); ?></summary>
                    <ul>
                        <?php foreach ($data['summary'] as $line) : ?>
                            <li><?php echo esc_html($line); ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <p class="at-ai-reading__note"><?php echo esc_html(apply_filters('at_ai_assistant_reading_tools_note', __('נוצר בעזרת בינה מלאכותית ונבדק על ידי עורך', 'wordpress-ai-assistant'), $post_id)); ?></p>
                </details>
            <?php endif; ?>
        </section>
        <?php
        return (string) ob_get_clean();
    }

    public function action_render($post_id = null) {
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in render().
        echo self::render($post_id);
    }

    /**
     * Auto-insert at the top of the content unless the theme places it
     * itself (filter at_ai_assistant_reading_tools_auto_insert -> false).
     */
    public function auto_insert($content) {
        if (!is_singular() || !in_the_loop() || !is_main_query()) {
            return $content;
        }
        if (!apply_filters('at_ai_assistant_reading_tools_auto_insert', true)) {
            return $content;
        }
        $post_id = get_the_ID();
        if (isset(self::$rendered[$post_id])) {
            return $content;
        }
        return self::render($post_id) . $content;
    }

    public function enqueue_front() {
        if (!is_singular()) {
            return;
        }
        $data = self::get_front_data(get_queried_object_id());
        if (!$data['summary'] && !$data['audio']) {
            return;
        }
        // Themes that style the component themselves return false here.
        if (apply_filters('at_ai_assistant_reading_tools_enqueue_css', true)) {
            wp_enqueue_style('at-ai-reading-tools', WORDPRESS_AI_ASSISTANT_URL . 'public/css/reading-tools.css', array(), WORDPRESS_AI_ASSISTANT_VERSION);
        }
        if ($data['audio']) {
            wp_enqueue_script('at-ai-reading-tools', WORDPRESS_AI_ASSISTANT_URL . 'public/js/reading-tools.js', array(), WORDPRESS_AI_ASSISTANT_VERSION, true);
        }
    }
}

/**
 * Render the summary + read-aloud component for an article.
 *
 * @param int|null $post_id Defaults to the current post.
 * @param bool     $echo    Echo (default) or return the markup.
 * @return string Markup ('' when there is nothing approved to show).
 */
function at_ai_assistant_render_reading_tools($post_id = null, $echo = true) {
    $html = AT_Reading_Tools::render($post_id);
    if ($echo) {
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in render().
        echo $html;
    }
    return $html;
}
