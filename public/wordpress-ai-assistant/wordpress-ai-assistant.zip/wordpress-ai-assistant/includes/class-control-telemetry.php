<?php

defined('ABSPATH') || exit;

final class AT_AI_Control_Telemetry
{
    public static function register($registry)
    {
        if (!is_object($registry) || !method_exists($registry, 'register')) {
            return;
        }

        $registry->register('wordpress-ai-assistant', array(__CLASS__, 'snapshot'));
    }

    public static function snapshot()
    {
        $provider = sanitize_key((string) at_ai_assistant_get_option('active_provider', 'openai'));
        $credentials = at_ai_assistant_get_option('ai_credentials', array());
        $api_key = is_array($credentials)
            ? (string) ($credentials[$provider]['api_key'] ?? '')
            : '';
        $configured = '' !== trim($api_key);

        return array(
            'name' => 'WordPress AI Assistant',
            'version' => WORDPRESS_AI_ASSISTANT_VERSION,
            'status' => $configured ? 'ready' : 'degraded',
            'status_reason' => $configured ? null : 'missing_provider_credentials',
            'capabilities' => array(
                'content.optimize',
                'content.translate',
                'media.alt_text',
                'media.caption',
                'taxonomy.suggest',
                'chat.respond',
            ),
            'metrics' => array(
                'provider' => $provider,
                'model' => (string) at_ai_assistant_get_option($provider . '_model', ''),
                'configured' => $configured,
                'chat_enabled' => (bool) at_ai_assistant_get_option('chat_enabled', false),
                'auto_alt_enabled' => (bool) at_ai_assistant_get_option('auto_generate_alt_text', true),
                'auto_tagging_enabled' => (bool) at_ai_assistant_get_option('auto_tagging_enabled', false),
            ),
            'links' => array(
                'settings' => admin_url('admin.php?page=wordpress-ai-assistant'),
            ),
        );
    }
}

add_action('at_control_register_integrations', array('AT_AI_Control_Telemetry', 'register'));
