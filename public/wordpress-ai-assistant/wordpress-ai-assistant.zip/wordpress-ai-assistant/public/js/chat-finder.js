/**
 * Accessible content-finder chat (vanilla JS, no dependencies).
 * Dialog semantics: focus moves in, is trapped, Esc closes, focus returns to the launcher.
 */
(function () {
    'use strict';

    var cfg = window.atAiFinder;
    var root = document.querySelector('[data-at-chat]');
    if (!cfg || !root) { return; }

    var S = cfg.strings || {};
    var launcher = root.querySelector('.at-chat__launcher');
    var panel = root.querySelector('.at-chat__panel');
    var closeBtn = root.querySelector('.at-chat__close');
    var log = root.querySelector('.at-chat__log');
    var form = root.querySelector('.at-chat__form');
    var input = root.querySelector('.at-chat__input');
    var sendBtn = root.querySelector('.at-chat__send');
    var chips = root.querySelector('.at-chat__suggestions');

    var history = [];
    var busy = false;
    var inerted = [];
    var greeted = false;

    function isOpen() { return !panel.hidden; }

    function setInert(on) {
        if (on) {
            Array.prototype.forEach.call(document.body.children, function (el) {
                if (el === root || el.tagName === 'SCRIPT' || el.tagName === 'STYLE' || el.hasAttribute('inert')) { return; }
                el.setAttribute('inert', '');
                inerted.push(el);
            });
        } else {
            inerted.forEach(function (el) { el.removeAttribute('inert'); });
            inerted = [];
        }
    }

    function open() {
        panel.hidden = false;
        launcher.setAttribute('aria-expanded', 'true');
        root.classList.add('is-open');
        setInert(true);
        if (!greeted) {
            greeted = true;
            addMessage('assistant', S.greeting || '');
        }
        input.focus();
    }

    function close() {
        panel.hidden = true;
        launcher.setAttribute('aria-expanded', 'false');
        root.classList.remove('is-open');
        setInert(false);
        launcher.focus();
    }

    function focusables() {
        return Array.prototype.filter.call(
            panel.querySelectorAll('a[href], button:not([disabled]), textarea:not([disabled]), [tabindex="0"]'),
            function (el) { return !el.hidden && el.offsetParent !== null; }
        );
    }

    // Append text with safe links: [label](url) and bare http(s) URLs.
    function appendRich(parent, text) {
        var re = /\*\*([^*]+)\*\*|\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)|(https?:\/\/[^\s<>"')\]]+)/g;
        var last = 0, m;
        while ((m = re.exec(text)) !== null) {
            if (m.index > last) { parent.appendChild(document.createTextNode(text.slice(last, m.index))); }
            if (m[1]) {
                var strong = document.createElement('strong');
                strong.textContent = m[1];
                parent.appendChild(strong);
            } else {
                var a = document.createElement('a');
                a.href = m[3] || m[4];
                a.textContent = m[2] || m[4];
                a.className = 'at-chat__link';
                parent.appendChild(a);
            }
            last = re.lastIndex;
        }
        if (last < text.length) { parent.appendChild(document.createTextNode(text.slice(last))); }
    }

    function renderText(parent, text) {
        String(text).split(/\n{2,}/).forEach(function (para) {
            var p = document.createElement('p');
            p.className = 'at-chat__para';
            var lines = para.split('\n');
            lines.forEach(function (line, i) {
                appendRich(p, line);
                if (i < lines.length - 1) { p.appendChild(document.createElement('br')); }
            });
            parent.appendChild(p);
        });
    }

    function addMessage(role, text, extra) {
        extra = extra || {};
        var wrap = document.createElement('div');
        wrap.className = 'at-chat__msg at-chat__msg--' + role + (extra.emergency ? ' at-chat__msg--emergency' : '');
        var who = document.createElement('span');
        who.className = 'at-chat__sr';
        who.textContent = role === 'user' ? S.you : S.assistant;
        wrap.appendChild(who);
        renderText(wrap, text);

        if (extra.items && extra.items.length) {
            var h = document.createElement('p');
            h.className = 'at-chat__sr';
            h.textContent = S.results;
            wrap.appendChild(h);
            var ul = document.createElement('ul');
            ul.className = 'at-chat__cards';
            extra.items.forEach(function (it) {
                var li = document.createElement('li');
                var a = document.createElement('a');
                a.className = 'at-chat__card';
                a.href = it.url;
                if (it.type) {
                    var t = document.createElement('span');
                    t.className = 'at-chat__card-type';
                    t.textContent = it.type;
                    a.appendChild(t);
                }
                var title = document.createElement('span');
                title.className = 'at-chat__card-title';
                title.textContent = it.title;
                a.appendChild(title);
                if (it.meta) {
                    var meta = document.createElement('span');
                    meta.className = 'at-chat__card-meta';
                    meta.textContent = it.meta;
                    a.appendChild(meta);
                }
                li.appendChild(a);
                ul.appendChild(li);
            });
            wrap.appendChild(ul);
        }
        log.appendChild(wrap);
        log.scrollTop = log.scrollHeight;
        return wrap;
    }

    function setBusy(on) {
        busy = on;
        sendBtn.disabled = on;
        input.setAttribute('aria-busy', on ? 'true' : 'false');
        root.classList.toggle('is-busy', on);
    }

    function send(text) {
        text = (text || '').trim();
        if (!text || busy) { return; }
        if (text.length > cfg.maxLength) { text = text.slice(0, cfg.maxLength); }

        addMessage('user', text);
        input.value = '';
        if (chips) { chips.hidden = true; }
        setBusy(true);
        var loading = addMessage('assistant', S.loading);
        loading.classList.add('at-chat__msg--loading');

        var body = new URLSearchParams();
        body.set('action', 'at_ai_chat_send_message');
        body.set('nonce', cfg.nonce || '');
        body.set('message', text);
        body.set('language', cfg.lang);
        body.set('history', JSON.stringify(history.slice(-cfg.maxHistory)));

        fetch(cfg.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: body.toString()
        }).then(function (r) {
            return r.json().catch(function () { return { success: false, data: {} }; });
        }).then(function (res) {
            loading.remove();
            if (res && res.success) {
                var d = res.data;
                addMessage('assistant', d.text || d.response || '', { items: d.items, emergency: !!d.emergency });
                if (!d.emergency) {
                    history.push({ role: 'user', content: text });
                    history.push({ role: 'assistant', content: d.text || d.response || '' });
                    history = history.slice(-cfg.maxHistory);
                }
            } else {
                var msg = res && res.data && res.data.message ? res.data.message : S.error;
                addMessage('assistant', msg);
            }
        }).catch(function () {
            loading.remove();
            addMessage('assistant', S.error);
        }).then(function () {
            setBusy(false);
            input.focus();
        });
    }

    launcher.addEventListener('click', function () { isOpen() ? close() : open(); });
    closeBtn.addEventListener('click', close);

    document.addEventListener('keydown', function (e) {
        if (!isOpen()) { return; }
        if (e.key === 'Escape') {
            e.preventDefault();
            e.stopPropagation();
            close();
            return;
        }
        if (e.key === 'Tab') {
            var f = focusables();
            if (!f.length) { return; }
            if (!panel.contains(document.activeElement)) { e.preventDefault(); f[0].focus(); return; }
            var first = f[0], lastEl = f[f.length - 1];
            if (e.shiftKey && document.activeElement === first) { e.preventDefault(); lastEl.focus(); }
            else if (!e.shiftKey && document.activeElement === lastEl) { e.preventDefault(); first.focus(); }
        }
    });

    form.addEventListener('submit', function (e) { e.preventDefault(); send(input.value); });

    input.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
            e.preventDefault();
            send(input.value);
        }
    });

    if (chips) {
        chips.addEventListener('click', function (e) {
            var btn = e.target.closest('.at-chat__chip');
            if (btn) { send(btn.textContent); }
        });
    }
}());
