/* Reading tools front end: playback speed toggle for the article audio. */
(function () {
    'use strict';

    function init(root) {
        var audio = root.querySelector('audio');
        var btn = root.querySelector('.at-ai-reading__speed');
        var live = root.querySelector('.at-ai-reading__live');
        if (!audio || !btn) { return; }

        var speeds = (btn.getAttribute('data-speeds') || '1,1.25,1.5').split(',').map(Number);
        var label = btn.getAttribute('data-label') || '%s';
        var liveTpl = btn.getAttribute('data-live') || '%s';
        var i = 0;

        function fmt(n) { return String(n) + 'x'; }

        function apply() {
            var sp = speeds[i];
            audio.playbackRate = sp;
            btn.textContent = label.replace('%s', fmt(sp));
            btn.setAttribute('aria-pressed', sp === 1 ? 'false' : 'true');
            if (live) { live.textContent = liveTpl.replace('%s', fmt(sp)); }
        }

        btn.addEventListener('click', function () {
            i = (i + 1) % speeds.length;
            apply();
        });
        // Browsers reset playbackRate when the media (re)loads.
        audio.addEventListener('loadedmetadata', function () { audio.playbackRate = speeds[i]; });
        audio.addEventListener('play', function () { audio.playbackRate = speeds[i]; });
    }

    document.addEventListener('DOMContentLoaded', function () {
        var roots = document.querySelectorAll('.at-ai-reading');
        for (var k = 0; k < roots.length; k++) { init(roots[k]); }
    });
})();
