<?php
/**
 * Accessible content-finder chat: launcher button + modal dialog.
 *
 * @package WordPress_AI_Assistant
 * @var array  $d   Finder data.
 * @var array  $s   Strings.
 * @var string $dir rtl|ltr.
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="at-chat<?php echo 'start' === $d['position'] ? ' at-chat--start' : ''; ?>" data-at-chat dir="<?php echo esc_attr($dir); ?>" lang="<?php echo esc_attr($d['lang']); ?>">
    <button type="button" class="at-chat__launcher" aria-haspopup="dialog" aria-expanded="false" aria-controls="at-chat-panel">
        <svg class="at-chat__icon" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M21 15a2 2 0 0 1-2 2H8l-5 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><circle cx="11" cy="10" r="3.2"/><path d="m16 15-2.4-2.4"/></svg>
        <span class="at-chat__launcher-label"><?php echo esc_html($s['launcher']); ?></span>
    </button>

    <div class="at-chat__panel" id="at-chat-panel" role="dialog" aria-modal="true" aria-labelledby="at-chat-title" aria-describedby="at-chat-disclaimer" hidden>
        <div class="at-chat__header">
            <h2 class="at-chat__title" id="at-chat-title"><?php echo esc_html($s['title']); ?></h2>
            <button type="button" class="at-chat__close" aria-label="<?php echo esc_attr($s['close']); ?>">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true" focusable="false"><path d="M5 5l14 14M19 5L5 19"/></svg>
            </button>
        </div>

        <p class="at-chat__disclaimer" id="at-chat-disclaimer"><?php echo esc_html($s['disclaimer']); ?></p>

        <div class="at-chat__log" role="log" aria-live="polite" aria-relevant="additions" aria-label="<?php echo esc_attr($s['log_label']); ?>" tabindex="0"></div>

        <?php if (!empty($d['suggestions'])) : ?>
            <div class="at-chat__suggestions" role="group" aria-label="<?php echo esc_attr($s['suggestions']); ?>">
                <?php foreach ($d['suggestions'] as $suggestion) : ?>
                    <button type="button" class="at-chat__chip"><?php echo esc_html($suggestion); ?></button>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form class="at-chat__form" novalidate>
            <label class="at-chat__sr" for="at-chat-input"><?php echo esc_html($s['input_label']); ?></label>
            <textarea class="at-chat__input" id="at-chat-input" rows="2" maxlength="<?php echo (int) $d['maxLength']; ?>" placeholder="<?php echo esc_attr($s['placeholder']); ?>" aria-describedby="at-chat-disclaimer" autocomplete="off"></textarea>
            <button type="submit" class="at-chat__send">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" class="at-chat__send-icon"><path d="M22 2 11 13"/><path d="M22 2 15 22l-4-9-9-4z"/></svg>
                <span class="at-chat__send-label"><?php echo esc_html($s['send']); ?></span>
            </button>
        </form>
    </div>
</div>
